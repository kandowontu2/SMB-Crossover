"""Fit the user's original Kamikaze naked Mario skin to native SMB poses.

Every used 8x8 tile is authenticated against original SMB pixels, including
preflipped source tiles. No approximated or redrawn player art is generated.
"""
from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[1]
SOURCE = Path("C:/NES/the stash/Kamikaze_Mario_DX_Plus_V1.9_SMB1_Hack.nes")
BASE = Path("C:/NES/Super Mario Bros. (World).nes")
OUT = ROOT / "build/kamikaze-mario-art-v1"


def sha(data):
    return hashlib.sha256(data).hexdigest()


def binding(path):
    p = Path(path)
    b = p.read_bytes()
    return dict(path=str(p.resolve()), bytes=len(b), sha256=sha(b))


def flip(data, horizontal, vertical):
    out = []
    for plane in [0, 8]:
        rows = data[plane:plane+8]
        for row in rows[::-1] if vertical else rows:
            out.append(int(f"{row:08b}"[::-1], 2) if horizontal else row)
    return bytes(out)


def main():
    OUT.mkdir(exist_ok=True)
    receipt = OUT / "source-art.json"
    assert not receipt.exists(), "Preserve frozen original-art proof"
    raw, original = SOURCE.read_bytes(), BASE.read_bytes()
    assert sha(raw) == "5e866dab7fd0d3f402dff679748a68f9c98d32ffa6c970923be97b79f33617d1"
    assert sha(original) == "0b3d9e1f01ed1668205bab34d6c82b0e281456e137352e4f36a9b2cfa3b66dea"
    assert len(raw) == 98320 and raw[4:7] == bytes([5, 2, 16])
    source_chr = raw[16+5*16384:]
    base_chr = original[16+2*16384:]
    host_path = ROOT / "chr/mmc5/sprites_mario.chr"
    host = host_path.read_bytes()
    assert len(host) == 4096 and len(source_chr) == 16384
    output, records = bytearray(host), []
    for page in range(4):
        # Actual native Mario pose definitions use pairs00..3A only. The four
        # remaining editor-marker tiles keep original host bytes; admission
        # controls independently decode compiled records to prove this bound.
        for local in range(60):
            index = page*64+local
            pattern = host[index*16:index*16+16]
            matches = []
            for tile in range(256):
                base_tile = base_chr[tile*16:tile*16+16]
                for horizontal, vertical in [(False,False),(True,False),(False,True),(True,True)]:
                    if flip(base_tile,horizontal,vertical) == pattern:
                        replacement = flip(source_chr[tile*16:tile*16+16],horizontal,vertical)
                        matches.append((tile,horizontal,vertical,replacement))
            assert matches, ("No exact source pose tile",page,local)
            assert len({v[3] for v in matches}) == 1, ("Ambiguous changed source tile",page,local)
            tile,horizontal,vertical,replacement = matches[0]
            output[index*16:index*16+16] = replacement
            records.append(dict(host_page=page, host_tile=local, original_tile=tile,
                                flip_H=horizontal,flip_V=vertical,
                                all_matching_replacements_equal=True,
                                replacement_sha256=sha(replacement)))
    target = ROOT / "chr/characters/kamikaze-mario.chr"
    target.write_bytes(output)
    proof = dict(status="PASS_EXACT_ORIGINAL_SKIN_TILE_EXTRACTION_NOT_HOST_OR_NATIVE_ADMISSION",
                 source=binding(SOURCE), original=binding(BASE), host=binding(host_path),
                 output=binding(target), bindings=[binding(Path(__file__))],
                 exact_used_tiles=len(records), records=records,
                 planned_CHR_pages=[696,697,698,699],
                 scope="Original first CHR bank's naked Mario patterns, fitted by exact original-SMB tile/flip equality to existing native Mario poses. Existing physics, abilities, hitboxes and pose geometry remain host-owned.",
                 remaining=["Decode actual compiled native Mario records to qualify00..3B tile bound",
                            "Actual CHR publication and menu/lives/gameplay/scene transitions",
                            "Native hardware-limit-on gameplay and palette/visual review"])
    receipt.write_text(json.dumps(proof,indent=2)+"\n")
    print(json.dumps(dict(output=str(target.relative_to(ROOT)),sha256=sha(output),tiles=len(records))))


if __name__ == "__main__":
    main()
