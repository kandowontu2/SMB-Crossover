"""Bounded compiled-CPU skin admission; native PPU testing is separate."""
from pathlib import Path
import argparse,hashlib,itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(R/'tools/audit'))
from sunny_integrated_controls_v1 import *

def pub(q,p=0x71):
 c,w,_=run(q,'X5PublishChr',a=87,x=177,y=91,p=p)
 upper=0;pages={}
 for at,v in w:
  if at==0x5130:upper=v&3
  if 0x5120<=at<=0x512b:pages[at-0x5120]=(upper<<8)|v
 assert len(pages)==12
 return pages,c,w

def setup(b,var=3,tier=0,area=1):
 q=seed(b,0);run(q,'X5ColdInit');q.put(CrossoverMenuIndex=0,MarioVariant=var,
   VRAM_Buffer1_Offset=0,PlayerStatus=tier,PlayerSize=int(tier==0))
 run(q,'MenuResolveCharacter');run(q,'GetAreaType',a=area<<5)
 run(q,'QueueSelection');return q

def signature(q,c,w,skip=()):
 live=[]
 for g in q.b['segs'].values():
  if g.get('name')in['"SHORTRAM"','"SMCCODE"']:
   live.extend(i for i in range(int(g['start'],0),int(g['start'],0)+int(g['size'],0))if i not in skip)
 return registers(c),app(q,skip),q.m.banks,bytes(q.m[z]for z in live),[(i,v)for i,v in cleanwrites(q,w)if i not in skip]

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();assert not a.output.exists()
 paths=[R/'build/roster-shared-celeste-small-chr-v1.nes',R/'build/kamikaze-mario-host-v2/candidate.nes']
 old,b=[scoped_load(p)for p in paths]
 fs=[Path(__file__),R/'tools/audit/sunny_integrated_controls_v1.py',R/'tools/audit/check_tmnt_render_oa.py',R/'tools/audit/link_pit_rygar_sophia_audit_cpu.py',R/'tools/audit/verify_native_relocation.py',R/'src/kamikaze_mario.s',R/'tools/prepare_kamikaze_mario_host_v1.py',R/'tools/prepare_kamikaze_mario_art_v1.py',R/'build/kamikaze-mario-art-v1/source-art.json']+[p.with_suffix(e)for p in paths for e in['.nes','.dbg','.lbl']]+list((R/'build/kamikaze-mario-host-v2/overlay/src').glob('*'))
 proof=dict(passed=False,source_CPU_only=True,native_run=False,bindings={str(p.resolve()):sha(p)for p in fs},checks={});ck=proof['checks']
 try:
  changed={i:sum(x!=y for x,y in zip(old['raw'][16+i*8192:16+(i+1)*8192],b['raw'][16+i*8192:16+(i+1)*8192]))for i in range(128)};changed={i:v for i,v in changed.items()if v}
  assert set(changed)=={62,66,81,124},changed
  moved=[]
  for n,z in old['syms'].items():
   if n=='_FARCALL_COUNT':continue
   assert n in b['syms'],n
   if address(old,n)!=address(b,n):moved.append(n)
  assert not moved,moved[:20]
  for n,bank,pc in [('KmNextVariant',124,0xadce),('KmQueueName',81,0xbf60),('KmNmiSlot0',62,0xa9c0)]:
   assert address(b,n)==pc and (location(b,n)-16)//8192==bank
  cb=1048592
  assert b['raw'][cb:cb+696*1024]==old['raw'][cb:cb+696*1024]
  assert b['raw'][cb+700*1024:]==old['raw'][cb+700*1024:]
  assert b['raw'][cb+696*1024:cb+700*1024]==(R/'chr/characters/kamikaze-mario.chr').read_bytes()
  ck['layout']=dict(passed=True,changed_PRG_bytes_by_bank=changed,all_old_PC_RAM_exact=True,new_CHR_pages=[696,697,698,699],no_physical4_use=True)
  # Decode every compiled native Mario descriptor, rather than trusting a
  # source comment about the 60 used tiles in each page.
  start=address(b,'METASPRITE_BIG_MARIO_STANDING');count=address(b,'TOTAL_MARIO_METASPRITES');rows=[]
  for i,face in itertools.product(range(start,start+count),['Left','Right']):
   bank=b['raw'][location(b,'PlayerBankTable')+i];assert 16<=bank<=19,bank
   ptr=b['raw'][location(b,'MetaspriteTable'+face+'Lo')+i]+256*b['raw'][location(b,'MetaspriteTable'+face+'Hi')+i]
   sg=b['segs'][b['syms']['MetaspriteTable'+face+'Lo']['seg']];off=int(sg['ooffs'],0)+ptr-int(sg['start'],0);length=b['raw'][off];assert length%4==0 and length<=16
   for j in range(off+1,off+length+1,4):
    tile=b['raw'][j];assert tile&1==0 and tile<60,(i,face,tile)
   rows.append([i,face,bank,length])
  ck['compiled_native_pose_closure']=dict(passed=True,records=len(rows),max_pair_tile=59,all_window0=True,all_four_source_pages=True)
  # Actual menu cycle -> resolver -> complete QueueSelection publishes the
  # tag only after its usual foreign-owner clear; leave each alternate too.
  q=setup(b,0);cycle=[]
  for want in[1,3,4,0,1,3]:
   q.put(CrossoverMenuPressed=32,CrossoverMenuIndex=0,VRAM_Buffer1_Offset=0)
   run(q,'NrMenuToggle');run(q,'MenuResolveCharacter');run(q,'QueueSelection')
   got=q.get('MarioVariant');assert got==want,(got,want)
   assert q.get('SelectedCharacter')==(8 if want==1 else 0)
   assert (q.get('X5ChrMode')==0x84)==(want==3),(want,q.get('X5ChrMode'))
   cycle.append([got,q.get('SelectedCharacter'),q.get('X5ChrMode')])
  q.put(CrossoverMenuIndex=1,VRAM_Buffer1_Offset=0);run(q,'MenuResolveCharacter');run(q,'QueueSelection');assert q.get('X5ChrMode')!=0x84
  ck['real_menu_selection_chain']=dict(passed=True,cycle=cycle,foreign_exit_clears_tag=True)
  # Every valid old direct mode and every six-flag combination retains all
  # old output, including the ordered mapper writes and page1 code state.
  costs=[];n=0
  for mode,flags,page in itertools.product(range(0x80,0x84),[p for p in range(256)if p&0x30==0x30],[0,16,19,255]):
   outs=[]
   for bundle in[old,b]:
    q=seed(bundle,0);run(q,'X5ColdInit');q.put(X5WideChrActive=1)
    for i in range(12):q.set('X5ChrMode',mode,i);q.set('CurrentCHRBank',(page+17*i)&255,i)
    c,w,_=run(q,'X5PublishChr',a=87,x=177,y=91,p=flags);outs.append((signature(q,c,w),c.processorCycles))
   assert outs[0][0]==outs[1][0],('old direct publisher',mode,flags,page);costs.append(outs[1][1]-outs[0][1]);n+=1
  ck['old_publisher_full_ABI']=dict(passed=True,cases=n,all_six_flags_AXY_SP_RAM_banks_fiveSMC_ordered_writes=True,CPU_delta=[min(costs),max(costs)])
  for area,page,flags in itertools.product(range(4),range(16,20),[0x30,0x31,0x70,0x71,0xf3]):
   q=setup(b,3,area=area);q.set('CurrentCHRBank',page);before=[(q.get('CurrentCHRBank',i),q.get('X5ChrMode',i))for i in range(12)];pages,c,w=pub(q,flags)
   normal=setup(b,0,area=area);normal.set('CurrentCHRBank',page);np,_,_=pub(normal)
   assert pages[0]==696+page-16 and all(pages[i]==np[i]for i in range(1,12))
   assert before==[(q.get('CurrentCHRBank',i),q.get('X5ChrMode',i))for i in range(12)]
  ck['new_publisher']=dict(passed=True,cases=80,window0_only=True,no_live_identity_read=True)
  # Compare a real complete Main against ordinary Mario: only identity tag,
  # reload bookkeeping and menu text differ before entry, then no movement,
  # hitbox, tile, enemy, OAM or application-state differences are permitted.
  costs=[];n=0
  for mode,area,tier,keys in itertools.product([0,1],range(4),range(3),[0,1,129,65,4]):
   pair=[]
   for var in[0,3]:
    q=setup(b,var,tier,area);q.put(VRAM_Buffer1_Offset=0,VRAM_Buffer2_Offset=0,CrossoverBehaviorVersion=mode,GameTimerDisplay=4,PlayerEntranceCtrl=2,SavedJoypadBits=keys,Left_Right_Buttons=keys&3,A_B_Buttons=keys&192)
    # Menu text is a preceding-screen payload, not a Main-owned state.
    for k in range(84):q.m[address(b,'VRAM_Buffer1')+k]=0
    c,w,_=run(q,'GameLoop',p=0x71)
    skip=[address(b,'MarioVariant'),address(b,'X5ChrMode'),address(b,'X5WideChrActive'),address(b,'ReloadCHRBank')]
    pair.append((signature(q,c,w,skip),c.processorCycles))
   assert pair[0][0]==pair[1][0],('skin native Main',mode,area,tier,keys);costs.append(pair[1][1]-pair[0][1]);n+=1
  ck['skin_complete_Main']=dict(passed=True,calls=n,all_state_OAM_physics_hitboxes_banks_fiveSMC_writes_exact=True,explicit_tag_fields_only=True,CPU_delta=[min(costs),max(costs)],typed_empty_map=True)
  # IRQ and lag NMI preserve each new foreground helper's live return stack,
  # all six flags, application RAM and five runtime mapper operands.
  counts={}
  for kind,name,var in itertools.product(['IRQ','NMI'],['NrMenuToggle','QueueSelection'],[0,1,3,4]):
   q=setup(b,var);q.put(CrossoverMenuIndex=0,CrossoverMenuPressed=32,VRAM_Buffer1_Offset=0,NmiDisable=255)
   original=NesMPU.step;seen=set()
   def step(c):
    bank=q.m.banks[(c.pc-0x8000)//8192]if c.pc>=0x8000 else -1
    if ((bank==81 and 0xbf60<=c.pc<address(b,'KmMenuEnd'))or(bank==124 and 0xadce<=c.pc<0xade7))and c.pc not in seen and not c.p&4:
     seen.add(c.pc)
     # Actual lag NMI increments its counter and, for raw0, performs the
     # ordinary BankSwitchCHR that consumes ReloadCHRBank. Check those two
     # effects explicitly; all other100..17A bytes remain compared.
     volatile={address(b,n)for n in['NmiSkipped','ReloadCHRBank']}
     skipped,reload=q.get('NmiSkipped'),q.get('ReloadCHRBank')
     def snap():return(c.a,c.x,c.y,c.p&0xcf,c.sp,c.pc,tuple(q.m.banks),bytes(q.m[0x101+c.sp:0x200]),app(q),bytes(q.m[i]for i in range(0x100,0x17b)if i not in volatile))
     before=snap()
     if kind=='IRQ':q.m[0x5204]=128;c.irq()
     else:c.nmi()
     for _ in range(60000):
      original(c)
      if c.pc==before[5]and c.sp==before[4]:break
     else:raise AssertionError('ISR timeout')
     assert q.get('NmiSkipped')==((skipped+1)&255 if kind=='NMI'else skipped)
     assert q.get('ReloadCHRBank')==(0 if kind=='NMI'and q.get('SelectedCharacter')==0 else reload)
     after=snap()
     assert after==before,(kind,name,var,hex(c.pc),[(i,list(zip(x,z))if not isinstance(x,bytes)else[(j,a,b)for j,(a,b)in enumerate(zip(x,z))if a!=b])for i,(x,z)in enumerate(zip(before,after))if x!=z])
    original(c)
   NesMPU.step=step
   try:run(q,name,p=0x30)
   finally:NesMPU.step=original
   counts[kind+' '+name+' '+str(var)]=len(seen)
  ck['foreground_interrupts']=dict(passed=True,boundaries=counts,full_live_stack_and_RAM=True)
  assert all(sha(p)==h for p,h in proof['bindings'].items());proof['passed']=True
 except Exception as e:proof.update(failure=repr(e),traceback=traceback.format_exc())
 a.output.write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(dict(passed=proof['passed'],failure=proof.get('failure'),checks=list(ck))));assert proof['passed']

if __name__=='__main__':main()
