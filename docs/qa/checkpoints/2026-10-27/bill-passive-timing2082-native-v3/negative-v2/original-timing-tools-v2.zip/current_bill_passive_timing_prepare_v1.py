"""Prepare one small saved-input Bill timing prefix. Never launches Mesen."""
from pathlib import Path
import argparse
import contextlib
import io
import json
import re
import sys

import current_roster_compact_11_v1 as route

ROOT = route.ROOT
ROM_SHA = '2082c19a7364920f828e97f70040d37f1f7059bde1ea136b5c2c4532324abf36'
OBSERVER = Path(__file__).with_name('current_bill_passive_timing_v1.lua')


def scoped_symbols(path):
    scopes, symbols = {}, []
    for line in path.read_text().splitlines():
        if not line.startswith(('scope\t', 'sym\t')):
            continue
        z = dict(q.split('=', 1) for q in line.split('\t', 1)[1].split(',') if '=' in q)
        if line.startswith('scope\t'):
            scopes[z['id']] = z
        elif 'val' in z:
            symbols.append(z)
    answer = {}
    for z in symbols:
        names, key = [], z.get('scope')
        while key in scopes:
            q = scopes[key]
            name = q.get('name', '""').strip('"')
            if name:
                names.append(name)
            key = q.get('parent')
        answer[tuple(reversed(names)) + (z['name'].strip('"'),)] = z
    return answer


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--output', type=Path, required=True)
    a = ap.parse_args()
    out = a.output.resolve()
    baseline = ROOT / 'build/verification/compact-next-bill-hard-v1'
    rom = ROOT / 'build/proto_palette_ack.nes'
    inputs = baseline / 'inputs.csv'
    assert route.sha(rom) == ROM_SHA
    old = json.loads((baseline / 'ready.json').read_text())
    result = json.loads((baseline / 'result.json').read_text())
    assert result['passed'] and result['ROM_sha256'] == ROM_SHA and result['identity'] == 'bill'
    saved = list(route.csv.DictReader(inputs.open(newline='')))
    assert len(saved) == result['polls']
    assert [int(q['poll']) for q in saved] == list(range(1, len(saved) + 1))
    assert any(int(q['frame']) == 3559 for q in saved)
    options = argparse.Namespace(rom=rom, output=out, expected_sha256=ROM_SHA, identity='bill',
                                mode='hard', frames=3560, policy=Path(old['config']['policy']), replay=inputs)
    with contextlib.redirect_stdout(io.StringIO()):
        route.prepare(options)
    ready = json.loads((out / 'ready.json').read_text())
    cfg = ready['config']
    assert cfg['character'] == 3 and cfg['variant'] == 0 and cfg['mode_value'] == 1
    cfg['capture_bytes'] = 128 * 1024 * 1024
    raw, syms, address, location, hook = route.linked(rom)
    scoped = scoped_symbols(rom.with_suffix('.dbg'))

    def bound(name, public=None, leaf=None):
        if leaf:
            z = scoped[tuple(public.split('::')) + (leaf,)]
            parent = syms[public]
            assert z['seg'] == parent['seg']
            pc = int(z['val'], 0)
            at = location(public) + pc - address(public)
        else:
            public = public or name
            pc, at = address(public), location(public)
        bank = (at - 16) // 8192
        banks = [bank]
        if bank == 127:
            clone = 16 + 125 * 8192 + (pc & 8191)
            size = int(syms[public].get('size', '3'), 0)
            if raw[at:at + size] == raw[clone:clone + size]:
                banks.append(125)
        return dict(name=name, symbol=public + ('::' + leaf if leaf else ''), pc=pc,
                    banks=banks, bytes=list(raw[at:at + 3]))

    names = ['GameLoop', 'PlayerCtrlRoutine', 'PlayerMovementSubs', 'RosterMovement',
             'PlayerBGCollision', 'BillHotProject', 'BillBGEmptyEnvelope', 'RosterWeapons',
             'RemainingWeapons', 'GuestPrepareEnemies', 'RemainingDraw', 'RosterDrawShots',
             'DrawAllMetasprites', 'MetaspriteRenderLoop', 'AudioUpdate']
    functions = [bound(n) for n in names]
    functions += [bound('BulletBlocks', 'MegaManWeapons', 'Blocks'),
                  bound('BulletEnemies', 'MegaManWeapons', 'Enemies')]
    assert len({(q['pc'], tuple(q['banks'])) for q in functions}) == len(functions)
    targets = {q['pc'] for q in functions}
    returns = {}
    # Raw candidates are NOT a claim that data bytes are executed code.
    # At actual entry, the observer verifies the stacked return, mapped
    # physical owner, literal JSR bytes and final SP at the real return.
    for bank in range(128):
        block = raw[16 + bank * 8192:16 + (bank + 1) * 8192]
        for i in range(8190):
            if block[i] != 0x20 or (block[i + 1] | block[i + 2] << 8) not in targets:
                continue
            for base in (0x8000, 0xa000, 0xc000, 0xe000):
                ret = (base + i + 3) & 65535
                if ret >= 0x8000:
                    returns.setdefault(str(ret), []).append(dict(bank=bank, bytes=list(block[i:i + 3])))
    # This measured entry also has one genuine tail caller: the head-probe
    # JSR calls a fixed-bank selector which JMPs into BillBGEmptyEnvelope.
    # Keep its real JSR owner, rather than aliasing the selector to that entry.
    head = bound('PlayerHeadProbe')
    selector = bound('BillBGHeadConsumer')
    envelope = bound('BillBGEmptyEnvelope')
    legacy = bound('BillHeadConsumer')
    assert head['pc'] == 0x9bc2 and head['banks'] == [126]
    assert selector['pc'] == 0xf113 and selector['banks'][0] == 127
    assert envelope['pc'] == 0x94b0 and envelope['banks'] == [126]
    word = lambda v: [v & 255, v >> 8]
    assert head['bytes'] == [0x20] + word(selector['pc'])
    selector_bytes = [0x08, 0x48, 0xad] + word(address('SelectedCharacter')) + [
        0xc9, cfg['character'], 0xf0, 5, 0x68, 0x28, 0x4c] + word(legacy['pc']) + [
        0x68, 0x28, 0x4c] + word(envelope['pc'])
    assert len(selector_bytes) == int(syms['BillBGHeadConsumer']['size'], 0) == 19
    for bank in selector['banks']:
        at = 16 + bank * 8192 + (selector['pc'] & 8191)
        assert list(raw[at:at + 19]) == selector_bytes
    ret = head['pc'] + 3
    assert str(ret) not in returns  # Preserve the exact v1 counterexample.
    owner = dict(bank=head['banks'][0], bytes=head['bytes'])
    returns[str(ret)] = [owner]
    accepts = lambda bank, code: any(q['bank'] == bank and q['bytes'] == code
                                    for q in returns[str(ret)])
    assert accepts(126, head['bytes'])
    assert not accepts(127, head['bytes'])
    assert not accepts(126, [0x4c] + word(selector['pc']))
    assert not accepts(126, [0x20] + word(envelope['pc']))
    tail_return = dict(return_pc=ret, call=head, selector=selector,
        selector_bytes=selector_bytes, measured_tail_entry=envelope,
        legacy_tail_entry=legacy,
        source_path='JSR selector; PHP/PHA; LDA SelectedCharacter/CMP3/BEQ owned; PLA/PLP; JMP measured entry. No extra return address is pushed.',
        metadata_controls=dict(original_missing_return=True, exact_owner_accepts=True,
            wrong_bank_rejected=True, JMP_in_place_of_JSR_rejected=True,
            wrong_JSR_target_rejected=True),
        scope='Compiled control-flow and caller-metadata controls only; not a new native timing result.')
    assert 0 < len(returns) < 2048
    smc_record = syms['FarcallJmpTarget_SMC']
    segments = {}
    for line in rom.with_suffix('.dbg').read_text().splitlines():
        if line.startswith('seg\t'):
            z = dict(q.split('=', 1) for q in line[4:].strip().split(',') if '=' in q)
            segments[z['id']] = z
    smc = segments[smc_record['seg']]
    start, size = int(smc['start'], 0), int(smc['size'], 0)
    assert smc['name'] == '"SMCCODE"' and 0x100 <= start < start + size <= 0x200
    interrupts = {}
    for key, proc in [('NMI', 'NonMaskableInterrupt'), ('IRQ', 'IrqScrollSplit')]:
        interrupts[key] = bound(proc)
        h = hook(proc, tail=True)
        interrupts[key + '_return'] = dict(name=proc + ' preRTI', pc=h['pc'],
                                         banks=interrupts[key]['banks'], bytes=[0x40])
        assert h['bytes'][0] == 0x40
        for bank in interrupts[key]['banks']:
            off = 16 + bank * 8192 + (h['pc'] & 8191)
            assert raw[off] == 0x40
    ram_names = set(re.findall(r"\br\(['\"]([^'\"]+)['\"]", OBSERVER.read_text()))
    assert not (ram_names - syms.keys())
    profile = dict(output=out.as_posix() + '/', ROM_sha256=ROM_SHA, first_frame=3500, last_frame=3560,
                   row_cap=200, byte_cap=1024 * 1024, functions=functions, returns=returns,
                   smc_start=start, smc_end=start + size - 1, interrupts=interrupts,
                   dma_complete=cfg['hooks']['dma_complete'], ram={n: address(n) for n in sorted(ram_names)})
    text = OBSERVER.read_text()
    assert not re.search(r'emu\.(?:write\w*|setInput|setState|loadSavestate|reset|stop)\s*\(', text)
    assert text.count('emu.addMemoryCallback(') == 6 and text.count('emu.addEventCallback(') == 1
    # Exact original runner around one configuration/observer insertion.
    alias = 'for name,value in pairs(ROSTER_CONFIG.extra_ram)do assert(L[name]==nil or L[name]==value,"RAM alias conflict: "..name);L[name]=value end\n'
    original = 'ROSTER_CONFIG=' + route.lua(cfg) + '\n' + alias + 'dofile(' + route.lua(route.SCRIPT.as_posix()) + ')\n'
    insertion = 'BILL_PASSIVE_TIMING=' + route.lua(profile) + '\n' + 'dofile(' + route.lua(OBSERVER.as_posix()) + ')\n'
    generated = 'ROSTER_CONFIG=' + route.lua(cfg) + '\n' + alias + insertion + 'dofile(' + route.lua(route.SCRIPT.as_posix()) + ')\n'
    assert generated.replace(insertion, '', 1) == original
    (out / 'run.lua').write_text(generated, encoding='utf-8')
    (out / 'profile-config.json').write_text(json.dumps(profile, indent=2) + '\n')
    (out / 'command.json').write_text(json.dumps(ready['command'], indent=2) + '\n')
    dependencies = {Path(k) for k in ready['bindings']}
    dependencies.update({OBSERVER, Path(__file__).resolve(), out / 'profile-config.json', out / 'command.json',
                         baseline / 'ready.json', baseline / 'result.json',
                         baseline / 'trace.csv', baseline / 'events.jsonl',
                         Path('C:/Mesen2/Mesen.exe'), Path('C:/Mesen2/MesenCore.dll')})
    ready['bindings'] = {str(f): route.sha(f) for f in sorted(dependencies)}
    ready['passive_timing'] = dict(functions=len(functions), startup_static_return_PCs=len(returns),
        warmup_first_frame=3499, detailed_window=[3500, 3560], CSV_max_rows=200, CSV_max_bytes=1048576,
        expected_CSV_rows=62, no_runtime_callback_registration=True, no_state_or_input_writes=True,
        spans='Completed at real callerPC/SP/physical bank. Inclusive minus ISR; exclusive additionally minus same-context childCPU. Completion buckets are not physical-frame CPU integrals. Open spans atcutoff censored.',
        expected_native_terminal='Original unmodified harness FALSE/exit1: finite frame bound at3560. Any earlier or other guard failure remains a failure, never normalized.',
        exact_saved_inputs=str(inputs), identity='Bill Hard variant0',
        capture='One128MiB NESPPU01 container,3568 record cap (<4000), zero native PNG/per-frame files.',
        ordinary_game_or_driver_changes=False, original_harness_sha256=route.sha(route.SCRIPT),
        host_runner_reverse_removes_only_observer_insertion=True,
        source_scope='Metadata derived only from immutable build/proto_palette_ack.nes/.dbg/.lbl; no canonical source dependencies.',
        historical_scope='Original BillHardv1 full6076-frame clear remains separate; this prefix is diagnostic, not a new clear or60fps claim.')
    ready['passive_timing']['source_proven_tail_return'] = tail_return
    ready['max_total_frames'] = 3560
    ready['container_cap_bytes'] = cfg['capture_bytes']
    (out / 'ready.json').write_text(json.dumps(ready, indent=2) + '\n')
    (out / 'command.json').write_text(json.dumps(ready['command'], indent=2) + '\n')
    print(json.dumps(dict(prepared=True, native_run=False, ready=str(out / 'ready.json'),
                         ready_sha256=route.sha(out / 'ready.json'), bindings=len(dependencies),
                         functions=len(functions), return_PCs=len(returns), command=ready['command']), indent=2))


if __name__ == '__main__':
    main()
