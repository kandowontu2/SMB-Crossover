"""Actual public Hu endpoints and true-vector seams for the BT proposal."""
from pathlib import Path
import hashlib,itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import battletoads_current_loader_controls_v1 as L
H=L.H;V=L.V
from check_tmnt_render_oa import address,location
P=R/'build/battletoads-current-host-v4/joint'
O=R/'build/battletoads-transport-proposal-v2';J=O/'joint'
FLAGS=[0x30|sum(bit for i,bit in enumerate([1,2,4,8,64,128])if n>>i&1)for n in range(64)]
ROWS=['Movement','Graphics','Draw','Portrait','Weapons','Injury','InjuryStatus','DeathStart','Death','Visible','Head','Body','Adder','Box','Side','Fresh','FullBox','MenuPortrait','MenuName','Reset','Prepare','Rise','Private','Mature','Pickup','FullPower','Colors','BounceOnly','HeadWithinOnly','Ui','Status','Bounce','WorldPalette','Powerup','WeaponTail','Vine']
sha=L.sha
def reset(m,raw,rd=0,alt=0):
    b=m.bundle
    m[0x5115]=0xfe;m[0x5116]=0xd8
    H.put(m,CurrentBank=0xfe,CurrentBankC=0xd8,SelectedCharacter=raw,RdVariant=rd,FmAlts=alt,NmiDisable=255,GamePauseStatus=0)
    m.writes.clear();m.ram_writes.clear()
def endpoint(m,slot,p,hook=None,forced_index=None):
    name='Hu'+ROWS[slot];c=H.start(m,name,a=0x83,x=0x5a,y=0xc7,p=p,sp=224)
    hu=address(m.bundle,'HuEntryBase');smc=address(m.bundle,'FarcallJmpTarget_SMC')
    seen=False;low=c.sp
    for step in range(2500):
        if hook:hook(m,c,step)
        low=min(low,c.sp)
        if forced_index is not None and c.pc==address(m.bundle,'HuCommon'):
            c.y=forced_index;forced_index=None
        if c.pc==smc:
            dest=m[smc+1]+256*m[smc+2]
            if seen and not(m.rawtags[1]==207 and hu<=dest<hu+36*16):
                return dict(target=dest,bank=m.rawtags[1],AXYP_SP=[c.a,c.x,c.y,c.p,c.sp],CPU=c.processorCycles,minimum_SP=low),c
            seen=True
        assert m[c.pc]!=0,('actual endpoint BRK',name,hex(c.pc),m.rawtags)
        c.step()
    raise AssertionError(('actual endpoint timeout',name,hex(c.pc),m.rawtags))
def same(a,z,ma,mz,case):
    assert all(a[k]==z[k]for k in['target','bank','AXYP_SP','minimum_SP']),('actual endpoint ABI',case,a,z)
    assert ma.rawtags==mz.rawtags and ma.chr_latches==mz.chr_latches and ma.ram==mz.ram,('mapper/cache/CHR',case)
    assert bytes(ma[:256])==bytes(mz[:256]) and bytes(ma[512:0x8000])==bytes(mz[512:0x8000]),('application and all33SMC',case)
    assert bytes(ma[0x101+a['minimum_SP']:512])==bytes(mz[0x101+z['minimum_SP']:512]),('live page1',case)
    app=lambda m:[v for v in m.writes if not 0x100<=v[0]<0x200]
    assert app(ma)==app(mz),('actual ordered application/SMC/mapper writes',case,app(ma),app(mz))
    return z['CPU']-a['CPU']
def main():
    out=O/'endpoint-controls.json';assert not out.exists();q=dict(passed=False,native=False)
    try:
        bundles=[H.C.qualified(x/'candidate.nes')for x in[P,J]]
        pair=[L.make(b)for b in bundles];deltas=[];cases=0
        # Every one of 144 true old table endpoints receives all64 input flags.
        for raw,rd in[(0,0),(28,0),(24,0),(2,1)]:
            for slot,p in itertools.product(range(36),FLAGS):
                results=[]
                for m in pair:reset(m,raw,rd);results.append(endpoint(m,slot,p)[0])
                deltas.append(same(*results,*pair,[raw,rd,slot,p]));cases+=1
        q['all144_members_full64flags_pairs']=cases
        # All256 raw owners, including unsupported values, preserve their old
        # behavior except the explicitly new33 path. Alternate Quick remains.
        rawcases=0
        for raw,slot,p in itertools.product([x for x in range(256)if x!=33],range(36),[FLAGS[0],FLAGS[-1]]):
            for rd,alt in([(0,0),(1,0),(255,0)]if raw==2 else[(0,0),(0,32)]if raw==9 else[(0,0)]):
                results=[]
                for m in pair:reset(m,raw,rd,alt);results.append(endpoint(m,slot,p)[0])
                deltas.append(same(*results,*pair,[raw,rd,alt,slot,p]));rawcases+=1
        q['all_raw_foreign_and_Quick_alt_pairs']=rawcases
        # True public prologues restore original liveY/P/sourceA before Bt's
        # own ROM row. No cache preloading or unavailable worker interception.
        m=pair[1];bt=[]
        for slot,p in itertools.product(range(36),FLAGS):
            reset(m,33);z,c=endpoint(m,slot,p)
            assert z['target']==address(m.bundle,'BtServiceVeneers')+slot*3 and z['bank']==215
            expectp=(p&~0x82)|0x80
            assert z['AXYP_SP'][:4]==[0x83,0x5a,0xc7,expectp],('BT true sourceA/P/Y/X',slot,p,z)
            bt.append([slot,p,z['CPU']])
        invalid=[]
        for index,p in itertools.product([36,37,127,255],FLAGS):
            reset(m,33);z,c=endpoint(m,0,p,forced_index=index)
            assert z['target']==address(m.bundle,'BtServiceUnavailable')and z['bank']==215
            invalid.append([index,p,z['CPU']])
        q.update(passed=True,BT_public_allflags=len(bt),BT_invalid_clamp_allflags=len(invalid),
            foreign_CPU_delta=[min(deltas),max(deltas)],foreign_mapper_trips_and_ordered_writes_exact=True,
            source_AXYP_SP_33SMC_livepage1_maps_cache_CHR_exact=True,
            scope='Actual source entry→true typed endpoint only. New raw33 cache API is still pending gameplay; current62 menu/readiness exact.',BT=bt,invalid=invalid)
    except Exception as e:q.update(error=repr(e),traceback=traceback.format_exc())
    q['bindings']={str(p.resolve()):sha(p)for p in[Path(__file__),Path(L.__file__),O/'proposal.json',P/'candidate.nes',J/'candidate.nes',J/'candidate.dbg']}
    out.write_text(json.dumps(q,indent=2)+'\n');print(json.dumps({k:v for k,v in q.items()if k not in['bindings','BT','invalid','traceback']}));assert q['passed'],q.get('error')
if __name__=='__main__':main()
