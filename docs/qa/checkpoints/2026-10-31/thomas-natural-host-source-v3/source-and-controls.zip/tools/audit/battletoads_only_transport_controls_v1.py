"""Real constant-index Only callers: all owner/flag classifiers and endpoints."""
from pathlib import Path
import itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import battletoads_transport_controls_v1 as T
L=T.L;H=T.H;V=T.V;address=T.address;location=T.location
P=R/'build/battletoads-transport-proposal-v2/joint';O=R/'build/battletoads-only-transport-v2';J=O/'joint'
ONLY=['GmFreshGate','GmFullBoxGate','GmMenuDrawGate','GmMenuNameGate','GmResetGate','GmPrepareGate','GmRiseGate','GmPrivateGate','GmMatureGate','GmPickupGate','GmFullPowerGate','GmColorsGate','GmStompGate','GmHeadWithinGate','GmUiGate','GmStatusGate']
def endpoint(m,name,p,hook=None):
    c=H.start(m,name,a=0x83,x=0x5a,y=0xc7,p=p,sp=224)
    hu=address(m.bundle,'HuEntryBase');smc=address(m.bundle,'FarcallJmpTarget_SMC');seen=False;low=c.sp
    for step in range(2500):
        if hook:hook(m,c,step)
        low=min(low,c.sp)
        if c.pc==smc:
            dest=m[smc+1]+256*m[smc+2]
            if seen and not(m.rawtags[1]==207 and hu<=dest<hu+36*16):
                return dict(target=dest,bank=m.rawtags[1],AXYP_SP=[c.a,c.x,c.y,c.p,c.sp],CPU=c.processorCycles,minimum_SP=low),c
            seen=True
        assert m[c.pc]!=0,('actual Only BRK',name,hex(c.pc),m.rawtags)
        c.step()
    raise AssertionError(('actual Only bound',name,hex(c.pc),m.rawtags))
def same(a,z,ma,mz,case):
    assert all(a[k]==z[k]for k in['target','bank','AXYP_SP','minimum_SP']),('foreign ABI',case,a,z)
    assert ma.rawtags==mz.rawtags and ma.ram==mz.ram and ma.chr_latches==mz.chr_latches
    # Observer reads underlying CPU storage without synthesizing MMIO reads.
    raw=lambda m,lo,hi:bytes(list.__getitem__(m,slice(lo,hi)))
    assert raw(ma,0,256)==raw(mz,0,256)and raw(ma,512,0x8000)==raw(mz,512,0x8000),('actual RAM and33SMC',case)
    live=min(a['minimum_SP'],z['minimum_SP'])
    assert raw(ma,0x101+live,512)==raw(mz,0x101+live,512),('live page1',case)
    app=lambda m:[x for x in m.writes if not 0x100<=x[0]<0x200]
    assert app(ma)==app(mz),('ordered application/SMC/mapper writes',case)
    return z['CPU']-a['CPU']
def main():
    out=O/'endpoint-controls.json';assert not out.exists();q=dict(passed=False,native=False)
    try:
        bundles=[H.C.qualified(p/'candidate.nes')for p in[P,J]];pair=[L.make(b)for b in bundles]
        deltas=[];count=0;bt=0
        for raw,name in itertools.product(range(256),ONLY):
            flags=T.FLAGS if name in['GmFreshGate','GmColorsGate']else[T.FLAGS[0],T.FLAGS[-1]]
            for p in flags:
                for rd,alt in([(0,0),(1,0),(255,0)]if raw==2 else[(0,0),(0,32)]if raw==9 else[(0,0)]):
                    z=[]
                    for m in pair:T.reset(m,raw,rd,alt);z.append(endpoint(m,name,p)[0])
                    if raw!=33:deltas.append(same(*z,*pair,[raw,name,p,rd,alt]));count+=1
                    else:
                        index=ONLY.index(name)+15
                        assert(z[1]['target'],z[1]['bank'])==(address(pair[1].bundle,'BtServiceVeneers')+3*index,215)
                        assert z[1]['AXYP_SP'][:4]==[0x83,0x5a,0xc7,(p&~0x82)|0x80]
                        bt+=1
        # Actual branch operands all rebind to their one true assembled local
        # symbol; no imported/numeric alias to moved GmOnlyRare exists.
        b=bundles[1];src=(J/'src/new_roster_dispatch.s').read_text()
        assert '.export GmOnlyRare'not in src
        high=address(b,'GmOnlyHigh');rare=address(b,'GmOnlyRare')
        assert rare==high+4
        q.update(passed=True,foreign_constantY_endpoint_pairs=count,raw33_real_Only_pairs=bt,
            all256_raw_full64flags_for_both_shared_classifiers=True,all16_real_Only_callers=True,
            privateY_scope='Actual constant service0..15 callers; no arbitraryY ABI promise',
            foreign_CPU_delta=[min(deltas),max(deltas)],all_AXYP_SP_33SMC_maps_livepage1_orderedwrites_equal=True,
            shared_menu_and_62_readiness_unchanged=True)
    except Exception as e:q.update(error=repr(e),traceback=traceback.format_exc())
    q['bindings']={str(p.resolve()):T.sha(p)for p in[Path(__file__),Path(T.__file__),O/'proposal.json',P/'candidate.nes',J/'candidate.nes',J/'candidate.dbg',J/'src/new_roster_dispatch.s']}
    out.write_text(json.dumps(q,indent=2)+'\n');print(json.dumps({k:v for k,v in q.items()if k not in['bindings','traceback']}));assert q['passed'],q.get('error')
if __name__=='__main__':main()
