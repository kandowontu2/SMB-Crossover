"""Bounded immutable8961 own BT/menu protocol rebind; no cold/admission claim."""
from pathlib import Path
import argparse,json,sys
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import battletoads_current_loader_controls_v1 as L
O=R/'build/bt-current-cf-component-controls-v1';J=R/'build/bt-current-cf-component-v2/joint'
def main():
 a=argparse.ArgumentParser();a.add_argument('--check',choices=['menu','protocol','smoke'],required=True);a=a.parse_args()
 O.mkdir(exist_ok=True);stage=json.loads((J.parent/'source-stage.json').read_text())
 assert stage['candidate']==L.sha(J/'candidate.nes')=='8961be0a5c51ca091efdddea07c122a0c7a8204e1eb071b2cd001bba4a7c9f8c'
 for n,v in stage['bindings'].items():assert L.sha(n)==v,n
 if a.check=='menu':
  p=R/'tools/audit/battletoads_menu_lease_controls_v3.py';text=p.read_text()
  text=text.replace("P=R/'build/battletoads-cold-acquire-v4/joint';J=R/'build/battletoads-menu-lease-v7/joint';O=J.parent",f"P=R/'build/cf-preload-name-source-v1/joint';J=R/{J.relative_to(R).as_posix()!r};O=R/{O.relative_to(R).as_posix()!r}")
  text=text.replace("==64","==66").replace('previous64ready_preserved','previous66ready_preserved')
  text=text.replace("O/'source-stage.json'","J.parent/'source-stage.json'")
  ns={'__file__':str(p),'__name__':'rebound_bt_current_menu'};exec(compile(text,str(p),'exec'),ns);ns['main']();out=O/'menu-controls.json'
 elif a.check=='protocol':
  import battletoads_menu_protocol_controls_v2 as M
  M.O=O;M.J=J
  # Existing report binds source-stage beside O; point only its report input at the real immutable source stage.
  p=Path(M.__file__);text=p.read_text().replace("O=R/'build/battletoads-menu-lease-v7';J=O/'joint'",f"O=R/{O.relative_to(R).as_posix()!r};J=R/{J.relative_to(R).as_posix()!r}").replace("O/'source-stage.json'","J.parent/'source-stage.json'")
  ns={'__file__':str(p),'__name__':'rebound_bt_current_protocol'};exec(compile(text,str(p),'exec'),ns);ns['main']();out=O/'protocol-controls.json'
 else:
  import battletoads_native_adapter_controls_v2 as M
  T=M.T;b=L.H.C.qualified(J/'candidate.nes')
  out=O/'smoke-controls.json';assert not out.exists()
  results={'source_health':T.health(b),'source_render':M.render(b)}
  q=dict(passed=True,native=False,admitted=False,candidate=stage['candidate'],checks=results,scope='Only loaded own source health and renderer/pixels; no natural menu/cold/Main claim.',bindings={str(n.resolve()):L.sha(n)for n in[Path(M.__file__),Path(T.__file__)]});out.write_text(json.dumps(q,indent=2)+'\n')
 q=json.loads(out.read_text());q['bindings'].update({str(n.resolve()):L.sha(n)for n in[Path(__file__),J.parent/'source-stage.json',J/'candidate.nes',J/'candidate.dbg']});q['scope_current']='66-ready parent preserved; BT/CF remain pending. Cold17/26 transport not adopted.';out.write_text(json.dumps(q,indent=2)+'\n')
 print(json.dumps(dict(check=a.check,passed=q['passed'],output=str(out),sha256=L.sha(out))))
if __name__=='__main__':main()
