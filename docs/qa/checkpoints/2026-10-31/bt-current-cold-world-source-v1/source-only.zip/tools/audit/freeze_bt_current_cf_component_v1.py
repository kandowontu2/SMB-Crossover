"""Freeze genuine BT own/menu rebase; shared cold transport stays unadopted."""
from pathlib import Path
import difflib,hashlib,json,re,shutil,zipfile
R=Path(__file__).resolve().parents[2];P=R/'build/cf-preload-name-source-v1';O=R/'build/bt-current-cf-component-v2';J=O/'joint';D=R/'docs/qa/checkpoints/2026-10-31/bt-current-cf-component-source-v1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
save=lambda p,q:Path(p).write_text(json.dumps(q,indent=2)+'\n',encoding='utf-8')

def main():
 assert not(O/'handoff.json').exists()and not D.exists();files={Path(__file__)}
 roots=[P/'handoff.json',O/'source-stage.json',R/'build/bt-current-cf-component-controls-v1/handoff.json',R/'docs/qa/checkpoints/2026-10-31/battletoads-menu-lifecycle-v2/handoff.json']
 for p in roots:
  q=json.loads(p.read_text());files.add(p)
  for f,h in q['bindings'].items():assert sha(f)==h,('immutable input',f);files.add(Path(f))
 stage=json.loads((O/'source-stage.json').read_text());assert stage['candidate']==sha(J/'candidate.nes')=='8961be0a5c51ca091efdddea07c122a0c7a8204e1eb071b2cd001bba4a7c9f8c'
 for p in J.rglob('*'):
  if p.is_file()and p.suffix.lower()in['.s','.asm','.inc','.cfg','.chr','.rle','.dep','.d','.o','.bin']:files.add(p)
 for line in(J/'candidate.dbg').read_text().splitlines():
  if line.startswith('file\t'):
   p=Path(re.search(r'name="([^"]+)"',line).group(1));p=p if p.is_absolute()else R/p;assert p.is_file();files.add(p)
 files|=set(O.glob('*.json'))|{J/n for n in['candidate.nes','candidate.dbg','candidate.lbl','candidate.map','source-stage.json']}
 tools={Path(__file__),R/'tools/audit/prepare_bt_current_cf_component_v1.py',R/'tools/audit/prepare_bt_current_cf_component_v2.py',R/'tools/audit/check_bt_current_cf_component_v1.py'};files|=tools
 patch=''
 for name in['bt/api.s','bt/core.s','bt/art.s','bt/loader.s','bt/preview.s','bt/stream.s','src/full_roster_menu.s','src/cf_menu_body.inc']:
  patch+=''.join(difflib.unified_diff((P/'joint'/name).read_text().splitlines(True),(J/name).read_text().splitlines(True),fromfile='38a6/'+name,tofile='BT-own/'+name))
 (O/'source.patch').write_text(patch,encoding='utf-8')
 proof=dict(source=True,passed=True,candidate=stage['candidate'],parent=stage['parent'],ready=66,CF_pending=True,BT_pending=True,native=False,installed=False,admitted=False,changed_bytes=2968,own_menu_helper_bytes=[393,400],all_other_images_cookies_and_shared_router_exact=True,root_current68_M3_source_separate=True,
  semantic_receipt=str(R/'build/bt-current-cf-component-controls-v1/handoff.json'),semantic_receipt_sha256=sha(R/'build/bt-current-cf-component-controls-v1/handoff.json'),actual_menu_profiles=83,Select_cases=5120,Start_cases=10240,outer_AXYP_cases=3072,cache3_decline_cases=64,real_vectors=612,original_HP_cases=2048,food_cases=96,source_native_kernel_pixel_cases=96,
  remaining=['Current B020 remains exact211B JSR table; separate223B experiment is NOT adopted','CF retirement before new BT production load must be traced before cold routes are joined','Native world32, cold17/26 overrides and ready native-other preview remain unjoined','CF and BT remain pending; installed68 M3 source and experimental P1 remain separate'])
 save(O/'freeze-proof.json',proof)
 (O/'HANDOFF.txt').write_text('Genuine frozen BTv7 own/menu producer rebased onto38a6. Current66 admission and all CF/BW/Quick/Ar/FF payloads remain exact. Rebuild actual current Main plus six true BT source objects; no old9804 Main/common/CFG copied. BT cache/cookie are actual regenerated source outputs and equal frozen9a7246 cookie/005a7c cache. BtRetire movesAF63 toAF41 and genuine Main is rebound. TableB020/rejectB08C/workerB08E stay exact211B JSR protocol. New helper393/400 retires BT/P1 before masking and retains all conditional Alts/Groups bits. Separate223B JMP experiment, world32 and natural cold acquisition are not adopted. Root installed68 M3 remains a later surgical composition; this source parent is66. No native/install/readiness.\n')
 files|={O/'source.patch',O/'freeze-proof.json',O/'HANDOFF.txt'}
 archive=O/'source-only.zip';members=[];ext={'.s','.asm','.inc','.cfg','.chr','.rle','.dep','.d','.py','.json','.txt','.patch','.md','.lua'}
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
  for p in sorted(files):
   if p.suffix.lower()in ext or p.suffix.lower()=='.bin'and p.stat().st_size<=65536:
    rel=p.relative_to(R).as_posix();z.write(p,rel);members.append(rel)
 files.add(archive);q=dict(source=True,status='FROZEN_PENDING_BT_OWN_MENU_REBASE',candidate=stage['candidate'],parent=stage['parent'],joint=str(J),source_stage=str(J/'source-stage.json'),ready=66,CF_pending=True,BT_pending=True,native=False,installed=False,publication_allowed=False,source_archive_members=len(members),bindings={str(p.resolve()):sha(p)for p in sorted(files)})
 save(O/'handoff.json',q)
 for f,h in q['bindings'].items():assert sha(f)==h,f
 with zipfile.ZipFile(archive)as z:
  assert z.testzip()is None
  for n in z.namelist():assert hashlib.sha256(z.read(n)).hexdigest()==sha(R/n)
 D.mkdir(parents=True)
 for n in['handoff.json','source-only.zip','source.patch','freeze-proof.json','HANDOFF.txt']:shutil.copyfile(O/n,D/n)
 save(D/'receipt.json',dict(source=True,candidate=stage['candidate'],handoff=sha(O/'handoff.json'),verified_bindings=len(files),archive_members=len(members),bindings={str(p.resolve()):sha(p)for p in D.iterdir()}))
 owned=tools|set(D.iterdir())|{D/'owned-files.txt'};(D/'owned-files.txt').write_text('\n'.join(p.relative_to(R).as_posix()for p in sorted(owned))+'\n')
 print(json.dumps(dict(candidate=stage['candidate'],handoff=sha(O/'handoff.json'),bindings=len(files),archive_members=len(members),checkpoint=str(D))))
if __name__=='__main__':main()
