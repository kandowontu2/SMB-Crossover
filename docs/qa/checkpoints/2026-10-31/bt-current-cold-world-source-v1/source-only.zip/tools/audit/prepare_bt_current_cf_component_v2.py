"""Adopt only frozenBT own/menu sources onto38a6; transport/ready pending."""
from pathlib import Path
import difflib,hashlib,json,shutil,subprocess,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
from private_build_outputs_v1 import validate
from prepare_ff_current_component_v2 import qualified
from check_tmnt_render_oa import address,location
from prepare_cv3_dmc_mirror import prepare
P=R/'build/cf-preload-name-source-v1';B=R/'build/battletoads-menu-lease-v7/joint';H=R/'docs/qa/checkpoints/2026-10-31/battletoads-menu-lifecycle-v2/handoff.json'
O=R/'build/bt-current-cf-component-v2';J=O/'joint';M=R/'build/cf-cold-warm-source-v3'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
save=lambda p,q:Path(p).write_text(json.dumps(q,indent=2)+'\n')

def bound(p):
 q=json.loads(Path(p).read_text())
 for f,h in q['bindings'].items():assert sha(f)==h,('immutable input',f)
 return q

def proc(s,n):
 lo=s.index('.proc '+n);hi=s.index('.endproc',lo)+len('.endproc');return lo,hi,s[lo:hi]

def main():
 assert not O.exists();O.mkdir();logs=[]
 try:
  parent=bound(P/'handoff.json');bt=bound(H)
  assert parent['candidate']=='38a6259ca3abacccc10b8adb3b256f94a72f90307d44fb5ed5afe15114c372cd'
  assert sha(H)=='bc5a4a7e1d58e6c0fca96ad6b0cf85e02c388f864a4f13aa71812bbfe9b899ae'
  names=['api.s','core.s','art.s','loader.s','preview.s','stream.s','native-constants.inc','cookie.bin']
  for n in names:assert bt['bindings'].get(str((B/'bt'/n).resolve()))==sha(B/'bt'/n),('actual BTproducer',n)
  shutil.copytree(P/'joint',J)
  for n in names:
   p=J/'bt'/n
   if p.suffix in['.s','.inc']:p.write_text((B/'bt'/n).read_text().replace(str(B),str(J)).replace(B.as_posix(),J.as_posix()))
   else:shutil.copyfile(B/'bt'/n,p)
  (J/'bt/cache.bin').write_bytes(bytes(8192));(J/'bt/stream.bin').write_bytes(bytes(8192)) # source-generated bootstrap, never adopted
  # Actual current main producer; only own toggle/Start/helper are adopted.
  p=J/'src/full_roster_menu.s';s=p.read_text();old=s
  for n in['FmToggle','FmStartFlags']:
   lo,hi,_=proc(s,n);_,_,own=proc((B/'src/full_roster_menu.s').read_text(),n);s=s[:lo]+own+s[hi:]
  assert proc(s,'FmPending')[2]==proc(old,'FmPending')[2],('do not restore oldBowserpending or alter current66 readiness')
  p.write_text(s)
  (J/'src/cf_menu_body.inc').write_bytes((B/'src/cf_menu_body.inc').read_bytes())
  p=J/'private.cfg';p.write_text(p.read_text().replace(str(P/'joint'),str(J)).replace((P/'joint').as_posix(),J.as_posix()))
  def run(n,cmd):
   guard=validate(cmd,O,cwd=R);z=subprocess.run(cmd,cwd=R,capture_output=True,text=True);q=dict(command=cmd,cwd=str(R),output_guard=guard,returncode=z.returncode,stdout=z.stdout,stderr=z.stderr);logs.append(q);save(O/(n+'.json'),q);save(O/'commands.json',logs);assert z.returncode==0,(n,z.stderr)
  # Bind the true consumed8f0a Main producer, not the oldBT9804 recipe.
  oldmain=M/'joint/main.o';assert parent['bindings'].get(str(oldmain.resolve()))==sha(oldmain)
  cmd=json.loads((M/'main-build.json').read_text())['command'][:]
  for i,x in enumerate(cmd):
   if x.startswith(str(M/'joint')):cmd[i]=x.replace(str(M/'joint'),str(J))
  cmd[cmd.index('-o')+1]=str(J/'main.o');cmd[cmd.index('--create-full-dep')+1]=str(J/'main.dep');cmd[-1]=str(J/'entrypoint.s');cmd[1:1]=['-I',str(J),'-I',str(J/'src')];run('main-build',cmd)
  ca=R/'tools/Windows/cc65/bin/ca65.exe'
  def assemble(n):
   src=J/'bt'/(n+'.s');obj=src.with_suffix('.o');run(n+'-build',[str(ca),'--cpu','6502x','-g','-D','MAPPER_MMC5=1','-I',str(J/'bt'),'-I',str(J),'-I',str(R),'--create-full-dep',str(obj.with_suffix('.dep')),'-o',str(obj),str(src)])
  for n in['api','core','art','loader','preview','stream']:assemble(n)
  cmd=json.loads((P/'final-link.json').read_text())['command'][:];rebound={}
  for i,x in enumerate(cmd):
   p=Path(x)
   if p==oldmain:cmd[i]=str(J/'main.o');rebound['main']=str(p)
   if p.suffix=='.o'and p.parent.name=='bt'and p.stem in['api','core','art','loader','preview','stream']:
    assert parent['bindings'].get(str(p.resolve()))==sha(p),p;cmd[i]=str(J/'bt'/p.name);rebound[p.stem]=str(p)
  assert len(rebound)==7,rebound
  for flag in['-C','-Ln','-o','-m']:cmd[cmd.index(flag)+1]=str(J/Path(cmd[cmd.index(flag)+1]).name)
  cmd[cmd.index('--ld-args')+1]='--dbgfile,'+str(J/'candidate.dbg');run('initial-link',cmd)
  cache=(J/'sideoutputs/candidate/00-cache.bin').read_bytes();assert len(cache)==8192 and cache[0x1fe0:0x1ff0]==bytes(16)
  cookie=bytes([167,33,1,117])+hashlib.sha256(cache).digest()[:12]
  assert cookie==(B/'bt/cookie.bin').read_bytes(),('true current imports retain frozen BTsource cache identity',cookie.hex())
  (J/'bt/cache.bin').write_bytes(cache);(J/'bt/stream.bin').write_bytes(cache);(J/'bt/cookie.bin').write_bytes(cookie)
  assemble('loader');assemble('stream');run('final-link',cmd);prepare(R,J/'candidate.nes')
  old,b=map(qualified,[P/'joint/candidate.nes',J/'candidate.nes'])
  for n in['MenuResolveCharacter','QueueSelection','DrawSelectionPreview','FmPending','FmResolve','FmToggle','FmStartFlags','BwScene','BwBtResolve','BwCfSceneLoad','BtServiceVeneers','BtServiceUnavailable','BtRouter','BtCheck','BtLoad','CfOrBtCheck','CfRetire','CfLoadIfCold','BmFresh','BmColors']:
   assert(address(old,n),location(old,n))==(address(b,n),location(b,n)),n
  assert 'FmStartIdentityFlags'not in b['syms']and address(b,'FmCfHelperEnd')-address(b,'FmCfHelperStart')==393
  for n,side in[('bowser.bin','04-bowser.bin'),('ram3.bin','01-ram3.bin'),('code.bin','02-code.bin'),('data.bin','03-data.bin')]:
   f=J/'sideoutputs/candidate'/side;assert sha(f)==sha(P/'joint'/n),n;shutil.copyfile(f,J/n)
  for n in['ff-cookie.bin','cf-stream.bin','cf-cookie.bin']:assert sha(J/n)==sha(P/'joint'/n),n
  for n in['bowser/router.s','bowser/cold.s','bt/router.s','cf-cold-warm.s','src/chip_dale_render.s']:
   assert (J/n).read_bytes()==(P/'joint'/n).read_bytes(),n
  allowed=[(16+93*8192+0xdc0,487),(16+72*8192+0x1011,239),(location(b,'FmCfHelperStart'),400),(location(b,'FmToggle'),278),(location(b,'FmStartFlags'),28),(16+128*8192+915*1024,12*1024)]
  changed=[i for i,(x,y)in enumerate(zip(old['raw'],b['raw']))if x!=y];assert all(any(lo<=i<lo+size for lo,size in allowed)for i in changed)
  assert old['raw'][:16]==b['raw'][:16]
  stage=dict(source=True,status='PENDING_BT_OWN_COMPONENT_MENU_SOURCE_NO_COLD_TRANSPORT',candidate=sha(J/'candidate.nes'),parent=parent['candidate'],BT_frozen_source=sha(H),joint=str(J),ready=66,CF_pending=True,BT_pending=True,native=False,installed=False,admitted=False,menu_used_granted=[393,400],actual_rebuilt_objects=rebound,changed_bytes=len(changed),exact_owned_envelopes=allowed,shared_A67_B020_CF_and_all_other_images_cookies_exact=True,
   pending=['No oldBT9804main/CFG/common copied; root68M3leaf is separate future composition','BT cold17/26 transport redesign proposal is NOT adopted; current B020 stillJSR rows/fullguard','Trace actual retirement before every production BTwrite; exported loaderAPI still requires callerCfRetire','Native world32/query and ready native-other preview routing are not yet joined','No readiness/native/install/P1experimental source'],
   bindings={str(p.resolve()):sha(p)for p in[Path(__file__),R/'tools/audit/prepare_bt_current_cf_component_v1.py',R/'build/bt-current-cf-component-v1/negative.json',P/'handoff.json',H,M/'main-build.json',J/'candidate.nes',J/'candidate.dbg',J/'candidate.lbl',J/'private.cfg',J/'entrypoint.s',J/'src/full_roster_menu.s',J/'src/cf_menu_body.inc',*[J/'bt'/n for n in names],J/'bt/cache.bin',J/'bt/stream.bin',*[J/'bt'/(n+'.o')for n in['api','core','art','loader','preview','stream']],O/'final-link.json']})
  save(O/'source-stage.json',stage);save(J/'source-stage.json',stage);bound(P/'handoff.json');bound(H);print(json.dumps({k:v for k,v in stage.items()if k!='bindings'}))
 except Exception as e:save(O/'negative.json',dict(passed=False,error=repr(e),traceback=traceback.format_exc()));raise
if __name__=='__main__':main()
