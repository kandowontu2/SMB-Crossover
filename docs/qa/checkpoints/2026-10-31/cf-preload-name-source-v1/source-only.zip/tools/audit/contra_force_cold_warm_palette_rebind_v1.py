"""Targeted e82e body/UI producer checks rebound to real joined cold/warm cart."""
from pathlib import Path
import hashlib,itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(R/'tools/audit'))
import contra_force_palette_names_controls_v2 as V
Q,J,C,T,D=V.Q,V.J,V.C,V.T,V.D;P=R/'build/cf-cold-warm-palette-source-v1';O=R/'build/contra-force-cold-warm-palette-rebind-v1'
V.P=Q.P=Q.V.P=J.P=C.P=T.P=D.P=P;T.B=T.qualified(P/'joint/candidate.nes');T.PAYLOAD=(P/'joint/cf-stream.bin').read_bytes();T.COOKIE=(P/'joint/cf-cookie.bin').read_bytes()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 assert not O.exists();O.mkdir();out=dict(passed=False,native=False,natural_cold_owned_by_sibling=True,checks={})
 try:
  for p,h in json.loads((P/'source-stage.json').read_text())['bindings'].items():assert sha(p)==h,p
  assert sha(P/'joint/candidate.nes')=='ef2f11e232ec878c277245c3802bcf8a415415e38507c26feefaef3744c1bee1'
  old=R/'build/contra-force-palette-names-cart-v2/joint'
  for n in ['cf-stream.bin','cf-cookie.bin']:assert (P/'joint'/n).read_bytes()==(old/n).read_bytes()
  bases=[]
  for var in range(4):m=Q.load(var);Q.public(m,15);bases.append(m)
  rows=[]
  for var,area in itertools.product(range(4),range(4)):
   m=V.seed(bases[var]);T.put(m,AreaType=area,BackgroundColorCtrl=0);Q.public(m,26);z=V.consume(m)
   assert list(m.vram[0x3f10:0x3f14])==[V.BG[area],55,18,15];rows.append(dict(variant=var,area=area,**z))
  for var in range(4):
   m=V.seed(bases[var],77);before=V.queue(m);Q.public(m,26);assert V.queue(m)==before and m.ram[2][0x2e2]==1
   T.put(m,VRAM_Buffer1_Offset=0);Q.public(m,29);assert V.queue(m)[:8]==bytes([63,16,4,34,55,18,15,0])and m.ram[2][0x2e2]==0
  out['checks']['actual_original_PPU16_plus_fullqueue_retry4']=rows
  for n,f in [('identities',V.identities),('actual_WriteGameText_late_lives',V.late_lives),('world32',V.world_index)]:out['checks'][n]=f(bases);print('CF joinedP0/UI',n,'PASS',flush=True)
  assert all(x['has_body_packet']for x in out['checks']['actual_WriteGameText_late_lives']['natural_f523_status_ingress_observations'])
  out['passed']=True
 except Exception as e:out.update(error=repr(e),traceback=traceback.format_exc());raise
 finally:
  files=[Path(__file__),Path(V.__file__),P/'source-stage.json',P/'joint/candidate.nes',P/'joint/candidate.dbg',P/'joint/cf-stream.bin',P/'joint/cf-cookie.bin',R/'build/contra-force-palette-names-qualified-v1/handoff.json']
  out['bindings']={str(p.resolve()):sha(p)for p in files};p=O/'controls.json';p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(path=str(p),sha256=sha(p),passed=out['passed'],error=out.get('error'))),flush=True)
if __name__=='__main__':main()
