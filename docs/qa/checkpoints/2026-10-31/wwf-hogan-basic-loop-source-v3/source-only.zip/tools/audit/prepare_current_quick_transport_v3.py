"""Private genuine Quick transport, fixed public entries and owned padding only."""
from pathlib import Path
import difflib,hashlib,json,re,shutil
import build_current_character_composition_v1 as B
R=B.R;P=R/'build/current-character-composition-v2/joint';OLD=P.parent
O=R/'build/current-character-quick-transport-v3';N=O/'joint'

def check_bindings(path):
 d=json.loads(path.read_text())
 for name,value in d['bindings'].items():assert B.sha(name)==value,name

def rewrite(cmd,old):
 return[x.replace(str(old),str(N)).replace(old.as_posix(),N.as_posix())for x in cmd]

def guard(cmd):
 # Validate every declared write before any compiler starts. Imported paths may
 # remain read-only; outputs, dependency files, map/debug and config outputs may not.
 for flag in ['-o','-Ln','-m','--create-full-dep','--dbgfile']:
  if flag in cmd:assert Path(cmd[cmd.index(flag)+1]).resolve().is_relative_to(N.resolve()),(flag,cmd)
 for arg in cmd:
  if arg.startswith('--dbgfile,'):assert Path(arg.split(',',1)[1]).resolve().is_relative_to(N.resolve()),arg
 if '-C'in cmd:
  cfg=Path(cmd[cmd.index('-C')+1]);assert cfg.resolve().is_relative_to(N.resolve()),cfg
  for value in re.findall(r'file\s*=\s*"([^"]+)"',cfg.read_text()):
   if value and value!='%O':assert Path(value).resolve().is_relative_to(N.resolve()),value

def patch_source():
 p=N/'union.s';s=p.read_text();s='.import QwService,ArenaGateBank,FmAlts\n'+s
 tail='.proc HuSourceCallbackTail\n sta NextBank_SMC+1\n plp\n pla\n pla\n jmp NextBank_SMC\n.endproc\n'
 assert s.count(tail)==1;s=s.replace(tail,'')
 old=' lda #.lobyte(.bank(SamusDrawShots)|$80)\n sta NextBank_SMC+1\n plp\n pla\n pla\n jmp NextBank_SMC'
 assert s.count(old)==1;s=s.replace(old,old.replace(' sta NextBank_SMC+1','::HuSourceCallbackTail:\n sta NextBank_SMC+1'),1)
 prefix='''HuGenericIndex:
 lda SelectedCharacter
 jmp HuQClass
HuQuickAlt:
 lda FmAlts
 and #32
 beq HuQuickNative
 jmp HuQuickSet
'''
 s=s.replace('.res $20-(*-HuStart),$ff',prefix+'.res $20-(*-HuStart),$ff',1)
 islands=[('HuMovement','HuQClass:\n cmp #9\n jmp HuQDecide'),
 ('HuGraphics','HuQDecide:\n beq HuQuickAlt\n jmp HuCommonAfterSelected'),
 ('HuDraw','HuQuickNative:\n lda #9\n jmp HuCommonAfterSelected'),
 ('HuPortrait','HuQuickSet:\n sty ArenaGateBank\n bne HuQLow'),
 ('HuWeapons','HuQLow:\n lda #<QwService\n jmp HuQStoreLo'),
 ('HuInjury','HuQStoreLo:\n sta FarcallJmpTarget_SMC+1\n bne HuQHigh'),
 ('HuInjuryStatus','HuQHigh:\n lda #>QwService\n jmp HuQStoreHi'),
 ('HuDeathStart','HuQStoreHi:\n sta FarcallJmpTarget_SMC+2\n bne HuQBank'),
 ('HuDeath','HuQBank:\n lda #.lobyte(.bank(QwService)|$80)\n jmp HuQStoreBank'),
 ('HuVisible','HuQStoreBank:\n sta NextBank_SMC+1\n bne HuQRestore'),
 ('HuHead','HuQRestore:\n jmp HuCommon::Restore\n .res 2,$ff')]
 for name,body in islands:
  pat=r'(\.proc '+name+r'\n.*?)( \.res 5,\$ff)(.*?\.endproc)'
  s,n=re.subn(pat,lambda m:m[1]+'::'+body.replace('\nHu','\n::Hu')+m[3],s,count=1,flags=re.S);assert n==1,name
 s=s.replace('.proc HuCommon\n lda SelectedCharacter','.proc HuCommon\n jmp HuGenericIndex\n::HuCommonAfterSelected:',1)
 s+='\n.assert .lobyte(QwService)<>0,lderror,"Quick selector low-byte branch"\n.assert .hibyte(QwService)<>0,lderror,"Quick selector high-byte branch"\n'
 p.write_text(s,newline='\n')
 p=N/'src/new_roster_dispatch.s';s=p.read_text()
 # Existing rare hash requires carry1. CMP#9 supplies it for both legacy
 # native forms; HuCommon still chooses Quick ONLY for the actual alt bit.
 old=' cmp #24\n beq Rare\n cmp #28\n beq Rare\n cmp #20'
 assert s.count(old)==1;s=s.replace(old,' cmp #28\n bcs Rare\n cmp #20',1)
 old='Low:\n cmp #2\n beq Rare\n ldy #0\n rts'
 assert s.count(old)==1;s=s.replace(old,'Low:\n cmp #2\n beq Rare\n cmp #9\n beq Rare\n ldy #0\n rts',1)
 # The four bytes formerly rejecting every low ID now select ONLY raw9.
 old=' cmp #20\n bcc Legacy\n cmp #26';assert s.count(old)==1
 s=s.replace(old,' cmp #9\n beq GmOnlyQuick\n cmp #26',1)
 old=' beq GmOnlyRare\n jmp GmOnlyLegacy\n .res 9,$ff';assert s.count(old)==1
 new=''' beq GmOnlyRare
 bne GmOnlyLegacy
::GmOnlyQuick:
 lda FmAlts
 and #32
 beq GmOnlyLegacy
 jmp GmOnlyRare
'''
 s=s.replace(old,new,1);p.write_text(s,newline='\n')
 # Root-qualified true data bank, one-byte actual symbolic selector.
 p=N/'src/mmc5.s';s=p.read_text();assert '.import FfArtStart'not in s
 s='.import FfArtStart\n'+s
 lines=s.splitlines();at=next(i for i,l in enumerate(lines)if 'DwResidentGraphicsBanks:'in l)
 # Keep table formatting untouched, bind exact raw22 element in the assembler.
 index=0;changed=False
 for i in range(at+1,len(lines)):
  line=lines[i]
  if '.byte'not in line:
   if index:break
   continue
  code,*comment=line.split(';',1);values=code.split('.byte',1)[1].split(',')
  if index<=16<index+len(values):
   k=16-index;assert values[k].strip().lower()=='$ff',(i,values[k]);values[k]='.lobyte(.bank(FfArtStart)|MMC5_PRG_ROM)'
   lines[i]=code.split('.byte',1)[0]+'.byte'+','.join(values)+(' ;'+comment[0]if comment else'');changed=True
  index+=len(values)
 assert changed; p.write_text('\n'.join(lines)+'\n',newline='\n')

def compile_source():
 for name in ['union.s','src/new_roster_dispatch.s','src/mmc5.s']:
  (O/(Path(name).name+'.diff')).write_text(''.join(difflib.unified_diff((P/name).read_text().splitlines(True),(N/name).read_text().splitlines(True),fromfile='parent/'+name,tofile='successor/'+name)),newline='\n')
 commands=[]
 for name in ['main','union']:
  q=json.loads((R/'build/current-character-composition-v1'/('compile-'+name+'.json')).read_text())['command']
  commands.append((rewrite(q,R/'build/current-character-composition-v1/joint'),'compile-'+name))
 commands.append((rewrite(json.loads((OLD/'final-link.json').read_text())['command'],P),'final-link'))
 for cmd,name in commands:guard(cmd)
 B.O=O;B.N=N
 for cmd,name in commands:B.run(cmd,name)
 from prepare_cv3_dmc_mirror import prepare
 prepare(R,N/'candidate.nes')
 for name in ['code.bin','data.bin','ram3.bin','ff-cookie.bin','quick/cookie.bin']:assert(N/name).read_bytes()==(P/name).read_bytes(),name
 check_bindings(OLD/'source-stage-handoff-v2.json')
 (O/'source-stage.json').write_text(json.dumps(dict(candidate=B.sha(N/'candidate.nes'),parent=B.sha(P/'candidate.nes'),native=False,installed=False,upstream_raw9_legacy_latency_pending=True,notes='Original11B public prologues/PCs and all payloads preserved. Genuine source-only Quick service transport; first15 raw9 callbacks use original rare-hash frame.'),indent=2)+'\n')
 print((O/'source-stage.json').read_text())

def main():
 assert not O.exists();check_bindings(OLD/'source-stage-handoff-v2.json')
 O.mkdir();shutil.copytree(P,N)
 for p in N.rglob('*'):
  if p.is_file()and p.suffix in ['.s','.inc','.cfg']:
   s=p.read_text();z=s.replace(str(P),str(N)).replace(P.as_posix(),N.as_posix())
   if s!=z:p.write_text(z,newline='\n')
 patch_source();compile_source()

if __name__=='__main__':main()
