"""Actual0b16 constructor/real-menu retirement aliases and normal PPU flush."""
from pathlib import Path
import hashlib,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(R/'tools/audit'))
import contra_force_p1_stale_palette_ppu_v2 as F
V,Q,T,C=F.V,F.Q,F.T,F.C;O=R/'build/contra-force-p1-acquire-retire-controls-v1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 assert not O.exists();O.mkdir();out=dict(passed=False,native=False,ready=False,checks={})
 try:
  acquire=[];retire=[]
  for var in range(4):
   base=Q.load(var);Q.V.invoke(base,'MoveAllSpritesOffscreen')
   for marker in[0,1,128,193]:
    m=C.clone(base);T.put(m,SmFreezeLastBlue=marker,SmFreezePalettePending=128,SmFreezeTurn=1,SmFreezeRenderState=1,SmFreezePaletteControl=3,VRAM_Buffer1_Offset=0,VRAM_Buffer_AddrCtrl=0,Sprite0HitDetectFlag=0);m[T.address(T.B,'VRAM_Buffer1')]=0
    z=Q.public(m,15,p=0x79)
    assert [T.get(m,n)for n in['SmFreezeLastBlue','SmFreezePalettePending','SmFreezeTurn','SmFreezeRenderState','SmFreezePaletteControl']]==[192,192,0,1,3]
    assert all(m[512+i]>=240 for i in range(0,256,4))
    normal=F.normal(m);assert normal['paletteP1']==[28,54,23]
    acquire.append(dict(variant=var,oldmarker=marker,AXYP=z['AXYP'],nativeP1=normal['paletteP1']))
   # Actual controller-independent MenuResolve API, not readiness grant.
   m=V.scene(var)
   for _ in range(5):V.draw(m);F.normal(m)
   assert T.get(m,'SmFreezeLastBlue')==193
   for index in[0,1,21,26]:
    z=C.clone(m);T.put(z,CrossoverMenuIndex=index,FmAlts=0,FmGroups=var<<3,VRAM_Buffer1_Offset=0,VRAM_Buffer_AddrCtrl=0,Sprite0HitDetectFlag=0);z[T.address(T.B,'VRAM_Buffer1')]=0;writes=len(z.writes)
    result=Q.V.invoke(z,'MenuResolveCharacter')
    event=z.writes[writes:];invalidate=next(i for i,(a,v)in enumerate(event)if a==0xdfe0 and v==0);publish=next(i for i,(a,v)in enumerate(event)if a==T.address(T.B,'SelectedCharacter'))
    assert invalidate<publish and z.ram[2][0x1fe0]==0
    assert T.get(z,'SmFreezeLastBlue')not in[192,193]and T.get(z,'SmFreezePalettePending')==192
    assert all(z[512+i]>=240 for i in range(0,256,4)),('oldCF OAM retired',var,index)
    normal=F.normal(z);assert normal['paletteP1']==[26,48,39]
    retire.append(dict(variant=var,menu_index=index,selected=T.get(z,'SelectedCharacter'),invalidate_before_Selected=True,oldCF_OAM_off=True,PPU_nativeP1=normal['paletteP1'],AXYP=result['AXYP']))
  out['checks']=dict(actual_scene_acquisition=acquire,actual_MenuResolve_retirement=retire,protected_State_Control_preserved_by_CF_acquire=True)
  out['passed']=True
 except Exception as e:out.update(error=repr(e),traceback=traceback.format_exc());raise
 finally:
  files=[Path(__file__),Path(F.__file__),V.P/'source-stage.json',V.P/'joint/candidate.nes',R/'docs/qa/checkpoints/2026-10-31/contra-force-p1-source-experiment-v1/handoff.json']
  out['bindings']={str(p.resolve()):sha(p)for p in files};p=O/'controls.json';p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(path=str(p),sha256=sha(p),passed=out['passed'],error=out.get('error'))),flush=True)
if __name__=='__main__':main()
