"""Private59B source factoring and own selected-C2 palette/API checks."""
from pathlib import Path
import hashlib,itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import wwf_hogan_runtime_controls_v3 as V
import ff_joint_native_flash_controls_1030_v3 as F
from verify_native_relocation import NesMPU
from check_tmnt_render_oa import address,location
from ff_wram_host_isr_v4 import clone
from wwf_first_hogan_owner_isr_v1 import interrupt
H=V.H;T=V.T
J=R/'build/wwf-hogan-natural-source-v7/joint';P=R/'build/contra-force-world-roles-1031-v2/joint'
O=R/'build/wwf-hogan-palette-groups-controls-v2'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
flags=[0x30|(n&15)|((n&48)<<2)for n in range(64)]

def own(b):
 V.J=J
 return V.make(b)

def shared(m,p=0x71,hook=None):
 c=H.start(m,'FwNativeDrawAll',p=p);c,lo=H.finish(m,c,hook);assert m.rawtags[2]==H.get(m,'CurrentBankC');return c,lo

def main():
 assert not O.exists();O.mkdir();q=dict(passed=False,native=False,readiness=False,shared_private_proposal=True,checks={})
 old=T.qualified(P/'candidate.nes');b=T.qualified(J/'candidate.nes')
 try:
  # Loaded WWF body and a nativeP1 Koopa: whole groups alternate fairly.
  m=own(b);H.put(m,AreaType=1,SmFreezePaletteControl=2,SmFreezeRenderState=0,RgOamUsed=0,RgOamFirst=0,RgOamRotation=0,GuestOamRotationActive=0,SpriteShuffleOffset=0,FrameCounter=0)
  for n in ['ObjectMetasprite','SprObject_SprAttrib']:
   for i in range(24):m[address(b,n)+i]=0
  meta=address(b,'METASPRITE_KOOPA_WALKING_1')
  m[address(b,'ObjectMetasprite')+1]=meta
  for n,v in dict(Enemy_Flag=1,Enemy_ID=0,Enemy_X_Position=184,Enemy_PageLoc=0,Enemy_Y_Position=176,Enemy_Y_HighPos=1,Enemy_MovingDir=1,Enemy_SprAttrib=1).items():m[address(b,n)]=v
  phases=[];attrs=bytes(m[address(b,'SprObject_SprAttrib'):address(b,'SprObject_SprAttrib')+24])
  for age in range(4):
   H.put(m,CurrentOAMOffset=0,VRAM_Buffer1_Offset=0)
   m[512:768]=[248,0,0,0]*64;m[address(b,'VRAM_Buffer1')]=0
   H.invoke(m,'PlayerGfxHandler');shared(m)
   assert bytes(m[address(b,'SprObject_SprAttrib'):address(b,'SprObject_SprAttrib')+24])==attrs
   assert all(m[514+i]&24==0 for i in range(0,256,4))
   choice=m.ram[2][address(b,'WfP1Choice')-0xc000]
   queue=list(m[address(b,'VRAM_Buffer1'):address(b,'VRAM_Buffer1')+7])
   assert queue==[63,21,3,*([22,5,15]if choice else [26,48,39]),0]
   phases.append(dict(choice=choice,queue=queue,OAM=list(m[512:768]),visible_parts=sum(m[512+i]<240 for i in range(0,H.get(m,'CurrentOAMOffset'),4))))
  assert[r['choice']for r in phases]==[1,0,1,0],phases
  q['checks']['whole_original_body_native_P1_groups']=dict(passed=True,phases=phases)
  q.update(passed=True,candidate=sha(J/'candidate.nes'))
 except Exception as e:q.update(error=repr(e),traceback=traceback.format_exc());raise
 finally:
  q['bindings']={str(p.resolve()):sha(p)for p in [Path(__file__),Path(V.__file__),Path(F.__file__),J/'candidate.nes',J/'candidate.dbg',J.parent/'source-stage.json',P/'candidate.nes',P/'candidate.dbg']}
  (O/'controls.json').write_text(json.dumps(q,indent=2)+'\n');print(json.dumps({k:q.get(k)for k in ['passed','candidate','error']}))
if __name__=='__main__':main()
