"""Selected-owner indexed API in retained Quick ROM; no common hooks."""
from pathlib import Path
import json,shutil,sys
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(Path(__file__).parent))
import prepare_quickman_current_rebase_v1 as B
P=B.O;O=R/'build/quickman-current-services-v2'
ROWS=['QhMovement','QhGraphics','QhDraw','GmPublishEmpty','QhWeapons','QhInjury','QhStatus','QhDeathStart','QhDeath','QhVisible','QhHead','GmIceBody','QhAdder','QhBoxProfile','QhSide','QwConstruct','QhBox','QwPortrait','FmQueueName','QwConstruct','QhPrepare','QhDecline','QhDecline','GmMatureOwn','QhPickup','QhFullPower','QwColors','QhDecline','QhDecline','QhUi','QhStatusName','QhDecline','HuNativeWorldPalette','QhNoop','QhNoop','QhDecline']

def prepare():
    assert not O.exists()
    assert json.loads((P/'component-source-proof.json').read_text())['ROM_sha256']=='78341817b34727ecc41c0d0474b3d362915fdc29e737150fc4807d5fbb7f875b'
    shutil.copytree(P,O)
    for p in O.rglob('*'):
        if p.is_file()and p.suffix in ['.s','.inc','.cfg']:
            try:p.write_text(p.read_text().replace(P.as_posix(),O.as_posix()).replace(str(P),str(O)),newline='\n')
            except UnicodeDecodeError:pass
    # Consume only the two adjacent retained Quick leaves, not another owner.
    cfg=(O/'quick.cfg').read_text()
    assert cfg.count('QW_ROUTER_MEM:start=$a860,size=$2d0')==1
    cfg=cfg.replace('QW_ROUTER_MEM:start=$a860,size=$2d0','QW_ROUTER_MEM:start=$a860,size=$315',1)
    assert cfg.count('X5_NEW_46_Qkeep1:start=$cb30,size=$14d0')==1
    cfg=cfg.replace('X5_NEW_46_Qkeep1:start=$cb30,size=$14d0','X5_NEW_46_Qkeep1:start=$cb75,size=$148b',1)
    (O/'quick.cfg').write_text(cfg,newline='\n')
    pre=json.loads((O/'component-preflight.json').read_text())
    pre['slots'][0][2][0][1]=0x315
    raw=(P/'exact-parent.nes').read_bytes();at=16+70*8192+0x860
    assert raw[at:at+0x315]==bytes([255])*0x315
    (O/'component-preflight.json').write_text(json.dumps(pre,indent=2)+'\n',newline='\n')
    p=O/'quick/loader.s';s=p.read_text()
    # Shared producer owner approved this zero-byte export; no route or
    # instruction changes are introduced in the private common copy.
    (O/'union.s').write_text('.export HuNativeWorldPalette\n'+(O/'union.s').read_text(),newline='\n')
    declarations='.import NextBank_SMC,ArenaGateBank,GmPublishEmpty,GmIceBody,GmMatureOwn,FmQueueName,HuNativeWorldPalette\n.import '+','.join(sorted(set(n for n in ROWS if n.startswith('Qh')and n not in ['QhGraphics','QhDraw'])))+'\n.export QwService\n'
    helper='''
; Genuine SFC entry: source A, original Y/P, X unchanged. The selected common
; route stores only service index in the existing ArenaGateBank beforehand.
; RAM and ROM rows use true source imports; never OR80 a RAM-owned tag.
QwService:
 php
 pha
 tya
 pha
 ldy ArenaGateBank
 cpy #36
 bcs QwServiceReject
 lda QwServiceLo,y
 sta ArenaGatePtr
 sta FarcallJmpTarget_SMC+1
 lda QwServiceHi,y
 sta ArenaGatePtr+1
 sta FarcallJmpTarget_SMC+2
 lda QwServiceBank,y
 bmi QwServiceROM
 pla
 tay
 pla
 plp
 jmp QwRouter
QwServiceROM:
 sta NextBank_SMC+1
 pla
 tay
 pla
 plp
 sta SafecallA_SMC+1
 jmp FarCallCommon+3
QwServiceReject:
 pla
 tay
 pla
 plp
 clc
 rts
'''
    helper+='QwServiceLo:\n .byte '+','.join('<'+n for n in ROWS)+'\n'
    helper+='QwServiceHi:\n .byte '+','.join('>'+n for n in ROWS)+'\n'
    helper+='QwServiceBank:\n .byte '+','.join('1'if n.startswith('Qh')else'.lobyte(.bank('+n+')|$80)'for n in ROWS)+'\n'
    needle='.segment "QW_LOADER"'
    assert s.count(needle)==1
    p.write_text(declarations+s.replace(needle,helper+'\n'+needle,1),newline='\n')
    (O/'service-API.json').write_text(json.dumps(dict(status='PRIVATE_SELECTED_API_SOURCE_PROTOTYPE_NO_COMMON_HOOK',identity='SelectedCharacter9 and FmAlts&32',entry='QwService via genuine SFC, caller stores index in selected-owned ArenaGateBank before restoring original Y/P',input='A source; original Y/P (native SFC NZ as normal); X unmodified; index0..35',invalid='36..255 reject carry-clear; no payload dispatch',rows=[dict(index=i,target=n,raw_bank=1 if n.startswith('Qh')else'source .bank(target)|80')for i,n in enumerate(ROWS)],scope='No menu/common/draw ingress installed. Does not solve old nested Z2 foreign route by itself.',native=False),indent=2)+'\n',newline='\n')

if __name__=='__main__':
    if '--prepare'in sys.argv:prepare()
    if '--build'in sys.argv:
        B.O=O;B.run(B.command('union'),'service-zero-byte-export');B.build()
