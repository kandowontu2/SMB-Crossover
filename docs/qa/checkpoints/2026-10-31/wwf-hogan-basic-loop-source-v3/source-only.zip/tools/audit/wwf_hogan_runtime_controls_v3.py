"""Finite loaded first-Hogan runtime API checks. No shared hooks/native launch."""
from pathlib import Path
import hashlib,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import wwf_first_hogan_owner_controls_v1 as T
from check_tmnt_render_oa import address
from prepare_ff_current_component_v2 import qualified
J=R/'build/wwf-hogan-runtime-v8/joint';O=R/'build/wwf-hogan-runtime-controls-v3'
H=T.H
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def make(b):
 m=T.make(b);T.run(m,'WfLoad');T.run(m,'WfConstructCold')
 H.put(m,GameEngineSubroutine=8,TimerControl=0,GamePauseStatus=0,
       Player_X_Position=128,Player_PageLoc=0,Player_Y_Position=176,
       Player_Y_HighPos=1,Player_State=0,Player_Y_Speed=0,
       SavedJoypadBits=0,ScreenLeft_X_Pos=0,ScreenLeft_PageLoc=0,
       Player_SprAttrib=0,CurrentOAMOffset=0,ReloadCHRBank=0)
 for n in ['Enemy_Flag','Enemy_ID','Enemy_State']:
  at=address(b,n)
  for i in range(6):m[at+i]=0
 for at in range(address(b,'Block_Buffer_1'),address(b,'Block_Buffer_2')+208):m[at]=0
 return m

def main():
 assert not O.exists();O.mkdir();q=dict(passed=False,native=False,shared_hooks=False,checks={})
 b=qualified(J/'candidate.nes');stage=json.loads((J.parent/'source-stage.json').read_text())
 try:
  m=make(b);calls=[]
  def entered(mem,cpu,step):
   if cpu.pc in [address(b,'WfHostFrame'),address(b,'WfVmTickCore'),address(b,'ShellOrBlockDefeat')]:calls.append([cpu.pc,cpu.x,cpu.y])
  rows=[]
  for age in range(200):
   keys=0 if age<70 else (1 if age<110 else (129 if age==110 else (1 if age<160 else 64)))
   H.put(m,SavedJoypadBits=keys,A_B_Buttons=keys&192,PreviousA_B_Buttons=(rows[-1]['keys']&192)if rows else 0)
   c,lo=T.run(m,'WfMovement',hook=entered)
   assert c.p&1
   rows.append(dict(age=age,keys=keys,x=H.get(m,'Player_X_Position')+256*H.get(m,'Player_PageLoc'),y=H.get(m,'Player_Y_Position')+256*H.get(m,'Player_Y_HighPos'),source_jump=m.ram[2][0x30],action=m.ram[2][0x3c],pose=[m.ram[2][0x32],m.ram[2][0x34]],HP=m.ram[2][0x79],phase=m.ram[2][0x71]))
  q['checks']['controller_runtime']=dict(passed=True,frames=200,rows=rows,calls=calls)
  # Desired page changes must remain pending when the API restores its maps.
  m=make(b);before=H.get(m,'CurrentCHRBank');T.run(m,'WfGraphics')
  q['checks']['graphics_pending']=dict(old=before,new=H.get(m,'CurrentCHRBank'),reload=H.get(m,'ReloadCHRBank'))
  assert H.get(m,'CurrentCHRBank')==553&255 and H.get(m,'ReloadCHRBank')!=0,'New source body page lost pending hardware publication'
  T.run(m,'WfDrawBody');count=H.get(m,'CurrentOAMOffset');assert count==40,('idle original10parts',count)
  q['checks']['idle_native_OAM']=dict(passed=True,parts=count//4)
  art=json.loads((R/'build/wwf-roster-source-review-v1/wrestlers.json').read_text())
  poses=[p for p in art['poses']if p['character']==5];pages=sorted({p['packed_page']for p in poses});render=[]
  for pose in poses:
   for face in [0,1]:
    m=make(b);m.ram[2][0x32]=pose['group'];m.ram[2][0x34]=pose['frame'];m.ram[2][0x3a]=face
    T.run(m,'WfGraphics');off=address(b,'WfRenderBuffer')-0xc000;expected=[4*len(pose['packed_8x16_cells'])]
    for cell in pose['packed_8x16_cells']:
     expected += [cell['page_tile'],cell['role']|(64 if face else 0),cell['y']&255,((pose['width']-cell['x'])if face else cell['x'])&255]
    assert list(m.ram[2][off:off+len(expected)])==expected,('Source record',pose['group'],pose['frame'],face)
    assert H.get(m,'CurrentCHRBank')==(546+pages.index(pose['packed_page']))&255
    assert H.get(m,'ReloadCHRBank')==1
    T.run(m,'WfDrawBody');n=H.get(m,'CurrentOAMOffset');assert n==4*len(pose['packed_8x16_cells']),('OAM count',pose['group'],face,n)
    render.append([pose['group'],pose['frame'],face,n//4])
  q['checks']['all_original_pose_records_and_kernel']=dict(passed=True,cases=len(render),rows=render,fixture='Pose/face API units modify only authored pose fields after real load/constructor; no readiness/code preload')
  actions=[]
  for keys in [128,64,192,8|64,4|64]:
   m=make(b)
   for age in range(75):H.put(m,SavedJoypadBits=0,A_B_Buttons=0,PreviousA_B_Buttons=0);T.run(m,'WfMovement')
   trace=[]
   for age in range(140):
    held=keys if age<18 else 0
    H.put(m,SavedJoypadBits=held,A_B_Buttons=held&192,PreviousA_B_Buttons=(keys&192)if 0<age<=18 else 0);T.run(m,'WfMovement')
    trace.append([age,m.ram[2][0x3c],m.ram[2][0x32],m.ram[2][0x34],m.ram[2][0x30],H.get(m,'Player_Y_Position')])
   actions.append(dict(keys=keys,actions=sorted({r[1]for r in trace}),poses=sorted({r[2]for r in trace}),signed_min_jump=min(r[4]if r[4]<128 else r[4]-256 for r in trace),trace=trace))
  q['checks']['actual_controller_action_discovery']=dict(passed=True,cases=len(actions),rows=actions)
  q.update(passed=True,candidate=stage['candidate'])
 except Exception as e:q.update(error=repr(e),traceback=traceback.format_exc());raise
 finally:
  q['bindings']={str(p.resolve()):sha(p)for p in [Path(__file__),Path(T.__file__),J/'candidate.nes',J/'candidate.dbg',J.parent/'source-stage.json']}
  (O/'controls.json').write_text(json.dumps(q,indent=2)+'\n')
  print(json.dumps({k:q.get(k)for k in ['passed','candidate','error']}))
if __name__=='__main__':main()
