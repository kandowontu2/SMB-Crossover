"""Real selected indexed transport vs the same genuine direct source targets."""
from pathlib import Path
import copy,json,sys,hashlib
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(Path(__file__).parent))
import quickman_wram_palette_controls_v6 as C
from prepare_quickman_current_services_v2 import ROWS
O=R/'build/quickman-current-services-v2'
C.O=O;C.CODE=(O/'code.bin').read_bytes();C.DATA=(O/'data.bin').read_bytes()
def save(n,d):(O/n).write_text(json.dumps(d,indent=2)+'\n',newline='\n')
def clone(m):
    n=copy.copy(m)
    for k,v in m.__dict__.items():
        if k not in ['bundle','lab','ROM_banks']:setattr(n,k,copy.deepcopy(v))
    n.writes=[];n.cache_writes=[];n.events=[];return n
def execute(m,target,A=0,X=0,Y=1,P=0x30,hook=None):
    # Genuine SFC call setup, with no fixture redirects in cartridge bytes.
    # C is a typed output for certain ROM graphics rows, compared with exactly
    # the same original worker rather than incorrectly requiring old C.
    if target.startswith('Qh'):
        pc=m.lab[target];m.set('ArenaGatePtr',pc);m.ram[m.lab['ArenaGatePtr']+1]=pc>>8;target='QwRouter'
    m.ram[m.lab['SafecallA_SMC']+1]=A
    m.ram[m.lab['FarcallJmpTarget_SMC']+1]=m.lab[target]&255
    m.ram[m.lab['FarcallJmpTarget_SMC']+2]=m.lab[target]>>8
    m.ram[0x1fe]=0xfe;m.ram[0x1ff]=0x7f
    incoming=m.tags[:]
    c=C.H.N.NesMPU(memory=m,pc=m.lab['FarCallCommon']);c.a=m.bank(target)|128;c.x=X;c.y=Y;c.p=P;c.sp=253
    low=253
    for _ in range(800000):
        if c.pc==0x7fff:break
        m.pc=c.pc;low=min(low,c.sp)
        if hook:hook(c)
        assert m[c.pc]!=0,('BRK',target,hex(c.pc),m.tags)
        c.step()
    else:raise AssertionError(('timeout',target,hex(c.pc),m.tags))
    assert c.sp==255 and m.tags[0:2]==incoming[0:2]and m.tags[3]==incoming[3]
    assert m.get('CurrentBank')==m.tags[1]and m.get('CurrentBankC')==m.tags[2]
    return dict(A=c.a,X=c.x,Y=c.y,P=c.p,SP=c.sp),c.processorCycles,low
def main():
    m=C.Bus();C.invoke(m,'QwConstruct');C.exact_cache(m)
    m.set('GameEngineSubroutine',8);m.set('Player_Y_HighPos',1);m.set('Player_Y_Position',160);m.set('Player_X_Position',96)
    m.set('ObjectOffset',0);m.set('PowerUpType',0);m.set('Enemy_Flag',0)
    transport=set()
    for n,size in [('ArenaGateA',1),('ArenaGateP',1),('ArenaGatePtr',2),('ArenaGateBank',1)]:transport.update(range(m.lab[n],m.lab[n]+size))
    smc=next(s for s in m.bundle['segs'].values()if s['name']=='"SMCCODE"');sa=int(smc['start'],0);sn=int(smc['size'],0);assert sn==33
    ignore=transport|set(range(0x100,0x200))|set(range(0x5100,0x5140))
    rows=[]
    for i,target in enumerate(ROWS):
        for p in [x for x in range(256)if x&0x30==0x30]:
            a=clone(m);b=clone(m);a.set('ArenaGateBank',i);b.set('ArenaGateBank',i)
            ra,ca,la=execute(a,target,P=p);rb,cb,lb=execute(b,'QwService',P=p)
            assert ra==rb,('AXYP',i,target,p,ra,rb)
            assert a.tags==b.tags and a.chr==b.chr and a.upper==b.upper
            assert a.wram==b.wram
            diff=[j for j in range(0x8000)if j not in ignore and a.ram[j]!=b.ram[j]]
            assert not diff,('state',i,target,p,[hex(x)for x in diff[:30]])
            assert a.ram[sa:sa+33]==b.ram[sa:sa+33],('33SMC',i,target,p)
            app=lambda bus:[(ad,v)for ad,v in bus.writes if ad not in ignore and not sa<=ad<sa+sn]
            assert app(a)==app(b),('orderedapplicationwrites',i,target,p,app(a),app(b))
            live=min(la,lb);assert a.ram[0x100:0x100+live]==b.ram[0x100:0x100+live]
            rows.append([i,p,ca,cb,cb-ca,la,lb])
    rejected=[]
    for i in range(36,256):
        n=clone(m);n.set('ArenaGateBank',i);r,cycles,low=execute(n,'QwService',A=0x83,X=0x5a,Y=0xc7,P=0xf3)
        assert (r['A'],r['X'],r['Y'],r['P']&1)==(0x83,0x5a,0xc7,0)
        assert n.wram==m.wram and n.chr==m.chr
        rejected.append([i,cycles,low])
    save('service-controls.json',dict(passed=True,native=False,ROM_sha256=hashlib.sha256((O/'candidate.nes').read_bytes()).hexdigest(),scope='Direct selected QwService vs genuine workers; no shared ingress/Main claim',rows=rows,cases=len(rows),rejected_indices=rejected,all_AXYP_SP_maps_R01_33SMC_live_page1_ordered_application_writes_exact=True,maximum_added_CPU=max(x[4]for x in rows)))
    print('Quick genuine indexed API PASS',len(rows),'cases',len(rejected),'invalid indices',flush=True)
def interrupts():
    template=C.Bus();C.invoke(template,'QwConstruct');C.exact_cache(template)
    template.set('GameEngineSubroutine',8);template.set('Player_Y_HighPos',1);template.set('Player_Y_Position',160);template.set('Player_X_Position',96)
    rows=[]
    for index in [0,2,11,17,26,32,36]:
        m=clone(template);m.set('ArenaGateBank',index);cuts=[];seen=set();count=0
        def observe(c):
            nonlocal count
            pc=c.pc;tag=m.tags[(pc-0x8000)//8192]if pc>=0x8000 else -1
            op=bytes(m[pc:pc+3]);key=(tag,pc)
            if key not in seen and (m.lab['QwService']<=pc<m.lab['QwServiceLo']and tag==198 or 0x15a<=pc<0x17b or op in [b'\x8d\x15\x51',b'\x8d\x16\x51']):
                seen.add(key);cuts.append((count,pc))
            count+=1
        execute(m,'QwService',hook=observe)
        for step,pc in cuts:
            for lag in [0,255]:
                for kind in ['NMI','IRQ']:
                    m=clone(template);m.set('ArenaGateBank',index);m.set('NmiDisable',lag);at=0;proof=[]
                    def inject(c):
                        nonlocal at
                        if at==step:
                            assert c.pc==pc
                            assert not c.p&c.INTERRUPT
                            proof.append(C.interrupt_at(m,c,kind))
                        at+=1
                    execute(m,'QwService',hook=inject)
                    assert len(proof)==1
                    C.exact_cache(m)
                    rows.append(dict(service=index,step=step,PC=pc,lag=lag,**proof[0]))
    save('service-isr-controls.json',dict(passed=True,native=False,scope='Real vectors at every unique executed helper instruction and all genuine SFC/rawmapper seams on7distinct RAM/ROM/reject routes; no joint ingress/Main claim',real_interruptions=len(rows),preserves='AXYP/SP/livepage1/all33SMC/rawmaps/shadows/R01/R67/cache',rows=rows))
    print('Quick selected helper real ISR PASS',len(rows),flush=True)
if __name__=='__main__':
    if '--interrupts'in sys.argv:interrupts()
    else:main()
