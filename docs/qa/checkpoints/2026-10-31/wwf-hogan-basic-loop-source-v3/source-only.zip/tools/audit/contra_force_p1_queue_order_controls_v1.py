"""Actual native queue-full/body retry, heartbeat, late native P1 ordering."""
from pathlib import Path
import hashlib,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(R/'tools/audit'))
import contra_force_p1_stale_palette_ppu_v2 as F
V,Q,T,C,U=F.V,F.Q,F.T,F.C,F.U;O=R/'build/contra-force-p1-queue-order-controls-v1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def normal(m):
 T.put(m,NmiDisable=0,Sprite0HitDetectFlag=0,SavedJoypadBits=0);m[21028]=128;c=T.NesMPU(memory=m,pc=32767);c.sp=192;c.p=48;m.ppu_log.clear();proof=U.interrupt(m,c,'NMI',keep_ppu=False)
 return dict(**proof,P1=list(m.vram[0x3f15:0x3f18]),P2=list(m.vram[0x3f19:0x3f1c]),PPUDATA=[v for a,v in m.ppu_log if a==8199])
def row29(m):return Q.public(m,29,p=0x79)
def main():
 assert not O.exists();O.mkdir();out=dict(passed=False,native=False,ready=False,scope='Explicit actual source callbacks/queue consumers, not naturalMain/controller admission.',checks={})
 try:
  base=V.scene();V.draw(base);normal(base);assert T.get(base,'SmFreezeLastBlue')==193
  full=[]
  for paused in[0,1]:
   m=C.clone(base);T.put(m,NmiDisable=255,GamePauseStatus=paused,VRAM_Buffer1_Offset=0,VRAM_Buffer_AddrCtrl=0);m[T.address(T.B,'VRAM_Buffer1')]=0
   for _ in range(13):Q.V.invoke(m,'QueueGuestWeaponPalette')
   assert T.get(m,'VRAM_Buffer1_Offset')==78
   queue=bytes(m[T.address(T.B,'VRAM_Buffer1'):T.address(T.B,'VRAM_Buffer1')+85]);assert queue[:78]==bytes([63,25,3,22,48,39])*13
   oam=bytes(m[512:768]);turn=T.get(m,'SmFreezeTurn');m.ram[2][0x2e2]=1;z=row29(m)
   assert m.ram[2][0x2e2]==1 and bytes(m[T.address(T.B,'VRAM_Buffer1'):T.address(T.B,'VRAM_Buffer1')+85])==queue
   assert T.get(m,'SmFreezePalettePending')==128 and T.get(m,'SmFreezeTurn')==turn and bytes(m[512:768])==oam
   # Busy lagNMI cannot consume a pending completed palette or change source.
   c=T.NesMPU(memory=m,pc=32767);c.sp=192;c.p=48;before=(T.get(m,'SmFreezePalettePending'),bytes(m[512:768]));m.ppu_log.clear();lag=U.interrupt(m,c,'NMI',keep_ppu=False)
   assert (T.get(m,'SmFreezePalettePending'),bytes(m[512:768]))==before and not m.ppu_log
   n=normal(m);assert n['P1']==[32,56,22]and n['P2']==[22,48,39]and T.get(m,'VRAM_Buffer1_Offset')==0
   T.put(m,NmiDisable=255);z=row29(m);assert m.ram[2][0x2e2]==0 and T.get(m,'VRAM_Buffer1_Offset')==7
   n2=normal(m);assert n2['P1']==[32,56,22]and bytes(m[512:768])==oam
   full.append(dict(paused=paused,real_native_queue_bytes=78,dirty_retry_complete=True,no_draw_OAM_Turn_changes=True,lagCPU=lag['CPU'],normal_P1=n['P1'],retry_P1=n2['P1']))
  out['checks']['actual_fullqueue_and_paused_skipped_draw']=full
  # Every packet byte is validated; no blind rebuild of malformed payload.
  malformed=[]
  for byte in range(7):
   for xor in[1,128,255]:
    m=C.clone(base);T.put(m,NmiDisable=255,VRAM_Buffer1_Offset=0);m[T.address(T.B,'VRAM_Buffer1')]=0;m.ram[2][0x2e2]=0;m[T.address(T.B,'SmFreezePalettePacket')+byte]^=xor
    before=(bytes(m[512:768]),T.get(m,'SmFreezeLastBlue'),T.get(m,'SmFreezeTurn'));row29(m)
    assert T.get(m,'SmFreezePalettePending')==0 and before==(bytes(m[512:768]),T.get(m,'SmFreezeLastBlue'),T.get(m,'SmFreezeTurn'))
    malformed.append([byte,xor])
  out['checks']['21malformed_heartbeat_rejections']=malformed
  late=[]
  for age in[1,2]:
   m=V.scene();T.put(m,AreaType=2,SmFreezePaletteControl=3,VRAM_Buffer1_Offset=0,VRAM_Buffer_AddrCtrl=0);m[T.address(T.B,'VRAM_Buffer1')]=0
   for _ in range(age):V.draw(m)
   epoch=T.get(m,'SmFreezeLastBlue');Q.V.invoke(m,'SamusFreezePaletteStoreA',a=8)
   assert T.get(m,'SmFreezePaletteControl')==8 and T.get(m,'VRAM_Buffer_AddrCtrl')==8
   ref=C.clone(m);T.put(ref,SmFreezePalettePending=0);native=normal(ref);actual=normal(m)
   assert native['P1']==[26,48,39]
   assert actual['P1']==([32,56,22]if epoch==193 else native['P1']),('late actual native palette ordering',epoch,actual,native)
   late.append(dict(epoch=epoch,native_reference_P1=native['P1'],actual_epoch_P1=actual['P1'],actual_StoreA8=True))
  out['checks']['actual_late_native_bulk_palette']=late
  out['passed']=True
 except Exception as e:out.update(error=repr(e),traceback=traceback.format_exc());raise
 finally:
  files=[Path(__file__),Path(F.__file__),V.P/'source-stage.json',V.P/'joint/candidate.nes',R/'docs/qa/checkpoints/2026-10-31/contra-force-p1-source-experiment-v1/handoff.json']
  out['bindings']={str(p.resolve()):sha(p)for p in files};p=O/'controls.json';p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(path=str(p),sha256=sha(p),passed=out['passed'],error=out.get('error'))),flush=True)
if __name__=='__main__':main()
