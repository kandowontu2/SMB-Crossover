"""Reproduce installed 18de, then source-link only Quick's owned components.

No dispatcher/admission hooks are installed by this preparation stage.
"""
from pathlib import Path
import hashlib,json,re,shutil,subprocess,sys

R=Path(__file__).resolve().parents[2]
P=R/'build/expanded-playable-roster-1030-v1/joint'
F=R/'build/quickman-wram-render-v7'
O=R/'build/quickman-current-rebase-v1'
CA=R/'tools/Windows/cc65/bin/ca65.exe'
sys.path.insert(0,str(Path(__file__).parent))
from check_tmnt_render_oa import load,address

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(n,d):(O/n).write_text(json.dumps(d,indent=2)+'\n',newline='\n')
def put(n,s):(O/n).write_text(s,newline='\n')
def retarget(s):
    for a,b in [(str(P),str(O)),(P.as_posix(),O.as_posix())]:s=s.replace(a,b)
    return s
def run(cmd,name):
    for i,a in enumerate(cmd):
        if a in ['-o','-Ln','-m','--create-full-dep']:
            assert Path(cmd[i+1]).resolve().is_relative_to(O.resolve()),(a,cmd[i+1])
    p=subprocess.run(cmd,cwd=R,capture_output=True,text=True)
    save(name+'-build.json',dict(command=cmd,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr))
    assert p.returncode==0,p.stderr[-14000:]
def command(n):return [retarget(a)for a in json.loads((P/(n+'-build.json')).read_text())['command']]
def mirror():
    sys.path.insert(0,str(R/'tools'));from prepare_cv3_dmc_mirror import prepare
    prepare(R,O/'candidate.nes')
def prepare():
    assert not O.exists()
    assert sha(P/'candidate.nes')=='18de015564c61cd07d0d52ec26300661627278880d4226f7c589ac95028a0976'
    hand=json.loads((R/'build/quickman-wram-render-cpu-v7/handoff.json').read_text())
    for p,h in hand['bindings'].items():assert sha(p)==h,p
    shutil.copytree(P,O)
    for p in O.rglob('*'):
        if p.is_file()and p.suffix in ['.s','.inc','.cfg']:
            try:p.write_text(retarget(p.read_text()),newline='\n')
            except UnicodeDecodeError:pass
    for n in ['main','rogue-component','reader','skin','gm-nmi','dk-component','union','bbox-local']:
        run(command(n),'exact-'+n)
    run(command('link'),'exact-link');mirror()
    assert sha(O/'candidate.nes')==sha(P/'candidate.nes')
    save('exact-parent.json',dict(passed=True,ROM_sha256=sha(O/'candidate.nes'),current_source=str(P),Quick_frozen_bindings_verified=len(hand['bindings'])))
    for ext in ['nes','dbg','lbl','map']:shutil.copy2(O/('candidate.'+ext),O/('exact-parent.'+ext))

def split_region(mem,name,bank,regions):
    pat=r'(?m)^\s*'+name+r':[^\n]*;'
    old=re.search(pat,mem).group()
    base=int(re.search(r'start\s*=\s*\$(\w+)',old)[1],16)
    assert int(re.search(r'size\s*=\s*\$(\w+)',old)[1],16)==8192
    cursor=0;rows=[];part=0;keeps=[]
    for off,size,label,start in sorted(regions):
        assert off>=cursor and start&8191==off
        if off>cursor:
            keep=name if cursor==0 else name+'_Qkeep'+str(part)
            rows.append(f'{keep}:start=${base+cursor:x},size=${off-cursor:x},type=ro,file=%O,fill=yes,fillval=$ff,bank=${bank:x};')
            keeps.append((cursor,off,keep))
            part+=1
        rows.append(f'{label}:start=${start:x},size=${size:x},type=ro,file=%O,fill=yes,fillval=$ff,bank=${bank:x};')
        cursor=off+size
    if cursor<8192:
        keep=f'{name}_Qkeep{part}'
        rows.append(f'{keep}:start=${base+cursor:x},size=${8192-cursor:x},type=ro,file=%O,fill=yes,fillval=$ff,bank=${bank:x};')
        keeps.append((cursor,8192,keep))
    return re.sub(pat,'\n'.join(rows),mem,count=1),keeps

def components():
    assert json.loads((O/'exact-parent.json').read_text())['passed']
    Q=O/'quick';Q.mkdir(exist_ok=True)
    for n in ['whole.s','portrait.s','loader.s','qh_imports.inc','qh_fields.inc','art-source.chr','metasprites3.bin','cookie.bin','stream.bin','stream.s']:
        src=F/'quick'/n;dst=Q/n
        if src.suffix in ['.s','.inc']:
            dst.write_text(src.read_text().replace(F.as_posix(),O.as_posix()).replace(str(F),str(O)),newline='\n')
        else:shutil.copy2(src,dst)
    # The foreign nested draw wrapper is retained only as historical evidence.
    # Export the genuine selected draw worker, without installing old ingress.
    entry=retarget((P/'entrypoint.s').read_text())
    old=(F/'entrypoint.s').read_text();a=old.index('.include "quick-parent-exports.inc"')
    extra=old[a:]
    (O/'quick-parent-exports.inc').write_text((F/'quick-parent-exports.inc').read_text(),newline='\n')
    assert entry.count('nes2wram $2000')==1
    put('entrypoint.s',entry.replace('nes2wram $2000','nes2wram $8000',1)+'\n'+extra)
    mem,segs=(O/'private.cfg').read_text().split('SEGMENTS {',1)
    # Every interval is retained from the frozen Quick reservation, not inferred
    # from blank bytes. Only the actual used slots are split into this cart.
    slots=[(70,'X5_NEW_46',[(0x860,0x2d0,'QW_ROUTER_MEM',0xa860)]),
           (82,'X5_NEW_52',[(0x1c64,0x360,'QW_LOADER_MEM',0xdc64)]),
           (98,'X5_NEW_62',[(0xc91,0x26b,'QP_META_MEM',0xcc91),(0x1e0b,0xa3,'QP_LOOKUP_MEM',0xde0b),(0x1eae,0x16,'QP_PUBLISH_MEM',0xdeae),(0x1ec4,0x129,'QP_RENDER_MEM',0xdec4)]),
           (34,'XG_BASS_MEM',[(0x1d9d,1,'QW_EMPTY34_MEM',0xdd9d)])]
    base=(O/'exact-parent.nes').read_bytes()
    parent=load(O/'exact-parent.nes');native_rebind=[]
    for bank,name,rs in slots:
        for off,size,_,_ in rs:assert base[16+bank*8192+off:16+bank*8192+off+size]==bytes([255])*size,(bank,off,size)
        mem,keeps=split_region(mem,name,bank,rs)
        for s in parent['segs'].values():
            if 'ooffs'not in s:continue
            physical=int(s['ooffs'],0)-16
            if physical<0 or physical//8192!=bank:continue
            off=physical%8192;size=int(s['size'],0);label=s['name'].strip('"')
            candidates=[k for a,z,k in keeps if a<=off and off+size<=z]
            assert len(candidates)==1,(label,off,size,keeps)
            pat=r'(?m)^(\s*'+label+r':\s*load=)'+name+r'(?=,)'
            segs,n=re.subn(pat,lambda m:m[1]+candidates[0],segs)
            assert n==1,(label,name)
            native_rebind.append(dict(segment=label,load=candidates[0],start=s['start'],size=s['size']))
    # Existing dense PN producer is already source-qualified in installed18de.
    needle='RECLAIMED_PARODIUS_CHR_MEM: start=$d9000,size=$27000,type=ro,fill=yes,file=%O,fillval=$00;'
    assert mem.count(needle)==1
    mem=mem.replace(needle,'ARTHUR_RESERVED_CHR_MEM:start=$d9000,size=$4000,type=ro,fill=yes,file=%O,fillval=$00;\nQW_STREAM_MEM:start=$dd000,size=$2400,type=ro,fill=yes,file=%O,fillval=$00;\nPN_REMAINDER_MEM:start=$df400,size=$20c00,type=ro,fill=yes,file=%O,fillval=$00;')
    oldmem,oldseg=(F/'wram.cfg').read_text().split('SEGMENTS {',1)
    decls=[l for l in oldmem.splitlines()if re.match(r'(?:N\d+|QH_PERSIST_MEM):',l)]
    decls += [f'QW_RAM1:start=$a000,size=$2000,type=ro,fill=yes,fillval=$ff,file="{(O/"code.bin").as_posix()}",bank=1;',f'QW_RAM2:start=$c000,size=$2000,type=ro,fill=yes,fillval=$ff,file="{(O/"data.bin").as_posix()}",bank=2;']
    mem=mem.rsplit('}',1)[0]+'\n'+'\n'.join(decls)+'\n}\n'
    state=[l for l in oldseg.splitlines()if l.startswith(('QM_','QH_PERSIST:'))]
    rows=state+['QW_ROUTER:load=QW_ROUTER_MEM,type=ro;','QW_LOADER:load=QW_LOADER_MEM,type=ro;','QW_EMPTY34:load=QW_EMPTY34_MEM,type=ro;','QP_ARENA_ART_LOOKUP:load=QP_LOOKUP_MEM,type=ro;','QP_ARENA_ART_META:load=QP_META_MEM,type=ro;','QP_ARENA_ART_PUBLISH:load=QP_PUBLISH_MEM,type=ro;','QP_ARENA_RENDER:load=QP_RENDER_MEM,type=ro;','QW_CODE:load=QW_RAM1,type=ro;','QW_DATA:load=QW_RAM2,type=ro;','QW_STREAM:load=QW_STREAM_MEM,type=ro;']
    # Canonical packed-prefix tail is a dedicated reserved physical251..255.
    line=next(l for l in mem.splitlines()if re.match(r'\s*CHR\s*:',l))
    assert 'size = $40000' in line
    mem=mem.replace(line,line.replace('size = $40000','size = $3ec00')+'\nQH_CHR_MEM:start=$3ec00,size=$1400,type=ro,fill=yes,file=%O,fillval=$00;')
    rows.append('ARENA_CHR:load=QH_CHR_MEM,type=ro;')
    save('component-preflight.json',dict(parent_exact=True,slots=slots,all_PRG_preimages_FF=True,native_continuation_rebindings=native_rebind,common_and_frontend_hooks_installed=False,legacy_CHR_declaration=line))
    body,close,suffix=segs.partition('}')
    assert close
    put('quick.cfg',mem+'SEGMENTS {'+body+'\n'+'\n'.join(rows)+'\n}'+suffix)

def build():
    run(command('main'),'component-main')
    for n in ['whole','portrait','loader','stream']:
        run([str(CA),'-g','-I',str(O/'quick'),'-I',str(O),'-I',str(R),str(O/'quick'/(n+'.s')),'-o',str(O/'quick'/(n+'.o'))],'quick-'+n)
    cmd=command('link');cmd[cmd.index('-C')+1]=str(O/'quick.cfg')
    cmd += [str(O/'quick'/(n+'.o'))for n in ['whole','portrait','loader','stream']]
    run(cmd,'component-first-link')
    b=load(O/'candidate.nes')
    sizes={s['name'].strip('"'):int(s['size'],0)for s in b['segs'].values()}
    assert sizes['QW_CODE']<=7168 and sizes['QW_DATA']<=2048
    code=(O/'code.bin').read_bytes();data=(O/'data.bin').read_bytes()
    cookie=bytes([0xa7,9,32,4])+hashlib.sha256(code[:sizes['QW_CODE']]+data[:sizes['QW_DATA']]).digest()[:12]
    (O/'quick/cookie.bin').write_bytes(cookie)
    (O/'quick/stream.bin').write_bytes(code[:7168]+data[:2048])
    for n in ['loader','stream']:
        run([str(CA),'-g','-I',str(O/'quick'),'-I',str(O),str(O/'quick'/(n+'.s')),'-o',str(O/'quick'/(n+'.o'))],'final-'+n)
    run(cmd,'component-final-link');mirror()
    prove()

def prove():
    b=load(O/'candidate.nes')
    sizes={s['name'].strip('"'):int(s['size'],0)for s in b['segs'].values()}
    cookie=(O/'quick/cookie.bin').read_bytes()
    raw=(O/'candidate.nes').read_bytes();base=(O/'exact-parent.nes').read_bytes();cs=16+128*8192
    assert raw[:10]==base[:10]and raw[10]==9 and raw[11:16]==base[11:16]
    for a,z in [(0,251),(256,884),(893,1024)]:assert raw[cs+a*1024:cs+z*1024]==base[cs+a*1024:cs+z*1024],(a,z)
    assert raw[cs+251*1024:cs+256*1024]==(O/'quick/art-source.chr').read_bytes()
    assert raw[cs+884*1024:cs+893*1024]==(O/'quick/stream.bin').read_bytes()
    def native_symbols(path):
        out={};segments={}
        rows=path.read_text().splitlines()
        for line in rows:
            if not line.startswith('seg\t'):continue
            d=dict(re.findall(r'(\w+)=("[^"\n]*"|[^,\n]+)',line))
            segments[d['id']]=d['name']
        for line in rows:
            if not line.startswith('sym\t'):continue
            d=dict(re.findall(r'(\w+)=("[^"\n]*"|[^,\n]+)',line))
            if 'val'not in d or d.get('type')not in ['lab','equ']:continue
            key=(d['name'],d.get('scope',''),d['type'],segments.get(d.get('seg'),''))
            out[key]=d['val']
        return out
    old=native_symbols(O/'exact-parent.dbg');new=native_symbols(O/'candidate.dbg')
    header_equates={'"_nes2_wramsize"','"LOCAL-MACRO_SYMBOL-002A"'}
    changed_native=[(k,v,new.get(k))for k,v in old.items()if new.get(k)!=v and k[0]not in header_equates]
    assert all(v=='0x7'and new[k]=='0x9'for k,v in old.items()if k[0]in header_equates)
    assert not changed_native,changed_native
    ranges=json.loads((O/'component-preflight.json').read_text())['slots']
    allowed=set()
    for bank,_,regions in ranges:
        for off,size,_,_ in regions:allowed.update(range(16+bank*8192+off,16+bank*8192+off+size))
    diffs=[i for i in range(16,cs)if raw[i]!=base[i]]
    assert all(i in allowed for i in diffs),[hex(i)for i in diffs if i not in allowed][:30]
    save('component-source-proof.json',dict(status='PRIVATE_OWN_COMPONENT_SOURCE_LINKED_NO_ROUTES_OR_ADMISSION',ROM_sha256=sha(O/'candidate.nes'),parent_sha256=sha(O/'exact-parent.nes'),code_bytes=sizes['QW_CODE'],data_bytes=sizes['QW_DATA'],cookie=cookie.hex(),all_native_scoped_symbols_exact_except_header=True,native_symbols_checked=len(old),header_only_8_to_32KB=True,all_other_CHR_exact=True,own_PRG_changed_bytes=len(diffs),sizes={k:v for k,v in sizes.items()if k.startswith(('QW_','QP_'))},native=False,common_hooks=False,frontend_pending=True))
    print(json.dumps(json.loads((O/'component-source-proof.json').read_text()),indent=2))

if __name__=='__main__':
    if '--prepare'in sys.argv:prepare()
    if '--components'in sys.argv:components()
    if '--build'in sys.argv:build()
    if '--proof'in sys.argv:prove()
