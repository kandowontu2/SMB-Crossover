"""Real earlyDraw/nativeworld/portrait paths plus source-record rotation oracle."""
from pathlib import Path
import hashlib,itertools,json,re,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import contra_force_shared_transport_controls_v1 as J
C,T,D=J.C,J.T,J.D
P=R/'build/contra-force-presentation-shared-cart-v3';K=R/'build/contra-force-presentation-kernel-v2'
O=R/'build/contra-force-presentation-controls-v3'
J.P=P;D.P=P;C.P=P;T.P=P;T.B=T.qualified(P/'joint/candidate.nes');T.PAYLOAD=(P/'joint/cf-stream.bin').read_bytes();T.COOKIE=(P/'joint/cf-cookie.bin').read_bytes()
L={n:int(v,16)for v,n in re.findall(r'al ([0-9A-Fa-f]+) \.(\w+)',(K/'runtime.lbl').read_text())}
body=json.loads((R/'build/contra-force-body-pack-v3/packing.json').read_text())['per_pose_source_metadata']
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def invoke(m,n,a=0x57,x=2,y=3,p=0x30,hook=None):
 if n in L and n.startswith('Cf'):
  # Isolated own workers explicitly require C2. Genuine native entrypoints
  # below get no fixture mapper changes and must use the actual A2 importer.
  m.raw_page(2,2);T.put(m,CurrentBankC=2);c=C.start(m,L[n],3,a=a,x=x,y=y,p=p)
 else:c=T.cpu(m,n,a=a,x=x,y=y,p=p,public=True)
 return T.finish(m,c,hook=hook)
def original(m):return bytes(m.ram[2][i]for i in list(range(0x7f,0x83))+[0xb1,0xc0]+list(range(0x300,0x500)))
def init(var):
 m=J.ready(var);T.put(m,SavedJoypadBits=0,InjuryTimer=0)
 c=J.shared(m,0);T.finish(m,c)
 assert m.ram[2][0x31a]==[25,75,117,159][var]
 return m
def expect(v,x,y,prefix,rotation,canary=0xad):
 out=bytearray([canary])*256;end=prefix
 if prefix+4*len(v['parts'])>220:return bytes(out),end
 for p in v['parts']:
  xx=x+p['x']-128;yy=y+p['y']-128
  if not(0<=xx<256 and 0<=yy<240):continue
  at=(end+rotation)&255;out[at:at+4]=bytes([yy,p['local_pair']*2,p['attr'],xx]);end+=4
 return bytes(out),end
def records(bases):
 rows=[]
 for v in body:
  for rotation,prefix in itertools.product([0,4,100,228],[0,204]):
   m=C.clone(bases[v['variant']]);T.put(m,CurrentOAMOffset=prefix,GuestOamRotationActive=1,RgOamRotation=rotation,Player_X_Position=120,Player_PageLoc=0,Player_Y_Position=112,Player_Y_HighPos=1,ScreenLeft_X_Pos=0,ScreenLeft_PageLoc=0)
   m[512:768]=[0xad]*256;m.ram[2][0x31a]=v['frame'];m.ram[2][0x334]=0
   before=original(m);invoke(m,'CfHostRenderBody');wanted,end=expect(v,128,128,prefix,rotation)
   assert bytes(m[512:768])==wanted and T.get(m,'CurrentOAMOffset')==end,(v['variant'],v['frame'],rotation,prefix)
   assert original(m)==before
   rows.append([v['variant'],v['frame'],rotation,prefix,end])
 return dict(source_record_rotation_cases=len(rows),all156_authenticated_descriptor_views=True,explicit_pose_field_fixture=True,whole_record_capacity_reject=True,original_actor_fields_exact=True,rows=rows)
def world(bases):
 rows=[]
 for var in range(4):
  m=C.clone(bases[var]);T.put(m,ScreenLeft_X_Pos=0,ScreenLeft_PageLoc=0,FrameCounter=0,SpriteShuffleOffset=0,RgOamUsed=0,RgOamFirst=0,RgOamRotation=0,GuestOamRotationActive=0)
  for i in range(24):m[T.address(T.B,'ObjectMetasprite')+i]=0
  for n in['Block_State','FloateyNum_Control','Misc_State']:
   for i in range(9):m[T.address(T.B,n)+i]=0
  T.put(m,Player_Y_Position=176,Player_Y_HighPos=1)
  m[T.address(T.B,'ObjectMetasprite')+1]=T.address(T.B,'METASPRITE_GOOMBA_WALKING_1')
  for n,v in dict(Enemy_Flag=1,Enemy_ID=6,Enemy_X_Position=184,Enemy_PageLoc=0,Enemy_Y_Position=176,Enemy_Y_HighPos=1,Enemy_MovingDir=1,Enemy_SprAttrib=1).items():m[T.address(T.B,n)]=v
  for age in range(3):
   invoke(m,'PlayerGfxHandler');assert T.get(m,'ObjectMetasprite')==0 and T.get(m,'SmPosePtr')+256*T.get(m,'SmPosePtr',1)==T.address(T.B,'BlankPalette')+7
   before=original(m);calls=[]
   def hook(c,step):
    if c.pc==L['CfHostDraw']and m.rawtags[1]==3:calls.append('CFearly')
    if c.pc==T.address(T.B,'DrawMetasprite')and m.rawtags[1]==0x84:calls.append(['nativeActor',c.y])
   z=invoke(m,'DrawAllMetasprites',hook=hook)
   assert calls.count('CFearly')==1 and ['nativeActor',1]in calls and ['nativeActor',0]not in calls,calls
   assert original(m)==before and T.get(m,'ObjectMetasprite')==0
   used=T.get(m,'RgOamUsed');rotation=T.get(m,'RgOamRotation');assert used>0
   v=next(v for v in body if v['variant']==var and v['frame']==m.ram[2][0x31a])
   wanted,end=expect(v,T.get(m,'Player_X_Position')+8,192,0,rotation,canary=0xf8)
   for off in range(0,end,4):
    at=(off+rotation)&255;assert bytes(m[512+at:512+at+4])==wanted[at:at+4],('actualbody/world overlap',var,age,off,at)
   assert used>=end+8,('native world actor missing allocation',var,age,end,used)
   rows.append(dict(variant=var,draw=age,rotation=rotation,body_bytes=end,used_bytes=used,calls=calls,CPU=z['CPU']))
 return dict(genuine_native_DrawAll_cases=len(rows),real_typed_early_draw_once_native_Goomba_once=True,no_late_native_player_draw=True,actual_rotated_source_body_OAM_exact=True,scope='Actual source cartridge code with manually loaded CF API and seeded native actor/world inputs; no natural Main/palette/native emulator claim.',rows=rows)
def portraits(bases):
 rows=[]
 for var,mode in itertools.product(range(4),[0,1]):
  m=C.clone(bases[var]);T.put(m,OperMode=mode,Player_Y_Position=(88 if mode else 160),Player_Y_HighPos=1,Player_X_Position=96,Player_PageLoc=0,ScreenLeft_X_Pos=0,ScreenLeft_PageLoc=0,GuestOamRotationActive=0,CurrentOAMOffset=0,RgOamRotation=0)
  before=original(m);oldY=T.get(m,'Player_Y_Position');m[512:768]=[0xad]*256
  # Genuine title/lives portrait rendering ingress, no callback redirection.
  z=invoke(m,'X5PortraitRender',a=0,x=0,y=0)
  v=next(v for v in body if v['variant']==var and v['frame']==[25,75,117,159][var]);want,end=expect(v,104,oldY+16+(56 if mode else 0),0,0)
  assert bytes(m[512:768])==want and T.get(m,'CurrentOAMOffset')==end,(var,mode,z)
  assert end>0 and T.get(m,'Player_Y_Position')==oldY and original(m)==before
  rows.append(dict(variant=var,mode=mode,parts=end//4,minY=min(want[i]for i in range(0,end,4)),maxY=max(want[i]+16 for i in range(0,end,4)),CPU=z['CPU']))
 return dict(actual_X5PortraitRender_cases=len(rows),original_idle_pose_and_nativeY_restored=True,source_body_UI_nonempty=True,rows=rows)
def main():
 assert not O.exists();O.mkdir();out=dict(passed=False,native=False,actual_natural_cold_or_Main=False,actual_PPU_palette_commit=False,checks={})
 try:
  for p,h in json.loads((P/'source-stage.json').read_text())['bindings'].items():assert sha(p)==h,p
  bases=[init(v)for v in range(4)]
  for n,f in[('records',records),('native_world',world),('native_portraits',portraits)]:out['checks'][n]=f(bases);print('CF presentation',n,'PASS',flush=True)
  out['retained_v2_negative']='V2 passed1248 source-record rotations but invoked CrossoverGraphicsBank instead of actualPlayerGfxHandler. Separate source inspection also found missing Visible9; v3 implements original native injury/death visibility and retains both old negatives.'
  out['retained_v1_negative']='V1 isolated direct renderer call omitted its declared C2 prerequisite and attempted C2alias write while actualROM D8 was mapped. V2 mapsC2 only for isolated own-worker calls; genuine nativeDrawAll/X5Portrait ingress gets NO mapper normalization. No productsourcechange.'
  out['passed']=True
 except Exception as e:out.update(failure=repr(e),traceback=traceback.format_exc());raise
 finally:
  paths=[Path(__file__),Path(J.__file__),Path(C.__file__),Path(T.__file__),P/'source-stage.json',P/'joint/candidate.nes',P/'joint/candidate.dbg',P/'joint/cf-stream.bin',P/'joint/cf-cookie.bin',K/'build-proof.json',K/'runtime.lbl',R/'build/contra-force-body-pack-v3/packing.json',R/'build/contra-force-presentation-controls-v1/controls.json',R/'build/contra-force-presentation-controls-v2/controls.json']
  out['bindings']={str(p.resolve()):sha(p)for p in paths};p=O/'controls.json';p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(path=str(p),sha256=sha(p),passed=out['passed'],failure=out.get('failure'))),flush=True)
if __name__=='__main__':main()
