"""Narrow rebound on the actual joint retirement source, no native/admission."""
from pathlib import Path
import hashlib,itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import contra_force_internal_checkpoint_controls_v2 as J
import contra_force_retire_controls_v2 as Q
T,C=J.T,J.C
P=R/'build/cf-owner-retirement-v2';O=R/'build/contra-force-owner-retirement-rebind-v1'
T.P=P;T.B=T.qualified(P/'joint/candidate.nes');T.PAYLOAD=(P/'joint/cf-stream.bin').read_bytes();T.COOKIE=(P/'joint/cf-cookie.bin').read_bytes()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def exact_code():
 old=(R/'build/contra-force-checkpoint-loader-cart-v1/joint/candidate.nes').read_bytes();new=(P/'joint/candidate.nes').read_bytes();rows=[]
 for bank,start,n in[(115,0x1f38,147),(78,0xe68,302),(69,0x1f47,154)]:
  at=16+bank*8192+start;assert old[at:at+n]==new[at:at+n];rows.append([bank,start,n])
 assert T.PAYLOAD==(R/'build/contra-force-checkpoint-loader-cart-v1/joint/cf-stream.bin').read_bytes()
 return dict(qualified_code_and_fullcookie_payload_byteexact=rows,scope='Inherited fullflag/readback/realISR proofs remain bound by exact ownbytes; actual joint caller/lifecycle coverage belongs sibling.')
def copies():
 rows=[]
 for var,(wide,mode,ctrl,reload)in enumerate([(0,0,0xa0,0),(0,0x83,0x84,1),(1,0x80,0xa4,0),(1,0x83,0x84,1)]):
  m=T.Bus();T.put(m,FmGroups=var<<3,X5WideChrActive=wide,Mirror_PPUCTRL=ctrl,ReloadCHRBank=reload);m.ppuctrl=ctrl;m[T.address(T.B,'X5ChrMode')+11]=mode
  m.chr_latches[:]=[(600+113*i)&1023 for i in range(12)];m.upper=2
  oracle=C.clone(m);c=T.cpu(oracle,'X5PublishChr',public=True);T.finish(oracle,c);expected=(oracle.chr_latches[:],oracle.upper)
  c=T.cpu(m);before=(m.rawtags[:],T.smc(m),bytes(m[3:11]),bytes(m[0x1e1:0x200]),bytes(m[0x6000:0x8000]),m.protection[:]);z=T.finish(m,c);T.exact(m,var)
  assert z['AXYP']==[0x57,0xa9,0x63,0x31]and(m.chr_latches,m.upper)==expected
  assert(m.rawtags,T.smc(m),bytes(m[3:11]),bytes(m[0x1e1:0x200]),bytes(m[0x6000:0x8000]),m.protection)==before
  assert(m.ppuctrl,m.toggle,m.scroll,T.get(m,'ReloadCHRBank'))==(ctrl,0,[73,32],reload)
  c=T.cpu(m,'CfOrBtCheck',p=0x79);T.finish(m,c);assert[c.a,c.x,c.y,c.p]==[0x57,0xa9,0x63,0x79]
  c=T.cpu(m,'CfRetire',p=0x79);T.finish(m,c);assert[c.a,c.x,c.y,c.p]==[0x57,0xa9,0x63,0x79]and m.ram[2][0x1fe0]==0
  c=T.cpu(m,'CfOrBtCheck',p=0x79);T.finish(m,c);assert not c.p&1
  rows.append(dict(variant=var,wide=wide,mode=mode,reload=reload,**z))
 return dict(actual_internal_checkpoint_full24KB_copies=4,actual_fullcookie_guard_then_retire_then_reject=4,no_RAM_preload_or_external_checkpoint=True,rows=rows)
def foreign():
 rows=[];base=T.Bus()
 for family,p,rawC in itertools.product([9,31,33],[0x30,0x31,0x79,0xf9],[2,3,0xd8]):
  m=C.clone(base);m.ram[2][0x1fe0:0x1ff0]=bytes([0xa7,family,0,1])+bytes(range(12));m.raw_page(2,rawC);T.put(m,CurrentBankC=rawC)
  c=T.cpu(m,'CfRetire',p=p);before=([bytes(x)for x in m.ram],m.rawtags[:],T.smc(m));z=T.finish(m,c)
  assert z['AXYP']==[0x57,0xa9,0x63,p]and [bytes(x)for x in m.ram]==Q.expected(before[0],family)
  assert(m.rawtags,T.smc(m))==before[1:]and not m.executed_guest
  rows.append([family,p,rawC,z['CPU']])
 return dict(actual_class_independent_foreign_cookie_API_cases=len(rows),rows=rows)
def main():
 assert not O.exists();O.mkdir();out=dict(passed=False,native=False,actual_natural_cold=False,checks={})
 try:
  for p,h in json.loads((P/'source-stage.json').read_text())['bindings'].items():assert sha(p)==h,p
  for n,f in[('exact_code',exact_code),('actual_copy_guard_retire',copies),('foreign_cookies',foreign)]:out['checks'][n]=f();print('CF jointretire rebound',n,'PASS',flush=True)
  out['passed']=True
 except Exception as e:out.update(failure=repr(e),traceback=traceback.format_exc());raise
 finally:
  paths=[Path(__file__),Path(J.__file__),Path(Q.__file__),Path(T.__file__),Path(C.__file__),P/'source-stage.json',P/'joint/candidate.nes',P/'joint/candidate.dbg',P/'joint/cf-stream.bin',P/'joint/cf-cookie.bin',R/'build/contra-force-checkpoint-loader-qualified-v1/handoff.json']
  out['bindings']={str(p.resolve()):sha(p)for p in paths};p=O/'controls.json';p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(path=str(p),sha256=sha(p),passed=out['passed'],failure=out.get('failure'))),flush=True)
if __name__=='__main__':main()
