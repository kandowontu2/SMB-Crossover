"""Freeze the same-lease internally checkpointed real source loader."""
from pathlib import Path
import hashlib,json,zipfile
R=Path(__file__).resolve().parents[2];O=R/'build/contra-force-checkpoint-loader-qualified-v1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
ROOTS=['build/contra-force-retire-qualified-v1/handoff.json',
 'build/contra-force-checkpoint-loader-cart-v1/source-stage.json',
 'build/contra-force-internal-checkpoint-controls-v2/controls.json',
 'build/contra-force-internal-checkpoint-controls-v1/controls.json',
 'build/contra-force-internal-checkpoint-isr-controls-v1/controls.json']
def main():
 assert not O.exists();O.mkdir();bound={}
 def add(p,h=None):
  p=Path(p).resolve();now=sha(p)
  if h:assert h==now,(str(p),h,now)
  if str(p)in bound:assert bound[str(p)]==now
  bound[str(p)]=now
 for root in ROOTS:
  p=R/root;add(p);d=json.loads(p.read_text())
  for q,h in d.get('bindings',{}).items():add(q,h)
 add(__file__);stage=json.loads((R/ROOTS[1]).read_text())
 for root in[ROOTS[2],ROOTS[4]]:assert json.loads((R/root).read_text())['passed']
 assert stage['candidate']=='c803098f36f236cf9ee064f0020d32dfb134810b96235d02288f1ea6cd9f892b'
 api=dict(entry='CfLoaderProposal',A_ROM=115,PC='BF38',A_bytes=147,core_entry='CfLoaderCoreProposal',C_ROM=78,core_PC='CE68',C_bytes=302,expected_cookie_PC='CF86',
  difference='Actual genuine X5PublishChr is called once INTERNALLY from stableC78 while nativeA62 ownsA, BEFORE borrowedPPU copy. It establishes the real software-to-hardware12window/upper0 checkpoint; an external call is no longer required.',
  preserved='FullAXYP except resultC, rawA/C, nativeR0..3, all33SMC inside worker, livepage1, Reload, originalCTRL/latch/scroll, all12publishedCHR windows, RAM0/protection. No5102/5103/5113 writes.',
  preconditions=['Selected31','FamilyMainCommit bit0=1','OperMode1','forcedblank MirrorPPUMASK&18=0 and DisableScreenFlag!=0','NmiDisable negative','retire prior selected owners BEFORE any destructive write','native WRAM writable'],
  copy='Actual bufferedPPUDATA2007 full24576B copy+readback; invalidateC2 thenRAM3 before firstcopy, full16cookie/class A7validity publishedLAST.',
  implementation='Equivalent two-cookie STX loop saves8B, shared R0/R2zero init saves2B, MapPageY0 reorder saves2B. Add genuine11B mapA62/JSR publisher,1B pad retainsCF86. No source kernel/payload/cookie changes.',
  cold='This worker is callable at actual forcedblank InitScreen but no native hook is installed. Menu/scene/player owner coverage and full presentation remain pending. CfRetire BFBD is present unchanged and separately qualified.')
 ap=O/'API.json';ap.write_text(json.dumps(api,indent=2)+'\n');add(ap)
 selected=[]
 for p in bound:
  p=Path(p)
  if p.is_relative_to(R)and p.suffix in['.s','.inc','.cfg','.dep','.py','.json']and any(x in p.as_posix()for x in['contra-force-checkpoint-loader','contra-force-internal-checkpoint','contra_force_checkpoint_loader','contra_force_internal_checkpoint','contra_force_loader_checkpoint']):selected.append(p)
 archive=O/'source-delta-only.zip'
 with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED)as z:
  for p in sorted(set(selected)):z.write(p,p.relative_to(R).as_posix())
 with zipfile.ZipFile(archive)as z:
  assert z.testzip()is None
  for p in selected:assert hashlib.sha256(z.read(p.relative_to(R).as_posix())).hexdigest()==sha(p)
 out=dict(passed=True,source=True,native=False,ready=False,installed=False,actual_cold_hook=False,
  candidate=stage['candidate'],previous_retired_cart=stage['previous_retired_cart'],source_stage=ROOTS[1],only302B_C_loader_span_changes=True,
  all79572_nativePCs_header_kernel_payload_cookie_and_expectedCF86_exact=True,API=api,
  controls=dict(dirty_hardware_no_external_checkpoint_copies=16,full_payload_bytes=24576,rejected_flag_cases=384,accepted_flag_edges=8,readback_faults=6,locked_WRAM_reject=True,
   actual_prefix_nativepublisher_STX_lagNMI_cuts=164,prefix_maskedIRQ_requests=141,full_transfer_lagNMI_cuts=1475,full_transfer_maskedIRQ_requests=1474,actual_unmasked_IRQ_edges=2,actual_normal_and_paused_NMI_rejections=2),
  fixture_contract='Real pending mapper STA or STX validated against actual opcode and actual source register equal to shadow; no opcode/memory/CPU normalization.',
  retained_negative='V1 observer captured rawA BEFORE directAPI entrysetup, falsely comparing originalD7 with the correct returnedA115. V2 captures actual entrycontext; source/ROM unchanged.',
  source_archive=dict(path=str(archive),sha256=sha(archive),bytes=archive.stat().st_size,members=len(set(selected)),unchanged_predecessor='build/contra-force-retire-qualified-v1/handoff.json'),
  bindings={**bound,str(archive.resolve()):sha(archive)})
 p=O/'handoff.json';p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(path=str(p),sha256=sha(p),bindings=len(out['bindings']),archive=out['source_archive'])),flush=True)
if __name__=='__main__':main()
