"""Source-only real BT/native boundary successor. Cold lifecycle still pending."""
from pathlib import Path
import hashlib,json,shutil,subprocess,sys
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
from private_build_outputs_v1 import validate
from prepare_cv3_dmc_mirror import prepare
from check_tmnt_render_oa import load,address,location
P=R/'build/battletoads-cold-acquire-v4';O=R/'build/battletoads-menu-lease-v7';J=O/'joint'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s)
def command(c,n):
    v=validate(c,J,cwd=R);z=subprocess.run(c,cwd=R,text=True,capture_output=True)
    write(O/(n+'.json'),json.dumps(dict(command=c,validated_outputs=v,returncode=z.returncode,stdout=z.stdout,stderr=z.stderr),indent=2)+'\n')
    assert z.returncode==0,(n,z.stderr)
def main():
    assert not O.exists();assert sha(P/'joint/candidate.nes')=='95f141fafffc1d58170cd09369d4e1cbaeb837e7439742f215a11d3d0829611f'
    shutil.copytree(P/'joint',J,ignore=shutil.ignore_patterns('*.o','candidate.nes','candidate.dbg','candidate.lbl','candidate.map'))
    for p in J.rglob('*'):
        if p.is_file()and p.suffix in['.s','.inc','.cfg']:
            write(p,p.read_text().replace(str(P/'joint'),str(J)).replace((P/'joint').as_posix(),J.as_posix()))
    api=(J/'bt/api.s').read_text()
    needle=' cpx #72\n bcs PaletteDone'
    assert api.count(needle)==1
    api=api.replace(needle,needle+'\n lda FmGroups\n ora #$40\n sta FmGroups')
    import re
    api,n=re.subn(r'^ jmp BtDraw\s+;3.*$',' jmp BtUnavailable    ;3 preparation never emits OAM; ROM17 owns cold draw',api,flags=re.M)
    assert n==1
    api=api.replace('.import BtInit,','.import CmHostFresh,JnResetDispatch\n.import BtSrc_Objects_AnimID,BtSrc_InputHold_P1,BtSrc_InputTap_P1\n.import BtInit,',1)
    api=api.replace('.export BtEnsure\n','.export BtFresh,BtScene,BtEnsure\n',1)
    api=api.replace(' jmp BtConstruct      ;15 ROM Fresh chain still pending',' jmp BtFresh          ;15 true native Fresh then source constructor')
    api=api.replace(' jmp BtUnavailable    ;19 ROM scene bridge pending',' jmp BtScene          ;19 true native area-reset then own motion reset')
    marker='BtEnsure:\n'
    assert api.count(marker)==1
    wrappers="""; Called only through the full-cookie typed table. Native callback output
; remains live; source bookkeeping must not replace its returned AXYP.
.macro BtSaveResult
 php
 pha
 txa
 pha
 tya
 pha
.endmacro
.macro BtRestoreResult
 pla
 tay
 pla
 tax
 pla
 plp
.endmacro
BtFresh:
 BtFar CmHostFresh,jsr
 BtSaveResult
 jsr BtConstruct
 BtRestoreResult
 rts
BtScene:
 BtFar JnResetDispatch,jsr
 BtSaveResult
 ldx CurrentPlayer
 txa
 and #1
 tax
 jsr BtGroundAtNative
 lda #0
 sta BtSrc_Objects_X_speed,x
 sta BtSrc_Objects_X_sub,x
 sta BtSrc_Objects_dir,x
 sta BtSrc_Objects_Flags,x
 sta BtSrc_Objects_AnimID,x
 sta BtSrc_InputHold_P1,x
 sta BtSrc_InputTap_P1,x
 sta BtPunchPending
 lda #1
 sta BtSrc_player1_obj_wanted_frame,x
 BtRestoreResult
 rts
BtEnsure:
"""
    api=api.replace(marker,wrappers)
    write(J/'bt/api.s',api)
    preview=(J/'bt/preview.s').read_text()
    assert preview.count(' sta SafecallA_SMC+1')==1
    preview=preview.replace(' sta SafecallA_SMC+1',' ; All three internal targets have dead incoming A; outer body saves A.')
    needle=' lda FmGroups\n and #$20'
    assert preview.count(needle)==1
    preview=preview.replace(needle,' lda FmGroups\n ora #$40\n sta FmGroups\n and #$20')
    write(J/'bt/preview.s',preview)
    menu=(J/'src/full_roster_menu.s').read_text()
    a=menu.index('.proc FmToggle');z=menu.index('.endproc',a)
    toggle=menu[a:z]
    old=""" cmp #4
 beq SelectThomas
 lda FmAlts
 and #$bb
 sta FmAlts
 jmp Yes
SelectShinobi:lda #4
 bne Flip
SelectThomas:lda #68
 bne Flip"""
    new=""" cmp #4
 bne Flip
 lda #68
 bne Flip
SelectShinobi:lda #4
 bne Flip"""
    # Indentation is two spaces in this source; use exact producer text.
    assert toggle.count(old)==1
    toggle=toggle.replace(old,new)
    assert toggle.count(' jmp Yes')==7
    toggle=toggle.replace(' jmp Yes',' sec\n rts')
    needle='NotSMB2:\n cpx #28'
    if needle not in toggle:needle='NotSMB2:\n  cpx #28'
    assert toggle.count(needle)==1
    toggle=toggle.replace(needle,"""NotSMB2:
  cpx #23
  bne NotBattletoads
  lda FmGroups
  eor #$20
  sta FmGroups
  sec
  rts
NotBattletoads:
  cpx #28""")
    old=' adc #8\n and #31'
    assert toggle.count(old)==1
    toggle=toggle.replace(old,'  adc #8\n  eor FmGroups\n  and #24\n  eor FmGroups')
    toggle=toggle.replace('.res 2,$ea','.res 0,$ea')
    menu=menu[:a]+toggle+menu[z:]
    a=menu.index('.proc FmStartFlags');z=menu.index('.endproc',a)
    menu=menu[:a]+'.proc FmStartFlags\n farcall FmStartRetireFlags,jmp\n .res 10,$ea\n'+menu[z:]
    write(J/'src/full_roster_menu.s',menu)
    cf=(J/'src/cf_menu_body.inc').read_text()
    old=""" lda FmGroups
 bpl Done
 and #$7f
 sta FmGroups"""
    assert cf.count(old)==1
    new=""" ; Retire only a valid tagged BT cache; foreign cache families are untouched.
 farcall BtRetire
 lda FmGroups
 and #$c0
 beq Done
 lda FmGroups
 and #$3f
 sta FmGroups"""
    cf='.import BtRetire\n'+cf.replace(old,new)
    cf=cf.replace('; Only bit7 is the temporary menu P1 lease marker. Existing WWF/CF bits0..4','; Bit6 is the temporary BT P1 lease; bit7 remains the CF P1 lease. WWF/CF bits0..4')
    router=(R/'build/bowser-functional-host-v9/joint/bowser/router.s').read_text()
    masks=router.split('BwStartFlags:\n',1)[1].split('.assert',1)[0]
    assert masks.startswith(' php\n')
    masks=masks[len(' php\n'):]
    wrapper="""; Start retires P1/cache before any family mask can discard its marker.
; One saved P remains through the near mask tail; its final PLP restores it.
.proc FmStartRetireFlags
 php
 txa
 pha
 tya
 pha
 jsr FmCfRestoreP1
 pla
 tay
 pla
 tax
"""+masks+'.endproc\n'
    cf=cf.replace('FmCfHelperEnd:',wrapper+'FmCfHelperEnd:')
    write(J/'src/cf_menu_body.inc',cf)
    constants=(R/'inc/constants.inc').read_text().splitlines()
    names=['Sfx_PowerUpGrab','Sfx_PipeDown_Injury','Goomba','Bowser']
    selected=[l for l in constants if any(l.startswith(n+' ')for n in names)]
    assert len(selected)==4
    write(J/'bt/native-constants.inc','\n'.join(selected)+'\n')
    cc=R/'tools/Windows/cc65/bin'
    p=J/'entrypoint.s'
    main=json.loads((P/'main-build.json').read_text())['command'][:]
    main[-1]=str(J/'entrypoint.s');main[main.index('-o')+1]=str(J/'bt-main.o')
    main[1:1]=['-I',str(J),'-I',str(J/'src')]
    for flag in ['--create-dep','--create-full-dep','-l','--listing']:
        if flag in main:main[main.index(flag)+1]=str(J/Path(main[main.index(flag)+1]).name)
    command(main,'main-build')
    def assemble(n):command([str(cc/'ca65.exe'),'-g','-D','MAPPER_MMC5=1','-I',str(R),'-o',str(J/'bt'/f'{n}.o'),str(J/'bt'/f'{n}.s')],n+'-build')
    for n in['api','core','art','loader','router','preview','stream']:assemble(n)
    link=json.loads((P/'final-link.json').read_text())['command'][:]
    for flag in['-o','-Ln','-C','-m','--dbgfile','--mapfile']:
        if flag in link:link[link.index(flag)+1]=str(J/Path(link[link.index(flag)+1]).name)
    if '--ld-args'in link:
        k=link.index('--ld-args')+1;v=link[k].split(',')
        for i in range(1,len(v),2):v[i]=str(J/Path(v[i]).name)
        link[k]=','.join(v)
    oldmain=str(P/'joint/bt-main.o');assert link.count(oldmain)==1;link[link.index(oldmain)]=str(J/'bt-main.o')
    for n in['api','core','art','loader','router','preview','stream']:
        hit=[i for i,p in enumerate(link)if p.endswith('/bt/'+n+'.o')or p.endswith('\\bt\\'+n+'.o')]
        assert len(hit)==1,(n,hit);link[hit[0]]=str(J/'bt'/f'{n}.o')
    command(link,'initial-link')
    cache=(J/'bt/cache.bin').read_bytes();assert len(cache)==8192 and cache[0x1fe0:0x1ff0]==bytes(16)
    cookie=bytes([0xa7,33,1,117])+hashlib.sha256(cache).digest()[:12]
    (J/'bt/cookie.bin').write_bytes(cookie);(J/'bt/stream.bin').write_bytes(cache)
    assemble('loader');assemble('stream');command(link,'final-link');prepare(R,J/'candidate.nes')
    old,new=[load(x/'joint/candidate.nes')for x in[P,O]]
    diff=[i for i,(a,b)in enumerate(zip(old['raw'],new['raw']))if a!=b]
    spans=[(16+93*8192+0xdc0,16+93*8192+0xfa7),(16+72*8192+0x1011,16+72*8192+0x1100),(16+29*8192+0x149b,16+29*8192+0x162b),(location(old,'FmToggle'),location(old,'FmToggle')+278),(location(old,'FmStartFlags'),location(old,'FmStartFlags')+28),(16+0x100000+919*1024,16+0x100000+927*1024)]
    assert all(any(a<=i<b for a,b in spans)for i in diff)
    for n in['BtServiceVeneers','BtCheck','BtLoad','BtRetire','BtState','BtHostState','BtCacheServices','BtInit','BtPoseIds']:
        assert address(old,n)==address(new,n)
    q=dict(status='PRIVATE_BT_MENU_LEASE_SOURCE_PENDING_FINAL_COHORT_INTEGRATION',native=False,ready=False,
        candidate=sha(J/'candidate.nes'),parent=sha(P/'joint/candidate.nes'),changed_bytes=len(diff),
        header_current64_readiness_all_art_and_non_owned_bytes_exact=True,
        source_core_code_bytes=2864,source_state_bytes=117,new_global_RAM0_bytes=0,
        host_code_end=address(new,'BtUnavailable')+2,host_code_limit=0xbee0,
        menu_P1_lease_bit=64,menu_helper_bytes=address(new,'FmCfHelperEnd')-address(new,'FmCfHelperStart'),
        implemented=['Menu-only BT P1 lease retires via genuine cache tag and native P1 source before Start masks','Donor integrator native import/export once','Original source fractional X/jump/gravity','Native real head/side tile probes','Native big-body contact rectangle','Exact source P0/P1 queue without universal writes','Native kernel/sourcepose geometry','Original player-punch profile18 health math','Original food+8/cap2F','Native Star/1up genuine consumer','One authentic E2 event to native actor immunity/defeat/Bowser/score path'],
        pending=['Natural ROM Fresh/Reset/cold acquisition chain','Actual mixed-table cold portrait/name/status publication','Native firstlook/route'],
        scope='Actual private cache boundary source; no readiness/Main/cold/native qualification from this link',
        bindings={str(p.resolve()):sha(p)for p in[Path(__file__),R/'build/bowser-functional-host-v9/handoff.json',P/'loader-controls.json',J/'candidate.nes',J/'candidate.dbg',J/'candidate.lbl',J/'private.cfg',J/'bt/api.s',J/'bt/cache.bin',J/'bt/cookie.bin',J/'bt/stream.bin']})
    write(O/'source-stage.json',json.dumps(q,indent=2)+'\n');print(json.dumps({k:v for k,v in q.items()if k!='bindings'}))
if __name__=='__main__':main()
