"""Actual CF internal native checkpoint, dirty hardware, full copy/flag/faults."""
from pathlib import Path
import hashlib,itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import contra_force_external_guard_controls_v2 as D
T,C=D.T,D.C
P=R/'build/contra-force-checkpoint-loader-cart-v1';O=R/'build/contra-force-internal-checkpoint-controls-v2'
T.P=P;T.B=T.qualified(P/'joint/candidate.nes');T.PAYLOAD=(P/'joint/cf-stream.bin').read_bytes();T.COOKIE=(P/'joint/cf-cookie.bin').read_bytes()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def transfers():
 rows=[]
 for var,(wide,mode,ctrl,reload)in itertools.product(range(4),[(0,0,0xa0,0),(0,0x83,0x84,1),(1,0x80,0xa4,0),(1,0x83,0x84,1)]):
  m=T.Bus();T.put(m,FmGroups=var<<3,X5WideChrActive=wide,Mirror_PPUCTRL=ctrl,ReloadCHRBank=reload)
  m.ppuctrl=ctrl;m[T.address(T.B,'X5ChrMode')+11]=mode
  m.chr_latches[:]=[(i*113+600)&1023 for i in range(12)];m.upper=2
  oracle=C.clone(m);q=T.cpu(oracle,'X5PublishChr',public=True);T.finish(oracle,q)
  wanted=(oracle.chr_latches[:],oracle.upper)
  c=T.cpu(m)
  before=dict(RAM0=bytes(m[0x6000:0x8000]),protect=m.protection[:],raw=m.rawtags[:],scratch=bytes(m[3:11]),stack=bytes(m[0x1e1:0x200]),smc=T.smc(m))
  calls=[]
  def hook(cpu,step):
   if cpu.pc==T.address(T.B,'X5PublishChr'):calls.append([m.rawtags[1],m.rawtags[2],step])
  z=T.finish(m,c,hook=hook);T.exact(m,var)
  assert calls and len(calls)==1 and calls[0][:2]==[0xbe,0xce],calls
  assert(m.chr_latches,m.upper)==wanted
  assert(m.rawtags,m.ppuctrl,m.toggle,m.scroll)==(before['raw'],ctrl,0,[73,32])
  assert(bytes(m[0x6000:0x8000]),m.protection,bytes(m[3:11]),bytes(m[0x1e1:0x200]),T.smc(m))==(before['RAM0'],before['protect'],before['scratch'],before['stack'],before['smc'])
  assert z['AXYP']==[0x57,0xa9,0x63,0x31]and T.get(m,'ReloadCHRBank')==reload
  rows.append(dict(variant=var,wide=wide,last_mode=mode,control=ctrl,reload=reload,native_X5PublishChr_calls=calls,**z))
 return dict(dirty_hardware_full24KB_transfers=len(rows),no_external_checkpoint=True,actual_native12window_upper0_oracle_exact=True,originalAXYP_maps_R0to7_SMC_page1_RAM0_and_protection_preserved=True,rows=rows)
def main():
 assert not O.exists();O.mkdir();out=dict(passed=False,native=False,actual_cold_hook=False,checks={})
 try:
  for p,h in json.loads((P/'source-stage.json').read_text())['bindings'].items():assert sha(p)==h,p
  for n,f in[('dirty_transfers',transfers),('flags',T.flags_and_rejections),('faults',T.failures)]:out['checks'][n]=f();print('CF internal checkpoint',n,'PASS',flush=True)
  out['retained_v1_negative']='V1 captured rawA before directAPI setup maps its entryROM115, then compared against after-return rawA115. V2 captures context after actual directcall setup, as the frozen fullflag controls do. ROM/source unchanged.'
  out['passed']=True
 except Exception as e:out.update(failure=repr(e),traceback=traceback.format_exc());raise
 finally:
  paths=[Path(__file__),Path(T.__file__),Path(C.__file__),P/'source-stage.json',P/'joint/candidate.nes',P/'joint/candidate.dbg',P/'joint/cf-stream.bin',P/'joint/cf-cookie.bin',P/'joint/cf-loader.s',R/'tools/reference/contra_force_loader_checkpoint_v1.s',R/'build/contra-force-internal-checkpoint-controls-v1/controls.json']
  out['bindings']={str(p.resolve()):sha(p)for p in paths};p=O/'controls.json';p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(path=str(p),sha256=sha(p),passed=out['passed'],failure=out.get('failure'))),flush=True)
if __name__=='__main__':main()
