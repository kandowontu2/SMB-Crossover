"""True loaded row15/19 preserve actual native callback output and ownership."""
from pathlib import Path
import itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import battletoads_native_adapter_controls_v1 as T
H=T.H;L=T.L;address=T.address
O=R/'build/battletoads-menu-lease-v7';J=O/'joint'

def main():
    out=O/'lifecycle-controls.json';assert not out.exists();q=dict(passed=False,native=False,rows=[])
    try:
        b=H.C.qualified(J/'candidate.nes');seed=L.make(b);L.call(seed,'BtAcquire')
        exclusions=set(range(0x15a,0x17b))|{address(b,'CurrentBank'),address(b,'CurrentBankC')}
        def app(m):return[(a,v)for a,v in m.writes if(a<256 or 0x200<=a<0x5100 or 0x5200<=a<0x8000)and a not in exclusions]
        for player,variant,slot,native,f in itertools.product(range(2),range(2),[15,19],['one'],range(64)):
            fn='CmHostFresh'if slot==15 else'JnResetDispatch'
            m=L.fork(seed);H.put(m,CurrentPlayer=player,FmGroups=variant<<5,Player_X_Position=120,Player_Y_Position=160,Player_Y_HighPos=1)
            for name,value in [('BtSrc_Objects_Life',19),('BtSrc_FrameCounter',73),('BtSrc_Objects_AnimID',2),
                ('BtSrc_Objects_X_speed',128),('BtSrc_Objects_X_sub',77),('BtSrc_Objects_Flags',64),
                ('BtSrc_Objects_Zpos_L',8),('BtSrc_InputHold_P1',64),('BtSrc_InputTap_P1',64),('BtPunchPending',1)]:
                T.put(m,name,value,0 if name in['BtSrc_FrameCounter','BtPunchPending']else player)
            ref=L.fork(m);before=[bytes(x)for x in m.ram[:3]];live=bytes(m[0x1e1:0x200])
            m.writes.clear();ref.writes.clear();m.ram_writes.clear();ref.ram_writes.clear()
            c,_=L.call(ref,fn,a=173,x=91,y=37,p=L.flags(f));hits=[]
            cpu=H.start(m,'BtServiceVeneers',a=173,x=91,y=37,p=L.flags(f));pc=address(b,'BtServiceVeneers')+slot*3
            m[address(b,'FarcallJmpTarget_SMC')+1]=pc&255;m[address(b,'FarcallJmpTarget_SMC')+2]=pc>>8
            def observe(mm,cpu,step):
                if cpu.pc==address(b,fn)and mm.rawtags[1]==((L.location(b,fn)-16)//8192)|128:hits.append(cpu.pc)
            z,low=H.finish(m,cpu,observe)
            assert len(hits)==1 and(c.a,c.x,c.y,c.p,c.sp)==(z.a,z.x,z.y,z.p,z.sp)
            assert[bytes(x)for x in m.ram[:3]]==before and bytes(m[0x1e1:0x200])==live
            assert app(ref)==app(m),('native ordered writes',player,variant,slot,f)
            assert H.get(m,'CurrentBank')==m.rawtags[1]and H.get(m,'CurrentBankC')==m.rawtags[2]
            if slot==15:
                assert T.get(m,'BtSrc_Objects_Life',player)==47 and T.get(m,'BtSrc_FrameCounter')==0
                assert T.get(m,'BtHostReady')==1
                assert m.ram_writes[-1]==(3,address(b,'BtHostReady')&8191,1)
            else:
                assert T.get(m,'BtSrc_Objects_Life',player)==19 and T.get(m,'BtSrc_FrameCounter')==73
                for name in['BtSrc_Objects_AnimID','BtSrc_Objects_X_speed','BtSrc_Objects_X_sub','BtSrc_Objects_Zpos_L','BtSrc_InputHold_P1','BtSrc_InputTap_P1']:
                    assert T.get(m,name,player)==0,(slot,name,T.get(m,name,player))
            assert T.get(m,'BtPunchPending')==0,('old-area E2 must not hit a new-area enemy',player,variant,slot,f)
            q['rows'].append(dict(player=player,variant=variant,slot=slot,flags=f,native_callback=fn,native_once=True,
                actual_return_AXYP_SP_exact=True,original_clock_ticks=0,minimum_SP=low,CPU=z.processorCycles))
        q.update(passed=True,pairs=len(q['rows']),scope='Actual cookie-guarded loaded row15/19 against actual native callback, source Fresh and current-player area reset. Cold-invalid resolver fallback and natural parser still require shared composition.')
    except Exception as e:q.update(error=repr(e),traceback=traceback.format_exc())
    q['bindings']={str(p.resolve()):L.sha(p)for p in[Path(__file__),Path(T.__file__),Path(L.__file__),O/'source-stage.json',J/'candidate.nes',J/'candidate.dbg',J/'bt/api.s',J/'bt/cache.bin',J/'bt/cookie.bin']}
    out.write_text(json.dumps(q,indent=2)+'\n');print(json.dumps({k:v for k,v in q.items()if k not in['rows','bindings','traceback']}));assert q['passed'],q.get('error')
if __name__=='__main__':main()
