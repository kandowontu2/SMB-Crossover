"""Current64 real menu routes plus BT/CF lease and Start-mask caller controls."""
from pathlib import Path
import itertools,json,re,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import benj_all_menu_controls_1030_v1 as B
import battletoads_current_loader_controls_v1 as L
H=L.H;address=L.address
P=R/'build/battletoads-cold-acquire-v4/joint';J=R/'build/battletoads-menu-lease-v3/joint';O=J.parent

def main():
    out=O/'menu-controls.json';assert not out.exists();q=dict(passed=False,native=False,checks={});ck=q['checks']
    try:
        old,new=B.collect(P,True),B.collect(J,True)
        assert old==new and len(new)==83 and sum(not r['pending']for r in new.values())==64
        ck['actual_all83_profiles']=dict(previous64ready_preserved=True,all_names_identity_Start_A_664boundaries_exact=True,rows=list(new.values()))
        bs=[H.C.qualified(p/'candidate.nes')for p in[P,J]];seeds=[L.make(b,OperMode=0,FmGroups=0)for b in bs]
        toggles=0
        # All live flags for every actual slot, then exhaustive byte domains
        # at the three rewritten Select predicates.
        cases=list(itertools.product(range(32),[255],[255],range(64)))
        cases +=[(slot,g,a,f)for slot in[23,30]for g in range(256)for a in[0,255]for f in[0,63]]
        cases +=[(10,g,a,f)for g in[0,255]for a in range(256)for f in[0,63]]
        for slot,groups,alts,f in cases:
            pair=[]
            for seed in seeds:
                m=L.fork(seed);H.put(m,CrossoverMenuIndex=slot,CrossoverMenuPressed=32,FmGroups=groups,FmAlts=alts,RlVariant=0,VRAM_Buffer1_Offset=0)
                c,_=L.call(m,'FmToggle',p=L.flags(f));pair.append((m,c))
            a,c=pair[0];m,z=pair[1]
            assert H.get(a,'FmAlts')==H.get(m,'FmAlts')
            if slot==23:
                assert H.get(m,'FmGroups')==groups^32 and z.p&1
            elif slot==30:
                assert H.get(m,'FmGroups')==(groups&231)|((groups+8)&24) and z.p&1
                assert H.get(m,'FmGroups')&224==groups&224
            else:
                assert H.get(a,'FmGroups')==H.get(m,'FmGroups')
                assert(c.a,c.x,c.y,c.p,c.sp)==(z.a,z.x,z.y,z.p,z.sp)
            toggles+=1
        ck['typed_Select']=dict(pairs=toggles,CF_and_BT_preserve_all_high_markers=True,Shinobi_256Alts_allflags_subset_exact=True,
            CF_changed_A_NZ_caller_dead='Actual CrossoverMenuInput consumes only returned C then overwrites A with CrossoverMenuIndex; all83 real paths above pass.')
        starts=0
        for slot,bits in itertools.product(range(32),range(256)):
            m=L.fork(seeds[1]);H.put(m,FmAlts=bits,FmGroups=bits,VRAM_Buffer1_Offset=0)
            c,_=L.call(m,'FmStartFlags',x=slot,a=85,y=99,p=249)
            assert(c.a,c.x,c.y,c.p,c.sp)==(0,slot,99,(249&125)|2,224)
            assert H.get(m,'FmAlts')==bits&{9:32,26:8,31:128}.get(slot,0)
            assert H.get(m,'FmGroups')==bits&{23:32,30:24}.get(slot,0);starts+=1
        for slot,f in itertools.product(range(32),range(64)):
            m=L.fork(seeds[1]);H.put(m,FmAlts=255,FmGroups=255,VRAM_Buffer1_Offset=0)
            p=L.flags(f);c,_=L.call(m,'FmStartFlags',x=slot,a=173,y=99,p=p)
            assert(c.a,c.x,c.y,c.p,c.sp)==(0,slot,99,(p&125)|2,224);starts+=1
        ck['Start_masks']=dict(actual_rows=starts,all32slots_all256bits=True,all32slots_all64flags=True,AXYP_SP_actual_caller_contract_exact=True,
            Alts={'9':'20','26':'08','31':'80'},Groups={'23':'20','30':'18'},retire_before_mask=True)
        retirement=[]
        for bits,family in itertools.product([0,32,64,128,192,255],[0,9,22,27,32,33]):
            m=L.fork(seeds[1]);H.put(m,FmGroups=bits,VRAM_Buffer1_Offset=0)
            m.ram[3][0x1fe0]=167;m.ram[3][0x1fe1]=family;before=[bytes(x)for x in m.ram]
            L.call(m,'FmCfRestoreP1')
            assert m.ram[3][0x1fe0]==(0 if family==33 else 167)
            assert[bytes(x)for x in m.ram[:3]]==before[:3]
            expected=bytearray(before[3]);expected[0x1fe0]=0 if family==33 else 167;assert m.ram[3]==expected
            assert H.get(m,'FmGroups')==bits&63
            at=address(m.bundle,'VRAM_Buffer1');queued=bytes(m[at:at+7])
            if bits&192:
                shades=bytes(m[ address(m.bundle,'GroundPaletteData')+24:address(m.bundle,'GroundPaletteData')+27])
                assert queued==bytes([63,21,3])+shades+bytes([0])
                assert H.get(m,'VRAM_Buffer1_Offset')==6
            else:assert H.get(m,'VRAM_Buffer1_Offset')==0
            retirement.append(dict(bits=bits,family=family,retired=family==33,queued_native_P1=bool(bits&192)))
        ck['retirement']=dict(rows=retirement,valid_BT_retired_even_if_title_already_cleared_marker=True,all_foreign_cache_families_exact=True,
            original_CF_data_and_actual_body_producer_unchanged=True)
        # Exact copied source audit, including numeric consumers, not a symbol
        # count alone. Generic constructors clear these menu bytes after Start;
        # source title entry retains its already-authorized complete clear.
        refs=[]
        for p in sorted(J.rglob('*')):
            if p.suffix not in['.s','.inc']:continue
            for i,line in enumerate(p.read_text(errors='replace').splitlines(),1):
                if re.search(r'\bFmGroups\b|\$5fe8\b|\b24552\b',line,re.I):refs.append(dict(path=str(p),sha256=L.sha(p),line=i,text=line.strip()))
        ck['source_consumers']=dict(references=refs,bit5_variant_only=True,bit6_temporary_BT_P1=True,bit7_temporary_CF_P1=True,
            CF_toggle_preserves_E0=True,WWF_preserves_F8=True,Start_retires_before_masks=True,
            complete_title_clear_unchanged=True,no_new_address_or_global_RAM=True,helper_bytes=address(bs[1],'FmCfHelperEnd')-address(bs[1],'FmCfHelperStart'))
        q['passed']=True
    except Exception as e:q.update(error=repr(e),traceback=traceback.format_exc())
    q['bindings']={str(p.resolve()):L.sha(p)for p in[Path(__file__),Path(B.__file__),Path(L.__file__),O/'source-stage.json',J/'candidate.nes',J/'candidate.dbg',
        J/'src/full_roster_menu.s',J/'src/cf_menu_body.inc',J/'bt/preview.s',J/'bt/api.s',P/'candidate.nes',P/'candidate.dbg']}
    out.write_text(json.dumps(q,indent=2)+'\n');print(json.dumps(dict(passed=q['passed'],checks=list(ck),error=q.get('error'),traceback=q.get('traceback'))));assert q['passed'],q.get('error')
if __name__=='__main__':main()
