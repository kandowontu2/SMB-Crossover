"""Freeze the granted36B retirement successor, preserving its exact negatives."""
from pathlib import Path
import hashlib,json,zipfile
R=Path(__file__).resolve().parents[2];O=R/'build/contra-force-retire-qualified-v1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
ROOTS=['build/contra-force-guarded-runtime-qualified-v1/handoff.json','build/contra-force-retired-cart-v1/source-stage.json',
 'build/contra-force-retire-controls-v2/controls.json','build/contra-force-retire-controls-v1/controls.json',
 'build/contra-force-retire-proposal-v2/proposal.json','build/contra-force-retire-proposal-v1/negative.json',
 'docs/qa/checkpoints/2026-10-31/contra-force-retire-resources/root-review-and-reservations.json']
def main():
 assert not O.exists();O.mkdir();bound={}
 def add(p,h=None):
  p=Path(p).resolve();now=sha(p)
  if h:assert now==h,(str(p),h,now)
  if str(p)in bound:assert bound[str(p)]==now
  bound[str(p)]=now
 for root in ROOTS:
  p=R/root;add(p);d=json.loads(p.read_text())
  for q,h in d.get('bindings',{}).items():add(q,h)
 add(__file__)
 stage=json.loads((R/ROOTS[1]).read_text());check=json.loads((R/ROOTS[2]).read_text())
 assert stage['candidate']=='812cfe9c5b0353e429dddc4ddc4750c615a196f55d182ba7f8d7689905b8c4dc'
 assert stage['changed_from_guarded']==36 and check['passed']
 api=dict(entry='CfRetire',actual_A_ROM=69,PC='BFBD',end_exclusive='BFE1',bytes=36,
  caller='FullAXYP unchanged, including C; X/Y untouched. Real SFC still performs its own two documented immediate writes and N/Z reload of returned A.',
  maps='Original rawC+shadow restored, rawA unchanged inside worker, original SFC frame and live page1 preserved; direct worker and ISR all33SMC exact.',
  effect='Only C2DFE0 is zeroed when C2DFE1==31, including stale/malformed CF. Foreign families stay byteexact. No guest opcode/PPU/protection/globalRAM writes.',
  ordering='Call BEFORE any foreign A1/C2/RAM3 destructive write and before future owner readiness publication, irrespective of SelectedCharacter or class.',
  lifecycle='Worker qualified only. Actual joint Menu/scene/global/alternate-player/load call coverage remains uninstalled and must be independently proved.')
 ap=O/'API.json';ap.write_text(json.dumps(api,indent=2)+'\n');add(ap)
 # Delta archive only; complete unchanged producer lineage is in the frozen
 # predecessor source-only.zip. Do not duplicate that archive here.
 delta=[]
 for p in bound:
  q=Path(p)
  if not q.is_relative_to(R):continue
  rel=q.relative_to(R).as_posix()
  if q.suffix not in['.s','.inc','.cfg','.py','.dep','.json','.txt']:continue
  if any(s in rel for s in['contra-force-retired-cart-v1','contra-force-retire-','contra_force_retire','prepare_contra_force_retired','freeze_contra_force_retire']):delta.append(q)
 delta=sorted(set(delta));zp=O/'source-delta-only.zip'
 with zipfile.ZipFile(zp,'x',compression=zipfile.ZIP_DEFLATED)as z:
  for p in delta:z.write(p,p.relative_to(R).as_posix())
 with zipfile.ZipFile(zp)as z:
  assert z.testzip()is None
  for p in delta:assert hashlib.sha256(z.read(p.relative_to(R).as_posix())).hexdigest()==sha(p)
 out=dict(passed=True,source=True,native=False,ready=False,installed=False,actual_lifecycle_hooks=False,
  candidate=stage['candidate'],parent_guarded=stage['previous_guarded_cart'],source_stage=ROOTS[1],
  all_preexisting_PCs_exact=79572,only36B_new_code=True,unchanged_payload_sha256=stage['payload_sha256'],API=api,
  controls=dict(direct_fullflag_foreign_cookie_cases=3456,actualSFC_flags=64,stale_replacement_guard_rejections=20,real_normal_lag_paused_NMI_IRQ_cuts=496),
  retained_negatives=['Unlinked V1 manual40B assertion failed; actual emitted V2 is36B.',
   'V1 publicSFC fixture incorrectly required untouched NextBank/SafereturnA immediates. Genuine src/mmc5.s stores them. V2 explicitly checks those2 exact native bytes; direct worker and allISR retain all33SMC. No product change.'],
  source_archive=dict(path=str(zp),sha256=sha(zp),bytes=zp.stat().st_size,members=len(delta),predecessor='build/contra-force-guarded-runtime-qualified-v1/source-only.zip'),
  bindings={**bound,str(zp.resolve()):sha(zp)})
 p=O/'handoff.json';p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(path=str(p),sha256=sha(p),bindings=len(out['bindings']),archive=out['source_archive'])),flush=True)
if __name__=='__main__':main()
