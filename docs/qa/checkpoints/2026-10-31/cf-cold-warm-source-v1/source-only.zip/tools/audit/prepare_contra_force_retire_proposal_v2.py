"""Assemble only: measure a ROM retirement proposal, no cart/lease adoption."""
from pathlib import Path
import hashlib,json,subprocess,sys,re
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
from private_build_outputs_v1 import validate
from prepare_ff_current_component_v2 import qualified
from check_tmnt_render_oa import address,location
O=R/'build/contra-force-retire-proposal-v2'
P=R/'build/contra-force-guarded-cart-v2'
N=R/'build/bowser-playable-jump-v1'
S=R/'tools/reference/contra_force_retire_proposal_v2.s'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 assert not O.exists();O.mkdir()
 a=json.loads((P/'source-stage.json').read_text());b=json.loads((N/'handoff.json').read_text())
 for d in[a,b]:
  for p,h in d['bindings'].items():assert sha(p)==h,p
 ca=R/'tools/Windows/cc65/bin/ca65.exe';od=ca.with_name('od65.exe')
 cmd=[str(ca),'--cpu','6502x','-g','--create-full-dep',str(O/'retire.dep'),'-o',str(O/'retire.o'),str(S)]
 guard=validate(cmd,O,cwd=R);z=subprocess.run(cmd,cwd=R,capture_output=True,text=True)
 assert z.returncode==0,(z.stdout,z.stderr)
 q=subprocess.run([str(od),'--dump-segments',str(O/'retire.o')],cwd=R,capture_output=True,text=True);assert q.returncode==0
 assert re.search(r'Name:\s+"CF_RETIRE_PROPOSAL"[\s\S]*?Size:\s+36\b',q.stdout),q.stdout
 (O/'object-segments.txt').write_text(q.stdout)
 worlds=[]
 for path in[P/'joint/candidate.nes',N/'joint/candidate.nes',R/'build/peach-palette-fix-1030-v1/joint/candidate.nes']:
  raw=path.read_bytes();base=16+69*8192;pre=raw[base+0x1fbd:base+0x2000]
  assert pre==bytes([255])*67
  worlds.append(dict(path=str(path),sha256=sha(path),unallocated_tail_preimage=pre.hex(),tail_bytes=67))
 cart=qualified(P/'joint/candidate.nes')
 assert address(cart,'CfExternalGuardEnd')==0xbfbd and(location(cart,'CfOrBtCheck')-16)//8192==69
 # Current genuine shadow is imported by the real source, not a new alias.
 native=dict(symbol='CurrentBankC',PC=address(cart,'CurrentBankC'))
 out=dict(passed=True,source=True,measurement_only=True,allocated=False,cart_linked=False,native=False,
  proposed=dict(physical_ROM=69,first_PC='BFBD',end_PC_exclusive='BFE1',bytes=36,remaining_unallocated_tail=31),
  ABI='Full AXYP/SP/live caller stack and all33SMC unchanged; rawC restored. Only a family31 C2 cookie validity byte is cleared, including stale/malformed CF; alreadyforeign family cookie/state untouched. No guest opcode. Hardware5116 mapping writes are intentional.',
  eligibility='May be called independently of SelectedCharacter/class, BEFORE selected publication or any foreign A1/C2/RAM3 overwrite. No full-cookie requirement: clearing invalid/stale family31 cannot confer authority.',
  coverage_gap='Existence does not prove every foreign replacement calls it. Shared owner must compose MenuResolve/scene/global/alternating-player/load paths and test real ordering. No adoption here.',
  native_import=native,current_preimages=worlds,
  command=dict(argv=cmd,output_guard=guard,returncode=z.returncode,stdout=z.stdout,stderr=z.stderr),
  bindings={str(p.resolve()):sha(p)for p in[Path(__file__),S,ca,od,R/'tools/audit/private_build_outputs_v1.py',P/'source-stage.json',N/'handoff.json',O/'retire.o',O/'retire.dep',O/'object-segments.txt',*[Path(w['path'])for w in worlds]]})
 p=O/'proposal.json';p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(path=str(p),sha256=sha(p),bytes=36)))
if __name__=='__main__':main()
