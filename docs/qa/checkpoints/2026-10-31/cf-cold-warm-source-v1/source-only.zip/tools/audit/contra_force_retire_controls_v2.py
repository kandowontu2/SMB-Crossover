"""Real source-cart retirement API + stale-guest rejection + real vectors."""
from pathlib import Path
import hashlib,itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import contra_force_external_guard_controls_v2 as D
import contra_force_loader_isr_controls_v2 as U
C,T=D.C,D.T
P=R/'build/contra-force-retired-cart-v1';O=R/'build/contra-force-retire-controls-v2'
D.P=P;C.P=P;T.P=P;T.B=T.qualified(P/'joint/candidate.nes');U.B=T.B
T.PAYLOAD=(P/'joint/cf-stream.bin').read_bytes();T.COOKIE=(P/'joint/cf-cookie.bin').read_bytes()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def call(m,a=0x57,p=0x30,x=0xa9,y=0x63,public=False):
 if public:return C.start(m,T.address(T.B,'CfRetire'),0xc5,a=a,p=p,x=x,y=y)
 return T.cpu(m,'CfRetire',a=a,p=p,x=x,y=y)
def expected(base,family):
 v=[bytearray(x)for x in base]
 if family==31:v[2][0x1fe0]=0
 return [bytes(x)for x in v]
def flags():
 rows=[];base=T.Bus()
 for family,valid,p,rawC in itertools.product([0,9,31,32,33,255],[0,0x7f,0xa7],[v for v in range(256)if v&0x30==0x30],[2,3,0xd8]):
  m=C.clone(base);m.ram[2][0x1fe0:0x1ff0]=bytes([valid,family,3,1])+bytes(range(12))
  T.put(m,SelectedCharacter=(family+p)&255);m.raw_page(2,rawC);T.put(m,CurrentBankC=rawC)
  a=(family+p+rawC)&255;c=call(m,a=a,p=p)
  before=([bytes(x)for x in m.ram],m.rawtags[:],T.smc(m),bytes(m[0x1e1:0x200]),bytes(m[3:11]))
  z=T.finish(m,c)
  assert z['AXYP']==[a,0xa9,0x63,p],('fullAXYP',family,valid,p,rawC,z)
  assert [bytes(x)for x in m.ram]==expected(before[0],family)
  assert(m.rawtags,T.smc(m),bytes(m[0x1e1:0x200]),bytes(m[3:11]))==before[1:]
  assert not m.executed_guest and not m.protection_writes and not m.ppu_log
  assert m.ram_writes==([(2,0x1fe0,0)]if family==31 else[])
  rows.append([family,valid,p,rawC,z['CPU']])
 publics=[]
 for p in[v for v in range(256)if v&0x30==0x30]:
  m=C.clone(base);m.ram[2][0x1fe1]=31;c=call(m,a=0x57,p=p,public=True)
  before=(m.rawtags[:],T.smc(m),bytes(m[0x1e1:0x200]));z=T.finish(m,c)
  assert z['AXYP']==[0x57,0xa9,0x63,p&0x7d]
  seg=next(s for s in T.B['segs'].values()if s['name']=='"SMCCODE"');smc_start=int(seg['start'],0)
  real_sfc_expected=bytearray(before[1])
  for name,value in [('NextBank_SMC',0xc5),('SafereturnA_SMC',0x57)]:real_sfc_expected[T.address(T.B,name)+1-smc_start]=value
  assert(m.rawtags,T.smc(m),bytes(m[0x1e1:0x200]))==(before[0],bytes(real_sfc_expected),before[2])
  assert not m.executed_guest and m.ram_writes==[(2,0x1fe0,0)]
  publics.append([p,z['CPU']])
 return dict(direct_cases=len(rows),actualSFC_all64_flags=publics,fullAXYP_maps_page1_R0to7_33SMC_and_foreign_cookies_exact=True,only_C2_family31_validity_write=True,rows=rows)
def stale():
 rows=[]
 for var,foreign in itertools.product(range(4),[9,22,27,32,33]):
  m=D.loaded(var);c=call(m,public=True);T.finish(m,c)
  assert m.ram[2][0x1fe0]==0
  # Explicit destructive replacement witness AFTER actual pure-ROM retire.
  # No guest code may execute merely because old C2 code/fingerprint remains.
  m.ram[3][:]=bytes([0])*8192;m.ram[3][0x1fe1]=foreign
  T.put(m,SelectedCharacter=31,FmGroups=var<<3);m.ram_writes.clear();m.executed_guest.clear()
  c=D.public(m,a=0,p=0x31);T.finish(m,c)
  assert not c.p&1 and not m.executed_guest and not m.ram_writes
  rows.append([var,foreign])
 return dict(actual_loader_retire_foreignRAM3_replace_guard_reject=len(rows),no_first_A2_opcode=True,scope='Manual actualAPI ordering; shared Menu/scene/alternating-player call coverage is not installed.')
def vectors():
 rows=[];phases=set()
 for family,lag,pause in itertools.product([9,31],[0,255],[0,1]):
  base=T.Bus();base.ram[2][0x1fe0:0x1ff0]=bytes([0xa7,family,0,1])+bytes(range(12))
  T.put(base,NmiDisable=lag,GamePauseStatus=pause,VRAM_Buffer_AddrCtrl=0,VRAM_Buffer1_Offset=0,Sprite0HitDetectFlag=0,ReloadCHRBank=0)
  base[T.address(T.B,'VRAM_Buffer1')]=0
  m=C.clone(base);c=call(m,p=0x31,public=True);steps=0
  while c.pc!=0x7fff:
   assert steps<10000
   pc=c.pc;tag=m.rawtags[(pc-0x8000)//8192]if pc>=0x8000 else-1
   physical=tag&127 if tag>=128 else -1
   if physical==69 or pc<0x8000:
    phases.add((physical,pc))
    for kind in['NMI','IRQ']:
     if kind=='IRQ'and c.p&4:continue
     z,d=U.clone(m,c);z[0x5204]=0x80;proof=U.interrupt(z,d,kind,keep_ppu=False);T.finish(z,d)
     assert[d.a,d.x,d.y,d.p]==[0x57,0xa9,0x63,0x31]
     assert z.ram[2][0x1fe0]==(0 if family==31 else 0xa7)
     assert z.rawtags==base.rawtags and not z.executed_guest
     assert not z.protection_writes
     rows.append(dict(family=family,lag=lag,pause=pause,PC=pc,physical=physical,**proof))
   c.step();steps+=1
  assert m.ram[2][0x1fe0]==(0 if family==31 else 0xa7)
 assert any(phy==69 and 0xbfbd<=pc<0xbfe1 for phy,pc in phases)
 return dict(real_instruction_vector_cases=len(rows),normal_lag_paused_NMI_and_actual_unmaskedIRQ=True,all33SMC_fullAXYP_page1_rawmaps_payload_untouched_byISR=True,rows=rows)
def main():
 assert not O.exists();O.mkdir();out=dict(passed=False,native=False,actual_lifecycle_hooks=False,checks={})
 try:
  for p,h in json.loads((P/'source-stage.json').read_text())['bindings'].items():assert sha(p)==h,p
  for n,f in[('flags',flags),('stale',stale),('vectors',vectors)]:out['checks'][n]=f();print('CF retire',n,'PASS',flush=True)
  out['retained_v1_negative']='V1 public SFC fixture wrongly demanded untouched caller NextBank/SafereturnA operands. Genuine src/mmc5.s writes rawbank and worker outputA; V2 explicitly checks those exact2 bytes, while direct worker and every actual ISR retain all33 exactly. No source/product/assertion removal.'
  out['passed']=True
 except Exception as e:out.update(failure=repr(e),traceback=traceback.format_exc());raise
 finally:
  paths=[Path(__file__),Path(D.__file__),Path(C.__file__),Path(T.__file__),Path(U.__file__),P/'source-stage.json',P/'joint/candidate.nes',P/'joint/candidate.dbg',P/'joint/cf-cookie.bin',R/'tools/reference/contra_force_retire_proposal_v2.s',R/'build/contra-force-retire-controls-v1/controls.json',R/'src/mmc5.s']
  out['bindings']={str(p.resolve()):sha(p)for p in paths};p=O/'controls.json';p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(path=str(p),sha256=sha(p),passed=out['passed'],failure=out.get('failure'))),flush=True)
if __name__=='__main__':main()
