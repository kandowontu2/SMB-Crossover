"""Targeted real shared B020->ROM guard->A2 source methods; no native/cold hook."""
from pathlib import Path
import hashlib,itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import contra_force_external_guard_controls_v2 as D
C,T=D.C,D.T
P=R/'build/cf-bt-shared-transport-v3';O=R/'build/contra-force-shared-transport-controls-v1'
D.P=P;C.P=P;T.P=P;T.B=T.qualified(P/'joint/candidate.nes')
T.PAYLOAD=(P/'joint/cf-stream.bin').read_bytes();T.COOKIE=(P/'joint/cf-cookie.bin').read_bytes()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def shared(m,service,a=0x57,p=0x30):
 return C.start(m,T.address(T.B,'BtServiceVeneers')+3*service,0xd7,a=a,p=p)
def ready(var):
 m=D.loaded(var)
 T.put(m,GameEngineSubroutine=8,TimerControl=0,GamePauseStatus=0,MmDeathFlag=0,NumberofLives=2,
  AreaType=1,PlayerStatus=0,PlayerSize=0,Player_X_Position=120,Player_PageLoc=0,Player_Y_Position=176,Player_Y_HighPos=1,
  ScreenLeft_X_Pos=0,ScreenLeft_PageLoc=0,PlayerFacingDir=1,Player_State=0,Player_X_Speed=0,Player_Y_Speed=0,
  InjuryTimer=3,StarInvincibleTimer=0,SavedJoypadBits=0,CurrentOAMOffset=0,ObjectOffset=5,CrouchingFlag=0,SwimmingFlag=0)
 for n in['Enemy_Flag','Enemy_State','Enemy_ID','PowerUpType']:
  for i in range(6):m[T.address(T.B,n)+i]=0
 c=shared(m,15);T.finish(m,c);assert m.ram[2][0x2e1]==1 and m.ram[2][0xb1]==var
 return m
def pairs():
 rows=[]
 for var in range(4):
  base=ready(var)
  for service,p in itertools.product([0,2,10,14,15,26],[v for v in range(256)if v&0x30==0x30]):
   pair=[]
   for routed in[False,True]:
    m=C.clone(base)
    c=shared(m,service,p=p)if routed else C.start(m,C.L['CfServiceVeneers']+3*service,2,p=p)
    origin=m.rawtags[:];z=T.finish(m,c)
    assert m.rawtags==origin and T.get(m,'CurrentBank')==origin[1]and T.get(m,'CurrentBankC')==origin[2]
    source=bytes(v for i,v in enumerate(m.ram[2][:0x500])if not 0x2ec<=i<0x2f1)
    pair.append((z['AXYP'],C.app(m),source,bytes(m[0x1e1:0x200]),z['CPU']))
   assert pair[0][:4]==pair[1][:4],('real shared source endpoint',var,service,p,pair[0][0],pair[1][0])
   rows.append([var,service,p,pair[0][4],pair[1][4],pair[1][4]-pair[0][4]])
 return dict(actual_class_service_flag_pairs=len(rows),services=[0,2,10,14,15,26],AXYP_sourcefields_application_upperpage1_and_individual_maps_exact=True,service26_still_declared_unimplemented=True,rows=rows)
def rejection():
 rows=[]
 for var in range(4):
  base=ready(var)
  for i in range(16):
   m=C.clone(base);m.ram[2][0x1fe0+i]^=1;before=[bytes(x)for x in m.ram]
   c=shared(m,0,p=0x31);z=T.finish(m,c)
   assert not c.p&1 and not m.executed_guest and not m.ram_writes and [bytes(x)for x in m.ram]==before
   rows.append([var,i,z['CPU']])
  for family in[0,9,22,32,33]:
   m=C.clone(base);m.ram[2][:]=bytes(8192);m.ram[2][0x1fe0:0x1fe4]=bytes([0xa7,family,var,1]);before=[bytes(x)for x in m.ram]
   c=shared(m,15);T.finish(m,c)
   assert not c.p&1 and not m.executed_guest and not m.ram_writes and [bytes(x)for x in m.ram]==before
   rows.append([var,'foreign',family])
 return dict(poison_or_foreign_rejections=len(rows),no_first_A2_opcode_or_guest_write=True,rows=rows)
def movement():
 rows=[]
 for var in range(4):
  m=ready(var);T.put(m,SavedJoypadBits=1);before=T.get(m,'Player_X_Position')
  for tick in range(16):c=shared(m,0);T.finish(m,c)
  assert T.get(m,'Player_X_Position')>before and m.ram[2][0x23]==16
  rows.append(dict(variant=var,source_steps=16,before=before,after=T.get(m,'Player_X_Position')))
 return dict(actual_B020_guard_constructor_source_movement=rows,no_RAM_preload=True,scope='Actual forcedblank loader plus manual genuine shared API calls. Natural Menu/InitScreen/Main, colors and complete native actor draw remain uninstalled/pending.')
def main():
 assert not O.exists();O.mkdir();out=dict(passed=False,native=False,actual_natural_cold_or_Main=False,ready=False,checks={})
 try:
  for p,h in json.loads((P/'source-stage.json').read_text())['bindings'].items():assert sha(p)==h,p
  for n,f in[('pairs',pairs),('rejections',rejection),('movement',movement)]:out['checks'][n]=f();print('CF shared',n,'PASS',flush=True)
  out['passed']=True
 except Exception as e:out.update(failure=repr(e),traceback=traceback.format_exc());raise
 finally:
  paths=[Path(__file__),Path(D.__file__),Path(C.__file__),Path(T.__file__),P/'source-stage.json',P/'joint/candidate.nes',P/'joint/candidate.dbg',P/'joint/cf-cookie.bin',P/'joint/cf-stream.bin',P/'joint/bt/router.s',P/'joint/bowser/router.s']
  out['bindings']={str(p.resolve()):sha(p)for p in paths};p=O/'controls.json';p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(path=str(p),sha256=sha(p),passed=out['passed'],failure=out.get('failure'))),flush=True)
if __name__=='__main__':main()
