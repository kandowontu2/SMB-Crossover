"""Real ISR cuts for internally checkpointed loader, including actualSTX seams."""
from pathlib import Path
import hashlib,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import contra_force_internal_checkpoint_controls_v2 as J
import contra_force_loader_isr_controls_v2 as U
T=J.T;B=T.B;U.B=B;address=T.address
state=U.state;ppu=U.ppu
O=R/'build/contra-force-internal-checkpoint-isr-controls-v1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def interrupt(m,c,kind='NMI',keep_ppu=True):
 live=kind=='IRQ'or T.get(m,'NmiDisable')!=0
 before=dict(cpu=state(c),tags=m.rawtags[:],shadow=[T.get(m,n)for n in['CurrentBank','CurrentBankC']],smc=T.smc(m),stack=bytes(m[0x101+c.sp:0x200]),zp=bytes(m[:256]),banks=[bytes(x)for x in m.ram],ppu=ppu(m),protection=m.protection[:])
 expected=m.rawtags[:]
 if kind=='NMI':
  for slot,n,op in[(1,'CurrentBank',b'\x8d\x15\x51'),(2,'CurrentBankC',b'\x8d\x16\x51')]:
   if expected[slot]!=T.get(m,n):
    actual=bytes(m[c.pc:c.pc+3]);allowed=[op,bytes([0x8e])+op[1:]]
    assert actual in allowed and (c.a if actual[0]==0x8d else c.x)==T.get(m,n),('not an actual pending STA/STX mapper write',slot,hex(c.pc),actual,m.rawtags,T.get(m,n),c.a,c.x)
    expected[slot]=T.get(m,n)
  c.nmi()
 else:
  assert not c.p&4;c.irq()
 cycles=c.processorCycles;low=c.sp;steps=0
 while state(c)!=before['cpu']:
  assert steps<100000,('actual vector bound',kind,hex(c.pc),m.rawtags)
  assert m[c.pc]!=0,('actual vector BRK',kind,hex(c.pc),m.rawtags)
  low=min(low,c.sp);c.step();steps+=1
 assert m.rawtags==expected and [T.get(m,n)for n in['CurrentBank','CurrentBankC']]==before['shadow'],('actual vector raw mappings',kind,hex(c.pc),m.rawtags,expected)
 assert T.smc(m)==before['smc']and bytes(m[0x101+c.sp:0x200])==before['stack'],('actual vector 33SMC/live upper page1',kind,hex(c.pc))
 assert [bytes(x)for x in m.ram]==before['banks']and m.protection==before['protection'],('actual vector changed loader payload/protection',kind,hex(c.pc))
 changed=[i for i,(a,b)in enumerate(zip(before['zp'],m[:256]))if a!=b]
 # A lag native audio acquisition may initialize only its declared persistent
 # decoder pointers; the loader's real R0..7 are never audio scratch.
 start,end=(address(B,n)for n in['XgAudioPtr','XgAudioZeroPageEnd'])
 if live:assert all(kind=='NMI'and start<=i<end for i in changed),('actual live zero page clobber',kind,hex(c.pc),changed)
 assert bytes(m[3:11])==before['zp'][3:11]
 if keep_ppu:assert ppu(m)==before['ppu'],('actual vector disturbed buffered transfer/CHR/CTRL/scroll',kind,hex(c.pc),before['ppu'],ppu(m))
 return dict(kind=kind,CPU=c.processorCycles-cycles,minimum_SP=low,ZP_changes=changed)

U.interrupt=interrupt

def prefix():
 m=T.Bus();m.chr_latches[:]=[(i*113+600)&1023 for i in range(12)];m.upper=2
 c=T.cpu(m,p=0x30);end=address(B,'CfLoadNextBank');seen=set();rows=[];masked=0;steps=0
 while c.pc!=end:
  assert steps<10000
  key=(c.pc,c.x if c.pc>=0xce68 and c.pc<0xcf96 else 0)
  if key not in seen:
   seen.add(key);z,d=U.clone(m,c)
   if d.p&4:
    before=state(d);d.irq();assert state(d)==before;masked+=1
   proof=interrupt(z,d,'NMI',keep_ppu=T.get(m,'ReloadCHRBank')==0)
   rows.append(dict(PC=c.pc,X=c.x,rawA=m.rawtags[1],rawC=m.rawtags[2],**proof))
  c.step();steps+=1
 T.finish(m,c);T.exact(m,0)
 assert any(row['PC']==address(B,'CfInvalidatePreviousCookies')+3 and row['X']==2 for row in rows)
 assert any(row['PC']==address(B,'CfInvalidatePreviousCookies')+3 and row['X']==3 for row in rows)
 return dict(real_prefix_nativepublisher_STX_map_NMI_cuts=len(rows),actual_maskedIRQ_requests=masked,dirty_incoming_hardware=True,rows=rows)

def main():
 assert not O.exists();O.mkdir();out=dict(passed=False,native=False,actual_cold_hook=False,checks={})
 try:
  for p,h in json.loads((J.P/'source-stage.json').read_text())['bindings'].items():assert sha(p)==h,p
  for n,f in[('native_checkpoint_prefix',prefix),('full_transfer_seams',U.seams),('normal_rejection',U.normal_rejected)]:out['checks'][n]=f();print('CF internal checkpoint ISR',n,'PASS',flush=True)
  out['pending_mapper_contract']='Exact STA5115/5116 or STX5115/5116 accepted only when actual source register equals software shadow; real opcode and register verified, no memory/opcode/CPU normalization.'
  out['passed']=True
 except Exception as e:out.update(failure=repr(e),traceback=traceback.format_exc());raise
 finally:
  paths=[Path(__file__),Path(J.__file__),Path(T.__file__),Path(U.__file__),J.P/'source-stage.json',J.P/'joint/candidate.nes',J.P/'joint/candidate.dbg',J.P/'joint/cf-loader.s',J.P/'joint/cf-stream.bin',J.P/'joint/cf-cookie.bin']
  out['bindings']={str(p.resolve()):sha(p)for p in paths};p=O/'controls.json';p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(path=str(p),sha256=sha(p),passed=out['passed'],failure=out.get('failure'))),flush=True)
if __name__=='__main__':main()
