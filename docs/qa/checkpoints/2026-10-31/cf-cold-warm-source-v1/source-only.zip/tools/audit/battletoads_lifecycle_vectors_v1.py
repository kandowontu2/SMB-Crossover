"""Actual native/source Fresh and area-reset caller frames across real ISR."""
from pathlib import Path
import json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import battletoads_native_adapter_controls_v1 as T
H=T.H;L=T.L;address=T.address
O=R/'build/battletoads-menu-lease-v7';J=O/'joint'

def begin(m,slot):
    c=H.start(m,'BtServiceVeneers',p=48);pc=address(m.bundle,'BtServiceVeneers')+slot*3
    m[address(m.bundle,'FarcallJmpTarget_SMC')+1]=pc&255;m[address(m.bundle,'FarcallJmpTarget_SMC')+2]=pc>>8
    return c

def main():
    out=O/'lifecycle-vectors.json';assert not out.exists();q=dict(passed=False,native=False,rows=[])
    try:
        b=H.C.qualified(J/'candidate.nes');warm=L.make(b);L.call(warm,'BtAcquire')
        for slot in[15,19]:
            seed=L.fork(warm);H.put(seed,NmiDisable=255,GuestAudioCharacter=22,Square1SoundQueue=4,Square2SoundQueue=8)
            T.put(seed,'BtSrc_Objects_Life',19);T.put(seed,'BtSrc_FrameCounter',73);T.put(seed,'BtPunchPending',1)
            m=L.fork(seed);cuts=[];seen=set()
            def observe(mm,c,step):
                tag=mm.rawtags[(c.pc-32768)//8192]if c.pc>=32768 else -1
                own=(tag==3 and address(b,'BtFresh')<=c.pc<address(b,'BtActive'))or(tag==215 and address(b,'BtRouter')<=c.pc<0xb100)or 0x15a<=c.pc<0x17b
                key=(tag,c.pc)
                if own and key not in seen:seen.add(key);cuts.append((step,c.pc,bool(c.p&4)))
            H.finish(m,begin(m,slot),observe)
            for step,pc,masked in cuts:
                for kind in['NMI']+([]if masked else['IRQ']):
                    m=L.fork(seed);proof=[]
                    def interrupt(mm,c,age):
                        if age!=step:return
                        assert c.pc==pc
                        old=c.step;calls=[]
                        def stepper():
                            if c.pc==address(b,'AudioUpdate'):calls.append(c.pc)
                            return old()
                        c.step=stepper;r=L.V.interrupt(mm,c,kind);c.step=old
                        assert len(calls)==int(kind=='NMI');proof.append(r)
                    c,low=H.finish(m,begin(m,slot),interrupt)
                    assert len(proof)==1 and c.sp==224 and T.get(m,'BtPunchPending')==0
                    assert T.get(m,'BtSrc_Objects_Life')==(47 if slot==15 else 19)
                    assert T.get(m,'BtSrc_FrameCounter')==(0 if slot==15 else 73)
                    q['rows'].append(dict(slot=slot,PC=pc,phase='real foreground lag',**proof[0]))
            for pause in[0,1]:
                m=L.fork(seed);c,_=H.finish(m,begin(m,slot));H.put(m,NmiDisable=0,GamePauseStatus=pause)
                r=L.V.interrupt(m,c,'NMI');q['rows'].append(dict(slot=slot,pause=pause,phase='completed caller',**r))
        q.update(passed=True,actual_vector_cases=len(q['rows']),all33SMC_livepage1_AXYP_SP_rawbanks_borrowed_pairs_exact=True,
            original_AudioUpdate_once_per_lag_NMI=True,clock_not_advanced_by_IRQ_NMI=True,
            sourceFresh_health_reset_and_area_health_preservation=True,pending_old_area_E2_cleared=True,
            scope='Actual loaded typed Fresh/scene frames. Source-owned cold-invalid resolver and genuine fullmenu/parser/Main still require shared successor.')
    except Exception as e:q.update(error=repr(e),traceback=traceback.format_exc())
    q['bindings']={str(p.resolve()):L.sha(p)for p in[Path(__file__),Path(T.__file__),Path(L.__file__),O/'source-stage.json',O/'lifecycle-controls.json',J/'candidate.nes',J/'candidate.dbg',J/'bt/api.s',J/'bt/cache.bin',J/'bt/cookie.bin']}
    out.write_text(json.dumps(q,indent=2)+'\n');print(json.dumps({k:v for k,v in q.items()if k not in['rows','bindings','traceback']}));assert q['passed'],q.get('error')
if __name__=='__main__':main()
