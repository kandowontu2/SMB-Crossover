"""Read-only source/assembled-object fit review of the proposed B020 owner gate.

No assembler/linker invocation, candidate patch or emulator launch. Actual
shared full-flag/interrupt qualification belongs to the source-composition lane.
"""
from pathlib import Path
import hashlib
import json
import re
import subprocess

R=Path(__file__).resolve().parents[2]
O=R/'build/battletoads-shared-owner-gate-review-v1'
P=R/'build/cf-cold-existing-fit-proposal-v1'
W=R/'build/cf-cold-warm-resource-proposal-v1/proposal.json'
F=R/'build/cf-owner-retirement-v2/joint/bt/router.s'
BT=R/'docs/qa/checkpoints/2026-10-31/battletoads-menu-lifecycle-v2/handoff.json'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()


def verify(p,expected):
    assert sha(p)==expected,(p,sha(p))
    q=json.loads(p.read_text())
    for n,h in q.get('bindings',{}).items():assert sha(n)==h,(p,n)
    return q


def main():
    assert not O.exists()
    verify(P/'proposal.json','6052db7b5d0c6eab1c44ce717f832df1835e7a3c50c09838a07ca34ec9b7c6ba')
    verify(W,'7357aa7067966a117fcd63a2cf251ff25df00d59b5ccc1341b900b7c689d1161')
    verify(BT,'bc5a4a7e1d58e6c0fca96ad6b0cf85e02c388f864a4f13aa71812bbfe9b899ae')
    old=F.read_text()
    proposed=(P/'joint/bt-router.s').read_text()
    anchor=' tya\n pha\n tsx'
    replacement=''' tya
 pha
 ; Current real native AXYP already saved. Reject all other owner values
 ; before the single-import resolver can use native fallback rows15/19.
 lda SelectedCharacter
 cmp #27
 beq Owner
 cmp #31
 beq Owner
 cmp #33
 bne BtRouterBad
Owner:
 tsx'''
    assert old.count(anchor)==1
    expected=old.replace('.import BwBtResolve,','.import SelectedCharacter,BwBtResolve,')
    expected=expected.replace(anchor,replacement).replace(
        '.assert *<=$b100,lderror,"Exact BT224B Quick partition"',
        '.assert *=$b100,lderror,"Exact BT224B Quick partition"')
    assert proposed==expected,'Unexpected source delta outside reviewed gate/import/exact fit assertion'
    gate=['lda SelectedCharacter','cmp #27','beq Owner','cmp #31','beq Owner','cmp #33','bne BtRouterBad']
    assert sum([3,2,2,2,2,2,2])==15
    # The genuine existing tail and original row-offset decode are source-exact.
    assert proposed.split('Owner:\n',1)[1]==old.split(anchor,1)[1].join([' tsx','']).replace(
        '.assert *<=$b100,lderror,"Exact BT224B Quick partition"',
        '.assert *=$b100,lderror,"Exact BT224B Quick partition"')
    cmd=[str(R/'tools/Windows/cc65/bin/od65.exe'),'--dump-segments',str(P/'joint/bt-router.o')]
    z=subprocess.run(cmd,cwd=R,text=True,capture_output=True)
    assert z.returncode==0,z.stderr
    found=re.search(r'Name:\s+"BT_ROM_ROUTER".*?Size:\s+(\d+)',z.stdout,re.S)
    assert found and int(found.group(1))==211,z.stdout
    oldcmd=[str(R/'tools/Windows/cc65/bin/od65.exe'),'--dump-segments',str(F.with_suffix('.o'))]
    olddump=subprocess.run(oldcmd,cwd=R,text=True,capture_output=True)
    assert olddump.returncode==0,olddump.stderr
    oldfound=re.search(r'Name:\s+"BT_ROM_ROUTER".*?Size:\s+(\d+)',olddump.stdout,re.S)
    assert oldfound and int(oldfound.group(1))==196,olddump.stdout
    # The standalone assembler did not evaluate this linker assertion. Its
    # corrected <= form is required before linking at the actual B020 origin.
    assert '.assert *=$b100,lderror' in proposed
    assert 0xb020+211==0xb0f3 and 0xb100-0xb0f3==13
    q=dict(
        status='APPROVE_GATE_LOGIC_CORRECT_LINK_ASSERT_AND_COUNTS_BEFORE_LINK',
        approval_scope='Only the proposed B020 owner gate; not broader CF allocation/lifecycle/readiness/native approval',
        read_only_review=True,compiled_or_linked=False,native=False,
        proposal_sha256=sha(P/'proposal.json'),BT_packet_sha256=sha(BT),
        source_delta_exact=True,assembled_object_segment_bytes=211,
        old_bytes=196,added_bytes=15,approved_partition_end='B100 exclusive',
        actual_start='B020',actual_proposed_end='B0F3',remaining_allocated_bytes=13,
        required_correction='Change proposed .assert *=$b100 to .assert *<=$b100, or deliberately emit13B padding. Correct proposal counts196->211; no public PC must move.',
        retained_initial_review_negative='Initial review script expected the proposal report224B; actual od65 rejected it with211B before any artifact/public approval of fit. Frozen parent DBG confirms old196B. Proposal source/object remain untouched.',
        public_entries_unchanged_by_prefix_insertion=['36 B020 JSR rows','slot36 CLC/RTS','BtRouter worker entry'],
        changed_internal_entry='BtRouterBad relocates B0CB->B0DA within same source module; actual branch is reassembled, not copied relative bytes.',
        instructions=gate,admitted_raw_values=[27,31,33],
        rejected_raw_values=[i for i in range(256) if i not in [27,31,33]],
        stack_contract=dict(
            before_gate='Original PHP/PHA/TXA/PHA/TYA/PHA has saved native P,A,X,Y in four bytes.',
            gate_stack_operations=0,entry_frame_unchanged=True,
            row_return_decode='Same TSX/LDA $0105,X/SEC/SBC #<(BtServiceVeneers+2); $0105 remains correct.',
            accept='Gate A and comparison flags are dead before resolver offset decode. Same genuine target/callback and full original AXYP restore path.',
            reject='Existing BtRouterBad restores original A/X/Y and entry stack depth, clears returned C, and retains the established outer FarCallCommon NZ-from-A contract.'),
        estimated_added_cycles_no_page_cross={'raw27':9,'raw31':13,'raw33':16,'foreign_gate_then_reject':17},
        BT_compatibility=dict(
            full_check='BtCheck remains selected33-only and full16-byte fingerprint; no broadened cookie acceptance.',
            valid_Fresh15='Current correct v7 cache row15 calls native CmHostFresh once then source constructor, preserving native callback results.',
            valid_Reset19='Current correct v7 cache row19 calls native JnResetDispatch once and clears own motion/pending E2 while preserving health/clock and native result.',
            invalid_Fresh_Reset='Gate allows intended selected31/33 to reach future resolver native-only15/19 fallback. Other raw owners reject before resolver, including direct-table calls.',
            cold='This gate does not supply BT ROM17/26 targets, call BtAcquire or change menu readiness. Those remain a separate genuine source join.',
            menu='Does not touch frozen FmStartRetireFlags/FmGroups/P1 protocol; relocating old BwStartFlags still requires actual consumer rebind and closure.'),
        required_after_link=[
            'All256raw/full64flags direct table callback/reject endpoints; slot36 and original AXYP/SP/ordered application writes.',
            'Actual linked public entry/partition/branch checks, real family cookie poison and no A2/A3 execution on rejected owners.',
            'True normal/lag/paused NMI and legal IRQ cuts across gate/save/reject/restore with all33SMC/raw maps/live stack preserved.',
            'Genuine source cold Fresh/Reset/parser/Main controls after final mixed-row/lifecycle composition.'
        ],
        no_claim='Source ABI logic approved with concrete link-assert/count correction required. Not linked CPU/vector/gameplay proof.',
        bindings={str(p.resolve()):sha(p) for p in [Path(__file__),P/'proposal.json',W,F,
            P/'joint/bt-router.s',P/'joint/bt-router.o',F.with_suffix('.o'),
            F.parent.parent/'candidate.dbg',F.parent.parent/'private.cfg',BT]})
    O.mkdir(parents=True)
    (O/'object-segment-dump.txt').write_text(z.stdout,encoding='utf-8')
    (O/'parent-object-segment-dump.txt').write_text(olddump.stdout,encoding='utf-8')
    q['bindings'][str((O/'object-segment-dump.txt').resolve())]=sha(O/'object-segment-dump.txt')
    q['bindings'][str((O/'parent-object-segment-dump.txt').resolve())]=sha(O/'parent-object-segment-dump.txt')
    (O/'review.json').write_text(json.dumps(q,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(dict(status=q['status'],review_sha256=sha(O/'review.json'),bindings=len(q['bindings']))))


if __name__=='__main__':main()
