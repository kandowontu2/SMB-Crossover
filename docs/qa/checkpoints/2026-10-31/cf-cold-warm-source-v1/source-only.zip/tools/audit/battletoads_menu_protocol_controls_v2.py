"""Exact BT bit6 producer/retire caller ABI and real legal-phase vector seams."""
from pathlib import Path
import itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import battletoads_native_adapter_controls_v1 as T
H=T.H;L=T.L;address=T.address
O=R/'build/battletoads-menu-lease-v7';J=O/'joint'

def flags_out(p,a,carry=None):
    p=(p&125)|(a&128)|(2 if a==0 else 0)
    return p if carry is None else(p&254)|carry

def main():
    out=O/'protocol-controls.json';assert not out.exists();q=dict(passed=False,native=False,checks={});ck=q['checks']
    try:
        b=H.C.qualified(J/'candidate.nes');menu=L.make(b,OperMode=0,FmGroups=32)
        warm=L.make(b,OperMode=1,FmGroups=32);L.call(warm,'BtAcquire');assert T.get(warm,'BtHostReady')==1
        inputs=list(itertools.product(range(256),[0,63]))+list(itertools.product([0,1,128,255],range(64)))
        pairs=0
        for source,seed in [('menu',menu),('warmblank',warm)]:
            for name in['BtColdPortrait','BtColdColors']:
                for a,f in inputs:
                    m=L.fork(seed);H.put(m,VRAM_Buffer1_Offset=0,CurrentOAMOffset=0)
                    before=[bytes(x)for x in m.ram];c,low=L.call(m,name,a=a,x=91,y=37,p=L.flags(f))
                    assert(c.a,c.x,c.y,c.p,c.sp)==(a,91,37,flags_out(L.flags(f),a),224)
                    assert[bytes(x)for x in m.ram]==before
                    if name=='BtColdColors':assert H.get(m,'FmGroups')==96
                    else:assert H.get(m,'FmGroups')==32 and H.get(m,'CurrentOAMOffset')==32
                    pairs+=1
        ck['internal_dead_A_and_actual_outer_ABI']=dict(pairs=pairs,all256A_two_extreme_flags_plus_all64flags_A_edges=True,
            genuine_sources=['MetaspriteRenderLoop: LDX/LDY then LDA(Ptr),Y, no incoming A use',
                'X5QueueAreaBackdrop: initial LDX/CPX then LDA3F; own preflight guarantees offset<68',
                'BtAcquire/BtLoad: incoming A only saved/returned; Ensure ignores A; outer ColdColors saves/restores actual caller A'],
            all_stack_AXY_CVDI_exact=True,source_cache_and_earned_health_not_modified=True)
        rows=[]
        for f in range(64):
            m=L.fork(warm);H.put(m,CurrentOAMOffset=20);before=[bytes(x)for x in m.ram]
            c,_=T.row(m,3,p=L.flags(f));assert(c.a,c.x,c.y,c.sp)==(85,7,91,224)
            assert c.p==flags_out(L.flags(f),85,0)
            assert H.get(m,'CurrentOAMOffset')==20 and[bytes(x)for x in m.ram]==before
            rows.append(f)
        ck['service3']=dict(all64flags=len(rows),no_OAM_double_draw_or_cache_write=True,
            service17_still_requires_actual_ROM_cold_table='BtColdPortrait; cache17 is not a cold pipeline proof')
        # Original source fields and bit5 remain independent of the two lease
        # bits. A real producer sets40 before the actual existing consumer.
        m=L.fork(menu);H.put(m,VRAM_Buffer1_Offset=0);L.call(m,'BtColdColors');assert H.get(m,'FmGroups')==96
        H.put(m,VRAM_Buffer1_Offset=0);L.call(m,'FmCfRestoreP1');assert H.get(m,'FmGroups')==32
        ck['producer_consumer']=dict(real_ROM_colors_sets_40=True,genuine_existing_restore_clears_only_C0=True,
            source_variant20_retained=True,native_GroundPaletteData_used=True)
        # New queue/cache mutation happens only inside the real foreground's
        # lag-NMI interval. Test all reached instruction/SMC cuts, legal IRQ,
        # stale audio owner/pending native SFX, then normal/paused NMI AFTER
        # the complete publication (never invent a normal mid-packet phase).
        vectors=[]
        for audio in[0,22,32]:
            seed=L.fork(warm);H.put(seed,OperMode=0,FmGroups=224,FmAlts=255,NmiDisable=255,
                GuestAudioCharacter=audio,Square1SoundQueue=4,Square2SoundQueue=8,VRAM_Buffer1_Offset=0)
            cuts=[];seen=set();m=L.fork(seed);c=H.start(m,'FmStartFlags',x=23,p=48)
            def trace(mm,c,step):
                tag=mm.rawtags[(c.pc-32768)//8192]if c.pc>=32768 else -1
                own=(tag==157 and address(b,'FmCfRestoreP1')<=c.pc<address(b,'FmCfHelperEnd'))or(tag==221 and address(b,'BtRetire')<=c.pc<address(b,'BtPublishChr'))or 0x15a<=c.pc<0x17b
                key=(tag,c.pc)
                if own and key not in seen:seen.add(key);cuts.append((step,c.pc,bool(c.p&4)))
            H.finish(m,c,trace)
            for step,pc,masked in cuts:
                for kind in['NMI']+([]if masked else['IRQ']):
                    z=L.fork(seed);proof=[]
                    def inject(mm,c,age):
                        if age==step:
                            assert c.pc==pc
                            audiohits=[];original=c.step
                            def stepping():
                                if c.pc==address(b,'AudioUpdate'):audiohits.append(c.pc)
                                return original()
                            c.step=stepping;r=L.V.interrupt(mm,c,kind);c.step=original
                            assert len(audiohits)==int(kind=='NMI');proof.append(r)
                    cc,low=H.finish(z,H.start(z,'FmStartFlags',x=23,p=48),inject)
                    assert len(proof)==1 and H.get(z,'FmGroups')==32 and H.get(z,'FmAlts')==0 and z.ram[3][0x1fe0]==0
                    vectors.append(dict(stale_audio=audio,PC=pc,phase='actual lag foreground',**proof[0]))
            for pause in[0,1]:
                z=L.fork(seed);cc,_=L.call(z,'FmStartFlags',x=23,p=48)
                H.put(z,NmiDisable=0,GamePauseStatus=pause)
                r=L.V.interrupt(z,cc,'NMI');vectors.append(dict(stale_audio=audio,pause=pause,phase='completed publication',**r))
        ck['real_vectors']=dict(cases=len(vectors),rows=vectors,all33SMC_livepage1_AXYP_SP_rawbanks_exact=True,
            cache_retired_before_Start_mask=True,original_AudioUpdate_once_per_lag_NMI=True,
            normal_paused_after_complete_publication=True,pending_native_SFX_and_stale_FF_Arthur_owners=True)
        q.update(passed=True,scope='Exact own producer/menu Start/retire protocol. All83 current profile controls separately bound; true BT ready menu/parser/Main and native still pending.')
    except Exception as e:q.update(error=repr(e),traceback=traceback.format_exc())
    q['bindings']={str(p.resolve()):L.sha(p)for p in[Path(__file__),Path(T.__file__),Path(L.__file__),O/'source-stage.json',J/'candidate.nes',J/'candidate.dbg',J/'bt/api.s',J/'bt/preview.s',J/'bt/loader.s',J/'src/cf_menu_body.inc',J/'src/full_roster_menu.s']}
    out.write_text(json.dumps(q,indent=2)+'\n');print(json.dumps(dict(passed=q['passed'],checks=list(ck),error=q.get('error'),traceback=q.get('traceback'))));assert q['passed'],q.get('error')
if __name__=='__main__':main()
