; Source-owned CF loader successor inside the granted147+302B ROM spans.
; No common/lifecycle/native admission hook is installed by this source.
; A retained A-ROM outer worker maps a retained C-ROM copier. No guest code
; executes until all24KiB are copied, verified and C2 cookie validity is last.
; Caller must FIRST retire prior selected owners and assert Main-busy, then
; reach genuine InitScreen forced blank. This successor establishes the
; actual native12-window X5PublishChr checkpoint INTERNALLY, before copying.
.setcpu "6502"
.macpack longbranch
.import SelectedCharacter,FamilyMainCommit,OperMode,FmGroups,X5PublishChr
.import Mirror_PPUMASK,Mirror_PPUCTRL,NmiDisable,DisableScreenFlag
.import CurrentBank,CurrentBankC,ReloadCHRBank,CurrentCHRBank
.import X5ChrMode,X5WideChrActive,ChrPhysicalMap,HorizontalScroll,VerticalScroll
.importzp R0,R1,R2,R3
.export CfLoaderProposal,CfLoaderCoreProposal,CfLoaderExpectedCookie

.segment "CF_LOADER_PROPOSAL_A"
CfLoaderProposal:
 php
 pha
 txa
 pha
 tya
 pha
 lda SelectedCharacter
 cmp #31
 jne CfLoaderRejected
 lda FamilyMainCommit
 and #1
 jeq CfLoaderRejected
 lda OperMode
 cmp #1
 jne CfLoaderRejected
 lda Mirror_PPUMASK
 and #$18
 jne CfLoaderRejected
 lda DisableScreenFlag
 jeq CfLoaderRejected
 lda NmiDisable
 jpl CfLoaderRejected
 sei
 cld
 lda R0
 pha
 lda R1
 pha
 lda R2
 pha
 lda R3
 pha
 lda ReloadCHRBank
 pha
 lda #0
 sta ReloadCHRBank
 lda CurrentBankC
 pha
 lda #.lobyte(.bank(CfLoaderCoreProposal)|$80)
 sta CurrentBankC
 sta $5116
 jsr CfLoaderCoreProposal
 ; Stack-save result carry without a new RAM byte. All following restores
 ; preserve C. Original P is edited only after the stack is back at AXY/P.
 pla
 sta CurrentBankC
 sta $5116
 pla
 sta ReloadCHRBank
 pla
 sta R3
 pla
 sta R2
 pla
 sta R1
 pla
 sta R0
 jmp CfLoaderFinish
CfLoaderRejected:clc
CfLoaderFinish:
 tsx
 lda $0104,x
 and #$fe
 bcc :+
 ora #1
:
 sta $0104,x
 pla
 tay
 pla
 tax
 pla
 plp
 rts

.segment "CF_LOADER_PROPOSAL_C"
CfLoaderCoreProposal:
 lda CurrentBank
 pha
 ; C78 remains executable while the genuine A62 publisher owns A.
 lda #.lobyte(.bank(X5PublishChr)|$80)
 sta CurrentBank
 sta $5115
 jsr X5PublishChr
 ldx #2
CfInvalidatePreviousCookies:
 stx CurrentBank
 stx $5115
 lda #0
 sta $bfe0                     ; C2 FIRST, RAM3 SECOND, before ANY copy
 inx
 cpx #4
 bne CfInvalidatePreviousCookies
 lda Mirror_PPUCTRL
 and #$fb
 ora #$20
 sta $2000
 lda #0
 sta R2                        ; stream-page0..23
 sta R0                        ; pointer low stays0 through all24 source pages
 lda #1
 sta R3                        ; actual destination rawA1,2,3
CfLoadNextBank:
 lda R3
 sta CurrentBank
 sta $5115
 lda #$a0
 sta R1
CfLoadNextPage:
 jsr CfMapSourcePage
 ldx #4
CfCopy256:
 lda $2007
 sta (R0),y
 iny
 bne CfCopy256
 inc R1
 dex
 bne CfCopy256
 lda R1
 sec
 sbc #4
 sta R1
 jsr CfMapSourcePage
 ldx #4
CfVerify256:
 lda $2007
 cmp (R0),y
 jne CfLoadFailed
 iny
 bne CfVerify256
 inc R1
 dex
 bne CfVerify256
 inc R2
 lda R2
 cmp #24
 beq CfLoadVerified
 lda R1
 cmp #$c0
 bne CfLoadNextPage
 inc R3
 jmp CfLoadNextBank
CfLoadVerified:
 ; Payload C2DFE0 and RAM3BFE0 are specified zero, never valid in the CHR
 ; carrier. Publish identity/fingerprint only after the last byte verifies.
 lda #2
 sta CurrentBank
 sta $5115
 ldx #15
CfPublishCookie:
 lda CfLoaderExpectedCookie,x
 sta $bfe0,x
 dex
 bne CfPublishCookie
 lda FmGroups
 lsr
 lsr
 lsr
 and #3
 sta $bfe2
 lda #$a7
 sta $bfe0
 sec
 bcs CfRestorePublication
CfLoadFailed:
 lda #2
 sta CurrentBank
 sta $5115
 lda #0
 sta $bfe0
 clc
CfRestorePublication:
 php
 ; Genuine native X5PublishChr has established this software-to-hardware
 ; checkpoint before entry. Only BG11/upper/CTRL/latch/scroll are borrowed.
 lda X5WideChrActive
 beq CfLegacy11
 lda X5ChrMode+11
 bmi CfDirect11
CfLegacy11:
 lda #0
 sta $5130
 ldy CurrentCHRBank+11
 lda ChrPhysicalMap,y
 jmp CfWrite11
CfDirect11:
 and #3
 sta $5130
 lda CurrentCHRBank+11
CfWrite11:
 sta $512b
 lda #0
 sta $5130
 bit $2002
 lda Mirror_PPUCTRL
 sta $2000
 lda HorizontalScroll
 sta $2005
 lda VerticalScroll
 sta $2005
 plp
 pla
 sta CurrentBank
 sta $5115
 rts
CfMapSourcePage:
 lda #3
 sta $5130
 lda R2
 clc
 adc #$a7                     ; granted935=upper3,low167
 sta $512b
 bit $2002
 lda #$0c
 sta $2006
 ldy #0
 sty $2006
 lda $2007                    ; discard actual buffered first read
 rts
.res 1,$ff                   ; retain genuine expected-cookie PC CF86
CfLoaderExpectedCookie:
 .byte $a7,$1f,0,1
 .res 12,0                    ; MEASUREMENT ONLY, final payload SHA required
