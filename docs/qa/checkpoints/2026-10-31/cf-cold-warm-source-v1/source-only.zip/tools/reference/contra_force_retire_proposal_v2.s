; UNALLOCATED SOURCE PROPOSAL. A retained ROM entry must run BEFORE any
; foreign A1/C2/RAM3 replacement. This worker never executes guest code.
; Family31-only clearing is intentional even for a malformed/invalid CF
; cookie; already-foreign family09/20/21 cookies are byte-for-byte untouched.
; All original AXYP, raw C, SP/live caller stack and SMC are preserved.
.setcpu "6502"
.import CurrentBankC
.export CfRetire,CfRetireEnd
.segment "CF_RETIRE_PROPOSAL"
CfRetire:
 php
 pha
 lda CurrentBankC
 pha
 lda #2
 sta CurrentBankC
 sta $5116
 lda $dfe1
 cmp #31
 bne CfRetireRestore
 lda #0
 sta $dfe0
CfRetireRestore:
 pla
 sta CurrentBankC
 sta $5116
 pla
 plp
 rts
CfRetireEnd:
.assert CfRetireEnd-CfRetire=36,error,"Measured pure ROM retirement size"
