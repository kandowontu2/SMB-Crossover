Private BT menu-retirement and real Fresh/Scene source successor

Exact candidate35842285 is built on genuine current64/98048319 through frozen
95f141fa. Installed f56e55cd has three separate Peach palette constants; those
must be preserved during shared composition. This packet changes no readiness,
header, old64 artwork or nonowned bytes and is not installed/native-qualified.

Root granted bit5 as BT variant and bit6 only as temporary P1 lease. Existing
CFbit7/CFbits3..4/WWFlow3 survive toggles. Exact393/400B menu helper retires the
tagged BT cache and native GroundPaletteData P1 before Start masks can discard
either marker. Start retains only the selected family bits. FmToggle278B and
FmStartFlags28B remain fixed. No new ROM/RAM/ZP/header grant is used.

Source-owned Fresh15 and Scene19 call genuine native callbacks once and retain
their actual results. Fresh initializes real original health and foreground
clock; Scene preserves those while clearing motion and the old punch event.
Retained v6 negative shows the pending E2 leak at an area transition before fix.

Exact controls: all83 current profiles/664 real Start+A boundaries;5120 Select;
10240 Start;3072 internal dead-A/actual outer caller pairs;512 lifecycle pairs;
612 menu and372 lifecycle true-vector cuts;2048 original health+96food pairs;
600 integrator ticks;96 source/native-kernel pose pixels;208 true B/E2 enemy
consumers. All applicable AXYP/SP,33SMC,livepage1,maps and ordered native writes
are checked. Source clock is once per foreground tick, not NMI; native audio
still runs once per real NMI. Stale FF/Arthur AudioOwner/pending SFX are covered.

These are source boundaries, not a full gameplay claim. Shared mixed27/33 ROM
cold targets and the raw33 preview seam must be genuinely composed next, followed
by actual menu/Start/parser/Main and a bounded native firstlook. No manually
seeded cache result qualifies a ready roster gate. See row-and-cold-API.json.
Original BT P1 secondary colors may tint native P1 actors while BT is selected;
retirement restores native foreign palette. Extended combos/grabs/depth/water
specials/source music/custom HUD and vine moves remain outside this basic core.

Source archive includes exact own changed producers, commands, controls and
retained failed ancestors. Rebuilding also needs frozen current64 and the bound
95f source milestone. Its own source-and-controls.zip is included as a verified
predecessor. No ROM/object/executable/capture payloads are archived.
