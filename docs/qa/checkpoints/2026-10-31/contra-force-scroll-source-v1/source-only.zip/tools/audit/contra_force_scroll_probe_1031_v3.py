"""Real CF cold menu/parser/Main scroll+enemy proof; source CPU, never Mesen."""
from pathlib import Path
import argparse,collections,hashlib,json,re,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import contra_force_menu_cold_parser_1031_v1 as M
from prepare_ff_current_component_v2 import qualified
from check_tmnt_render_oa import address,location
P,C,H=M.P,M.C,M.H
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
 ap=argparse.ArgumentParser(description=__doc__);ap.add_argument('--joint',type=Path,required=True);ap.add_argument('--kernel',type=Path,required=True)
 ap.add_argument('--output',type=Path,required=True);ap.add_argument('--variants',type=int,nargs='+',default=[0]);ap.add_argument('--expect-scroll',action='store_true')
 a=ap.parse_args();J=a.joint.resolve();K=a.kernel.resolve();O=a.output.resolve();assert not O.exists();O.mkdir()
 P.J=H.O=J;P.L={n:int(v,16)for v,n in re.findall(r'al ([0-9A-Fa-f]+) \.(\w+)',(K/'runtime.lbl').read_text())}
 b=qualified(J/'candidate.nes');rows=[];q=dict(passed=False,source_CPU=True,native=False,candidate=sha(J/'candidate.nes'),cohorts=rows)
 original=H.finish;current=None
 names=['ScrollHandler','ScrollScreen','InitScrlAmt','AreaParserTaskHandler','EnemiesAndLoopsCore','ProcessEnemyData']
 points={(address(b,n),(location(b,n)-16)//8192|128):n for n in names}
 fields=['Player_X_Position','Player_PageLoc','Player_Y_Position','Player_State','Player_Pos_ForScroll','Player_Rel_XPos','Player_X_Scroll','Player_X_Speed','Player_XSpeedAbsolute','SideCollisionTimer','ScrollLock','ScrollAmount','ScreenLeft_X_Pos','ScreenLeft_PageLoc','ScrollThirtyTwo','AreaParserTaskNum','AreaPointer','EnemyDataOffset']
 def read(m):return{n:H.get(m,n)for n in fields}
 def finish(m,c,hook=None):
  def audit(mem,cpu,step):
   if current is not None and cpu.pc>=0x8000:
    n=points.get((cpu.pc,mem.rawtags[(cpu.pc-0x8000)//8192]))
    if n:
     current['calls'][n]+=1
     if n in('ScrollHandler','ScrollScreen','InitScrlAmt'):
      current['events'].append(dict(point=n,**read(mem)))
   if hook:hook(mem,cpu,step)
  return original(m,c,audit)
 H.finish=finish
 try:
  for v in a.variants:
   m=C.fresh(b,0);H.put(m,Player_Pos_ForScroll=0) # Actual AllZeros native power-on field, before real menu; no guest state projection.
   H.put(m,CrossoverMenuIndex=30,FmGroups=v<<3,FmAlts=0,CrossoverMenuState=2,SelectedCharacter=0)
   for n in['MenuResolveCharacter','QueueSelection','DrawSelectionPreview']:P.invoke(m,n)
   H.put(m,CrossoverMenuButtons=0,SavedJoypad1Bits=16,SavedJoypad2Bits=0);s=P.invoke(m,'CrossoverMenuInput')
   P.invoke(m,'NativeRareGameMenuRoutineCore::ChkContinue',a=s['AXYP'][0],x=s['AXYP'][1],y=s['AXYP'][2],p=s['AXYP'][3]);P.invoke(m,'PauseRoutine',a=0)
   for setup in range(600):
    if H.get(m,'OperMode_Task')==3 and H.get(m,'GameEngineSubroutine')==8:break
    H.put(m,SavedJoypadBits=0,SavedJoypad1Bits=0,SavedJoypad2Bits=0,A_B_Buttons=0,Left_Right_Buttons=0,Up_Down_Buttons=0,NmiDisable=255)
    P.invoke(m,'GameLoop');C.A.consume(m)
   else:raise AssertionError('Cold native parser timeout')
   cohort=dict(variant=v,setup_Main=setup,initial=read(m),initial_area_data=H.get(m,'AreaDataLow')+256*H.get(m,'AreaDataHigh'),initial_enemy_data=H.get(m,'EnemyDataLow')+256*H.get(m,'EnemyDataHigh'),frames=[]);rows.append(cohort)
   bp=address(b,'Block_Buffer_1');initial=bytes(m[bp:bp+416]);life=H.get(m,'NumberofLives')
   for age in range(240):
    current=dict(age=age,calls=collections.Counter(),events=[])
    # Only ordinary real controller bytes change after the actual cold Start.
    H.put(m,SavedJoypadBits=1,SavedJoypad1Bits=1,SavedJoypad2Bits=0,A_B_Buttons=0,Left_Right_Buttons=1,Up_Down_Buttons=0,NmiDisable=255)
    result=P.invoke(m,'GameLoop');C.A.consume(m)
    current.update(end=read(m),Main_CPU=result['CPU'],minimum_SP=result['minimum_SP'],
      enemies=[dict(slot=i,id=m[address(b,'Enemy_ID')+i],flag=m[address(b,'Enemy_Flag')+i],x=m[address(b,'Enemy_X_Position')+i]+256*m[address(b,'Enemy_PageLoc')+i],y=m[address(b,'Enemy_Y_Position')+i])for i in range(6)if m[address(b,'Enemy_Flag')+i]],
      block_buffer_changed=bytes(m[bp:bp+416])!=initial)
    cohort['frames'].append(current)
    assert H.get(m,'NumberofLives')==life and H.get(m,'GameEngineSubroutine')!=11,'Early native contact/death'
    x=H.get(m,'Player_X_Position')+256*H.get(m,'Player_PageLoc');camera=H.get(m,'ScreenLeft_X_Pos')+256*H.get(m,'ScreenLeft_PageLoc')
    if a.expect_scroll and x>=256 and camera>=112 and current['enemies'] and current['block_buffer_changed']:break
   cohort.update(final_X=x,final_camera=camera,actual_enemy_spawn=any(r['enemies']for r in cohort['frames']),native_terrain_advanced=any(r['block_buffer_changed']for r in cohort['frames']))
   if a.expect_scroll:assert x>=256 and camera>=112 and cohort['actual_enemy_spawn']and cohort['native_terrain_advanced'],cohort
   else:assert x==239 and camera==0 and not cohort['actual_enemy_spawn']and not cohort['native_terrain_advanced'],cohort
   current=None
  q.update(passed=True,expected_scroll=a.expect_scroll,scope='Actual cold menu/Start/native parser/Main+normalNMI source executions with only held Right. No guest-state/load/position/camera/terrain/enemy seeds; source CPU model, no new native result. Native Player_Pos_ForScroll starts at real AllZeros0 before menu; inherited seeded96 factory is explicitly corrected, not camera/guest outcome seeded.')
 except Exception as e:q.update(error=repr(e),traceback=traceback.format_exc())
 finally:H.finish=original
 refs=[Path(__file__),Path(M.__file__),Path(P.__file__),Path(C.__file__),Path(H.__file__),J/'candidate.nes',J/'candidate.dbg',J/'candidate.lbl',K/'runtime.lbl',J.parent/'source-stage.json',R/'build/contra-force-11-native-1031-v5/burns/capture/result.json',R/'build/contra-force-11-native-1031-v5/burns/capture/trace.csv']
 q['bindings']={str(p.resolve()):sha(p)for p in refs}
 (O/'controls.json').write_text(json.dumps(q,indent=2)+'\n')
 print(json.dumps(dict(path=str(O/'controls.json'),sha256=sha(O/'controls.json'),passed=q['passed'],summary=[{k:v for k,v in c.items()if k!='frames'}for c in rows],error=q.get('error')),indent=2),flush=True);assert q['passed']
if __name__=='__main__':main()
