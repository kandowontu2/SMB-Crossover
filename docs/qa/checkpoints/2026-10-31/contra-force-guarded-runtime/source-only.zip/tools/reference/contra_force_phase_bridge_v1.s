; Selected-owner CF code transport in always-mapped rawC2. No resident code.
; All targets must be genuine linked rawA1/rawA3 labels. CfTarget/Bank/Arg
; are consumed before entering the target, so nested calls may reuse them.
.setcpu "6502"
.import CfState,CurrentBank
.export CfCallA,CfTarget,CfTargetBank,CfArgA,CfArgP
CfTarget=CfState+$02ec
CfTargetBank=CfState+$02ee
CfArgA=CfState+$02ef
CfArgP=CfState+$02f0
.segment "CF_C2_TRANSPORT"
CfCallA:
 sta CfArgA
 php
 pla
 sta CfArgP
 lda CurrentBank
 pha                          ; origin lives on CPU stack, never shared state
 lda CfTargetBank
 sta CurrentBank
 sta $5115
 lda CfArgP
 pha
 lda CfArgA
 plp
 jsr CfIndirectA
 sta CfArgA
 php
 pla
 sta CfArgP
 pla
 sta CurrentBank
 sta $5115                    ; restore origin BEFORE caller RTS fetch
 lda CfArgP
 pha
 lda CfArgA
 plp
 rts
CfIndirectA:jmp(CfTarget)
