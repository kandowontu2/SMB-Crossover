; Selected raw31 source-host boundaries. No shared routing/admission here.
; All native world/collision/score/pickup services remain the actual host.
.setcpu "6502"
.macpack longbranch
.import CfState,CfNativeShot,CfNativeShotWorld,CfNativeAdvance
.import CfNativeAnimation24,CfNativeShotImpact,CfCallA,CfTarget,CfTargetBank
.import ScreenLeft_X_Pos,ScreenLeft_PageLoc,BlockBufferAddr,MTileAttribute
.import BoundBoxCtrlData,ShellOrBlockDefeat,HandleEnemyFBallCol
.import SelectedCharacter,GamePauseStatus,TimerControl,MmDeathFlag
.import PlayerStatus,PlayerSize,StarInvincibleTimer,AreaMusicQueue,Square1SoundQueue,Square2SoundQueue
.import EraseEnemyObject,SetupFloateyNumber,FloateyNum_Control
.import NumberofLives
.importzp R0,R1,R2,R3,R4,R5,R6,R7,ObjectOffset,GameEngineSubroutine
.importzp Enemy_Flag,Enemy_ID,Enemy_State,Enemy_X_Position,Enemy_PageLoc
.importzp Enemy_Y_Position,Enemy_Y_HighPos,PowerUpType
.import Enemy_BoundBoxCtrl
.importzp MTILE_SOLID,MTILE_CLIMB,PowerUpObject,Bowser,BuzzyBeetle,Podoboo,BulletBill_FrenzyVar
.importzp Sfx_Fireball,Sfx_PowerUpGrab,StarPowerMusic
.export CfHostShots,CfHostShotContacts,CfHostCollect
.export CfHostScript,CfHostShotWorld,CfHostAudio,CfHostPoint
.export CfUnsupportedScript,CfShotSlot,CfEnemySlot,CfPointResult
.export sub_0x01D072,sub_0x01E086
.export sub_B388,sub_0x01F3C3_execute_script,loc_0x01F3C3_execute_script
.export sub_0x0095E8_play_music,loc_0x0095E8_play_music
.export sub_0x01FEDA_add_music_to_queue,loc_0x01FEDA_add_music_to_queue
CfShotSlot=CfState+$02fc
CfEnemySlot=CfState+$02fd
CfPointResult=CfState+$02fe
CfUnsupportedScript=CfState+$02ff

; Gates live in the always-visible verified C2 phase. They may be entered
; from A1 or A3; the real transport restores the original A bank before RTS.
.segment "CF_HOST_CALLBACK_GATES"
.macro PhaseGate label,target
label:
 php
 pha
 lda #<target
 sta CfTarget
 lda #>target
 sta CfTarget+1
 lda #3
 sta CfTargetBank
 pla
 plp
 jmp CfCallA
.endmacro
PhaseGate sub_B388,CfHostShotWorld
loc_0x01F3C3_execute_script:
PhaseGate sub_0x01F3C3_execute_script,CfHostScript
loc_0x0095E8_play_music:
sub_0x01FEDA_add_music_to_queue:
loc_0x01FEDA_add_music_to_queue:
PhaseGate sub_0x0095E8_play_music,CfHostAudio

; Exact original fixed-source helper semantics, projected into owned state.
sub_0x01D072:
 lda #0
 sta CfState+$21
 sta CfState+$22
 rts
sub_0x01E086:
 lda CfState+$b3,y
 beq :+
 sec
 sbc #1
:
 sta CfState+$0a
 and #15
 cmp #15
 bne :+
 lda CfState+$0a
 sec
 sbc #16
 and #$f0
 ora #9
 sta CfState+$0a
:
 rts

.segment "CF_HOST_BOUNDARIES"
CfHostScript:
 cmp #$24
 beq CfScriptAnimation
 cmp #0
 beq CfScriptWorld
 cmp #$25
 beq CfScriptNoPartner
 ; AI scripts are never legal in this single-human native owner. Latch
 ; unexpected requests instead of executing an unverified pointer/stub.
 sta CfUnsupportedScript
 clc
 rts
CfScriptAnimation:jmp CfNativeAnimation24
CfScriptNoPartner:
 ; Original25 is a donor stage-special partner/contact request. SMB native
 ; terrain/platforms own those contacts; there is no donor partner object.
 lda #0
 sta CfState+$08
 rts
CfScriptWorld:
 jsr CfHostPoint
 lda #1                        ; original table role1 = nonblocking region
 ldy CfPointResult
 beq :+
 lda #0                        ; original role0 = solid, tested by 008FD0
:
 sta CfState+$01
 rts

CfHostShotWorld:
 lda CfState+$034e,x
 sta CfState
 lda CfState+$0368,x
 sta CfState+1
 jsr CfHostPoint
 lda CfPointResult
 beq :+
 lda #2                        ; original B388's admitted impact result
:
 sta CfState
 rts

; Actual native block-buffer page/cell and solidity, at source screenpoint
; State00/01. All native R0..7 and source slotX survive the native query.
CfHostPoint:
 txa
 pha
 ldx #7
:
 lda R0,x
 pha
 dex
 bpl :-
 lda #0
 sta CfPointResult
 lda CfState+1
 cmp #32
 bcc CfPointDone
 cmp #240
 bcs CfPointDone
 and #$f0
 sec
 sbc #32
 pha
 lda CfState
 clc
 adc ScreenLeft_X_Pos
 sta R5
 lda ScreenLeft_PageLoc
 adc #0
 and #1
 tay
 lda BlockBufferAddr+2,y
 sta R7
 lda R5
 lsr
 lsr
 lsr
 lsr
 clc
 adc BlockBufferAddr,y
 sta R6
 pla
 tay
 lda (R6),y
 tay
 lda MTileAttribute,y
 and #MTILE_SOLID|MTILE_CLIMB
 cmp #MTILE_SOLID
 bne CfPointDone
 inc CfPointResult
CfPointDone:
 ldx #0
:
 pla
 sta R0,x
 inx
 cpx #8
 bcc :-
 pla
 tax
 rts

CfHostAudio:
 ; Explicit WIP host SFX adaptation. Original weapon selection/cadence
 ; remains source-owned; native SMB fireball sound replaces donor audio.
 pha
 lda #Sfx_Fireball
 sta Square1SoundQueue
 pla
 rts

CfHostShots:
 ; Original8132: active slot10..21 world pass, handler, animation. Camera
 ; byte69 is a one-update native scroll delta, not another player motion.
 lda #13
 sta CfState+$36
 ldx #10
CfHostNextShot:
 stx CfShotSlot
 stx CfState+$53
 lda CfState+$0382,x
 beq CfHostShotNext
 jsr CfNativeShotWorld
 ldx CfShotSlot
 lda CfState+$0382,x
 beq CfHostShotNext
 jsr CfNativeShot
 ldx CfShotSlot
 jsr CfNativeAdvance
 ldx CfShotSlot
 jsr CfHostShotContacts
CfHostShotNext:
 ldx CfShotSlot
 inx
 cpx #22
 bcc CfHostNextShot
 lda #2
 sta CfState+$36
 lda #0
 sta CfState+$53             ; next genuine source body owns actor0
 rts

CfHostShotContacts:
 lda CfState+$0382,x
 beq CfNoContact
 lda CfState+$0300,x
 and #$f0
 bne CfNoContact
 lda CfState+$0334,x
 cmp #28
 bne CfNoContact
 txa
 pha
 ldx #7
:
 lda R0,x
 pha
 dex
 bpl :-
 lda ObjectOffset
 pha
 lda #0
 sta CfEnemySlot
CfContactNext:
 ldx CfEnemySlot
 lda Enemy_Flag,x
 jeq CfContactAdvance
 jmi CfContactAdvance         ; duplicated/composite native actor is not owner
 lda Enemy_State,x
 and #$20
 jne CfContactAdvance
 lda Enemy_Y_HighPos,x
 cmp #1
 jne CfContactAdvance
 lda Enemy_ID,x
 cmp #Bowser
 beq CfContactGeometry
 cmp #$15
 jcs CfContactAdvance
 cmp #BuzzyBeetle
 jeq CfContactAdvance
 cmp #Podoboo
 jeq CfContactAdvance
 cmp #BulletBill_FrenzyVar
 jeq CfContactAdvance
CfContactGeometry:
 lda Enemy_BoundBoxCtrl,x
 cmp #21
 jcs CfContactAdvance
 asl
 asl
 tay
 lda ScreenLeft_X_Pos
 ldx CfShotSlot
 clc
 adc CfState+$034e,x
 sta R2
 lda ScreenLeft_PageLoc
 adc #0
 sta R3
 ldx CfEnemySlot
 lda R2
 sec
 sbc Enemy_X_Position,x
 sta R2
 lda R3
 sbc Enemy_PageLoc,x
 jne CfContactAdvance
 lda R2
 cmp BoundBoxCtrlData,y
 jcc CfContactAdvance
 cmp BoundBoxCtrlData+2,y
 beq :+
 jcs CfContactAdvance
:
 ldx CfShotSlot
 lda CfState+$0368,x
 ldx CfEnemySlot
 sec
 sbc Enemy_Y_Position,x
 jcc CfContactAdvance
 cmp BoundBoxCtrlData+1,y
 jcc CfContactAdvance
 cmp BoundBoxCtrlData+3,y
 beq :+
 jcs CfContactAdvance
:
 stx ObjectOffset
 stx R1                       ; genuine fireball/Bowser caller's actor origin
 lda Enemy_ID,x
 cmp #Bowser
 bne CfOrdinaryDefeat
 jsr HandleEnemyFBallCol
 jmp CfSourceImpact
CfOrdinaryDefeat:jsr ShellOrBlockDefeat
CfSourceImpact:
 ldx CfShotSlot
 jsr CfNativeShotImpact       ; source world-impact action, not erased art
 jmp CfContactDone
CfContactAdvance:
 inc CfEnemySlot
 lda CfEnemySlot
 cmp #6
 jcc CfContactNext
CfContactDone:
 pla
 sta ObjectOffset
 ldx #0
:
 pla
 sta R0,x
 inx
 cpx #8
 bcc :-
 pla
 tax
CfNoContact:rts

CfHostCollect:
 lda SelectedCharacter
 cmp #31
 jne CfCollectNo
 lda GameEngineSubroutine
 cmp #8
 jne CfCollectNo
 lda GamePauseStatus
 and #1
 jne CfCollectNo
 lda TimerControl
 ora MmDeathFlag
 jne CfCollectNo
 cpx #6
 jcs CfCollectNo
 lda Enemy_Flag,x
 jeq CfCollectNo
 jmi CfCollectNo
 lda Enemy_ID,x
 cmp #PowerUpObject
 jne CfCollectNo
 lda Enemy_State,x
 jpl CfCollectNo
 lda PowerUpType,x
 cmp #4
 jcs CfCollectNo
 lda ObjectOffset
 pha
 stx ObjectOffset
 txa
 pha
 lda PowerUpType,x
 pha
 jsr EraseEnemyObject
 lda #6
 jsr SetupFloateyNumber
 pla
 cmp #2
 bcs CfNativeItem
 lda PlayerStatus
 cmp #2
 bcs :+
 inc PlayerStatus
:
 ldx CfState+$02e0
 lda PlayerStatus
 ora #$10
 sta CfState+$7f,x
 lda #1
 sta CfState+$02e2            ; original body palette needs re-publication
 jmp CfCollectSound
CfNativeItem:
 cmp #3
 beq CfCollectLife
 lda #$23
 sta StarInvincibleTimer
 lda #StarPowerMusic
 sta AreaMusicQueue
 jmp CfCollectSound
CfCollectLife:
 pla
 tax
 txa
 pha
 lda #$0b
 sta FloateyNum_Control,x
CfCollectSound:
 lda #Sfx_PowerUpGrab
 sta Square2SoundQueue
 pla
 tax
 pla
 sta ObjectOffset
 sec
 rts
CfCollectNo:clc
 rts


