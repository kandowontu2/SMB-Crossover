"""Resolve actual OAM visible winners before comparing source palette colors."""
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parents[2];A=R/'tools/audit/export_contra_force_bodies_v2_generated.py';s=A.read_text().replace("build/contra-force-body-art-v2'","build/contra-force-body-art-v3'")
needle='source[xy]=code;colors.setdefault(code,set()).add(image.getpixel(xy))';assert s.count(needle)==1;s=s.replace(needle,'source[xy]=code')
needle="assert len(parts)>=4 and all(len(z)==1 for z in colors.values())";assert s.count(needle)==1;s=s.replace(needle,"for xy,code in source.items():colors.setdefault(code,set()).add(image.getpixel(xy))\n "+needle)
p=R/'tools/audit/export_contra_force_bodies_v3_generated.py';assert not p.exists();p.write_text(s,newline='\n');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();O=R/'build/contra-force-body-export-builder-v3';O.mkdir()
(O/'derivation.json').write_text(json.dumps(dict(base=str(A),base_sha256=sha(A),successor=str(p),successor_sha256=sha(p),retained_negative='v2 screenshot check compared hidden lower-priority gun/arm pixels before actual OAM compositing; compare every actual final visible winner, retaining all original ROM patterns and native priority/order.'),indent=2)+'\n',newline='\n')
print(json.dumps(dict(path=str(p),sha256=sha(p))))
