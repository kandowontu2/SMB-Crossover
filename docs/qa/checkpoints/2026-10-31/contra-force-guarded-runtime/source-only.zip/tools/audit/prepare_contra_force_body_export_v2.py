"""Use actual visible-scanline ROM-backed CHR, retaining rejected empty dump."""
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parents[2];A=R/'tools/audit/export_contra_force_bodies_v1.py';s=A.read_text().replace("build/contra-force-body-art-v1'","build/contra-force-body-art-v2'")
needle="oam=p[14:270];chr=p[270:8462];pal=p[8462:8494];assert oam==dma[13:269],'EndFrame OAM does not match actual lastDMA source buffer'"
assert s.count(needle)==1
s=s.replace(needle,"""oam=p[14:270];assert oam==dma[13:269],'EndFrame OAM does not match actual lastDMA source buffer'
 vp=folder/f'frame-{frame:05d}-visible.bin';vis=vp.read_bytes();assert vis[:8]==b'VISIBLE1'
 vf,line,ctrl=struct.unpack_from('<IHB',vis,8);assert vf==frame and line==160 and ctrl&32
 physical=list(struct.unpack_from('<8I',vis,15));chr=vis[47:8239];pal=vis[8239:8271];assert len(chr)==8192 and len(pal)==32
 for w,physical_offset in enumerate(physical):assert chr[w*1024:(w+1)*1024]==original[physical_offset:physical_offset+1024],('Visible physical publisher mismatch',w,physical_offset)
 assert any(chr),'Rejected zero-filled late-HUD pattern snapshot'""")
s=s.replace("ROM,path,dp,sp,fp,tp,O/f'{name}-native-HUD.png'","ROM,path,dp,vp,sp,fp,tp,O/f'{name}-native-HUD.png'")
s=s.replace("snapshot_sha256=sha(path),DMA_snapshot", "snapshot_sha256=sha(path),visible_scanline=160,visible_physical_CHR_offsets=physical,visible_snapshot=str(vp),visible_snapshot_sha256=sha(vp),DMA_snapshot")
p=R/'tools/audit/export_contra_force_bodies_v2_generated.py';assert not p.exists();p.write_text(s,newline='\n')
O=R/'build/contra-force-body-export-builder-v2';O.mkdir();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();(O/'derivation.json').write_text(json.dumps(dict(base=str(A),base_sha256=sha(A),successor=str(p),successor_sha256=sha(p),retained_negative='v1 empty late-HUD CHR produced no source pixels and was rejected; v2 requires actual eight physical ROM page matches at visible scanline160.'),indent=2)+'\n',newline='\n')
print(json.dumps(dict(successor=str(p),sha256=sha(p))))
