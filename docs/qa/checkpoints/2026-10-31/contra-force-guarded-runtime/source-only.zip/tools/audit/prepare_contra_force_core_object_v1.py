"""Compile genuine4-class source player core with conservative abstract projection.

This object intentionally has real unresolved engine service imports. It is
not a linked host cartridge, stubbed playable demonstration or memory lease.
"""
from pathlib import Path
import hashlib,json,re,subprocess,sys
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit')]
from private_build_outputs_v1 import validate
P=R/'build/contra-force-reproduction-v2';O=R/'build/contra-force-core-object-v1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 assert not O.exists();O.mkdir()
 proof=json.loads((P/'proof.json').read_text())
 for p,v in proof['bindings'].items():assert sha(p)==v,p
 original=P/'copy_bank_05.asm';full=original.read_text()
 body='sub_A030:'+full.split('sub_A030:',1)[1].split('loc_AE7B:',1)[0]
 assert body.rstrip().endswith('RTS')
 known=set()
 for p in P.glob('copy_bank_*.asm'):
  known|=set(re.findall(r'^(\w+):',p.read_text(),re.M))
 local=set(re.findall(r'^(\w+):',body,re.M))
 used=set(re.findall(r'\b\w+\b',body.split(';')[0]))
 # Strip every comment before finding real label/field consumers.
 code=re.sub(r';[^\n]*','',body)
 used=set(re.findall(r'\b\w+\b',code))
 foreign=sorted((used&known)-local)
 fields=sorted(n for n in used if n.startswith('ram_'))
 # Evaluate genuine source aliases, never inventing a field offset.
 defs={}
 for line in (P/'copy_bank_ram.inc').read_text().splitlines():
  m=re.match(r'\s*(ram_\w+)\s*=\s*([^;]+)',line)
  if m:defs[m[1]]=m[2].strip()
 vals={}
 def value(n):
  if n not in vals:
   s=re.sub(r'\$([0-9A-Fa-f]+)',r'0x\1',defs[n])
   s=re.sub(r'\bram_\w+\b',lambda m:str(value(m[0])),s)
   assert re.fullmatch(r'[0-9xXa-fA-F+()\s-]+',s),(n,s)
   vals[n]=eval(s,{'__builtins__':{}},{})
  return vals[n]
 indirect=set()
 for n in re.findall(r'\((ram_\w+)\)\s*,\s*Y|\((ram_\w+)\s*,\s*X\)',code,re.I):
  name=next(v for v in n if v);indirect.add(value(name))
 # Every actually indirect source pair keeps a genuine zero-page pair.
 pointerbytes=sorted({v for a in indirect for v in[a,a+1]})
 zpmap={a:i for i,a in enumerate(pointerbytes)}
 state=['; Abstract component only; no current host RAM addresses assigned.','.segment "CF_POINTERS": zeropage','.exportzp CfPointers,CfPointersEnd','CfPointers: .res '+str(len(pointerbytes)),'CfPointersEnd:','.segment "CF_STATE"','.export CfState,CfStateEnd','CfState: .res $800','CfStateEnd:']
 fieldmap={}
 for n in fields:
  a=value(n);assert 0<=a<2048,(n,a)
  target='CfPointers+'+str(zpmap[a])if a in zpmap else 'CfState+$%04x'%a
  state.append(n+' = '+target);fieldmap[n]=dict(original=a,projected_expression=target)
 (O/'state.inc').write_text('\n'.join(state)+'\n',encoding='utf-8')
 # Branch relaxation changes only control transport; source instructions and
 # original labels/data remain explicit. This is measured before any host fit.
 branches={'BCC':'jcc','BCS':'jcs','BEQ':'jeq','BNE':'jne','BMI':'jmi','BPL':'jpl','BVC':'jvc','BVS':'jvs'}
 body=re.sub(r'^(\s*)(BCC|BCS|BEQ|BNE|BMI|BPL|BVC|BVS)\b',lambda m:m[1]+branches[m[2]],body,flags=re.M)
 source=['.macpack longbranch','.feature force_range','.include "state.inc"','.include "copy_bank_val.inc"']
 source += ['.import '+n for n in foreign]
 source += ['.export CfNativeInput := sub_A2E7','.export CfNativeBody := ofs_006_0x00A548_13','.export CfNativeJump := sub_AB42','.export CfNativeMotion := sub_AD5A','.export CfNativeWeaponDirection := sub_ACF6','.segment "CF_CORE"','.export CfCoreStart,CfCoreEnd','CfCoreStart:',body,'CfCoreEnd:']
 target=O/'component.s';target.write_text('\n'.join(source)+'\n',encoding='utf-8')
 ca=R/'tools/Windows/cc65/bin/ca65.exe';od=R/'tools/Windows/cc65/bin/od65.exe'
 cmd=[str(ca),'--cpu','6502x','-g','-I',str(P),'--create-full-dep',str(O/'component.dep'),'-o',str(O/'component.o'),str(target)]
 guard=validate(cmd,O,cwd=O);r=subprocess.run(cmd,cwd=O,capture_output=True,text=True)
 log=dict(command=cmd,cwd=str(O),output_guard=guard,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr)
 (O/'compile.json').write_text(json.dumps(log,indent=2)+'\n',encoding='utf-8');assert r.returncode==0,log
 q=subprocess.run([str(od),'--dump-segments',str(O/'component.o')],cwd=O,capture_output=True,text=True);assert q.returncode==0
 (O/'segments.txt').write_text(q.stdout,encoding='utf-8')
 # Read actual object segment size instead of estimating expanded addressing.
 chunks=q.stdout.split('Name:')
 sizes={}
 for chunk in chunks[1:]:
  m=re.search(r'"(\w+)"',chunk);z=re.search(r'Size:\s+(\d+)',chunk)
  if m and z:sizes[m[1]]=int(z[1])
 assert sizes['CF_STATE']==2048 and sizes['CF_POINTERS']==len(pointerbytes)
 out=dict(status='COMPILED_SOURCE_CORE_OBJECT_UNRESOLVED_SERVICES_NO_HOST',passed=True,original_source_range=dict(bank=5,start=0xa030,end=0xae7b,bytes=0xe4b),actual_segments=sizes,indirect_original_pairs=sorted(indirect),abstract_zero_page_bytes=len(pointerbytes),conservative_private_state_bytes=2048,field_map=fieldmap,unresolved_genuine_source_services=foreign,declared_host_world_boundary='Original source contacts/environment/area-tail require explicit SMB adapters; no dummy implementations emitted.',no_fixed_host_allocation=True,no_native=True,bindings={str(p.resolve()):sha(p)for p in[Path(__file__),original,P/'copy_bank_ram.inc',P/'copy_bank_val.inc',P/'proof.json',ca,od,*[p for p in O.iterdir()if p.is_file()]]})
 p=O/'source-object-proof.json';p.write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8')
 print(json.dumps(dict(path=str(p),sha256=sha(p),segments=sizes,unresolved_services=len(foreign))),flush=True)
if __name__=='__main__':main()
