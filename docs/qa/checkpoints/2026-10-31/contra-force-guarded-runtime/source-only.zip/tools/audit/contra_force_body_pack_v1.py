"""Decode genuine CF animation+OAM bytecode; lossless P0/red-P2 pose-local pack."""
from pathlib import Path
import hashlib,json,sys,importlib.util
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit')]
import contra_force_engine_probe_v1 as T
from verify_native_relocation import NesMPU
O=R/'build/contra-force-body-pack-v1';assert not O.exists();O.mkdir()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
RAW=T.RAW;CHR=RAW[16+131072:]
class Mem(T.Mem):
 def pair(self,lo):
  self.reg[6:8]=[lo,lo+1];self[0x36]={0:0,4:2,10:1}[lo];self.map()
def machine(var):
 m=Mem();m.pair(4);m[0xb1]=var;m[0x7f+var]=16;m[0x782]=46;m[0x682]=10;m[0x64e]=128;m[0x668]=128
 return NesMPU(memory=m)
def word(m,a):return m[a]+256*m[a+1]
def render(c):
 m=c.memory;m.pair(0)
 for i in range(64):m[0x200+4*i]=244
 m[8]=0;m[1]=64
 T.call(c,0xd35b,a=m[0x61a],x=0,y=0)
 parts=[]
 for i in range(64):
  y,t,a,x=m[0x200+4*i:0x204+4*i]
  if y<240:parts.append(dict(slot=i,x=x,y=y,tile=t,attr=a))
 assert parts
 return parts
def pixelmap(parts,bankmap,pal):
 pix={}
 for p in reversed(parts):
  a,t=p['attr'],p['tile'];start=(t&1)*4096+(t&254)*16
  for yy in range(16):
   sy=15-yy if a&128 else yy
   for xx in range(8):
    sx=7-xx if a&64 else xx;at=start+(sy//8)*16+sy%8
    low=CHR[bankmap[at//1024]*1024+at%1024];high=CHR[bankmap[(at+8)//1024]*1024+(at+8)%1024]
    value=((low>>(7-sx))&1)|(((high>>(7-sx))&1)<<1)
    if value:pix[(p['x']+xx,p['y']+1+yy)]=(pal[16+(a&3)*4+value],a&32)
 return pix
def encode(values):
 data=bytearray(32)
 for y in range(16):
  for x in range(8):
   at=(y//8)*16+y%8;v=values[y*8+x]
   data[at]|=(v&1)<<(7-x);data[at+8]|=((v>>1)&1)<<(7-x)
 return bytes(data)
def coalesce(pix):
 loX=min(x for x,y in pix);hiX=max(x for x,y in pix);loY=min(y for x,y in pix);hiY=max(y for x,y in pix);out=[]
 for y in range(loY,hiY+1,16):
  for x in range(loX,hiX+1,8):
   for palette,priority in[(0,0),(2,0),(0,32),(2,32)]:
    values=[]
    for yy in range(16):
     for xx in range(8):
      p=pix.get((x+xx,y+yy));v=0
      if p and p[1]==priority:
       if palette==0:v={55:1,18:2,15:3,22:0}[p[0]]
       elif p[0]==22:v=1
      values.append(v)
    if any(values):out.append(dict(x=x,y=y-1,attr=palette|priority,pattern=encode(values)))
 return out
def emitted(parts):
 pal={0:[None,55,18,15],2:[None,22,None,None]};pix={}
 for p in reversed(parts):
  pair=p['pattern']
  for yy in range(16):
   for xx in range(8):
    at=(yy//8)*16+yy%8;v=((pair[at]>>(7-xx))&1)|(((pair[at+8]>>(7-xx))&1)<<1)
    if v:pix[(p['x']+xx,p['y']+1+yy)]=(pal[p['attr']&3][v],p['attr']&32)
 return pix
def lines(parts):return max(sum(p['y']+1<=y<p['y']+17 for p in parts)for y in range(240))
views={};rows=[]
try:
 for var in range(4):
  c=machine(var);m=c.memory
  m.pair(10);T.call(c,0x97cf)
  bankmap=[48,49,50,51,m[0x79],m[0x7a],0,13]
  T.call(c,0xf4b1,a=0,y=2);pal=list(m[0x3b0:0x3d0])
  assert pal[16:24]==[15,55,18,15,15,55,22,15]
  m.pair(4);pointer=word(m,0xa99d+2*var);end=word(m,0xa99d+2*(var+1))
  seqs=set(m[pointer:end])
  extras=[[23,26,24,29,28],[46,49,47,52,51],[69,74,72,71,70],[98,103,101,100,99]][var]
  seqs.update(extras);assert seqs and min(seqs)>0 and max(seqs)<=104
  for seq in sorted(seqs):
   c=machine(var);m=c.memory;m[0xc0]=var<<2
   T.call(c,0x9762,a=seq,y=0)
   for age in range(64):
    frame=m[0x61a];key=(var,frame,m[0x634])
    if frame and key not in views:
     original=render(c);assert lines(original)<=8
     pix=pixelmap(original,bankmap,pal);assert pix and set(p[0]for p in pix.values())<={55,18,15,22}
     target=coalesce(pix);assert emitted(target)==pix
     assert lines(target)<=8,('intrinsic body overload',key,lines(target))
     views[key]=dict(variant=var,sequence=seq,source_age=age,frame=frame,source_high=m[0x634],source_parts=original,source_line_max=lines(original),target_line_max=lines(target),opaque_pixels=len(pix),parts=target)
    m.pair(4);T.call(c,0xf3b3,a=36)
  rows.append(dict(variant=var,source_sequences=sorted(seqs),native_CHR_banks=bankmap,actual_original_P0_P1=pal[16:24]))
 # Every view occupies ONE1KB window; source-created masks count as art.
 pages=[]
 for v in sorted(views.values(),key=lambda v:-len({p['pattern']for p in v['parts']})):
  pairs={p['pattern']for p in v['parts']};assert len(pairs)<=32
  fits=[(len(pairs-set(p)),i)for i,p in enumerate(pages)if len(set(p)|pairs)<=32]
  if fits:i=min(fits)[1]
  else:i=len(pages);pages.append([])
  page=pages[i]
  for p in v['parts']:
   pair=p.pop('pattern')
   if pair not in page:page.append(pair)
   p['local_pair']=page.index(pair)
  v['local_page']=i
 atlas=b''.join(b''.join(p).ljust(1024,b'\0')for p in pages);(O/'atlas.chr').write_bytes(atlas)
 d=dict(passed=True,status='ABSTRACT_SOURCE_PIXEL_EXACT_BODY_PACK_NO_PHYSICAL_LEASE',native=False,host=False,views=len(views),local_1KB_pages=len(pages),CHR_bytes=len(atlas),original_source_palette_roles=rows,per_pose_source_metadata=list(views.values()),maximum_target_scanline_parts=max(v['target_line_max']for v in views.values()),maximum_target_parts=max(len(v['parts'])for v in views.values()),normal_world_palettes_unchanged=True,world_P2_index1_donor_proof='Existing frozen S2 eye/BG source scene consumer controls; this pack uses NES16 only, no P1 loan. No new publisher or host palette write.',sprite_window='One private pose-local window0; preserve world1..7. No fixed page publication granted.',scope='Genuine source-selected side-view sequence superset with64 original animation updates each, actual original OAM decoder and static original palette consumer. No sourceMain/world/collision/native controller admission.',bindings={str(p.resolve()):sha(p)for p in[Path(__file__),Path(T.__file__),R/'tools/audit/verify_native_relocation.py',R/'build/contra-force-reproduction-v2/candidate.nes',R/'build/contra-force-reproduction-v2/proof.json',R/'build/smb2-eye-sky-controls-v1/controls.json',O/'atlas.chr']})
 p=O/'packing.json';p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8');print(json.dumps(dict(passed=True,path=str(p),sha256=sha(p),views=len(views),pages=len(pages),maxline=d['maximum_target_scanline_parts'],maxparts=d['maximum_target_parts'])),flush=True)
except Exception as e:
 (O/'negative.json').write_text(json.dumps(dict(passed=False,error=repr(e),completed_views=len(views),rows=rows),indent=2)+'\n',encoding='utf-8');raise
