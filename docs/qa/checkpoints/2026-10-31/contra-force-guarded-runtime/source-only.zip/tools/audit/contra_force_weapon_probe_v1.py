"""Run original CF projectile Main in an explicit empty-source-world CPU arena.

This is a donor-engine measurement, not an SMB host or native replay. Every
shot is allocated by the original player weapon routine before source8132.
"""
from pathlib import Path
import hashlib,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit')]
import contra_force_engine_probe_v1 as T
from verify_native_relocation import NesMPU
O=R/'build/contra-force-weapon-probe-v1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
class Mem(T.Mem):
 def pair(self,lo):
  self.reg[6:8]=[lo,lo+1];self[0x36]={0:0,4:2,10:1}[lo];self.map()
def machine(var,gear):
 m=Mem();m.pair(4);m[0xb1]=var;m[0x7f+var]=16|gear;m[0x782]=46
 m[0x64e]=112;m[0x668]=168;m[0x682]=10;m[0x7d2]=1
 return NesMPU(memory=m)
def slots(m):
 return [dict(slot=i,kind=m[0x682+i],x=m[0x64e+i],y=m[0x668+i],
              speed=m[0x69c+i],direction=m[0x6b2+i],
              fractionX=m[0x6c8+i],fractionY=m[0x6de+i],
              animation=[m[0x61a+i],m[0x634+i]],age=m[0x720+i])
         for i in range(10,22)if m[0x682+i]]
def main():
 assert not O.exists();O.mkdir()
 d=dict(passed=False,native=False,host=False,
        boundary='Actual original8132 with original bank13 world collision tables; source world RAM zero/empty and no native actors. Not an SMB collision proof.',rows=[])
 try:
  for var in range(4):
   for gear in range(3):
    c=machine(var,gear);m=c.memory
    T.step(c,0x40);initial=slots(m);assert initial,(var,gear)
    seq=[]
    for age in range(48):
     m[0x23]=(m[0x23]+1)&255
     z=T.call(c,0x8132)
     assert m.reg[6:8]==[4,5]and m[0x36]==2
     seq.append(dict(age=age,cpu=z['CPU'],active=slots(m)))
    moved=any(any(p['x']!=initial[0]['x']or p['y']!=initial[0]['y']for p in z['active'])for z in seq)
    assert moved,('original shot did not move',var,gear,initial,seq)
    d['rows'].append(dict(variant=var,gear=gear,initial=initial,updates=seq))
    print(f'original weapon {var}/{gear} PASS',flush=True)
  d['passed']=True
 except Exception as e:
  d.update(error=repr(e),traceback=traceback.format_exc());raise
 finally:
  files=[Path(__file__),Path(T.__file__),R/'tools/audit/verify_native_relocation.py',T.P/'candidate.nes',T.P/'proof.json']
  d['bindings']={str(p.resolve()):sha(p)for p in files}
  p=O/'controls.json';p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
  print(json.dumps(dict(passed=d['passed'],path=str(p),sha256=sha(p),error=d.get('error'))),flush=True)
if __name__=='__main__':main()
