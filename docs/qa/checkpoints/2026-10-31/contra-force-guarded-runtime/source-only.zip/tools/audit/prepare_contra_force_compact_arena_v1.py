"""Link projected CF source in a flat CPU arena with explicit oracle gates.

This is NOT a cartridge or granted A1/C2 layout. Unimplemented world/mapper/
audio services have BRK entries intercepted by the CPU fixture and executed
in the original donor ROM. Never describe those oracle services as SMB hooks.
"""
from pathlib import Path
import hashlib,json,re,subprocess,sys
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit')]
from private_build_outputs_v1 import validate
P=R/'build/contra-force-component-closure-v5/object'
O=R/'build/contra-force-compact-arena-v1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert not O.exists();O.mkdir()
d=json.loads((P/'source-object-proof.json').read_text())
for p,h in d['bindings'].items():assert sha(p)==h,p
page={0:0,2:1,3:2,6:3,7:4}
assert set(z['original']//256 for z in d['field_map'].values())==set(page)
state=(P/'state.inc').read_text(encoding='utf-8').replace('CfState: .res $800','CfState: .res $500')
def mapped(m):
 a=int(m[1],16);return 'CfState+$%04x'%(page[a//256]*256+a%256)
state=re.sub(r'CfState\+\$([0-9a-fA-F]{4})',mapped,state)
(O/'state.inc').write_text(state,encoding='utf-8')
source=(P/'component.s').read_text(encoding='utf-8')
source+='\n.export CfNativeClear := sub_0x01F650\n.export CfNativeAnimation := ofs_006_0x009793_24\n'
(O/'component.s').write_text(source,encoding='utf-8')
imports=d['unresolved_genuine_source_services']
gates=['.segment "ORACLE_GATES"']
for n in imports:gates+=['.export '+n,n+': brk',' .byte 0']
(O/'oracle-gates.s').write_text('\n'.join(gates)+'\n',encoding='utf-8')
(O/'arena.cfg').write_text('''MEMORY {
 ZP:start=$0090,size=$10,type=rw,file="";
 RAM:start=$6000,size=$0500,type=rw,file="";
 CODE:start=$8000,size=$4000,type=ro,file=%O;
 GATES:start=$f000,size=$0100,type=ro,file="oracle-gates.bin";
}
SEGMENTS {
 CF_POINTERS:load=ZP,type=zp;
 CF_STATE:load=RAM,type=bss;
 CF_CORE:load=CODE,type=ro;
 CF_ANIMATION:load=CODE,type=ro;
 CF_METASPRITES:load=CODE,type=ro;
 ORACLE_GATES:load=GATES,type=ro;
}
''',encoding='utf-8')
ca=R/'tools/Windows/cc65/bin/ca65.exe';ld=ca.with_name('ld65.exe');logs=[]
commands=[]
for name in['component','oracle-gates']:
 commands.append([str(ca),'--cpu','6502x','-g','-I',str(R/'build/contra-force-reproduction-v2'),'--create-full-dep',str(O/(name+'.dep')),'-o',str(O/(name+'.o')),str(O/(name+'.s'))])
commands.append([str(ld),'-C',str(O/'arena.cfg'),'-o',str(O/'arena.bin'),'--dbgfile',str(O/'arena.dbg'),'-Ln',str(O/'arena.lbl'),'-m',str(O/'arena.map'),str(O/'component.o'),str(O/'oracle-gates.o')])
for cmd in commands:
 guard=validate(cmd,O,cwd=O);r=subprocess.run(cmd,cwd=O,capture_output=True,text=True)
 log=dict(command=cmd,output_guard=guard,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr);logs.append(log)
 (O/'build-log.json').write_text(json.dumps(logs,indent=2)+'\n',encoding='utf-8')
 assert r.returncode==0,log
out=dict(passed=True,status='LINKED_FLAT_CPU_ARENA_WITH_EXPLICIT_ORIGINAL_ROM_ORACLE_GATES_NOT_HOST',
         projected_state_bytes=1280,pointer_bytes=d['abstract_zero_page_bytes'],
         source_state_page_projection={hex(k*256):hex(v*256)for k,v in page.items()},
         source_code_and_data_bytes=len((O/'arena.bin').read_bytes()),
         original_services_executed_by_fixture_only=imports,
         allocation='None. Flat CPU test addresses6000/8000/F000 are not a current MMC5 lease.',
         physical_A1_C2_fit='Unproved: actual routine-boundary placement and complete SMB host glue remain.',
         bindings={str(p.resolve()):sha(p)for p in[Path(__file__),R/'tools/audit/private_build_outputs_v1.py',P/'source-object-proof.json',P/'component.s',P/'state.inc',ca,ld,*[p for p in O.iterdir()if p.is_file()]]})
p=O/'build-proof.json';p.write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8');print(json.dumps(dict(path=str(p),sha256=sha(p),source_bytes=out['source_code_and_data_bytes'],state=1280,pointers=out['pointer_bytes'])),flush=True)
