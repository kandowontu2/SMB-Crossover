"""Keep original bank-local branch identities unique in merged measurement."""
from pathlib import Path
import json,hashlib
R=Path(__file__).resolve().parents[2];P=Path(__file__).with_name('prepare_contra_force_component_closure_v1.py')
N=R/'build/contra-force-component-closure-v1/preparation-negative.json'
assert not N.exists()
N.write_text(json.dumps(dict(passed=False,failure='Original separate source banks reuse local branch bra_BAAB; v1 global symbol collector rejected duplicate before compilation.',tool=str(P),tool_sha256=hashlib.sha256(P.read_bytes()).hexdigest()),indent=2)+'\n',encoding='utf-8')
s=P.read_text(encoding='utf-8').replace('build/contra-force-component-closure-v1','build/contra-force-component-closure-v2')
mark='# These are real original services'
pre=r'''# Preserve each actual bank-local branch target when linking separate banks.
counts={}
for bank,text in banks.items():
 for name in re.findall(r'^(\w+):',text,re.M):counts.setdefault(name,set()).add(bank)
duplicates={name for name,owners in counts.items()if len(owners)>1}
for bank,text in banks.items():
 for name in duplicates:
  if bank in counts[name]:text=re.sub(r'\b'+re.escape(name)+r'\b','Cf'+bank+'_'+name,text)
 banks[bank]=text
'''
s=s.replace(mark,pre+'\n'+mark)
exec(compile(s,str(P),'exec'),{'__name__':'__main__','__file__':str(Path(__file__).resolve())})
