"""Advance linked genuine CF shot code against the original12 weapon Main.

World collision/source script/audio remain explicitly original-ROM oracle
services. This does not stand in for actual SMB shot impacts or rendering.
"""
from pathlib import Path
import hashlib,json,re,traceback
R=Path(__file__).resolve().parents[2]
P=Path(__file__).with_name('contra_force_compact_arena_controls_v1.py')
s=re.sub(r'\b(else|if)(?=\d)',r'\1 ',P.read_text(encoding='utf-8'))
s=s.replace("m=source_image(c);m.pair(0 if integration or name in['sub_B388','sub_BA51']else 4)","m=source_image(c)\n pair=0 if integration else m[0x36]\n m.reg[6:8]={0:[0,1],1:[10,11],2:[4,5],5:[4,6],13:[4,1]}[pair];m.map()")
s=s.replace('def call(c,name):','def call(c,name,x=0):').replace('c.a=c.x=c.y=0;c.p=0x24;c.sp=255;', 'c.a=c.y=0;c.x=x;c.p=0x24;c.sp=255;')
g={'__name__':'cf_definitions','__file__':str(P)};exec(compile(s,str(P),'exec'),g)
T,at,original,arena,call,oracle,compare,proof=[g[n]for n in['T','at','original','arena','call','oracle','compare','proof']]
O=R/'build/contra-force-compact-shot-controls-v1';assert not O.exists();O.mkdir()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
d=dict(passed=False,native=False,host=False,rows=[],scope='Actual linked source handler and animation; original-ROM collision/script/audio oracle; empty donor source-world. Not SMB contact or art proof.')
try:
 for p,h in proof['bindings'].items():assert sha(p)==h,p
 for var in range(4):
  for gear in range(3):
   z=original(var,gear);T.step(z,64);c=arena(z);rows=[]
   for age in range(48):
    z.memory[0x23]=(z.memory[0x23]+1)&255;c.memory[at(0x23)]=(c.memory[at(0x23)]+1)&255
    T.call(z,0x8132)
    c.memory[at(0x36)]=13;count=0
    for slot in range(10,22):
     if not c.memory[at(0x682+slot)]:continue
     c.memory[at(0x53)]=slot;c.x=slot;c.a=c.y=0;c.p=0x24
     # The original source3315 uses actual original pair13[4,1]. It remains
     # a declared world-query oracle, separate from the linked shot kernel.
     c.sp=253;c.memory[0x1fe:0x200]=[0xfe,0x7f]
     oracle(c,'sub_0x003315')
     if not c.memory[at(0x682+slot)]:continue
     a=call(c,'sub_0x0037C0',x=slot);b=call(c,'sub_9772',x=slot);count+=1
    c.memory[at(0x36)]=2
    compare(c,z,(var,gear,age))
    rows.append(dict(age=age,source_actor_updates=count,live=[dict(slot=i,kind=z.memory[0x682+i],x=z.memory[0x64e+i],y=z.memory[0x668+i],frame=z.memory[0x61a+i],group=z.memory[0x634+i])for i in range(10,22)if z.memory[0x682+i]]))
   d['rows'].append(dict(variant=var,gear=gear,updates=rows));print(f'projected original shots {var}/{gear} PASS',flush=True)
 d.update(passed=True,source_main_pairs=576,compared_actor_bytes_per_update=519)
except Exception as e:d.update(error=repr(e),traceback=traceback.format_exc());raise
finally:
 files=[Path(__file__),P,R/'tools/audit/verify_native_relocation.py',R/'build/contra-force-compact-arena-v2/build-proof.json',R/'build/contra-force-compact-arena-v2/arena.bin',R/'build/contra-force-compact-arena-v2/arena.dbg',T.P/'candidate.nes',T.P/'candidate.dbg']
 d['bindings']={str(p.resolve()):sha(p)for p in files}
 p=O/'controls.json';p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8');print(json.dumps(dict(path=str(p),sha256=sha(p),passed=d['passed'],error=d.get('error'))),flush=True)
