"""Use actual same-visible-frame OAM; retain late next-vblank priority negative."""
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parents[2];A=R/'tools/audit/export_contra_force_bodies_v3_generated.py';s=A.read_text().replace("build/contra-force-body-art-v3'","build/contra-force-body-art-v4'")
needle="assert any(chr),'Rejected zero-filled late-HUD pattern snapshot'";assert s.count(needle)==1
s=s.replace(needle,needle+"\n assert len(vis)==8532,'Visible OAM/DMA metadata missing'\n oam=vis[8271:8527];visible_dma_frame,visible_dma_page=struct.unpack_from('<IB',vis,8527);assert visible_dma_page==2")
s=s.replace("visible_scanline=160,visible_physical_CHR_offsets=physical", "visible_scanline=160,visible_OAM_byte_exact_DMA=True,visible_DMA_frame=visible_dma_frame,visible_DMA_page=visible_dma_page,visible_physical_CHR_offsets=physical")
p=R/'tools/audit/export_contra_force_bodies_v4_generated.py';assert not p.exists();p.write_text(s,newline='\n');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();O=R/'build/contra-force-body-export-builder-v4';O.mkdir();(O/'derivation.json').write_text(json.dumps(dict(before=str(A),before_sha256=sha(A),after=str(p),after_sha256=sha(p),negative='Only four native overlapped pixels disagreed using endFrame next-vblank rotated OAM. New capture latches actual same-visible-frame OAM and asserts equal to then-current DMA CPU buffer; no inferred rotation/pixel repair.'),indent=2)+'\n',newline='\n');print(json.dumps(dict(path=str(p),sha256=sha(p))))
