"""Real source-cart CF external auth/BT-tail API, no shared adoption/native."""
from pathlib import Path
import hashlib,json,itertools,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import contra_force_a2_router_controls_v2 as C
P=R/'build/contra-force-guarded-cart-v1';O=R/'build/contra-force-external-guard-controls-v1'
C.P=P;T=C.T;T.P=P;T.B=T.qualified(P/'joint/candidate.nes');T.PAYLOAD=(P/'joint/cf-stream.bin').read_bytes();T.COOKIE=(P/'joint/cf-cookie.bin').read_bytes()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def loaded(var=0):
 m=T.Bus();T.put(m,FmGroups=var<<3);T.checkpoint(m);c=T.cpu(m,public=True);T.finish(m,c);T.exact(m,var)
 m.writes.clear();m.ram_writes.clear();m.ppu_log.clear();m.executed_guest.clear();return m
def direct(m,a=0x57,p=0x30,x=0xa9,y=0x63):return T.cpu(m,'CfOrBtCheck',a=a,p=p,x=x,y=y)
def public(m,a=0x57,p=0x30,x=0xa9,y=0x63):return C.start(m,T.address(T.B,'CfOrBtCheck'),0xc5,a=a,p=p,x=x,y=y)

def flags():
 rows=[]
 for var in range(4):
  base=loaded(var)
  for p,a,rawC in itertools.product([v for v in range(256)if v&0x30==0x30],[0,3,105,108],[2,3,0xd8]):
   m=C.clone(base);m.raw_page(2,rawC);T.put(m,CurrentBankC=rawC)
   c=direct(m,a=a,p=p);before=(m.rawtags[:],T.smc(m),bytes(m[0x1e1:0x200]),[bytes(x)for x in m.ram]);z=T.finish(m,c)
   assert z['AXYP']==[a,0xa9,0x63,p|1],('direct fullAXYP',var,p,a,rawC,z['AXYP'])
   assert(m.rawtags,T.smc(m),bytes(m[0x1e1:0x200]),[bytes(x)for x in m.ram])==before
   assert T.get(m,'CurrentBankC')==rawC and not m.executed_guest and not m.ram_writes
   rows.append([var,p,a,rawC,z['CPU']])
 # Actual SFC caller A=3*service for every valid/clamped service and both
 # carry inputs. Its real LDA sourceA intentionally establishes N/Z.
 calls=[]
 base=loaded()
 for service,p in itertools.product(range(37),[0x30,0x79]):
  m=C.clone(base);c=public(m,a=service*3,p=p);z=T.finish(m,c)
  expect=(p&0x7c)|1|(0x80 if service*3&128 else 0)|(2 if service==0 else 0)
  assert z['AXYP']==[service*3,0xa9,0x63,expect],(service,p,z['AXYP'],expect)
  assert m.rawtags==base.rawtags and not m.executed_guest and not m.ram_writes
  calls.append([service,p,z['CPU']])
 return dict(direct_all64_flags_classes_rawC_cases=len(rows),actual_SFC_service_calls=calls,fullAXYP_except_validityC_preserved=True,no_C2_or_other_guest_opcode_or_write=True,all33SMC_and_live_upper_page1_exact=True,rows=rows)

def failures():
 base=loaded();rows=[]
 for i,p in itertools.product(range(16),[v for v in range(256)if v&0x30==0x30]):
  m=C.clone(base);m.ram[2][0x1fe0+i]^=1;before=[bytes(x)for x in m.ram]
  c=direct(m,p=p);z=T.finish(m,c)
  assert z['AXYP']==[0x57,0xa9,0x63,p&254]and [bytes(x)for x in m.ram]==before and not m.executed_guest and not m.ram_writes
  rows.append([i,p,z['CPU']])
 wrong=[]
 for family,var in itertools.product([0,9,32,33,255],range(4)):
  m=C.clone(base)
  # Deliberate unrelated payload including BRK at every potential A2 entry.
  # ROM auth must reject BEFORE even one opcode from this bank executes.
  m.ram[2][:]=bytes(8192);m.ram[2][0x1fe0:0x1fe4]=bytes([0xa7,family,var,1]);T.put(m,FmGroups=var<<3)
  c=public(m);z=T.finish(m,c)
  assert not c.p&1 and not m.executed_guest and not m.ram_writes
  wrong.append([family,var,z['CPU']])
 return dict(poisoned_full16_all64_flag_cases=len(rows),foreign_payload_BRK_first_opcode_rejections=wrong,all_no_guest_execution_or_write=True,rows=rows)

def bt_tail():
 rows=[];base=loaded()
 off=T.location(T.B,'BtCookie');cookie=T.B['raw'][off:off+16]
 assert(cookie[0],cookie[1])==(0xa7,33)
 for selected,valid,p,a in itertools.product([0,27,31,32,33,255],[0,1],[0x30,0x79],[0,3,105]):
  if selected==31:continue
  pair=[]
  for guarded in[False,True]:
   m=C.clone(base);T.put(m,SelectedCharacter=selected);m.ram[3][0x1fe0:0x1ff0]=cookie if valid else bytes(16)
   c=public(m,a=a,p=p)if guarded else C.start(m,T.address(T.B,'BtCheck'),0xdd,a=a,p=p,x=0xa9,y=0x63)
   z=T.finish(m,c)
   pair.append((z['AXYP'],m.rawtags[:],T.smc(m),bytes(m[0x1e1:0x200]),[bytes(x)for x in m.ram],z['CPU']))
  assert pair[0][:5]==pair[1][:5],('genuine BtCheck tail ABI',selected,valid,p,a,pair[0][0],pair[1][0])
  rows.append([selected,valid,p,a,pair[1][5]-pair[0][5]])
 return dict(actual_BtCheck_API_pairs=len(rows),fullAXYP_SP_rawmaps_33SMC_cache_exact=True,explicit_BT_cookie_preload_fixture=True,no_BT_loader_claim=True,rows=rows)

def guarded_source():
 rows=[]
 for var in range(4):
  m=loaded(var);T.put(m,PlayerStatus=0,Player_X_Position=120,Player_PageLoc=0,Player_Y_Position=176,Player_Y_HighPos=1,ScreenLeft_X_Pos=0,ScreenLeft_PageLoc=0,PlayerFacingDir=1,Player_State=0,SavedJoypadBits=1)
  c=public(m,a=45);T.finish(m,c);assert c.p&1 and not m.executed_guest
  c=C.start(m,C.L['CfServiceVeneers']+45,2);T.finish(m,c);assert m.ram[2][0x2e1]==1 and m.ram[2][0xb1]==var
  before=T.get(m,'Player_X_Position')
  for age in range(8):
   c=public(m,a=0);T.finish(m,c);assert c.p&1
   c=C.start(m,C.L['CfServiceVeneers'],2);T.finish(m,c)
  assert T.get(m,'Player_X_Position')>before and m.ram[2][0x23]==8
  rows.append(dict(variant=var,source_steps=8,x_before=before,x_after=T.get(m,'Player_X_Position')))
 return dict(actual_external_ROM_guard_then_source_constructor_movement=rows,scope='Actual genuine SFC guard and owned A2/source workers, sequential manual API calls. Shared resolver/menu/InitScreen chain and native Main are not installed.')

def main():
 assert not O.exists();O.mkdir();d=dict(passed=False,native=False,actual_shared_ingress=False,CF_RAM_preload=False,checks={})
 try:
  for p,h in json.loads((P/'source-stage.json').read_text())['bindings'].items():assert sha(p)==h,p
  for n,f in[('flags',flags),('failures',failures),('bt_tail',bt_tail),('guarded_source',guarded_source)]:d['checks'][n]=f();print('CF external guard',n,'PASS',flush=True)
  d['passed']=True
 except Exception as e:d.update(failure=repr(e),traceback=traceback.format_exc());raise
 finally:
  paths=[Path(__file__),Path(C.__file__),Path(T.__file__),P/'source-stage.json',P/'joint/candidate.nes',P/'joint/candidate.dbg',P/'joint/cf-stream.bin',P/'joint/cf-cookie.bin',C.K/'runtime.lbl',R/'tools/reference/contra_force_rom_guard_v1.s']
  d['bindings']={str(p.resolve()):sha(p)for p in paths};path=O/'controls.json';path.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(path=str(path),sha256=sha(path),passed=d['passed'],failure=d.get('failure'))),flush=True)

if __name__=='__main__':main()
