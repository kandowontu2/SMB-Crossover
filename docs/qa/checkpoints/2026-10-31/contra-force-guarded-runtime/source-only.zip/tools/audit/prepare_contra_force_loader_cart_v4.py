"""Source-build an inert CF bootstrap/carrier successor of the current64 ROM.

Existing frontend remains pending. Guest images still have declared source
callback obligations; they are NOT exposed through Main/readiness by this
loader-only stage. No old source/object/output is modified.
"""
from pathlib import Path
import hashlib,json,re,subprocess,sys
R=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
from private_build_outputs_v1 import validate
from prepare_ff_current_component_v2 import qualified
from prepare_cv3_dmc_mirror import prepare as mirror
P=R/'build/peach-palette-fix-1030-v1'
K=R/'build/contra-force-a2-router-v1'
O=R/'build/contra-force-loader-cart-v4'
J=O/'joint'
GRANT=R/'docs/qa/checkpoints/2026-10-31/contra-force-loader-resources/root-review-and-reservations.json'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def bound(d):
 for p,h in d['bindings'].items():assert sha(p)==h,p

def write_json(path,d):path.write_text(json.dumps(d,indent=2)+'\n')

def private_side_files(text,prefix):
 index=0;changes=[]
 def swap(m):
  nonlocal index
  value=m[1]
  if value in['','%O']:return m[0]
  target=J/'sideoutputs'/prefix/('%02d-'%index+Path(value).name);index+=1
  target.parent.mkdir(parents=True,exist_ok=True);changes.append([value,str(target)])
  return 'file="'+target.as_posix()+'"'
 return re.sub(r'file\s*=\s*"([^"]*)"',swap,text),changes

def main():
 assert not O.exists();J.mkdir(parents=True)
 parent=json.loads((P/'handoff.json').read_text());bound(parent)
 assert parent['candidate']=='f56e55cd69b93821e66548848305cf9822e2ac0e8a25752d7192332cded53b78'
 grant=json.loads(GRANT.read_text());bound(grant)
 assert sha(GRANT)=='bdfde94b0fdb0af309607a67da7ccba23edc74e63ee57cbb178565550ff6a780'
 kernel=json.loads((K/'build-proof.json').read_text());bound(kernel)
 original=json.loads((P/'final-link.json').read_text())['command']
 objects=[v for v in original if Path(v).suffix.lower()=='.o']
 for p in objects:assert parent['bindings'].get(str(Path(p).resolve()))==sha(p),('Original link input not parent-bound',p)
 cl=R/'tools/Windows/cc65/bin/cl65.exe';ca=cl.with_name('ca65.exe');logs=[]
 def run(cmd):
  guard=validate(cmd,O,cwd=R);p=subprocess.run(cmd,cwd=R,capture_output=True,text=True)
  row=dict(command=cmd,cwd=str(R),output_guard=guard,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr)
  logs.append(row);write_json(O/'commands.json',logs);assert p.returncode==0,row
 def link(config,name,objs):
  run([str(cl),'--cpu','6502x','-t','nes','-C',str(config),'-Ln',str(J/(name+'.lbl')),'--ld-args','--dbgfile,'+str(J/(name+'.dbg')),'-o',str(J/(name+'.nes')),*objs,'-m',str(J/(name+'.map'))])
  mirror(R,J/(name+'.nes'))
 cfg=(P/'joint/private.cfg').read_text()
 baseline,basefiles=private_side_files(cfg,'baseline');(J/'baseline.cfg').write_text(baseline)
 link(J/'baseline.cfg','baseline',objects)
 assert sha(J/'baseline.nes')==parent['candidate'],'Exact current source reproduction required first'
 # Prepare a real full24KiB carrier from source-linked guest images. Stale
 # C2 andRAM3 validity are never present in the source stream itself.
 banks=[]
 for bank in[1,2,3]:
  data=bytearray((K/f'ram{bank}.bin').read_bytes());data.extend([0]*(8192-len(data)))
  assert len(data)==8192
  if bank in[2,3]:data[0x1fe0:0x2000]=bytes(32)
  (J/f'cf-ram{bank}.bin').write_bytes(data);banks.append(bytes(data))
 payload=b''.join(banks);(J/'cf-stream.bin').write_bytes(payload)
 cookie=bytes([0xa7,31,0,1])+hashlib.sha256(payload).digest()[:12]
 (J/'cf-cookie.bin').write_bytes(cookie)
 source=(R/'tools/reference/contra_force_loader_proposal_v1.s').read_text()
 old=' .byte $a7,$1f,0,1\n .res 12,0                    ; MEASUREMENT ONLY, final payload SHA required'
 assert source.count(old)==1
 source=source.replace(old,'.incbin "'+(J/'cf-cookie.bin').as_posix()+'"')
 (J/'cf-loader.s').write_text(source)
 body=R/'build/contra-force-body-pack-v3/atlas.chr';shots=R/'build/contra-force-shot-pack-v1/atlas.chr'
 carrier='.segment "CF_CARRIER"\n.incbin "'+(J/'cf-stream.bin').as_posix()+'"\n.segment "CF_BODY_CHR"\n.incbin "'+body.as_posix()+'"\n.segment "CF_SHOT_CHR"\n.incbin "'+shots.as_posix()+'"\n'
 (J/'cf-carrier.s').write_text(carrier)
 config,newfiles=private_side_files(cfg,'candidate')
 before='X5_NEW_73: start=$a000, size=$2000, type=ro, file=%O, fill=yes, fillval=$ff, bank=$73;'
 after='X5_NEW_73:start=$a000,size=$1f38,type=ro,file=%O,fill=yes,fillval=$ff,bank=$73;\n CF_LOADER_A_MEM:start=$bf38,size=$93,type=ro,file=%O,fill=yes,fillval=$ff,bank=$73;\n CF_LOADER_A_TAIL:start=$bfcb,size=$35,type=ro,file=%O,fill=yes,fillval=$ff,bank=$73;'
 assert config.count(before)==1;config=config.replace(before,after)
 before='X5_NEW_4E: start=$a000, size=$2000, type=ro, file=%O, fill=yes, fillval=$ff, bank=$4e;'
 after='X5_NEW_4E:start=$a000,size=$e68,type=ro,file=%O,fill=yes,fillval=$ff,bank=$4e;\n CF_LOADER_C_MEM:start=$ce68,size=$12e,type=ro,file=%O,fill=yes,fillval=$ff,bank=$4e;\n CF_LOADER_C_TAIL:start=$af96,size=$106a,type=ro,file=%O,fill=yes,fillval=$ff,bank=$4e;'
 assert config.count(before)==1;config=config.replace(before,after)
 config=config.replace('ROLL_WORLD:load=X5_NEW_4E,','ROLL_WORLD:load=CF_LOADER_C_TAIL,').replace('ROGUE_AUDIO_PAGES_4: load=X5_NEW_4E,','ROGUE_AUDIO_PAGES_4: load=CF_LOADER_C_TAIL,')
 before='UNALLOCATED_CHR_MEM:start=$e1400,size=$1ec00,type=ro,fill=yes,file=%O,fillval=$00;'
 after='UNALLOCATED_CHR_MEM:start=$e1400,size=$8800,type=ro,fill=yes,file=%O,fillval=$00;\n CF_CARRIER_MEM:start=$e9c00,size=$6000,type=ro,fill=yes,file=%O,fillval=$00;\n CF_BODY_CHR_MEM:start=$efc00,size=$2400,type=ro,fill=yes,file=%O,fillval=$00;\n CF_SHOT_CHR_MEM:start=$f2000,size=$400,type=ro,fill=yes,file=%O,fillval=$00;\n CF_CHR_TAIL:start=$f2400,size=$dc00,type=ro,fill=yes,file=%O,fillval=$00;'
 assert config.count(before)==1;config=config.replace(before,after)
 insert=' CF_LOADER_PROPOSAL_A:load=CF_LOADER_A_MEM,type=ro;\n CF_LOADER_PROPOSAL_C:load=CF_LOADER_C_MEM,type=ro;\n CF_CARRIER:load=CF_CARRIER_MEM,type=ro;\n CF_BODY_CHR:load=CF_BODY_CHR_MEM,type=ro;\n CF_SHOT_CHR:load=CF_SHOT_CHR_MEM,type=ro;\n'
 config=config.replace('SEGMENTS {','SEGMENTS {\n'+insert);(J/'private.cfg').write_text(config)
 extras=[]
 for name in['cf-loader','cf-carrier']:
  obj=J/(name+'.o');extras.append(str(obj))
  run([str(ca),'--cpu','6502x','-g','--create-full-dep',str(J/(name+'.dep')),'-o',str(obj),str(J/(name+'.s'))])
 # Genuine zero-byte native export, with all actual source includes retained.
 wrapper=J/'main-export.s';wrapper.write_text('.export FmGroups\n.include "entrypoint.s"\n')
 maincmd=json.loads((P/'main-build.json').read_text())['command'][:]
 assert maincmd[-1]==str(P/'joint/entrypoint.s'),maincmd[-1]
 maincmd[-1]=str(wrapper)
 for flag,output in[('-o',J/'main-export.o'),('--create-full-dep',J/'main-export.dep')]:
  index=maincmd.index(flag)+1;maincmd[index]=str(output)
 run(maincmd)
 current_main=str(P/'joint/main.o');assert objects.count(current_main)==1
 objects=[str(J/'main-export.o')if v==current_main else v for v in objects]
 link(J/'private.cfg','candidate',objects+extras)
 old,new=qualified(P/'joint/candidate.nes'),qualified(J/'candidate.nes')
 assert len(old['raw'])==len(new['raw'])
 moves={n:[d['val'],new['syms'].get(n,{}).get('val')]for n,d in old['syms'].items()if new['syms'].get(n,{}).get('val')!=d['val']}
 assert not moves,('Existing qualified source symbol moved',moves)
 allowed=[]
 for row in grant['ROM']:allowed.append([16+row['physical_bank']*8192+row['first_offset'],16+row['physical_bank']*8192+row['end_offset_exclusive']])
 allowed.append([16+1048576+935*1024,16+1048576+969*1024])
 delta=[i for i,(a,b)in enumerate(zip(old['raw'],new['raw']))if a!=b]
 assert delta and all(any(a<=i<b for a,b in allowed)for i in delta)
 assert new['raw'][:16]==old['raw'][:16]
 assert new['raw'][16+1048576+935*1024:16+1048576+959*1024]==payload
 assert new['raw'][16+1048576+959*1024:16+1048576+968*1024]==body.read_bytes()
 assert new['raw'][16+1048576+968*1024:16+1048576+969*1024]==shots.read_bytes()
 bound(parent);bound(kernel);bound(grant)
 out=dict(passed=True,status='SOURCE_LINKED_INERT_CF_BOOTSTRAP_CARRIER_FRONTEND_PENDING',source=True,native=False,ready=False,installed=False,
          parent=parent['candidate'],candidate=sha(J/'candidate.nes'),exact_parent_source_reproduction=sha(J/'baseline.nes'),
          actual_source_symbol_pairs_preserved=len(old['syms']),header_unchanged=True,allowed_changed_ranges=allowed,changed_bytes=len(delta),
          payload_sha256=hashlib.sha256(payload).hexdigest(),cookie=cookie.hex(),kernel_source=str(K/'build-proof.json'),
          actual_loader_ROM_ranges=grant['ROM'],private_side_output_rebindings=basefiles+newfiles,
          scope='Bootstrap is genuinely linked/callable at its own ROM entries; no native/shared InitScreen operand or frontend readiness changed. Full code/data/CHR are source producers; actual source/native boundaries and own A2 router are present. Shared ingress, cold lifecycle and P1 ownership remain unimplemented; not playable Main.',
          bindings={**parent['bindings'],str((P/'handoff.json').resolve()):sha(P/'handoff.json'),str((K/'build-proof.json').resolve()):sha(K/'build-proof.json'),str(GRANT.resolve()):sha(GRANT),str(Path(__file__).resolve()):sha(__file__),str((R/'tools/audit/private_build_outputs_v1.py').resolve()):sha(R/'tools/audit/private_build_outputs_v1.py')})
 # Explicit dictionary update avoids any implicit file enumeration outside
 # this new root; every source/cart/side output in it is a concrete receipt.
 out['bindings'].update({str(p.resolve()):sha(p)for p in O.rglob('*')if p.is_file()})
 path=O/'source-stage.json';write_json(path,out)
 print(json.dumps(dict(path=str(path),sha256=sha(path),candidate=out['candidate'],preserved_symbols=len(old['syms']),changed_bytes=len(delta))),flush=True)

if __name__=='__main__':main()

