"""Pack actual class/gear/aim/air-selected CF shot frames into one window.

NormalP3 source yellow/white/red ownership is an explicit future host protocol;
this tool neither writes palettes nor assumes the worldP3 palette is unused.
"""
from pathlib import Path
import hashlib,itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit')]
import contra_force_engine_probe_v1 as T
from verify_native_relocation import NesMPU
O=R/'build/contra-force-shot-pack-v1';assert not O.exists();O.mkdir()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
CHR=T.RAW[16+131072:]
class Mem(T.Mem):
 def pair(self,lo):
  self.reg[6:8]=[lo,lo+1];self[0x36]={0:0,4:2,10:1}[lo];self.map()
def machine(var,gear):
 m=Mem();m.pair(4);m[0xb1]=var;m[0x7f+var]=16|gear;m[0x782]=46;m[0x64e]=128;m[0x668]=128;m[0x682]=10;m[0x7d2]=1
 return NesMPU(memory=m)
def render(c,frame,high):
 m=c.memory;m.pair(0);slot=10
 m[0x64e+slot]=128;m[0x668+slot]=128;m[0x634+slot]=high;m[0x61a+slot]=frame;m[0x600+slot]=0
 for i in range(64):m[0x200+4*i]=244
 m[8]=slot;m[1]=64;T.call(c,0xd35b,a=frame,x=0,y=slot)
 return [dict(oam=i,x=m[0x203+4*i],y=m[0x200+4*i],tile=m[0x201+4*i],attr=m[0x202+4*i])for i in range(64)if m[0x200+4*i]<240]
def pattern(tile,banks):
 start=(tile&1)*4096+(tile&254)*16
 return bytes(CHR[banks[(start+i)//1024]*1024+(start+i)%1024]for i in range(32))
def values(pair):
 return [((pair[(y//8)*16+y%8]>>(7-x))&1)|(((pair[(y//8)*16+y%8+8]>>(7-x))&1)<<1)for y in range(16)for x in range(8)]
def encode(v):
 p=bytearray(32)
 for y in range(16):
  for x in range(8):
   n=v[y*8+x];at=(y//8)*16+y%8;p[at]|=(n&1)<<(7-x);p[at+8]|=((n>>1)&1)<<(7-x)
 return bytes(p)
def pixels(parts,pal):
 out={}
 for p in reversed(parts):
  v=values(p['pattern']);a=p['attr']
  for y in range(16):
   for x in range(8):
    n=v[(15-y if a&128 else y)*8+(7-x if a&64 else x)]
    if n:out[(p['x']+x,p['y']+1+y)]=(pal[a&3][n],a&32)
 return out
def lines(parts):
 return max([0]+[sum(p['y']+1<=y<p['y']+17 for p in parts)for y in range(240)])
d=dict(passed=False,native=False,host=False,cohorts=[],views=[],scope='Actual source action-selected frame superset in216 class/gear/aim/ground-air cohorts, original projectileMain and canonical originalOAM rendering. Pixel/priority atlas only; worldpalette protocol/host/native still pending.')
try:
 observed={};cohorts=[]
 for var,gear,pad,air in itertools.product(range(4),range(3),[0,1,2,4,5,6,8,9,10],[False,True]):
  c=machine(var,gear);m=c.memory
  if air:m[0x7aa]=64;m[0x7b4]=128;m[0x7d2]=0
  T.step(c,pad|64,ground=not air);seen=set()
  for age in range(96):
   m.pair(4);m[0x23]=(m[0x23]+1)&255;T.call(c,0x8132)
   for slot in range(10,22):
    if m[0x682+slot]and m[0x61a+slot]:
     key=(var,m[0x61a+slot],m[0x634+slot]);seen.add(key);observed.setdefault(key,dict(variant=var,gear=gear,pad=pad,air=air,age=age,kind=m[0x682+slot]))
  cohorts.append(dict(variant=var,gear=gear,pad=pad,air=air,frame_keys=[list(k)for k in sorted(seen)]))
 patterns=[];rows=[]
 for(var,frame,high),witness in sorted(observed.items()):
  c=machine(var,0);m=c.memory;m.pair(10);T.call(c,0x97cf);banks=[48,49,50,51,m[0x79],m[0x7a],0,13]
  T.call(c,0xf4b1,a=0,y=2);native=[list(m[0x3b0+16+i*4:0x3b0+20+i*4])for i in range(4)]
  source=render(c,frame,high)
  for p in source:p['pattern']=pattern(p['tile'],banks)
  target=[]
  for p in source:
   role=p['attr']&3;v=values(p['pattern'])
   if role in[0,3]:target.append(dict(p))
   elif role==1:
    for role2,val in[(0,[n if n in[1,3]else 0 for n in v]),(2,[1 if n==2 else 0 for n in v])]:
     if any(val):target.append({**p,'attr':(p['attr']&252)|role2,'pattern':encode(val)})
   else:raise AssertionError(('unimplemented actual source color role',witness,frame,high,role))
  want=pixels(source,native);actual=pixels(target,[[15,55,18,15],[0,0,0,0],[15,22,48,39],[15,32,56,22]])
  assert want==actual,(witness,frame,high,'color/opaque/priority')
  assert lines(target)<=8,(witness,frame,high,'intrinsic scanline',lines(target))
  for p in target:
   pair=p.pop('pattern')
   if pair not in patterns:patterns.append(pair)
   p['local_pair']=patterns.index(pair);p['target_window6_tile']=129+2*p['local_pair']
  rows.append(dict(frame=frame,high=high,variant=var,source_witness=witness,opaque_pixels=len(want),source_parts=len(source),target_parts=target,maximum_line=lines(target)))
 assert len(patterns)<=32,('one granted1KBshot page cannot fit',len(patterns),32*len(patterns))
 atlas=b''.join(patterns).ljust(1024,b'\0');(O/'atlas.chr').write_bytes(atlas)
 d.update(passed=True,cohorts=cohorts,views=rows,unique_pairs=len(patterns),CHR_bytes=len(atlas),target_window=6,maximum_target_parts=max(len(v['target_parts'])for v in rows),maximum_scanline=max(v['maximum_line']for v in rows),palette_policy='SourceP0 laser exact; sourceP1 white/black remapP0 +red-only nativeP2; sourceP3 exact20/38/16 requires approved complete worldP3 ownership/restore protocol. No hardware palette publisher implemented.')
except Exception as e:d.update(error=repr(e),traceback=traceback.format_exc(),cohorts=cohorts,views=rows if 'rows'in locals()else[]);raise
finally:
 files=[Path(__file__),Path(T.__file__),R/'tools/audit/verify_native_relocation.py',T.P/'candidate.nes',T.P/'proof.json',R/'build/contra-force-body-art-v6/manifest.json']
 if(O/'atlas.chr').exists():files.append(O/'atlas.chr')
 d['bindings']={str(p.resolve()):sha(p)for p in files}
 p=O/'packing.json';p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8');print(json.dumps(dict(passed=d['passed'],path=str(p),sha256=sha(p),views=len(d['views']),pairs=d.get('unique_pairs'),error=d.get('error'))),flush=True)
