"""Execute granted CF bank phases against the frozen flat source projection.

Donor world/audio/script calls are explicit test oracles in both versions.
No SMB world, loader, ISR, native playback, or admission is claimed.
"""
from pathlib import Path
import hashlib,json,re,sys,traceback

R=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(R/'tools/audit')]
from verify_native_relocation import NesMPU
P=R/'build/contra-force-runtime-split-v1'
O=R/'build/contra-force-runtime-split-controls-v1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

base=R/'tools/audit/contra_force_compact_arena_controls_v1.py'
s=re.sub(r'\b(else|if)(?=\d)',r'\1 ',base.read_text())
s=s.replace('build/contra-force-compact-arena-v2','build/contra-force-jump-adaptation-v1')
s=s.replace("m=source_image(c);m.pair(0 if integration or name in['sub_B388','sub_BA51']else 4)",
            "m=source_image(c)\n pair=0 if integration else m[0x36]\n m.reg[6:8]={0:[0,1],1:[10,11],2:[4,5],5:[4,6],13:[4,1]}[pair];m.map()")
s=s.replace('def call(c,name):','def call(c,name,x=0):')
s=s.replace('c.a=c.x=c.y=0;c.p=0x24;c.sp=255;', 'c.a=c.y=0;c.x=x;c.p=0x24;c.sp=255;')
g={'__name__':'cf_reference_definitions','__file__':str(base)}
exec(compile(s,str(base),'exec'),g)
T,reference_at,original,reference_arena,reference_call,reference_oracle,reference_step=[g[n]for n in[
 'T','at','original','arena','call','oracle','step']]
proof=json.loads((P/'build-proof.json').read_text())
L=g['labels'](P/'runtime.dbg')
G={L[n]:n for n in proof['original_services_executed_by_fixture_only']}
page={0:0,2:1,3:2,6:3,7:4}

def at(a):return L['CfState']+page[a//256]*256+a%256

class Mem:
 def __init__(self):
  self.ram=[0]*65536
  self.banks={n:bytearray((P/f'ram{n}.bin').read_bytes())for n in[1,2,3]}
  self.banks[2].extend([255]*(8192-len(self.banks[2])))
  self.ram[0xf000:0xf000+len((P/'oracle-gates.bin').read_bytes())]=(P/'oracle-gates.bin').read_bytes()
  self.a_bank=1;self.c_bank=2;self.writes=[]
  self.ram[L['CurrentBank']]=1
 def __getitem__(self,a):
  if isinstance(a,slice):return[self[i]for i in range(*a.indices(65536))]
  if 0xa000<=a<0xc000:return self.banks[self.a_bank][a-0xa000]
  if 0xc000<=a<0xe000:return self.banks[self.c_bank][a-0xc000]
  return self.ram[a]
 def __setitem__(self,a,v):
  if isinstance(a,slice):
   for i,w in zip(range(*a.indices(65536)),v):self[i]=w
   return
  v&=255
  if a==0x5115:self.a_bank=v;self.writes.append((a,v));assert v in[1,3]
  elif a==0x5116:self.c_bank=v;self.writes.append((a,v));assert v==2
  elif 0xa000<=a<0xc000:self.banks[self.a_bank][a-0xa000]=v
  elif 0xc000<=a<0xe000:self.banks[self.c_bank][a-0xc000]=v
  else:self.ram[a]=v

def arena(z):
 m=Mem()
 for old in page:m[at(old*256):at(old*256)+256]=z.memory[old*256:old*256+256]
 return NesMPU(memory=m)

def donor_oracle(c,name=None,integration=False):
 m=g['OriginalMem']()
 for old in page:m[old*256:old*256+256]=c.memory[at(old*256):at(old*256)+256]
 pair=0 if integration else m[0x36]
 m.reg[6:8]={0:[0,1],1:[10,11],2:[4,5],5:[4,6],13:[4,1]}[pair];m.map()
 z=NesMPU(memory=m);z.a,z.x,z.y,z.p=c.a,c.x,c.y,c.p
 z.sp=c.sp+2 if name else 255
 z.stPushWord(0x7ffe);z.pc=0xbce0 if integration else g['N'][name]
 count=0
 while z.pc!=0x7fff:
  assert count<30000 and z.memory[z.pc],('Original donor bound/BRK',name,hex(z.pc))
  z.step();count+=1
 for old in page:c.memory[at(old*256):at(old*256)+256]=z.memory[old*256:old*256+256]
 c.a,c.x,c.y,c.p=z.a,z.x,z.y,z.p
 if integration:c.memory[at(0x36)]=2
 else:c.pc=(c.stPopWord()+1)&65535
 return count

def call(c,name,x=0):
 # Explicit test ingress maps the source phase. Actual outer ROM router is
 # intentionally not substituted by this test setup.
 bank=3 if name in['CfNativeShot','sub_0x0037C0']else 1
 c.memory.a_bank=bank;c.memory.ram[L['CurrentBank']]=bank
 c.pc=L[name];c.a=c.y=0;c.x=x;c.p=0x24;c.sp=255;c.stPushWord(0x7ffe)
 steps=0;services={};start=c.processorCycles
 while c.pc!=0x7fff:
  assert steps<30000,('Split source bound',name,hex(c.pc),c.memory.a_bank)
  if c.pc in G:
   service=G[c.pc];services[service]=services.get(service,0)+1;donor_oracle(c,service)
  else:
   assert c.memory[c.pc],('Split BRK',name,hex(c.pc),c.memory.a_bank)
   c.step()
  steps+=1
 assert c.sp==255 and c.memory.a_bank==bank and c.memory[L['CurrentBank']]==bank,(name,c.sp,c.memory.a_bank)
 return dict(instructions=steps,cycles=c.processorCycles-start,donor_oracles=services)

def step(c,pad,ground):
 m=c.memory;m[at(0x23)]=(m[at(0x23)]+1)&255
 m[at(0x40)]=pad&~m[at(0x42)];m[at(0x42)]=pad
 rows=[call(c,'CfNativeClear')];m[at(0x7d2)]=1 if ground else 0
 rows.extend([call(c,'CfNativeInput'),call(c,'CfNativeBody')])
 c.a=c.x=c.y=0;c.p=0x24;donor_oracle(c,integration=True)
 return rows

def compare(c,ref,context):
 for a in[0x7f+i for i in range(4)]+[0x83,0xb1,0xc0]+list(range(0x600,0x800)):
  assert c.memory[at(a)]==ref.memory[reference_at(a)],(context,hex(a),c.memory[at(a)],ref.memory[reference_at(a)])

def shots(c,split):
 a=at if split else reference_at;invoke=call if split else reference_call;oracle=donor_oracle if split else reference_oracle
 c.memory[a(0x23)]=(c.memory[a(0x23)]+1)&255;c.memory[a(0x36)]=13
 for slot in range(10,22):
  if not c.memory[a(0x682+slot)]:continue
  c.memory[a(0x53)]=slot;c.x=slot;c.a=c.y=0;c.p=0x24;c.sp=253;c.memory[0x1fe:0x200]=[0xfe,0x7f]
  oracle(c,'sub_0x003315')
  if not c.memory[a(0x682+slot)]:continue
  invoke(c,'CfNativeShot'if split else'sub_0x0037C0',x=slot)
  invoke(c,'CfNativeAdvance'if split else'sub_9772',x=slot)
 c.memory[a(0x36)]=2

def main():
 assert not O.exists();O.mkdir()
 out=dict(passed=False,native=False,host=False,scope='Actual rawA1/A3/C2 split engine against frozen flat adapted-source projection. Explicit original donor world/script/audio callbacks and donor position integration remain test boundaries.',rows=[])
 try:
  for p,h in proof['bindings'].items():assert sha(p)==h,p
  body=shot=0
  for var in range(4):
   for gear in range(3):
    z=original(var,gear);c=arena(z);ref=reference_arena(z);cycles=[]
    for age in range(96):
     pad=(1 if age<24 else 2 if age<36 else 0)|(0x80 if 36<=age<70 else 0)|(0x40 if age in[4,20,80]else 0)
     ground=not(ref.memory[reference_at(0x7aa)]&64)
     reference_step(ref,pad,ground);obs=step(c,pad,ground);compare(c,ref,(var,gear,age));body+=1
     cycles.append(sum(x['cycles']for x in obs))
    # Construct a fresh original first weapon, then execute actual source
    # 8132 handler cadence through real split gates for all12class/gears.
    z=original(var,gear);T.step(z,64);c=arena(z);ref=reference_arena(z)
    for age in range(64):shots(ref,False);shots(c,True);compare(c,ref,('shot',var,gear,age));shot+=1
    out['rows'].append(dict(variant=var,gear=gear,body_updates=96,shot_updates=64,body_call_cycles_min=min(cycles),body_call_cycles_max=max(cycles),real_mapper_writes=len(c.memory.writes)))
    print('split source',var,gear,'PASS',flush=True)
  out.update(passed=True,actual_split_body_update_pairs=body,actual_split_shot_update_pairs=shot,compared_source_actor_bytes_each=519,mapping_shadow_restored_each_endpoint=True)
 except Exception as e:out.update(error=repr(e),traceback=traceback.format_exc());raise
 finally:
  paths=[Path(__file__),base,R/'tools/audit/verify_native_relocation.py',R/'tools/audit/contra_force_engine_probe_v1.py',P/'build-proof.json',P/'runtime.dbg',P/'ram1.bin',P/'ram2.bin',P/'ram3.bin',P/'oracle-gates.bin',g['P']/'build-proof.json',g['P']/'arena.bin',g['P']/'arena.dbg',T.P/'candidate.nes',T.P/'candidate.dbg']
  out['bindings']={str(p.resolve()):sha(p)for p in paths}
  path=O/'controls.json';path.write_text(json.dumps(out,indent=2)+'\n')
  print(json.dumps(dict(path=str(path),sha256=sha(path),passed=out['passed'],error=out.get('error'))),flush=True)

if __name__=='__main__':main()
