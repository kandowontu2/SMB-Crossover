"""Real native vector cuts during the granted CF bootstrap; no native run."""
from pathlib import Path
import copy,hashlib,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import contra_force_loader_controls_v2 as T
O=R/'build/contra-force-loader-isr-controls-v2'
B=T.B;address=T.address;NesMPU=T.NesMPU
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def clone(m,c):
 z=T.Bus.__new__(T.Bus);list.__init__(z,list(m))
 for name,value in m.__dict__.items():setattr(z,name,value if name=='bundle'else copy.deepcopy(value))
 d=NesMPU(memory=z,pc=c.pc);d.a,d.x,d.y,d.p,d.sp=c.a,c.x,c.y,c.p,c.sp;d.processorCycles=c.processorCycles
 return z,d

def ppu(m):return(m.chr_latches[:],m.upper,m.lastset,m.ppu_addr,m.toggle,m.buffer,m.ppuctrl,m.ppu_mask,m.scroll[:],m.ppu_reads)
def state(c):return(c.pc,c.a,c.x,c.y,c.p,c.sp)

def interrupt(m,c,kind='NMI',keep_ppu=True):
 live=kind=='IRQ'or T.get(m,'NmiDisable')!=0
 before=dict(cpu=state(c),tags=m.rawtags[:],shadow=[T.get(m,n)for n in['CurrentBank','CurrentBankC']],smc=T.smc(m),stack=bytes(m[0x101+c.sp:0x200]),zp=bytes(m[:256]),banks=[bytes(x)for x in m.ram],ppu=ppu(m),protection=m.protection[:])
 expected=m.rawtags[:]
 if kind=='NMI':
  for slot,n,op in[(1,'CurrentBank',b'\x8d\x15\x51'),(2,'CurrentBankC',b'\x8d\x16\x51')]:
   if expected[slot]!=T.get(m,n):
    assert bytes(m[c.pc:c.pc+3])==op,('not an actual pending native mapper write',slot,hex(c.pc),m.rawtags,T.get(m,n))
    expected[slot]=T.get(m,n)
  c.nmi()
 else:
  assert not c.p&4;c.irq()
 cycles=c.processorCycles;low=c.sp;steps=0
 while state(c)!=before['cpu']:
  assert steps<100000,('actual vector bound',kind,hex(c.pc),m.rawtags)
  assert m[c.pc]!=0,('actual vector BRK',kind,hex(c.pc),m.rawtags)
  low=min(low,c.sp);c.step();steps+=1
 assert m.rawtags==expected and [T.get(m,n)for n in['CurrentBank','CurrentBankC']]==before['shadow'],('actual vector raw mappings',kind,hex(c.pc),m.rawtags,expected)
 assert T.smc(m)==before['smc']and bytes(m[0x101+c.sp:0x200])==before['stack'],('actual vector 33SMC/live upper page1',kind,hex(c.pc))
 assert [bytes(x)for x in m.ram]==before['banks']and m.protection==before['protection'],('actual vector changed loader payload/protection',kind,hex(c.pc))
 changed=[i for i,(a,b)in enumerate(zip(before['zp'],m[:256]))if a!=b]
 # A lag native audio acquisition may initialize only its declared persistent
 # decoder pointers; the loader's real R0..7 are never audio scratch.
 start,end=(address(B,n)for n in['XgAudioPtr','XgAudioZeroPageEnd'])
 if live:assert all(kind=='NMI'and start<=i<end for i in changed),('actual live zero page clobber',kind,hex(c.pc),changed)
 assert bytes(m[3:11])==before['zp'][3:11]
 if keep_ppu:assert ppu(m)==before['ppu'],('actual vector disturbed buffered transfer/CHR/CTRL/scroll',kind,hex(c.pc),before['ppu'],ppu(m))
 return dict(kind=kind,CPU=c.processorCycles-cycles,minimum_SP=low,ZP_changes=changed)

def seams():
 m=T.Bus();T.checkpoint(m);c=T.cpu(m,p=0x30)
 labels={n:address(B,n)for n in['CfLoaderProposal','CfLoaderCoreProposal','CfLoadNextBank','CfLoadNextPage','CfMapSourcePage','CfCopy256','CfVerify256','CfLoadVerified','CfPublishCookie','CfRestorePublication','CfLegacy11','CfDirect11','CfWrite11','CfLoaderFinish']}
 seen=set();rows=[];source_steps=0;masked=0
 while c.pc!=0x7fff:
  assert source_steps<600000
  pc=c.pc;op=bytes(m[pc:pc+3]);page=m[address(B,'R2')];y=c.y
  # One cut at each actual named phase/page/cookie entry, each mapper store,
  # each of four256-byte transfer blocks at first/middle/last byte, and the
  # instruction immediately AFTER PPUDATA loads (live A must survive).
  key=None
  if pc in labels.values():key=('entry',pc,page,m[address(B,'R1')],y if pc==labels['CfPublishCookie']else 0)
  if op in[b'\x8d\x15\x51',b'\x8d\x16\x51',b'\x8d\x2b\x51',b'\x8d\x30\x51']:key=('map',pc,page,m[address(B,'R1')])
  if pc in[labels['CfCopy256'],labels['CfCopy256']+3,labels['CfVerify256'],labels['CfVerify256']+3]and y in[0,127,255]:key=('byte',pc,page,m[address(B,'R1')],y)
  if key is not None and key not in seen:
   seen.add(key);z,d=clone(m,c)
   # The genuine loader masks IRQ during the copy; a masked IRQ request
   # cannot change execution. Real unmasked IRQ is tested at legal edges.
   if d.p&4:
    before=state(d);d.irq();assert state(d)==before;masked+=1
   result=interrupt(z,d,'NMI',keep_ppu=T.get(m,'ReloadCHRBank')==0)
   # Continue both interrupted and uninterrupted machines naturally. Full
   # final transfer is checked once below; each cut verifies immediate live
   # vector return, real code/data, stack, maps and PPU transaction exactly.
   assert state(d)==state(c)
   rows.append(dict(step=source_steps,PC=pc,source_page=page,Y=y,**result))
  c.step();source_steps+=1
 T.exact(m,0);assert c.p&1
 # Real unmasked IRQ before SEI and after restoring caller flags. Those do
 # not get normalized into an artificial enabled interrupt in the copy.
 irqs=[]
 for n in['CfLoaderProposal','CfLoaderFinish']:
  z=T.Bus();T.checkpoint(z);d=T.cpu(z,p=0x30)
  for _ in range(600000):
   if d.pc==labels[n]:break
   d.step()
  else:raise AssertionError(('edge not reached',n))
  if d.p&4:
   # Finish precedes original PLP. The true unmasked caller boundary is the
   # RTS following that PLP, found without editing its actual status.
   while z[d.pc]!=0x60 or d.p&4:d.step()
  z[0x5204]=0x80;result=interrupt(z,d,'IRQ',keep_ppu=False)
  T.finish(z,d);T.exact(z,0);irqs.append(dict(entry=n,PC=d.pc,**result))
 return dict(real_lag_NMI_cuts=len(rows),real_masked_IRQ_requests=masked,real_unmasked_IRQ_edges=irqs,all24_source_page_and_read_write_verify_cookie_map_boundaries=True,original_AXIYP_page1_R0to7_all33SMC_payload_and_PPU_live=True,rows=rows)

def normal_rejected():
 rows=[]
 # A normal NMI is legal before/after a rejected NmiDisable=0 call. During
 # an accepted transfer NmiDisable<0 is a required boundary, not a fixture
 # field that can be changed into an artificial ordinary NMI mid-copy.
 for pause in[0,1]:
  m=T.Bus();T.checkpoint(m);T.put(m,NmiDisable=0,GamePauseStatus=pause,VRAM_Buffer_AddrCtrl=0,VRAM_Buffer1_Offset=0,Sprite0HitDetectFlag=0,ReloadCHRBank=0)
  m[address(B,'VRAM_Buffer1')]=0
  c=T.cpu(m,p=0x30);before=[bytes(x)for x in m.ram]
  result=interrupt(m,c,'NMI',keep_ppu=False)
  # Actual normalNMI decrements0 toFF; re-establishing API's rejected state
  # models the normal caller publication after completion, not a load grant.
  T.put(m,NmiDisable=0);T.finish(m,c)
  assert not c.p&1 and [bytes(x)for x in m.ram]==before and not m.ram_writes
  rows.append(dict(pause=pause,**result))
 return dict(real_normal_NMI_cold_rejection_edges=rows,no_RAM_execution_or_copy=True,scope='Accepted transfer cuts are real lag NMIs only, because the source API requires NmiDisable<0 throughout forced blank. IRQ remains actually masked after SEI.')

def main():
 assert not O.exists();O.mkdir();d=dict(passed=False,native=False,guest_RAM_preloaded=False,actual_cart_hooks=False,checks={})
 try:
  for n,f in[('normal_rejected',normal_rejected)]:d['checks'][n]=f();print('CF loader ISR',n,'PASS',flush=True)
  previous=R/'build/contra-force-loader-isr-controls-v1/controls.json'
  old=json.loads(previous.read_text());assert old['checks']['seams']['real_lag_NMI_cuts']==1462
  d['retained_positive_seams']=dict(path=str(previous),sha256=sha(previous),checks=old['checks']['seams'])
  d['passed']=True
 except Exception as e:d.update(failure=repr(e),traceback=traceback.format_exc());raise
 finally:
  paths=[R/'build/contra-force-loader-isr-controls-v1/controls.json',R/'tools/audit/contra_force_loader_isr_controls_v1.py',Path(__file__),Path(T.__file__),T.P/'source-stage.json',T.P/'joint/candidate.nes',T.P/'joint/candidate.dbg',T.P/'joint/cf-stream.bin',T.P/'joint/cf-cookie.bin',R/'tools/audit/arthur_cache_host_controls_v1.py',R/'tools/audit/verify_native_relocation.py']
  d['bindings']={str(p.resolve()):sha(p)for p in paths};path=O/'controls.json';path.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(path=str(path),sha256=sha(path),passed=d['passed'],failure=d.get('failure'))),flush=True)

if __name__=='__main__':main()

