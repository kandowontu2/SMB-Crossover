"""Compile authenticated CF records/renderer in granted phase images.

Yellow projectile P1 ownership is deliberately unimplemented and required;
uncommitted whole objects are rejected. No native/cold/readiness claim.
"""
from pathlib import Path
import hashlib,json,re,subprocess,sys
R=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(R/'tools/audit')]
from private_build_outputs_v1 import validate
P=R/'build/contra-force-host-arena-v4'
O=R/'build/contra-force-render-arena-v1'
N=R/'build/peach-palette-fix-1030-v1/joint/candidate.dbg'
H=R/'tools/reference/contra_force_host_render_v1.s'
BODY=R/'build/contra-force-body-pack-v3/packing.json'
SHOTS=R/'build/contra-force-shot-pack-v1/packing.json'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def body_source():
 d=json.loads(BODY.read_text());views=sorted(d['per_pose_source_metadata'],key=lambda v:v['frame'])
 lut=[255]*192
 for i,v in enumerate(views):assert lut[v['frame']]==255 and v['source_high']==0;lut[v['frame']]=i
 arrays=dict(CfBodyFrameIndex=lut,CfBodyPage=[v['local_page']for v in views],CfBodyBytes=[4*len(v['parts'])for v in views])
 lines=['.segment "CF_BODY_META"','.export CfBodyFrameIndex,CfBodyPage,CfBodyBytes,CfBodyLo,CfBodyHi,CfBodyRecords,CfBodyRecordsEnd','CfBodyMetaStart:']
 for name,values in arrays.items():lines+=[name+': .byte '+','.join(str(x)for x in values)]
 for name,op in[('CfBodyLo','<'),('CfBodyHi','>')]:lines+=[name+': .byte '+','.join(op+'CfBodyPose%d'%i for i in range(len(views)))]
 lines+=['CfBodyRecords:']
 for i,v in enumerate(views):
  data=[]
  for p in v['parts']:data.extend([(p['y']-128)&255,(p['x']-128)&255,2*p['local_pair'],p['attr']])
  lines+=['CfBodyPose%d:.byte '%i+','.join(str(x)for x in data)]
 lines+=['CfBodyRecordsEnd:']
 return '\n'.join(lines)+'\n',views

def shot_source():
 d=json.loads(SHOTS.read_text());by={}
 for v in d['views']:
  assert v['high']==28
  key=v['frame'];parts=[((p['y']-128)&255,(p['x']-128)&255,p['target_window6_tile'],(p['attr']&252)|(1 if p['attr']&3==3 else p['attr']&3))for p in v['target_parts']]
  if key in by:assert by[key][0]==parts
  else:by[key]=(parts,v)
 views=sorted(by);lut=[255]*139
 for i,frame in enumerate(views):lut[frame]=i
 arrays=dict(CfShotFrameIndex=lut,CfShotBytes=[4*len(by[f][0])for f in views],CfShotNeedsLoan=[int(any(p['attr']&3==3 for p in by[f][1]['target_parts']))for f in views])
 lines=['.segment "CF_SHOT_META"','.export CfShotFrameIndex,CfShotBytes,CfShotNeedsLoan,CfShotLo,CfShotHi,CfShotRecordsEnd','CfShotMetaStart:']
 for name,values in arrays.items():lines+=[name+': .byte '+','.join(str(x)for x in values)]
 for name,op in[('CfShotLo','<'),('CfShotHi','>')]:lines+=[name+': .byte '+','.join(op+'CfShotPose%d'%i for i in range(len(views)))]
 for i,frame in enumerate(views):lines+=['CfShotPose%d:.byte '%i+','.join(str(x)for p in by[frame][0]for x in p)]
 lines+=['CfShotRecordsEnd:']
 return '\n'.join(lines)+'\n',[by[f][1]for f in views]

def main():
 assert not O.exists();O.mkdir()
 h=json.loads((P/'build-proof.json').read_text())
 for p,v in h['bindings'].items():assert sha(p)==v,p
 for path in[BODY,SHOTS]:
  d=json.loads(path.read_text());assert d['passed']
  for p,v in d['bindings'].items():assert sha(p)==v,p
 objects=['component','phase-bridge','oracle-gates','native-imports','host-runtime','host-gates']
 for name in objects:(O/(name+'.s')).write_bytes((P/(name+'.s')).read_bytes())
 (O/'state.inc').write_bytes((P/'state.inc').read_bytes())
 (O/'render.s').write_bytes(H.read_bytes())
 body,bviews=body_source();shots,sviews=shot_source()
 (O/'body-meta.s').write_text(body);(O/'shot-meta.s').write_text(shots)
 defs={}
 for line in N.read_text().splitlines():
  n=re.search(r'name="([^"]+)"',line);v=re.search(r'\bval=0x([0-9a-fA-F]+)',line)
  if n and v:defs[n[1]]=int(v[1],16)
 imports=[]
 for row in re.findall(r'^\.import(?:zp)? (.*)',H.read_text(),re.M):imports.extend(row.split(','))
 prior=(O/'native-imports.s').read_text()
 for name in sorted({n for n in imports if not n.startswith('Cf')}):
  assert name in defs,name
  if not re.search(r'^\.export '+name+r'$',prior,re.M):prior+='.export '+name+'\n'+name+'=$%04x\n'%defs[name]
 (O/'native-imports.s').write_text(prior)
 cfg=(P/'runtime.cfg').read_text().replace(' CF_GATES_1:', ' CF_BODY_META:load=C2,type=ro;\n CF_C2_RENDER_PUBLISHER:load=C2,type=ro;\n CF_SHOT_META:load=A3,type=ro;\n CF_HOST_RENDER:load=A3,type=ro;\n CF_GATES_1:')
 (O/'runtime.cfg').write_text(cfg)
 objects+=['render','body-meta','shot-meta'];ca=R/'tools/Windows/cc65/bin/ca65.exe';ld=ca.with_name('ld65.exe');logs=[]
 commands=[]
 for name in objects:commands.append([str(ca),'--cpu','6502x','-g','-I',str(R/'build/contra-force-reproduction-v2'),'--create-full-dep',str(O/(name+'.dep')),'-o',str(O/(name+'.o')),str(O/(name+'.s'))])
 commands.append([str(ld),'-C',str(O/'runtime.cfg'),'-o',str(O/'unused.bin'),'--dbgfile',str(O/'runtime.dbg'),'-Ln',str(O/'runtime.lbl'),'-m',str(O/'runtime.map'),*[str(O/(n+'.o'))for n in objects]])
 for cmd in commands:
  guard=validate(cmd,O,cwd=O);p=subprocess.run(cmd,cwd=O,capture_output=True,text=True)
  logs.append(dict(command=cmd,cwd=str(O),output_guard=guard,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr))
  (O/'build-log.json').write_text(json.dumps(logs,indent=2)+'\n');assert p.returncode==0,logs[-1]
 out=dict(passed=True,status='SOURCE_RENDERER_PHASE_IMAGES_UNQUALIFIED_PALETTE_OWNER_NOT_READY',native=False,actual_cart_hooks=False,
          body_views=len(bviews),shot_views=len(sviews),body_CHR_pages=[959,968],shot_CHR_page=968,
          body_native_colors='P0[37,12,0F] plus existing nativeP2index1=16',
          yellow_shot_policy='Exact originalP3[20,38,16] records remap to prospective P1. Whole object MUST reject while CfShotPaletteOwned0. No actual commit/restore protocol implemented.',
          software_capacity_end=220,hardware_sprite_limit=8,
          missing=['Real selected importer/loader/common Main','Native P0queue/loanP1commit and complete native-object fairness','Projectile contact/pickup/lifecycle/native qualification'],
          bindings={str(p.resolve()):sha(p)for p in[Path(__file__),H,P/'build-proof.json',BODY,SHOTS,N,ca,ld,R/'tools/audit/private_build_outputs_v1.py',*[p for p in O.iterdir()if p.is_file()]]})
 path=O/'build-proof.json';path.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(path=str(path),sha256=sha(path))),flush=True)

if __name__=='__main__':main()
