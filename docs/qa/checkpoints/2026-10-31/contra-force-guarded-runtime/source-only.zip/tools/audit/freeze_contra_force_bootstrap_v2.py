"""Freeze the inert source-linked CF bootstrap and bounded CPU evidence."""
from pathlib import Path
import hashlib,json,zipfile
R=Path(__file__).resolve().parents[2]
O=R/'build/contra-force-bootstrap-qualified-v2'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
ROOTS=[
 'build/contra-force-loader-cart-v3/source-stage.json',
 'build/contra-force-loader-controls-v2/controls.json',
 'build/contra-force-loader-isr-controls-v2/controls.json',
 'build/contra-force-render-arena-v1/build-proof.json',
 'build/contra-force-render-controls-v1/controls.json',
 'build/contra-force-host-bg-controls-v2/controls.json',
 'build/contra-force-loader-proposal-qualified-v1/handoff.json',
]

def main():
 assert not O.exists();O.mkdir()
 bound={};seen=set()
 def add(path,expected=None):
  path=Path(path).resolve();h=sha(path)
  if expected:assert h==expected,('Frozen binding changed',str(path),expected,h)
  if str(path)in bound:assert bound[str(path)]==h
  bound[str(path)]=h
  if path in seen or path.suffix!='.json':return
  # Current cart source-stage already binds the complete actual parent link
  # closure. Recurse only CF producer lineage, not unrelated old QA history.
  if 'contra-force-'not in str(path):return
  seen.add(path)
  try:d=json.loads(path.read_text())
  except(UnicodeError,json.JSONDecodeError):return
  if isinstance(d,dict):
   edges=d.get('bindings',{})
   assert isinstance(edges,dict),('Unexpected CF binding schema',str(path))
   for p,h in edges.items():add(p,h)
 for p in ROOTS:add(R/p)
 for p in[Path(__file__),R/'tools/audit/freeze_contra_force_bootstrap_v1.py',
           *[R/('tools/audit/prepare_contra_force_loader_cart_v%d.py'%i)for i in[1,2,3]],
           *[R/('tools/audit/contra_force_loader_controls_v%d.py'%i)for i in[1,2]],
           *[R/('tools/audit/contra_force_loader_isr_controls_v%d.py'%i)for i in[1,2]],
           R/'build/contra-force-loader-cart-v1/negative.json',
           R/'build/contra-force-loader-cart-v2/negative.json',
           R/'build/contra-force-loader-controls-v1/controls.json',
           R/'build/contra-force-loader-isr-controls-v1/controls.json']:
  add(p)
 stage=json.loads((R/ROOTS[0]).read_text())
 assert stage['candidate']=='f013a333bd56ffb9ff566afa78622a4697c140343d5257e1168db5b3fa0f61cd'
 assert stage['header_unchanged']and stage['actual_source_symbol_pairs_preserved']==78939
 for p in ROOTS[1:3]:assert json.loads((R/p).read_text())['passed']
 sources=sorted(Path(p)for p in bound if Path(p).suffix in['.s','.asm','.inc','.cfg','.dep','.py','.json','.chr']and Path(p).is_relative_to(R))
 archive=O/'source-only.zip'
 with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED)as z:
  for p in sources:z.write(p,p.relative_to(R).as_posix())
 with zipfile.ZipFile(archive)as z:
  assert z.testzip()is None and len(z.namelist())==len(sources)
  for p in sources:assert hashlib.sha256(z.read(p.relative_to(R).as_posix())).hexdigest()==sha(p)
 assert archive.stat().st_size<50*1024*1024
 report=dict(status='FROZEN_SOURCE_LINKED_CF_BOOTSTRAP_CPU_QUALIFIED_FRONTEND_PENDING',source=True,native=False,ready=False,installed=False,
  candidate=stage['candidate'],parent=stage['parent'],source_stage=str((R/ROOTS[0]).resolve()),
  sizes=dict(loader_A=147,loader_C=302,carrier_pages=24,body_pages=9,shot_pages=1),
  copied_verified_payload=24576,payload_sha256=stage['payload_sha256'],cookie=stage['cookie'],
  all78939_preexisting_symbol_PCs_exact=True,only449_PRG_and_granted_CHR935_969_change=True,header_exact=True,
  controls=dict(fullcopies=16,readback_faults=6,rejected_flag_cases=384,accepted_flag_edges=8,real_lag_NMI_cuts=1462,real_masked_IRQ_requests=1461,unmasked_IRQ_edges=2,real_normal_NMI_rejection_edges=2),
  failures_retained=['V1 link unresolved real FmGroups export','V2 ca65 absolute include operand rejected','V1 CPU fixture poisoned live SMC before its first SFC','V1 normal-NMI fixture checked decremented status instead of entry liveness','V1 freezer followed unrelated historical list-schema bindings; no source/object mutation'],
  API=dict(entry='CfLoaderProposal',actual_A_ROM=115,PC='BF38',actual_C_ROM=78,core_PC='CE68',returns='Full caller AXYP except C=success; original raw A/C restored. R0..3 borrowed/restored, no SMC work inside loader.',preconditions=['raw31','FamilyMainCommit bit0 set','OperMode1','forcedblank PPUMASK0 + DisableScreenFlag!=0','NmiDisable negative','Native RAM write protection already writable','All previous guest owners retired before entry','Actual native X5PublishChr software/hardware12-window upper0 checkpoint established before entry']),
  open=['No InitScreen/shared dispatcher/readiness change','Current source images still retain nine declared donor-script/world/audio callbacks; not safe as playable Main yet','Real native-owner retirement/fullcookie importer and palette publication still required','Source shot P3 loan requires genuine P1 commit/restore and whole-object world fairness','Native controller route and physical cadence untested'],
  source_archive=dict(path=str(archive),sha256=sha(archive),bytes=archive.stat().st_size,members=len(sources),excludes='NES/object/debug/map and derived binary payloads; source/commands/assets reconstruct them'),
  bindings={**bound,str(archive.resolve()):sha(archive)})
 p=O/'handoff.json';p.write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps(dict(path=str(p),sha256=sha(p),bindings=len(report['bindings']),archive=report['source_archive'])),flush=True)

if __name__=='__main__':main()

