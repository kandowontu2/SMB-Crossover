"""Measure genuine CF body/shot static closure with explicit host boundaries.

No fixed host addresses, stub services, physical carrier or shared edits.
"""
from pathlib import Path
import hashlib,json,re
R=Path(__file__).resolve().parents[2]
P=R/'build/contra-force-reproduction-v2';O=R/'build/contra-force-component-closure-v1'
assert not O.exists();O.mkdir()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
banks={n:(P/f'copy_bank_{n}.asm').read_text(encoding='utf-8')for n in['00','04','05','06','FF']}
# These are real original services requiring a deliberate host-world/mapper/
# lifecycle policy. Leave every reference imported until that implementation.
boundary={
 'loc_0x01F3C3_execute_script','sub_0x01F3C3_execute_script',
 'loc_0x01FEDA_add_music_to_queue','sub_0x01FEDA_add_music_to_queue',
 'sub_0x0095E8_play_music','loc_0x0095E8_play_music',
 'loc_AE7B','loc_AEB1','sub_AEF0','sub_B032',
 'sub_0x008FD0','loc_0x008FD0','sub_9ACB',
 'sub_0x01D072','sub_0x01E086','sub_FBF0',
 'sub_F34C_prg_bankswitch','loc_F34C_prg_bankswitch',
 'sub_0x01F35C_prg_bankswitch','loc_0x01F35C_prg_bankswitch',
 # Native actor/world collision is hosted, never the original CF tile map.
 'sub_0x003315','sub_B388','sub_BA51',
 'sub_0x00B2B4','loc_0x005D77','sub_0x005D43',
}
special={'tbl_987A','tbl_0x000011_spr_data'}
chunks=[];labels={}
for bank,text in banks.items():
 for i,body in enumerate(re.split(r'\n(?:[ \t]*\n){3,}',text)):
  defs=set(re.findall(r'^(\w+):',body,re.M))
  if not defs:continue
  k=len(chunks);chunks.append(dict(bank=bank,order=i,body=body,labels=sorted(defs)))
  for name in defs:
   if name in labels:raise AssertionError(('duplicate source label',name))
   labels[name]=k
roots=['sub_A2E7','ofs_006_0x00A548_13','sub_AB42','sub_AD5A',
       'sub_9762','ofs_006_0x009793_24','sub_0x01F650',
       'sub_0x0037C0','sub_D35B',
       '_off019_0x00D2AB_00','_off019_0x00D7EF_07',
       '_off032_9A70_00','_off032_801F_07']
selected=set();todo=list(roots);external=set();edges={}
while todo:
 name=todo.pop()
 if name in boundary:external.add(name);continue
 if name in special:continue
 if name not in labels:external.add(name);continue
 k=labels[name]
 if k in selected:continue
 selected.add(k);z=chunks[k]
 code=re.sub(r';[^\n]*','',z['body'])
 used=set(re.findall(r'\b\w+\b',code))
 refs=(used&labels.keys())-set(z['labels'])
 edges[name]=sorted(refs);todo.extend(refs)
# Original tables point into complete substreams, whose following labelled
# records are reached via bytecode rather than individually listed words.
def whole(bank,start,end):
 text=banks[bank];return start+':'+text.split(start+':',1)[1].split(end+':',1)[0]
streams=[('06','_off019_0x00D2AB_00','_off019_0x00D4E1_01','CF_ANIMATION'),
         ('06','_off019_0x00D7EF_07','_off019_0x00D90F_04','CF_ANIMATION'),
         ('00','_off032_9A70_00','_off032_A2C0_04','CF_METASPRITES'),
         ('00','_off032_801F_07','_off032_86A5_09','CF_METASPRITES')]
streamlabels=set()
for bank,start,end,seg in streams:streamlabels.update(re.findall(r'^(\w+):',whole(bank,start,end),re.M))
selected={k for k in selected if not(set(chunks[k]['labels'])&streamlabels)}
body=''
for k in sorted(selected,key=lambda k:(chunks[k]['bank'],chunks[k]['order'])):
 z=chunks[k]
 # Definitions sharing a chunk with a declared host service would falsely
 # include original-world behavior. Fail instead of silently overriding it.
 assert not(set(z['labels'])&boundary),('boundary shares source chunk',z['labels'])
 body+='\n'+z['body']+'\n'
body+='\ntbl_987A:\n .word _off019_0x00D2AB_00\n .res 12,0\n .word _off019_0x00D7EF_07\n'
body+='\ntbl_0x000011_spr_data:\n .word _off032_9A70_00\n .res 12,0\n .word _off032_801F_07\n'
for bank,start,end,seg in streams:body+='\n.segment "'+seg+'"\n'+whole(bank,start,end)+'\n'
(O/'closure-body.inc').write_text(body,encoding='utf-8')
d=dict(passed=True,status='STATIC_DONOR_CLOSURE_MEASURE_ONLY_NO_HOST',roots=roots,
       selected_source_groups=len(selected),source_text_bytes=len(body.encode()),
       explicit_unimplemented_host_boundaries=sorted(external),declared_boundaries=sorted(boundary),
       indirect_groups='Only actual side-view body0 and original player-shot7; host must reject other groups before native indirect lookup.',
       bindings={str(p.resolve()):sha(p)for p in[Path(__file__),P/'proof.json',*[P/f'copy_bank_{n}.asm'for n in banks],O/'closure-body.inc']})
(O/'closure.json').write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8')
# Reuse the already source-pinned field projection/compiler, with an explicit
# current body and all newly derived actual symbol consumers. Outputs all NEW.
base=R/'tools/audit/prepare_contra_force_core_object_v1.py'
s=base.read_text(encoding='utf-8').replace("O=R/'build/contra-force-core-object-v1'", "O=R/'build/contra-force-component-closure-v1/object'")
s=s.replace('.read_text()',".read_text(encoding='utf-8')")
a=s.index(" body='sub_A030:'");b=s.index(' known=set()',a)
s=s[:a]+" body=(R/'build/contra-force-component-closure-v1/closure-body.inc').read_text(encoding='utf-8')\n"+s[b:]
s=s.replace("'.export CfNativeWeaponDirection := sub_ACF6',", "'.export CfNativeWeaponDirection := sub_ACF6',")
s=s.replace("'.export CfNativeInput := sub_A2E7'", "'.export CfNativeInput := sub_A2E7'")
s=s.replace("status='COMPILED_SOURCE_CORE_OBJECT_UNRESOLVED_SERVICES_NO_HOST'", "status='COMPILED_STATIC_BODY_SHOT_CLOSURE_UNIMPLEMENTED_HOST_BOUNDARIES'")
s=s.replace("original_source_range=dict(bank=5,start=0xa030,end=0xae7b,bytes=0xe4b)","original_source_closure_manifest=str(R/'build/contra-force-component-closure-v1/closure.json')")
exec(compile(s,str(base),'exec'),{'__name__':'__main__','__file__':str(Path(__file__).resolve())})
