"""Retain v3 wrapper escaped-newline syntax failure; no compiler was invoked."""
from pathlib import Path
P=Path(__file__).with_name('prepare_contra_force_core_object_v3.py')
s=P.read_text(encoding='utf-8').replace("build/contra-force-core-object-v3'", "build/contra-force-core-object-v4'")
s=s.replace("add='''", "add=r'''")
exec(compile(s,str(P),'exec'),{'__name__':'__main__','__file__':str(Path(__file__).resolve())})
