"""Compile routine/data groups for granted CF A1/A3/C2 runtime packing.

The offline original OAM decoder/data are replaced by source-pixel-verified
host records, so they are not redundantly copied into the gameplay payload.
All remaining original engine imports stay explicit, no stubbed host services.
"""
from pathlib import Path
R=Path(__file__).resolve().parents[2];P=Path(__file__).with_name('prepare_contra_force_component_closure_v5.py')
g={'__file__':str(P)}
exec(P.read_text(encoding='utf-8').split('exec(compile(s,str(P)')[0],g)
s=g['s'].replace('build/contra-force-component-closure-v5','build/contra-force-runtime-groups-v3')
s=s.replace("'sub_0x0037C0','sub_D35B',","'sub_0x0037C0',")
s=s.replace("       '_off032_9A70_00','_off032_801F_07']","       ]")
s=s.replace("         ('00','_off032_9A70_00','_off032_A2C0_04','CF_METASPRITES'),\n         ('00','_off032_801F_07','_off032_86A5_09','CF_METASPRITES')",'')
# Above leaves a trailing comma in streams, which is legal; no original sprite
# data pointer table is needed by the runtime after removing its renderer.
s=s.replace("body+='\\ntbl_0x000011_spr_data:\\n .word _off032_9A70_00\\n .res 12,0\\n .word _off032_801F_07\\n'",'')
needle="body='';"
if needle in s:raise AssertionError('Unexpected compact producer spelling')
s=s.replace("body=''\nfor k", "body=''\ngroup_inventory=[]\nfor k")
needle=" body+='\\n'+z['body']+'\\n'"
replacement=r''' code=re.sub(r';[^\n]*','',z['body'])
 lines=[v.strip()for v in code.splitlines()if v.strip()and not v.strip().endswith(':')]
 data=bool(lines)and all(v.startswith(('.byte','.word','.res'))for v in lines)
 tail=lines[-1]if lines else ''
 fall=bool(re.match(r'(?i)^(?:LDA|LDX|LDY|STA|STX|STY|JSR|BCC|BCS|BEQ|BNE|BMI|BPL|BVC|BVS|CLC|SEC|ADC|SBC|AND|ORA|EOR|ASL|LSR|ROL|ROR|INC|DEC|INX|DEX|INY|DEY|TAX|TAY|TXA|TYA|PHA|PLA|PHP|PLP|NOP)\b',tail))
 segment='CF_CHUNK_%03d'%k
 group_inventory.append(dict(id=k,segment=segment,bank=z['bank'],order=z['order'],labels=z['labels'],source=z['body'],data=data,fallthrough_to=(k+1 if fall and k+1 in selected and chunks[k+1]['bank']==z['bank']else None)))
 body+='\n.segment "'+segment+'"\n.export CfChunkStart_%03d,CfChunkEnd_%03d\nCfChunkStart_%03d:\n'%(k,k,k)+z['body']+'\nCfChunkEnd_%03d:\n'%k'''
assert needle in s;s=s.replace(needle,replacement)
s=s.replace("body+='\\ntbl_987A:","body+='\\n.segment \"CF_ANIM_POINTERS\"\\ntbl_987A:")
needle="(O/'closure-body.inc').write_text(body,encoding='utf-8')"
assert needle in s;s=s.replace(needle,needle+"\n(O/'runtime-groups.json').write_text(json.dumps(group_inventory,indent=2)+'\\n',encoding='utf-8')")
# The underlying emitter measures an unresolved object. Before its compiler,
# apply the same already executed conservative2-byte indirect projection.
needle="exec(compile(s,str(base),'exec')"
inject=r'''s=s.replace(" state=['; Abstract component only; no current host RAM addresses assigned.'", " state=['; CF granted whole-page selected-owner state; no shared RAM0 fields.'")
s=s.replace("'CfPointers: .res '+str(len(pointerbytes))", "'CfPointers: .res 2'")
s=s.replace("'CfState: .res $800'", "'CfState: .res $500'")
s=s.replace("target='CfPointers+'+str(zpmap[a])if a in zpmap else 'CfState+$%04x'%a", "target='CfState+$%04x'%({0:0,2:1,3:2,6:3,7:4}[a//256]*256+a%256)")
before=" target=O/'component.s';target.write_text('\\n'.join(source)+'\\n',encoding='utf-8')"
after=r""" bodytext='\n'.join(source)+'\n'
 sites=[]
 pattern=re.compile(r'(?m)^(\s*)(LDA|STA|ADC|SBC|AND|ORA|EOR|CMP|JMP)\s+\((ram_\w+)\)(\s*,\s*Y)?([^\n]*)$')
 def project_indirect_site(m):
  indent,op,pointer,index,comment=m.groups();assert(op=='JMP')==(not index)
  sites.append(dict(instruction=op,source_pointer=pointer,indexed=bool(index)))
  return '\n'.join(indent+v for v in['php','pha','lda '+pointer,'sta CfPointers','lda '+pointer+'+1','sta CfPointers+1','pla','plp',op+' (CfPointers)'+(',Y'if index else'')+comment])
 bodytext=pattern.sub(project_indirect_site,bodytext)
 a=bodytext.index('bra_ABB8:');b=bodytext.index('bra_ABD4:',a)
 up=bodytext[a:b];assert up.count('LDA tbl_ACCE')==2
 bodytext=bodytext[:a]+up.replace('LDA tbl_ACCE','LDA CfHostJumpUpLimit')+bodytext[b:]
 bodytext+='\n.segment "CF_JUMP_LIMIT"\nCfHostJumpUpLimit:.word $0440,$0400,$03c0,$0420,$0200\n.export CfNativeClear := sub_0x01F650\n.export CfNativeAdvance := sub_9772\n.export CfNativeShot := sub_0x0037C0\n'
 (O/'indirect-sites.json').write_text(json.dumps(sites,indent=2)+'\n',encoding='utf-8')
 target=O/'component.s';target.write_text(bodytext,encoding='utf-8')"""
assert before in s;s=s.replace(before,after)
s=s.replace("assert sizes['CF_STATE']==2048 and sizes['CF_POINTERS']==len(pointerbytes)","assert sizes['CF_STATE']==1280 and sizes['CF_POINTERS']==2")
s=s.replace('abstract_zero_page_bytes=len(pointerbytes),conservative_private_state_bytes=2048','abstract_zero_page_bytes=2,conservative_private_state_bytes=1280')
'''
assert needle in s;s=s.replace(needle,inject+'\n'+needle)
# Include actual original attachment/target selection, not donor callbacks.
a="'sub_0x008FD0','loc_0x008FD0','sub_9ACB',";assert a in s;s=s.replace(a,"'sub_0x008FD0','loc_0x008FD0',")
a="'sub_0x003315','sub_B388','sub_BA51','sub_0x003393',";assert a in s;s=s.replace(a,"'sub_0x003315','sub_B388','sub_0x003393',")
exec(compile(s,str(P),'exec'),{'__name__':'__main__','__file__':str(Path(__file__).resolve())})
