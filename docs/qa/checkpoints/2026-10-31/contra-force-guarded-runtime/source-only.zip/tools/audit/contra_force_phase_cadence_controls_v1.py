"""Retain real duplicate-shot negative and prove once-per-source-update handoff."""
from pathlib import Path
import hashlib,json,itertools,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import contra_force_host_boundaries_controls_v2 as C
O=R/'build/contra-force-phase-cadence-controls-v1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
 assert not O.exists();O.mkdir();d=dict(passed=False,native=False,guest_RAM_preloaded=True,checks={})
 try:
  rows=[]
  for var,tier in itertools.product(range(4),range(3)):
   pair=[]
   for revised in[False,True]:
    C.T.P=R/('build/contra-force-host-boundaries-v5'if revised else'build/contra-force-host-boundaries-v4');C.T.L=C.T.S.g['labels'](C.T.P/'runtime.dbg');C.L=C.T.L
    m,slot=C.fire(var,tier);before=bytes(m.ram[2]);age=m[C.at(m,0x23)]
    C.T.run(m,'CfHostShots');after=bytes(m.ram[2])
    delta=[dict(offset=i,before=a,after=b)for i,(a,b)in enumerate(zip(before,after))if a!=b]
    actor_delta=[x for x in delta if 0x300<=x['offset']<0x500]
    if revised:
     assert not delta,('repeated early/remaining weapon phase changed source',var,tier,delta)
     C.T.put(m,SavedJoypadBits=64);C.T.run(m,'CfHostMovement');C.T.run(m,'CfHostShots')
     assert m[C.at(m,0x23)]==(age+1)&255 and m[C.L['CfState']+0x2de]==(age+1)&255
    else:assert actor_delta,('retained old duplicate phase did not reproduce',var,tier,delta)
    pair.append(dict(revised=revised,source_age=age,active_slot=slot,source_actor_changes=actor_delta,all_changes=delta))
   rows.append(dict(variant=var,tier=tier,pair=pair))
  d.update(passed=True,source_cases=len(rows),rows=rows,alias=dict(offset='C2 State02DE (original03DE)',semantics='last completed source23 weapon frame',initialization='actual own constructor clears whole1280B state; warm scene/life constructor also clears counter and originalframe together',scope='Selected-owner state only, no globalRAM or new cursor. Retained original state.inc has no field at this exact address; original peractor spdY is03DE (original06DE), a different physical offset.'))
 except Exception as e:d.update(failure=repr(e),traceback=traceback.format_exc());raise
 finally:
  files=[Path(__file__),Path(C.__file__),Path(C.T.__file__),R/'tools/reference/contra_force_host_boundaries_v3.s',R/'tools/reference/contra_force_host_boundaries_v4.s',R/'build/contra-force-host-boundaries-v4/build-proof.json',R/'build/contra-force-host-boundaries-v5/build-proof.json',R/'build/contra-force-host-boundaries-controls-v3/controls.json']
  d['bindings']={str(p.resolve()):sha(p)for p in files};p=O/'controls.json';p.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(path=str(p),sha256=sha(p),passed=d['passed'],failure=d.get('failure'))),flush=True)

if __name__=='__main__':main()
