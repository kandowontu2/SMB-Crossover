"""Retain v1 parser failure before execution; correct literal token spacing."""
from pathlib import Path
import hashlib,json,re
R=Path(__file__).resolve().parents[2];P=Path(__file__).with_name('contra_force_compact_arena_controls_v1.py')
N=R/'build/contra-force-compact-arena-controls-v1';assert not N.exists();N.mkdir()
(N/'preparation-negative.json').write_text(json.dumps(dict(passed=False,failure='Python else4/else255/else0 literal tokens in v1 observer caused SyntaxError before any CPU execution or compiler.',tool=str(P),tool_sha256=hashlib.sha256(P.read_bytes()).hexdigest()),indent=2)+'\n',encoding='utf-8')
s=P.read_text(encoding='utf-8').replace('build/contra-force-compact-arena-controls-v1','build/contra-force-compact-arena-controls-v2')
s=re.sub(r'\belse(?=\d)','else ',s)
exec(compile(s,str(P),'exec'),{'__name__':'__main__','__file__':str(Path(__file__).resolve())})
