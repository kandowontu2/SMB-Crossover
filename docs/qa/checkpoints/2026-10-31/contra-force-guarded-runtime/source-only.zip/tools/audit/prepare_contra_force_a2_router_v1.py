"""Measure an owned C2/A2 transport against its genuine loader ROM ABI."""
from pathlib import Path
import hashlib,json,re,subprocess,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
from private_build_outputs_v1 import validate
from prepare_ff_current_component_v2 import qualified
from check_tmnt_render_oa import address,location
P=R/'build/contra-force-host-boundaries-v4';O=R/'build/contra-force-a2-router-v1'
H=R/'tools/reference/contra_force_a2_router_v1.s'
N=R/'build/contra-force-loader-cart-v3/joint/candidate.nes'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
 assert not O.exists();O.mkdir();logs=[]
 try:
  proof=json.loads((P/'build-proof.json').read_text())
  for p,h in proof['bindings'].items():assert sha(p)==h,p
  logs0=json.loads((P/'build-log.json').read_text())
  names=[Path(x['command'][-1]).stem for x in logs0 if Path(x['command'][0]).stem=='ca65']
  for n in names:(O/(n+'.s')).write_bytes((P/(n+'.s')).read_bytes())
  (O/'state.inc').write_bytes((P/'state.inc').read_bytes());(O/'a2-router.s').write_bytes(H.read_bytes());names+=['a2-router']
  b=qualified(N);assert address(b,'CfLoaderExpectedCookie')==0xcf86 and (location(b,'CfLoaderExpectedCookie')-16)//8192==78
  text=(O/'native-imports.s').read_text()
  for n in['CfLoaderExpectedCookie','FmGroups','FarcallJmpTarget_SMC','CurrentBankC']:
   if not re.search(r'^\.export '+n+r'$',text,re.M):text+='\n.export '+n+'\n'+n+'=$%04x\n'%address(b,n)
  (O/'native-imports.s').write_text(text)
  cfg=(P/'runtime.cfg').read_text().replace('C2:start=$c000,size=$1fe0','C2:start=$c000,size=$1e00')
  cfg=cfg.replace(' ORACLE:start=', ' C2TAIL:start=$de00,size=$1e0,type=ro,bank=2,file="ram2.bin",fill=yes,fillval=$ff;\n A2ALIAS:start=$be00,size=$1e0,type=ro,bank=2,file="";\n ORACLE:start=')
  cfg=cfg.replace('SEGMENTS {','SEGMENTS {\n CF_A2_ROUTER:load=C2TAIL,run=A2ALIAS,type=ro;')
  (O/'runtime.cfg').write_text(cfg)
  ca=R/'tools/Windows/cc65/bin/ca65.exe';ld=ca.with_name('ld65.exe')
  cmds=[[str(ca),'--cpu','6502x','-g','-I',str(R/'build/contra-force-reproduction-v2'),'--create-full-dep',str(O/(n+'.dep')),'-o',str(O/(n+'.o')),str(O/(n+'.s'))]for n in names]
  cmds+=[[str(ld),'-C',str(O/'runtime.cfg'),'-o',str(O/'unused.bin'),'--dbgfile',str(O/'runtime.dbg'),'-Ln',str(O/'runtime.lbl'),'-m',str(O/'runtime.map'),*[str(O/(n+'.o'))for n in names]]]
  for cmd in cmds:
   guard=validate(cmd,O,cwd=O);p=subprocess.run(cmd,cwd=O,capture_output=True,text=True)
   logs.append(dict(command=cmd,cwd=str(O),output_guard=guard,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr));(O/'build-log.json').write_text(json.dumps(logs,indent=2)+'\n');assert p.returncode==0,logs[-1]
  labels={n:int(v,16)for v,n in re.findall(r'al ([0-9A-Fa-f]+) \.(\w+)',(O/'runtime.lbl').read_text())}
  assert labels['CfServiceVeneers']==0xbe00 and len((O/'ram2.bin').read_bytes())==0x1fe0
  result=dict(passed=True,source=True,native=False,ready=False,actual_cart_hooks=False,
   A2_veneer_PC=labels['CfServiceVeneers'],bytes=labels['CfA2RouterEnd']-labels['CfServiceVeneers'],
   service36_unavailable_PC=labels['CfServiceUnavailable'],remaining_tail=0xbfe0-labels['CfA2RouterEnd'],
   genuine_ROM_cookie=dict(bank=78,PC=address(b,'CfLoaderExpectedCookie'),from_actual_cart=sha(N)),
   preconditions=['Genuine forcedblank CF load+verify succeeded BEFORE any rawA2 entry opcode','Real SFC public operand targets this exact page-aligned3*service veneer','No shared ingress/admission installed'],
   unimplemented_rows=[1,3,6,7,8,9,17,18,20,21,22,23,26,27,29,30,31,32,33,35],
   bindings={str(p.resolve()):sha(p)for p in[Path(__file__),H,P/'build-proof.json',N,N.with_suffix('.dbg'),ca,ld,R/'tools/audit/private_build_outputs_v1.py',*[p for p in O.iterdir()if p.is_file()]]})
  path=O/'build-proof.json';path.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(path=str(path),sha256=sha(path),bytes=result['bytes'],remaining=result['remaining_tail'])),flush=True)
 except Exception as e:(O/'negative.json').write_text(json.dumps(dict(passed=False,error=repr(e),traceback=traceback.format_exc(),commands=logs),indent=2)+'\n');raise

if __name__=='__main__':main()
