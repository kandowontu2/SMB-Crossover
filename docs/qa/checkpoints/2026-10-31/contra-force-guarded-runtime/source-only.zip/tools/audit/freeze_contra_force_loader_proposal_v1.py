"""Freeze the exact measured CF bootstrap and its private resource receipt."""
from pathlib import Path
import hashlib,json,zipfile
R=Path(__file__).resolve().parents[2]
P=R/'build/contra-force-loader-proposal-v1'
O=R/'build/contra-force-loader-proposal-qualified-v1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
 assert not O.exists();O.mkdir()
 proposal=P/'proposal.json';d=json.loads(proposal.read_text())
 assert sha(proposal)=='d54274a31e4f25df1c8d8c412804a0569c1ccd998211d6af9f833725d89c39a9'
 for p,h in d['bindings'].items():assert sha(p)==h,p
 grant=R/'docs/qa/checkpoints/2026-10-31/contra-force-loader-resources/root-review-and-reservations.json'
 assert sha(grant)=='bdfde94b0fdb0af309607a67da7ccba23edc74e63ee57cbb178565550ff6a780'
 g=json.loads(grant.read_text())
 for p,h in g['bindings'].items():assert sha(p)==h,p
 source=R/'tools/reference/contra_force_loader_proposal_v1.s'
 assert sha(source)=='e5966aaee8c65ab84d4440e9ab8a477d2050f7473ba60436ae168f888eb8e231'
 files=[Path(__file__),source,R/'tools/audit/prepare_contra_force_loader_proposal_v1.py',R/'tools/audit/private_build_outputs_v1.py',proposal,grant,*[p for p in P.iterdir()if p.suffix in['.s','.dep','.json','.cfg']]]
 files=sorted(set(p.resolve()for p in files))
 archive=O/'source-only.zip'
 with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED)as z:
  for p in files:z.write(p,p.relative_to(R).as_posix())
 with zipfile.ZipFile(archive)as z:
  assert z.testzip()is None and len(z.namelist())==len(files)
  for p in files:assert hashlib.sha256(z.read(p.relative_to(R).as_posix())).hexdigest()==sha(p)
 report=dict(status='FROZEN_MEASURED_SOURCE_BOOTSTRAP_AND_EXACT_PRIVATE_ROM_GRANT',source=True,native=False,ready=False,installed=False,
             proposal=str(proposal),proposal_sha256=sha(proposal),source_sha256=sha(source),
             actual_sizes=d['actual_emitted_bytes'],private_ranges=g['ROM'],
             limits=['No linked cartridge or loader execution controls in this measured proposal','No source/native/readiness assertion follows from the zero fingerprint measurement placeholder','Future successor must bind actual fullpayload/cookie and prove original-owner retirement and real native publication/ISR contracts'],
             archive=dict(path=str(archive),sha256=sha(archive),bytes=archive.stat().st_size,members=len(files)),
             bindings={**d['bindings'],**g['bindings'],str(proposal.resolve()):sha(proposal),str(grant.resolve()):sha(grant),str(Path(__file__).resolve()):sha(__file__),str(archive.resolve()):sha(archive)})
 p=O/'handoff.json';p.write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps(dict(path=str(p),sha256=sha(p),archive=report['archive'],bindings=len(report['bindings']))),flush=True)

if __name__=='__main__':main()
