"""Preserve source cells when8-line-safe; coalesce only true split-mask overloads."""
from pathlib import Path
P=Path(__file__).with_name('contra_force_body_pack_v1.py')
s=P.read_text(encoding='utf-8').replace("build/contra-force-body-pack-v1'", "build/contra-force-body-pack-v3'")
new=r'''def split_original(parts,bankmap):
 out=[]
 for p in parts:
  palette=p['attr']&3;assert palette in[0,1]
  at=(p['tile']&1)*4096+(p['tile']&254)*16
  pair=bytes(CHR[bankmap[(at+i)//1024]*1024+(at+i)%1024]for i in range(32))
  if palette==0:out.append(dict(x=p['x'],y=p['y'],attr=p['attr'],pattern=pair));continue
  base=bytearray(pair);red=bytearray(32)
  for tile in[0,16]:
   for row in range(8):
    lo,hi=pair[tile+row],pair[tile+row+8];mask=hi&(~lo&255)
    base[tile+row+8]=hi&lo;red[tile+row]=mask
  if any(base):out.append(dict(x=p['x'],y=p['y'],attr=p['attr']&252,pattern=bytes(base)))
  if any(red):out.append(dict(x=p['x'],y=p['y'],attr=(p['attr']&252)|2,pattern=bytes(red)))
 return out
def coalesce(pix):'''
s=s.replace('def coalesce(pix):',new)
s=s.replace("at=(yy//8)*16+yy%8;v=((pair[at]>>(7-xx))&1)|(((pair[at+8]>>(7-xx))&1)<<1)", "sy=15-yy if p['attr']&128 else yy;sx=7-xx if p['attr']&64 else xx;at=(sy//8)*16+sy%8;v=((pair[at]>>(7-sx))&1)|(((pair[at+8]>>(7-sx))&1)<<1)")
s=s.replace('target=coalesce(pix);assert emitted(target)==pix', 'target=split_original(original,bankmap);split_line=lines(target)\n     if split_line>8:target=coalesce(pix)\n     assert emitted(target)==pix')
s=s.replace('target_line_max=lines(target),opaque_pixels=', 'target_line_max=lines(target),source_cell_split_line_max=split_line,coalesced_only_for_real_line_overload=split_line>8,opaque_pixels=')
s=s.replace("[Path(__file__),Path(T.__file__)", "[Path(__file__).with_name('contra_force_body_pack_v1.py'),Path(__file__),Path(T.__file__)")
exec(compile(s,str(P),'exec'),{'__name__':'__main__','__file__':str(Path(__file__).resolve())})
