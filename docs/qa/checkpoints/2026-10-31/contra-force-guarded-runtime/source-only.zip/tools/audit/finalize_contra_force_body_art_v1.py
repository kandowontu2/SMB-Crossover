"""Freeze four original gameplay bodies with honest source/display phases."""
from pathlib import Path
import hashlib,json
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parents[2];O=R/'build/contra-force-body-art-v6';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();entries=[];files={Path(__file__)}
sheet=Image.new('RGBA',(4*176,170),'#18242c');dr=ImageDraw.Draw(sheet)
for i,name in enumerate(['burns','smith','iron','beans']):
 f=O/f'{name}-manifest.json';p=json.loads(f.read_text())
 for path,h in p['bindings'].items():assert sha(path)==h,path
 p['native_palette_rows']=[list(Path(p['source']['visible_snapshot']).read_bytes()[8255+j*4:8259+j*4])for j in range(2)]
 p['selected_preview_requirement']='Original8x16 body parts and native P0/P1 roles,24x32 envelope; no quantization of source colors.'
 entries.append(p);files|={f}|set(map(Path,p['bindings']))
 pic=Image.open(p['path']).convert('RGBA');thumb=Image.open(p['thumbnail']).convert('RGBA')
 dr.text((i*176+6,5),name.upper(),fill='white');sheet.alpha_composite(pic.resize((pic.width*4,pic.height*4),Image.Resampling.NEAREST),(i*176+8,32));sheet.alpha_composite(thumb.resize((32,48),Image.Resampling.NEAREST),(i*176+136,40))
 tag={'burns':'up-1','smith':'up-2','iron':'up-3','beans':'beans'}[name];folder=R/'build/roster-body-companions-v3'/tag
 terminal=json.loads((folder/'terminal.json').read_text());assert terminal['exit_code']==0 and terminal['source_bindings_pre_post_exact']
 files|={p for p in folder.rglob('*')if p.is_file()}
sheet.save(O/'all-four-body-review.png');files.add(O/'all-four-body-review.png')
p=dict(passed=True,status='FROZEN_AUTHENTIC_ORIGINAL_GAMEPLAY_MENU_ART_ONLY',entries=entries,original_native_gameplay_captures=True,host_gameplay_admission=False,
 source_phase='Every originalROM pattern/page and actual visible OAM/DMA exact; source720 descriptor/palette/priority matches every opaque pixel of actual screenshot900, both frame numbers recorded; no same-frame screenshot claim.',
 checks=dict(characters=4,native_processes_terminal=4,opaque_pixels=[e['source']['opaque_source_pixels']for e in entries],screenshots_each=6,physical_frames_each=1200,no_emulated_writes=True,normal_eight_sprite_limit=True,original_black_opaque=True),
 limits=['Frontend artwork only, not playable ContraForce host integration.','Burns/Iron need four visiblecolors across native P0/P1; do not silently quantize tothree.'],
 retained_negatives=['Initial original-controller runs stayedWAIT, retained.', 'Late PPUdebug pattern readout returnedzero; no art accepted. Visible physicalROM capture fixes source authority.', 'EndFrame/screenshot phase mismatched four overlappedBurns pixels; visible-source/display pairing explicitly records both phases and exact fullpixel proof.'],
 bindings={str(f.resolve()):sha(f)for f in sorted(files)})
assert not(O/'manifest.json').exists();(O/'manifest.json').write_text(json.dumps(p,indent=2)+'\n',newline='\n');print(json.dumps(dict(path=str(O/'manifest.json'),sha256=sha(O/'manifest.json'),bindings=len(files),names=[e['name']for e in entries])))
