"""Actual source weapons/native contacts/items; finite CPU scenes, no admission."""
from pathlib import Path
import hashlib,importlib.util,itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
sp=importlib.util.spec_from_file_location('cf_native_boundary_fixture',R/'tools/audit/contra_force_host_bg_controls_v1.py')
T=importlib.util.module_from_spec(sp);sp.loader.exec_module(T)
P=R/'build/contra-force-host-boundaries-v5';O=R/'build/contra-force-host-boundaries-controls-v3'
T.P=P;T.L=T.S.g['labels'](P/'runtime.dbg');T.GATES={}
L=T.L;sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def at(m,a):return L['CfState']+{0:0,2:1,3:2,6:3,7:4}[a//256]*256+a%256
def make(var=0,tier=0):
 m=T.make(var);T.put(m,PlayerStatus=tier)
 T.run(m,'CfHostConstruct');return m
def actor(m,slot,kind,x,y,flag=1,state=0,high=1):
 for n,v in[('Enemy_Flag',flag),('Enemy_ID',kind),('Enemy_State',state),('Enemy_X_Position',x&255),('Enemy_PageLoc',x>>8),('Enemy_Y_Position',y&255),('Enemy_Y_HighPos',high),('Enemy_BoundBoxCtrl',3)]:m[T.address(T.B,n)+slot]=v
def shot(m):return next((i for i in range(10,22)if m[at(m,0x682+i)]and m[at(m,0x634+i)]==28),None)
def fire(var=0,tier=0):
 m=make(var,tier)
 for age in range(12):
  T.put(m,SavedJoypadBits=64)
  T.run(m,'CfHostMovement');T.run(m,'CfHostShots')
  i=shot(m)
  if i is not None:return m,i
 raise AssertionError(('original source did not fire',var,tier))

def world():
 rows=[]
 for var,tile,px,py in itertools.product(range(4),[0,0x61,0x26,0x67],[0,15,127,248],[16,32,191,239,240]):
  m=make(var);m[L['CfState']]=px;m[L['CfState']+1]=py
  if 32<=py<240:T.cell(m,px,py,tile)
  regs=bytes(m[3:11]);c,z=T.run(m,'CfHostPoint',x=17)
  flags=m[T.address(T.B,'MTileAttribute')+tile];expect=int(32<=py<240 and flags&(T.address(T.B,'MTILE_SOLID')|T.address(T.B,'MTILE_CLIMB'))==T.address(T.B,'MTILE_SOLID'))
  assert m[L['CfPointResult']]==expect and c.x==17 and bytes(m[3:11])==regs,(var,tile,px,py,expect,m[L['CfPointResult']])
  rows.append([var,tile,px,py,expect,z['CPU']])
 return dict(native_blockbuffer_geometry_cases=len(rows),rows=rows)

def interleaved():
 rows=[]
 for var,tier in itertools.product(range(4),range(3)):
  m=make(var,tier);seen=set();frames=set();poses=set();positions=[]
  for age in range(96):
   keys=(1 if age<32 else 0)|(128 if 36<=age<68 else 0)|(64 if age<24 or 72<=age<88 else 0)
   T.put(m,SavedJoypadBits=keys)
   _,move=T.run(m,'CfHostMovement');_,weapons=T.run(m,'CfHostShots')
   before_duplicate=bytes(m.ram[2])
   T.run(m,'CfHostShots')
   assert bytes(m.ram[2])==before_duplicate,('duplicate early/remaining shot phase',var,tier,age)
   assert not m[L['CfUnsupportedScript']],('illegal source script',var,tier,age,m[L['CfUnsupportedScript']])
   assert m[at(m,0x53)]==0,('source player index leaked from weapons into next body update',var,tier,age,m[at(m,0x53)])
   frames.add(m[at(m,0x61a)]);poses.add(m[at(m,0x7aa)])
   for i in range(10,22):
    if m[at(m,0x682+i)]:seen.add(m[at(m,0x682+i)]&15)
   positions.append([T.get(m,'Player_X_Position'),T.get(m,'Player_Y_Position')])
  assert seen and len(frames)>1,(var,tier,seen,frames)
  rows.append(dict(variant=var,tier=tier,source_shot_kinds=sorted(seen),body_frames=sorted(frames),positions=positions))
 return dict(actual_interleaved_source_body_and_shot_updates=1152,all12class_gear_pairs=True,no_donor_oracles_or_illegal_AI_script=True,rows=rows)

def contacts():
 rows=[]
 cases=[(6,1,0,1),(2,1,0,1),(12,1,0,1),(8,1,0,1),(0x15,1,0,1),(0x2e,1,0x80,1),(6,0x81,0,1),(6,1,0x20,1),(6,1,0,2),(0x2d,1,0,1)]
 for var,(kind,flag,status,high)in itertools.product(range(4),cases):
  m,i=fire(var);px=m[at(m,0x64e+i)];py=m[at(m,0x668+i)]
  actor(m,2,kind,(px-8)&255,(py-14)&255,flag,status,high)
  T.put(m,ObjectOffset=5,BowserHitPoints=5);m[L['CfShotSlot']]=i
  native=bytes(m[3:11]);old=m[at(m,0x682+i)];c,z=T.run(m,'CfHostShotContacts',x=i)
  hit=kind in[6,0x2d]and flag==1 and status==0 and high==1
  if hit:
   if kind==0x2d:assert T.get(m,'BowserHitPoints')==4 and T.get(m,'Enemy_State',2)==0
   else:assert T.get(m,'Enemy_State',2)&32 and T.get(m,'FloateyNum_Control',2)==1
   assert m[at(m,0x682+i)]!=old,('original source impact not applied',var,i,old,m[at(m,0x682+i)])
  else:assert T.get(m,'Enemy_State',2)==status and T.get(m,'BowserHitPoints')==5
  assert T.get(m,'ObjectOffset')==5 and bytes(m[3:11])==native and c.x==i
  rows.append(dict(variant=var,kind=kind,flags=flag,state=status,high=high,hit=hit,source_action_before=old,source_action_after=m[at(m,0x682+i)],CPU=z['CPU']))
 return dict(actual_native_defeat_and_Bowser_consumers_cases=len(rows),native_immunity_duplicate_death_high_rejections=True,rows=rows)

def items():
 rows=[]
 for var,slot,kind,mature in itertools.product(range(4),range(6),range(4),[0,1]):
  m=make(var);actor(m,slot,0x2e,128,176,state=0x80 if mature else 1)
  m[T.address(T.B,'PowerUpType')+slot]=kind;T.put(m,ObjectOffset=(slot+1)%6)
  c,z=T.run(m,'CfHostCollect',x=slot)
  if mature:
   assert c.p&1 and T.get(m,'Enemy_Flag',slot)==0
   if kind<2:assert T.get(m,'PlayerStatus')==1 and m[at(m,0x7f+var)]==0x11
   elif kind==2:assert T.get(m,'StarInvincibleTimer')==0x23
   else:assert T.get(m,'FloateyNum_Control',slot)==11
  else:assert not c.p&1 and T.get(m,'Enemy_Flag',slot)==1 and T.get(m,'PlayerStatus')==0
  assert c.x==slot and T.get(m,'ObjectOffset')==(slot+1)%6
  rows.append([var,slot,kind,mature,z['CPU']])
 return dict(actual_mature_and_emerging_item_cases=len(rows),source_gear_from_native_items_star_and_deferred_life=True,rows=rows)

def main():
 assert not O.exists();O.mkdir();d=dict(passed=False,native=False,actual_cart_hooks=False,guest_RAM_preloaded=True,checks={})
 try:
  proof=json.loads((P/'build-proof.json').read_text())
  for p,h in proof['bindings'].items():assert sha(p)==h,p
  for n,f in[('world',world),('interleaved',interleaved),('contacts',contacts),('items',items)]:d['checks'][n]=f();print('CF boundaries',n,'PASS',flush=True)
  d['passed']=True
 except Exception as e:d.update(failure=repr(e),traceback=traceback.format_exc());raise
 finally:
  files=[Path(__file__),Path(T.__file__),P/'build-proof.json',P/'runtime.dbg',P/'ram1.bin',P/'ram2.bin',P/'ram3.bin',T.N,T.N.with_suffix('.dbg')]
  d['bindings']={str(p.resolve()):sha(p)for p in files};path=O/'controls.json';path.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(path=str(path),sha256=sha(path),passed=d['passed'],failure=d.get('failure'))),flush=True)

if __name__=='__main__':main()


