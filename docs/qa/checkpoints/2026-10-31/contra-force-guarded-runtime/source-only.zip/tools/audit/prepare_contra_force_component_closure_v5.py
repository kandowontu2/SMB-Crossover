"""Split genuine shared RTS leaves, preserving actual source fallthrough edges.

v3/v4 conservatively pulled donor level/VRAM code through a shared one-byte
RTS label. No linked/execution claim was made. This measures true leaves and
retains any required next source block when a code chunk falls through.
"""
from pathlib import Path
R=Path(__file__).resolve().parents[2];P=Path(__file__).with_name('prepare_contra_force_component_closure_v1.py')
s=P.read_text(encoding='utf-8').replace('build/contra-force-component-closure-v1','build/contra-force-component-closure-v5')
mark='# These are real original services'
pre=r'''counts={}
for bank,text in banks.items():
 for name in re.findall(r'^(\w+):',text,re.M):counts.setdefault(name,set()).add(bank)
duplicates={name for name,owners in counts.items()if len(owners)>1}
for bank,text in banks.items():
 for name in duplicates:
  if bank in counts[name]:text=re.sub(r'\b'+re.escape(name)+r'\b','Cf'+bank+'_'+name,text)
 # No opcode changes: merely identify actual standalone shared RTS leaves.
 text=re.sub(r'(?m)^(bra_\w+_RTS:\s*\n[ \t]*RTS)[ \t]*',r'\n\n\n\n\1\n\n\n',text)
 banks[bank]=text
'''
s=s.replace(mark,pre+'\n'+mark)
s=s.replace("'sub_0x003315','sub_B388','sub_BA51',", "'sub_0x003315','sub_B388','sub_BA51','sub_0x003393',")
s=s.replace(" assert not(set(z['labels'])&boundary),('boundary shares source chunk',z['labels'])", " # Shared unused native entries retain original instructions, no host claim.")
needle=" edges[name]=sorted(refs);todo.extend(refs)"
fall=r''' # Preserve code falling through a split leaf/next native source block.
 lines=[v.strip()for v in code.splitlines()if v.strip()and not v.strip().endswith(':')]
 tail=lines[-1]if lines else ''
 if re.match(r'(?i)^(?:LDA|LDX|LDY|STA|STX|STY|JSR|BCC|BCS|BEQ|BNE|BMI|BPL|BVC|BVS|CLC|SEC|ADC|SBC|AND|ORA|EOR|ASL|LSR|ROL|ROR|INC|DEC|INX|DEX|INY|DEY|TAX|TAY|TXA|TYA|PHA|PLA|PHP|PLP|NOP)\b',tail):
  if k+1<len(chunks)and chunks[k+1]['bank']==z['bank']:
   refs.add(chunks[k+1]['labels'][0])
 edges[name]=sorted(refs);todo.extend(refs)'''
assert needle in s;s=s.replace(needle,fall)
exec(compile(s,str(P),'exec'),{'__name__':'__main__','__file__':str(Path(__file__).resolve())})
