"""Replace donor callback gates with actual source/native boundaries privately."""
from pathlib import Path
import hashlib,json,re,subprocess,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
from private_build_outputs_v1 import validate
from prepare_ff_current_component_v2 import qualified
from check_tmnt_render_oa import address,location
P=R/'build/contra-force-render-arena-v1'
O=R/'build/contra-force-host-boundaries-v5'
N=R/'build/peach-palette-fix-1030-v1/joint/candidate.nes'
H=R/'tools/reference/contra_force_host_boundaries_v4.s'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
 assert not O.exists();O.mkdir();logs=[]
 try:
  old=json.loads((P/'build-proof.json').read_text())
  for p,h in old['bindings'].items():assert sha(p)==h,p
  names=['component','phase-bridge','native-imports','host-runtime','host-gates','render','body-meta','shot-meta']
  for n in names:(O/(n+'.s')).write_bytes((P/(n+'.s')).read_bytes())
  (O/'state.inc').write_bytes((P/'state.inc').read_bytes())
  runtime=R/'tools/reference/contra_force_host_runtime_v4.s'
  host=runtime.read_text()
  for before,after in [('CfNativeInput','CfHostCallInput'),('CfNativeBody','CfHostCallBody')]:host=re.sub(r'\b'+before+r'\b',after,host)
  (O/'host-runtime.s').write_text(host)
  text=(O/'component.s').read_text()
  text+='\n.export CfNativeAnimation24 := ofs_006_0x009793_24\n.export CfNativeShotImpact := ofs_020_B331_04\n'
  (O/'component.s').write_text(text)
  text=H.read_text().replace('CfNativeAdvance','CfHostCallAdvance').replace('CfNativeAnimation24','CfHostCallAnimation24')
  # Long source-safe branches are required across the complete native actor
  # loop. Original body/weapon instructions are never rewritten here.
  at=text.index('CfHostShotContacts:');end=text.index(' txa\n pha\n ldx #7',at)
  text=text[:at]+text[at:end].replace(' beq CfNoContact',' jeq CfNoContact').replace(' bne CfNoContact',' jne CfNoContact')+text[end:]
  (O/'boundaries.s').write_text(text);names+=['boundaries','boundary-gates']
  gates=['.import CfNativeAdvance,CfNativeAnimation24,CfCallA,CfTarget,CfTargetBank',
         '.export CfHostCallAdvance,CfHostCallAnimation24','.segment "CF_HOST_BOUNDARIES"']
  for n,target in[('CfHostCallAdvance','CfNativeAdvance'),('CfHostCallAnimation24','CfNativeAnimation24')]:
   gates+=[n+':',' php',' pha',' lda #<'+target,' sta CfTarget',' lda #>'+target,' sta CfTarget+1',' lda #1',' sta CfTargetBank',' pla',' plp',' jmp CfCallA']
  (O/'boundary-gates.s').write_text('\n'.join(gates)+'\n')
  b=qualified(N);imports=set()
  for row in re.findall(r'^\.import(?:zp)? (.*)',H.read_text(),re.M):imports.update(row.split(','))
  imports={n for n in imports if not n.startswith('Cf')}|{'CurrentBank'}
  native=(O/'native-imports.s').read_text();new=[]
  for n in sorted(imports):
   assert n in b['syms'],n
   if not re.search(r'^\.export '+n+r'$',native,re.M):native+='\n.export '+n+'\n'+n+'=$%04x\n'%address(b,n);new.append(n)
  (O/'native-imports.s').write_text(native)
  cfg=(P/'runtime.cfg').read_text().replace(' ORACLE_GATES:load=ORACLE,type=ro;','')
  cfg=cfg.replace(' CF_GATES_1:',' CF_HOST_CALLBACK_GATES:load=C2,type=ro;\n CF_HOST_BOUNDARIES:load=A3,type=ro;\n CF_GATES_1:')
  (O/'runtime.cfg').write_text(cfg)
  ca=R/'tools/Windows/cc65/bin/ca65.exe';ld=ca.with_name('ld65.exe')
  def run(cmd):
   guard=validate(cmd,O,cwd=O);p=subprocess.run(cmd,cwd=O,capture_output=True,text=True)
   logs.append(dict(command=cmd,cwd=str(O),output_guard=guard,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr))
   (O/'build-log.json').write_text(json.dumps(logs,indent=2)+'\n');assert p.returncode==0,logs[-1]
  for n in names:run([str(ca),'--cpu','6502x','-g','-I',str(R/'build/contra-force-reproduction-v2'),'--create-full-dep',str(O/(n+'.dep')),'-o',str(O/(n+'.o')),str(O/(n+'.s'))])
  run([str(ld),'-C',str(O/'runtime.cfg'),'-o',str(O/'unused.bin'),'--dbgfile',str(O/'runtime.dbg'),'-Ln',str(O/'runtime.lbl'),'-m',str(O/'runtime.map'),*[str(O/(n+'.o'))for n in names]])
  segs={}
  for line in(O/'runtime.dbg').read_text().splitlines():
   if line.startswith('seg\t'):
    fields=dict(re.findall(r'(\w+)=("[^"]*"|[^,]+)',line[4:]));segs[fields['name'].strip('"')]=int(fields['size'],0)
  out=dict(passed=True,source=True,native=False,ready=False,actual_cart_hooks=False,
   source_ORACLE_BRK_services_remaining=0,
   actual_segments={n:segs[n]for n in['CF_HOST_CALLBACK_GATES','CF_HOST_BOUNDARIES']},
   actual_native_imports={n:dict(PC=address(b,n),physical_bank=(location(b,n)-16)//8192 if 'seg'in b['syms'][n]and 'ooffs'in b['segs'][b['syms'][n]['seg']]else None)for n in sorted(imports)},
   scope='Preloadable actual native/source boundary image. Original body/weapon source retained; script24 original, script0 SMB world adaptation, script25 explicit no donor partner, illegal AI request latched. Native ordinary/Bowser hits/pickups are new source adapters and need CPU controls. No P1 ownership or readiness.',
   bindings={str(p.resolve()):sha(p)for p in[Path(__file__),H,runtime,P/'build-proof.json',N,N.with_suffix('.dbg'),ca,ld,R/'tools/audit/private_build_outputs_v1.py',*[p for p in O.iterdir()if p.is_file()]]})
  path=O/'build-proof.json';path.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(path=str(path),sha256=sha(path),segments=out['actual_segments'])),flush=True)
 except Exception as e:
  (O/'negative.json').write_text(json.dumps(dict(passed=False,error=repr(e),traceback=traceback.format_exc(),commands=logs),indent=2)+'\n');raise

if __name__=='__main__':main()




