"""Keep all indexed source scratch in RAM; borrow only one indirect pair.

Every actual (sourcepair),Y/JMP(sourcepair) site saves A/P, projects the true
source pointer, restores A/P, and executes the original instruction. This
avoids assuming that separately compacted native pairs form an indexed array.
"""
from pathlib import Path
R=Path(__file__).resolve().parents[2];P=Path(__file__).with_name('prepare_contra_force_compact_arena_v1.py')
s=P.read_text(encoding='utf-8').replace('build/contra-force-compact-arena-v1','build/contra-force-compact-arena-v2')
needle="(O/'state.inc').write_text(state,encoding='utf-8')"
add=r'''# All original fields, including direct/indexed pointer bytes, remain in
# their genuine relative source RAM ranges. Only indirect hardware uses ZP.
for name,z in d['field_map'].items():
 a=z['original'];target='CfState+$%04x'%(page[a//256]*256+a%256)
 state=re.sub(r'(?m)^'+re.escape(name)+r' = [^\n]+',name+' = '+target,state)
state=state.replace('CfPointers: .res 10','CfPointers: .res 2')
'''
assert needle in s;s=s.replace(needle,add+'\n'+needle)
needle="(O/'component.s').write_text(source,encoding='utf-8')"
add=r'''sites=[]
pattern=re.compile(r'(?m)^(\s*)(LDA|STA|ADC|SBC|AND|ORA|EOR|CMP|JMP)\s+\((ram_\w+)\)(\s*,\s*Y)?([^\n]*)$')
def indirect(m):
 indent,op,pointer,index,comment=m.groups()
 assert(op=='JMP')==(not index),(op,pointer,index)
 sites.append(dict(instruction=op,source_pointer=pointer,indexed=bool(index)))
 return '\n'.join(indent+v for v in[
  'php','pha','lda '+pointer,'sta CfPointers','lda '+pointer+'+1',
  'sta CfPointers+1','pla','plp',op+' (CfPointers)'+(',Y'if index else'')+comment])
source=pattern.sub(indirect,source)
assert sites and not re.search(r'\(ram_\w+\)',re.sub(r';[^\n]*','',source))
(O/'indirect-sites.json').write_text(json.dumps(sites,indent=2)+'\n',encoding='utf-8')
'''
assert needle in s;s=s.replace(needle,add+'\n'+needle)
s=s.replace("pointer_bytes=d['abstract_zero_page_bytes']",'pointer_bytes=2')
exec(compile(s,str(P),'exec'),{'__name__':'__main__','__file__':str(Path(__file__).resolve())})
