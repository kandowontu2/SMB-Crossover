"""Inventory original live CF shot OAM/CHR/color consumers, no recoloring."""
from pathlib import Path
import hashlib,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit')]
import contra_force_engine_probe_v1 as T
from verify_native_relocation import NesMPU
O=R/'build/contra-force-shot-art-inventory-v1';assert not O.exists();O.mkdir()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
CHR=T.RAW[16+131072:]
class Mem(T.Mem):
 def pair(self,lo):
  self.reg[6:8]=[lo,lo+1];self[0x36]={0:0,4:2,10:1}[lo];self.map()
def render(c,slot):
 m=c.memory;m.pair(0)
 for i in range(64):m[0x200+4*i]=244
 m[8]=slot;m[1]=64
 T.call(c,0xd35b,a=m[0x61a+slot],x=0,y=slot)
 return [dict(oam=i,x=m[0x203+4*i],y=m[0x200+4*i],tile=m[0x201+4*i],attr=m[0x202+4*i])for i in range(64)if m[0x200+4*i]<240]
def pattern(tile,banks):
 start=(tile&1)*4096+(tile&254)*16
 return bytes(CHR[banks[(start+i)//1024]*1024+(start+i)%1024]for i in range(32))
def indices(pair):
 return sorted({((pair[(y//8)*16+y%8]>>(7-x))&1)|(((pair[(y//8)*16+y%8+8]>>(7-x))&1)<<1)for y in range(16)for x in range(8)}-{0})
d=dict(passed=False,native=False,host=False,views=[],cohorts=[],source_chr_windows='Original stage1 source/native body capture map:48,49,50,51,4,classPage,0,13.',scope='Twelve native allocated weapons,96 original projectile Main updates percohort; actual original D35B/OAM and original F4B1 A0 palette consumer. No host publisher or palette adaptation.')
try:
 views={};pairs=set();colors=set()
 for var in range(4):
  for gear in range(3):
   m=Mem();m.pair(4);m[0xb1]=var;m[0x7f+var]=16|gear;m[0x782]=46;m[0x64e]=112;m[0x668]=168;m[0x682]=10;m[0x7d2]=1
   c=NesMPU(memory=m);m.pair(10);T.call(c,0x97cf);banks=[48,49,50,51,m[0x79],m[0x7a],0,13]
   T.call(c,0xf4b1,a=0,y=2);palette=list(m[0x3b0:0x3d0]);T.step(c,64)
   found=set()
   for age in range(96):
    m.pair(4);m[0x23]=(m[0x23]+1)&255;T.call(c,0x8132)
    for slot in range(10,22):
     if not m[0x682+slot]or not m[0x61a+slot]:continue
     kind,frame,hi=m[0x682+slot],m[0x61a+slot],m[0x634+slot]
     parts=render(c,slot);key=(kind,frame,hi,tuple((p['tile'],p['attr'],(p['x']-m[0x64e+slot])&255,(p['y']-m[0x668+slot])&255)for p in parts))
     if key in views:found.add(views[key]['id']);continue
     roles=[]
     for p in parts:
      pair=pattern(p['tile'],banks);used=indices(pair);raw=[palette[16+4*(p['attr']&3)+i]for i in used]
      pairs.add(pair);colors.update(raw)
      roles.append(dict(tile=p['tile'],palette=p['attr']&3,used_indices=used,raw_NES_colors=raw,pair_sha256=hashlib.sha256(pair).hexdigest()))
     z=dict(id=len(views),variant=var,gear=gear,source_age=age,slot=slot,kind=kind,frame=frame,high=hi,original_parts=parts,actual_roles=roles)
     views[key]=z;found.add(z['id'])
   d['cohorts'].append(dict(variant=var,gear=gear,source_CHR=banks,source_sprite_palettes=palette[16:32],view_ids=sorted(found)))
 d.update(passed=True,views=list(views.values()),unique_original_pattern_pairs=len(pairs),actual_source_raw_colors=sorted(colors),maximum_parts_per_actor=max(len(v['original_parts'])for v in views.values()))
except Exception as e:d.update(error=repr(e),traceback=traceback.format_exc());raise
finally:
 files=[Path(__file__),Path(T.__file__),R/'tools/audit/verify_native_relocation.py',T.P/'candidate.nes',T.P/'proof.json',R/'build/contra-force-body-art-v6/manifest.json']
 d['bindings']={str(p.resolve()):sha(p)for p in files}
 p=O/'inventory.json';p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8');print(json.dumps(dict(passed=d['passed'],path=str(p),sha256=sha(p),views=len(d['views']),pairs=d.get('unique_original_pattern_pairs'),colors=d.get('actual_source_raw_colors'),error=d.get('error'))),flush=True)
