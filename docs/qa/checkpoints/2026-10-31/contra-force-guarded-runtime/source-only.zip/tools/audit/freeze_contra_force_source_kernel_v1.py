"""Freeze source-only CF kernel progress and explicit incomplete host plan."""
from pathlib import Path
import hashlib,json,zipfile
R=Path(__file__).resolve().parents[2]
O=R/'build/contra-force-source-kernel-qualified-v1';assert not O.exists();O.mkdir()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
reports=[
 'build/contra-force-initial-source-qualified-v1/handoff.json',
 'build/contra-force-weapon-probe-v1/controls.json',
 'build/contra-force-core-object-v4/source-object-proof.json',
 'build/contra-force-component-closure-v3/closure.json',
 'build/contra-force-component-closure-v3/object/source-object-proof.json',
 'build/contra-force-component-closure-v4/object/source-object-proof.json',
 'build/contra-force-component-closure-v5/closure.json',
 'build/contra-force-component-closure-v5/object/source-object-proof.json',
 'build/contra-force-compact-arena-v1/build-proof.json',
 'build/contra-force-compact-arena-v2/build-proof.json',
 'build/contra-force-compact-arena-controls-v3/controls.json',
 'build/contra-force-compact-shot-controls-v1/controls.json',
 'build/contra-force-body-pack-v1/packing.json',
 'build/contra-force-body-pack-v2/packing.json',
 'build/contra-force-body-pack-v3/packing.json',
 'build/contra-force-shot-art-inventory-v1/inventory.json',
 'build/contra-force-jump-adaptation-v1/build-proof.json',
 'build/contra-force-jump-adaptation-controls-v1/controls.json',
 'build/contra-force-host-object-v1/build-proof.json']
bindings={};paths=set()
def bind(p):
 p=Path(p).resolve();assert p.is_file(),p
 h=sha(p)
 if str(p)in bindings:assert bindings[str(p)]==h,p
 bindings[str(p)]=h;paths.add(p)
for rel in reports:
 p=R/rel;d=json.loads(p.read_text(encoding='utf-8'));bind(p)
 for q,h in d.get('bindings',{}).items():
  assert sha(q)==h,q
  bind(q)
# Source-generator wrappers are actual inputs, even when older receipts did
# not enumerate the executed parent text; bind all CF lineage explicitly.
tools=sorted({*list((R/'tools/audit').glob('*contra_force*.py'))})
for p in tools:bind(p)
bind(R/'tools/reference/contra_force_host_runtime_v1.s')
negatives=[]
for rel in['contra-force-component-closure-v1','contra-force-component-closure-v2','contra-force-compact-arena-controls-v1','contra-force-compact-arena-controls-v2']:
 p=R/'build'/rel/'preparation-negative.json';bind(p);negatives.append(str(p))
parent=R/'build/benj-menu-unlocked-1030-v3/handoff.json';bind(parent)
native=parent.parent/'joint/candidate.nes';bind(native)
plan=dict(status='RESOURCE_PROPOSAL_ONLY_NO_GRANT',
 actual_current64_parent=sha(native),slot=30,raw=31,variants=['Burns','Smith','Iron','Beans'],identity='FmGroups bits3..4; preserve18hex onlyslot30 at Start. Preserve current MarioVariant5/6/BmFresh/BmColors and future BT20/Bowser08 identities.',
 measured=dict(source_code_animation_and_OAM=14725,source_state=1280,borrowed_ZP=2,partial_host_worker=737,minimum_total=16742,minimum_over_16KB=358,
               note='Before payload cookies, native shot-hit/collection, render metadata/emitter, phase transport, palette ownership and ROM loader/router. A16KB fit is explicitly rejected.'),
 architecture_proposed=dict(code='RawA1 plus a second temporal A-code phase raw03 only if parent approves sharing RAM3 after prior BT/Bowser owner retirement. C2 holds private state/data plus a small always-mapped A-bank transport worker.',
  alternate='RetainA1/C2 only if parent can grant genuine ROM islands for enough source workers/glue; no island requested solely from fill.',
  carrier='At most24pages for complete three-bank guest image, subject actual packed output and producer closure.935+ only; no physical write or lease assumed.',
  art='9 measured lossless body pages + tentative1 common-shot page (22 original pairs before target remap; full target packing still pending). Conservative total34pages935..<969 is a proposal, not final size/grant.',
  state='CF1280B whole source pages00/02/03/06/07.12 proposed authored bytes use unused original03E0..<03EC inside that selected-owner image. No global RAM0/ExRAM request.',
  cookie='Proposed family1F,alternate0..3 in sharedC2DFE0..<DFEF full16B; valid clear before touchingA1/C2/A3 and publish last after verification. Must retire Quick/Arthur/BT/Bowser and invalidate theRAM3cookie before overwrite. Not implemented/approved.',
  IRQ_NMI='No CF code in NMI. Main uses one borrowed indirect pair with fullA/P preservation at every site; dispatcher will save native pair and rawmaps.5FFF busy/real ISR cuts and loader forcedblank contracts still required.'),
 traversal=dict(original_full_hold=[64,56,49,60],declared_adaptation='Only two positive-age reads use source upward-base+$0080; native fall/release table unchanged.',adapted_full_hold=[81,72,64,77],actual_SMB_pipe_geometry='Required before readiness; source apex alone is not route qualification.'),
 palette=dict(body='P0[37,12,0F] plus nativeP2 index1=16 red-only mask; source pixel/priority exact156views,9pages,max12parts/max8line bodyalone.',
  actual_shots='OriginalP3[20,38,16] for default bullets/explosions; sourceP0 lasers and occasionalP1 red/black roles also occur.65 actual views22 pattern pairs,raw colors0F/12/16/20/37/38.',
  pending='Exact yellow38 has no matching ordinary native donor. Investigate borrowing original sourceP3 with whole-native-P3-object fairness (or P1 family scheduler) and exact native restore. Do not recolor world/weapon or assume P3 unused. Actual source sprite counts/window coexistence must pass.'),
 shared_API='Existing accepted service index inArenaGateBank and originalA/P/Y SFC contract proposed. Parent dispatcher owner must fit raw31 ingress; noA79 edit or36row assumed.',
 explicit_original_oracle_services=json.loads((R/'build/contra-force-jump-adaptation-v1/build-proof.json').read_text())['original_services_executed_by_fixture_only'],
 host_next=['native typed terrain all7probes/postBG/automatic4/5','source-shot real native enemy/breakable-block damage and cleanup','mature mushroom/flower plus star/1UP native writers','actual constructor/retire and two-player/life/area progression','ROM-only select/lives before cache readiness','full source render/palette/window/OAM admission','actual cold controller1-1/64px pipe checks'])
(O/'host-resource-proposal.json').write_text(json.dumps(plan,indent=2)+'\n',encoding='utf-8');bind(O/'host-resource-proposal.json')
summary='''Contra Force source kernel: private CPU progress, NOT playable admission

Original ba533736 PRG/CHR reproduces exactly from pinned cyneprepou4uk source.
All4 classes preserve distinct original speeds/aim/variable jump/weapon types.
864 linked projected input/body update pairs compare519 actor/stats bytes each.
576 linked source projectile-handler/animation pairs match original8132 Main.
Those comparisons execute remaining services in the original ROM oracle; they
do not implement SMB terrain, damage, loader, audio, lifecycle or native play.

Only2 borrowed indirect bytes are needed. All original indexed scratch remains
in private1280B source pages. The9-page body pack preserves opaque black, every
visible NES color and BG-priority for156 source views; max12parts/8perline.
Actual shot art adds22 unique original pairs across65 views; original yellow38
requires a palette-ownership solution. No guessed colors have been adopted.

The approved source upward-base+$80 adaptation gives81/72/64/77px full jumps.
1536 native falling/released endpoints stay exact. A real64px SMB pipe route
is still owed. Original64/56/49/60px arcs remain in the receipt.

Measured source+state+partial737B host already exceeds16KB before cookies,
renderer/shot-hit/loader/dispatch. See host-resource-proposal.json. There is NO
CF RAM3/PRG/CHR grant, no installed/common edit and no native capture.
Previous parser, bank-local-label and conservative whole-chunk measurements
remain retained. v3/v4 16217B code is a conservative donor-level/VRAM closure;
v5 isolates actual sharedRTS leaves with true fallthrough and compiles9412B.
'''
(O/'README.txt').write_text(summary,encoding='utf-8');bind(O/'README.txt')
# Source-only export deliberately omits ROM/object/debug/map/cache binaries.
allowed={'.py','.s','.asm','.inc','.cfg','.json','.txt','.md','.dep','.lua','.sh','.bat'}
members={p for p in paths if p.is_relative_to(R)and p.suffix.lower()in allowed and p.suffix.lower()not in{'.dbg','.lbl','.map'}}
archive=O/'source-only.zip'
with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
 for p in sorted(members):z.write(p,p.relative_to(R).as_posix())
assert archive.stat().st_size<10*1024*1024
with zipfile.ZipFile(archive)as z:
 assert len(z.infolist())==len(members)
 for p in members:assert hashlib.sha256(z.read(p.relative_to(R).as_posix())).hexdigest()==sha(p)
bind(archive)
hpd=dict(status='FROZEN_SOURCE_KERNEL_CPU_ONLY_UNIMPLEMENTED_HOST_NO_GRANT',source=True,native=False,host=False,admitted=False,
 checks=dict(original_weapon_cohorts=12,original_weapon_updates=576,linked_input_body_pairs=864,compared_actor_bytes=519,linked_projectile_Main_pairs=576,fall_or_release_exact_endpoints=1536,body_pixel_priority_views=156,shot_OAM_CHR_palette_views=65),
 native_oracle_caveat='All remaining service callbacks and original position integration execute genuine donor-ROM instructions in explicit CPU fixtures, not SMB adapters.',
 actual_parent64=sha(native),proposal=str(O/'host-resource-proposal.json'),retained_preparation_negatives=negatives,
 archive=dict(path=str(archive),sha256=sha(archive),bytes=archive.stat().st_size,members=len(members)),
 bindings=bindings)
p=O/'handoff.json';p.write_text(json.dumps(hpd,indent=2)+'\n',encoding='utf-8')
print(json.dumps(dict(path=str(p),sha256=sha(p),bindings=len(bindings),archive_bytes=archive.stat().st_size,members=len(members),proposal_sha256=sha(O/'host-resource-proposal.json'))),flush=True)
