"""Retain original arcs and check adapted source fall/variable-hold controls."""
from pathlib import Path
import hashlib,json,re,traceback
R=Path(__file__).resolve().parents[2];P=Path(__file__).with_name('contra_force_compact_arena_controls_v1.py')
s=re.sub(r'\b(else|if)(?=\d)',r'\1 ',P.read_text(encoding='utf-8')).replace('build/contra-force-compact-arena-v2','build/contra-force-jump-adaptation-v1')
g={'__name__':'cf_definitions','__file__':str(P)};exec(compile(s,str(P),'exec'),g)
T,at,original,arena,call,compare,step,proof=[g[n]for n in['T','at','original','arena','call','compare','step','proof']]
O=R/'build/contra-force-jump-adaptation-controls-v1';assert not O.exists();O.mkdir()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
d=dict(passed=False,native=False,host=False,original_arcs=[],adapted_arcs=[],scope='Declared native upward-base+$80 source adaptation. Original falling/released paths compared; explicit arena source contacts and donor position oracle. Actual SMB pipe collision still required.')
try:
 for p,h in proof['bindings'].items():assert sha(p)==h,p
 count=0
 for var in range(4):
  for phase in range(256):
   for held in range(2):
    if phase<128 and held:continue
    z=original(var,0);m=z.memory;m[0x7b4]=phase;m[0x7aa]=64|(32 if held else 0);m[0x7d2]=0;m[0x668]=128
    c=arena(z);T.call(z,0xab42);call(c,'CfNativeJump');compare(c,z,(var,phase,held));count+=1
 for var in range(4):
  for hold in[1,20,80]:
   for adapted in[False,True]:
    z=original(var,0);c=arena(z);rows=[]
    for age in range(96):
     pad=128 if age<hold else 0
     if adapted:
      m=c.memory;step(c,pad,not(m[at(0x7aa)]&64))
      y=m[at(0x668)];lo=m[at(0x7ea)];hi=m[at(0x7ec)];dy=lo+256*hi;dy=dy-65536 if dy>=32768 else dy
      phase=m[at(0x7b4)]
     else:
      q=T.step(z,pad,not(z.memory[0x7aa]&64));y=q['y'];dy=q['dY'];phase=z.memory[0x7b4]
     rows.append(dict(age=age,y=y,dY=dy,phase=phase))
     if age>1 and dy>=0 and y>=168:break
    q=dict(variant=var,A_hold_updates=hold,apex_pixels=168-min(r['y']for r in rows),updates=rows)
    d['adapted_arcs'if adapted else'original_arcs'].append(q)
 full=[q['apex_pixels']for q in d['adapted_arcs']if q['A_hold_updates']==80]
 assert len(full)==4 and min(full)>=64,full
 for var in range(4):
  peaks=[q['apex_pixels']for q in d['adapted_arcs']if q['variant']==var]
  assert peaks[0]<peaks[1]<peaks[2],(var,peaks)
 d.update(passed=True,exact_original_falling_or_released_endpoints=count,full_hold_apex_pixels=full,
          source_horizontal_tables_unchanged=True,readiness=False,
          remaining='Exact64px tallest-pipe crossing/landing with real SMB head/feet/side order, actual controls and existing sprite/body bound still owed.')
except Exception as e:d.update(error=repr(e),traceback=traceback.format_exc());raise
finally:
 files=[Path(__file__),P,R/'tools/audit/contra_force_engine_probe_v1.py',R/'tools/audit/verify_native_relocation.py',R/'build/contra-force-jump-adaptation-v1/build-proof.json',R/'build/contra-force-jump-adaptation-v1/arena.bin',R/'build/contra-force-jump-adaptation-v1/arena.dbg',T.P/'candidate.nes',T.P/'candidate.dbg']
 d['bindings']={str(p.resolve()):sha(p)for p in files}
 p=O/'controls.json';p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8');print(json.dumps(dict(path=str(p),sha256=sha(p),passed=d['passed'],full=d.get('full_hold_apex_pixels'),exact=d.get('exact_original_falling_or_released_endpoints'),error=d.get('error'))),flush=True)
