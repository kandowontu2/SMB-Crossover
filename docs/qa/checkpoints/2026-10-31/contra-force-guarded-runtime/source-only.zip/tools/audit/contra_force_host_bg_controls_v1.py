"""CF source movement and real native BG with explicit staged typed routes.

Guest RAM is preloaded. Only the listed selectors redirect through genuine
FarCallCommon; all native world decisions and block/pipe consumers execute.
This is not an installed common dispatcher, loader, Main, or native run.
"""
from pathlib import Path
import hashlib,importlib.util,itertools,json,re,sys,traceback
R=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
from verify_native_relocation import NesMPU
from prepare_ff_current_component_v2 import qualified
from check_tmnt_render_oa import address,location
from arthur_cache_host_controls_v1 import OverlayMemory
P=R/'build/contra-force-host-arena-v3'
N=R/'build/peach-palette-fix-1030-v1/joint/candidate.nes'
O=R/'build/contra-force-host-bg-controls-v1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

sp=importlib.util.spec_from_file_location('cf_split_source_definitions',R/'tools/audit/contra_force_runtime_split_controls_v1.py')
S=importlib.util.module_from_spec(sp);sp.loader.exec_module(S)
B=qualified(N);L=S.g['labels'](P/'runtime.dbg')
ROUTES={'MegaManCollisionAdder':'CfHostAdder','HuBillBGHeadFast':'CfHostHead',
        'GmFootResident':'CfHostFeet','CrossoverSourceSideProbe':'CfHostSide',
        'CrossoverHeadWithinTerrain':'CfHostHeadWithin'}
TARGETS={address(B,n):(n,t)for n,t in ROUTES.items()}
GATES={L[n]:n for n in json.loads((P/'build-proof.json').read_text())['unresolved_original_oracles']}

def get(m,n,i=0):return m[address(B,n)+i]
def put(m,**values):
 for n,v in values.items():m[address(B,n)]=v

def make(var,x=120,y=176):
 m=OverlayMemory(B)
 for bank in[1,2,3]:
  data=(P/f'ram{bank}.bin').read_bytes();m.ram[bank][:]=data+bytes(8192-len(data))
 m.raw_page(2,2)
 put(m,CurrentBankC=2,SelectedCharacter=31,FmGroups=var<<3,PlayerStatus=0,
     OperMode=1,GameEngineSubroutine=8,TimerControl=0,GamePauseStatus=0,
     NumberofLives=2,AreaType=1,Player_X_Position=x&255,Player_PageLoc=x>>8,
     Player_Y_Position=y,Player_Y_HighPos=1,Player_X_Speed=0,Player_Y_Speed=0,
     Player_State=0,PlayerFacingDir=1,PlayerSize=0,CrouchingFlag=0,
     ScreenLeft_X_Pos=0,ScreenLeft_PageLoc=0,DisableCollisionDet=0,SwimmingFlag=0,
     JumpspringAnimCtrl=0,BlockBounceTimer=0,GuestHurtTicks=0,InjuryTimer=0,
     StarInvincibleTimer=0,SprDataOffset_Ctrl=0,Player_MovingDir=1)
 for a in range(address(B,'Block_Buffer_1'),address(B,'Block_Buffer_2')+208):m[a]=0
 run(m,'CfHostConstruct');m.writes.clear();m.ram_writes.clear()
 return m

def run(m,name,a=0,x=0,y=0,p=0x30,staged=False):
 target=L[name]if name.startswith('Cf')else address(B,name)
 bank=3 if name.startswith('Cf')else ((location(B,name)-16)//8192)|128
 m[address(B,'SafecallA_SMC')+1]=a
 m[address(B,'FarcallJmpTarget_SMC')+1]=target&255
 m[address(B,'FarcallJmpTarget_SMC')+2]=target>>8
 c=NesMPU(memory=m,pc=address(B,'FarCallCommon'));c.a=bank;c.x=x;c.y=y;c.p=p;c.sp=224;c.stPushWord(0x7ffe)
 before=m.rawtags[:];trace=[];routes=[];oracles={};low=c.sp
 for step in range(100000):
  if c.pc==0x7fff:break
  if staged and c.pc in TARGETS:
   source,dest=TARGETS[c.pc];routes.append((source,dest,c.y))
   pc=L[dest];m[address(B,'SafecallA_SMC')+1]=c.a
   m[address(B,'FarcallJmpTarget_SMC')+1]=pc&255;m[address(B,'FarcallJmpTarget_SMC')+2]=pc>>8
   c.a=3;c.pc=address(B,'FarCallCommon')
  if c.pc in GATES:
   service=GATES[c.pc];oracles[service]=oracles.get(service,0)+1;S.donor_oracle(c,service)
  else:
   assert m[c.pc],('actual source/native BRK',name,hex(c.pc),m.rawtags,trace[-12:])
   trace.append((c.pc,m.rawtags[(c.pc-0x8000)//8192]if c.pc>=0x8000 else-1));c.step()
  low=min(low,c.sp)
 else:raise AssertionError(('source/native bound',name,hex(c.pc),m.rawtags,trace[-12:]))
 assert c.sp==224 and m.rawtags==before and get(m,'CurrentBank')==before[1]and get(m,'CurrentBankC')==before[2],(name,c.sp,m.rawtags,before)
 return c,dict(CPU=c.processorCycles,minimumSP=low,typed_routes=routes,donor_oracles=oracles)

def cell(m,wx,y,tile):
 base=address(B,'Block_Buffer_1')+(208 if(wx>>8)&1 else 0)+(wx&255)//16
 row=(y//16)*16-32;assert 0<=row<208
 m[base+row]=tile

def world(m,pipe_x=192):
 # Genuine native solidity table and 32pxwide/64pxhigh pipe geometry. This
 # finite CPU world DATA is a fixture; it is not a native controller replay.
 solid=0x61
 assert m[address(B,'MTileAttribute')+solid]&address(B,'MTILE_SOLID')
 for wx in range(0,512,16):cell(m,wx,208,solid);cell(m,wx,224,solid)
 for wx in range(pipe_x,pipe_x+32,16):
  for yy in range(144,208,16):cell(m,wx,yy,solid)

def query_controls():
 rows=[]
 for var in range(4):
  m=make(var)
  for px,page,py,index in itertools.product([0,1,15,247,255],[0,1],[48,99,176,200],range(7)):
   if py+[1,32,32,8,31,8,31][index]>=240:continue
   for a in range(address(B,'Block_Buffer_1'),address(B,'Block_Buffer_2')+208):m[a]=((a*17+31)%254)+1
   put(m,Player_X_Position=px,Player_PageLoc=page,Player_Y_Position=py,CrouchingFlag=0)
   dx=[8,1,15,1,1,15,15][index];dy=[1,32,32,8,31,8,31][index]
   wx=page*256+px+dx;base=address(B,'Block_Buffer_1')+(208 if(wx>>8)&1 else 0)+(wx&255)//16;row=((py+dy)//16)*16-32
   name='CfHostHead'if index==0 else'CfHostFeet'if index<3 else'CfHostSide'
   c,out=run(m,name,y=index-1 if index<3 and index else index)
   expected=m[base+row]
   assert(c.a,c.x,c.y)==(expected,0,index),(var,px,page,py,index,c.a,expected,c.y)
   assert[get(m,n)for n in['R2','R3','R6','R7']]==[row,expected,base&255,base>>8]
   assert get(m,'R4')==((py if index<3 else px)&15)
   rows.append([var,px,page,py,index,expected])
 return dict(actual_native_BlockBufferAddr_queries=len(rows),source_1_or17top_32feet_1_to15width=True)

def pipe_controls():
 rows=[]
 for var in range(4):
  successes=[];attempts=[]
  for launch_x in[152,156,160,164,168]:
   m=make(var,launch_x);world(m);positions=[];landed=False
   for age in range(112):
    keys=129 if age<76 else 1
    put(m,SavedJoypadBits=keys)
    run(m,'CfHostMovement')
    _,bg=run(m,'PlayerBGCollision',staged=True)
    run(m,'CfHostAfterBG')
    wx=get(m,'Player_X_Position')+256*get(m,'Player_PageLoc');py=get(m,'Player_Y_Position')
    positions.append(dict(age=age,x=wx,y=py,state=get(m,'Player_State'),sourceDY=m[L['CfState']+0x4ea]+256*m[L['CfState']+0x4ec],routes=bg['typed_routes']))
    if 192<=wx<224 and py==112 and get(m,'Player_State')==0:landed=True
    if landed and wx>=225:break
   attempts.append(dict(launchX=launch_x,landedOn64pxPipe=landed,finalX=wx,minimumY=min(z['y']for z in positions)))
   if landed and wx>=225:successes.append(dict(launchX=launch_x,updates=positions));break
  assert successes,('actual native64pxpipe traversal failed',var,attempts)
  rows.append(dict(variant=var,attempts=attempts,successful=successes[0]))
  print('CF real native64pxpipe',var,'PASS',flush=True)
 return dict(classes=len(rows),actual_native_BG_driver=True,actual_source_input_body_and_host_position=True,native_controller_replay=False,rows=rows)

def main():
 assert not O.exists();O.mkdir();out=dict(passed=False,native=False,actual_cart_hooks=False,guest_RAM_fixture_preloaded=True,checks={})
 try:
  h=json.loads((P/'build-proof.json').read_text())
  for p,v in h['bindings'].items():assert sha(p)==v,p
  out['checks']['queries']=query_controls();print('CF typed queries PASS',flush=True)
  out['checks']['pipes']=pipe_controls();out['passed']=True
 except Exception as e:out.update(error=repr(e),traceback=traceback.format_exc());raise
 finally:
  paths=[Path(__file__),Path(S.__file__),P/'build-proof.json',P/'runtime.dbg',P/'ram1.bin',P/'ram2.bin',P/'ram3.bin',N,N.with_suffix('.dbg'),R/'tools/audit/arthur_cache_host_controls_v1.py',R/'tools/audit/verify_native_relocation.py']
  out['bindings']={str(p.resolve()):sha(p)for p in paths}
  path=O/'controls.json';path.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(path=str(path),sha256=sha(path),passed=out['passed'],error=out.get('error'))),flush=True)

if __name__=='__main__':main()
