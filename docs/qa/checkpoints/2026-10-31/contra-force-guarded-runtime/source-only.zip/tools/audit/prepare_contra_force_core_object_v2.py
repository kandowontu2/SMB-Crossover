"""Retain v1 Windows-default decoding failure; donor text is explicitly UTF8."""
from pathlib import Path
P=Path(__file__).with_name('prepare_contra_force_core_object_v1.py')
s=P.read_text(encoding='utf-8').replace("O=R/'build/contra-force-core-object-v1'", "O=R/'build/contra-force-core-object-v2'")
s=s.replace('.read_text()', ".read_text(encoding='utf-8')")
exec(compile(s,str(P),'exec'),{'__name__':'__main__','__file__':str(Path(__file__).resolve())})
