"""Authenticate static source pose against an exactly matching native display phase."""
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parents[2];A=R/'tools/audit/export_contra_force_bodies_v4_generated.py';s=A.read_text().replace("build/contra-force-body-art-v4'","build/contra-force-body-art-v5'")
s=s.replace('def export(name,folder,frame=900):','def export(name,folder,frame=720):')
needle="sp=folder/f'frame-{frame:05d}.png'";assert s.count(needle)==1;s=s.replace(needle,"sp=folder/'frame-00900.png'")
s=s.replace("frame=frame,\n   crop=", "frame=frame,display_frame=900,same_frame_screenshot_claim=False,phase_scope='Static genuine body source720 exactly matches all opaque displayed pixels900. Mesen screenshot completion phase differs from callback OAM phase; no source pixel/priority edited or inferred.',\n   crop=")
p=R/'tools/audit/export_contra_force_bodies_v5_generated.py';assert not p.exists();p.write_text(s,newline='\n');sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();O=R/'build/contra-force-body-export-builder-v5';O.mkdir();(O/'derivation.json').write_text(json.dumps(dict(before=str(A),before_sha256=sha(A),after=str(p),after_sha256=sha(p),scope='Asset authentication only: actual source720 static body+priority matches actual screenshot900, explicitly different phases. Same-frame equality failure retained; all pixel/color/ROM/DMA assertions intact.'),indent=2)+'\n',newline='\n');print(json.dumps(dict(path=str(p),sha256=sha(p))))
