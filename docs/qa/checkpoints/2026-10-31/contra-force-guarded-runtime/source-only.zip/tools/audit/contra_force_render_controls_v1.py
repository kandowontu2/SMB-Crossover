"""Actual source record emission/capacity/window checks; no palette ownership.

Guest RAM is explicitly preloaded. Accepted sourceP3 shots use a fixture
ownership flag; this is not evidence of a real PPU palette commit protocol.
"""
from pathlib import Path
import hashlib,importlib.util,json,sys,traceback
R=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
sp=importlib.util.spec_from_file_location('cf_bg_render_definitions',R/'tools/audit/contra_force_host_bg_controls_v1.py')
T=importlib.util.module_from_spec(sp);sp.loader.exec_module(T)
P=R/'build/contra-force-render-arena-v1';O=R/'build/contra-force-render-controls-v1'
T.P=P;T.L=T.S.g['labels'](P/'runtime.dbg')
L=T.L;sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
body=json.loads((R/'build/contra-force-body-pack-v3/packing.json').read_text())['per_pose_source_metadata']
shot=json.loads((R/'build/contra-force-shot-pack-v1/packing.json').read_text())['views']

def init(var=0,prefix=0):
 m=T.make(var,x=120,y=112)
 m[512:768]=[0xad]*256;T.put(m,CurrentOAMOffset=prefix)
 for i in range(12):
  m[T.address(T.B,'CurrentCHRBank')+i]=0x60+i
  m[T.address(T.B,'X5ChrMode')+i]=i
 m[3]=0xa5;m[4]=0x5a
 return m

def relevant(m):return bytes(m.ram[2][i]for i in list(range(0x7f,0x83))+[0x83,0xb1,0xc0]+list(range(0x300,0x500)))

def expect(parts,anchorx,anchory,prefix,p1=False):
 out=[]
 if prefix+4*len(parts)>220:return out,prefix
 for p in parts:
  x=anchorx+p['x']-128;y=anchory+p['y']-128
  if not(0<=x<256 and 0<=y<240):continue
  attr=p['attr'];tile=p.get('target_window6_tile',2*p['local_pair'])
  if p1 and attr&3==3:attr=(attr&252)|1
  out.extend([y,tile,attr,x])
 return out,prefix+len(out)

def verify(m,expected,prefix,end,before):
 actual=bytes(m[512:768])
 assert actual[:prefix]==bytes([0xad])*prefix and actual[prefix:end]==bytes(expected)
 assert actual[end:]==bytes([0xad])*(256-end)
 assert T.get(m,'CurrentOAMOffset')==end and bytes(m[3:5])==bytes([0xa5,0x5a])
 assert relevant(m)==before,('render changed original source actors')

def bodies():
 rows=[]
 for v in body:
  for prefix in[0,204,252]:
   m=init(v['variant'],prefix);m[L['CfState']+0x31a]=v['frame'];m[L['CfState']+0x334]=0
   before=relevant(m);c,info=T.run(m,'CfHostRenderBody');out,end=expect(v['parts'],128,128,prefix)
   verify(m,out,prefix,end,before)
   assert T.get(m,'SmChrBank')==(959+v['local_page'])&255
   assert m[T.address(T.B,'CurrentCHRBank')]==(959+v['local_page'])&255 and m[T.address(T.B,'X5ChrMode')]==0x83
   for i in range(1,12):assert m[T.address(T.B,'CurrentCHRBank')+i]==0x60+i and m[T.address(T.B,'X5ChrMode')+i]==i
   assert c.a==end and c.p&1
   rows.append([v['variant'],v['frame'],prefix,end,info['CPU']])
 # Real signed world/screen page clipping and native vertical-high input.
 v=max(body,key=lambda v:len(v['parts']));edges=[]
 for wx,py,high in[(248,112,1),(249,16,1),(256,0,1),(503,112,1),(511,223,1),(512,239,1),(384,112,0),(384,255,2)]:
  m=init(v['variant']);T.put(m,Player_X_Position=wx&255,Player_PageLoc=wx>>8,ScreenLeft_X_Pos=0,ScreenLeft_PageLoc=1,Player_Y_Position=py,Player_Y_HighPos=high)
  m[L['CfState']+0x31a]=v['frame'];m[L['CfState']+0x334]=0
  before=relevant(m);T.run(m,'CfHostRenderBody');out,end=expect(v['parts'],wx-256+8,(high-1)*256+py+16,0);verify(m,out,0,end,before);edges.append([wx,py,high,end])
 return dict(actual_source_pose_cases=len(rows),all156source_views=True,signed_page_and_vertical_clipping=edges,maximum_original_body_scanline_parts=max(v['target_line_max']for v in body),rows=rows)

def shots():
 rows=[];by={v['frame']:v for v in shot}
 for v in by.values():
  for owner in[0,1]:
   for prefix in[0,204,252]:
    m=init(v['variant'],prefix);slot=10;m[L['CfState']+0x382+slot]=v['source_witness']['kind'];m[L['CfState']+0x31a+slot]=v['frame'];m[L['CfState']+0x334+slot]=28;m[L['CfState']+0x34e+slot]=128;m[L['CfState']+0x368+slot]=128;m[L['CfState']+0x300+slot]=0
    m[L['CfShotPaletteOwned']]=owner;loan=any(p['attr']&3==3 for p in v['target_parts'])
    before=relevant(m);c,info=T.run(m,'CfHostRenderShot',x=slot)
    out,end=([],prefix)if loan and not owner else expect(v['target_parts'],128,128,prefix,p1=True)
    verify(m,out,prefix,end,before)
    assert c.a==end and c.p&1
    if not(loan and not owner):assert m[T.address(T.B,'CurrentCHRBank')+6]==200 and m[T.address(T.B,'X5ChrMode')+6]==0x83
    for i in range(12):
     if i==6 and not(loan and not owner):continue
     assert m[T.address(T.B,'CurrentCHRBank')+i]==0x60+i and m[T.address(T.B,'X5ChrMode')+i]==i
    rows.append([v['frame'],owner,prefix,end,int(loan),info['CPU']])
 return dict(unique_source_frames=len(by),actual_source_record_cases=len(rows),whole_loan_object_rejected_without_fixture_owner=True,source_P3_to_exact_prospective_P1_only=True,world_windows_except6_preserved=True,rows=rows)

def main():
 assert not O.exists();O.mkdir();out=dict(passed=False,native=False,actual_cart_hooks=False,guest_RAM_fixture_preloaded=True,actual_P1_palette_commit=False,checks={})
 try:
  p=P/'build-proof.json';h=json.loads(p.read_text())
  for p,v in h['bindings'].items():assert sha(p)==v,p
  out['checks']['body']=bodies();print('CF156 actual body records PASS',flush=True)
  out['checks']['shots']=shots();print('CF123 actual shot records/whole owner gate PASS',flush=True)
  out['passed']=True
 except Exception as e:out.update(error=repr(e),traceback=traceback.format_exc());raise
 finally:
  files=[Path(__file__),Path(T.__file__),P/'build-proof.json',P/'runtime.dbg',P/'ram1.bin',P/'ram2.bin',P/'ram3.bin',R/'build/contra-force-body-pack-v3/packing.json',R/'build/contra-force-shot-pack-v1/packing.json',T.N,T.N.with_suffix('.dbg')]
  out['bindings']={str(p.resolve()):sha(p)for p in files}
  p=O/'controls.json';p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(path=str(p),sha256=sha(p),passed=out['passed'],error=out.get('error'))),flush=True)

if __name__=='__main__':main()
