"""Actual loader -> owned A2 indexed router -> native/source method CPU proof."""
from pathlib import Path
import copy,hashlib,json,re,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import contra_force_loader_controls_v2 as T
from prepare_ff_current_component_v2 import qualified
P=R/'build/contra-force-loader-cart-v4';K=R/'build/contra-force-a2-router-v1'
O=R/'build/contra-force-a2-router-controls-v2'
T.P=P;T.B=qualified(P/'joint/candidate.nes');T.PAYLOAD=(P/'joint/cf-stream.bin').read_bytes();T.COOKIE=(P/'joint/cf-cookie.bin').read_bytes()
L={n:int(v,16)for v,n in re.findall(r'al ([0-9A-Fa-f]+) \.(\w+)',(K/'runtime.lbl').read_text())}
methods=['CfHostMovement','CfHostUnimplemented','CfHostRenderAll','CfHostUnimplemented','CfHostShots','CfHostInjury','CfHostUnimplemented','CfHostUnimplemented','CfHostUnimplemented','CfHostUnimplemented','CfHostHead','CfHostBody','CfHostAdder','CfHostBoxProfile','CfHostSide','CfHostConstruct','CfHostBox','CfHostUnimplemented','CfHostUnimplemented','CfHostReset','CfHostUnimplemented','CfHostUnimplemented','CfHostUnimplemented','CfHostUnimplemented','CfHostCollect','CfHostFullPower','CfHostUnimplemented','CfHostUnimplemented','CfHostHeadWithin','CfHostUnimplemented','CfHostUnimplemented','CfHostUnimplemented','CfHostUnimplemented','CfHostUnimplemented','CfHostShots','CfHostUnimplemented']
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def clone(m):
 z=T.Bus.__new__(T.Bus);list.__init__(z,list(m))
 for n,v in m.__dict__.items():setattr(z,n,v if n=='bundle'else copy.deepcopy(v))
 z.writes.clear();z.ram_writes.clear();z.ppu_log.clear();z.executed_guest.clear();return z

def start(m,pc,raw,a=0x57,x=2,y=3,p=0x30):
 m[T.address(T.B,'SafecallA_SMC')+1]=a
 m[T.address(T.B,'FarcallJmpTarget_SMC')+1]=pc&255
 m[T.address(T.B,'FarcallJmpTarget_SMC')+2]=pc>>8
 c=T.NesMPU(memory=m,pc=T.address(T.B,'FarCallCommon'));c.a,c.x,c.y,c.p,c.sp=raw,x,y,p,0xe0;c.stPushWord(0x7ffe)
 return c

def ready():
 m=T.Bus();T.put(m,GameEngineSubroutine=8,TimerControl=0,GamePauseStatus=0,MmDeathFlag=0,NumberofLives=2,
  AreaType=1,PlayerStatus=0,PlayerSize=0,Player_X_Position=120,Player_PageLoc=0,Player_Y_Position=176,Player_Y_HighPos=1,
  ScreenLeft_X_Pos=0,ScreenLeft_PageLoc=0,PlayerFacingDir=1,Player_State=0,Player_X_Speed=0,Player_Y_Speed=0,
  InjuryTimer=3,StarInvincibleTimer=0,SavedJoypadBits=0,CurrentOAMOffset=0,ObjectOffset=5,CrouchingFlag=0,SwimmingFlag=0)
 for n in['Enemy_Flag','Enemy_State','Enemy_ID','PowerUpType']:
  for i in range(6):m[T.address(T.B,n)+i]=0
 T.checkpoint(m);c=T.cpu(m,public=True);T.finish(m,c);T.exact(m,0)
 c=start(m,L['CfServiceVeneers']+15*3,2);T.finish(m,c)
 assert m.ram[2][0x2e1]==1
 m.writes.clear();m.ram_writes.clear();m.ppu_log.clear();m.executed_guest.clear()
 return m

def app(m):
 skip=set(range(0x100,0x1e1))|set(range(0x2000,0x5c00))
 # Direct workers require incomingC2; routed calls preserve incomingROMd8.
 # Assert both exact raw/shadow restores separately, not equal shadow bytes.
 skip.add(T.address(T.B,'CurrentBankC'))
 seg=next(s for s in T.B['segs'].values()if s['name']=='"SMCCODE"')
 skip.update(range(int(seg['start'],0),int(seg['start'],0)+int(seg['size'],0)))
 return bytes(m[i]for i in range(0x8000)if i not in skip)

def interfaces():
 base=ready();rows=[];code=[bytes(x)for x in base.ram]
 for service in range(36):
  for p in[v for v in range(256)if v&0x30==0x30]:
   pair=[]
   for routed in[False,True]:
    m=clone(base)
    if not routed:m.raw_page(2,2);T.put(m,CurrentBankC=2)
    incoming=m.rawtags[:]
    pc=L['CfServiceVeneers']+service*3 if routed else L[methods[service]]
    c=start(m,pc,2 if routed else 3,p=p);z=T.finish(m,c)
    assert m.rawtags==incoming and T.get(m,'CurrentBank')==incoming[1]and T.get(m,'CurrentBankC')==incoming[2]
    assert bytes(m.ram[1])==code[1]and bytes(m.ram[3])==code[3]and bytes(m.ram[2][0x500:])==code[2][0x500:],('source code/data write',service)
    # Five declared transport bytes intentionally carry the selected method;
    # every original source field and all other owned adapter state agree.
    source=bytes(v for i,v in enumerate(m.ram[2][:0x500])if not 0x2ec<=i<0x2f1)
    pair.append((z['AXYP'],app(m),source,bytes(m[0x1e1:0x200]),z['CPU']))
   assert pair[0][:4]==pair[1][:4],('actual indexed callback difference',service,p,pair[0][0],pair[1][0])
   rows.append([service,p,pair[0][4],pair[1][4],pair[1][4]-pair[0][4]])
 return dict(actual36_by64_direct_worker_pairs=len(rows),all_original_source_fields_and_owned_adapter_state_exact=True,AXYP_SP_live_upper_page1_application_and_rawmaps_exact=True,declared_transport_bytes_only=[0x2ec,0x2f1],rows=rows)

def stale():
 base=ready();rows=[]
 for i in range(16):
  m=clone(base);m.ram[2][0x1fe0+i]^=1;before=[bytes(x)for x in m.ram]
  c=start(m,L['CfServiceVeneers'],2,p=0x79);z=T.finish(m,c)
  assert z['AXYP']==[0x57,2,3,0x78]and [bytes(x)for x in m.ram]==before and not m.ram_writes,(i,z['AXYP'])
  assert m.rawtags==base.rawtags and T.get(m,'CurrentBankC')==base.rawtags[2]
  rows.append([i,z['CPU']])
 for var in[1,2,3]:
  m=clone(base);T.put(m,FmGroups=var<<3);before=[bytes(x)for x in m.ram]
  c=start(m,L['CfServiceVeneers'],2);z=T.finish(m,c)
  assert not c.p&1 and [bytes(x)for x in m.ram]==before and not m.ram_writes;rows.append(['class',var,z['CPU']])
 m=clone(base);before=[bytes(x)for x in m.ram];c=start(m,L['CfServiceUnavailable'],2);z=T.finish(m,c)
 assert not c.p&1 and [bytes(x)for x in m.ram]==before
 return dict(full16_cookie_and_class_rejections=rows,service36_reject=True,scope='Payload code is deliberately still the verified CF image in these stale-cookie tests. An arbitrary foreign C2 image is NOT safe to enter; root-owned external ROM guard is mandatory before any A2 opcode.')

def main():
 assert not O.exists();O.mkdir();d=dict(passed=False,native=False,guest_RAM_preloaded=False,actual_shared_ingress=False,ready=False,checks={})
 try:
  for root in[P/'source-stage.json',K/'build-proof.json']:
   for p,h in json.loads(root.read_text())['bindings'].items():assert sha(p)==h,p
  for n,f in[('interfaces',interfaces),('stale',stale)]:d['checks'][n]=f();print('CF A2 router',n,'PASS',flush=True)
  d['passed']=True
 except Exception as e:d.update(failure=repr(e),traceback=traceback.format_exc());raise
 finally:
  paths=[Path(__file__),Path(T.__file__),P/'source-stage.json',P/'joint/candidate.nes',P/'joint/candidate.dbg',P/'joint/cf-stream.bin',P/'joint/cf-cookie.bin',K/'build-proof.json',K/'runtime.dbg',K/'runtime.lbl']
  d['bindings']={str(p.resolve()):sha(p)for p in paths};path=O/'controls.json';path.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(path=str(path),sha256=sha(path),passed=d['passed'],failure=d.get('failure'))),flush=True)

if __name__=='__main__':main()

