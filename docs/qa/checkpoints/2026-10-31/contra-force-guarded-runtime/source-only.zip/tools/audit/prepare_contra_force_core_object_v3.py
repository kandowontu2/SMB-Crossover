"""Add genuine source allocator/math/animation/body-decoder/data to abstract object."""
from pathlib import Path
P=Path(__file__).with_name('prepare_contra_force_core_object_v1.py')
s=P.read_text(encoding='utf-8').replace("O=R/'build/contra-force-core-object-v1'", "O=R/'build/contra-force-core-object-v3'")
s=s.replace('.read_text()', ".read_text(encoding='utf-8')")
old=" assert body.rstrip().endswith('RTS')"
add=''' assert body.rstrip().endswith('RTS')
 core_body=body
 def piece(bank,start,end):
  text=(P/f'copy_bank_{bank}.asm').read_text(encoding='utf-8')
  return start+':'+text.split(start+':',1)[1].split(end+':',1)[0]
 chunks=[
  ('04','sub_0x00846C','ofs_017_853C_05'),
  ('04','sub_90D6_0600x_AND_F0','sub_90DC'),
  ('04','sub_9147_copy_speed','sub_9183_0782x_AND_7F'),
  ('04','sub_9372','sub_93BA'),
  ('04','sub_9762','tbl_987A'),
  ('04','sub_9A4C_clear_animation','bra_9A52'),
  ('FF','sub_0x01F348_convert_dpad_buttons','sub_F34C_prg_bankswitch'),
  ('FF','sub_0x01F650','sub_0x01F66E'),
  ('FF','tbl_0x01F679','sub_0x01F69F_get_stage_view_type'),
  ('FF','sub_0x01F6E1','loc_0x01F712'),
  ('FF','sub_D35B','tbl_D55B'),
 ]
 body+='\nCfCoreEnd:\n.segment "CF_HELPERS"\n'
 for bank,start,end in chunks:body+=piece(bank,start,end)+'\n'
 body+='\ntbl_987A: .word _off019_0x00D2AB_00\n'
 body+='\n.segment "CF_ANIMATION"\n'+piece('06','_off019_0x00D2AB_00','_off019_0x00D4E1_01')
 body+='\n.segment "CF_METASPRITES"\n'+piece('00','_off032_9A70_00','_off032_A2C0_04')
'''
s=s.replace(old,add)
s=s.replace("body,'CfCoreEnd:']", "body,'CfObjectEnd:']")
s=s.replace("original_source_range=dict(bank=5,start=0xa030,end=0xae7b,bytes=0xe4b)", "original_core_range=dict(bank=5,start=0xa030,end=0xae7b,bytes=0xe4b),genuine_added_chunks=chunks,animation_table_scope='Only genuine group0 pointer and original group0 sequences, all4 side-view player classes. Other animation groups remain unimplemented/rejected host work.'")
exec(compile(s,str(P),'exec'),{'__name__':'__main__','__file__':str(Path(__file__).resolve())})
