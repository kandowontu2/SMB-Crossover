"""Measure declared SMB traversal adjustment, preserving native fall terminal.

Only the two upward-phase table reads use base velocity+$80. The original
ACCE table and negative-age falling/release paths remain source-exact.
"""
from pathlib import Path
import hashlib,json,re,subprocess,sys
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit')]
from private_build_outputs_v1 import validate
P=R/'build/contra-force-compact-arena-v2';O=R/'build/contra-force-jump-adaptation-v1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert not O.exists();O.mkdir()
d=json.loads((P/'build-proof.json').read_text())
for p,h in d['bindings'].items():assert sha(p)==h,p
s=(P/'component.s').read_text(encoding='utf-8');a=s.index('bra_ABB8:');b=s.index('bra_ABD4:',a)
up=s[a:b];assert len(re.findall(r'\bLDA tbl_ACCE(?: \+ \$01)?,Y',up))==2
up=up.replace('LDA tbl_ACCE','LDA CfHostJumpUpLimit')
s=s[:a]+up+s[b:]
s+='\n.segment "CF_CORE"\n.export CfHostJumpUpLimit\nCfHostJumpUpLimit:\n .word $0440,$0400,$03c0,$0420,$0200\n'
(O/'component.s').write_text(s,encoding='utf-8')
for name in['state.inc','oracle-gates.s','arena.cfg']:(O/name).write_bytes((P/name).read_bytes())
ca=R/'tools/Windows/cc65/bin/ca65.exe';ld=ca.with_name('ld65.exe');logs=[]
cmds=[]
for name in['component','oracle-gates']:cmds.append([str(ca),'--cpu','6502x','-g','-I',str(R/'build/contra-force-reproduction-v2'),'--create-full-dep',str(O/(name+'.dep')),'-o',str(O/(name+'.o')),str(O/(name+'.s'))])
cmds.append([str(ld),'-C',str(O/'arena.cfg'),'-o',str(O/'arena.bin'),'--dbgfile',str(O/'arena.dbg'),'-Ln',str(O/'arena.lbl'),'-m',str(O/'arena.map'),str(O/'component.o'),str(O/'oracle-gates.o')])
for cmd in cmds:
 guard=validate(cmd,O,cwd=O);r=subprocess.run(cmd,cwd=O,capture_output=True,text=True);log=dict(command=cmd,output_guard=guard,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr);logs.append(log)
 (O/'build-log.json').write_text(json.dumps(logs,indent=2)+'\n',encoding='utf-8');assert r.returncode==0,log
out=dict(passed=True,status='DECLARED_UPWARD_VELOCITY_ADAPTATION_CPU_ARENA_NO_HOST_OR_LEASE',
 source_change='Only positive-age jump LDA2 table operands use original per-class magnitude+$0080. Native negative-age terminal/release table untouched.',
 original_upward_magnitudes=[960,896,832,928],adapted_upward_magnitudes=[1088,1024,960,1056],
 projected_state_bytes=1280,pointer_bytes=2,source_code_and_data_bytes=len((O/'arena.bin').read_bytes()),original_services_executed_by_fixture_only=d['original_services_executed_by_fixture_only'],
 bindings={str(p.resolve()):sha(p)for p in[Path(__file__),R/'tools/audit/private_build_outputs_v1.py',P/'build-proof.json',P/'component.s',P/'state.inc',ca,ld,*[p for p in O.iterdir()if p.is_file()]]})
p=O/'build-proof.json';p.write_text(json.dumps(out,indent=2)+'\n',encoding='utf-8');print(json.dumps(dict(path=str(p),sha256=sha(p),bytes=out['source_code_and_data_bytes'])),flush=True)
