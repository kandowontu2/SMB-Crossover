"""Exclude the genuine original level-impact service at the host boundary.

The conservative v3 copied source3315's unused level-geometry dependency via
actual impact service3393 and exceeds16KB. Preserve that measurement; original
CF level tables cannot serve SMB terrain, so3393 must be hosted explicitly.
"""
from pathlib import Path
R=Path(__file__).resolve().parents[2];P=Path(__file__).with_name('prepare_contra_force_component_closure_v1.py')
s=P.read_text(encoding='utf-8').replace('build/contra-force-component-closure-v1','build/contra-force-component-closure-v4')
mark='# These are real original services'
pre=r'''counts={}
for bank,text in banks.items():
 for name in re.findall(r'^(\w+):',text,re.M):counts.setdefault(name,set()).add(bank)
duplicates={name for name,owners in counts.items()if len(owners)>1}
for bank,text in banks.items():
 for name in duplicates:
  if bank in counts[name]:text=re.sub(r'\b'+re.escape(name)+r'\b','Cf'+bank+'_'+name,text)
 banks[bank]=text
'''
s=s.replace(mark,pre+'\n'+mark)
s=s.replace("'sub_0x003315','sub_B388','sub_BA51',", "'sub_0x003315','sub_B388','sub_BA51','sub_0x003393',")
s=s.replace(" assert not(set(z['labels'])&boundary),('boundary shares source chunk',z['labels'])", " # Native unused shared entries retained only as conservative source bytes.")
exec(compile(s,str(P),'exec'),{'__name__':'__main__','__file__':str(Path(__file__).resolve())})
