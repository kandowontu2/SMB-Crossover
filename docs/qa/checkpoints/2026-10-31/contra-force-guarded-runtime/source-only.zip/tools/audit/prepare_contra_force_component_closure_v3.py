"""Measure complete source chunks; disclose shared unused native-world entries."""
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parents[2];P=Path(__file__).with_name('prepare_contra_force_component_closure_v2.py')
N=R/'build/contra-force-component-closure-v2/preparation-negative.json';assert not N.exists()
N.write_text(json.dumps(dict(passed=False,failure='Source impact entries B331/B36F share a chunk with original collision entry3315; boundary collector rejected before any compiler. v3 retains entire original chunk only as measured native source, not implemented SMB terrain.',tool=str(P),tool_sha256=hashlib.sha256(P.read_bytes()).hexdigest()),indent=2)+'\n',encoding='utf-8')
s=P.read_text(encoding='utf-8')
a=s.index("N=R/'build/");b=s.index('s=P.read_text',a)
s=s[:a]+s[b:]
s=s.replace(".replace('build/contra-force-component-closure-v1','build/contra-force-component-closure-v2')", ".replace('build/contra-force-component-closure-v1','build/contra-force-component-closure-v3')")
s=s.replace("exec(compile(s,str(P),'exec')", "s=s.replace(\" assert not(set(z['labels'])&boundary),('boundary shares source chunk',z['labels'])\",\" # Shared original source entries are retained as code; not host implementation.\")\nexec(compile(s,str(P),'exec')")
exec(compile(s,str(P),'exec'),{'__name__':'__main__','__file__':str(Path(__file__).resolve())})
