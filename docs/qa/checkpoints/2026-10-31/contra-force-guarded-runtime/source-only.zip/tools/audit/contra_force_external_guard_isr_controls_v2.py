"""Real vectors at external ROM-auth bytes/maps/stack and foreign BT tail."""
from pathlib import Path
import hashlib,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import contra_force_external_guard_controls_v1 as D
import contra_force_loader_isr_controls_v2 as U
C,T=D.C,D.T;U.B=T.B
O=R/'build/contra-force-external-guard-isr-controls-v2'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def cpuclone(m,c):
 z=C.clone(m);d=T.NesMPU(memory=z,pc=c.pc)
 d.a,d.x,d.y,d.p,d.sp,d.processorCycles=c.a,c.x,c.y,c.p,c.sp,c.processorCycles
 return z,d

def main():
 assert not O.exists();O.mkdir();out=dict(passed=False,native=False,actual_shared_hook=False,checks={})
 try:
  rows=[]
  for owner in[31,33]:
   base=D.loaded();T.put(base,SelectedCharacter=owner,VRAM_Buffer_AddrCtrl=0,VRAM_Buffer1_Offset=0,Sprite0HitDetectFlag=0,ReloadCHRBank=0)
   base[T.address(T.B,'VRAM_Buffer1')]=0
   if owner==33:base.ram[3][0x1fe0:0x1ff0]=bytes(16) # rejected foreign BT cookie; no BT-code preload
   for lag in[0,255]:
    m=C.clone(base);T.put(m,NmiDisable=lag);c=D.public(m,a=105,p=0x30);seen=set();count=0
    while c.pc!=0x7fff:
     assert count<100000
     pc=c.pc;raw=m.rawtags[(pc-0x8000)//8192]if pc>=0x8000 else-1
     tag=(raw&127)if raw>=128 else(-2-raw if raw>=0 else-1)
     # Every CF69 instruction/16cookie index, every true SFC instruction and
     # genuine foreign BtCheck93 endpoint instruction, including pending
     # hardware-map stores whose software shadow has already changed.
     if tag in[69,93]or pc<0x8000:
      key=(tag,pc,c.x)
      if key not in seen:
       seen.add(key)
       for kind in['NMI','IRQ']:
        z,d=cpuclone(m,c);z[0x5204]=0x80
        if kind=='IRQ'and d.p&4:continue
        proof=U.interrupt(z,d,kind,keep_ppu=False)
        T.finish(z,d)
        assert bool(d.p&1)==(owner==31)and z.rawtags==base.rawtags
        assert not z.executed_guest and not z.ram_writes
        rows.append(dict(owner=owner,lag=lag,PC=pc,physical=tag,source_X=c.x,**proof))
     c.step();count+=1
    assert bool(c.p&1)==(owner==31)
  assert any(r['physical']==69 for r in rows)and any(r['physical']==93 for r in rows)
  assert sum(r['physical']==69 for r in rows)>100
  out['checks']['actual_vectors']=dict(cases=len(rows),normal_and_lag_NMI_and_real_unmasked_IRQ=True,all33SMC_AXIYP_SP_live_page1_and_raw_C_A_restored=True,no_guest_opcode_or_write_before_external_auth=True,rows=rows)
  out['retained_v1_coverage_correction']='V1 rawROMtag197/221 was compared with physical69/93, so only112 resident SFC cuts ran. Those remain valid; broad worker-coverage claim is withdrawn in this successor.'
  out['passed']=True
 except Exception as e:out.update(failure=repr(e),traceback=traceback.format_exc());raise
 finally:
  paths=[Path(__file__),Path(D.__file__),Path(C.__file__),Path(T.__file__),Path(U.__file__),D.P/'source-stage.json',D.P/'joint/candidate.nes',D.P/'joint/candidate.dbg',D.P/'joint/cf-cookie.bin',R/'tools/audit/contra_force_loader_isr_controls_v1.py']
  out['bindings']={str(p.resolve()):sha(p)for p in paths};p=O/'controls.json';p.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(path=str(p),sha256=sha(p),passed=out['passed'],failure=out.get('failure'),cases=out['checks'].get('actual_vectors',{}).get('cases'))),flush=True)

if __name__=='__main__':main()

