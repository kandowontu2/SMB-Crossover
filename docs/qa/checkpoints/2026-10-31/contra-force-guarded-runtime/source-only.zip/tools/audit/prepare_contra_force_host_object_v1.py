"""Compile unresolved actual-native CF movement/terrain/lifecycle worker.

No import fixture aliases, current cart edits, physical lease or readiness.
"""
from pathlib import Path
import hashlib,json,re,subprocess,sys
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit')]
from private_build_outputs_v1 import validate
P=R/'tools/reference/contra_force_host_runtime_v1.s';O=R/'build/contra-force-host-object-v1'
assert not O.exists();O.mkdir()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
native=R/'build/benj-menu-unlocked-1030-v3/joint/candidate.dbg'
defs={}
for line in native.read_text(encoding='utf-8').splitlines():
 n=re.search(r'name="([^"]+)"',line);v=re.search(r'\bval=0x([0-9a-fA-F]+)',line)
 if n and v:defs[n[1]]=int(v[1],16)
source=P.read_text(encoding='utf-8');imports=[]
for values in re.findall(r'^\.import(?:zp)? (.*)',source,re.M):imports.extend(values.split(','))
own={n for n in imports if n.startswith('Cf')};foreign=set(imports)-own
assert not(foreign-defs.keys()),sorted(foreign-defs.keys())
(O/'host-runtime.s').write_text(source,encoding='utf-8')
ca=R/'tools/Windows/cc65/bin/ca65.exe';od=ca.with_name('od65.exe')
cmd=[str(ca),'--cpu','6502x','-g','--create-full-dep',str(O/'host-runtime.dep'),'-o',str(O/'host-runtime.o'),str(O/'host-runtime.s')]
guard=validate(cmd,O,cwd=O);r=subprocess.run(cmd,cwd=O,capture_output=True,text=True)
log=dict(command=cmd,output_guard=guard,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr)
(O/'compile.json').write_text(json.dumps(log,indent=2)+'\n',encoding='utf-8');assert r.returncode==0,log
q=subprocess.run([str(od),'--dump-segments',str(O/'host-runtime.o')],cwd=O,capture_output=True,text=True);assert q.returncode==0
(O/'segments.txt').write_text(q.stdout,encoding='utf-8')
z=q.stdout.split('"CF_HOST_RUNTIME"',1)[1];size=int(re.search(r'Size:\s*(\d+)',z)[1])
d=dict(passed=True,status='COMPILED_UNLINKED_HOST_MOVEMENT_TERRAIN_LIFECYCLE_NO_GRANT',actual_worker_bytes=size,
 actual_current64_native_imports={n:defs[n]for n in sorted(foreign)},source_kernel_imports=sorted(own),
 alias_scope='12 bytes in unused original source03E0..<03EC within abstract whole-page privateCfState; not sharedRAM or granted host addresses.',
 precondition='Selectedraw31 and full CF cookie verified, source C2 mapped before any worker entry; future native importer must enforce. No such importer is installed.',
 implemented_source_only=['source-input edges; genuine playercore entry; conservative8.8 host-position integration; standing/prone1-or17top32foot and14pxwidth; actual native typed query tuple; native clamp/bonk resync; nativePlayerStatus-backed tier preserves native alternating-player gear; native no-stomp/contact injury policy'],
 not_yet_proven=['actual cold lifecycle/cookie/native Main ingress','query tuple full native caller vectors','native maturepickup collection/score writer','source-shot/native actor and world impacts','full source render/OAM/palette ownership','native auto4/5 fallback and flags','64px pipe route'],
 bindings={str(p.resolve()):sha(p)for p in[Path(__file__),R/'tools/audit/private_build_outputs_v1.py',P,native,R/'build/benj-menu-unlocked-1030-v3/handoff.json',ca,od,*[p for p in O.iterdir()if p.is_file()]]})
p=O/'build-proof.json';p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8');print(json.dumps(dict(path=str(p),sha256=sha(p),actual_worker_bytes=size)),flush=True)
