"""Link actual CF host worker and phase engine against true current imports.

This produces explicitly preloadable RAM images, not an installed cartridge.
The source world/audio/script oracles remain declared unimplemented callbacks.
"""
from pathlib import Path
import hashlib,json,re,subprocess,sys
R=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(R/'tools/audit')]
from private_build_outputs_v1 import validate
P=R/'build/contra-force-runtime-split-v1'
O=R/'build/contra-force-host-arena-v3'
N=R/'build/peach-palette-fix-1030-v1/joint/candidate.dbg'
H=R/'tools/reference/contra_force_host_runtime_v3.s'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
 assert not O.exists();O.mkdir()
 proof=json.loads((P/'build-proof.json').read_text())
 for p,h in proof['bindings'].items():assert sha(p)==h,p
 for name in['component.s','state.inc','phase-bridge.s']:(O/name).write_bytes((P/name).read_bytes())
 host=H.read_text()
 for old,new in[('CfNativeInput','CfHostCallInput'),('CfNativeBody','CfHostCallBody')]:host=re.sub(r'\b'+old+r'\b',new,host)
 gates=['.import CfNativeInput,CfNativeBody,CfCallA,CfTarget,CfTargetBank',
        '.export CfHostCallInput,CfHostCallBody','.segment "CF_HOST_RUNTIME"']
 for name,target in[('CfHostCallInput','CfNativeInput'),('CfHostCallBody','CfNativeBody')]:
  gates+=[name+':',' php',' pha',' lda #<'+target,' sta CfTarget',' lda #>'+target,' sta CfTarget+1',' lda #1',' sta CfTargetBank',' pla',' plp',' jmp CfCallA']
 (O/'host-runtime.s').write_text(host)
 (O/'host-gates.s').write_text('\n'.join(gates)+'\n')
 defs={}
 for line in N.read_text().splitlines():
  name=re.search(r'name="([^"]+)"',line);value=re.search(r'\bval=0x([0-9a-fA-F]+)',line)
  if name and value:defs[name[1]]=int(value[1],16)
 imports=[]
 for row in re.findall(r'^\.import(?:zp)? (.*)',H.read_text(),re.M):imports.extend(row.split(','))
 names=sorted({n for n in imports if not n.startswith('Cf')})
 assert not(set(names)-defs.keys()),set(names)-defs.keys()
 (O/'native-imports.s').write_text('\n'.join('.export '+name+'\n'+name+'=$%04x'%defs[name]for name in names)+'\n')
 cfg=(P/'runtime.cfg').read_text().replace('ORACLE:start=$f000','ORACLE:start=$5b00')
 cfg=cfg.replace(' CF_GATES_1:', ' CF_HOST_RUNTIME:load=A3,type=ro;\n CF_GATES_1:')
 (O/'runtime.cfg').write_text(cfg)
 (O/'oracle-gates.s').write_bytes((P/'oracle-gates.s').read_bytes())
 ca=R/'tools/Windows/cc65/bin/ca65.exe';ld=ca.with_name('ld65.exe');logs=[]
 commands=[];objects=['component','phase-bridge','oracle-gates','native-imports','host-runtime','host-gates']
 for name in objects:
  commands.append([str(ca),'--cpu','6502x','-g','-I',str(R/'build/contra-force-reproduction-v2'),
                   '--create-full-dep',str(O/(name+'.dep')),'-o',str(O/(name+'.o')),str(O/(name+'.s'))])
 commands.append([str(ld),'-C',str(O/'runtime.cfg'),'-o',str(O/'unused.bin'),'--dbgfile',str(O/'runtime.dbg'),'-Ln',str(O/'runtime.lbl'),'-m',str(O/'runtime.map'),*[str(O/(n+'.o'))for n in objects]])
 for cmd in commands:
  guard=validate(cmd,O,cwd=O);p=subprocess.run(cmd,cwd=O,capture_output=True,text=True)
  logs.append(dict(command=cmd,cwd=str(O),output_guard=guard,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr))
  (O/'build-log.json').write_text(json.dumps(logs,indent=2)+'\n');assert p.returncode==0,logs[-1]
 out=dict(passed=True,status='PRELOADABLE_SPLIT_ENGINE_AND_REAL_NATIVE_HOST_IMPORTS_NOT_CARTRIDGE',native=False,actual_cart_hooks=False,
          current_parent=str(N.with_suffix('.nes')),current_parent_sha256=sha(N.with_suffix('.nes')),
          actual_native_imports={n:defs[n]for n in names},host_worker_source=str(H),state_preloaded=True,
          unresolved_original_oracles=proof['original_services_executed_by_fixture_only'],
          missing=['ROMloader and fullcookie importer','actual shared selected31typedroutes','SMB projectile/worldhits/audio bridge','authentic gameplay OAM/palette publication','cold lifecycle and native qualification'],
          bindings={str(p.resolve()):sha(p)for p in[Path(__file__),P/'build-proof.json',H,N,N.with_suffix('.nes'),ca,ld,R/'tools/audit/private_build_outputs_v1.py',*[p for p in O.iterdir()if p.is_file()]]})
 path=O/'build-proof.json';path.write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(path=str(path),sha256=sha(path))),flush=True)

if __name__=='__main__':main()
