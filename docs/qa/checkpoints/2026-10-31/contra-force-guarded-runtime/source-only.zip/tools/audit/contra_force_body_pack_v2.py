"""Same genuine156 views/pixels; fixed source-anchor grid improves exact reuse."""
from pathlib import Path
P=Path(__file__).with_name('contra_force_body_pack_v1.py')
s=P.read_text(encoding='utf-8').replace("build/contra-force-body-pack-v1'", "build/contra-force-body-pack-v2'")
s=s.replace('loX=min(x for x,y in pix);hiX=max(x for x,y in pix);loY=min(y for x,y in pix);hiY=max(y for x,y in pix);out=[]', 'loX=((min(x for x,y in pix)-116)//8)*8+116;hiX=max(x for x,y in pix);loY=((min(y for x,y in pix)-113)//16)*16+113;hiY=max(y for x,y in pix);out=[]')
s=s.replace("[Path(__file__),Path(T.__file__)", "[P,Path(__file__),Path(T.__file__)")
# P in executed source names the original-ROM reproduction directory; bind the
# tool by its explicit own name, never by an inherited generic variable.
s=s.replace("[P,Path(__file__),Path(T.__file__)", "[Path(__file__).with_name('contra_force_body_pack_v1.py'),Path(__file__),Path(T.__file__)")
exec(compile(s,str(P),'exec'),{'__name__':'__main__','__file__':str(Path(__file__).resolve())})
