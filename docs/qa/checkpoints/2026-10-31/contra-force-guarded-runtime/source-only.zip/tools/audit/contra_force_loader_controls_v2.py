"""Execute the source-linked CF bootstrap and real buffered PPUDATA/readback.

No guest RAM is preloaded. The frontend remains pending and no native game
hook is installed. This qualifies only the declared forced-blank loader API.
"""
from pathlib import Path
import argparse,hashlib,itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
from prepare_ff_current_component_v2 import qualified
from check_tmnt_render_oa import address,location
from verify_native_relocation import NesMPU
from arthur_cache_host_controls_v1 import OverlayMemory
P=R/'build/contra-force-loader-cart-v3'
O=R/'build/contra-force-loader-controls-v2'
B=qualified(P/'joint/candidate.nes')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
PAYLOAD=(P/'joint/cf-stream.bin').read_bytes()
COOKIE=(P/'joint/cf-cookie.bin').read_bytes()

def get(m,n,i=0):return m[address(B,n)+i]
def put(m,**values):
 for n,v in values.items():m[address(B,n)]=v
def smc(m):
 s=next(s for s in B['segs'].values()if s['name']=='"SMCCODE"')
 at,count=int(s['start'],0),int(s['size'],0)
 assert count==33
 return bytes(m[at:at+count])

class Bus(OverlayMemory):
 def __init__(self):
  self.ppu_mask=0;self.scroll=[0,0];self.protection_writes=[]
  self.readback_fault=None;self.status_reads=0;self.executed_guest=[]
  super().__init__(B)
  for bank in range(4):self.ram[bank][:]=bytes((bank*17+i*31+0x5d)&255 for i in range(8192))
  # Four independent native WRAM banks; RAM0 remains the native 6000 window.
  for a in range(0x6000,0x8000):list.__setitem__(self,a,(a*13+7)&255)
  # No source/header initialization is inferred: these are explicit API
  # preconditions, matching the already-writable native mapper state.
  self.protection=[2,1]
  put(self,SelectedCharacter=31,FmGroups=0,FamilyMainCommit=1,OperMode=1,
      Mirror_PPUMASK=0,Mirror_PPUCTRL=0xa4,NmiDisable=255,DisableScreenFlag=1,
      HorizontalScroll=73,VerticalScroll=32,ReloadCHRBank=1,
      X5WideChrActive=1,SsChrActive=0,InvHudActive=0)
  for i in range(12):
   self[address(B,'CurrentCHRBank')+i]=70+i
   self[address(B,'X5ChrMode')+i]=0x80|(i%4)
  self.ppuctrl=get(self,'Mirror_PPUCTRL');self.ppu_mask=0
  # Deliberately preserve nonzero borrowed registers and every live upper
  # page1 byte. Native mapper shadows are seeded AFTER this poison.
  for i in range(256):self[i]=(i*19+71)&255
  for i in range(0x100,0x200):self[i]=(i*7+93)&255
  # Restore genuine executable SMC after poisoning application page1. V1's
  # fixture overwrote this code before its first SFC; retain that negative.
  segment=next(s for s in B['segs'].values()if s['name']=='"SMCCODE"')
  at,count,offset=(int(segment[k],0)for k in['start','size','ooffs'])
  self[at:at+count]=B['raw'][offset:offset+count]
  self.raw_page(1,0xd7);self.raw_page(2,0xd8)
  put(self,CurrentBank=0xd7,CurrentBankC=0xd8,NmiDisable=255)
  self.ppu_addr=0x2c31;self.toggle=1;self.buffer=0x69
  self.writes.clear();self.ram_writes.clear();self.ppu_log.clear()
 def __getitem__(self,i):
  if isinstance(i,int)and i==0x2002:self.status_reads+=1
  if isinstance(i,int)and i>=0x8000:
   raw=self.rawtags[(i-0x8000)//8192]
   if not raw&128 and self.readback_fault==(raw&3,i&8191):return self.ram[raw&3][i&8191]^1
  return super().__getitem__(i)
 def __setitem__(self,i,v):
  if isinstance(i,int):
   if i in[0x5102,0x5103,0x5113]:self.protection_writes.append((i,v))
   if i==0x2001:self.ppu_mask=v
   if i==0x2005:self.scroll[self.toggle]=v
  super().__setitem__(i,v)

def cpu(m,target='CfLoaderProposal',a=0x57,x=0xa9,y=0x63,p=0x30,public=False):
 at=address(B,target);bank=(location(B,target)-16)//8192
 if public:
  put(m,**{'SafecallA_SMC':get(m,'SafecallA_SMC')})
  m[address(B,'SafecallA_SMC')+1]=a
  m[address(B,'FarcallJmpTarget_SMC')+1]=at&255
  m[address(B,'FarcallJmpTarget_SMC')+2]=at>>8
  at=address(B,'FarCallCommon');incoming=bank|128
 else:
  win=(at-0x8000)//8192;m.raw_page(win,bank|128)
  put(m,**{('CurrentBank'if win==1 else'CurrentBankC'):bank|128})
  incoming=a
 c=NesMPU(memory=m,pc=at);c.a,c.x,c.y,c.p,c.sp=incoming,x,y,p,0xe0
 c.stPushWord(0x7ffe)
 return c

def finish(m,c,hook=None,maxsteps=600000):
 low=c.sp;steps=0
 while c.pc!=0x7fff:
  assert steps<maxsteps,('actual loader bound',hex(c.pc),m.rawtags)
  if hook:hook(c,steps)
  low=min(low,c.sp)
  if c.pc>=0x8000 and not m.rawtags[(c.pc-0x8000)//8192]&128:m.executed_guest.append((c.pc,m.rawtags[:]))
  assert m[c.pc]!=0,('actual cartridge BRK',hex(c.pc),m.rawtags)
  c.step();steps+=1
 assert c.sp==0xe0,('actual stack leak',c.sp)
 return dict(CPU=c.processorCycles,steps=steps,minimum_SP=low,AXYP=[c.a,c.x,c.y,c.p])

def checkpoint(m):
 """Use the actual native software-to-hardware publisher, not guessed latches."""
 c=cpu(m,'X5PublishChr',public=True);finish(m,c)
 assert m.upper==0
 m.writes.clear();m.ram_writes.clear();m.ppu_log.clear();m.ppu_reads=0

def exact(m,var):
 for bank in[1,2,3]:
  wanted=bytearray(PAYLOAD[(bank-1)*8192:bank*8192])
  if bank==2:
   wanted[0x1fe0:0x1ff0]=COOKIE;wanted[0x1fe2]=var
  assert bytes(m.ram[bank])==wanted,('actual full8KB copy mismatch',bank,[(i,a,b)for i,(a,b)in enumerate(zip(m.ram[bank],wanted))if a!=b][:4])
 assert m.ram_writes[:2]==[(2,0x1fe0,0),(3,0x1fe0,0)],('both previous owners invalid before copy',m.ram_writes[:3])
 assert m.ram_writes[-1]==(2,0x1fe0,0xa7),('validity must publish LAST',m.ram_writes[-3:])
 assert not m.executed_guest and not m.protection_writes
 assert m.ppu_reads==24*1025*2

def transfers():
 rows=[]
 cases=[(0,0,0xa0,0),(0,0x83,0x84,1),(1,0x80,0xa4,0),(1,0x83,0x84,1)]
 for var,(wide,mode,ctrl,reload)in itertools.product(range(4),cases):
  m=Bus();put(m,FmGroups=var<<3,X5WideChrActive=wide,Mirror_PPUCTRL=ctrl,ReloadCHRBank=reload)
  m.ppuctrl=ctrl;m[address(B,'X5ChrMode')+11]=mode
  checkpoint(m);before=dict(chr=m.chr_latches[:],RAM0=bytes(m[0x6000:0x8000]),protect=m.protection[:],raw=m.rawtags[:],scratch=bytes(m[3:11]),stack=bytes(m[0x1e1:0x200]))
  c=cpu(m,public=True);z=finish(m,c);assert c.p&1
  exact(m,var)
  assert(m.rawtags,m.chr_latches,m.upper,m.ppuctrl,m.toggle,m.scroll)==(before['raw'],before['chr'],0,ctrl,0,[73,32])
  assert bytes(m[3:11])==before['scratch']and m.protection==before['protect']and bytes(m[0x6000:0x8000])==before['RAM0']and bytes(m[0x1e1:0x200])==before['stack']
  assert get(m,'ReloadCHRBank')==reload and(get(m,'CurrentBank'),get(m,'CurrentBankC'))==tuple(m.rawtags[1:3])
  rows.append(dict(variant=var,wide=wide,last_mode=mode,control=ctrl,reload=reload,PPUDATA_reads=m.ppu_reads,**z))
 return dict(cases=len(rows),actual_buffered_copy_and_verify_24576_bytes=True,complete_code_and_data_and_both_cookies=True,original_all12_CHR_publication_restored=True,no_guest_execution_or_global_RAM_writes=True,rows=rows)

def flags_and_rejections():
 rows=[]
 # Rejected branches exercise all64 architectural flag inputs without a
 # costly irrelevant full24KB copy. Accepted legal allflag inputs follow.
 guards=[dict(SelectedCharacter=0),dict(FamilyMainCommit=0),dict(OperMode=0),dict(Mirror_PPUMASK=24),dict(DisableScreenFlag=0),dict(NmiDisable=0)]
 for p in[v for v in range(256)if v&0x30==0x30]:
  for values in guards:
   m=Bus();put(m,**values);c=cpu(m,p=p);before=(smc(m),m.rawtags[:],bytes(m[3:11]),bytes(m[0x1e1:0x200]),[bytes(x)for x in m.ram]);z=finish(m,c)
   assert[c.a,c.x,c.y,c.p]==[0x57,0xa9,0x63,p&254],('actual rejected fullAXYP',p,values,z['AXYP'])
   assert(smc(m),m.rawtags,bytes(m[3:11]),bytes(m[0x1e1:0x200]),[bytes(x)for x in m.ram])==before
   assert not m.ram_writes and not m.ppu_reads and not m.protection_writes
   rows.append([p,values,z['CPU']])
 accepted=[]
 for p in[0x30,0x31,0x38,0x3d,0x70,0x79,0xb0,0xf9]:
  m=Bus();checkpoint(m);c=cpu(m,p=p);before=(smc(m),m.rawtags[:],bytes(m[3:11]));z=finish(m,c);exact(m,0)
  assert[c.a,c.x,c.y,c.p]==[0x57,0xa9,0x63,p|1],('actual accepted fullAXYP',p,z['AXYP'])
  assert(smc(m),m.rawtags,bytes(m[3:11]))==before
  accepted.append([p,z['CPU']])
 return dict(rejected_all64_flags=len(rows),rejected_AXYP_SP_full33SMC_maps_and_cache_exact=True,accepted_flag_edges=accepted,accepted_fullAXYP_except_result_C=True,rows=rows)

def failures():
 rows=[]
 for bank,offset in[(1,0),(1,0x1fff),(2,0),(2,0x1fe0),(3,0),(3,0x1fff)]:
  m=Bus();checkpoint(m);m.readback_fault=(bank,offset);c=cpu(m);z=finish(m,c)
  assert not c.p&1 and m.ram[2][0x1fe0]==0 and m.ram[3][0x1fe0]==0 and not m.executed_guest
  assert not m.protection_writes
  rows.append([bank,offset,z['CPU']])
 m=Bus();checkpoint(m);m.protection=[0,0];c=cpu(m);z=finish(m,c)
 assert not c.p&1 and not m.executed_guest and m.protection==[0,0]and not m.protection_writes
 assert m.blocked,('hardware protection must block actual writes',m.blocked)
 return dict(real_readback_fault_cases=rows,locked_WRAM_rejected_without_protection_change=True,scope='Write ownership requires native RAM writable. A locked stale cookie cannot be invalidated by this loader; the actual parent retirement/boundary must not call it under locked global protection.')

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--only',default='transfers,flags,failures');args=ap.parse_args()
 assert not O.exists();O.mkdir();d=dict(passed=False,native=False,guest_RAM_preloaded=False,actual_cart_hooks=False,ready=False,checks={})
 try:
  stage=json.loads((P/'source-stage.json').read_text())
  for p,h in stage['bindings'].items():assert sha(p)==h,p
  for n in args.only.split(','):
   d['checks'][n]=dict(transfers=transfers,flags=flags_and_rejections,failures=failures)[n]();print('CF loader',n,'PASS',flush=True)
  d['passed']=True
 except Exception as e:d.update(failure=repr(e),traceback=traceback.format_exc());raise
 finally:
  paths=[Path(__file__),P/'source-stage.json',P/'joint/candidate.nes',P/'joint/candidate.dbg',P/'joint/cf-loader.s',P/'joint/cf-stream.bin',P/'joint/cf-cookie.bin',R/'tools/audit/arthur_cache_host_controls_v1.py',R/'tools/audit/check_tmnt_render_oa.py',R/'tools/audit/verify_native_relocation.py']
  d['bindings']={str(p.resolve()):sha(p)for p in paths}
  path=O/'controls.json';path.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(path=str(path),sha256=sha(path),passed=d['passed'],failure=d.get('failure'))),flush=True)

if __name__=='__main__':main()

