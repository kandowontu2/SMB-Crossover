"""Retain parser negatives and validate corrected observer before execution."""
from pathlib import Path
import hashlib,json,re
R=Path(__file__).resolve().parents[2];P=Path(__file__).with_name('contra_force_compact_arena_controls_v1.py')
N=R/'build/contra-force-compact-arena-controls-v2';assert not N.exists();N.mkdir()
(N/'preparation-negative.json').write_text(json.dumps(dict(passed=False,failure='v2 corrected else literal spacing but original if36 token also prevented parsing; no CPU or compiler execution.',tool_sha256=hashlib.sha256(P.read_bytes()).hexdigest()),indent=2)+'\n',encoding='utf-8')
s=P.read_text(encoding='utf-8').replace('build/contra-force-compact-arena-controls-v1','build/contra-force-compact-arena-controls-v3')
s=re.sub(r'\b(else|if)(?=\d)',r'\1 ',s)
code=compile(s,str(P),'exec')
exec(code,{'__name__':'__main__','__file__':str(Path(__file__).resolve())})
