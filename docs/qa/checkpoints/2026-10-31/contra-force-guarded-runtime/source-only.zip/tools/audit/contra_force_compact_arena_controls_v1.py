"""Compare actual relocated CF instructions with original donor updates.

Explicit original-ROM oracle services and original position integration are
test boundaries, not implemented SMB adapters. All code/state stay private.
"""
from pathlib import Path
import hashlib,json,re,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit')]
import contra_force_engine_probe_v1 as T
from verify_native_relocation import NesMPU
P=R/'build/contra-force-compact-arena-v2';O=R/'build/contra-force-compact-arena-controls-v1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
page={0:0,2:1,3:2,6:3,7:4}
def labels(p):
 out={}
 for line in p.read_text(encoding='utf-8').splitlines():
  n=re.search(r'name="([^"]+)"',line);v=re.search(r'\bval=0x([0-9A-Fa-f]+)',line)
  if n and v:out[n[1]]=int(v[1],16)
 return out
L=labels(P/'arena.dbg');N=labels(T.P/'candidate.dbg')
proof=json.loads((P/'build-proof.json').read_text());gates={L[n]:n for n in proof['original_services_executed_by_fixture_only']}
def at(a):return L['CfState']+page[a//256]*256+a%256
class OriginalMem(T.Mem):
 def pair(self,lo):
  self.reg[6:8]=[lo,lo+1];self[0x36]={0:0,4:2,10:1}[lo];self.map()
def original(var,gear):
 m=OriginalMem();m.pair(4);m[0xb1]=var;m[0x7f+var]=16|gear
 m[0x782]=46;m[0x64e]=112;m[0x668]=168;m[0x682]=10;m[0x7d2]=1
 return NesMPU(memory=m)
def arena(c):
 m=[0]*65536;m[0x8000:0x8000+len((P/'arena.bin').read_bytes())]=(P/'arena.bin').read_bytes()
 m[0xf000:0xf000+len((P/'oracle-gates.bin').read_bytes())]=(P/'oracle-gates.bin').read_bytes()
 for old,new in page.items():m[at(old*256):at(old*256)+256]=c.memory[old*256:old*256+256]
 return NesMPU(memory=m)
def source_image(c):
 m=OriginalMem()
 for old in page:m[old*256:old*256+256]=c.memory[at(old*256):at(old*256)+256]
 return m
def oracle(c,name=None,integration=False):
 m=source_image(c);m.pair(0 if integration or name in['sub_B388','sub_BA51']else4)
 z=NesMPU(memory=m);z.a,z.x,z.y,z.p=c.a,c.x,c.y,c.p
 z.sp=c.sp+2 if name else255
 z.stPushWord(0x7ffe);z.pc=0xbce0 if integration else N[name]
 n=0
 while z.pc!=0x7fff:
  assert n<30000,('original oracle bound',name,hex(z.pc))
  assert z.memory[z.pc],('original oracle BRK',name,hex(z.pc))
  z.step();n+=1
 for old in page:c.memory[at(old*256):at(old*256)+256]=z.memory[old*256:old*256+256]
 c.a,c.x,c.y,c.p=z.a,z.x,z.y,z.p
 if integration:c.memory[at(0x36)]=2
 else:c.pc=(c.stPopWord()+1)&65535
 return n
def call(c,name):
 c.pc=L[name];c.a=c.x=c.y=0;c.p=0x24;c.sp=255;c.stPushWord(0x7ffe)
 n=0;services={};start=c.processorCycles
 while c.pc!=0x7fff:
  assert n<30000,('projected source bound',name,hex(c.pc))
  if c.pc in gates:
   service=gates[c.pc];services[service]=services.get(service,0)+1;oracle(c,service)
  else:
   assert c.memory[c.pc],('projected source BRK',name,hex(c.pc))
   c.step()
  n+=1
 return dict(source_instructions=n,source_cycles=c.processorCycles-start,original_oracle_services=services)
def step(c,pad,ground):
 m=c.memory;m[at(0x23)]=(m[at(0x23)]+1)&255
 m[at(0x40)]=pad&~m[at(0x42)];m[at(0x42)]=pad
 out=[call(c,'CfNativeClear')];m[at(0x7d2)]=1 if ground else0
 out+=[call(c,'CfNativeInput'),call(c,'CfNativeBody')]
 c.a=c.x=c.y=0;c.p=0x24;oracle(c,integration=True)
 return out
def compare(c,z,ctx):
 # Every actor byte (all26 native object slots plus both players), not only
 # the measured velocities. Pointer scratch legitimately contains relocated
 # program addresses, so it is outside this semantic source-state comparison.
 for a in[0x7f+i for i in range(4)]+[0x83,0xb1,0xc0]+list(range(0x600,0x800)):
  assert c.memory[at(a)]==z.memory[a],(ctx,hex(a),c.memory[at(a)],z.memory[a])
def main():
 assert not O.exists();O.mkdir();d=dict(passed=False,native=False,host=False,rows=[],scope='Flat linked projected instructions; genuine donor oracle callbacks and original position integration, explicit contacts. No SMB worlds or mapper/ISR qualification.')
 try:
  for p,h in proof['bindings'].items():assert sha(p)==h,p
  total=0
  for var in range(4):
   for gear in range(3):
    z=original(var,gear);c=arena(z);rows=[]
    for age in range(72):
     pad=(1 if age<24 else2 if age<36 else0)|(0x80 if36<=age<56 else0)|(0x40 if age in[4,20,60]else0)
     ground=not(z.memory[0x7aa]&64)
     ref=T.step(z,pad,ground);obs=step(c,pad,ground);compare(c,z,(var,gear,age))
     rows.append(dict(age=age,pad=pad,ground=ground,x=ref['x'],y=ref['y'],dX=ref['dX'],dY=ref['dY'],animation=ref['animation'],projected_calls=obs))
     total+=1
    d['rows'].append(dict(variant=var,gear=gear,updates=rows))
    print(f'projected donor {var}/{gear}72updates PASS',flush=True)
  d.update(passed=True,actual_source_differential_updates=total,compared_actor_bytes_per_update=519)
 except Exception as e:d.update(error=repr(e),traceback=traceback.format_exc());raise
 finally:
  files=[Path(__file__),Path(T.__file__),R/'tools/audit/verify_native_relocation.py',P/'build-proof.json',P/'arena.bin',P/'arena.dbg',P/'oracle-gates.bin',T.P/'proof.json',T.P/'candidate.nes',T.P/'candidate.dbg']
  d['bindings']={str(p.resolve()):sha(p)for p in files}
  p=O/'controls.json';p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8');print(json.dumps(dict(path=str(p),sha256=sha(p),passed=d['passed'],error=d.get('error'))),flush=True)
if __name__=='__main__':main()
