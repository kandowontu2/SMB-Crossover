"""Measure genuine CF24-page bootstrap before requesting any ROM interval."""
from pathlib import Path
import hashlib,json,re,subprocess,sys
R=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(R/'tools/audit')]
from private_build_outputs_v1 import validate
O=R/'build/contra-force-loader-proposal-v1'
P=R/'tools/reference/contra_force_loader_proposal_v1.s'
N=R/'build/peach-palette-fix-1030-v1/joint/candidate.dbg'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
 assert not O.exists();O.mkdir()
 defs={}
 for line in N.read_text().splitlines():
  name=re.search(r'name="([^"]+)"',line);value=re.search(r'\bval=0x([0-9a-fA-F]+)',line)
  if name and value:defs[name[1]]=int(value[1],16)
 imports=[]
 for row in re.findall(r'^\.import(?:zp)? (.*)',P.read_text(),re.M):imports.extend(row.split(','))
 assert not(set(imports)-defs.keys()),set(imports)-defs.keys()
 source=P.read_text()
 (O/'proposal.s').write_text(source)
 (O/'native-imports.s').write_text('\n'.join('.export '+name+'\n'+name+'=$%04x'%defs[name]for name in imports)+'\n')
 ca=R/'tools/Windows/cc65/bin/ca65.exe';ld=ca.with_name('ld65.exe');od=ca.with_name('od65.exe')
 (O/'proposal.cfg').write_text('''MEMORY {
 A:start=$a000,size=$2000,type=ro,bank=$70,file="outer.bin";
 C:start=$c000,size=$2000,type=ro,bank=$71,file="core.bin";
}
SEGMENTS {
 CF_LOADER_PROPOSAL_A:load=A,type=ro;
 CF_LOADER_PROPOSAL_C:load=C,type=ro;
}
''')
 commands=[]
 for name in['proposal','native-imports']:
  commands.append([str(ca),'--cpu','6502x','-g','--create-full-dep',str(O/(name+'.dep')),'-o',str(O/(name+'.o')),str(O/(name+'.s'))])
 commands.append([str(ld),'-C',str(O/'proposal.cfg'),'-o',str(O/'unused.bin'),'--dbgfile',str(O/'proposal.dbg'),'-Ln',str(O/'proposal.lbl'),'-m',str(O/'proposal.map'),str(O/'proposal.o'),str(O/'native-imports.o')])
 logs=[]
 for cmd in commands:
  guard=validate(cmd,O,cwd=O);p=subprocess.run(cmd,cwd=O,capture_output=True,text=True)
  logs.append(dict(command=cmd,output_guard=guard,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr))
  (O/'build-log.json').write_text(json.dumps(logs,indent=2)+'\n');assert p.returncode==0,logs[-1]
 sizes=dict(retained_A_ROM_outer=len((O/'outer.bin').read_bytes()),retained_C_ROM_core=len((O/'core.bin').read_bytes()))
 proof=dict(passed=True,status='MEASURED_ROM_BOOTSTRAP_PROPOSAL_NO_ROM_LEASE_NO_EXECUTION_OR_ADOPTION',native=False,host=False,
            actual_emitted_bytes=sizes,actual_current64_imports={n:defs[n]for n in imports},
            stream=dict(first_physical_CHR=935,pages=24,destinations=[dict(raw_A=i,pages=8)for i in[1,2,3]],C2_cookie=dict(address=0xdfe0,validity=0xa7,family=31,alternate='FmGroups>>3 &3',version=1,payload_fingerprint='Final actual24KiB SHA prefix required; zero measurement placeholder is not executable readiness')),
            preconditions=['Genuine old-owner retire chain completed before any guest overwrite','Selectedraw31 + Mainbusy1 + OperMode1 + MirrorPPUMASK&18=0 + DisableScreenFlag!=0 + NmiDisable<0','Native X5PublishChr completed actual12-window/upper0 software-to-hardware checkpoint','C2DFE0 andRAM3BFE0 source carrier bytes arezero'],
            invariants=['No5102/5103/5113 writes','Shared C2cookie invalidfirst; stale RAM3cookie invalidbeforecopy; full24576B buffered2007 copy+verify; validitylast','R0..3 borrowed/saved; AXYP preserved except resultC; origin A/C restored before return; Reload/CTRL/scroll/latch/BG11 restored'],
            remaining=['Root-owned source/resource decision for ROM placement or generic-loader factoring','Executable CPUmodel/readback corruption/realISR/fullcookie controls','Actual InitScreen/common ingress, header/sourcecarrier producer and native qualification'],
            bindings={str(p.resolve()):sha(p)for p in[Path(__file__),P,N,ca,ld,od,R/'tools/audit/private_build_outputs_v1.py',*[p for p in O.iterdir()if p.is_file()]]})
 out=O/'proposal.json';out.write_text(json.dumps(proof,indent=2)+'\n')
 print(json.dumps(dict(path=str(out),sha256=sha(out),sizes=sizes)),flush=True)

if __name__=='__main__':main()
