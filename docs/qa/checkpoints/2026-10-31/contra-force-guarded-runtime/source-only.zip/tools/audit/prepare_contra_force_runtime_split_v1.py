"""Link genuine CF engine into granted A1/A3/C2 phases for CPU controls.

Original host-service imports remain explicit donor-oracle BRK entries.  This
is not a cartridge loader, SMB collision adapter, or playable admission.
"""
from pathlib import Path
import hashlib,json,re,subprocess,sys

R=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(R/'tools/audit')]
from private_build_outputs_v1 import validate

P=R/'build/contra-force-runtime-groups-v2'
O=R/'build/contra-force-runtime-split-v1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
 assert not O.exists();O.mkdir()
 proof=json.loads((P/'object/source-object-proof.json').read_text())
 for p,h in proof['bindings'].items():assert sha(p)==h,p
 grant=R/'docs/qa/checkpoints/2026-10-30/contra-force-source-kernel-resource-review/resource-grant.json'
 assert sha(grant)=='c0c5ff0494e07d44e983e84d809249eff3e2a5f10e86aaa01e2ca002d473f64b'
 groups=json.loads((P/'runtime-groups.json').read_text())
 byid={g['id']:g for g in groups}
 symbols={name:g for g in groups for name in g['labels']}
 # Source bank04/05 player/allocator/animation engine stays together. Shot
 # handlers are A3. Original fixed-bank helpers and the two shared SFX
 # tables are always-visible C2, so data reads never require a code gate.
 phase={g['id']:(2 if g['bank']=='FF' or g['id']in[1070,1071]
                    else 3 if g['bank']=='00' else 1)for g in groups}
 for g in groups:
  if g['fallthrough_to'] is not None:
   assert phase[g['id']]==phase[g['fallthrough_to']],g
 text=(P/'object/component.s').read_text()
 gates={};references=[]
 for g in groups:
  start=text.index('CfChunkStart_%03d:'%g['id'])
  end=text.index('CfChunkEnd_%03d:'%g['id'],start)
  chunk=text[start:end];origin=phase[g['id']]
  if origin==2:
   cross=[name for name in set(re.findall(r'\b\w+\b',re.sub(r';[^\n]*','',chunk)))&symbols.keys()
          if phase[symbols[name]['id']]!=2]
   assert not cross,('C2 helper unexpectedly calls phase-local source',g['id'],cross)
  def replace(m):
   name=m[0]
   if name not in symbols:return name
   target=symbols[name];dest=phase[target['id']]
   if dest in[origin,2]:return name
   # Definitions stay at their genuine source boundary; only consumers
   # enter the same-A gate. Every cross-A reference here is executable or
   # an executable pointer-table entry, never a foreign data read.
   assert not target['data'],('Cross-A data read',g['id'],name)
   key=(origin,name);gate='CfGate%d_%s'%(origin,name)
   gates[key]=dict(name=gate,target=name,target_phase=dest,origin_phase=origin)
   references.append(dict(group=g['id'],target=name,gate=gate,source_phase=origin,target_phase=dest))
   return gate
  # Do not rewrite names inside original comments.
  changed='\n'.join(re.sub(r'\b\w+\b',replace,line.split(';')[0])+(' ;'+line.split(';',1)[1]if';'in line else'')for line in chunk.splitlines())+'\n'
  text=text[:start]+changed+text[end:]
 # Replace uses only; unresolved genuine source imports are intentionally
 # not transformed into SMB services in this source-only split packet.
 text+='\n.import CfCallA,CfTarget,CfTargetBank\n'
 for bank in[1,3]:
  text+='\n.segment "CF_GATES_%d"\n'%bank
  for (origin,name),gate in sorted(gates.items()):
   if origin!=bank:continue
   text+=gate['name']+':\n php\n pha\n lda #<'+name+'\n sta CfTarget\n lda #>'+name+'\n sta CfTarget+1\n lda #'+str(gate['target_phase'])+'\n sta CfTargetBank\n pla\n plp\n jmp CfCallA\n'
 state=(P/'object/state.inc').read_text()
 (O/'state.inc').write_text(state,encoding='utf-8')
 (O/'component.s').write_text(text,encoding='utf-8')
 bridge=R/'tools/reference/contra_force_phase_bridge_v1.s'
 (O/'phase-bridge.s').write_bytes(bridge.read_bytes())
 services=proof['unresolved_genuine_source_services']
 oracle=['.segment "ORACLE_GATES"','.export CurrentBank','CurrentBank=$0145']
 for name in services:oracle+=['.export '+name,name+':brk',' .byte 0']
 (O/'oracle-gates.s').write_text('\n'.join(oracle)+'\n')
 cfg=['MEMORY {',' ZP:start=$0003,size=2,type=rw,file="";',
      ' A1:start=$a000,size=$2000,type=ro,bank=1,file="ram1.bin",fill=yes,fillval=$ff;',
      ' A3:start=$a000,size=$2000,type=ro,bank=3,file="ram3.bin",fill=yes,fillval=$ff;',
      ' C2:start=$c000,size=$1fe0,type=rw,bank=2,file="ram2.bin",fill=yes,fillval=$ff;',
      ' ORACLE:start=$f000,size=$0100,type=ro,file="oracle-gates.bin";','}',
      'SEGMENTS {',' CF_POINTERS:load=ZP,type=zp;',
      ' CF_STATE:load=C2,type=bss;', ' CF_CORE:load=A1,type=ro;']
 for g in groups:cfg+=[' '+g['segment']+':load='+{1:'A1',3:'A3',2:'C2'}[phase[g['id']]]+',type=ro;']
 cfg+=[' CF_ANIM_POINTERS:load=C2,type=ro;',' CF_ANIMATION:load=C2,type=ro;',
       ' CF_JUMP_LIMIT:load=C2,type=ro;',' CF_C2_TRANSPORT:load=C2,type=ro;',
       ' CF_GATES_1:load=A1,type=ro;',' CF_GATES_3:load=A3,type=ro;',
       ' ORACLE_GATES:load=ORACLE,type=ro;','}']
 (O/'runtime.cfg').write_text('\n'.join(cfg)+'\n')
 ca=R/'tools/Windows/cc65/bin/ca65.exe';ld=ca.with_name('ld65.exe');logs=[]
 commands=[]
 for name in['component','phase-bridge','oracle-gates']:
  commands.append([str(ca),'--cpu','6502x','-g','-I',str(R/'build/contra-force-reproduction-v2'),
                   '--create-full-dep',str(O/(name+'.dep')),'-o',str(O/(name+'.o')),str(O/(name+'.s'))])
 commands.append([str(ld),'-C',str(O/'runtime.cfg'),'-o',str(O/'runtime.bin'),
                  '--dbgfile',str(O/'runtime.dbg'),'-Ln',str(O/'runtime.lbl'),'-m',str(O/'runtime.map'),
                  *[str(O/(n+'.o'))for n in['component','phase-bridge','oracle-gates']]])
 for cmd in commands:
  guard=validate(cmd,O,cwd=O);q=subprocess.run(cmd,cwd=O,capture_output=True,text=True)
  row=dict(command=cmd,cwd=str(O),output_guard=guard,returncode=q.returncode,stdout=q.stdout,stderr=q.stderr)
  logs.append(row);(O/'build-log.json').write_text(json.dumps(logs,indent=2)+'\n')
  assert q.returncode==0,row
 syms={}
 for line in(O/'runtime.dbg').read_text().splitlines():
  name=re.search(r'name="([^"]+)"',line);value=re.search(r'\bval=0x([0-9a-fA-F]+)',line)
  if name and value:syms[name[1]]=int(value[1],16)
 sizes={}
 for g in groups:sizes[g['segment']]=syms['CfChunkEnd_%03d'%g['id']]-syms['CfChunkStart_%03d'%g['id']]
 usage={bank:sum(sizes[g['segment']]for g in groups if phase[g['id']]==bank)for bank in[1,2,3]}
 # The measured gate is 24 bytes, not a source-size estimate. Link map
 # captures any long-branch growth independently.
 gate_sizes={bank:len([v for v in gates.values()if v['origin_phase']==bank])*24 for bank in[1,3]}
 out=dict(passed=True,status='SOURCE_LINKED_A1_A3_C2_ENGINE_WITH_EXPLICIT_DONOR_ORACLES_NOT_HOST',
          native=False,host=False,raw_A_phases=[1,3],raw_C_phase=2,borrowed_native_pair=[3,4],
          state_bytes=1280,phase_by_group=phase,gates=list(gates.values()),cross_phase_references=references,
          source_group_bytes_by_phase=usage,gate_bytes_by_phase=gate_sizes,
          original_services_executed_by_fixture_only=services,
          allocation_grant=str(grant),all_static_source_fields_retained=True,
          missing=['Natural forced-blank loader and retirement','SMB world/shot impact callbacks','Host renderer/palette/lifecycle routes','Actual Main/ISR/native execution'],
          bindings={str(p.resolve()):sha(p)for p in[Path(__file__),grant,bridge,P/'runtime-groups.json',P/'object/source-object-proof.json',P/'object/component.s',P/'object/state.inc',ca,ld,R/'tools/audit/private_build_outputs_v1.py',*[p for p in O.iterdir()if p.is_file()]]})
 path=O/'build-proof.json';path.write_text(json.dumps(out,indent=2)+'\n')
 print(json.dumps(dict(path=str(path),sha256=sha(path),source_bytes=usage,gates=gate_sizes)),flush=True)

if __name__=='__main__':main()
