"""Reconstruct original in-game CF bodies; every opaque pixel screenshot checked."""
from pathlib import Path
import hashlib,json,struct
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parents[2];O=R/'build/contra-force-body-art-v2';O.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
ROM=Path('C:/NES/Contra Force (USA).nes');raw=ROM.read_bytes();assert sha(ROM)=='ba5337367a2140c72ae40826ff4fb9b86a38798ed129edc9bd519aec8818abfa'
original=raw[16+128*1024:];assert len(original)==128*1024
def export(name,folder,frame=900):
 path=folder/f'frame-{frame:05d}.bin';dp=folder/f'frame-{frame:05d}-dma.bin';sp=folder/f'frame-{frame:05d}.png';p=path.read_bytes();dma=dp.read_bytes()
 assert p[:8]==b'NATIVE02'and struct.unpack_from('<I',p,8)[0]==frame
 oam=p[14:270];assert oam==dma[13:269],'EndFrame OAM does not match actual lastDMA source buffer'
 vp=folder/f'frame-{frame:05d}-visible.bin';vis=vp.read_bytes();assert vis[:8]==b'VISIBLE1'
 vf,line,ctrl=struct.unpack_from('<IHB',vis,8);assert vf==frame and line==160 and ctrl&32
 physical=list(struct.unpack_from('<8I',vis,15));chr=vis[47:8239];pal=vis[8239:8271];assert len(chr)==8192 and len(pal)==32
 for w,physical_offset in enumerate(physical):assert chr[w*1024:(w+1)*1024]==original[physical_offset:physical_offset+1024],('Visible physical publisher mismatch',w,physical_offset)
 assert any(chr),'Rejected zero-filled late-HUD pattern snapshot'
 image=Image.open(sp).convert('RGB');source={};parts=[];origins=[];colors={}
 for slot in range(63,-1,-1):
  y,t,a,x=oam[slot*4:slot*4+4]
  if not(80<=x<=132 and 128<=y<=184):continue
  parts.append(dict(slot=slot,y=y,tile=t,attr=a,x=x));pair=chr[(t&1)*4096+(t&254)*16:(t&1)*4096+(t&254)*16+32]
  matches=[i for i in range(0,len(original)-31,16)if original[i:i+32]==pair];assert matches,'Bodypair missing from authenticated originalROM'
  origins.append(dict(tile=t,possible_original_CHR_offsets=matches,pattern_sha256=hashlib.sha256(pair).hexdigest()))
  for yy in range(16):
   sy=15-yy if a&128 else yy
   for xx in range(8):
    sx=7-xx if a&64 else xx;at=(sy//8)*16+sy%8;v=(pair[at]>>(7-sx)&1)|((pair[at+8]>>(7-sx)&1)<<1)
    if v:
     xy=(x+xx,y+1+yy);code=pal[16+(a&3)*4+v]&63;source[xy]=code;colors.setdefault(code,set()).add(image.getpixel(xy))
 assert len(parts)>=4 and all(len(z)==1 for z in colors.values()),('Actual OAM/palette/CHR disagree with screenshot',name,colors)
 canvas=Image.new('RGBA',(256,240))
 for xy,code in source.items():canvas.putpixel(xy,next(iter(colors[code]))+(255,))
 box=canvas.getbbox();body=canvas.crop(box);fp=O/f'contra-force-{name}.png';assert not fp.exists();body.save(fp)
 scale=min(16/body.width,24/body.height,1);small=body.resize((round(body.width*scale),round(body.height*scale)),Image.Resampling.NEAREST)
 thumb=Image.new('RGBA',(16,24));thumb.alpha_composite(small,((16-small.width)//2,24-small.height))
 for y in range(24):
  for x in range(16):
   r,g,b,a=thumb.getpixel((x,y))
   if a:
    l=(299*r+587*g+114*b)//1000;g=72 if l<85 else 160 if l<170 else 248;thumb.putpixel((x,y),(g,g,g,255))
 tp=O/f'contra-force-{name}-thumb16x24.png';thumb.save(tp)
 crop=image.crop((16,196,120,225));crop.save(O/f'{name}-native-HUD.png')
 entry=dict(name='contra-force-'+name,key='contra-force-'+name,path=str(fp),thumbnail=str(tp),output_sha256=sha(fp),thumbnail_sha256=sha(tp),size=list(body.size),
  source=dict(kind='ORIGINAL_NATIVE_GAMEPLAY_FULL_BODY',ROM=str(ROM),ROM_sha256=sha(ROM),snapshot=str(path),snapshot_sha256=sha(path),visible_scanline=160,visible_physical_CHR_offsets=physical,visible_snapshot=str(vp),visible_snapshot_sha256=sha(vp),DMA_snapshot=str(dp),DMA_sha256=sha(dp),screenshot=str(sp),screenshot_sha256=sha(sp),frame=frame,
   crop=list(box),source_parts=sorted(parts,key=lambda p:p['slot']),original_pattern_origins=origins,palette_indices={str(k):list(next(iter(v)))for k,v in colors.items()},
   opaque_source_pixels=len(source),every_opaque_source_pixel_screenshot_checked=True,opaque_black_preserved=True,transparent_policy='Only original pattern index0 is transparent.',identity='Actual original gameplay HUD visually reviewed; no identity inferred from Up count.'),
  bindings={str(f.resolve()):sha(f)for f in[Path(__file__),ROM,path,dp,vp,sp,fp,tp,O/f'{name}-native-HUD.png',folder.parent/'prepared.json',folder.parent/'terminal.json']})
 (O/f'{name}-manifest.json').write_text(json.dumps(entry,indent=2)+'\n',newline='\n');print(json.dumps(dict(name=name,size=list(body.size),parts=len(parts),opaque_pixels=len(source),codes=sorted(colors),manifest=str(O/f'{name}-manifest.json'))))
if __name__=='__main__':
 import argparse
 p=argparse.ArgumentParser();p.add_argument('name');p.add_argument('folder',type=Path);a=p.parse_args();export(a.name,a.folder)
