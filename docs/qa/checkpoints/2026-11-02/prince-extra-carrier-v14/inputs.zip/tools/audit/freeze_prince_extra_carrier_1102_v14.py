"""Record root's exact291 grant and preserve only its necessary small proofs."""
from pathlib import Path
import hashlib,json,sys,zipfile
R=Path(__file__).resolve().parents[2];O=R/'build/prince-actor-1101-v1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
 audit=O/'extra-carrier-291-v14.json';pub=O/'extra291-publication-v14.json';a=json.loads(audit.read_text());p=json.loads(pub.read_text())
 assert a['passed']and p['passed']and a['proposed_page']==291 and p['proposed_pages']==[291]
 assert a['current_ROM_SHA256']==p['current_ROM_sha256']=='1966a4883a888a5e62f90c4d3e96d25ecf028ddd7d714214727793418d633243'
 proofs=[R/'tools/audit/audit_prince_extra_carrier_1102_v14.py',R/'tools/audit/check_prince_extra_carrier_publication_1102_v14.py',audit,pub]
 q=dict(granted=True,owner='Prince of Persia private source code storage',date='2026-11-02',base_ROM_SHA256=a['current_ROM_SHA256'],root_approval='Explicit root message after reviewing v14 source consumer audit and actual publication supplement.',additional_physical_CHR_pages=[dict(page=291,file_offset=1346576,bytes=1024,preimage_SHA256='8c9c5a281191c36a17f638689b0b27b122d183dc988a5468b1fcd15494a8e1bc')],original_42_page_grant='docs/qa/allocations/prince-1102-v1.json',total_Prince_carrier_pages=43,total_pool_bytes=44032,source_consumer_closure=dict(original_Darkwing_pose_rows=71,animation_rows=42,body_domain=a['exact_Darkwing_body_domain'],actual_body_cases=324,actual_weapon_pages=[302,303],all_inherited_direct_writers_exact=816,private_writer_chunks_exact=15,current_tables_exact=24,legacy_publication_upper=0),publication=dict(typed_setter_cuts=240,native_Mario_menu_cuts=2376,real_lag_NMI_returns=2654,transient291_pairs=32,page291_ever_published=False),conditions=['Source-funded code storage only; physical page291 must match this exact preimage before composition.','No additional RAM, shared loader, routing, menu confirmation or native gameplay admission is granted.','Retain the original Prince43-page conditional overlay/authentication/forcedblank/mapper/header publication conditions.','The proposed executable-state binding remains a separate amendment requiring reader/writer/constructor/clock closure.','Carry exact1966 and all later root-approved disjoint cumulative updates into eventual composition.'],ROM_written=False,installed=False,bindings={str(f.relative_to(R)):sha(f)for f in proofs})
 grant=R/'docs/qa/allocations/prince-extra-carrier-1102-v14.json';grant.write_text(json.dumps(q,indent=2)+'\n')
 files=[*proofs,grant,Path(__file__)];archive=O/'extra-carrier-291-source-v14.zip'
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
  for f in files:z.writestr(f.relative_to(R).as_posix(),f.read_bytes())
 with zipfile.ZipFile(archive)as z:
  assert len(z.infolist())==len(files)
  for f in files:assert z.read(f.relative_to(R).as_posix())==f.read_bytes()
 print(json.dumps(dict(granted_page=291,grant=str(grant.relative_to(R)),grant_SHA256=sha(grant),checkpoint=str(archive.relative_to(R)),checkpoint_bytes=archive.stat().st_size,checkpoint_SHA256=sha(archive),members=len(files))))


if __name__=='__main__':main()
