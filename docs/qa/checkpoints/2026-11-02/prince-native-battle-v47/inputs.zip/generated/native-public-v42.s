PpNativeInit=$d963
PpNativeMotionExport=$daa9
PpNativePitDeath=$d9eb
PpNativeQuietMusic=$da8e
PpNativeQuietSfx=$da7f
PpNativeRetire=$d98f
PpNativeServicesEnd=$dad4
PpNativeTick=$d999
PpNativeUnpublishedMaterial=$daa8
PpNativeProxyIn=$ddcc
PpNativeProxyOut=$dea7
PpNativeCall=$da2a
PpNativeContact=$bd22
PpNativeHealthStatus=$bd3a
PpNativeColors=$df71
PpNativeCallKind=$da48
PpNativeCallSlot=$da59
PpHostDraw=$bbc1
.setcpu "6502"
PpServiceTag=$c09e ; Source world SavedY; overwritten before its only read.
.segment "FRESH_PREFIX"
.export PpNativeFresh,PpNativeFreshEnd
PpNativeFresh:
 lda #0
 ldx #7
FreshGap:
 sta $c0f8,x
 dex
 bpl FreshGap
 jmp PpNativeResetTail
PpNativeFreshEnd:
.segment "PUBLIC"
.export PpNativeResetTail,PpNativeRoute,PpNativePublicEnd
PpNativeResetTail:
 ldx #$af
FreshPrefix:
 sta $c000,x
 dex
 cpx #$ff
 bne FreshPrefix
 ldx #$0f
FreshGap2:
 sta $c352,x
 dex
 bpl FreshGap2
 ldx #$0b
FreshGap3:
 sta $c3ff,x
 dex
 bpl FreshGap3
 ldx #$6d
FreshGap4:
 sta $c491,x
 dex
 bpl FreshGap4
 ldx #$f9
FreshActorPage:
 sta $c606,x
 dex
 cpx #$ff
 bne FreshActorPage
 ldx #0
FreshLastPage:
 sta $c700,x
 inx
 bne FreshLastPage
 jmp PpNativeInit
PpNativeRoute:
 pha
 lda PpServiceTag
 beq PublicTick
 cmp #6
 beq PublicDraw
 cmp #45
 beq PublicFresh
 cmp #108
 beq PublicFresh
 cmp #3
 beq PublicGraphics
 cmp #15
 beq PublicContact
 cmp #33
 beq PublicContact
 cmp #18
 beq PublicStatus
 cmp #27
 beq PublicGraphics
 cmp #78
 beq PublicColors
 pla
 clc
 rts
PublicTick:
 pla
 jmp PpNativeTick
PublicDraw:
 pla
 jmp PpHostDraw
PublicFresh:
 pla
 jmp PpNativeFresh
PublicContact:
 pla
 jmp PpNativeContact
PublicStatus:
 pla
 jmp PpNativeHealthStatus
PublicColors:
 pla
 jmp PpNativeColors
PublicGraphics:
 pla
 sec
 rts
PpNativePublicEnd:
