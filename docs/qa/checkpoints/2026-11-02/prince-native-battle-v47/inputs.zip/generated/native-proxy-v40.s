Enemy_Flag=$0010
Enemy_ID=$0017
Enemy_State=$001f
Enemy_BoundBoxCtrl=$0646
Enemy_X_Position=$0076
Enemy_PageLoc=$005d
Enemy_Y_Position=$00be
Enemy_Y_HighPos=$00a5
Enemy_MovingDir=$053f
R0=$0003
SafecallA_SMC=$0169
FarcallJmpTarget_SMC=$016b
FarCallCommon=$015a
PpHostImportX=$b3d1
PpSourceNear=$a3b9
SmcOffsets=$dc6b
NativeDefeat=$9af5
NativeDefeatBank=$00fe

.setcpu "6502"
.macpack longbranch
.segment "PROXY"
.export PpNativeProxyIn,PpNativeProxyOut,PpProxyEnd
.export PpProxyBestSlot,PpProxyBestDistance
PpNativeProxyIn:
 lda $c0a6
 and #3
 cmp #2
 jne Return
 jsr PpHostImportX
 lda #104
 sta PpProxyBestDistance
 lda #255
 sta PpProxyBestSlot
 ldx #5
Scan:
 lda Enemy_Flag,x
 cmp #1
 bne Next
 lda Enemy_ID,x
 cmp #7
 bcs Next
 lda Enemy_State,x
 and #$20
 bne Next
 lda Enemy_BoundBoxCtrl,x
 cmp #3
 bne Next
 lda Enemy_Y_HighPos,x
 cmp #1
 bne Next
 jsr ImportX
 jsr PpSourceNear
 bcs Next
 lda $c017
 cmp PpProxyBestDistance
 bcs Next
 sta PpProxyBestDistance
 stx PpProxyBestSlot
Next:
 dex
 bpl Scan
 ldx PpProxyBestSlot
 bmi Absent
 txa
 ora #$80
 cmp $c61c
 beq Import
 ldy #13
Birth:
 lda GuardTemplate,y
 sta $c61c,y
 dey
 bpl Birth
 txa
 ora #$80
 sta $c61c
 stx $c051
 stx $c710
 lda #255
 sta $c712
 lda #0
 sta $c711
 sta $c6de
 lda #1
 sta $c6d0
Import:
 jsr ImportX
 lda Enemy_Y_Position,x
 clc
 adc #21
 sta $c61f
 lda Enemy_Y_HighPos,x
 adc #$ff
 sta $c620
 sec
 lda $c61f
 sbc $c089
 sta $c61f
 lda $c620
 sbc $c08a
 sta $c620
 lda #0
 ldy Enemy_MovingDir,x
 cpy #1
 bne FaceReady
 lda #255
FaceReady:
 sta $c623
 lda #1
 sta $c6e0
 rts
Absent:
 lda #0
 sta $c6e0
 sta $c61c
Return:rts
ImportX:
 lda Enemy_X_Position,x
 clc
 adc #8
 sta $c61d
 lda Enemy_PageLoc,x
 adc #0
 sta $c61e
 rts

; Export only the original guard's genuine terminal damage result. Native
; physics/AI/flags remain owned by the native actor, no outcome is seeded.
PpNativeProxyOut:
 lda $c6d0
 bne Return
 lda $c6de
 cmp #85
 bne Return
 lda $c61c
 bpl Return
 and #$7f
 cmp #6
 bcs Return
 tax
 stx PpProxyBestSlot
 lda Enemy_Flag,x
 cmp #1
 bne Return
 lda Enemy_State,x
 and #$20
 bne Return
 lda Enemy_ID,x
 cmp #7
 bcs Return
 ldx #0
SaveZp:
 lda R0,x
 pha
 inx
 cpx #8
 bne SaveZp
 ldx #0
SaveSmc:
 ldy SmcOffsets,x
 lda $0100,y
 pha
 inx
 cpx #5
 bne SaveSmc
 lda #<NativeDefeat
 sta FarcallJmpTarget_SMC+1
 lda #>NativeDefeat
 sta FarcallJmpTarget_SMC+2
 ldx PpProxyBestSlot
 lda #NativeDefeatBank
 jsr FarCallCommon
 ldx #4
RestoreSmc:
 pla
 ldy SmcOffsets,x
 sta $0100,y
 dex
 bpl RestoreSmc
 ldx #7
RestoreZp:
 pla
 sta R0,x
 dex
 bpl RestoreZp
 lda #0
 sta $c61c
 sta $c6e0
 rts
PpProxyBestSlot:.byte 255
PpProxyBestDistance:.byte 104
GuardTemplate:
 .byte $80,$08,$00,$00,$00,$f6,$96,$00,$39,$ab,$01,$00,$00,$00
PpProxyEnd:
