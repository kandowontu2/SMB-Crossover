PpNativeCall=$da1e
PpNativeCallKind=$da3c
PpNativeCallSlot=$da4d
PpNativeInit=$d963
PpNativeMotionExport=$da9b
PpNativePitDeath=$d9e9
PpNativeQuietMusic=$da80
PpNativeQuietSfx=$da71
PpNativeRetire=$d98f
PpNativeServicesEnd=$dac9
PpNativeTick=$d999
PpNativeUnpublishedMaterial=$da9a
PpNativeProxyIn=$ddc1
PpNativeProxyOut=$de9c
PpNativeColors=$df9e
PpNativeContact=$bd22
PpNativeHealthStatus=$bd3a
PpNativePacket=$c200
PpNativeAdder=$bd3e
PpNativeVerticalExport=$bd42
PpNativeFullBox=$c79a
PpNativePickup=$c7b5
PpNativeDeathUpdate=$c7ec
PpNativeDeferredKill=$c781
PpNativeColdPrefix=$c766
BlockBufferColli_Head=$9587
BlockBufferColli_Side=$958b
PpHostDraw=$bbc1
.setcpu "6502"
PpServiceTag=$c09e ; Source world SavedY; overwritten before its only read.
.segment "FRESH_PREFIX"
.export PpNativeFresh,PpNativeFreshEnd
PpNativeFresh:
 lda #0
 ldx #7
FreshGap:
 sta $c0f8,x
 dex
 bpl FreshGap
 jmp PpNativeResetTail
PpNativeFreshEnd:
.segment "PUBLIC"
.export PpNativeResetTail,PpNativeRoute,PpNativePublicEnd
PpNativeResetTail:
 ldx #$af
FreshPrefix:
 sta $c000,x
 dex
 cpx #$ff
 bne FreshPrefix
 ldx #$0f
FreshGap2:
 sta $c352,x
 dex
 bpl FreshGap2
 ldx #$0b
FreshGap3:
 sta $c3ff,x
 dex
 bpl FreshGap3
 ldx #$6d
FreshGap4:
 sta $c491,x
 dex
 bpl FreshGap4
 ldx #$f9
FreshActorPage:
 sta $c606,x
 dex
 cpx #$ff
 bne FreshActorPage
 ldx #$65
FreshLastPage:
 sta $c700,x
 dex
 bpl FreshLastPage
 jmp PpNativeInit

PpNativeRoute:
 pha
 lda PpServiceTag
 sec
 sbc #24
 bcc Scalar
 cmp #27
 bcs Scalar
 adc #<NativeVector
 sta VectorJump+1
 pla
VectorJump:jmp NativeVector
Scalar:
 lda PpServiceTag
 beq Tick
 cmp #6
 beq Draw
 cmp #108
 beq Fresh
 cmp #3
 beq Yes

 cmp #69
 beq Yes
 cmp #15
 beq Contact
 cmp #18
 beq Status
 cmp #72
 beq Pickup
 cmp #78
 beq Colors
 cmp #102
 beq Late
 pla
 clc
 rts
Tick:pla
 jmp PpNativeTick
Draw:pla
 jmp PpHostDraw
Fresh:pla
 jmp PpNativeFresh
Contact:pla
 jmp PpNativeContact
Status:pla
 jmp PpNativeHealthStatus
Pickup:pla
 jmp PpNativePickup
Colors:pla
 jmp PpNativeColors
Late:pla
 jmp PpNativeDeferredKill
Yes:pla
 sec
 rts
NativeVector:
 jmp PpNativeDeathUpdate
 sec
 rts
 nop
 jmp BlockBufferColli_Head
 jmp PpNativeContact
 jmp PpNativeAdder
 ldy #0
 rts
 jmp BlockBufferColli_Side
 jmp PpNativeFresh
 jmp PpNativeFullBox
.assert >NativeVector=>(NativeVector+26),error,"Native nine-row vector crosses page"
PpNativePublicEnd:
