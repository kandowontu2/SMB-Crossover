Player_Y_Speed=$008e
.setcpu "6502"
.segment "SMALL"
.export PpNativeAdder,PpNativeVerticalExport,PpSmallEnd
PpNativeAdder:
 ldy #6
 sec
 rts
PpNativeVerticalExport:
 lda $c084
 sbc $c086
 sta Player_Y_Speed
 rts
PpSmallEnd:
