PpNativeProxyIn=$ddc1
PpNativeProxyOut=$de9c
PpNativeVerticalExport=$bd42
NativeLo=$c7f0
NativeHi=$c7f4
NativeDefeatBank=$00fe
NativeDefaultBank=$0083
NativeDeathBank=$0088
SelectedCharacter=$6002
OperMode=$0771
GameEngineSubroutine=$000f
GamePauseStatus=$0777
FrameCounter=$000e
Player_Y_Position=$00bd
Player_Y_HighPos=$00a4
Player_X_Scroll=$0701
Player_X_Speed=$0046
PlayerFacingDir=$053e
R0=$0003
SafecallA_SMC=$0169
FarcallJmpTarget_SMC=$016b
NextBank_SMC=$0161
SafereturnA_SMC=$0178
FarCallCommon=$015a
KillPlayer=$97d6
PpHostInit=$c0b0
PpHostUpdate=$b36e
Bank_KillPlayer=$00fe
; Private authenticated-caller leaves. The resident owner must validate both
; headers before entering RAM2/3, and retire them before any overlay replacement.
; Only original source movement runs; these leaves supply native lifecycle.
.setcpu "6502"
.macpack longbranch
.segment "SERVICES"
.export PpNativeInit,PpNativeRetire,PpNativeTick,PpNativePitDeath
PpEpoch=$c0a9
PpEpochValid=$c0aa
PpReady=$c0ab
PpDead=$c0ac
PpNativeInit:
 lda #0
 sta PpReady
 jsr PpHostInit
 lda $c084
 sta $c07f
 lda $c085
 sta $c080
 lda #0
 sta PpEpochValid
 sta PpDead
 sta $c0ad
 sta $c0ae
 sta $c0af
 lda #$a7
 sta PpReady
 sec
 rts
PpNativeRetire:
 lda #0
 sta PpReady
 sta PpEpochValid
 sec
 rts
PpNativeTick:
 lda SelectedCharacter
 cmp #38
 bne Rejected
 lda PpReady
 cmp #$a7
 bne Rejected
 lda PpDead
 bne Rejected
 lda OperMode
 cmp #1
 bne Rejected
 lda GameEngineSubroutine
 cmp #8
 bne Rejected
 lda GamePauseStatus
 and #1
 bne Rejected
 lda PpEpochValid
 beq NewEpoch
 lda FrameCounter
 cmp PpEpoch
 beq Rejected
NewEpoch:
 lda FrameCounter
 sta PpEpoch
 lda #1
 sta PpEpochValid
 jsr PpNativeProxyIn
 ldx #0                 ; original F158 consumes X=actor slot
 jsr PpHostUpdate
 jsr PpNativeProxyOut
 jsr PpNativeMotionExport
 jmp PpNativePitDeath
Rejected:
 clc
 rts
PpNativePitDeath:

 lda $c6cf
 bne NativePit
 lda $c4ce
 cmp #2
 beq Kill
 lda $c616
 cmp #85
 bne NativePit
 lda $c617
 cmp #185
 beq Kill
NativePit:
 lda Player_Y_HighPos
 cmp #1
 bne CheckHigh
 lda Player_Y_Position
 cmp #240
 bcc DeathDone
 bcs Kill
CheckHigh:
 cmp #2
 bcc DeathDone
Kill:
 lda #2
 sta PpDead
 sec
 rts
DeathDone:
 sec
 rts
; Both genuine host services share exactly the same13-byte foreground lease.
; Slot/kind are synchronous owned instruction operands, never shared RAM.
.export PpNativeCall,PpNativeCallSlot,PpNativeCallKind,SmcOffsets
PpNativeCall:
 stx PpNativeCallSlot+1
 sty PpNativeCallKind+1
 ldx #7
SaveZp:
 lda R0,x
 sta $c200,x
 dex
 bpl SaveZp
 ldx #4
SaveSmc:
 ldy SmcOffsets,x
 lda $0100,y
 sta $c208,x
 dex
 bpl SaveSmc
PpNativeCallKind:ldy #0
 lda NativeLo,y
 sta FarcallJmpTarget_SMC+1
 lda NativeHi,y
 sta FarcallJmpTarget_SMC+2
 lda NativeBank,y
PpNativeCallSlot:ldx #0
 jsr FarCallCommon
 ldx #4
RestoreSmc:
 lda $c208,x
 ldy SmcOffsets,x
 sta $0100,y
 dex
 bpl RestoreSmc
 ldx #7
RestoreZp:
 lda $c200,x
 sta R0,x
 dex
 bpl RestoreZp
 sec
 rts
SmcOffsets:
 .byte <(SafecallA_SMC+1),<(FarcallJmpTarget_SMC+1),<(FarcallJmpTarget_SMC+2),<(NextBank_SMC+1),<(SafereturnA_SMC+1)
; Quiet event boundary for the initial WIP: no host APU stores or invented
; sound mapping. Original event values and actor-visible music return X remain.
.export PpNativeQuietSfx,PpNativeQuietMusic,PpNativeUnpublishedMaterial
.export PpNativeMotionExport
PpNativeQuietSfx:
 sta $c0ad
 stx $c0ae
 sty $c041
 lda #6
 sta $c6d1
 rts
PpNativeQuietMusic:
 sta $c0af
 ; Original6:AA1F/AA46 arithmetic, including ASL carry. All legal source
 ; music values are small; retain all128 low-input results nonetheless.
 cmp #$80
 bcs QuietStop
 sta $c006
 asl
 asl
 adc $c006
 tax
 inx
 inx
 inx
 inx
 lda #3
 rts
QuietStop:
 lda #$e0
 rts
PpNativeUnpublishedMaterial:
 ; Exact original entry guards need materials18/10/22/2 or demo0735!=0.
 ; This adapter only publishes0/1/20 and initializes0735=0. This leaf is
 ; unreachable in the closed initial native material/player domain.
 rts
PpNativeMotionExport:
 ; Native scroll/parser and 4.4 speed consumers have smaller units than
 ; original32px alignment. Bound transport samples; leave source/world X exact.
 lda Player_X_Scroll
 bmi NegativeSample
 cmp #6
 bcc SampleReady
 lda #5
 bne SampleReady
NegativeSample:
 cmp #$fb
 bcs SampleReady
 lda #$fb
SampleReady:
 sta Player_X_Scroll
 asl
 asl
 asl
 asl
 sta Player_X_Speed
 lda #1
 cmp $c615
 adc #0
 sta PlayerFacingDir
 sec
 jmp PpNativeVerticalExport

.export PpNativeServicesEnd
NativeBank:.byte Bank_KillPlayer,NativeDefeatBank,NativeDefaultBank,NativeDeathBank
.export NativeBank
PpNativeServicesEnd:

.export PpPendingSoundOpcode,PpPendingSoundID,PpPendingMusic
PpPendingSoundOpcode=$c0ad
PpPendingSoundID=$c0ae
PpPendingMusic=$c0af
