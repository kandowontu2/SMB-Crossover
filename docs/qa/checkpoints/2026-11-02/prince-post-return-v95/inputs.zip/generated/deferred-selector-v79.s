.setcpu "6502"
.macpack longbranch
SelectedCharacter=$6002
FarcallJmpTarget_SMC=$016b
ShDispatch=$aaf7
ShDispatchNo=$ab4f
PrSharedCall=$ab12
ShServiceVeneers=$aa88
ShCheckCode=$a800
CoCheckCode=$aef3
ExForeignUi=$b031
PpNativeRoute=$df1e
.segment "EX_SELECT"
.export ExDispatch,PrSelectEnd,ExForeignLo,ExDispatchNo
ExDispatch:
 jmp ShDispatch
PrFamily:
 lda FarcallJmpTarget_SMC+2
 cmp #>ShServiceVeneers
 beq PrSh
 lda SelectedCharacter
 sec
 sbc #37
 cmp #3
 bcc PrOdd
 lda FarcallJmpTarget_SMC+1
 jmp ExForeignUi
PrOdd:
 jsr CoCheckCode
 jcc ShDispatchNo
 lda FarcallJmpTarget_SMC+2
 cmp #$b0
 jne ShDispatchNo
 lda FarcallJmpTarget_SMC+1
 sec
 sbc #$8c
 jcc ShDispatchNo
 cmp #114
 jcs ShDispatchNo
 sta FarcallJmpTarget_SMC+1
 lda SelectedCharacter
 cmp #38
 beq PrPrince
 cmp #39
 beq PrOddBB
 lda #$a5
 jmp PrSharedCall
PrOddBB:
 lda #$a0
 jmp PrSharedCall
PrSh:
 lda SelectedCharacter
 cmp #36
 jne ShDispatchNo
 lda FarcallJmpTarget_SMC+1
 sec
 sbc #<ShServiceVeneers
 sta FarcallJmpTarget_SMC+1
 lda FarcallJmpTarget_SMC+2
 sbc #>ShServiceVeneers
 jne ShDispatchNo
 lda FarcallJmpTarget_SMC+1
 cmp #111
 jcs ShDispatchNo
 jsr ShCheckCode
 jcc ShDispatchNo
 lda #$a0
 jmp PrSharedCall
PrPrince:
 lda FarcallJmpTarget_SMC+1
 sta $0179
 lda #<PpNativeRoute
 sta FarcallJmpTarget_SMC+1
 lda #>PpNativeRoute
 jmp PrSharedCall
ExDispatchNo=ShDispatchNo
ExForeignLo:
.byte $7b,$03
PrSelectEnd:
