PpOriginalDefenderContact=$dae0
VRAM_Buffer1=$04af
VRAM_Buffer1_Offset=$04ae
.setcpu "6502"
.segment "CONTACT"
.export PpNativeContact,PpNativeHealthStatus,PpContactEnd
PpNativeContact:
 php
 pha
 txa
 pha
 tya
 pha
 lda $c6cf
 beq ContactDone
 ldy #0
 jsr PpOriginalDefenderContact
ContactDone:
 pla
 tay
 pla
 tax
 pla
 plp
 sec
 rts
PpNativeHealthStatus:
 lda #1
 sec
 rts
PpContactEnd:
.segment "COLORS"
.export PpNativeColors,PpColorsEnd
PpNativeColors:
 php
 pha
 txa
 pha
 tya
 pha
 ldx VRAM_Buffer1_Offset
 cpx #$4e
 bcs ColorsDone
 ldy #0
ColorsCopy:
 lda ColorsPacket,y
 sta VRAM_Buffer1,x
 inx
 iny
 cpy #6
 bne ColorsCopy
 stx VRAM_Buffer1_Offset
 lda #0
 sta VRAM_Buffer1,x
ColorsDone:
 pla
 tay
 pla
 tax
 pla
 plp
 sec
 rts
ColorsPacket:.byte $3f,$11,3,$27,$16,$20
PpColorsEnd:
