Player_Rel_XPos=$0571
Player_Rel_YPos=$057c
BoundingBox_UL_XPos=$0658
BoundingBox_UL_YPos=$0659
BoundingBox_LR_Corner=$065a
PowerUpType=$0034
Enemy_State=$001f
EraseEnemyObject=$8d2f
SetupFloateyNumber=$98b5
BlockBufferColli_Head=$9587
BlockBufferColli_Side=$958b
Player_Y_Speed=$008e
NativeDefaultPickup=$af71
NativeDefaultBank=$0083
NativeDefeat=$9af5
NativeDefeatBank=$00fe
KillPlayer=$97d6
Bank_KillPlayer=$00fe
NativeDeathUpdate=$af3a
NativeDeathBank=$0088
GameEngineSubroutine=$000f
PpNativeCall=$da1e
PpColdContinue=$bfa7
PpSetAction=$aa51
.setcpu "6502"
.segment "AUDIO"
.export PpNativeColdPrefix,PpNativeFullBox,PpNativePickup,PpAudioEnd
.export NativeLo,NativeHi,PpNativeDeathUpdate,PpNativeDeferredKill
PpNativeColdPrefix:
 ldy #0
ColdCopy:
 lda $c65f,y
 sta $c766,y
 cmp $c766,y
 bne ColdFailed
 iny
 cpy #154
 bne ColdCopy
 ldy #0
 ldx #5
 jmp PpColdContinue
ColdFailed:clc
 rts
PpNativeDeferredKill:
 lda $c0ac
 cmp #2
 bne DeferredDone
 dec $c0ac
 lda GameEngineSubroutine
 cmp #8
 bne DeferredDone
 ldx #0
 ldy #0
 jmp PpNativeCall
DeferredDone:sec
 rts
; Native X=0 is an actual sole-caller contract at PlayerSubs. Source center
; X=nativeX+8, explicit world-body probes span16px, foot=nativeY+32.
PpNativeFullBox:
 lda Player_Rel_XPos
 sta BoundingBox_UL_XPos
 adc #16
 sta BoundingBox_LR_Corner
 lda Player_Rel_YPos
 sta BoundingBox_UL_YPos
 clc
 adc #32
 sta BoundingBox_LR_Corner+1
 ldy #0
 sec
 rts
; Native collision has admitted the actual item overlap. Immature regular
; items remain in their block. Mushroom maps to the original small-heal
; effect bounded by the genuine initial5HP; flower maps to original sword
; effect6EE1/action91. Star/1up use the genuine native collector unchanged.
PpNativePickup:
 lda $c6cf
 beq PickupDone
 lda PowerUpType,x
 cmp #2
 bcs NativePickup
 lda Enemy_State,x
 bpl PickupDone
 lda PowerUpType,x
 bne Sword
 lda $c6cf
 cmp #5
 bcs Consume
 inc $c6cf
 bne Consume
Sword:
 txa
 pha
 lda #1
 sta $c6ee
 lda #91
 jsr PpSetAction
 pla
 tax
Consume:
 jsr EraseEnemyObject
 lda #6
 jsr SetupFloateyNumber
PickupDone:sec
 rts
PpNativeDeathUpdate:
 ldy #3
 bne NativeGo
NativePickup:
 ldy #2
NativeGo:
 jmp PpNativeCall
NativeLo:.byte <KillPlayer,<NativeDefeat,<NativeDefaultPickup,<NativeDeathUpdate
NativeHi:.byte >KillPlayer,>NativeDefeat,>NativeDefaultPickup,>NativeDeathUpdate
PpAudioEnd:
