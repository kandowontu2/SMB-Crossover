PpNativeSfx=$da71
PpNativeRawSfx=$da71
PpN_5_8710=$a32d
PpN_5_8730=$a34d
PpN_5_88FB=$a3a5
PpN_5_890D=$a3b9
PpN_7_CB05=$a5d1
PpMap5=$b2f9
PpWorldLandingAlign=$c362
PpN_7_D6D8=$aa51
PpMap4=$b2f4
PpN_7_DAFA=$ab1d
PpMap6=$b303
PpN_7_E9A4=$ab57
PpN_7_F109=$ac37
PpN_7_F110=$ac3e
PpN_7_FE44=$b2b5
PpN_7_FE66=$b2d7
.setcpu "6502"
.macpack longbranch
.segment "BATTLE"
.export PpCombatControls
PpCombatControls=PpBattle_7_F090
.export PpOriginalStrike
PpOriginalStrike=PpBattle_4_ACD6
.export PpOriginalIncoming
PpOriginalIncoming=PpBattle_4_ACFA
.export PpBattle_4_ACCD
PpBattle_4_ACCD: ; original4:ACCD 60 RTS
 rts
.export PpBattle_4_ACD6
PpBattle_4_ACD6: ; original4:ACD6 b91606 LDA $0616,Y
 lda $c616,y
.export PpBattle_4_ACD9
PpBattle_4_ACD9: ; original4:ACD9 c94a CMP #$4a
 cmp #$4a
.export PpBattle_4_ACDB
PpBattle_4_ACDB: ; original4:ACDB f0f0 BEQ $accd
 beq PpBattle_4_ACCD
.export PpBattle_4_ACDD
PpBattle_4_ACDD: ; original4:ACDD c945 CMP #$45
 cmp #$45
.export PpBattle_4_ACDF
PpBattle_4_ACDF: ; original4:ACDF f0ec BEQ $accd
 beq PpBattle_4_ACCD
.export PpBattle_4_ACE1
PpBattle_4_ACE1: ; original4:ACE1 b91706 LDA $0617,Y
 lda $c617,y
.export PpBattle_4_ACE4
PpBattle_4_ACE4: ; original4:ACE4 c99a CMP #$9a
 cmp #$9a
.export PpBattle_4_ACE6
PpBattle_4_ACE6: ; original4:ACE6 d0e5 BNE $accd
 bne PpBattle_4_ACCD
.export PpBattle_4_ACE8
PpBattle_4_ACE8: ; original4:ACE8 98 TYA
 tya
.export PpBattle_4_ACE9
PpBattle_4_ACE9: ; original4:ACE9 490e EOR #$0e
 eor #$0e
.export PpBattle_4_ACEB
PpBattle_4_ACEB: ; original4:ACEB a8 TAY
 tay
.export PpBattle_4_ACEC
PpBattle_4_ACEC: ; original4:ACEC b91606 LDA $0616,Y
 lda $c616,y
.export PpBattle_4_ACEF
PpBattle_4_ACEF: ; original4:ACEF c945 CMP #$45
 cmp #$45
.export PpBattle_4_ACF1
PpBattle_4_ACF1: ; original4:ACF1 f004 BEQ $acf7
 beq PpBattle_4_ACF7
.export PpBattle_4_ACF3
PpBattle_4_ACF3: ; original4:ACF3 c93e CMP #$3e
 cmp #$3e
.export PpBattle_4_ACF5
PpBattle_4_ACF5: ; original4:ACF5 d003 BNE $acfa
 bne PpBattle_4_ACFA
.export PpBattle_4_ACF7
PpBattle_4_ACF7: ; original4:ACF7 4c5dfa JMP $fa5d
 jmp PpBattle_7_FA5D
.export PpBattle_4_ACFA
PpBattle_4_ACFA: ; original4:ACFA 20b9db JSR $dbb9
 jsr PpBattle_7_DBB9
.export PpBattle_4_ACFD
PpBattle_4_ACFD: ; original4:ACFD b91606 LDA $0616,Y
 lda $c616,y
.export PpBattle_4_AD00
PpBattle_4_AD00: ; original4:AD00 c94a CMP #$4a
 cmp #$4a
.export PpBattle_4_AD02
PpBattle_4_AD02: ; original4:AD02 f0c9 BEQ $accd
 beq PpBattle_4_ACCD
.export PpBattle_4_AD04
PpBattle_4_AD04: ; original4:AD04 c945 CMP #$45
 cmp #$45
.export PpBattle_4_AD06
PpBattle_4_AD06: ; original4:AD06 f0c5 BEQ $accd
 beq PpBattle_4_ACCD
.export PpBattle_4_AD08
PpBattle_4_AD08: ; original4:AD08 c000 CPY #$00
 cpy #$00
.export PpBattle_4_AD0A
PpBattle_4_AD0A: ; original4:AD0A d007 BNE $ad13
 bne PpBattle_4_AD13
.export PpBattle_4_AD0C
PpBattle_4_AD0C: ; original4:AD0C adee06 LDA $06ee
 lda $c6ee
.export PpBattle_4_AD0F
PpBattle_4_AD0F: ; original4:AD0F c902 CMP #$02
 cmp #$02
.export PpBattle_4_AD11
PpBattle_4_AD11: ; original4:AD11 d003 BNE $ad16
 bne PpBattle_4_AD16
.export PpBattle_4_AD13
PpBattle_4_AD13: ; original4:AD13 4c5ae9 JMP $e95a
 jmp PpBattle_7_E95A
.export PpBattle_4_AD16
PpBattle_4_AD16: ; original4:AD16 20a4e9 JSR $e9a4
 jsr PpN_7_E9A4
.export PpBattle_4_AD19
PpBattle_4_AD19: ; original4:AD19 c000 CPY #$00
 cpy #$00
.export PpBattle_4_AD1B
PpBattle_4_AD1B: ; original4:AD1B f016 BEQ $ad33
 beq PpBattle_4_AD33
.export PpBattle_4_AD1D
PpBattle_4_AD1D: ; original4:AD1D a570 LDA $70
 lda $c070
.export PpBattle_4_AD1F
PpBattle_4_AD1F: ; original4:AD1F c90c CMP #$0c
 cmp #$0c
.export PpBattle_4_AD21
PpBattle_4_AD21: ; original4:AD21 d010 BNE $ad33
 bne PpBattle_4_AD33
.export PpBattle_4_AD23
PpBattle_4_AD23: ; original4:AD23 a914 LDA #$14
 lda #$14
.export PpBattle_4_AD25
PpBattle_4_AD25: ; original4:AD25 8ddc06 STA $06dc
 sta $c6dc
.export PpBattle_4_AD28
PpBattle_4_AD28: ; original4:AD28 a902 LDA #$02
 lda #$02
.export PpBattle_4_AD2A
PpBattle_4_AD2A: ; original4:AD2A 8dd504 STA $04d5
 sta $c4d5
.export PpBattle_4_AD2D
PpBattle_4_AD2D: ; original4:AD2D 20e0fb JSR $fbe0
 jsr PpBattle_7_FBE0
.export PpBattle_4_AD30
PpBattle_4_AD30: ; original4:AD30 4c3dad JMP $ad3d
 jmp PpBattle_4_AD3D
.export PpBattle_4_AD33
PpBattle_4_AD33: ; original4:AD33 adee06 LDA $06ee
 lda $c6ee
.export PpBattle_4_AD36
PpBattle_4_AD36: ; original4:AD36 f005 BEQ $ad3d
 beq PpBattle_4_AD3D
.export PpBattle_4_AD38
PpBattle_4_AD38: ; original4:AD38 a901 LDA #$01
 lda #$01
.export PpBattle_4_AD3A
PpBattle_4_AD3A: ; original4:AD3A 8dee06 STA $06ee
 sta $c6ee
.export PpBattle_4_AD3D
PpBattle_4_AD3D: ; original4:AD3D a900 LDA #$00
 lda #$00
.export PpBattle_4_AD3F
PpBattle_4_AD3F: ; original4:AD3F 8ddb06 STA $06db
 sta $c6db
.export PpBattle_4_AD42
PpBattle_4_AD42: ; original4:AD42 b91106 LDA $0611,Y
 lda $c611,y
.export PpBattle_4_AD45
PpBattle_4_AD45: ; original4:AD45 38 SEC
 sec
.export PpBattle_4_AD46
PpBattle_4_AD46: ; original4:AD46 e920 SBC #$20
 sbc #$20
.export PpBattle_4_AD48
PpBattle_4_AD48: ; original4:AD48 991106 STA $0611,Y
 sta $c611,y
.export PpBattle_4_AD4B
PpBattle_4_AD4B: ; original4:AD4B 2087d4 JSR $d487
 jsr PpWorldLandingAlign
.export PpBattle_4_AD4E
PpBattle_4_AD4E: ; original4:AD4E a955 LDA #$55
 lda #$55
.export PpBattle_4_AD50
PpBattle_4_AD50: ; original4:AD50 9ddd06 STA $06dd,X
 sta $c6dd,x
.export PpBattle_4_AD53
PpBattle_4_AD53: ; original4:AD53 4cddd6 JMP $d6dd
 jmp PpBattle_7_D6DD
.export PpBattle_4_B8D5
PpBattle_4_B8D5: ; original4:B8D5 a900 LDA #$00
 lda #$00
.export PpBattle_4_B8D7
PpBattle_4_B8D7: ; original4:B8D7 8517 STA $17
 sta $c017
.export PpBattle_4_B8D9
PpBattle_4_B8D9: ; original4:B8D9 a617 LDX $17
 ldx $c017
.export PpBattle_4_B8DB
PpBattle_4_B8DB: ; original4:B8DB bd1007 LDA $0710,X
 lda $c710,x
.export PpBattle_4_B8DE
PpBattle_4_B8DE: ; original4:B8DE c551 CMP $51
 cmp $c051
.export PpBattle_4_B8E0
PpBattle_4_B8E0: ; original4:B8E0 f00c BEQ $b8ee
 beq PpBattle_4_B8EE
.export PpBattle_4_B8E2
PpBattle_4_B8E2: ; original4:B8E2 c9ff CMP #$ff
 cmp #$ff
.export PpBattle_4_B8E4
PpBattle_4_B8E4: ; original4:B8E4 d003 BNE $b8e9
 bne PpBattle_4_B8E9
.export PpBattle_4_B8E6
PpBattle_4_B8E6: ; original4:B8E6 68 PLA
 pla
.export PpBattle_4_B8E7
PpBattle_4_B8E7: ; original4:B8E7 68 PLA
 pla
 lda #$e9 ; Original popped return high of7:E982, not relocated address
.export PpBattle_4_B8E8
PpBattle_4_B8E8: ; original4:B8E8 60 RTS
 rts
.export PpBattle_4_B8E9
PpBattle_4_B8E9: ; original4:B8E9 e8 INX
 inx
.export PpBattle_4_B8EA
PpBattle_4_B8EA: ; original4:B8EA e8 INX
 inx
.export PpBattle_4_B8EB
PpBattle_4_B8EB: ; original4:B8EB 4cdbb8 JMP $b8db
 jmp PpBattle_4_B8DB
.export PpBattle_4_B8EE
PpBattle_4_B8EE: ; original4:B8EE 60 RTS
 rts
.export PpBattle_5_88AC
PpBattle_5_88AC: ; original5:88AC a226 LDX #$26
 ldx #$26
.export PpBattle_5_88AE
PpBattle_5_88AE: ; original5:88AE ad1506 LDA $0615
 lda $c615
.export PpBattle_5_88B1
PpBattle_5_88B1: ; original5:88B1 d002 BNE $88b5
 bne PpBattle_5_88B5
.export PpBattle_5_88B3
PpBattle_5_88B3: ; original5:88B3 a220 LDX #$20
 ldx #$20
.export PpBattle_5_88B5
PpBattle_5_88B5: ; original5:88B5 8647 STX $47
 stx $c047
.export PpBattle_5_88B7
PpBattle_5_88B7: ; original5:88B7 adee06 LDA $06ee
 lda $c6ee
.export PpBattle_5_88BA
PpBattle_5_88BA: ; original5:88BA c902 CMP #$02
 cmp #$02
.export PpBattle_5_88BC
PpBattle_5_88BC: ; original5:88BC f00b BEQ $88c9
 beq PpBattle_5_88C9
.export PpBattle_5_88BE
PpBattle_5_88BE: ; original5:88BE ad1606 LDA $0616
 lda $c616
.export PpBattle_5_88C1
PpBattle_5_88C1: ; original5:88C1 c904 CMP #$04
 cmp #$04
.export PpBattle_5_88C3
PpBattle_5_88C3: ; original5:88C3 d004 BNE $88c9
 bne PpBattle_5_88C9
.export PpBattle_5_88C5
PpBattle_5_88C5: ; original5:88C5 a930 LDA #$30
 lda #$30
.export PpBattle_5_88C7
PpBattle_5_88C7: ; original5:88C7 8547 STA $47
 sta $c047
.export PpBattle_5_88C9
PpBattle_5_88C9: ; original5:88C9 ad1006 LDA $0610
 lda $c610
.export PpBattle_5_88CC
PpBattle_5_88CC: ; original5:88CC cd1e06 CMP $061e
 cmp $c61e
.export PpBattle_5_88CF
PpBattle_5_88CF: ; original5:88CF d006 BNE $88d7
 bne PpBattle_5_88D7
.export PpBattle_5_88D1
PpBattle_5_88D1: ; original5:88D1 ad0f06 LDA $060f
 lda $c60f
.export PpBattle_5_88D4
PpBattle_5_88D4: ; original5:88D4 cd1d06 CMP $061d
 cmp $c61d
.export PpBattle_5_88D7
PpBattle_5_88D7: ; original5:88D7 b014 BCS $88ed
 bcs PpBattle_5_88ED
.export PpBattle_5_88D9
PpBattle_5_88D9: ; original5:88D9 ad1d06 LDA $061d
 lda $c61d
.export PpBattle_5_88DC
PpBattle_5_88DC: ; original5:88DC 38 SEC
 sec
.export PpBattle_5_88DD
PpBattle_5_88DD: ; original5:88DD ed0f06 SBC $060f
 sbc $c60f
.export PpBattle_5_88E0
PpBattle_5_88E0: ; original5:88E0 8517 STA $17
 sta $c017
.export PpBattle_5_88E2
PpBattle_5_88E2: ; original5:88E2 ad1e06 LDA $061e
 lda $c61e
.export PpBattle_5_88E5
PpBattle_5_88E5: ; original5:88E5 ed1006 SBC $0610
 sbc $c610
.export PpBattle_5_88E8
PpBattle_5_88E8: ; original5:88E8 8518 STA $18
 sta $c018
.export PpBattle_5_88EA
PpBattle_5_88EA: ; original5:88EA 4cf088 JMP $88f0
 jmp PpBattle_5_88F0
.export PpBattle_5_88ED
PpBattle_5_88ED: ; original5:88ED 20fb88 JSR $88fb
 jsr PpN_5_88FB
.export PpBattle_5_88F0
PpBattle_5_88F0: ; original5:88F0 a518 LDA $18
 lda $c018
.export PpBattle_5_88F2
PpBattle_5_88F2: ; original5:88F2 d005 BNE $88f9
 bne PpBattle_5_88F9
.export PpBattle_5_88F4
PpBattle_5_88F4: ; original5:88F4 a517 LDA $17
 lda $c017
.export PpBattle_5_88F6
PpBattle_5_88F6: ; original5:88F6 c547 CMP $47
 cmp $c047
.export PpBattle_5_88F8
PpBattle_5_88F8: ; original5:88F8 60 RTS
 rts
.export PpBattle_5_88F9
PpBattle_5_88F9: ; original5:88F9 38 SEC
 sec
.export PpBattle_5_88FA
PpBattle_5_88FA: ; original5:88FA 60 RTS
 rts
.export PpBattle_5_8943
PpBattle_5_8943: ; original5:8943 ad1606 LDA $0616
 lda $c616
.export PpBattle_5_8946
PpBattle_5_8946: ; original5:8946 c938 CMP #$38
 cmp #$38
.export PpBattle_5_8948
PpBattle_5_8948: ; original5:8948 f01c BEQ $8966
 beq PpBattle_5_8966
.export PpBattle_5_894A
PpBattle_5_894A: ; original5:894A c93a CMP #$3a
 cmp #$3a
.export PpBattle_5_894C
PpBattle_5_894C: ; original5:894C f018 BEQ $8966
 beq PpBattle_5_8966
.export PpBattle_5_894E
PpBattle_5_894E: ; original5:894E 2044fe JSR $fe44
 jsr PpN_7_FE44
.export PpBattle_5_8951
PpBattle_5_8951: ; original5:8951 d014 BNE $8967
 bne PpBattle_5_8967
.export PpBattle_5_8953
PpBattle_5_8953: ; original5:8953 a53b LDA $3b
 lda $c03b
.export PpBattle_5_8955
PpBattle_5_8955: ; original5:8955 f00f BEQ $8966
 beq PpBattle_5_8966
.export PpBattle_5_8957
PpBattle_5_8957: ; original5:8957 20b9db JSR $dbb9
 jsr PpBattle_7_DBB9
.export PpBattle_5_895A
PpBattle_5_895A: ; original5:895A ad0a04 LDA $040a
 lda $c40a
.export PpBattle_5_895D
PpBattle_5_895D: ; original5:895D 2980 AND #$80
 and #$80
.export PpBattle_5_895F
PpBattle_5_895F: ; original5:895F d005 BNE $8966
 bne PpBattle_5_8966
.export PpBattle_5_8961
PpBattle_5_8961: ; original5:8961 a939 LDA #$39
 lda #$39
.export PpBattle_5_8963
PpBattle_5_8963: ; original5:8963 20d8d6 JSR $d6d8
 jsr PpN_7_D6D8
.export PpBattle_5_8966
PpBattle_5_8966: ; original5:8966 60 RTS
 rts
.export PpBattle_5_8967
PpBattle_5_8967: ; original5:8967 a939 LDA #$39
 lda #$39
.export PpBattle_5_8969
PpBattle_5_8969: ; original5:8969 8d1606 STA $0616
 sta $c616
.export PpBattle_5_896C
PpBattle_5_896C: ; original5:896C 2087d4 JSR $d487
 jsr PpWorldLandingAlign
.export PpBattle_5_896F
PpBattle_5_896F: ; original5:896F 4cfada JMP $dafa
 jmp PpN_7_DAFA
.export PpBattle_5_8972
PpBattle_5_8972: ; original5:8972 20ac88 JSR $88ac
 jsr PpBattle_5_88AC
.export PpBattle_5_8975
PpBattle_5_8975: ; original5:8975 9013 BCC $898a
 bcc PpBattle_5_898A
.export PpBattle_5_8977
PpBattle_5_8977: ; original5:8977 a53a LDA $3a
 lda $c03a
.export PpBattle_5_8979
PpBattle_5_8979: ; original5:8979 f00f BEQ $898a
 beq PpBattle_5_898A
.export PpBattle_5_897B
PpBattle_5_897B: ; original5:897B 20b9db JSR $dbb9
 jsr PpBattle_7_DBB9
.export PpBattle_5_897E
PpBattle_5_897E: ; original5:897E ad1606 LDA $0616
 lda $c616
.export PpBattle_5_8981
PpBattle_5_8981: ; original5:8981 c93a CMP #$3a
 cmp #$3a
.export PpBattle_5_8983
PpBattle_5_8983: ; original5:8983 f005 BEQ $898a
 beq PpBattle_5_898A
.export PpBattle_5_8985
PpBattle_5_8985: ; original5:8985 a938 LDA #$38
 lda #$38
.export PpBattle_5_8987
PpBattle_5_8987: ; original5:8987 20d8d6 JSR $d6d8
 jsr PpN_7_D6D8
.export PpBattle_5_898A
PpBattle_5_898A: ; original5:898A 60 RTS
 rts
.export PpBattle_5_898B
PpBattle_5_898B: ; original5:898B adde06 LDA $06de
 lda $c6de
.export PpBattle_5_898E
PpBattle_5_898E: ; original5:898E d014 BNE $89a4
 bne PpBattle_5_89A4
.export PpBattle_5_8990
PpBattle_5_8990: ; original5:8990 c90f CMP #$0f
 cmp #$0f
.export PpBattle_5_8992
PpBattle_5_8992: ; original5:8992 adee06 LDA $06ee
 lda $c6ee
.export PpBattle_5_8995
PpBattle_5_8995: ; original5:8995 c901 CMP #$01
 cmp #$01
.export PpBattle_5_8997
PpBattle_5_8997: ; original5:8997 d00b BNE $89a4
 bne PpBattle_5_89A4
.export PpBattle_5_8999
PpBattle_5_8999: ; original5:8999 eeee06 INC $06ee
 inc $c6ee
.export PpBattle_5_899C
PpBattle_5_899C: ; original5:899C a937 LDA #$37
 lda #$37
.export PpBattle_5_899E
PpBattle_5_899E: ; original5:899E 203087 JSR $8730
 jsr PpN_5_8730
.export PpBattle_5_89A1
PpBattle_5_89A1: ; original5:89A1 2087d4 JSR $d487
 jsr PpWorldLandingAlign
.export PpBattle_5_89A4
PpBattle_5_89A4: ; original5:89A4 60 RTS
 rts
.export PpBattle_5_8AE9
PpBattle_5_8AE9: ; original5:8AE9 b91706 LDA $0617,Y
 lda $c617,y
.export PpBattle_5_8AEC
PpBattle_5_8AEC: ; original5:8AEC c9ab CMP #$ab
 cmp #$ab
.export PpBattle_5_8AEE
PpBattle_5_8AEE: ; original5:8AEE d005 BNE $8af5
 bne PpBattle_5_8AF5
.export PpBattle_5_8AF0
PpBattle_5_8AF0: ; original5:8AF0 adde06 LDA $06de
 lda $c6de
.export PpBattle_5_8AF3
PpBattle_5_8AF3: ; original5:8AF3 d001 BNE $8af6
 bne PpBattle_5_8AF6
.export PpBattle_5_8AF5
PpBattle_5_8AF5: ; original5:8AF5 60 RTS
 rts
.export PpBattle_5_8AF6
PpBattle_5_8AF6: ; original5:8AF6 c000 CPY #$00
 cpy #$00
.export PpBattle_5_8AF8
PpBattle_5_8AF8: ; original5:8AF8 d005 BNE $8aff
 bne PpBattle_5_8AFF
.export PpBattle_5_8AFA
PpBattle_5_8AFA: ; original5:8AFA a901 LDA #$01
 lda #$01
.export PpBattle_5_8AFC
PpBattle_5_8AFC: ; original5:8AFC 8dee06 STA $06ee
 sta $c6ee
.export PpBattle_5_8AFF
PpBattle_5_8AFF: ; original5:8AFF a95d LDA #$5d
 lda #$5d
.export PpBattle_5_8B01
PpBattle_5_8B01: ; original5:8B01 4c3087 JMP $8730
 jmp PpN_5_8730
.export PpBattle_7_D6DD
PpBattle_7_D6DD: ; original7:D6DD 2005cb JSR $cb05
 jsr PpN_7_CB05
.export PpBattle_7_D6E0
PpBattle_7_D6E0: ; original7:D6E0 4cfcd8 JMP $d8fc
 jmp PpMap4
.export PpBattle_7_DBB9
PpBattle_7_DBB9: ; original7:DBB9 b91706 LDA $0617,Y
 lda $c617,y
.export PpBattle_7_DBBC
PpBattle_7_DBBC: ; original7:DBBC c000 CPY #$00
 cpy #$00
.export PpBattle_7_DBBE
PpBattle_7_DBBE: ; original7:DBBE f004 BEQ $dbc4
 beq PpBattle_7_DBC4
.export PpBattle_7_DBC0
PpBattle_7_DBC0: ; original7:DBC0 c9ab CMP #$ab
 cmp #$ab
.export PpBattle_7_DBC2
PpBattle_7_DBC2: ; original7:DBC2 f004 BEQ $dbc8
 beq PpBattle_7_DBC8
.export PpBattle_7_DBC4
PpBattle_7_DBC4: ; original7:DBC4 c9aa CMP #$aa
 cmp #$aa
.export PpBattle_7_DBC6
PpBattle_7_DBC6: ; original7:DBC6 d005 BNE $dbcd
 bne PpBattle_7_DBCD
.export PpBattle_7_DBC8
PpBattle_7_DBC8: ; original7:DBC8 a900 LDA #$00
 lda #$00
.export PpBattle_7_DBCA
PpBattle_7_DBCA: ; original7:DBCA 991606 STA $0616,Y
 sta $c616,y
.export PpBattle_7_DBCD
PpBattle_7_DBCD: ; original7:DBCD 60 RTS
 rts
.export PpBattle_7_E95A
PpBattle_7_E95A: ; original7:E95A 98 TYA
 tya
.export PpBattle_7_E95B
PpBattle_7_E95B: ; original7:E95B 48 PHA
 pha
.export PpBattle_7_E95C
PpBattle_7_E95C: ; original7:E95C a900 LDA #$00
 lda #$00
.export PpBattle_7_E95E
PpBattle_7_E95E: ; original7:E95E a20c LDX #$0c
 ldx #$0c
.export PpBattle_7_E960
PpBattle_7_E960: ; original7:E960 c00e CPY #$0e
 cpy #$0e
.export PpBattle_7_E962
PpBattle_7_E962: ; original7:E962 d003 BNE $e967
 bne PpBattle_7_E967
.export PpBattle_7_E964
PpBattle_7_E964: ; original7:E964 a903 LDA #$03
 lda #$03
.export PpBattle_7_E966
PpBattle_7_E966: ; original7:E966 e8 INX
 inx
.export PpBattle_7_E967
PpBattle_7_E967: ; original7:E967 8dd504 STA $04d5
 sta $c4d5
.export PpBattle_7_E96A
PpBattle_7_E96A: ; original7:E96A a9ff LDA #$ff
 lda #$ff
.export PpBattle_7_E96C
PpBattle_7_E96C: ; original7:E96C 20ced6 JSR $d6ce
 jsr PpNativeSfx
.export PpBattle_7_E96F
PpBattle_7_E96F: ; original7:E96F 68 PLA
 pla
.export PpBattle_7_E970
PpBattle_7_E970: ; original7:E970 a8 TAY
 tay
.export PpBattle_7_E971
PpBattle_7_E971: ; original7:E971 2010d0 JSR $d010
 jsr PpMap5
.export PpBattle_7_E974
PpBattle_7_E974: ; original7:E974 201087 JSR $8710
 jsr PpN_5_8710
.export PpBattle_7_E977
PpBattle_7_E977: ; original7:E977 9025 BCC $e99e
 bcc PpBattle_7_E99E
.export PpBattle_7_E979
PpBattle_7_E979: ; original7:E979 c000 CPY #$00
 cpy #$00
.export PpBattle_7_E97B
PpBattle_7_E97B: ; original7:E97B f01c BEQ $e999
 beq PpBattle_7_E999
.export PpBattle_7_E97D
PpBattle_7_E97D: ; original7:E97D 8441 STY $41
 sty $c041
.export PpBattle_7_E97F
PpBattle_7_E97F: ; original7:E97F 20fcd8 JSR $d8fc
 jsr PpMap4
.export PpBattle_7_E982
PpBattle_7_E982: ; original7:E982 20d5b8 JSR $b8d5
 jsr PpBattle_4_B8D5
.export PpBattle_7_E985
PpBattle_7_E985: ; original7:E985 a441 LDY $41
 ldy $c041
.export PpBattle_7_E987
PpBattle_7_E987: ; original7:E987 b91506 LDA $0615,Y
 lda $c615,y
.export PpBattle_7_E98A
PpBattle_7_E98A: ; original7:E98A 2980 AND #$80
 and #$80
.export PpBattle_7_E98C
PpBattle_7_E98C: ; original7:E98C 4a LSR A
 lsr a
.export PpBattle_7_E98D
PpBattle_7_E98D: ; original7:E98D 0980 ORA #$80
 ora #$80
.export PpBattle_7_E98F
PpBattle_7_E98F: ; original7:E98F 8517 STA $17
 sta $c017
.export PpBattle_7_E991
PpBattle_7_E991: ; original7:E991 bd1107 LDA $0711,X
 lda $c711,x
.export PpBattle_7_E994
PpBattle_7_E994: ; original7:E994 0517 ORA $17
 ora $c017
.export PpBattle_7_E996
PpBattle_7_E996: ; original7:E996 9d1107 STA $0711,X
 sta $c711,x
.export PpBattle_7_E999
PpBattle_7_E999: ; original7:E999 a94a LDA #$4a
 lda #$4a
.export PpBattle_7_E99B
PpBattle_7_E99B: ; original7:E99B 4cddd6 JMP $d6dd
 jmp PpBattle_7_D6DD
.export PpBattle_7_E99E
PpBattle_7_E99E: ; original7:E99E 20fcd8 JSR $d8fc
 jsr PpMap4
.export PpBattle_7_E9A1
PpBattle_7_E9A1: ; original7:E9A1 4c19ad JMP $ad19
 jmp PpBattle_4_AD19
.export PpBattle_7_F090
PpBattle_7_F090: ; original7:F090 ad1506 LDA $0615
 lda $c615
.export PpBattle_7_F093
PpBattle_7_F093: ; original7:F093 cd2306 CMP $0623
 cmp $c623
.export PpBattle_7_F096
PpBattle_7_F096: ; original7:F096 d003 BNE $f09b
 bne PpBattle_7_F09B
.export PpBattle_7_F098
PpBattle_7_F098: ; original7:F098 4c10f1 JMP $f110
 jmp PpN_7_F110
.export PpBattle_7_F09B
PpBattle_7_F09B: ; original7:F09B a000 LDY #$00
 ldy #$00
.export PpBattle_7_F09D
PpBattle_7_F09D: ; original7:F09D 20b9db JSR $dbb9
 jsr PpBattle_7_DBB9
.export PpBattle_7_F0A0
PpBattle_7_F0A0: ; original7:F0A0 ad1606 LDA $0616
 lda $c616
.export PpBattle_7_F0A3
PpBattle_7_F0A3: ; original7:F0A3 c937 CMP #$37
 cmp #$37
.export PpBattle_7_F0A5
PpBattle_7_F0A5: ; original7:F0A5 f069 BEQ $f110
 jeq PpN_7_F110
.export PpBattle_7_F0A7
PpBattle_7_F0A7: ; original7:F0A7 c94a CMP #$4a
 cmp #$4a
.export PpBattle_7_F0A9
PpBattle_7_F0A9: ; original7:F0A9 f065 BEQ $f110
 jeq PpN_7_F110
.export PpBattle_7_F0AB
PpBattle_7_F0AB: ; original7:F0AB adee06 LDA $06ee
 lda $c6ee
.export PpBattle_7_F0AE
PpBattle_7_F0AE: ; original7:F0AE c902 CMP #$02
 cmp #$02
.export PpBattle_7_F0B0
PpBattle_7_F0B0: ; original7:F0B0 f008 BEQ $f0ba
 beq PpBattle_7_F0BA
.export PpBattle_7_F0B2
PpBattle_7_F0B2: ; original7:F0B2 2010d0 JSR $d010
 jsr PpMap5
.export PpBattle_7_F0B5
PpBattle_7_F0B5: ; original7:F0B5 200d89 JSR $890d
 jsr PpN_5_890D
.export PpBattle_7_F0B8
PpBattle_7_F0B8: ; original7:F0B8 b056 BCS $f110
 jcs PpN_7_F110
.export PpBattle_7_F0BA
PpBattle_7_F0BA: ; original7:F0BA adee06 LDA $06ee
 lda $c6ee
.export PpBattle_7_F0BD
PpBattle_7_F0BD: ; original7:F0BD f051 BEQ $f110
 jeq PpN_7_F110
.export PpBattle_7_F0BF
PpBattle_7_F0BF: ; original7:F0BF a000 LDY #$00
 ldy #$00
.export PpBattle_7_F0C1
PpBattle_7_F0C1: ; original7:F0C1 20e98a JSR $8ae9
 jsr PpBattle_5_8AE9
.export PpBattle_7_F0C4
PpBattle_7_F0C4: ; original7:F0C4 2009f1 JSR $f109
 jsr PpN_7_F109
.export PpBattle_7_F0C7
PpBattle_7_F0C7: ; original7:F0C7 c9e2 CMP #$e2
 cmp #$e2
.export PpBattle_7_F0C9
PpBattle_7_F0C9: ; original7:F0C9 b004 BCS $f0cf
 bcs PpBattle_7_F0CF
.export PpBattle_7_F0CB
PpBattle_7_F0CB: ; original7:F0CB c91e CMP #$1e
 cmp #$1e
.export PpBattle_7_F0CD
PpBattle_7_F0CD: ; original7:F0CD b041 BCS $f110
 jcs PpN_7_F110
.export PpBattle_7_F0CF
PpBattle_7_F0CF: ; original7:F0CF ade006 LDA $06e0
 lda $c6e0
.export PpBattle_7_F0D2
PpBattle_7_F0D2: ; original7:F0D2 f03c BEQ $f110
 jeq PpN_7_F110
.export PpBattle_7_F0D4
PpBattle_7_F0D4: ; original7:F0D4 ad0104 LDA $0401
 lda $c401
.export PpBattle_7_F0D7
PpBattle_7_F0D7: ; original7:F0D7 d037 BNE $f110
 jne PpN_7_F110
.export PpBattle_7_F0D9
PpBattle_7_F0D9: ; original7:F0D9 208b89 JSR $898b
 jsr PpBattle_5_898B
.export PpBattle_7_F0DC
PpBattle_7_F0DC: ; original7:F0DC adee06 LDA $06ee
 lda $c6ee
.export PpBattle_7_F0DF
PpBattle_7_F0DF: ; original7:F0DF c902 CMP #$02
 cmp #$02
.export PpBattle_7_F0E1
PpBattle_7_F0E1: ; original7:F0E1 d02d BNE $f110
 jne PpN_7_F110
.export PpBattle_7_F0E3
PpBattle_7_F0E3: ; original7:F0E3 adde06 LDA $06de
 lda $c6de
.export PpBattle_7_F0E6
PpBattle_7_F0E6: ; original7:F0E6 d028 BNE $f110
 jne PpN_7_F110
.export PpBattle_7_F0E8
PpBattle_7_F0E8: ; original7:F0E8 a8 TAY
 tay
.export PpBattle_7_F0E9
PpBattle_7_F0E9: ; original7:F0E9 2067fe JSR $fe67
 jsr PpBattle_7_FE67
.export PpBattle_7_F0EC
PpBattle_7_F0EC: ; original7:F0EC 207afe JSR $fe7a
 jsr PpBattle_7_FE7A
.export PpBattle_7_F0EF
PpBattle_7_F0EF: ; original7:F0EF 207289 JSR $8972
 jsr PpBattle_5_8972
.export PpBattle_7_F0F2
PpBattle_7_F0F2: ; original7:F0F2 204389 JSR $8943
 jsr PpBattle_5_8943
.export PpBattle_7_F0F5
PpBattle_7_F0F5: ; original7:F0F5 2051fa JSR $fa51
 jsr PpBattle_7_FA51
.export PpBattle_7_F0F8
PpBattle_7_F0F8: ; original7:F0F8 b016 BCS $f110
 jcs PpN_7_F110
.export PpBattle_7_F0FA
PpBattle_7_F0FA: ; original7:F0FA 20fcd8 JSR $d8fc
 jsr PpMap4
.export PpBattle_7_F0FD
PpBattle_7_F0FD: ; original7:F0FD ad2406 LDA $0624
 lda $c624
.export PpBattle_7_F100
PpBattle_7_F100: ; original7:F100 c938 CMP #$38
 cmp #$38
.export PpBattle_7_F102
PpBattle_7_F102: ; original7:F102 f00c BEQ $f110
 jeq PpN_7_F110
.export PpBattle_7_F104
PpBattle_7_F104: ; original7:F104 a000 LDY #$00
 ldy #$00
.export PpBattle_7_F106
PpBattle_7_F106: ; original7:F106 4cd6ac JMP $acd6
 jmp PpBattle_4_ACD6
.export PpBattle_7_FA51
PpBattle_7_FA51: ; original7:FA51 2010d0 JSR $d010
 jsr PpMap5
.export PpBattle_7_FA54
PpBattle_7_FA54: ; original7:FA54 20ac88 JSR $88ac
 jsr PpBattle_5_88AC
.export PpBattle_7_FA57
PpBattle_7_FA57: ; original7:FA57 48 PHA
 pha
.export PpBattle_7_FA58
PpBattle_7_FA58: ; original7:FA58 20fcd8 JSR $d8fc
 jsr PpMap4
.export PpBattle_7_FA5B
PpBattle_7_FA5B: ; original7:FA5B 68 PLA
 pla
.export PpBattle_7_FA5C
PpBattle_7_FA5C: ; original7:FA5C 60 RTS
 rts
.export PpBattle_7_FA5D
PpBattle_7_FA5D: ; original7:FA5D 4c3ffc JMP $fc3f
 jmp PpBattle_7_FC3F
.export PpBattle_7_FBE0
PpBattle_7_FBE0: ; original7:FBE0 a920 LDA #$20
 lda #$20
.export PpBattle_7_FBE2
PpBattle_7_FBE2: ; original7:FBE2 8de406 STA $06e4
 sta $c6e4
.export PpBattle_7_FBE5
PpBattle_7_FBE5: ; original7:FBE5 a900 LDA #$00
 lda #$00
.export PpBattle_7_FBE7
PpBattle_7_FBE7: ; original7:FBE7 8de606 STA $06e6
 sta $c6e6
.export PpBattle_7_FBEA
PpBattle_7_FBEA: ; original7:FBEA a932 LDA #$32
 lda #$32
.export PpBattle_7_FBEC
PpBattle_7_FBEC: ; original7:FBEC 8de506 STA $06e5
 sta $c6e5
.export PpBattle_7_FBEF
PpBattle_7_FBEF: ; original7:FBEF a922 LDA #$22
 lda #$22
.export PpBattle_7_FBF1
PpBattle_7_FBF1: ; original7:FBF1 8d0004 STA $0400
 sta $c400
.export PpBattle_7_FBF4
PpBattle_7_FBF4: ; original7:FBF4 8df706 STA $06f7
 sta $c6f7
.export PpBattle_7_FBF7
PpBattle_7_FBF7: ; original7:FBF7 ad0704 LDA $0407
 lda $c407
.export PpBattle_7_FBFA
PpBattle_7_FBFA: ; original7:FBFA f005 BEQ $fc01
 beq PpBattle_7_FC01
.export PpBattle_7_FBFC
PpBattle_7_FBFC: ; original7:FBFC a902 LDA #$02
 lda #$02
.export PpBattle_7_FBFE
PpBattle_7_FBFE: ; original7:FBFE 8df606 STA $06f6
 sta $c6f6
.export PpBattle_7_FC01
PpBattle_7_FC01: ; original7:FC01 60 RTS
 rts
.export PpBattle_7_FC2A
PpBattle_7_FC2A: ; original7:FC2A 20e1e0 JSR $e0e1
 jsr PpMap6
.export PpBattle_7_FC2D
PpBattle_7_FC2D: ; original7:FC2D a204 LDX #$04
 ldx #$04
.export PpBattle_7_FC2F
PpBattle_7_FC2F: ; original7:FC2F a900 LDA #$00
 lda #$00
.export PpBattle_7_FC31
PpBattle_7_FC31: ; original7:FC31 8554 STA $54
 sta $c054
.export PpBattle_7_FC33
PpBattle_7_FC33: ; original7:FC33 a9ff LDA #$ff
 lda #$ff
.export PpBattle_7_FC35
PpBattle_7_FC35: ; original7:FC35 2013aa JSR $aa13
 jsr PpNativeRawSfx
.export PpBattle_7_FC38
PpBattle_7_FC38: ; original7:FC38 a9ff LDA #$ff
 lda #$ff
.export PpBattle_7_FC3A
PpBattle_7_FC3A: ; original7:FC3A a205 LDX #$05
 ldx #$05
.export PpBattle_7_FC3C
PpBattle_7_FC3C: ; original7:FC3C 4c13aa JMP $aa13
 jmp PpNativeRawSfx
.export PpBattle_7_FC3F
PpBattle_7_FC3F: ; original7:FC3F 202afc JSR $fc2a
 jsr PpBattle_7_FC2A
.export PpBattle_7_FC42
PpBattle_7_FC42: ; original7:FC42 4cfcd8 JMP $d8fc
 jmp PpMap4
.export PpBattle_7_FE67
PpBattle_7_FE67: ; original7:FE67 ad0a04 LDA $040a
 lda $c40a
.export PpBattle_7_FE6A
PpBattle_7_FE6A: ; original7:FE6A 2980 AND #$80
 and #$80
.export PpBattle_7_FE6C
PpBattle_7_FE6C: ; original7:FE6C f0f8 BEQ $fe66
 jeq PpN_7_FE66
.export PpBattle_7_FE6E
PpBattle_7_FE6E: ; original7:FE6E ad1606 LDA $0616
 lda $c616
.export PpBattle_7_FE71
PpBattle_7_FE71: ; original7:FE71 c943 CMP #$43
 cmp #$43
.export PpBattle_7_FE73
PpBattle_7_FE73: ; original7:FE73 f0f1 BEQ $fe66
 jeq PpN_7_FE66
.export PpBattle_7_FE75
PpBattle_7_FE75: ; original7:FE75 a93a LDA #$3a
 lda #$3a
.export PpBattle_7_FE77
PpBattle_7_FE77: ; original7:FE77 4cd8d6 JMP $d6d8
 jmp PpN_7_D6D8
.export PpBattle_7_FE7A
PpBattle_7_FE7A: ; original7:FE7A ad0a04 LDA $040a
 lda $c40a
.export PpBattle_7_FE7D
PpBattle_7_FE7D: ; original7:FE7D 2940 AND #$40
 and #$40
.export PpBattle_7_FE7F
PpBattle_7_FE7F: ; original7:FE7F f0e5 BEQ $fe66
 jeq PpN_7_FE66
.export PpBattle_7_FE81
PpBattle_7_FE81: ; original7:FE81 20b9db JSR $dbb9
 jsr PpBattle_7_DBB9
.export PpBattle_7_FE84
PpBattle_7_FE84: ; original7:FE84 c9ab CMP #$ab
 cmp #$ab
.export PpBattle_7_FE86
PpBattle_7_FE86: ; original7:FE86 d0de BNE $fe66
 jne PpN_7_FE66
.export PpBattle_7_FE88
PpBattle_7_FE88: ; original7:FE88 a93e LDA #$3e
 lda #$3e
.export PpBattle_7_FE8A
PpBattle_7_FE8A: ; original7:FE8A 4cd8d6 JMP $d6d8
 jmp PpN_7_D6D8
