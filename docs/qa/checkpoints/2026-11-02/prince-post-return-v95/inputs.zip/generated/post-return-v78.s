.setcpu "6502"
.segment "FIRST"
.export PrPostWeapon,PrPostWeaponEnd,PrPostClassify,PrPostClassifyEnd
PrPostWeapon:
 sta $016a
 .byte $90,<(Done-(*+1)) ; BCC to the linked second fragment, same bank.
 php
 lda $6002
 cmp #38
 jmp PrPostClassify
PrPostWeaponEnd:
.segment "SECOND"
PrPostClassify:
 beq Own
 lda $016a
 plp
Done:rts
Own:plp
 jmp $97d6
PrPostClassifyEnd:
