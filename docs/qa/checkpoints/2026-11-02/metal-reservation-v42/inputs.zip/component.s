ObjectOffset=$000d
Enemy_X_Position=$0076
Enemy_PageLoc=$005d
Enemy_Y_Position=$00be
Enemy_Y_HighPos=$00a5
HandleEnemyFBallCol=$9a8f
MS25_NATIVE_PICKUP_BANK=131
MarioSourcePowerupCollision=$af71
InvPickupSaveHi=$7d7a
InvPickupSaveLo=$7d74
InvRisePhase=$7d68
InvPickup=$7d62
InvPickupOwner=$7d6e
SetupFloateyNumber=$98b5
EraseEnemyObject=$8d2f
Sfx_PowerUpGrab=$0020
Square2SoundQueue=$0104
PlayerStatus=$075b
PowerUpType=$0034
Enemy_State=$001f
Enemy_ID=$0017
Enemy_Flag=$0010
BlockBufferColli_Head=$9587
BlockBufferColli_Side=$958b
BackgroundColorCtrl=$0747
AreaType=$0753
.define CurrentPlayer Ms12Host_CurrentPlayer
.define NumberofLives Ms12Host_NumberofLives
.define Player_Pos_ForScroll Ms12Host_Player_Pos_ForScroll
.define Player_X_Scroll Ms12Host_Player_X_Scroll
.define Player_X_Speed Ms12Host_Player_X_Speed
.define Player_XSpeedAbsolute Ms12Host_Player_XSpeedAbsolute
.define Player_Y_Speed Ms12Host_Player_Y_Speed
.define Player_State Ms12Host_Player_State
.define PlayerSize Ms12Host_PlayerSize
.define CrouchingFlag Ms12Host_CrouchingFlag
.define PlayerFacingDir Ms12Host_PlayerFacingDir
.define Player_BoundBoxCtrl Ms12Host_Player_BoundBoxCtrl
.setcpu "6502"
.macpack longbranch
.define SelectedCharacter Ms11Host_SelectedCharacter
.define SavedJoypadBits Ms11Host_SavedJoypadBits
.define FrameCounter Ms11Host_FrameCounter
.define GamePauseStatus Ms11Host_GamePauseStatus
.define OperMode Ms11Host_OperMode
.define GameEngineSubroutine Ms11Host_GameEngineSubroutine
.define CrossoverMenuIndex Ms11Host_CrossoverMenuIndex
.define FmAlts Ms11Host_FmAlts
.define Block_Buffer_1 Ms11Host_Block_Buffer_1
.define BlockBufferAddr Ms11Host_BlockBufferAddr
.define MTileAttribute Ms11Host_MTileAttribute
.define Player_X_Position Ms11Host_Player_X_Position
.define Player_PageLoc Ms11Host_Player_PageLoc
.define Player_Y_Position Ms11Host_Player_Y_Position
.define Player_Y_HighPos Ms11Host_Player_Y_HighPos
.define MetaspriteRenderLoop Ms11Host_MetaspriteRenderLoop
.define X5SetPhysicalChr Ms11Host_X5SetPhysicalChr
.define FarCallCommon Ms11Host_FarCallCommon
.define SafecallA_SMC Ms11Host_SafecallA_SMC
.define FarcallJmpTarget_SMC Ms11Host_FarcallJmpTarget_SMC
.define CurrentBank Ms11Host_CurrentBank
.define CurrentBankC Ms11Host_CurrentBankC
.define ScreenLeft_X_Pos Ms11Host_ScreenLeft_X_Pos
.define ScreenLeft_PageLoc Ms11Host_ScreenLeft_PageLoc
.define Player_SprAttrib Ms11Host_Player_SprAttrib
.define CurrentOAMOffset Ms11Host_CurrentOAMOffset
.define SsChrActive Ms11Host_SsChrActive
.define VRAM_Buffer1 Ms11Host_VRAM_Buffer1
.define VRAM_Buffer1_Offset Ms11Host_VRAM_Buffer1_Offset
.define ObjectMetasprite Ms11Host_ObjectMetasprite
.define SmPosePtr Ms11Host_SmPosePtr
.define R0 Ms11Host_R0
.define R1 Ms11Host_R1
.define R2 Ms11Host_R2
.define R3 Ms11Host_R3
.define R4 Ms11Host_R4
.define R5 Ms11Host_R5
.define R6 Ms11Host_R6
.define R7 Ms11Host_R7
.define FamilyMainCommit Ms11Host_FamilyMainCommit
.define DisableScreenFlag Ms11Host_DisableScreenFlag
.define Mirror_PPUMASK Ms11Host_Mirror_PPUMASK
.define Mirror_PPUCTRL Ms11Host_Mirror_PPUCTRL
.define NmiDisable Ms11Host_NmiDisable
.define HorizontalScroll Ms11Host_HorizontalScroll
.define VerticalScroll Ms11Host_VerticalScroll
.define NextBank_SMC Ms11Host_NextBank_SMC
.define SafereturnA_SMC Ms11Host_SafereturnA_SMC
.define X5PublishChr Ms11Host_X5PublishChr
.define ReloadCHRBank Ms11Host_ReloadCHRBank
; Bound include C:\Users\kando\Documents\ChatGPT\SMB Crossover\tools\reference\metal_storm_owning_graft_1101_v11.inc
; Private owning-composition proposal. CHR is granted; ROM/RAM are NOT granted.
; Called only after complete C2/C3 authentication by the ROM gate. R0..R7 are
; foreground03..0A; native NMI00..02 are never borrowed. No menu ingress here.
.macro Ms11EmitUpdateEntry
Ms11UpdateGate:
 jsr Ms8GateAuth
 rts
.endmacro

.macro Ms11SelectUpdateBeforeReady
 tsx
 lda $010a,x
 cmp #<(Ms11UpdateGate+2)
 beq Ms11GateUpdateCall
.endmacro

.macro Ms11EmitUpdateCall
Ms11GateUpdateCall:
 jsr Ms11RenderUpdate
 bcs Ms8GateAccepted
 bcc Ms8GateBad
.endmacro

.macro Ms11EmitUpdate
; A/X = actual host-area right-bound low/high on the first accepted call.
; Existing source constructor supplies the original actor slots/activation,
; gravity reset, fractions and animation mask. No captured donor RAM image.
; Native scene8 and normal YHigh1 are required by the outer/source guards.
; Source-owned clock/input ordering and epoch guard remain in MsHostStep.
; Caller camera follows this single source world-delta application.
; All AXYP except result C, foreground R0..R7 and five SMC operands retained.
Ms11RenderUpdate:
 jsr MsRSave
 lda $c800
 cmp #$a7
 beq Ms11UpdateStep
 ; Gate stack keeps the original caller registers across authentication.
 ; Its9 saved bytes plus this child JSR put originalA at+10, X at+9.
 ; MsRSave captures the volatile transport registers, not these arguments.
 tsx
 lda $010a,x
 pha
 lda $0109,x
 tax
 pla
 MsRFar MsHostSetBounds,3
 MsRFar MsNativeConstruct,3
 bcc Ms11UpdateRejected
Ms11UpdateStep:
 MsRFar MsHostStep,3
 bcc Ms11UpdateRejected
 MsRFar MsNativeApplyDelta,3
 jsr MsRRestore
 sec
 rts
Ms11UpdateRejected:
 jsr MsRRestore
 clc
 rts
Ms11UpdateEnd:
.endmacro

; Bound include C:\Users\kando\Documents\ChatGPT\SMB Crossover\build\metal-storm-owning-graft-1101-v11\actor.s
.setcpu "6502"

MsState=$c000
MsPointer=$03
MsSaved0=MsState+$7fe
MsSaved1=MsState+$7ff
.segment "MS11_ACTOR"
MsHostServiceRows:
.repeat 37,I
 jmp Ms12ActorBridge
.endrepeat
MsHostReject:clc
 rts

.global MsExternal_8874
MsExternal_8BCF=MsObj_8BCF
.global MsExternal_9ED7
.global MsExternal_FF18
MsExternal_FF1E=MsNativeTileQuery
MsExternal_FF27=MsObj_DCAE
MsExternal_FF33=MsNativeFF33
MsExternal_FF36=MsNativeFF36
.global MsExternal_FF39
MsExternal_FF3F=MsNativeFF3F
MsAlias_FF69: jmp Ms_E324
MsAlias_FF6C: jmp Ms_EA4E
; Bound include C:\Users\kando\Documents\ChatGPT\SMB Crossover\build\metal-storm-objects-host-1101-v6\actor-relaxed.inc
Ms_AB53: LDA #$00 ; donor $ab53
Ms_AB55: STA MsState+$004a ; donor $ab55
Ms_AB57: LDA MsState+$004b ; donor $ab57
Ms_AB59: bpl Ms_AB5F ; donor $ab59
Ms_AB5B: LDA #$ff ; donor $ab5b
Ms_AB5D: STA MsState+$004a ; donor $ab5d
Ms_AB5F: LDA MsState+$0113 ; donor $ab5f
Ms_AB62: CLC ; donor $ab62
Ms_AB63: ADC MsState+$004b ; donor $ab63
Ms_AB65: STA MsState+$0558 ; donor $ab65
Ms_AB68: LDA MsState+$0114 ; donor $ab68
Ms_AB6B: ADC MsState+$004a ; donor $ab6b
Ms_AB6D: bmi Ms_AB81 ; donor $ab6d
Ms_AB6F: bne Ms_AB78 ; donor $ab6f
Ms_AB71: LDA MsState+$0558 ; donor $ab71
Ms_AB74: bmi Ms_AB81 ; donor $ab74
Ms_AB76: beq Ms_AB87 ; donor $ab76
Ms_AB78: JSR Ms_B413 ; donor $ab78
Ms_AB7B: JSR Ms_BBB1 ; donor $ab7b
Ms_AB7E: JMP Ms_AB87 ; donor $ab7e
Ms_AB81: JSR Ms_B458 ; donor $ab81
Ms_AB84: JSR Ms_BC04 ; donor $ab84
Ms_AB87: LDA MsState+$0570 ; donor $ab87
Ms_AB8A: STA MsState+$004c ; donor $ab8a
Ms_AB8C: LDA MsState+$004e ; donor $ab8c
Ms_AB8E: STA MsState+$0570 ; donor $ab8e
Ms_AB91: LDA MsState+$004d ; donor $ab91
Ms_AB93: STA MsState+$0558 ; donor $ab93
Ms_AB96: LDY MsState+$0050 ; donor $ab96
Ms_AB98: bne Ms_AB9B ; donor $ab98
Ms_AB9A: RTS ; donor $ab9a
Ms_AB9B: LDA MsState+$04c8 ; donor $ab9b
Ms_AB9E: bmi Ms_ABBD ; donor $ab9e
Ms_ABA0: bne Ms_ABA8 ; donor $aba0
Ms_ABA2: LDA MsState+$04b0 ; donor $aba2
Ms_ABA5: JMP Ms_ABAE ; donor $aba5
Ms_ABA8: LDA MsState+$04b0 ; donor $aba8
Ms_ABAB: CLC ; donor $abab
Ms_ABAC: ADC #$0a ; donor $abac
Ms_ABAE: CMP #$f0 ; donor $abae
Ms_ABB0: bcc Ms_ABB4 ; donor $abb0
Ms_ABB2: SBC #$f0 ; donor $abb2
Ms_ABB4: STA MsState+$04b0 ; donor $abb4
Ms_ABB7: LDA #$00 ; donor $abb7
Ms_ABB9: STA MsState+$04c8 ; donor $abb9
Ms_ABBC: RTS ; donor $abbc
Ms_ABBD: LDA MsState+$04b0 ; donor $abbd
Ms_ABC0: SEC ; donor $abc0
Ms_ABC1: SBC #$10 ; donor $abc1
Ms_ABC3: JMP Ms_ABAE ; donor $abc3
Ms_ABC6: .byte $ad
Ms_ABC7: .byte $98
Ms_ABC8: .byte $04
Ms_ABC9: .byte $d0
Ms_ABCA: .byte $07
Ms_ABCB: .byte $ad
Ms_ABCC: .byte $80
Ms_ABCD: .byte $04
Ms_ABCE: .byte $c9
Ms_ABCF: .byte $78
Ms_ABD0: .byte $90
Ms_ABD1: .byte $31
Ms_ABD2: .byte $ad
Ms_ABD3: .byte $80
Ms_ABD4: .byte $04
Ms_ABD5: .byte $38
Ms_ABD6: .byte $e9
Ms_ABD7: .byte $78
Ms_ABD8: .byte $8d
Ms_ABD9: .byte $10
Ms_ABDA: .byte $07
Ms_ABDB: .byte $ad
Ms_ABDC: .byte $98
Ms_ABDD: .byte $04
Ms_ABDE: .byte $e9
Ms_ABDF: .byte $00
Ms_ABE0: .byte $8d
Ms_ABE1: .byte $11
Ms_ABE2: .byte $07
Ms_ABE3: .byte $cd
Ms_ABE4: .byte $1b
Ms_ABE5: .byte $07
Ms_ABE6: .byte $90
Ms_ABE7: .byte $1b
Ms_ABE8: .byte $d0
Ms_ABE9: .byte $08
Ms_ABEA: .byte $ad
Ms_ABEB: .byte $10
Ms_ABEC: .byte $07
Ms_ABED: .byte $cd
Ms_ABEE: .byte $1a
Ms_ABEF: .byte $07
Ms_ABF0: .byte $90
Ms_ABF1: .byte $11
Ms_ABF2: .byte $ad
Ms_ABF3: .byte $1a
Ms_ABF4: .byte $07
Ms_ABF5: .byte $8d
Ms_ABF6: .byte $10
Ms_ABF7: .byte $07
Ms_ABF8: .byte $ad
Ms_ABF9: .byte $1b
Ms_ABFA: .byte $07
Ms_ABFB: .byte $8d
Ms_ABFC: .byte $11
Ms_ABFD: .byte $07
Ms_ABFE: .byte $a9
Ms_ABFF: .byte $00
Ms_AC00: .byte $8d
Ms_AC01: .byte $0f
Ms_AC02: .byte $07
Ms_AC03: .byte $60
Ms_AC04: .byte $ad
Ms_AC05: .byte $98
Ms_AC06: .byte $04
Ms_AC07: .byte $cd
Ms_AC08: .byte $33
Ms_AC09: .byte $07
Ms_AC0A: .byte $d0
Ms_AC0B: .byte $07
Ms_AC0C: .byte $ad
Ms_AC0D: .byte $80
Ms_AC0E: .byte $04
Ms_AC0F: .byte $c9
Ms_AC10: .byte $78
Ms_AC11: .byte $b0
Ms_AC12: .byte $1b
Ms_AC13: .byte $ad
Ms_AC14: .byte $80
Ms_AC15: .byte $04
Ms_AC16: .byte $38
Ms_AC17: .byte $e9
Ms_AC18: .byte $78
Ms_AC19: .byte $8d
Ms_AC1A: .byte $10
Ms_AC1B: .byte $07
Ms_AC1C: .byte $ad
Ms_AC1D: .byte $98
Ms_AC1E: .byte $04
Ms_AC1F: .byte $e9
Ms_AC20: .byte $00
Ms_AC21: .byte $8d
Ms_AC22: .byte $11
Ms_AC23: .byte $07
Ms_AC24: .byte $b0
Ms_AC25: .byte $08
Ms_AC26: .byte $a9
Ms_AC27: .byte $00
Ms_AC28: .byte $8d
Ms_AC29: .byte $10
Ms_AC2A: .byte $07
Ms_AC2B: .byte $8d
Ms_AC2C: .byte $11
Ms_AC2D: .byte $07
Ms_AC2E: .byte $60
Ms_AC2F: LDA #$00 ; donor $ac2f
Ms_AC31: STA MsState+$004b ; donor $ac31
Ms_AC33: STA MsState+$0618 ; donor $ac33
Ms_AC36: LDA MsState+$05b8 ; donor $ac36
Ms_AC39: bne Ms_AC4E ; donor $ac39
Ms_AC3B: LDA MsState+$0734 ; donor $ac3b
Ms_AC3E: bpl Ms_AC48 ; donor $ac3e
Ms_AC40: LDA MsState+$0031 ; donor $ac40
Ms_AC42: AND #$10 ; donor $ac42
Ms_AC44: bne Ms_AC83 ; donor $ac44
Ms_AC46: beq Ms_AC4E ; donor $ac46
Ms_AC48: LDA MsState+$0031 ; donor $ac48
Ms_AC4A: AND #$20 ; donor $ac4a
Ms_AC4C: bne Ms_AC83 ; donor $ac4c
Ms_AC4E: LDA MsState+$0031 ; donor $ac4e
Ms_AC50: ASL A ; donor $ac50
Ms_AC51: bcc Ms_AC67 ; donor $ac51
Ms_AC53: LDA #$80 ; donor $ac53
Ms_AC55: STA MsState+$043f ; donor $ac55
Ms_AC58: LDA MsState+$0754 ; donor $ac58
Ms_AC5B: AND #$40 ; donor $ac5b
Ms_AC5D: beq Ms_AC64 ; donor $ac5d
Ms_AC5F: LDA #$80 ; donor $ac5f
Ms_AC61: STA MsState+$0754 ; donor $ac61
Ms_AC64: JMP Ms_BB16 ; donor $ac64
Ms_AC67: ASL A ; donor $ac67
Ms_AC68: bcc Ms_AC7E ; donor $ac68
Ms_AC6A: LDA #$40 ; donor $ac6a
Ms_AC6C: STA MsState+$043f ; donor $ac6c
Ms_AC6F: LDA MsState+$0754 ; donor $ac6f
Ms_AC72: AND #$40 ; donor $ac72
Ms_AC74: bne Ms_AC7B ; donor $ac74
Ms_AC76: LDA #$c0 ; donor $ac76
Ms_AC78: STA MsState+$0754 ; donor $ac78
Ms_AC7B: JMP Ms_BB6C ; donor $ac7b
Ms_AC7E: LDA #$80 ; donor $ac7e
Ms_AC80: STA MsState+$0618 ; donor $ac80
Ms_AC83: RTS ; donor $ac83
Ms_AC84: LDA MsState+$0050 ; donor $ac84
Ms_AC86: bne Ms_ACB1 ; donor $ac86
Ms_AC88: LDA MsState+$0570 ; donor $ac88
Ms_AC8B: beq Ms_ACCB ; donor $ac8b
Ms_AC8D: bmi Ms_AC9C ; donor $ac8d
Ms_AC8F: CLC ; donor $ac8f
Ms_AC90: ADC MsState+$04b0 ; donor $ac90
Ms_AC93: STA MsState+$04b0 ; donor $ac93
Ms_AC96: bcc Ms_ACCB ; donor $ac96
Ms_AC98: INC MsState+$04c8 ; donor $ac98
Ms_AC9B: RTS ; donor $ac9b
Ms_AC9C: EOR #$ff ; donor $ac9c
Ms_AC9E: STA MsState+$0071 ; donor $ac9e
Ms_ACA0: INC MsState+$0071 ; donor $aca0
Ms_ACA2: LDA MsState+$04b0 ; donor $aca2
Ms_ACA5: SEC ; donor $aca5
Ms_ACA6: SBC MsState+$0071 ; donor $aca6
Ms_ACA8: STA MsState+$04b0 ; donor $aca8
Ms_ACAB: bcs Ms_ACCB ; donor $acab
Ms_ACAD: DEC MsState+$04c8 ; donor $acad
Ms_ACB0: RTS ; donor $acb0
Ms_ACB1: LDA MsState+$0570 ; donor $acb1
Ms_ACB4: beq Ms_ACCB ; donor $acb4
Ms_ACB6: CLC ; donor $acb6
Ms_ACB7: ADC MsState+$04b0 ; donor $acb7
Ms_ACBA: STA MsState+$04b0 ; donor $acba
Ms_ACBD: CMP #$f0 ; donor $acbd
Ms_ACBF: bcc Ms_ACCB ; donor $acbf
Ms_ACC1: LDY MsState+$0570 ; donor $acc1
Ms_ACC4: bmi Ms_ACCC ; donor $acc4
Ms_ACC6: SBC #$f0 ; donor $acc6
Ms_ACC8: STA MsState+$04b0 ; donor $acc8
Ms_ACCB: RTS ; donor $accb
Ms_ACCC: CLC ; donor $accc
Ms_ACCD: ADC #$f0 ; donor $accd
Ms_ACCF: STA MsState+$04b0 ; donor $accf
Ms_ACD2: RTS ; donor $acd2
Ms_ACD3: LDA MsState+$05b8 ; donor $acd3
Ms_ACD6: bne Ms_ACF7 ; donor $acd6
Ms_ACD8: LDA MsState+$0737 ; donor $acd8
Ms_ACDB: beq Ms_ACE9 ; donor $acdb
Ms_ACDD: CMP #$ff ; donor $acdd
Ms_ACDF: beq Ms_ACE4 ; donor $acdf
Ms_ACE1: JSR Ms_AD6F ; donor $ace1
Ms_ACE4: LDA #$00 ; donor $ace4
Ms_ACE6: STA MsState+$0737 ; donor $ace6
Ms_ACE9: LDA MsState+$0540 ; donor $ace9
Ms_ACEC: AND #$7f ; donor $acec
Ms_ACEE: ORA MsState+$0734 ; donor $acee
Ms_ACF1: STA MsState+$0540 ; donor $acf1
Ms_ACF4: JMP Ms_AF7D ; donor $acf4
Ms_ACF7: LDA MsState+$04e0 ; donor $acf7
Ms_ACFA: CMP #$04 ; donor $acfa
Ms_ACFC: bne Ms_AD16 ; donor $acfc
Ms_ACFE: LDA MsState+$04f8 ; donor $acfe
Ms_AD01: CMP #$03 ; donor $ad01
Ms_AD03: beq Ms_ACE9 ; donor $ad03
Ms_AD05: CMP #$05 ; donor $ad05
Ms_AD07: bcc Ms_AD53 ; donor $ad07
Ms_AD09: LDA #$07 ; donor $ad09
Ms_AD0B: STA MsState+$04e0 ; donor $ad0b
Ms_AD0E: LDA #$04 ; donor $ad0e
Ms_AD10: STA MsState+$04f8 ; donor $ad10
Ms_AD13: JMP Ms_AF7D ; donor $ad13
Ms_AD16: CMP #$05 ; donor $ad16
Ms_AD18: bne Ms_AD3C ; donor $ad18
Ms_AD1A: LDA MsState+$04f8 ; donor $ad1a
Ms_AD1D: CMP #$02 ; donor $ad1d
Ms_AD1F: beq Ms_ACE9 ; donor $ad1f
Ms_AD21: CMP #$05 ; donor $ad21
Ms_AD23: bne Ms_AD53 ; donor $ad23
Ms_AD25: LDA #$03 ; donor $ad25
Ms_AD27: STA MsState+$04f8 ; donor $ad27
Ms_AD2A: LDA MsState+$0737 ; donor $ad2a
Ms_AD2D: CMP #$ff ; donor $ad2d
Ms_AD2F: beq Ms_AD39 ; donor $ad2f
Ms_AD31: JSR Ms_AD6F ; donor $ad31
Ms_AD34: LDA #$ff ; donor $ad34
Ms_AD36: STA MsState+$0737 ; donor $ad36
Ms_AD39: JMP Ms_AF7D ; donor $ad39
Ms_AD3C: LDA MsState+$04f8 ; donor $ad3c
Ms_AD3F: CMP #$05 ; donor $ad3f
Ms_AD41: bcc Ms_AD53 ; donor $ad41
Ms_AD43: LDA #$03 ; donor $ad43
Ms_AD45: STA MsState+$04f8 ; donor $ad45
Ms_AD48: LDA #$00 ; donor $ad48
Ms_AD4A: STA MsState+$0737 ; donor $ad4a
Ms_AD4D: STA MsState+$0588 ; donor $ad4d
Ms_AD50: JSR Ms_AD6F ; donor $ad50
Ms_AD53: JMP Ms_AF7D ; donor $ad53
Ms_AD56: LDA MsState+$04e0 ; donor $ad56
Ms_AD59: CMP #$07 ; donor $ad59
Ms_AD5B: bne Ms_AD6E ; donor $ad5b
Ms_AD5D: LDA MsState+$04f8 ; donor $ad5d
Ms_AD60: CMP #$05 ; donor $ad60
Ms_AD62: bcc Ms_AD6E ; donor $ad62
Ms_AD64: LDA #$03 ; donor $ad64
Ms_AD66: STA MsState+$04f8 ; donor $ad66
Ms_AD69: LDA #$00 ; donor $ad69
Ms_AD6B: STA MsState+$0588 ; donor $ad6b
Ms_AD6E: RTS ; donor $ad6e
Ms_AD6F: LDX #$17 ; donor $ad6f
Ms_AD71: LDA MsState+$0510,X ; donor $ad71
Ms_AD74: bpl Ms_AD88 ; donor $ad74
Ms_AD76: LDA MsState+$0600,X ; donor $ad76
Ms_AD79: bpl Ms_AD88 ; donor $ad79
Ms_AD7B: LDA MsState+$0540,X ; donor $ad7b
Ms_AD7E: EOR #$80 ; donor $ad7e
Ms_AD80: STA MsState+$0540,X ; donor $ad80
Ms_AD83: LDA #$00 ; donor $ad83
Ms_AD85: STA MsState+$05b8,X ; donor $ad85
Ms_AD88: DEX ; donor $ad88
Ms_AD89: bne Ms_AD71 ; donor $ad89
Ms_AD8B: RTS ; donor $ad8b
Ms_AD8C: LDA #$00 ; donor $ad8c
Ms_AD8E: STA MsState+$004d ; donor $ad8e
Ms_AD90: STA MsState+$004e ; donor $ad90
Ms_AD92: STA MsState+$05e8 ; donor $ad92
Ms_AD95: LDA MsState+$06f8 ; donor $ad95
Ms_AD98: bpl Ms_AD9D ; donor $ad98
Ms_AD9A: JSR MsExternal_9ED7 ; donor $ad9a
Ms_AD9D: JSR Ms_AC2F ; donor $ad9d
Ms_ADA0: LDA MsState+$05b8 ; donor $ada0
Ms_ADA3: bne Ms_ADA8 ; donor $ada3
Ms_ADA5: JSR Ms_B5BC ; donor $ada5
Ms_ADA8: JSR MsAlias_FF69 ; donor $ada8
Ms_ADAB: JSR Ms_AC84 ; donor $adab
Ms_ADAE: JSR Ms_BB08 ; donor $adae
Ms_ADB1: JSR Ms_B744 ; donor $adb1
Ms_ADB4: JSR MsExternal_8BCF ; donor $adb4
Ms_ADB7: LDA MsState+$006b ; donor $adb7
Ms_ADB9: bne Ms_ADBF ; donor $adb9
Ms_ADBB: LDA MsState+$006a ; donor $adbb
Ms_ADBD: beq Ms_ADC2 ; donor $adbd
Ms_ADBF: JSR Ms_B93D ; donor $adbf
Ms_ADC2: JSR MsAlias_FF6C ; donor $adc2
Ms_ADC5: JSR MsExternal_FF27 ; donor $adc5
Ms_ADC8: LDA MsState+$0510 ; donor $adc8
Ms_ADCB: bpl Ms_ADE4 ; donor $adcb
Ms_ADCD: LDA MsState+$0588 ; donor $adcd
Ms_ADD0: bpl Ms_ADE4 ; donor $add0
Ms_ADD2: LDA MsState+$0053 ; donor $add2
Ms_ADD4: AND MsState+$05a0 ; donor $add4
Ms_ADD7: bne Ms_ADE4 ; donor $add7
Ms_ADD9: INC MsState+$04f8 ; donor $add9
Ms_ADDC: LDA MsState+$04f8 ; donor $addc
Ms_ADDF: AND #$07 ; donor $addf
Ms_ADE1: STA MsState+$04f8 ; donor $ade1
Ms_ADE4: LDA MsState+$0031 ; donor $ade4
Ms_ADE6: AND #$08 ; donor $ade6
Ms_ADE8: beq Ms_AE1A ; donor $ade8
Ms_ADEA: LDA MsState+$0735 ; donor $adea
Ms_ADED: AND #$08 ; donor $aded
Ms_ADEF: bne Ms_AE22 ; donor $adef
Ms_ADF1: LDA MsState+$0735 ; donor $adf1
Ms_ADF4: ORA #$08 ; donor $adf4
Ms_ADF6: STA MsState+$0735 ; donor $adf6
Ms_ADF9: LDA MsState+$0034 ; donor $adf9
Ms_ADFB: STA MsState+$0750 ; donor $adfb
Ms_ADFE: LDA MsState+$0035 ; donor $adfe
Ms_AE00: STA MsState+$0751 ; donor $ae00
Ms_AE03: LDA #$11 ; donor $ae03
Ms_AE05: STA MsState+$07e7 ; donor $ae05
Ms_AE08: LDA #$80 ; donor $ae08
Ms_AE0A: STA MsState+$06c6 ; donor $ae0a
Ms_AE0D: LDA #$01 ; donor $ae0d
Ms_AE0F: STA MsState+$0034 ; donor $ae0f
Ms_AE11: LDA #$00 ; donor $ae11
Ms_AE13: STA MsState+$0035 ; donor $ae13
Ms_AE15: STA MsState+$07f7 ; donor $ae15
Ms_AE18: beq Ms_AE22 ; donor $ae18
Ms_AE1A: LDA MsState+$0735 ; donor $ae1a
Ms_AE1D: AND #$f7 ; donor $ae1d
Ms_AE1F: STA MsState+$0735 ; donor $ae1f
Ms_AE22: LDA MsState+$0737 ; donor $ae22
Ms_AE25: bpl Ms_AE2A ; donor $ae25
Ms_AE27: JMP Ms_ACD3 ; donor $ae27
Ms_AE2A: JSR Ms_AD56 ; donor $ae2a
Ms_AE2D: LDA MsState+$0754 ; donor $ae2d
Ms_AE30: bpl Ms_AE35 ; donor $ae30
Ms_AE32: JMP Ms_AF7D ; donor $ae32
Ms_AE35: LDA MsState+$0031 ; donor $ae35
Ms_AE37: AND #$20 ; donor $ae37
Ms_AE39: beq Ms_AE9E ; donor $ae39
Ms_AE3B: LDA MsState+$0734 ; donor $ae3b
Ms_AE3E: bmi Ms_AEAC ; donor $ae3e
Ms_AE40: LDA MsState+$04e0 ; donor $ae40
Ms_AE43: CMP #$03 ; donor $ae43
Ms_AE45: beq Ms_AE5E ; donor $ae45
Ms_AE47: LDA #$03 ; donor $ae47
Ms_AE49: STA MsState+$04e0 ; donor $ae49
Ms_AE4C: LDA #$80 ; donor $ae4c
Ms_AE4E: STA MsState+$0588 ; donor $ae4e
Ms_AE51: LDA MsState+$05b8 ; donor $ae51
Ms_AE54: beq Ms_AE58 ; donor $ae54
Ms_AE56: LDA #$04 ; donor $ae56
Ms_AE58: STA MsState+$04f8 ; donor $ae58
Ms_AE5B: JMP Ms_AF7D ; donor $ae5b
Ms_AE5E: LDA MsState+$05b8 ; donor $ae5e
Ms_AE61: beq Ms_AE7E ; donor $ae61
Ms_AE63: LDA MsState+$04f8 ; donor $ae63
Ms_AE66: CMP #$06 ; donor $ae66
Ms_AE68: beq Ms_AE76 ; donor $ae68
Ms_AE6A: CMP #$03 ; donor $ae6a
Ms_AE6C: bcc Ms_AE47 ; donor $ae6c
Ms_AE6E: LDA #$80 ; donor $ae6e
Ms_AE70: STA MsState+$0588 ; donor $ae70
Ms_AE73: JMP Ms_AF7D ; donor $ae73
Ms_AE76: LDA #$00 ; donor $ae76
Ms_AE78: STA MsState+$0588 ; donor $ae78
Ms_AE7B: JMP Ms_AF7D ; donor $ae7b
Ms_AE7E: LDA #$80 ; donor $ae7e
Ms_AE80: STA MsState+$0618 ; donor $ae80
Ms_AE83: LDA MsState+$04f8 ; donor $ae83
Ms_AE86: CMP #$02 ; donor $ae86
Ms_AE88: beq Ms_AE96 ; donor $ae88
Ms_AE8A: CMP #$06 ; donor $ae8a
Ms_AE8C: beq Ms_AE91 ; donor $ae8c
Ms_AE8E: JMP Ms_AF7D ; donor $ae8e
Ms_AE91: LDA #$02 ; donor $ae91
Ms_AE93: STA MsState+$04f8 ; donor $ae93
Ms_AE96: LDA #$00 ; donor $ae96
Ms_AE98: STA MsState+$0588 ; donor $ae98
Ms_AE9B: JMP Ms_AF7D ; donor $ae9b
Ms_AE9E: LDA MsState+$0031 ; donor $ae9e
Ms_AEA0: AND #$10 ; donor $aea0
Ms_AEA2: bne Ms_AEA7 ; donor $aea2
Ms_AEA4: JMP Ms_AF24 ; donor $aea4
Ms_AEA7: LDA MsState+$0734 ; donor $aea7
Ms_AEAA: bmi Ms_AE40 ; donor $aeaa
Ms_AEAC: LDA MsState+$0031 ; donor $aeac
Ms_AEAE: AND #$c0 ; donor $aeae
Ms_AEB0: beq Ms_AED2 ; donor $aeb0
Ms_AEB2: LDA MsState+$05b8 ; donor $aeb2
Ms_AEB5: bne Ms_AED2 ; donor $aeb5
Ms_AEB7: LDA MsState+$04e0 ; donor $aeb7
Ms_AEBA: CMP #$02 ; donor $aeba
Ms_AEBC: beq Ms_AEC4 ; donor $aebc
Ms_AEBE: CMP #$01 ; donor $aebe
Ms_AEC0: bne Ms_AF08 ; donor $aec0
Ms_AEC2: beq Ms_AF01 ; donor $aec2
Ms_AEC4: LDA #$01 ; donor $aec4
Ms_AEC6: LDX MsState+$04f8 ; donor $aec6
Ms_AEC9: CPX #$01 ; donor $aec9
Ms_AECB: beq Ms_AF0F ; donor $aecb
Ms_AECD: bcs Ms_AF0D ; donor $aecd
Ms_AECF: JMP Ms_AF01 ; donor $aecf
Ms_AED2: LDA MsState+$04e0 ; donor $aed2
Ms_AED5: CMP #$02 ; donor $aed5
Ms_AED7: bne Ms_AF08 ; donor $aed7
Ms_AED9: LDA MsState+$05b8 ; donor $aed9
Ms_AEDC: bne Ms_AEEC ; donor $aedc
Ms_AEDE: LDA MsState+$04f8 ; donor $aede
Ms_AEE1: CMP #$02 ; donor $aee1
Ms_AEE3: beq Ms_AEF9 ; donor $aee3
Ms_AEE5: CMP #$03 ; donor $aee5
Ms_AEE7: bcs Ms_AF0D ; donor $aee7
Ms_AEE9: JMP Ms_AF01 ; donor $aee9
Ms_AEEC: LDA MsState+$04f8 ; donor $aeec
Ms_AEEF: CMP #$06 ; donor $aeef
Ms_AEF1: beq Ms_AEF9 ; donor $aef1
Ms_AEF3: CMP #$04 ; donor $aef3
Ms_AEF5: bcc Ms_AF13 ; donor $aef5
Ms_AEF7: bcs Ms_AF01 ; donor $aef7
Ms_AEF9: LDA #$00 ; donor $aef9
Ms_AEFB: STA MsState+$0588 ; donor $aefb
Ms_AEFE: JMP Ms_AF7D ; donor $aefe
Ms_AF01: LDA #$80 ; donor $af01
Ms_AF03: STA MsState+$0588 ; donor $af03
Ms_AF06: bne Ms_AF7D ; donor $af06
Ms_AF08: LDA MsState+$05b8 ; donor $af08
Ms_AF0B: bne Ms_AF13 ; donor $af0b
Ms_AF0D: LDA #$02 ; donor $af0d
Ms_AF0F: LDX #$00 ; donor $af0f
Ms_AF11: beq Ms_AF17 ; donor $af11
Ms_AF13: LDA #$02 ; donor $af13
Ms_AF15: LDX #$04 ; donor $af15
Ms_AF17: STA MsState+$04e0 ; donor $af17
Ms_AF1A: STX MsState+$04f8 ; donor $af1a
Ms_AF1D: LDA #$80 ; donor $af1d
Ms_AF1F: STA MsState+$0588 ; donor $af1f
Ms_AF22: bne Ms_AF7D ; donor $af22
Ms_AF24: LDA MsState+$05b8 ; donor $af24
Ms_AF27: beq Ms_AF3A ; donor $af27
Ms_AF29: LDA #$07 ; donor $af29
Ms_AF2B: STA MsState+$04e0 ; donor $af2b
Ms_AF2E: LDA #$03 ; donor $af2e
Ms_AF30: STA MsState+$04f8 ; donor $af30
Ms_AF33: LDA #$00 ; donor $af33
Ms_AF35: STA MsState+$0588 ; donor $af35
Ms_AF38: beq Ms_AF7D ; donor $af38
Ms_AF3A: LDA MsState+$0031 ; donor $af3a
Ms_AF3C: AND #$c0 ; donor $af3c
Ms_AF3E: bne Ms_AF66 ; donor $af3e
Ms_AF40: LDA MsState+$04e0 ; donor $af40
Ms_AF43: CMP #$07 ; donor $af43
Ms_AF45: bne Ms_AF55 ; donor $af45
Ms_AF47: LDA MsState+$04f8 ; donor $af47
Ms_AF4A: CMP #$02 ; donor $af4a
Ms_AF4C: bne Ms_AF7D ; donor $af4c
Ms_AF4E: LDA #$00 ; donor $af4e
Ms_AF50: STA MsState+$0588 ; donor $af50
Ms_AF53: beq Ms_AF7D ; donor $af53
Ms_AF55: LDA #$07 ; donor $af55
Ms_AF57: STA MsState+$04e0 ; donor $af57
Ms_AF5A: LDA #$80 ; donor $af5a
Ms_AF5C: STA MsState+$0588 ; donor $af5c
Ms_AF5F: LDA #$00 ; donor $af5f
Ms_AF61: STA MsState+$04f8 ; donor $af61
Ms_AF64: beq Ms_AF7D ; donor $af64
Ms_AF66: LDA MsState+$05b8 ; donor $af66
Ms_AF69: bne Ms_AF7D ; donor $af69
Ms_AF6B: LDA MsState+$04e0 ; donor $af6b
Ms_AF6E: beq Ms_AF7D ; donor $af6e
Ms_AF70: LDA #$00 ; donor $af70
Ms_AF72: STA MsState+$04e0 ; donor $af72
Ms_AF75: STA MsState+$04f8 ; donor $af75
Ms_AF78: LDA #$80 ; donor $af78
Ms_AF7A: STA MsState+$0588 ; donor $af7a
Ms_AF7D: LDA MsState+$0737 ; donor $af7d
Ms_AF80: bpl Ms_AF85 ; donor $af80
Ms_AF82: JMP Ms_AFD6 ; donor $af82
Ms_AF85: LDA MsState+$0754 ; donor $af85
Ms_AF88: bpl Ms_AF82 ; donor $af88
Ms_AF8A: LDA #$80 ; donor $af8a
Ms_AF8C: STA MsState+$0588 ; donor $af8c
Ms_AF8F: LDA MsState+$0031 ; donor $af8f
Ms_AF91: AND #$30 ; donor $af91
Ms_AF93: bne Ms_AFC0 ; donor $af93
Ms_AF95: LDA MsState+$04e0 ; donor $af95
Ms_AF98: CMP #$02 ; donor $af98
Ms_AF9A: beq Ms_AFB0 ; donor $af9a
Ms_AF9C: LDA #$02 ; donor $af9c
Ms_AF9E: STA MsState+$04e0 ; donor $af9e
Ms_AFA1: LDA #$00 ; donor $afa1
Ms_AFA3: LDX MsState+$05b8 ; donor $afa3
Ms_AFA6: beq Ms_AFAA ; donor $afa6
Ms_AFA8: ORA #$04 ; donor $afa8
Ms_AFAA: STA MsState+$04f8 ; donor $afaa
Ms_AFAD: JMP Ms_AFD6 ; donor $afad
Ms_AFB0: LDA MsState+$04f8 ; donor $afb0
Ms_AFB3: AND #$03 ; donor $afb3
Ms_AFB5: CMP #$02 ; donor $afb5
Ms_AFB7: beq Ms_AFC0 ; donor $afb7
Ms_AFB9: CMP #$03 ; donor $afb9
Ms_AFBB: beq Ms_AFC0 ; donor $afbb
Ms_AFBD: JMP Ms_B05C ; donor $afbd
Ms_AFC0: LDA MsState+$0540 ; donor $afc0
Ms_AFC3: AND #$bf ; donor $afc3
Ms_AFC5: STA MsState+$0540 ; donor $afc5
Ms_AFC8: LDA MsState+$0754 ; donor $afc8
Ms_AFCB: AND #$40 ; donor $afcb
Ms_AFCD: STA MsState+$0754 ; donor $afcd
Ms_AFD0: ORA MsState+$0540 ; donor $afd0
Ms_AFD3: STA MsState+$0540 ; donor $afd3
Ms_AFD6: LDA MsState+$0717 ; donor $afd6
Ms_AFD9: jpl Ms_B057 ; donor $afd9
Ms_AFDB: LDA MsState+$0031 ; donor $afdb
Ms_AFDD: AND #$f0 ; donor $afdd
Ms_AFDF: bne Ms_AFF0 ; donor $afdf
Ms_AFE1: LDA #$02 ; donor $afe1
Ms_AFE3: STA MsState+$074a ; donor $afe3
Ms_AFE6: LDA #$00 ; donor $afe6
Ms_AFE8: STA MsState+$0619 ; donor $afe8
Ms_AFEB: LDA MsState+$043e ; donor $afeb
Ms_AFEE: bne Ms_B031 ; donor $afee
Ms_AFF0: DEC MsState+$074a ; donor $aff0
Ms_AFF3: bne Ms_AFEB ; donor $aff3
Ms_AFF5: LDA #$02 ; donor $aff5
Ms_AFF7: STA MsState+$074a ; donor $aff7
Ms_AFFA: LDA MsState+$0618 ; donor $affa
Ms_AFFD: beq Ms_B00C ; donor $affd
Ms_AFFF: LDX MsState+$0619 ; donor $afff
Ms_B002: INX ; donor $b002
Ms_B003: CPX #$10 ; donor $b003
Ms_B005: bne Ms_B009 ; donor $b005
Ms_B007: LDX #$0f ; donor $b007
Ms_B009: STX MsState+$0619 ; donor $b009
Ms_B00C: LDA MsState+$05b8 ; donor $b00c
Ms_B00F: beq Ms_B016 ; donor $b00f
Ms_B011: LDA #$00 ; donor $b011
Ms_B013: STA MsState+$0619 ; donor $b013
Ms_B016: LDA MsState+$0031 ; donor $b016
Ms_B018: AND MsState+$043e ; donor $b018
Ms_B01B: beq Ms_B02A ; donor $b01b
Ms_B01D: LDA MsState+$0031 ; donor $b01d
Ms_B01F: AND #$30 ; donor $b01f
Ms_B021: beq Ms_B02F ; donor $b021
Ms_B023: LDA MsState+$043e ; donor $b023
Ms_B026: AND #$30 ; donor $b026
Ms_B028: bne Ms_B02F ; donor $b028
Ms_B02A: LDA #$00 ; donor $b02a
Ms_B02C: STA MsState+$0619 ; donor $b02c
Ms_B02F: LDA MsState+$0031 ; donor $b02f
Ms_B031: LSR A ; donor $b031
Ms_B032: LSR A ; donor $b032
Ms_B033: LSR A ; donor $b033
Ms_B034: LSR A ; donor $b034
Ms_B035: LSR A ; donor $b035
Ms_B036: bcc Ms_B040 ; donor $b036
Ms_B038: LDA #$10 ; donor $b038
Ms_B03A: STA MsState+$043e ; donor $b03a
Ms_B03D: JMP Ms_B391 ; donor $b03d
Ms_B040: LSR A ; donor $b040
Ms_B041: bcc Ms_B046 ; donor $b041
Ms_B043: JMP Ms_B312 ; donor $b043
Ms_B046: LSR A ; donor $b046
Ms_B047: bcc Ms_B04C ; donor $b047
Ms_B049: JMP Ms_B2C7 ; donor $b049
Ms_B04C: JSR Ms_B283 ; donor $b04c
Ms_B04F: LDA #$80 ; donor $b04f
Ms_B051: STA MsState+$043e ; donor $b051
Ms_B054: JMP Ms_B406 ; donor $b054
Ms_B057: LDA #$80 ; donor $b057
Ms_B059: STA MsState+$0499 ; donor $b059
Ms_B05C: LDA MsState+$043d ; donor $b05c
Ms_B05F: bmi Ms_B07A ; donor $b05f
Ms_B061: LDA MsState+$0053 ; donor $b061
Ms_B063: AND #$01 ; donor $b063
Ms_B065: bne Ms_B07A ; donor $b065
Ms_B067: LDA MsState+$0031 ; donor $b067
Ms_B069: AND #$02 ; donor $b069
Ms_B06B: beq Ms_B07A ; donor $b06b
Ms_B06D: LDX #$02 ; donor $b06d
Ms_B06F: LDA MsState+$0512 ; donor $b06f
Ms_B072: beq Ms_B0B7 ; donor $b072
Ms_B074: INX ; donor $b074
Ms_B075: LDA MsState+$0513 ; donor $b075
Ms_B078: beq Ms_B0B7 ; donor $b078
Ms_B07A: JSR Ms_BCAC ; donor $b07a
Ms_B07D: LDA #$00 ; donor $b07d
Ms_B07F: STA MsState+$0117 ; donor $b07f
Ms_B082: JSR MsExternal_8874 ; donor $b082
Ms_B085: JSR Ms_B08F ; donor $b085
Ms_B088: LDA #$00 ; donor $b088
Ms_B08A: LDX #$02 ; donor $b08a
Ms_B08C: JMP MsExternal_FF39 ; donor $b08c
Ms_B08F: LDA MsState+$0710 ; donor $b08f
Ms_B092: STA MsState+$0022 ; donor $b092
Ms_B094: LDA MsState+$0050 ; donor $b094
Ms_B096: bmi Ms_B09F ; donor $b096
Ms_B098: bne Ms_B0A2 ; donor $b098
Ms_B09A: STA MsState+$0713 ; donor $b09a
Ms_B09D: beq Ms_B0A2 ; donor $b09d
Ms_B09F: JSR Ms_BC44 ; donor $b09f
Ms_B0A2: LDX MsState+$0713 ; donor $b0a2
Ms_B0A5: DEX ; donor $b0a5
Ms_B0A6: CPX #$ff ; donor $b0a6
Ms_B0A8: bne Ms_B0AC ; donor $b0a8
Ms_B0AA: LDX #$ef ; donor $b0aa
Ms_B0AC: STX MsState+$0023 ; donor $b0ac
Ms_B0AE: LSR MsState+$0020 ; donor $b0ae
Ms_B0B0: LDA MsState+$0711 ; donor $b0b0
Ms_B0B3: LSR A ; donor $b0b3
Ms_B0B4: ROL MsState+$0020 ; donor $b0b4
Ms_B0B6: RTS ; donor $b0b6
Ms_B0B7: LDA #$80 ; donor $b0b7
Ms_B0B9: STA MsState+$0528,X ; donor $b0b9
Ms_B0BC: LDA #$02 ; donor $b0bc
Ms_B0BE: STA MsState+$0648,X ; donor $b0be
Ms_B0C1: LDA #$00 ; donor $b0c1
Ms_B0C3: STA MsState+$0618,X ; donor $b0c3
Ms_B0C6: LDA #$14 ; donor $b0c6
Ms_B0C8: STA MsState+$0660,X ; donor $b0c8
Ms_B0CB: LDA #$0a ; donor $b0cb
Ms_B0CD: STA MsState+$0600,X ; donor $b0cd
Ms_B0D0: LDA MsState+$0734 ; donor $b0d0
Ms_B0D3: beq Ms_B0D7 ; donor $b0d3
Ms_B0D5: LDA #$01 ; donor $b0d5
Ms_B0D7: TAY ; donor $b0d7
Ms_B0D8: LDA MsState+$0031 ; donor $b0d8
Ms_B0DA: AND #$f0 ; donor $b0da
Ms_B0DC: bne Ms_B0E1 ; donor $b0dc
Ms_B0DE: LDA MsState+$043f ; donor $b0de
Ms_B0E1: PHA ; donor $b0e1
Ms_B0E2: AND #$30 ; donor $b0e2
Ms_B0E4: bne Ms_B142 ; donor $b0e4
Ms_B0E6: PLA ; donor $b0e6
Ms_B0E7: ASL A ; donor $b0e7
Ms_B0E8: bcc Ms_B114 ; donor $b0e8
Ms_B0EA: LDA #$0c ; donor $b0ea
Ms_B0EC: STA MsState+$0558,X ; donor $b0ec
Ms_B0EF: LDA #$00 ; donor $b0ef
Ms_B0F1: STA MsState+$0570,X ; donor $b0f1
Ms_B0F4: STA MsState+$0540,X ; donor $b0f4
Ms_B0F7: LDA MsState+$0480 ; donor $b0f7
Ms_B0FA: CLC ; donor $b0fa
Ms_B0FB: ADC #$0e ; donor $b0fb
Ms_B0FD: STA MsState+$0480,X ; donor $b0fd
Ms_B100: LDA MsState+$0498 ; donor $b100
Ms_B103: ADC #$00 ; donor $b103
Ms_B105: STA MsState+$0498,X ; donor $b105
Ms_B108: LDA MsState+$04b0 ; donor $b108
Ms_B10B: CLC ; donor $b10b
Ms_B10C: ADC Ms_B112,Y ; donor $b10c
Ms_B10F: JMP Ms_B18C ; donor $b10f
Ms_B112: .byte $03
Ms_B113: .byte $0c
Ms_B114: ASL A ; donor $b114
Ms_B115: bcc Ms_B141 ; donor $b115
Ms_B117: LDA #$f4 ; donor $b117
Ms_B119: STA MsState+$0558,X ; donor $b119
Ms_B11C: LDA #$00 ; donor $b11c
Ms_B11E: STA MsState+$0570,X ; donor $b11e
Ms_B121: LDA #$40 ; donor $b121
Ms_B123: STA MsState+$0540,X ; donor $b123
Ms_B126: LDA MsState+$0480 ; donor $b126
Ms_B129: CLC ; donor $b129
Ms_B12A: ADC #$0a ; donor $b12a
Ms_B12C: STA MsState+$0480,X ; donor $b12c
Ms_B12F: LDA MsState+$0498 ; donor $b12f
Ms_B132: ADC #$00 ; donor $b132
Ms_B134: STA MsState+$0498,X ; donor $b134
Ms_B137: LDA MsState+$04b0 ; donor $b137
Ms_B13A: CLC ; donor $b13a
Ms_B13B: ADC Ms_B112,Y ; donor $b13b
Ms_B13E: JMP Ms_B18C ; donor $b13e
Ms_B141: RTS ; donor $b141
Ms_B142: PLA ; donor $b142
Ms_B143: AND #$20 ; donor $b143
Ms_B145: beq Ms_B1B3 ; donor $b145
Ms_B147: LDA #$00 ; donor $b147
Ms_B149: STA MsState+$0558,X ; donor $b149
Ms_B14C: LDA #$0c ; donor $b14c
Ms_B14E: STA MsState+$0570,X ; donor $b14e
Ms_B151: LDA #$80 ; donor $b151
Ms_B153: STA MsState+$0540,X ; donor $b153
Ms_B156: LDA MsState+$0718 ; donor $b156
Ms_B159: bmi Ms_B175 ; donor $b159
Ms_B15B: LDA MsState+$0480 ; donor $b15b
Ms_B15E: CLC ; donor $b15e
Ms_B15F: ADC #$0c ; donor $b15f
Ms_B161: STA MsState+$0480,X ; donor $b161
Ms_B164: LDA MsState+$0498 ; donor $b164
Ms_B167: ADC #$00 ; donor $b167
Ms_B169: STA MsState+$0498,X ; donor $b169
Ms_B16C: LDA MsState+$04b0 ; donor $b16c
Ms_B16F: CLC ; donor $b16f
Ms_B170: ADC #$0e ; donor $b170
Ms_B172: JMP Ms_B18C ; donor $b172
Ms_B175: LDA MsState+$0480 ; donor $b175
Ms_B178: CLC ; donor $b178
Ms_B179: ADC #$08 ; donor $b179
Ms_B17B: STA MsState+$0480,X ; donor $b17b
Ms_B17E: LDA MsState+$0498 ; donor $b17e
Ms_B181: ADC #$00 ; donor $b181
Ms_B183: STA MsState+$0498,X ; donor $b183
Ms_B186: LDA MsState+$04b0 ; donor $b186
Ms_B189: CLC ; donor $b189
Ms_B18A: ADC #$0e ; donor $b18a
Ms_B18C: STA MsState+$04b0,X ; donor $b18c
Ms_B18F: LDY MsState+$0050 ; donor $b18f
Ms_B191: beq Ms_B1A8 ; donor $b191
Ms_B193: bcc Ms_B197 ; donor $b193
Ms_B195: SBC #$f0 ; donor $b195
Ms_B197: CMP #$f0 ; donor $b197
Ms_B199: bcc Ms_B19D ; donor $b199
Ms_B19B: SBC #$f0 ; donor $b19b
Ms_B19D: STA MsState+$04b0,X ; donor $b19d
Ms_B1A0: LDA #$00 ; donor $b1a0
Ms_B1A2: STA MsState+$04c8,X ; donor $b1a2
Ms_B1A5: JMP Ms_B21A ; donor $b1a5
Ms_B1A8: LDA MsState+$04c8 ; donor $b1a8
Ms_B1AB: ADC #$00 ; donor $b1ab
Ms_B1AD: STA MsState+$04c8,X ; donor $b1ad
Ms_B1B0: JMP Ms_B21A ; donor $b1b0
Ms_B1B3: LDA #$00 ; donor $b1b3
Ms_B1B5: STA MsState+$0558,X ; donor $b1b5
Ms_B1B8: STA MsState+$0540,X ; donor $b1b8
Ms_B1BB: LDA #$f4 ; donor $b1bb
Ms_B1BD: STA MsState+$0570,X ; donor $b1bd
Ms_B1C0: LDA MsState+$0718 ; donor $b1c0
Ms_B1C3: bmi Ms_B1DF ; donor $b1c3
Ms_B1C5: LDA MsState+$0480 ; donor $b1c5
Ms_B1C8: CLC ; donor $b1c8
Ms_B1C9: ADC #$0c ; donor $b1c9
Ms_B1CB: STA MsState+$0480,X ; donor $b1cb
Ms_B1CE: LDA MsState+$0498 ; donor $b1ce
Ms_B1D1: ADC #$00 ; donor $b1d1
Ms_B1D3: STA MsState+$0498,X ; donor $b1d3
Ms_B1D6: LDA MsState+$04b0 ; donor $b1d6
Ms_B1D9: SEC ; donor $b1d9
Ms_B1DA: SBC #$01 ; donor $b1da
Ms_B1DC: JMP Ms_B1F6 ; donor $b1dc
Ms_B1DF: LDA MsState+$0480 ; donor $b1df
Ms_B1E2: CLC ; donor $b1e2
Ms_B1E3: ADC #$08 ; donor $b1e3
Ms_B1E5: STA MsState+$0480,X ; donor $b1e5
Ms_B1E8: LDA MsState+$0498 ; donor $b1e8
Ms_B1EB: ADC #$00 ; donor $b1eb
Ms_B1ED: STA MsState+$0498,X ; donor $b1ed
Ms_B1F0: LDA MsState+$04b0 ; donor $b1f0
Ms_B1F3: SEC ; donor $b1f3
Ms_B1F4: SBC #$01 ; donor $b1f4
Ms_B1F6: STA MsState+$04b0,X ; donor $b1f6
Ms_B1F9: LDY MsState+$0050 ; donor $b1f9
Ms_B1FB: beq Ms_B212 ; donor $b1fb
Ms_B1FD: bcs Ms_B201 ; donor $b1fd
Ms_B1FF: ADC #$f0 ; donor $b1ff
Ms_B201: CMP #$f0 ; donor $b201
Ms_B203: bcc Ms_B207 ; donor $b203
Ms_B205: SBC #$f0 ; donor $b205
Ms_B207: STA MsState+$04b0,X ; donor $b207
Ms_B20A: LDA #$00 ; donor $b20a
Ms_B20C: STA MsState+$04c8,X ; donor $b20c
Ms_B20F: JMP Ms_B21A ; donor $b20f
Ms_B212: LDA MsState+$04c8 ; donor $b212
Ms_B215: SBC #$00 ; donor $b215
Ms_B217: STA MsState+$04c8,X ; donor $b217
Ms_B21A: LDA #$03 ; donor $b21a
Ms_B21C: STA MsState+$07e3 ; donor $b21c
Ms_B21F: LDA #$00 ; donor $b21f
Ms_B221: STA MsState+$04e0,X ; donor $b221
Ms_B224: LDA MsState+$0718 ; donor $b224
Ms_B227: bpl Ms_B234 ; donor $b227
Ms_B229: LDA #$80 ; donor $b229
Ms_B22B: STA MsState+$04e0,X ; donor $b22b
Ms_B22E: INC MsState+$0528,X ; donor $b22e
Ms_B231: INC MsState+$07e3 ; donor $b231
Ms_B234: LDA #$80 ; donor $b234
Ms_B236: STA MsState+$0510,X ; donor $b236
Ms_B239: JMP Ms_B07A ; donor $b239
Ms_B23C: .byte $ad
Ms_B23D: .byte $b8
Ms_B23E: .byte $05
Ms_B23F: .byte $d0
Ms_B240: .byte $1e
Ms_B241: .byte $ad
Ms_B242: .byte $17
Ms_B243: .byte $01
Ms_B244: .byte $10
Ms_B245: .byte $19
Ms_B246: .byte $a5
Ms_B247: .byte $31
Ms_B248: .byte $29
Ms_B249: .byte $c0
Ms_B24A: .byte $d0
Ms_B24B: .byte $24
Ms_B24C: .byte $ad
Ms_B24D: .byte $e0
Ms_B24E: .byte $04
Ms_B24F: .byte $c9
Ms_B250: .byte $07
Ms_B251: .byte $d0
Ms_B252: .byte $0d
Ms_B253: .byte $ad
Ms_B254: .byte $f8
Ms_B255: .byte $04
Ms_B256: .byte $c9
Ms_B257: .byte $02
Ms_B258: .byte $d0
Ms_B259: .byte $05
Ms_B25A: .byte $a9
Ms_B25B: .byte $00
Ms_B25C: .byte $8d
Ms_B25D: .byte $88
Ms_B25E: .byte $05
Ms_B25F: .byte $60
Ms_B260: .byte $a9
Ms_B261: .byte $07
Ms_B262: .byte $8d
Ms_B263: .byte $e0
Ms_B264: .byte $04
Ms_B265: .byte $a9
Ms_B266: .byte $80
Ms_B267: .byte $8d
Ms_B268: .byte $88
Ms_B269: .byte $05
Ms_B26A: .byte $a9
Ms_B26B: .byte $00
Ms_B26C: .byte $8d
Ms_B26D: .byte $f8
Ms_B26E: .byte $04
Ms_B26F: .byte $60
Ms_B270: .byte $ad
Ms_B271: .byte $e0
Ms_B272: .byte $04
Ms_B273: .byte $f0
Ms_B274: .byte $ea
Ms_B275: .byte $a9
Ms_B276: .byte $00
Ms_B277: .byte $8d
Ms_B278: .byte $e0
Ms_B279: .byte $04
Ms_B27A: .byte $8d
Ms_B27B: .byte $f8
Ms_B27C: .byte $04
Ms_B27D: .byte $a9
Ms_B27E: .byte $80
Ms_B27F: .byte $8d
Ms_B280: .byte $88
Ms_B281: .byte $05
Ms_B282: .byte $60
Ms_B283: LDA MsState+$0480 ; donor $b283
Ms_B286: CLC ; donor $b286
Ms_B287: ADC #$1c ; donor $b287
Ms_B289: STA MsState+$0481 ; donor $b289
Ms_B28C: LDA MsState+$0498 ; donor $b28c
Ms_B28F: ADC #$00 ; donor $b28f
Ms_B291: STA MsState+$0499 ; donor $b291
Ms_B294: LDA MsState+$0618 ; donor $b294
Ms_B297: bpl Ms_B2AD ; donor $b297
Ms_B299: LDA MsState+$05b8 ; donor $b299
Ms_B29C: bne Ms_B2AD ; donor $b29c
Ms_B29E: LDA MsState+$0481 ; donor $b29e
Ms_B2A1: CLC ; donor $b2a1
Ms_B2A2: ADC MsState+$0619 ; donor $b2a2
Ms_B2A5: STA MsState+$0481 ; donor $b2a5
Ms_B2A8: bcc Ms_B2AD ; donor $b2a8
Ms_B2AA: INC MsState+$0499 ; donor $b2aa
Ms_B2AD: LDA MsState+$04b0 ; donor $b2ad
Ms_B2B0: STA MsState+$04b1 ; donor $b2b0
Ms_B2B3: LDA MsState+$04c8 ; donor $b2b3
Ms_B2B6: STA MsState+$04c9 ; donor $b2b6
Ms_B2B9: LDA #$00 ; donor $b2b9
Ms_B2BB: STA MsState+$04e1 ; donor $b2bb
Ms_B2BE: LDA MsState+$0541 ; donor $b2be
Ms_B2C1: AND #$bf ; donor $b2c1
Ms_B2C3: STA MsState+$0541 ; donor $b2c3
Ms_B2C6: RTS ; donor $b2c6
Ms_B2C7: LDA MsState+$0480 ; donor $b2c7
Ms_B2CA: SEC ; donor $b2ca
Ms_B2CB: SBC #$04 ; donor $b2cb
Ms_B2CD: STA MsState+$0481 ; donor $b2cd
Ms_B2D0: LDA MsState+$0498 ; donor $b2d0
Ms_B2D3: SBC #$00 ; donor $b2d3
Ms_B2D5: STA MsState+$0499 ; donor $b2d5
Ms_B2D8: LDA MsState+$0618 ; donor $b2d8
Ms_B2DB: bpl Ms_B2F1 ; donor $b2db
Ms_B2DD: LDA MsState+$05b8 ; donor $b2dd
Ms_B2E0: bne Ms_B2F1 ; donor $b2e0
Ms_B2E2: LDA MsState+$0481 ; donor $b2e2
Ms_B2E5: SEC ; donor $b2e5
Ms_B2E6: SBC MsState+$0619 ; donor $b2e6
Ms_B2E9: STA MsState+$0481 ; donor $b2e9
Ms_B2EC: bcs Ms_B2F1 ; donor $b2ec
Ms_B2EE: DEC MsState+$0499 ; donor $b2ee
Ms_B2F1: LDA MsState+$04b0 ; donor $b2f1
Ms_B2F4: STA MsState+$04b1 ; donor $b2f4
Ms_B2F7: LDA MsState+$04c8 ; donor $b2f7
Ms_B2FA: STA MsState+$04c9 ; donor $b2fa
Ms_B2FD: LDA #$00 ; donor $b2fd
Ms_B2FF: STA MsState+$04e1 ; donor $b2ff
Ms_B302: LDA MsState+$0541 ; donor $b302
Ms_B305: ORA #$40 ; donor $b305
Ms_B307: STA MsState+$0541 ; donor $b307
Ms_B30A: LDA #$40 ; donor $b30a
Ms_B30C: STA MsState+$043e ; donor $b30c
Ms_B30F: JMP Ms_B406 ; donor $b30f
Ms_B312: LDA #$20 ; donor $b312
Ms_B314: STA MsState+$043e ; donor $b314
Ms_B317: LDA MsState+$0480 ; donor $b317
Ms_B31A: CLC ; donor $b31a
Ms_B31B: ADC #$04 ; donor $b31b
Ms_B31D: STA MsState+$0481 ; donor $b31d
Ms_B320: LDA MsState+$0498 ; donor $b320
Ms_B323: ADC #$00 ; donor $b323
Ms_B325: STA MsState+$0499 ; donor $b325
Ms_B328: LDA #$80 ; donor $b328
Ms_B32A: STA MsState+$04e1 ; donor $b32a
Ms_B32D: STA MsState+$0541 ; donor $b32d
Ms_B330: LDA MsState+$04b0 ; donor $b330
Ms_B333: CLC ; donor $b333
Ms_B334: ADC #$20 ; donor $b334
Ms_B336: STA MsState+$04b1 ; donor $b336
Ms_B339: LDY MsState+$0050 ; donor $b339
Ms_B33B: beq Ms_B351 ; donor $b33b
Ms_B33D: bcc Ms_B341 ; donor $b33d
Ms_B33F: SBC #$f0 ; donor $b33f
Ms_B341: CMP #$f0 ; donor $b341
Ms_B343: bcc Ms_B347 ; donor $b343
Ms_B345: SBC #$f0 ; donor $b345
Ms_B347: STA MsState+$04b1 ; donor $b347
Ms_B34A: LDA #$00 ; donor $b34a
Ms_B34C: STA MsState+$04c9 ; donor $b34c
Ms_B34F: beq Ms_B359 ; donor $b34f
Ms_B351: LDA MsState+$04c8 ; donor $b351
Ms_B354: ADC #$00 ; donor $b354
Ms_B356: STA MsState+$04c9 ; donor $b356
Ms_B359: LDA MsState+$0734 ; donor $b359
Ms_B35C: bpl Ms_B361 ; donor $b35c
Ms_B35E: JMP Ms_B05C ; donor $b35e
Ms_B361: LDA MsState+$05b8 ; donor $b361
Ms_B364: bne Ms_B35E ; donor $b364
Ms_B366: LDA MsState+$04b1 ; donor $b366
Ms_B369: CLC ; donor $b369
Ms_B36A: ADC MsState+$0619 ; donor $b36a
Ms_B36D: STA MsState+$04b1 ; donor $b36d
Ms_B370: LDY MsState+$0050 ; donor $b370
Ms_B372: beq Ms_B389 ; donor $b372
Ms_B374: bcc Ms_B378 ; donor $b374
Ms_B376: SBC #$f0 ; donor $b376
Ms_B378: CMP #$f0 ; donor $b378
Ms_B37A: bcc Ms_B37E ; donor $b37a
Ms_B37C: SBC #$f0 ; donor $b37c
Ms_B37E: STA MsState+$04b1 ; donor $b37e
Ms_B381: LDA #$00 ; donor $b381
Ms_B383: STA MsState+$04c9 ; donor $b383
Ms_B386: JMP Ms_B05C ; donor $b386
Ms_B389: bcc Ms_B38E ; donor $b389
Ms_B38B: INC MsState+$04c9 ; donor $b38b
Ms_B38E: JMP Ms_B05C ; donor $b38e
Ms_B391: LDA MsState+$0480 ; donor $b391
Ms_B394: CLC ; donor $b394
Ms_B395: ADC #$04 ; donor $b395
Ms_B397: STA MsState+$0481 ; donor $b397
Ms_B39A: LDA MsState+$0498 ; donor $b39a
Ms_B39D: ADC #$00 ; donor $b39d
Ms_B39F: STA MsState+$0499 ; donor $b39f
Ms_B3A2: LDA #$80 ; donor $b3a2
Ms_B3A4: STA MsState+$04e1 ; donor $b3a4
Ms_B3A7: LDA #$00 ; donor $b3a7
Ms_B3A9: STA MsState+$0541 ; donor $b3a9
Ms_B3AC: LDA MsState+$04b0 ; donor $b3ac
Ms_B3AF: SEC ; donor $b3af
Ms_B3B0: SBC #$10 ; donor $b3b0
Ms_B3B2: STA MsState+$04b1 ; donor $b3b2
Ms_B3B5: LDY MsState+$0050 ; donor $b3b5
Ms_B3B7: beq Ms_B3CD ; donor $b3b7
Ms_B3B9: bcs Ms_B3BD ; donor $b3b9
Ms_B3BB: ADC #$f0 ; donor $b3bb
Ms_B3BD: CMP #$f0 ; donor $b3bd
Ms_B3BF: bcc Ms_B3C3 ; donor $b3bf
Ms_B3C1: SBC #$f0 ; donor $b3c1
Ms_B3C3: STA MsState+$04b1 ; donor $b3c3
Ms_B3C6: LDA #$00 ; donor $b3c6
Ms_B3C8: STA MsState+$04c9 ; donor $b3c8
Ms_B3CB: beq Ms_B3D5 ; donor $b3cb
Ms_B3CD: LDA MsState+$04c8 ; donor $b3cd
Ms_B3D0: SBC #$00 ; donor $b3d0
Ms_B3D2: STA MsState+$04c9 ; donor $b3d2
Ms_B3D5: LDA MsState+$0734 ; donor $b3d5
Ms_B3D8: bpl Ms_B406 ; donor $b3d8
Ms_B3DA: LDA MsState+$05b8 ; donor $b3da
Ms_B3DD: bne Ms_B406 ; donor $b3dd
Ms_B3DF: LDA MsState+$04b1 ; donor $b3df
Ms_B3E2: SEC ; donor $b3e2
Ms_B3E3: SBC MsState+$0619 ; donor $b3e3
Ms_B3E6: STA MsState+$04b1 ; donor $b3e6
Ms_B3E9: LDY MsState+$0050 ; donor $b3e9
Ms_B3EB: beq Ms_B401 ; donor $b3eb
Ms_B3ED: bcs Ms_B3F1 ; donor $b3ed
Ms_B3EF: ADC #$f0 ; donor $b3ef
Ms_B3F1: CMP #$f0 ; donor $b3f1
Ms_B3F3: bcc Ms_B3F7 ; donor $b3f3
Ms_B3F5: SBC #$f0 ; donor $b3f5
Ms_B3F7: STA MsState+$04b1 ; donor $b3f7
Ms_B3FA: LDA #$00 ; donor $b3fa
Ms_B3FC: STA MsState+$04c9 ; donor $b3fc
Ms_B3FF: beq Ms_B406 ; donor $b3ff
Ms_B401: bcs Ms_B406 ; donor $b401
Ms_B403: DEC MsState+$04c9 ; donor $b403
Ms_B406: LDA #$80 ; donor $b406
Ms_B408: STA MsState+$0511 ; donor $b408
Ms_B40B: LDA #$82 ; donor $b40b
Ms_B40D: STA MsState+$0529 ; donor $b40d
Ms_B410: JMP Ms_B05C ; donor $b410
Ms_B413: LDX #$00 ; donor $b413
Ms_B415: LDA MsState+$0734 ; donor $b415
Ms_B418: bpl Ms_B41B ; donor $b418
Ms_B41A: INX ; donor $b41a
Ms_B41B: LDA Ms_FECC,X ; donor $b41b
Ms_B41E: CLC ; donor $b41e
Ms_B41F: ADC MsState+$0480 ; donor $b41f
Ms_B422: STA MsState+$0059 ; donor $b422
Ms_B424: LDA MsState+$0498 ; donor $b424
Ms_B427: ADC #$00 ; donor $b427
Ms_B429: STA MsState+$005a ; donor $b429
Ms_B42B: JSR Ms_B49D ; donor $b42b
Ms_B42E: bcc Ms_B457 ; donor $b42e
Ms_B430: LDA #$00 ; donor $b430
Ms_B432: STA MsState+$0558 ; donor $b432
Ms_B435: LDA MsState+$05e8 ; donor $b435
Ms_B438: AND #$40 ; donor $b438
Ms_B43A: beq Ms_B43F ; donor $b43a
Ms_B43C: JMP Ms_BA4E ; donor $b43c
Ms_B43F: LDA MsState+$05e8 ; donor $b43f
Ms_B442: ORA #$80 ; donor $b442
Ms_B444: STA MsState+$05e8 ; donor $b444
Ms_B447: LDA MsState+$0059 ; donor $b447
Ms_B449: SEC ; donor $b449
Ms_B44A: SBC Ms_FECC,X ; donor $b44a
Ms_B44D: STA MsState+$0480 ; donor $b44d
Ms_B450: LDA MsState+$005a ; donor $b450
Ms_B452: SBC #$00 ; donor $b452
Ms_B454: STA MsState+$0498 ; donor $b454
Ms_B457: RTS ; donor $b457
Ms_B458: LDX #$00 ; donor $b458
Ms_B45A: LDA MsState+$0734 ; donor $b45a
Ms_B45D: bpl Ms_B460 ; donor $b45d
Ms_B45F: INX ; donor $b45f
Ms_B460: LDA Ms_FEC8,X ; donor $b460
Ms_B463: CLC ; donor $b463
Ms_B464: ADC MsState+$0480 ; donor $b464
Ms_B467: STA MsState+$0059 ; donor $b467
Ms_B469: LDA MsState+$0498 ; donor $b469
Ms_B46C: ADC #$00 ; donor $b46c
Ms_B46E: STA MsState+$005a ; donor $b46e
Ms_B470: JSR Ms_B49D ; donor $b470
Ms_B473: bcc Ms_B49C ; donor $b473
Ms_B475: LDA #$00 ; donor $b475
Ms_B477: STA MsState+$0558 ; donor $b477
Ms_B47A: LDA MsState+$05e8 ; donor $b47a
Ms_B47D: AND #$80 ; donor $b47d
Ms_B47F: beq Ms_B484 ; donor $b47f
Ms_B481: JMP Ms_BA4E ; donor $b481
Ms_B484: LDA MsState+$05e8 ; donor $b484
Ms_B487: ORA #$40 ; donor $b487
Ms_B489: STA MsState+$05e8 ; donor $b489
Ms_B48C: LDA MsState+$0059 ; donor $b48c
Ms_B48E: SEC ; donor $b48e
Ms_B48F: SBC Ms_FEC8,X ; donor $b48f
Ms_B492: STA MsState+$0480 ; donor $b492
Ms_B495: LDA MsState+$005a ; donor $b495
Ms_B497: SBC #$00 ; donor $b497
Ms_B499: STA MsState+$0498 ; donor $b499
Ms_B49C: RTS ; donor $b49c
Ms_B49D: LDA #$00 ; donor $b49d
Ms_B49F: STA MsState+$0703 ; donor $b49f
Ms_B4A2: LDA Ms_FECA,X ; donor $b4a2
Ms_B4A5: CLC ; donor $b4a5
Ms_B4A6: ADC MsState+$04b0 ; donor $b4a6
Ms_B4A9: STA MsState+$005b ; donor $b4a9
Ms_B4AB: STA MsState+$007d ; donor $b4ab
Ms_B4AD: LDY MsState+$0050 ; donor $b4ad
Ms_B4AF: beq Ms_B4E7 ; donor $b4af
Ms_B4B1: bcc Ms_B4B8 ; donor $b4b1
Ms_B4B3: SBC #$f0 ; donor $b4b3
Ms_B4B5: INC MsState+$0703 ; donor $b4b5
Ms_B4B8: CMP #$f0 ; donor $b4b8
Ms_B4BA: bcc Ms_B4C1 ; donor $b4ba
Ms_B4BC: SBC #$f0 ; donor $b4bc
Ms_B4BE: INC MsState+$0703 ; donor $b4be
Ms_B4C1: STA MsState+$005b ; donor $b4c1
Ms_B4C3: LDY MsState+$0703 ; donor $b4c3
Ms_B4C6: bne Ms_B4D2 ; donor $b4c6
Ms_B4C8: STA MsState+$007d ; donor $b4c8
Ms_B4CA: LDA #$00 ; donor $b4ca
Ms_B4CC: STA MsState+$005c ; donor $b4cc
Ms_B4CE: STA MsState+$007e ; donor $b4ce
Ms_B4D0: beq Ms_B4F2 ; donor $b4d0
Ms_B4D2: SEC ; donor $b4d2
Ms_B4D3: SBC #$10 ; donor $b4d3
Ms_B4D5: STA MsState+$007d ; donor $b4d5
Ms_B4D7: LDA #$00 ; donor $b4d7
Ms_B4D9: STA MsState+$005c ; donor $b4d9
Ms_B4DB: bcs Ms_B4E1 ; donor $b4db
Ms_B4DD: STA MsState+$007e ; donor $b4dd
Ms_B4DF: beq Ms_B4F2 ; donor $b4df
Ms_B4E1: LDA #$01 ; donor $b4e1
Ms_B4E3: STA MsState+$007e ; donor $b4e3
Ms_B4E5: bne Ms_B4F2 ; donor $b4e5
Ms_B4E7: LDA MsState+$04c8 ; donor $b4e7
Ms_B4EA: ADC #$00 ; donor $b4ea
Ms_B4EC: STA MsState+$005c ; donor $b4ec
Ms_B4EE: STA MsState+$007e ; donor $b4ee
Ms_B4F0: bne Ms_B502 ; donor $b4f0
Ms_B4F2: JSR MsExternal_FF1E ; donor $b4f2
Ms_B4F5: LDY #$00 ; donor $b4f5
Ms_B4F7: LDA (MsPointer),Y ; donor $b4f7
Ms_B4F9: AND #$e0 ; donor $b4f9
Ms_B4FB: CMP #$e0 ; donor $b4fb
Ms_B4FD: bne Ms_B502 ; donor $b4fd
Ms_B4FF: JMP Ms_B585 ; donor $b4ff
Ms_B502: LDA #$00 ; donor $b502
Ms_B504: STA MsState+$0703 ; donor $b504
Ms_B507: LDA MsState+$04b0 ; donor $b507
Ms_B50A: CLC ; donor $b50a
Ms_B50B: ADC Ms_FECE,X ; donor $b50b
Ms_B50E: STA MsState+$005b ; donor $b50e
Ms_B510: LDY MsState+$0050 ; donor $b510
Ms_B512: beq Ms_B52A ; donor $b512
Ms_B514: bcc Ms_B51B ; donor $b514
Ms_B516: SBC #$f0 ; donor $b516
Ms_B518: INC MsState+$0703 ; donor $b518
Ms_B51B: CMP #$f0 ; donor $b51b
Ms_B51D: bcc Ms_B524 ; donor $b51d
Ms_B51F: SBC #$f0 ; donor $b51f
Ms_B521: INC MsState+$0703 ; donor $b521
Ms_B524: STA MsState+$005b ; donor $b524
Ms_B526: LDA #$00 ; donor $b526
Ms_B528: beq Ms_B52F ; donor $b528
Ms_B52A: LDA MsState+$04c8 ; donor $b52a
Ms_B52D: ADC #$00 ; donor $b52d
Ms_B52F: STA MsState+$005c ; donor $b52f
Ms_B531: bne Ms_B540 ; donor $b531
Ms_B533: JSR MsExternal_FF1E ; donor $b533
Ms_B536: LDY #$00 ; donor $b536
Ms_B538: LDA (MsPointer),Y ; donor $b538
Ms_B53A: AND #$e0 ; donor $b53a
Ms_B53C: CMP #$e0 ; donor $b53c
Ms_B53E: beq Ms_B585 ; donor $b53e
Ms_B540: LDA MsState+$0050 ; donor $b540
Ms_B542: beq Ms_B556 ; donor $b542
Ms_B544: LDA MsState+$0703 ; donor $b544
Ms_B547: beq Ms_B556 ; donor $b547
Ms_B549: LDA MsState+$005b ; donor $b549
Ms_B54B: SEC ; donor $b54b
Ms_B54C: SBC #$10 ; donor $b54c
Ms_B54E: STA MsState+$005b ; donor $b54e
Ms_B550: LDA #$01 ; donor $b550
Ms_B552: SBC #$00 ; donor $b552
Ms_B554: STA MsState+$005c ; donor $b554
Ms_B556: LDA MsState+$005b ; donor $b556
Ms_B558: CLC ; donor $b558
Ms_B559: ADC MsState+$007d ; donor $b559
Ms_B55B: STA MsState+$005b ; donor $b55b
Ms_B55D: LDA MsState+$005c ; donor $b55d
Ms_B55F: ADC MsState+$007e ; donor $b55f
Ms_B561: STA MsState+$005c ; donor $b561
Ms_B563: LSR A ; donor $b563
Ms_B564: bne Ms_B588 ; donor $b564
Ms_B566: STA MsState+$005c ; donor $b566
Ms_B568: ROR MsState+$005b ; donor $b568
Ms_B56A: LDY MsState+$0050 ; donor $b56a
Ms_B56C: beq Ms_B578 ; donor $b56c
Ms_B56E: LDA MsState+$005b ; donor $b56e
Ms_B570: CMP #$f0 ; donor $b570
Ms_B572: bcc Ms_B578 ; donor $b572
Ms_B574: SBC #$f0 ; donor $b574
Ms_B576: STA MsState+$005b ; donor $b576
Ms_B578: JSR MsExternal_FF1E ; donor $b578
Ms_B57B: LDY #$00 ; donor $b57b
Ms_B57D: LDA (MsPointer),Y ; donor $b57d
Ms_B57F: AND #$e0 ; donor $b57f
Ms_B581: CMP #$e0 ; donor $b581
Ms_B583: bne Ms_B588 ; donor $b583
Ms_B585: JMP Ms_B58A ; donor $b585
Ms_B588: CLC ; donor $b588
Ms_B589: RTS ; donor $b589
Ms_B58A: LDA MsState+$0558 ; donor $b58a
Ms_B58D: bmi Ms_B5A2 ; donor $b58d
Ms_B58F: beq Ms_B588 ; donor $b58f
Ms_B591: STA MsState+$005f ; donor $b591
Ms_B593: LDA MsState+$0059 ; donor $b593
Ms_B595: AND #$0f ; donor $b595
Ms_B597: CLC ; donor $b597
Ms_B598: ADC #$01 ; donor $b598
Ms_B59A: CMP MsState+$005f ; donor $b59a
Ms_B59C: beq Ms_B5B0 ; donor $b59c
Ms_B59E: bcc Ms_B5B0 ; donor $b59e
Ms_B5A0: CLC ; donor $b5a0
Ms_B5A1: RTS ; donor $b5a1
Ms_B5A2: ORA #$f0 ; donor $b5a2
Ms_B5A4: STA MsState+$005f ; donor $b5a4
Ms_B5A6: LDA MsState+$0059 ; donor $b5a6
Ms_B5A8: ORA #$f0 ; donor $b5a8
Ms_B5AA: CMP MsState+$005f ; donor $b5aa
Ms_B5AC: bcs Ms_B5B0 ; donor $b5ac
Ms_B5AE: CLC ; donor $b5ae
Ms_B5AF: RTS ; donor $b5af
Ms_B5B0: LDY #$00 ; donor $b5b0
Ms_B5B2: LDA #$80 ; donor $b5b2
Ms_B5B4: STA MsState+$0618 ; donor $b5b4
Ms_B5B7: JSR MsExternal_FF33 ; donor $b5b7
Ms_B5BA: SEC ; donor $b5ba
Ms_B5BB: RTS ; donor $b5bb
Ms_B5BC: LDX #$00 ; donor $b5bc
Ms_B5BE: LDA MsState+$0734 ; donor $b5be
Ms_B5C1: bpl Ms_B5C4 ; donor $b5c1
Ms_B5C3: INX ; donor $b5c3
Ms_B5C4: LDA #$00 ; donor $b5c4
Ms_B5C6: STA MsState+$043d ; donor $b5c6
Ms_B5C9: STA MsState+$0630 ; donor $b5c9
Ms_B5CC: STA MsState+$0072 ; donor $b5cc
Ms_B5CE: LDA MsState+$0031 ; donor $b5ce
Ms_B5D0: AND #$f0 ; donor $b5d0
Ms_B5D2: bne Ms_B5FC ; donor $b5d2
Ms_B5D4: LDA MsState+$0754 ; donor $b5d4
Ms_B5D7: bmi Ms_B5FC ; donor $b5d7
Ms_B5D9: LDA MsState+$04e0 ; donor $b5d9
Ms_B5DC: CMP #$07 ; donor $b5dc
Ms_B5DE: bne Ms_B5E7 ; donor $b5de
Ms_B5E0: LDA MsState+$04f8 ; donor $b5e0
Ms_B5E3: CMP #$03 ; donor $b5e3
Ms_B5E5: bne Ms_B5F8 ; donor $b5e5
Ms_B5E7: LDA #$07 ; donor $b5e7
Ms_B5E9: STA MsState+$04e0 ; donor $b5e9
Ms_B5EC: LDA #$00 ; donor $b5ec
Ms_B5EE: STA MsState+$04f8 ; donor $b5ee
Ms_B5F1: LDA #$80 ; donor $b5f1
Ms_B5F3: STA MsState+$0588 ; donor $b5f3
Ms_B5F6: bne Ms_B5FC ; donor $b5f6
Ms_B5F8: CMP #$06 ; donor $b5f8
Ms_B5FA: bcs Ms_B5E7 ; donor $b5fa
Ms_B5FC: LDY MsState+$0734 ; donor $b5fc
Ms_B5FF: bmi Ms_B62D ; donor $b5ff
Ms_B601: LDA MsState+$05e8 ; donor $b601
Ms_B604: ORA #$20 ; donor $b604
Ms_B606: STA MsState+$05e8 ; donor $b606
Ms_B609: LDA #$04 ; donor $b609
Ms_B60B: STA MsState+$0073 ; donor $b60b
Ms_B60D: LDA MsState+$04b0 ; donor $b60d
Ms_B610: CLC ; donor $b610
Ms_B611: ADC #$01 ; donor $b611
Ms_B613: STA MsState+$005b ; donor $b613
Ms_B615: LDA MsState+$04c8 ; donor $b615
Ms_B618: ADC #$00 ; donor $b618
Ms_B61A: STA MsState+$005c ; donor $b61a
Ms_B61C: LDA MsState+$0050 ; donor $b61c
Ms_B61E: beq Ms_B656 ; donor $b61e
Ms_B620: LDA MsState+$005b ; donor $b620
Ms_B622: CMP #$f0 ; donor $b622
Ms_B624: bcc Ms_B656 ; donor $b624
Ms_B626: LDA #$00 ; donor $b626
Ms_B628: STA MsState+$005b ; donor $b628
Ms_B62A: JMP Ms_B656 ; donor $b62a
Ms_B62D: LDA #$02 ; donor $b62d
Ms_B62F: STA MsState+$0073 ; donor $b62f
Ms_B631: LDA MsState+$05e8 ; donor $b631
Ms_B634: ORA #$10 ; donor $b634
Ms_B636: STA MsState+$05e8 ; donor $b636
Ms_B639: LDA MsState+$04b0 ; donor $b639
Ms_B63C: SEC ; donor $b63c
Ms_B63D: SBC #$01 ; donor $b63d
Ms_B63F: STA MsState+$005b ; donor $b63f
Ms_B641: LDA MsState+$04c8 ; donor $b641
Ms_B644: SBC #$00 ; donor $b644
Ms_B646: STA MsState+$005c ; donor $b646
Ms_B648: LDA MsState+$0050 ; donor $b648
Ms_B64A: beq Ms_B656 ; donor $b64a
Ms_B64C: LDA MsState+$005b ; donor $b64c
Ms_B64E: CMP #$ff ; donor $b64e
Ms_B650: bne Ms_B656 ; donor $b650
Ms_B652: LDA #$ef ; donor $b652
Ms_B654: STA MsState+$005b ; donor $b654
Ms_B656: LDA Ms_FECE,X ; donor $b656
Ms_B659: CLC ; donor $b659
Ms_B65A: ADC MsState+$005b ; donor $b65a
Ms_B65C: STA MsState+$005b ; donor $b65c
Ms_B65E: LDY MsState+$0050 ; donor $b65e
Ms_B660: beq Ms_B674 ; donor $b660
Ms_B662: bcc Ms_B666 ; donor $b662
Ms_B664: SBC #$f0 ; donor $b664
Ms_B666: CMP #$f0 ; donor $b666
Ms_B668: bcc Ms_B66C ; donor $b668
Ms_B66A: SBC #$f0 ; donor $b66a
Ms_B66C: STA MsState+$005b ; donor $b66c
Ms_B66E: LDA #$00 ; donor $b66e
Ms_B670: STA MsState+$005c ; donor $b670
Ms_B672: beq Ms_B678 ; donor $b672
Ms_B674: bcc Ms_B678 ; donor $b674
Ms_B676: INC MsState+$005c ; donor $b676
Ms_B678: LDA MsState+$0480 ; donor $b678
Ms_B67B: CLC ; donor $b67b
Ms_B67C: ADC Ms_FEC8,X ; donor $b67c
Ms_B67F: STA MsState+$0059 ; donor $b67f
Ms_B681: STA MsState+$007b ; donor $b681
Ms_B683: LDA MsState+$0498 ; donor $b683
Ms_B686: ADC #$00 ; donor $b686
Ms_B688: STA MsState+$005a ; donor $b688
Ms_B68A: STA MsState+$007c ; donor $b68a
Ms_B68C: JSR MsExternal_FF1E ; donor $b68c
Ms_B68F: LDY #$00 ; donor $b68f
Ms_B691: LDA (MsPointer),Y ; donor $b691
Ms_B693: PHA ; donor $b693
Ms_B694: bpl Ms_B698 ; donor $b694
Ms_B696: INC MsState+$0072 ; donor $b696
Ms_B698: LDA MsState+$0480 ; donor $b698
Ms_B69B: CLC ; donor $b69b
Ms_B69C: ADC Ms_FECC,X ; donor $b69c
Ms_B69F: STA MsState+$0059 ; donor $b69f
Ms_B6A1: LDA MsState+$0498 ; donor $b6a1
Ms_B6A4: ADC #$00 ; donor $b6a4
Ms_B6A6: STA MsState+$005a ; donor $b6a6
Ms_B6A8: JSR MsExternal_FF1E ; donor $b6a8
Ms_B6AB: LDY #$00 ; donor $b6ab
Ms_B6AD: LDA (MsPointer),Y ; donor $b6ad
Ms_B6AF: PHA ; donor $b6af
Ms_B6B0: bpl Ms_B6B4 ; donor $b6b0
Ms_B6B2: INC MsState+$0072 ; donor $b6b2
Ms_B6B4: LDA MsState+$007b ; donor $b6b4
Ms_B6B6: CLC ; donor $b6b6
Ms_B6B7: ADC MsState+$0059 ; donor $b6b7
Ms_B6B9: STA MsState+$0059 ; donor $b6b9
Ms_B6BB: LDA MsState+$007c ; donor $b6bb
Ms_B6BD: ADC MsState+$005a ; donor $b6bd
Ms_B6BF: LSR A ; donor $b6bf
Ms_B6C0: STA MsState+$005a ; donor $b6c0
Ms_B6C2: ROR MsState+$0059 ; donor $b6c2
Ms_B6C4: JSR MsExternal_FF1E ; donor $b6c4
Ms_B6C7: LDY #$00 ; donor $b6c7
Ms_B6C9: LDA (MsPointer),Y ; donor $b6c9
Ms_B6CB: bpl Ms_B6CF ; donor $b6cb
Ms_B6CD: INC MsState+$0072 ; donor $b6cd
Ms_B6CF: AND MsState+$0073 ; donor $b6cf
Ms_B6D1: beq Ms_B6D8 ; donor $b6d1
Ms_B6D3: PLA ; donor $b6d3
Ms_B6D4: PLA ; donor $b6d4
Ms_B6D5: JMP Ms_B6E6 ; donor $b6d5
Ms_B6D8: PLA ; donor $b6d8
Ms_B6D9: AND MsState+$0073 ; donor $b6d9
Ms_B6DB: beq Ms_B6E1 ; donor $b6db
Ms_B6DD: PLA ; donor $b6dd
Ms_B6DE: JMP Ms_B6E6 ; donor $b6de
Ms_B6E1: PLA ; donor $b6e1
Ms_B6E2: AND MsState+$0073 ; donor $b6e2
Ms_B6E4: beq Ms_B739 ; donor $b6e4
Ms_B6E6: LDA MsState+$0648 ; donor $b6e6
Ms_B6E9: bmi Ms_B739 ; donor $b6e9
Ms_B6EB: LDA MsState+$0660 ; donor $b6eb
Ms_B6EE: bmi Ms_B72F ; donor $b6ee
Ms_B6F0: LDA MsState+$05d0 ; donor $b6f0
Ms_B6F3: beq Ms_B71B ; donor $b6f3
Ms_B6F5: LDA #$80 ; donor $b6f5
Ms_B6F7: STA MsState+$0648 ; donor $b6f7
Ms_B6FA: STA MsState+$0510 ; donor $b6fa
Ms_B6FD: LDA MsState+$0034 ; donor $b6fd
Ms_B6FF: STA MsState+$0750 ; donor $b6ff
Ms_B702: LDA MsState+$0035 ; donor $b702
Ms_B704: STA MsState+$0751 ; donor $b704
Ms_B707: LDA #$02 ; donor $b707
Ms_B709: STA MsState+$0034 ; donor $b709
Ms_B70B: STA MsState+$074c ; donor $b70b
Ms_B70E: LDA #$00 ; donor $b70e
Ms_B710: STA MsState+$0035 ; donor $b710
Ms_B712: STA MsState+$0033 ; donor $b712
Ms_B714: STA MsState+$0070 ; donor $b714
Ms_B716: STA MsState+$06c4 ; donor $b716
Ms_B719: beq Ms_B739 ; donor $b719
Ms_B71B: LDA #$02 ; donor $b71b
Ms_B71D: STA MsState+$0034 ; donor $b71d
Ms_B71F: STA MsState+$074c ; donor $b71f
Ms_B722: LDA #$08 ; donor $b722
Ms_B724: STA MsState+$07e7 ; donor $b724
Ms_B727: LDA #$00 ; donor $b727
Ms_B729: STA MsState+$0035 ; donor $b729
Ms_B72B: STA MsState+$0033 ; donor $b72b
Ms_B72D: beq Ms_B739 ; donor $b72d
Ms_B72F: LDA MsState+$0540 ; donor $b72f
Ms_B732: AND #$f0 ; donor $b732
Ms_B734: ORA #$01 ; donor $b734
Ms_B736: STA MsState+$0540 ; donor $b736
Ms_B739: LDA MsState+$0072 ; donor $b739
Ms_B73B: beq Ms_B73E ; donor $b73b
Ms_B73D: RTS ; donor $b73d
Ms_B73E: LDA #$1a ; donor $b73e
Ms_B740: STA MsState+$05b8 ; donor $b740
Ms_B743: RTS ; donor $b743
Ms_B744: LDX #$00 ; donor $b744
Ms_B746: LDA MsState+$0734 ; donor $b746
Ms_B749: bpl Ms_B750 ; donor $b749
Ms_B74B: INX ; donor $b74b
Ms_B74C: LDA #$40 ; donor $b74c
Ms_B74E: bne Ms_B752 ; donor $b74e
Ms_B750: LDA #$20 ; donor $b750
Ms_B752: STA MsState+$007f ; donor $b752
Ms_B754: LDA MsState+$05b8 ; donor $b754
Ms_B757: beq Ms_B769 ; donor $b757
Ms_B759: LDY MsState+$0050 ; donor $b759
Ms_B75B: bpl Ms_B765 ; donor $b75b
Ms_B75D: JSR Ms_BC8A ; donor $b75d
Ms_B760: LDA MsState+$05b8 ; donor $b760
Ms_B763: beq Ms_B769 ; donor $b763
Ms_B765: CMP #$1a ; donor $b765
Ms_B767: bcc Ms_B76F ; donor $b767
Ms_B769: JSR Ms_B7D4 ; donor $b769
Ms_B76C: bcs Ms_B774 ; donor $b76c
Ms_B76E: RTS ; donor $b76e
Ms_B76F: JSR Ms_B8B2 ; donor $b76f
Ms_B772: bcc Ms_B7D3 ; donor $b772
Ms_B774: LDA MsState+$05b8 ; donor $b774
Ms_B777: beq Ms_B77D ; donor $b777
Ms_B779: CMP #$1a ; donor $b779
Ms_B77B: bcc Ms_B798 ; donor $b77b
Ms_B77D: LDA MsState+$005b ; donor $b77d
Ms_B77F: SEC ; donor $b77f
Ms_B780: SBC Ms_FECE,X ; donor $b780
Ms_B783: STA MsState+$04b0 ; donor $b783
Ms_B786: LDY MsState+$0050 ; donor $b786
Ms_B788: beq Ms_B7A5 ; donor $b788
Ms_B78A: bcs Ms_B78E ; donor $b78a
Ms_B78C: ADC #$f0 ; donor $b78c
Ms_B78E: CMP #$f0 ; donor $b78e
Ms_B790: bcc Ms_B792 ; donor $b790
Ms_B792: STA MsState+$04b0 ; donor $b792
Ms_B795: JMP Ms_B7AC ; donor $b795
Ms_B798: LDA MsState+$005b ; donor $b798
Ms_B79A: SEC ; donor $b79a
Ms_B79B: SBC Ms_FECA,X ; donor $b79b
Ms_B79E: STA MsState+$04b0 ; donor $b79e
Ms_B7A1: LDY MsState+$0050 ; donor $b7a1
Ms_B7A3: bne Ms_B78A ; donor $b7a3
Ms_B7A5: LDA MsState+$005c ; donor $b7a5
Ms_B7A7: SBC #$00 ; donor $b7a7
Ms_B7A9: STA MsState+$04c8 ; donor $b7a9
Ms_B7AC: LDY #$00 ; donor $b7ac
Ms_B7AE: STY MsState+$0570 ; donor $b7ae
Ms_B7B1: LDA MsState+$05b8 ; donor $b7b1
Ms_B7B4: beq Ms_B7CB ; donor $b7b4
Ms_B7B6: CMP #$1e ; donor $b7b6
Ms_B7B8: bcc Ms_B7C6 ; donor $b7b8
Ms_B7BA: beq Ms_B7C6 ; donor $b7ba
Ms_B7BC: STY MsState+$05b8 ; donor $b7bc
Ms_B7BF: LDA #$07 ; donor $b7bf
Ms_B7C1: STA MsState+$07e3 ; donor $b7c1
Ms_B7C4: bne Ms_B7CB ; donor $b7c4
Ms_B7C6: LDA #$1e ; donor $b7c6
Ms_B7C8: STA MsState+$05b8 ; donor $b7c8
Ms_B7CB: LDA MsState+$0735 ; donor $b7cb
Ms_B7CE: AND #$cf ; donor $b7ce
Ms_B7D0: STA MsState+$0735 ; donor $b7d0
Ms_B7D3: RTS ; donor $b7d3
Ms_B7D4: LDA MsState+$04b0 ; donor $b7d4
Ms_B7D7: CLC ; donor $b7d7
Ms_B7D8: ADC Ms_FECE,X ; donor $b7d8
Ms_B7DB: STA MsState+$005b ; donor $b7db
Ms_B7DD: LDY MsState+$0050 ; donor $b7dd
Ms_B7DF: beq Ms_B7EA ; donor $b7df
Ms_B7E1: JSR MsExternal_FF3F ; donor $b7e1
Ms_B7E4: LDA #$00 ; donor $b7e4
Ms_B7E6: STA MsState+$005c ; donor $b7e6
Ms_B7E8: beq Ms_B7F9 ; donor $b7e8
Ms_B7EA: LDA MsState+$04c8 ; donor $b7ea
Ms_B7ED: ADC #$00 ; donor $b7ed
Ms_B7EF: STA MsState+$005c ; donor $b7ef
Ms_B7F1: bne Ms_B854 ; donor $b7f1
Ms_B7F3: LDA MsState+$005b ; donor $b7f3
Ms_B7F5: CMP #$f0 ; donor $b7f5
Ms_B7F7: bcs Ms_B854 ; donor $b7f7
Ms_B7F9: LDA MsState+$0480 ; donor $b7f9
Ms_B7FC: CLC ; donor $b7fc
Ms_B7FD: ADC Ms_FEC8,X ; donor $b7fd
Ms_B800: STA MsState+$0059 ; donor $b800
Ms_B802: STA MsState+$007b ; donor $b802
Ms_B804: LDA MsState+$0498 ; donor $b804
Ms_B807: ADC #$00 ; donor $b807
Ms_B809: STA MsState+$005a ; donor $b809
Ms_B80B: STA MsState+$007c ; donor $b80b
Ms_B80D: JSR MsExternal_FF1E ; donor $b80d
Ms_B810: LDY #$00 ; donor $b810
Ms_B812: LDA (MsPointer),Y ; donor $b812
Ms_B814: bpl Ms_B81C ; donor $b814
Ms_B816: JSR Ms_B859 ; donor $b816
Ms_B819: bcc Ms_B81C ; donor $b819
Ms_B81B: RTS ; donor $b81b
Ms_B81C: LDA MsState+$0480 ; donor $b81c
Ms_B81F: CLC ; donor $b81f
Ms_B820: ADC Ms_FECC,X ; donor $b820
Ms_B823: STA MsState+$0059 ; donor $b823
Ms_B825: LDA MsState+$0498 ; donor $b825
Ms_B828: ADC #$00 ; donor $b828
Ms_B82A: STA MsState+$005a ; donor $b82a
Ms_B82C: JSR MsExternal_FF1E ; donor $b82c
Ms_B82F: LDY #$00 ; donor $b82f
Ms_B831: LDA (MsPointer),Y ; donor $b831
Ms_B833: bpl Ms_B83B ; donor $b833
Ms_B835: JSR Ms_B859 ; donor $b835
Ms_B838: bcc Ms_B83B ; donor $b838
Ms_B83A: RTS ; donor $b83a
Ms_B83B: LDA MsState+$0059 ; donor $b83b
Ms_B83D: CLC ; donor $b83d
Ms_B83E: ADC MsState+$007b ; donor $b83e
Ms_B840: STA MsState+$0059 ; donor $b840
Ms_B842: LDA MsState+$005a ; donor $b842
Ms_B844: ADC MsState+$007c ; donor $b844
Ms_B846: LSR A ; donor $b846
Ms_B847: STA MsState+$005a ; donor $b847
Ms_B849: ROR MsState+$0059 ; donor $b849
Ms_B84B: JSR MsExternal_FF1E ; donor $b84b
Ms_B84E: LDY #$00 ; donor $b84e
Ms_B850: LDA (MsPointer),Y ; donor $b850
Ms_B852: bmi Ms_B859 ; donor $b852
Ms_B854: CLC ; donor $b854
Ms_B855: RTS ; donor $b855
Ms_B856: JSR Ms_BA02 ; donor $b856
Ms_B859: LDA MsState+$005c ; donor $b859
Ms_B85B: STA MsState+$0073 ; donor $b85b
Ms_B85D: LDA MsState+$005b ; donor $b85d
Ms_B85F: STA MsState+$0072 ; donor $b85f
Ms_B861: LDY #$00 ; donor $b861
Ms_B863: JSR MsExternal_FF36 ; donor $b863
Ms_B866: LDY MsState+$0050 ; donor $b866
Ms_B868: bne Ms_B88C ; donor $b868
Ms_B86A: LDA MsState+$0072 ; donor $b86a
Ms_B86C: SEC ; donor $b86c
Ms_B86D: SBC MsState+$005b ; donor $b86d
Ms_B86F: LDY MsState+$0570 ; donor $b86f
Ms_B872: bmi Ms_B87D ; donor $b872
Ms_B874: CMP MsState+$0570 ; donor $b874
Ms_B877: beq Ms_B87B ; donor $b877
Ms_B879: bcs Ms_B882 ; donor $b879
Ms_B87B: SEC ; donor $b87b
Ms_B87C: RTS ; donor $b87c
Ms_B87D: CMP MsState+$0570 ; donor $b87d
Ms_B880: bcs Ms_B87B ; donor $b880
Ms_B882: LDA MsState+$0072 ; donor $b882
Ms_B884: STA MsState+$005b ; donor $b884
Ms_B886: LDA MsState+$0073 ; donor $b886
Ms_B888: STA MsState+$005c ; donor $b888
Ms_B88A: CLC ; donor $b88a
Ms_B88B: RTS ; donor $b88b
Ms_B88C: LDA MsState+$0570 ; donor $b88c
Ms_B88F: bmi Ms_B8A4 ; donor $b88f
Ms_B891: STA MsState+$0071 ; donor $b891
Ms_B893: LDA MsState+$0072 ; donor $b893
Ms_B895: SEC ; donor $b895
Ms_B896: SBC MsState+$005b ; donor $b896
Ms_B898: bcs Ms_B89C ; donor $b898
Ms_B89A: ADC #$f0 ; donor $b89a
Ms_B89C: CMP MsState+$0071 ; donor $b89c
Ms_B89E: beq Ms_B87B ; donor $b89e
Ms_B8A0: bcs Ms_B882 ; donor $b8a0
Ms_B8A2: SEC ; donor $b8a2
Ms_B8A3: RTS ; donor $b8a3
Ms_B8A4: EOR #$ff ; donor $b8a4
Ms_B8A6: STA MsState+$0071 ; donor $b8a6
Ms_B8A8: INC MsState+$0071 ; donor $b8a8
Ms_B8AA: LDA MsState+$005b ; donor $b8aa
Ms_B8AC: SEC ; donor $b8ac
Ms_B8AD: SBC MsState+$0072 ; donor $b8ad
Ms_B8AF: JMP Ms_B898 ; donor $b8af
Ms_B8B2: LDA MsState+$04b0 ; donor $b8b2
Ms_B8B5: CLC ; donor $b8b5
Ms_B8B6: ADC Ms_FECA,X ; donor $b8b6
Ms_B8B9: STA MsState+$005b ; donor $b8b9
Ms_B8BB: LDY MsState+$0050 ; donor $b8bb
Ms_B8BD: beq Ms_B8C8 ; donor $b8bd
Ms_B8BF: JSR MsExternal_FF3F ; donor $b8bf
Ms_B8C2: LDA #$00 ; donor $b8c2
Ms_B8C4: STA MsState+$005c ; donor $b8c4
Ms_B8C6: beq Ms_B8D7 ; donor $b8c6
Ms_B8C8: LDA MsState+$04c8 ; donor $b8c8
Ms_B8CB: ADC #$00 ; donor $b8cb
Ms_B8CD: STA MsState+$005c ; donor $b8cd
Ms_B8CF: bne Ms_B93B ; donor $b8cf
Ms_B8D1: LDA MsState+$005b ; donor $b8d1
Ms_B8D3: CMP #$f0 ; donor $b8d3
Ms_B8D5: bcs Ms_B93B ; donor $b8d5
Ms_B8D7: LDA MsState+$0480 ; donor $b8d7
Ms_B8DA: CLC ; donor $b8da
Ms_B8DB: ADC Ms_FEC8,X ; donor $b8db
Ms_B8DE: STA MsState+$0059 ; donor $b8de
Ms_B8E0: STA MsState+$007b ; donor $b8e0
Ms_B8E2: LDA MsState+$0498 ; donor $b8e2
Ms_B8E5: ADC #$00 ; donor $b8e5
Ms_B8E7: STA MsState+$005a ; donor $b8e7
Ms_B8E9: STA MsState+$007c ; donor $b8e9
Ms_B8EB: JSR MsExternal_FF1E ; donor $b8eb
Ms_B8EE: LDY #$00 ; donor $b8ee
Ms_B8F0: LDA (MsPointer),Y ; donor $b8f0
Ms_B8F2: AND MsState+$007f ; donor $b8f2
Ms_B8F4: beq Ms_B8FC ; donor $b8f4
Ms_B8F6: JSR Ms_B856 ; donor $b8f6
Ms_B8F9: bcc Ms_B8FC ; donor $b8f9
Ms_B8FB: RTS ; donor $b8fb
Ms_B8FC: LDA MsState+$0480 ; donor $b8fc
Ms_B8FF: CLC ; donor $b8ff
Ms_B900: ADC Ms_FECC,X ; donor $b900
Ms_B903: STA MsState+$0059 ; donor $b903
Ms_B905: LDA MsState+$0498 ; donor $b905
Ms_B908: ADC #$00 ; donor $b908
Ms_B90A: STA MsState+$005a ; donor $b90a
Ms_B90C: JSR MsExternal_FF1E ; donor $b90c
Ms_B90F: LDY #$00 ; donor $b90f
Ms_B911: LDA (MsPointer),Y ; donor $b911
Ms_B913: AND MsState+$007f ; donor $b913
Ms_B915: beq Ms_B91D ; donor $b915
Ms_B917: JSR Ms_B856 ; donor $b917
Ms_B91A: bcc Ms_B91D ; donor $b91a
Ms_B91C: RTS ; donor $b91c
Ms_B91D: LDA MsState+$0059 ; donor $b91d
Ms_B91F: CLC ; donor $b91f
Ms_B920: ADC MsState+$007b ; donor $b920
Ms_B922: STA MsState+$0059 ; donor $b922
Ms_B924: LDA MsState+$005a ; donor $b924
Ms_B926: ADC MsState+$007c ; donor $b926
Ms_B928: LSR A ; donor $b928
Ms_B929: STA MsState+$005a ; donor $b929
Ms_B92B: ROR MsState+$0059 ; donor $b92b
Ms_B92D: JSR MsExternal_FF1E ; donor $b92d
Ms_B930: LDY #$00 ; donor $b930
Ms_B932: LDA (MsPointer),Y ; donor $b932
Ms_B934: AND MsState+$007f ; donor $b934
Ms_B936: beq Ms_B93B ; donor $b936
Ms_B938: JMP Ms_B856 ; donor $b938
Ms_B93B: CLC ; donor $b93b
Ms_B93C: RTS ; donor $b93c
Ms_B93D: JSR Ms_B955 ; donor $b93d
Ms_B940: bcc Ms_B954 ; donor $b940
Ms_B942: LDA MsState+$006b ; donor $b942
Ms_B944: bmi Ms_B94A ; donor $b944
Ms_B946: LDA #$10 ; donor $b946
Ms_B948: bne Ms_B94C ; donor $b948
Ms_B94A: LDA #$20 ; donor $b94a
Ms_B94C: AND MsState+$05e8 ; donor $b94c
Ms_B94F: beq Ms_B954 ; donor $b94f
Ms_B951: JMP Ms_BA4E ; donor $b951
Ms_B954: RTS ; donor $b954
Ms_B955: LDX #$00 ; donor $b955
Ms_B957: LDA MsState+$006b ; donor $b957
Ms_B959: bmi Ms_B95C ; donor $b959
Ms_B95B: INX ; donor $b95b
Ms_B95C: LDA MsState+$04b0 ; donor $b95c
Ms_B95F: CLC ; donor $b95f
Ms_B960: ADC Ms_FECA,X ; donor $b960
Ms_B963: STA MsState+$005b ; donor $b963
Ms_B965: LDY MsState+$0050 ; donor $b965
Ms_B967: beq Ms_B972 ; donor $b967
Ms_B969: JSR MsExternal_FF3F ; donor $b969
Ms_B96C: LDA #$00 ; donor $b96c
Ms_B96E: STA MsState+$005c ; donor $b96e
Ms_B970: beq Ms_B981 ; donor $b970
Ms_B972: LDA MsState+$04c8 ; donor $b972
Ms_B975: ADC #$00 ; donor $b975
Ms_B977: STA MsState+$005c ; donor $b977
Ms_B979: jne Ms_B9EE ; donor $b979
Ms_B97B: LDA MsState+$005b ; donor $b97b
Ms_B97D: CMP #$f0 ; donor $b97d
Ms_B97F: bcs Ms_B9EE ; donor $b97f
Ms_B981: LDA MsState+$0480 ; donor $b981
Ms_B984: CLC ; donor $b984
Ms_B985: ADC Ms_FEC8,X ; donor $b985
Ms_B988: STA MsState+$0059 ; donor $b988
Ms_B98A: STA MsState+$007b ; donor $b98a
Ms_B98C: LDA MsState+$0498 ; donor $b98c
Ms_B98F: ADC #$00 ; donor $b98f
Ms_B991: STA MsState+$005a ; donor $b991
Ms_B993: STA MsState+$007c ; donor $b993
Ms_B995: JSR MsExternal_FF1E ; donor $b995
Ms_B998: LDY #$00 ; donor $b998
Ms_B99A: LDA (MsPointer),Y ; donor $b99a
Ms_B99C: AND MsState+$007f ; donor $b99c
Ms_B99E: beq Ms_B9A9 ; donor $b99e
Ms_B9A0: JSR Ms_B9F0 ; donor $b9a0
Ms_B9A3: JSR Ms_B859 ; donor $b9a3
Ms_B9A6: bcc Ms_B9A9 ; donor $b9a6
Ms_B9A8: RTS ; donor $b9a8
Ms_B9A9: LDA MsState+$0480 ; donor $b9a9
Ms_B9AC: CLC ; donor $b9ac
Ms_B9AD: ADC Ms_FECC,X ; donor $b9ad
Ms_B9B0: STA MsState+$0059 ; donor $b9b0
Ms_B9B2: LDA MsState+$0498 ; donor $b9b2
Ms_B9B5: ADC #$00 ; donor $b9b5
Ms_B9B7: STA MsState+$005a ; donor $b9b7
Ms_B9B9: JSR MsExternal_FF1E ; donor $b9b9
Ms_B9BC: LDY #$00 ; donor $b9bc
Ms_B9BE: LDA (MsPointer),Y ; donor $b9be
Ms_B9C0: AND MsState+$007f ; donor $b9c0
Ms_B9C2: beq Ms_B9CD ; donor $b9c2
Ms_B9C4: JSR Ms_B9F0 ; donor $b9c4
Ms_B9C7: JSR Ms_B859 ; donor $b9c7
Ms_B9CA: bcc Ms_B9CD ; donor $b9ca
Ms_B9CC: RTS ; donor $b9cc
Ms_B9CD: LDA MsState+$0059 ; donor $b9cd
Ms_B9CF: CLC ; donor $b9cf
Ms_B9D0: ADC MsState+$007b ; donor $b9d0
Ms_B9D2: STA MsState+$0059 ; donor $b9d2
Ms_B9D4: LDA MsState+$005a ; donor $b9d4
Ms_B9D6: ADC MsState+$007c ; donor $b9d6
Ms_B9D8: LSR A ; donor $b9d8
Ms_B9D9: STA MsState+$005a ; donor $b9d9
Ms_B9DB: ROR MsState+$0059 ; donor $b9db
Ms_B9DD: JSR MsExternal_FF1E ; donor $b9dd
Ms_B9E0: LDY #$00 ; donor $b9e0
Ms_B9E2: LDA (MsPointer),Y ; donor $b9e2
Ms_B9E4: AND MsState+$007f ; donor $b9e4
Ms_B9E6: beq Ms_B9EE ; donor $b9e6
Ms_B9E8: JSR Ms_B9F0 ; donor $b9e8
Ms_B9EB: JMP Ms_B859 ; donor $b9eb
Ms_B9EE: CLC ; donor $b9ee
Ms_B9EF: RTS ; donor $b9ef
Ms_B9F0: LDY #$00 ; donor $b9f0
Ms_B9F2: LDA (MsPointer),Y ; donor $b9f2
Ms_B9F4: AND #$06 ; donor $b9f4
Ms_B9F6: beq Ms_BA01 ; donor $b9f6
Ms_B9F8: AND #$04 ; donor $b9f8
Ms_B9FA: bne Ms_BA15 ; donor $b9fa
Ms_B9FC: LDA MsState+$0734 ; donor $b9fc
Ms_B9FF: bmi Ms_BA1A ; donor $b9ff
Ms_BA01: RTS ; donor $ba01
Ms_BA02: LDY #$00 ; donor $ba02
Ms_BA04: LDA (MsPointer),Y ; donor $ba04
Ms_BA06: AND #$06 ; donor $ba06
Ms_BA08: beq Ms_BA4D ; donor $ba08
Ms_BA0A: AND #$02 ; donor $ba0a
Ms_BA0C: bne Ms_BA15 ; donor $ba0c
Ms_BA0E: LDA MsState+$0734 ; donor $ba0e
Ms_BA11: bpl Ms_BA4D ; donor $ba11
Ms_BA13: bmi Ms_BA1A ; donor $ba13
Ms_BA15: LDA MsState+$0734 ; donor $ba15
Ms_BA18: bmi Ms_BA4D ; donor $ba18
Ms_BA1A: LDA MsState+$0648 ; donor $ba1a
Ms_BA1D: bmi Ms_BA4D ; donor $ba1d
Ms_BA1F: LDA MsState+$0660 ; donor $ba1f
Ms_BA22: bmi Ms_BA66 ; donor $ba22
Ms_BA24: LDA MsState+$05d0 ; donor $ba24
Ms_BA27: beq Ms_BA53 ; donor $ba27
Ms_BA29: LDA #$80 ; donor $ba29
Ms_BA2B: STA MsState+$0648 ; donor $ba2b
Ms_BA2E: STA MsState+$0510 ; donor $ba2e
Ms_BA31: LDA MsState+$0034 ; donor $ba31
Ms_BA33: STA MsState+$0750 ; donor $ba33
Ms_BA36: LDA MsState+$0035 ; donor $ba36
Ms_BA38: STA MsState+$0751 ; donor $ba38
Ms_BA3B: LDA #$02 ; donor $ba3b
Ms_BA3D: STA MsState+$0034 ; donor $ba3d
Ms_BA3F: STA MsState+$074c ; donor $ba3f
Ms_BA42: LDA #$00 ; donor $ba42
Ms_BA44: STA MsState+$0035 ; donor $ba44
Ms_BA46: STA MsState+$0033 ; donor $ba46
Ms_BA48: STA MsState+$0070 ; donor $ba48
Ms_BA4A: STA MsState+$06c4 ; donor $ba4a
Ms_BA4D: RTS ; donor $ba4d
Ms_BA4E: LDA #$00 ; donor $ba4e
Ms_BA50: STA MsState+$05d0 ; donor $ba50
Ms_BA53: LDA #$02 ; donor $ba53
Ms_BA55: STA MsState+$0034 ; donor $ba55
Ms_BA57: STA MsState+$074c ; donor $ba57
Ms_BA5A: LDA #$00 ; donor $ba5a
Ms_BA5C: STA MsState+$0035 ; donor $ba5c
Ms_BA5E: STA MsState+$0033 ; donor $ba5e
Ms_BA60: LDA #$08 ; donor $ba60
Ms_BA62: STA MsState+$07e7 ; donor $ba62
Ms_BA65: RTS ; donor $ba65
Ms_BA66: LDA MsState+$0540 ; donor $ba66
Ms_BA69: AND #$f0 ; donor $ba69
Ms_BA6B: ORA #$01 ; donor $ba6b
Ms_BA6D: STA MsState+$0540 ; donor $ba6d
Ms_BA70: RTS ; donor $ba70
Ms_BA71: STA MsState+$071d ; donor $ba71
Ms_BA74: LSR A ; donor $ba74
Ms_BA75: STA MsState+$071e ; donor $ba75
Ms_BA78: LDA #$00 ; donor $ba78
Ms_BA7A: ROR A ; donor $ba7a
Ms_BA7B: STA MsState+$005b ; donor $ba7b
Ms_BA7D: LDA MsState+$0700 ; donor $ba7d
Ms_BA80: ASL A ; donor $ba80
Ms_BA81: ASL A ; donor $ba81
Ms_BA82: ASL A ; donor $ba82
Ms_BA83: STA MsState+$071f ; donor $ba83
Ms_BA86: LDA MsState+$00ed ; donor $ba86
Ms_BA88: beq Ms_BA86 ; donor $ba88
Ms_BA8A: LDX #$00 ; donor $ba8a
Ms_BA8C: LDA #$02 ; donor $ba8c
Ms_BA8E: STA MsState+$0080,X ; donor $ba8e
Ms_BA90: INX ; donor $ba90
Ms_BA91: LDA MsState+$071d ; donor $ba91
Ms_BA94: AND #$10 ; donor $ba94
Ms_BA96: beq Ms_BA9A ; donor $ba96
Ms_BA98: LDA #$04 ; donor $ba98
Ms_BA9A: CLC ; donor $ba9a
Ms_BA9B: ADC #$20 ; donor $ba9b
Ms_BA9D: STA MsState+$0080,X ; donor $ba9d
Ms_BA9F: ORA #$03 ; donor $ba9f
Ms_BAA1: STA MsState+$002d ; donor $baa1
Ms_BAA3: INX ; donor $baa3
Ms_BAA4: LDA MsState+$071d ; donor $baa4
Ms_BAA7: AND #$0f ; donor $baa7
Ms_BAA9: ASL A ; donor $baa9
Ms_BAAA: STA MsState+$0080,X ; donor $baaa
Ms_BAAC: INX ; donor $baac
Ms_BAAD: STX MsState+$00ee ; donor $baad
Ms_BAAF: LDA MsState+$071d ; donor $baaf
Ms_BAB2: AND #$0f ; donor $bab2
Ms_BAB4: LSR A ; donor $bab4
Ms_BAB5: ORA #$c0 ; donor $bab5
Ms_BAB7: STA MsState+$002c ; donor $bab7
Ms_BAB9: JMP MsExternal_FF18 ; donor $bab9
Ms_BABC: LDA MsState+$0558 ; donor $babc
Ms_BABF: bne Ms_BACA ; donor $babf
Ms_BAC1: LDA MsState+$0031 ; donor $bac1
Ms_BAC3: ASL A ; donor $bac3
Ms_BAC4: bcs Ms_BAD9 ; donor $bac4
Ms_BAC6: ASL A ; donor $bac6
Ms_BAC7: bcs Ms_BACC ; donor $bac7
Ms_BAC9: RTS ; donor $bac9
Ms_BACA: bpl Ms_BAD9 ; donor $baca
Ms_BACC: LDA MsState+$0710 ; donor $bacc
Ms_BACF: STA MsState+$0059 ; donor $bacf
Ms_BAD1: LDA MsState+$0711 ; donor $bad1
Ms_BAD4: STA MsState+$005a ; donor $bad4
Ms_BAD6: JMP Ms_BAE8 ; donor $bad6
Ms_BAD9: LDA MsState+$0710 ; donor $bad9
Ms_BADC: CLC ; donor $badc
Ms_BADD: ADC #$08 ; donor $badd
Ms_BADF: STA MsState+$0059 ; donor $badf
Ms_BAE1: LDA MsState+$0711 ; donor $bae1
Ms_BAE4: ADC #$00 ; donor $bae4
Ms_BAE6: STA MsState+$005a ; donor $bae6
Ms_BAE8: LDA MsState+$0059 ; donor $bae8
Ms_BAEA: LSR A ; donor $baea
Ms_BAEB: LSR A ; donor $baeb
Ms_BAEC: LSR A ; donor $baec
Ms_BAED: LSR A ; donor $baed
Ms_BAEE: STA MsState+$071d ; donor $baee
Ms_BAF1: LDA MsState+$005a ; donor $baf1
Ms_BAF3: AND #$0f ; donor $baf3
Ms_BAF5: TAX ; donor $baf5
Ms_BAF6: LDA Ms_FEF0,X ; donor $baf6
Ms_BAF9: ORA MsState+$071d ; donor $baf9
Ms_BAFC: CMP MsState+$071c ; donor $bafc
Ms_BAFF: beq Ms_BB06 ; donor $baff
Ms_BB01: STA MsState+$071c ; donor $bb01
Ms_BB04: SEC ; donor $bb04
Ms_BB05: RTS ; donor $bb05
Ms_BB06: CLC ; donor $bb06
Ms_BB07: RTS ; donor $bb07
Ms_BB08: LDA MsState+$0558 ; donor $bb08
Ms_BB0B: beq Ms_BB15 ; donor $bb0b
Ms_BB0D: bmi Ms_BB12 ; donor $bb0d
Ms_BB0F: JMP Ms_B413 ; donor $bb0f
Ms_BB12: JMP Ms_B458 ; donor $bb12
Ms_BB15: RTS ; donor $bb15
Ms_BB16: LDA MsState+$04e0 ; donor $bb16
Ms_BB19: CMP #$03 ; donor $bb19
Ms_BB1B: bne Ms_BB24 ; donor $bb1b
Ms_BB1D: LDA MsState+$04f8 ; donor $bb1d
Ms_BB20: CMP #$04 ; donor $bb20
Ms_BB22: bcc Ms_BB37 ; donor $bb22
Ms_BB24: LDA #$01 ; donor $bb24
Ms_BB26: STA MsState+$0558 ; donor $bb26
Ms_BB29: LDA MsState+$0730 ; donor $bb29
Ms_BB2C: CLC ; donor $bb2c
Ms_BB2D: ADC #$80 ; donor $bb2d
Ms_BB2F: STA MsState+$0730 ; donor $bb2f
Ms_BB32: bcc Ms_BB37 ; donor $bb32
Ms_BB34: INC MsState+$0558 ; donor $bb34
Ms_BB37: LDA MsState+$0558 ; donor $bb37
Ms_BB3A: STA MsState+$004b ; donor $bb3a
Ms_BB3C: bmi Ms_BB94 ; donor $bb3c
Ms_BB3E: LDA MsState+$0480 ; donor $bb3e
Ms_BB41: CLC ; donor $bb41
Ms_BB42: ADC MsState+$0558 ; donor $bb42
Ms_BB45: STA MsState+$0480 ; donor $bb45
Ms_BB48: LDA MsState+$0498 ; donor $bb48
Ms_BB4B: ADC #$00 ; donor $bb4b
Ms_BB4D: STA MsState+$0498 ; donor $bb4d
Ms_BB50: CMP MsState+$0733 ; donor $bb50
Ms_BB53: bcc Ms_BB6B ; donor $bb53
Ms_BB55: bne Ms_BB5F ; donor $bb55
Ms_BB57: LDA MsState+$0480 ; donor $bb57
Ms_BB5A: CMP MsState+$0732 ; donor $bb5a
Ms_BB5D: bcc Ms_BB6B ; donor $bb5d
Ms_BB5F: LDA MsState+$0732 ; donor $bb5f
Ms_BB62: STA MsState+$0480 ; donor $bb62
Ms_BB65: LDA MsState+$0733 ; donor $bb65
Ms_BB68: STA MsState+$0498 ; donor $bb68
Ms_BB6B: RTS ; donor $bb6b
Ms_BB6C: LDA MsState+$04e0 ; donor $bb6c
Ms_BB6F: CMP #$03 ; donor $bb6f
Ms_BB71: bne Ms_BB7A ; donor $bb71
Ms_BB73: LDA MsState+$04f8 ; donor $bb73
Ms_BB76: CMP #$04 ; donor $bb76
Ms_BB78: bcc Ms_BB8D ; donor $bb78
Ms_BB7A: LDA #$ff ; donor $bb7a
Ms_BB7C: STA MsState+$0558 ; donor $bb7c
Ms_BB7F: LDA MsState+$0730 ; donor $bb7f
Ms_BB82: SEC ; donor $bb82
Ms_BB83: SBC #$80 ; donor $bb83
Ms_BB85: STA MsState+$0730 ; donor $bb85
Ms_BB88: bcs Ms_BB8D ; donor $bb88
Ms_BB8A: DEC MsState+$0558 ; donor $bb8a
Ms_BB8D: LDA MsState+$0558 ; donor $bb8d
Ms_BB90: STA MsState+$004b ; donor $bb90
Ms_BB92: bpl Ms_BB3E ; donor $bb92
Ms_BB94: LDA MsState+$0480 ; donor $bb94
Ms_BB97: CLC ; donor $bb97
Ms_BB98: ADC MsState+$0558 ; donor $bb98
Ms_BB9B: STA MsState+$0480 ; donor $bb9b
Ms_BB9E: bcs Ms_BBB0 ; donor $bb9e
Ms_BBA0: DEC MsState+$0498 ; donor $bba0
Ms_BBA3: bpl Ms_BBB0 ; donor $bba3
Ms_BBA5: LDA #$00 ; donor $bba5
Ms_BBA7: STA MsState+$0480 ; donor $bba7
Ms_BBAA: STA MsState+$0498 ; donor $bbaa
Ms_BBAD: STA MsState+$070f ; donor $bbad
Ms_BBB0: RTS ; donor $bbb0
Ms_BBB1: LDA MsState+$0498 ; donor $bbb1
Ms_BBB4: bne Ms_BBBD ; donor $bbb4
Ms_BBB6: LDA MsState+$0480 ; donor $bbb6
Ms_BBB9: CMP #$78 ; donor $bbb9
Ms_BBBB: bcc Ms_BC03 ; donor $bbbb
Ms_BBBD: LDA MsState+$0480 ; donor $bbbd
Ms_BBC0: SEC ; donor $bbc0
Ms_BBC1: SBC #$78 ; donor $bbc1
Ms_BBC3: STA MsState+$0710 ; donor $bbc3
Ms_BBC6: LDA MsState+$0498 ; donor $bbc6
Ms_BBC9: SBC #$00 ; donor $bbc9
Ms_BBCB: STA MsState+$0711 ; donor $bbcb
Ms_BBCE: CMP MsState+$071b ; donor $bbce
Ms_BBD1: bcc Ms_BBEE ; donor $bbd1
Ms_BBD3: bne Ms_BBDD ; donor $bbd3
Ms_BBD5: LDA MsState+$0710 ; donor $bbd5
Ms_BBD8: CMP MsState+$071a ; donor $bbd8
Ms_BBDB: bcc Ms_BBEE ; donor $bbdb
Ms_BBDD: LDA MsState+$071a ; donor $bbdd
Ms_BBE0: STA MsState+$0710 ; donor $bbe0
Ms_BBE3: LDA MsState+$071b ; donor $bbe3
Ms_BBE6: STA MsState+$0711 ; donor $bbe6
Ms_BBE9: LDA #$00 ; donor $bbe9
Ms_BBEB: STA MsState+$070f ; donor $bbeb
Ms_BBEE: JSR Ms_BABC ; donor $bbee
Ms_BBF1: bcc Ms_BC03 ; donor $bbf1
Ms_BBF3: LDA #$00 ; donor $bbf3
Ms_BBF5: STA MsState+$043b ; donor $bbf5
Ms_BBF8: LDA MsState+$071c ; donor $bbf8
Ms_BBFB: CLC ; donor $bbfb
Ms_BBFC: ADC #$11 ; donor $bbfc
Ms_BBFE: bmi Ms_BC03 ; donor $bbfe
Ms_BC00: JMP Ms_BA71 ; donor $bc00
Ms_BC03: RTS ; donor $bc03
Ms_BC04: LDA MsState+$0498 ; donor $bc04
Ms_BC07: CMP MsState+$0733 ; donor $bc07
Ms_BC0A: bne Ms_BC13 ; donor $bc0a
Ms_BC0C: LDA MsState+$0480 ; donor $bc0c
Ms_BC0F: CMP #$78 ; donor $bc0f
Ms_BC11: bcs Ms_BC43 ; donor $bc11
Ms_BC13: LDA MsState+$0480 ; donor $bc13
Ms_BC16: SEC ; donor $bc16
Ms_BC17: SBC #$78 ; donor $bc17
Ms_BC19: STA MsState+$0710 ; donor $bc19
Ms_BC1C: LDA MsState+$0498 ; donor $bc1c
Ms_BC1F: SBC #$00 ; donor $bc1f
Ms_BC21: STA MsState+$0711 ; donor $bc21
Ms_BC24: bcs Ms_BC2E ; donor $bc24
Ms_BC26: LDA #$00 ; donor $bc26
Ms_BC28: STA MsState+$0710 ; donor $bc28
Ms_BC2B: STA MsState+$0711 ; donor $bc2b
Ms_BC2E: JSR Ms_BABC ; donor $bc2e
Ms_BC31: bcc Ms_BC43 ; donor $bc31
Ms_BC33: LDA #$80 ; donor $bc33
Ms_BC35: STA MsState+$043b ; donor $bc35
Ms_BC38: LDA MsState+$071c ; donor $bc38
Ms_BC3B: beq Ms_BC40 ; donor $bc3b
Ms_BC3D: SEC ; donor $bc3d
Ms_BC3E: SBC #$01 ; donor $bc3e
Ms_BC40: JMP Ms_BA71 ; donor $bc40
Ms_BC43: RTS ; donor $bc43
Ms_BC44: LDA MsState+$004c ; donor $bc44
Ms_BC46: bpl Ms_BC4D ; donor $bc46
Ms_BC48: EOR #$ff ; donor $bc48
Ms_BC4A: CLC ; donor $bc4a
Ms_BC4B: ADC #$01 ; donor $bc4b
Ms_BC4D: STA MsState+$004a ; donor $bc4d
Ms_BC4F: LDA MsState+$006b ; donor $bc4f
Ms_BC51: bmi Ms_BC58 ; donor $bc51
Ms_BC53: LDA MsState+$006a ; donor $bc53
Ms_BC55: JMP Ms_BC5F ; donor $bc55
Ms_BC58: LDA MsState+$006a ; donor $bc58
Ms_BC5A: EOR #$ff ; donor $bc5a
Ms_BC5C: CLC ; donor $bc5c
Ms_BC5D: ADC #$01 ; donor $bc5d
Ms_BC5F: CMP MsState+$004a ; donor $bc5f
Ms_BC61: bcs Ms_BC69 ; donor $bc61
Ms_BC63: LDA MsState+$004c ; donor $bc63
Ms_BC65: bpl Ms_BC8F ; donor $bc65
Ms_BC67: bmi Ms_BC6D ; donor $bc67
Ms_BC69: LDA MsState+$006a ; donor $bc69
Ms_BC6B: bpl Ms_BC8F ; donor $bc6b
Ms_BC6D: LDA MsState+$04b0 ; donor $bc6d
Ms_BC70: SEC ; donor $bc70
Ms_BC71: SBC MsState+$0713 ; donor $bc71
Ms_BC74: bcs Ms_BC78 ; donor $bc74
Ms_BC76: ADC #$f0 ; donor $bc76
Ms_BC78: CMP #$58 ; donor $bc78
Ms_BC7A: bcs Ms_BC89 ; donor $bc7a
Ms_BC7C: LDA MsState+$04b0 ; donor $bc7c
Ms_BC7F: SEC ; donor $bc7f
Ms_BC80: SBC #$58 ; donor $bc80
Ms_BC82: bcs Ms_BC86 ; donor $bc82
Ms_BC84: ADC #$f0 ; donor $bc84
Ms_BC86: STA MsState+$0713 ; donor $bc86
Ms_BC89: RTS ; donor $bc89
Ms_BC8A: LDA MsState+$0570 ; donor $bc8a
Ms_BC8D: bmi Ms_BC6D ; donor $bc8d
Ms_BC8F: LDA MsState+$04b0 ; donor $bc8f
Ms_BC92: SEC ; donor $bc92
Ms_BC93: SBC MsState+$0713 ; donor $bc93
Ms_BC96: bcs Ms_BC9A ; donor $bc96
Ms_BC98: ADC #$f0 ; donor $bc98
Ms_BC9A: CMP #$78 ; donor $bc9a
Ms_BC9C: bcc Ms_BCAB ; donor $bc9c
Ms_BC9E: LDA MsState+$04b0 ; donor $bc9e
Ms_BCA1: SEC ; donor $bca1
Ms_BCA2: SBC #$78 ; donor $bca2
Ms_BCA4: bcs Ms_BCA8 ; donor $bca4
Ms_BCA6: ADC #$f0 ; donor $bca6
Ms_BCA8: STA MsState+$0713 ; donor $bca8
Ms_BCAB: RTS ; donor $bcab
Ms_BCAC: RTS ; donor $bcac
Ms_E324: JSR Ms_EA9D ; donor $e324
Ms_E327: JMP Ms_EA7F ; donor $e327
Ms_E32A: .byte $60
Ms_EA4E: LDX MsState+$05b8 ; donor $ea4e
Ms_EA51: CPX #$10 ; donor $ea51
Ms_EA53: bcs Ms_EA6C ; donor $ea53
Ms_EA55: LDA MsState+$0031 ; donor $ea55
Ms_EA57: LSR A ; donor $ea57
Ms_EA58: bcs Ms_EA62 ; donor $ea58
Ms_EA5A: CPX #$00 ; donor $ea5a
Ms_EA5C: beq Ms_EA75 ; donor $ea5c
Ms_EA5E: LDX #$10 ; donor $ea5e
Ms_EA60: bne Ms_EA72 ; donor $ea60
Ms_EA62: LDA MsState+$0735 ; donor $ea62
Ms_EA65: LSR A ; donor $ea65
Ms_EA66: bcc Ms_EA6C ; donor $ea66
Ms_EA68: CPX #$00 ; donor $ea68
Ms_EA6A: beq Ms_EA75 ; donor $ea6a
Ms_EA6C: INX ; donor $ea6c
Ms_EA6D: CPX #$32 ; donor $ea6d
Ms_EA6F: bcc Ms_EA72 ; donor $ea6f
Ms_EA71: DEX ; donor $ea71
Ms_EA72: STX MsState+$05b8 ; donor $ea72
Ms_EA75: LSR MsState+$0735 ; donor $ea75
Ms_EA78: LDA MsState+$0031 ; donor $ea78
Ms_EA7A: LSR A ; donor $ea7a
Ms_EA7B: ROL MsState+$0735 ; donor $ea7b
Ms_EA7E: RTS ; donor $ea7e
Ms_EA7F: LDX MsState+$05b8 ; donor $ea7f
Ms_EA82: LDY MsState+$0734 ; donor $ea82
Ms_EA85: bmi Ms_EA92 ; donor $ea85
Ms_EA87: LDA Ms_DA09,X ; donor $ea87
Ms_EA8A: CLC ; donor $ea8a
Ms_EA8B: ADC MsState+$0570 ; donor $ea8b
Ms_EA8E: STA MsState+$0570 ; donor $ea8e
Ms_EA91: RTS ; donor $ea91
Ms_EA92: LDA Ms_DA3D,X ; donor $ea92
Ms_EA95: CLC ; donor $ea95
Ms_EA96: ADC MsState+$0570 ; donor $ea96
Ms_EA99: STA MsState+$0570 ; donor $ea99
Ms_EA9C: RTS ; donor $ea9c
Ms_EA9D: LDA MsState+$0119 ; donor $ea9d
Ms_EAA0: bpl Ms_EAA9 ; donor $eaa0
Ms_EAA2: LDA MsState+$0734 ; donor $eaa2
Ms_EAA5: bmi Ms_EB04 ; donor $eaa5
Ms_EAA7: bpl Ms_EAAE ; donor $eaa7
Ms_EAA9: LDA MsState+$0734 ; donor $eaa9
Ms_EAAC: bpl Ms_EB04 ; donor $eaac
Ms_EAAE: LDA MsState+$0031 ; donor $eaae
Ms_EAB0: AND #$21 ; donor $eab0
Ms_EAB2: CMP #$21 ; donor $eab2
Ms_EAB4: bne Ms_EAFD ; donor $eab4
Ms_EAB6: LDA MsState+$0735 ; donor $eab6
Ms_EAB9: AND #$21 ; donor $eab9
Ms_EABB: bne Ms_EAFD ; donor $eabb
Ms_EABD: LDA MsState+$0119 ; donor $eabd
Ms_EAC0: STA MsState+$0734 ; donor $eac0
Ms_EAC3: LDA MsState+$0735 ; donor $eac3
Ms_EAC6: ORA #$31 ; donor $eac6
Ms_EAC8: STA MsState+$0735 ; donor $eac8
Ms_EACB: LDA #$1a ; donor $eacb
Ms_EACD: STA MsState+$05b8 ; donor $eacd
Ms_EAD0: LDA MsState+$043c ; donor $ead0
Ms_EAD3: beq Ms_EAE1 ; donor $ead3
Ms_EAD5: LDA #$80 ; donor $ead5
Ms_EAD7: STA MsState+$0630 ; donor $ead7
Ms_EADA: STA MsState+$043d ; donor $eada
Ms_EADD: LDA #$05 ; donor $eadd
Ms_EADF: bne Ms_EAE3 ; donor $eadf
Ms_EAE1: LDA #$04 ; donor $eae1
Ms_EAE3: STA MsState+$04e0 ; donor $eae3
Ms_EAE6: LDA #$00 ; donor $eae6
Ms_EAE8: STA MsState+$04f8 ; donor $eae8
Ms_EAEB: LDA #$80 ; donor $eaeb
Ms_EAED: STA MsState+$0588 ; donor $eaed
Ms_EAF0: STA MsState+$0737 ; donor $eaf0
Ms_EAF3: LDA MsState+$043c ; donor $eaf3
Ms_EAF6: bmi Ms_EAFE ; donor $eaf6
Ms_EAF8: LDA #$05 ; donor $eaf8
Ms_EAFA: STA MsState+$07e7 ; donor $eafa
Ms_EAFD: RTS ; donor $eafd
Ms_EAFE: LDA #$06 ; donor $eafe
Ms_EB00: STA MsState+$07e3 ; donor $eb00
Ms_EB03: RTS ; donor $eb03
Ms_EB04: LDA MsState+$0031 ; donor $eb04
Ms_EB06: AND #$11 ; donor $eb06
Ms_EB08: CMP #$11 ; donor $eb08
Ms_EB0A: bne Ms_EAFD ; donor $eb0a
Ms_EB0C: LDA MsState+$0735 ; donor $eb0c
Ms_EB0F: AND #$11 ; donor $eb0f
Ms_EB11: bne Ms_EAFD ; donor $eb11
Ms_EB13: LDA MsState+$011a ; donor $eb13
Ms_EB16: JMP Ms_EAC0 ; donor $eb16
Ms_EB19: .byte $a9
Ms_EB1A: .byte $01
Ms_EB1B: .byte $85
Ms_EB1C: .byte $6f
Ms_EB1D: .byte $a9
Ms_EB1E: .byte $11
Ms_EB1F: .byte $85
Ms_EB20: .byte $6e
Ms_EB21: .byte $60

Ms_DA09: .byte $00
Ms_DA0A: .byte $fa
Ms_DA0B: .byte $fa
Ms_DA0C: .byte $fa
Ms_DA0D: .byte $fb
Ms_DA0E: .byte $fb
Ms_DA0F: .byte $fb
Ms_DA10: .byte $fc
Ms_DA11: .byte $fc
Ms_DA12: .byte $fc
Ms_DA13: .byte $fd
Ms_DA14: .byte $fc
Ms_DA15: .byte $fd
Ms_DA16: .byte $fe
Ms_DA17: .byte $fd
Ms_DA18: .byte $fe
Ms_DA19: .byte $fe
Ms_DA1A: .byte $fe
Ms_DA1B: .byte $ff
Ms_DA1C: .byte $fe
Ms_DA1D: .byte $ff
Ms_DA1E: .byte $ff
Ms_DA1F: .byte $00
Ms_DA20: .byte $ff
Ms_DA21: .byte $00
Ms_DA22: .byte $00
Ms_DA23: .byte $01
Ms_DA24: .byte $00
Ms_DA25: .byte $00
Ms_DA26: .byte $01
Ms_DA27: .byte $00
Ms_DA28: .byte $01
Ms_DA29: .byte $01
Ms_DA2A: .byte $02
Ms_DA2B: .byte $01
Ms_DA2C: .byte $02
Ms_DA2D: .byte $02
Ms_DA2E: .byte $02
Ms_DA2F: .byte $03
Ms_DA30: .byte $02
Ms_DA31: .byte $03
Ms_DA32: .byte $04
Ms_DA33: .byte $03
Ms_DA34: .byte $04
Ms_DA35: .byte $04
Ms_DA36: .byte $04
Ms_DA37: .byte $05
Ms_DA38: .byte $05
Ms_DA39: .byte $05
Ms_DA3A: .byte $06
Ms_DA3B: .byte $06
Ms_DA3C: .byte $06
Ms_DA3D: .byte $00
Ms_DA3E: .byte $06
Ms_DA3F: .byte $06
Ms_DA40: .byte $06
Ms_DA41: .byte $05
Ms_DA42: .byte $05
Ms_DA43: .byte $05
Ms_DA44: .byte $04
Ms_DA45: .byte $04
Ms_DA46: .byte $04
Ms_DA47: .byte $03
Ms_DA48: .byte $04
Ms_DA49: .byte $03
Ms_DA4A: .byte $02
Ms_DA4B: .byte $03
Ms_DA4C: .byte $02
Ms_DA4D: .byte $02
Ms_DA4E: .byte $02
Ms_DA4F: .byte $01
Ms_DA50: .byte $02
Ms_DA51: .byte $01
Ms_DA52: .byte $01
Ms_DA53: .byte $00
Ms_DA54: .byte $01
Ms_DA55: .byte $00
Ms_DA56: .byte $00
Ms_DA57: .byte $ff
Ms_DA58: .byte $00
Ms_DA59: .byte $00
Ms_DA5A: .byte $ff
Ms_DA5B: .byte $00
Ms_DA5C: .byte $ff
Ms_DA5D: .byte $ff
Ms_DA5E: .byte $fe
Ms_DA5F: .byte $ff
Ms_DA60: .byte $fe
Ms_DA61: .byte $fe
Ms_DA62: .byte $fe
Ms_DA63: .byte $fd
Ms_DA64: .byte $fe
Ms_DA65: .byte $fd
Ms_DA66: .byte $fc
Ms_DA67: .byte $fd
Ms_DA68: .byte $fc
Ms_DA69: .byte $fc
Ms_DA6A: .byte $fc
Ms_DA6B: .byte $fb
Ms_DA6C: .byte $fb
Ms_DA6D: .byte $fb
Ms_DA6E: .byte $fa
Ms_DA6F: .byte $fa
Ms_DA70: .byte $fa
Ms_FEC8: .byte $04
Ms_FEC9: .byte $04
Ms_FECA: .byte $00
Ms_FECB: .byte $1f
Ms_FECC: .byte $1b
Ms_FECD: .byte $1b
Ms_FECE: .byte $1f
Ms_FECF: .byte $00
Ms_FED0: .byte $00
Ms_FED1: .byte $08
Ms_FED2: .byte $10
Ms_FED3: .byte $18
Ms_FED4: .byte $20
Ms_FED5: .byte $28
Ms_FED6: .byte $30
Ms_FED7: .byte $38
Ms_FED8: .byte $40
Ms_FED9: .byte $48
Ms_FEDA: .byte $50
Ms_FEDB: .byte $58
Ms_FEDC: .byte $60
Ms_FEDD: .byte $68
Ms_FEDE: .byte $70
Ms_FEDF: .byte $78
Ms_FEE0: .byte $80
Ms_FEE1: .byte $88
Ms_FEE2: .byte $90
Ms_FEE3: .byte $98
Ms_FEE4: .byte $a0
Ms_FEE5: .byte $a8
Ms_FEE6: .byte $b0
Ms_FEE7: .byte $b8
Ms_FEE8: .byte $c0
Ms_FEE9: .byte $c8
Ms_FEEA: .byte $d0
Ms_FEEB: .byte $d8
Ms_FEEC: .byte $e0
Ms_FEED: .byte $e8
Ms_FEEE: .byte $f0
Ms_FEEF: .byte $f8
Ms_FEF0: .byte $00
Ms_FEF1: .byte $10
Ms_FEF2: .byte $20
Ms_FEF3: .byte $30
Ms_FEF4: .byte $40
Ms_FEF5: .byte $50
Ms_FEF6: .byte $60
Ms_FEF7: .byte $70
Ms_FEF8: .byte $80
Ms_FEF9: .byte $90
Ms_FEFA: .byte $a0
Ms_FEFB: .byte $b0
Ms_FEFC: .byte $c0
Ms_FEFD: .byte $d0
Ms_FEFE: .byte $e0
Ms_FEFF: .byte $f0
.export MsFrame
MsFrame:
 lda MsPointer
 sta MsSaved0
 lda MsPointer+1
 sta MsSaved1
 jsr Ms_AD8C
MsFrameResult:
 php
 pha
 lda MsSaved0
 sta MsPointer
 lda MsSaved1
 sta MsPointer+1
 pla
 plp
 rts
.export MsHorizontal
MsHorizontal:
 lda MsPointer
 sta MsSaved0
 lda MsPointer+1
 sta MsSaved1
 jsr Ms_AC2F
MsHorizontalResult:
 php
 pha
 lda MsSaved0
 sta MsPointer
 lda MsSaved1
 sta MsPointer+1
 pla
 plp
 rts
.export MsGravity
MsGravity:
 lda MsPointer
 sta MsSaved0
 lda MsPointer+1
 sta MsSaved1
 jsr Ms_E324
MsGravityResult:
 php
 pha
 lda MsSaved0
 sta MsPointer
 lda MsSaved1
 sta MsPointer+1
 pla
 plp
 rts
.export MsJumpClock
MsJumpClock:
 lda MsPointer
 sta MsSaved0
 lda MsPointer+1
 sta MsSaved1
 jsr Ms_EA4E
MsJumpClockResult:
 php
 pha
 lda MsSaved0
 sta MsPointer
 lda MsSaved1
 sta MsPointer+1
 pla
 plp
 rts
.export MsIntegrateY
MsIntegrateY:
 lda MsPointer
 sta MsSaved0
 lda MsPointer+1
 sta MsSaved1
 jsr Ms_AC84
MsIntegrateYResult:
 php
 pha
 lda MsSaved0
 sta MsPointer
 lda MsSaved1
 sta MsPointer+1
 pla
 plp
 rts
.export MsWalls
MsWalls:
 lda MsPointer
 sta MsSaved0
 lda MsPointer+1
 sta MsSaved1
 jsr Ms_BB08
MsWallsResult:
 php
 pha
 lda MsSaved0
 sta MsPointer
 lda MsSaved1
 sta MsPointer+1
 pla
 plp
 rts
.export MsSupport
MsSupport:
 lda MsPointer
 sta MsSaved0
 lda MsPointer+1
 sta MsSaved1
 jsr Ms_B744
MsSupportResult:
 php
 pha
 lda MsSaved0
 sta MsPointer
 lda MsSaved1
 sta MsPointer+1
 pla
 plp
 rts
MsEnd:
.export MsEnd,MsState,MsPointer
; Bound include C:\Users\kando\Documents\ChatGPT\SMB Crossover\build\metal-storm-render-host-1101-v7\host-step.inc
; Selected-owner source adapter, NOT a native admission/loader.
; Caller must authenticate BOTH full C2/C3 headers before any A3 opcode.
; Source actor: A3:A000, MsState=C2:C000, MsPointer=foregroundR0=$03.
; Never use native NMI scratch00..02 or convert motion into Mm velocities.
.global SelectedCharacter,SavedJoypadBits,FrameCounter,GamePauseStatus
.global OperMode,GameEngineSubroutine
.export MsHostSelected,MsHostInput,MsHostSetBounds,MsHostReadY
.export MsHostSavePoint,MsHostReadDelta,MsHostStep,MsHostContractEnd
MsHostReady=$c800
MsHostEpoch=$c801
MsHostHaveEpoch=$c802
MsHostDeltaX=$c803
MsHostDeltaY=$c805
MsHostBeforeX=$c807
MsHostBeforeY=$c809
MsHostPad=$c80b
MsHostMulLo=$c80c
MsHostMulHi=$c80d
MsHostLinearLo=$c80e
MsHostLinearHi=$c80f

; Typed selected owner. Raw11 remains Sophia; raw35 is a proposed new owner.
; A/N/Z/C volatile; X/Y retained. A resident ROM equivalent is required cold.
MsHostSelected:
 lda SelectedCharacter
 cmp #35
 beq :+
 clc
 rts
:sec
 rts

; A=original right-bound low, X=high. Exact original732/733 contract;
; caller supplies the HOST AREA extent, never just donor low byteE4.
; Stores preserve all AXYP.
MsHostSetBounds:
 sta MsState+$732
 stx MsState+$733
 rts

; Actual NES input bit order -> original Metal Storm31. AXYP preserved.
; Original polling follows the actor: call AFTER the accepted source step.
; Source735 remains the sole jump/gravity edge latch; do not synthesize it.
MsHostInput:
 php
 pha
 txa
 pha
 lda #0
 sta MsHostPad
 lda SavedJoypadBits
 ldx #8
:lsr a
 rol MsHostPad
 dex
 bne :-
 lda MsHostPad
 sta MsState+$31
 pla
 tax
 pla
 plp
 rts

; SourceY uses signed240-pixel pages, not SMB's256-pixel high byte.
; A=linear source topY low, X=high; Y retained, flags volatile.
MsHostReadY:
 lda MsState+$4c8
 sta MsHostMulLo
 lda #0
 bit MsHostMulLo
 bpl :+
 lda #$ff
:sta MsHostMulHi
 .repeat 4
 asl MsHostMulLo
 rol MsHostMulHi
 .endrepeat
 lda MsState+$4b0
 sec
 sbc MsHostMulLo
 sta MsHostLinearLo
 lda MsState+$4c8
 sbc MsHostMulHi
 sta MsHostLinearHi
 tax
 lda MsHostLinearLo
 rts

MsHostSavePoint:
 php
 pha
 txa
 pha
 lda MsState+$480
 sta MsHostBeforeX
 lda MsState+$498
 sta MsHostBeforeX+1
 jsr MsHostReadY
 sta MsHostBeforeY
 stx MsHostBeforeY+1
 pla
 tax
 pla
 plp
 rts

; Exact signed world displacement. Native bridge applies it ONCE, then lets
; typed terrain/camera callbacks reconcile source positions at their boundary.
; No private fractions, source velocities or jump clocks are round-tripped.
MsHostReadDelta:
 php
 pha
 txa
 pha
 lda MsState+$480
 sec
 sbc MsHostBeforeX
 sta MsHostDeltaX
 lda MsState+$498
 sbc MsHostBeforeX+1
 sta MsHostDeltaX+1
 jsr MsHostReadY
 sec
 sbc MsHostBeforeY
 sta MsHostDeltaY
 txa
 sbc MsHostBeforeY+1
 sta MsHostDeltaY+1
 pla
 tax
 pla
 plp
 rts

; AXYP preserved exceptC1accepted/C0rejected. Epoch/pause repeats produce
; zero deltas and do not advance source input, clocks or object callbacks.
; The real FF27 callback owns original DCAE:INC53; never add a second tick.
MsHostStep:
 php
 pha
 txa
 pha
 tya
 pha
 jsr MsHostSelected
 bcc Rejected
 lda MsHostReady
 cmp #$a7
 bne Rejected
 lda OperMode
 cmp #1
 bne Rejected
 lda GameEngineSubroutine
 cmp #8
 bne Rejected
 jsr MsNativeObjectsReady
 bcc Rejected
 lda #0
 sta MsHostDeltaX
 sta MsHostDeltaX+1
 sta MsHostDeltaY
 sta MsHostDeltaY+1
 lda GamePauseStatus
 and #1
 bne Accepted
 lda MsHostHaveEpoch
 beq Update
 lda FrameCounter
 cmp MsHostEpoch
 beq Accepted
Update:
 jsr MsHostSavePoint
 ; Restore the original source entry AXYP before its real frame routine.
 ; Temporary P/A copies are popped before entering the source call chain.
 tsx
 lda $0104,x
 pha
 lda $0101,x
 tay
 lda $0103,x
 pha
 lda $0102,x
 tax
 pla
 plp
 jsr MsFrame
 nop
 nop
 nop ; original FF39 now performs the recovered sourceAI pass
 jsr MsNativeAnimationMask ; source renderer mask follows actor, before input
 jsr MsHostReadDelta
 jsr MsHostInput                 ; original one-update controller pipeline
 lda FrameCounter
 sta MsHostEpoch
 lda #1
 sta MsHostHaveEpoch
Accepted:
 tsx
 lda $0104,x
 ora #1
 bne Status
Rejected:
 tsx
 lda $0104,x
 and #$fe
Status:
 sta $0104,x
 pla
 tay
 pla
 tax
 pla
 plp
 rts
MsHostContractEnd:

.export MsHostServiceRows
; Bound include C:\Users\kando\Documents\ChatGPT\SMB Crossover\build\metal-storm-terrain-host-1101-v5\donor-leaves.inc
MsCtor_911B: LDX #$17 ; original $911b
MsCtor_911D: LDA #$00 ; original $911d
MsCtor_911F: STA MsState+$0510,X ; original $911f
MsCtor_9122: LDA #$80 ; original $9122
MsCtor_9124: STA MsState+$0498,X ; original $9124
MsCtor_9127: STA MsState+$05e8,X ; original $9127
MsCtor_912A: DEX ; original $912a
MsCtor_912B: CPX #$01 ; original $912b
MsCtor_912D: jne MsCtor_911D ; original $912d
MsCtor_912F: RTS ; original $912f
MsCtor_9371: LDA #$00 ; original $9371
MsCtor_9373: STA MsState+$0041 ; original $9373
MsCtor_9375: STA MsState+$0558 ; original $9375
MsCtor_9378: STA MsState+$0570 ; original $9378
MsCtor_937B: STA MsState+$0701 ; original $937b
MsCtor_937E: STA MsState+$06ea ; original $937e
MsCtor_9381: STA MsState+$06eb ; original $9381
MsCtor_9384: STA MsState+$0648 ; original $9384
MsCtor_9387: LDA MsState+$0051 ; original $9387
MsCtor_9389: CMP #$21 ; original $9389
MsCtor_938B: jcc MsCtor_938F ; original $938b
MsCtor_938D: SBC #$21 ; original $938d
MsCtor_938F: TAX ; original $938f
MsCtor_9390: LDA MsCtor_8AE8,X ; original $9390
MsCtor_9393: STA MsState+$0756 ; original $9393
MsCtor_9396: LDA #$81 ; original $9396
MsCtor_9398: STA MsState+$0758 ; original $9398
MsCtor_939B: STA MsState+$0755 ; original $939b
MsCtor_939E: STA MsState+$0070 ; original $939e
MsCtor_93A0: LDA MsState+$043a ; original $93a0
MsCtor_93A3: jeq MsCtor_93AA ; original $93a3
MsCtor_93A5: LDA MsState+$042e ; original $93a5
MsCtor_93A8: jmi MsCtor_93DC ; original $93a8
MsCtor_93AA: LDA MsState+$0051 ; original $93aa
MsCtor_93AC: CMP #$21 ; original $93ac
MsCtor_93AE: jcc MsCtor_93B2 ; original $93ae
MsCtor_93B0: SBC #$21 ; original $93b0
MsCtor_93B2: ASL A ; original $93b2
MsCtor_93B3: TAX ; original $93b3
MsCtor_93B4: LDA MsCtor_8B4C,X ; original $93b4
MsCtor_93B7: STA MsState+$04b0 ; original $93b7
MsCtor_93BA: LDA #$00 ; original $93ba
MsCtor_93BC: STA MsState+$004c ; original $93bc
MsCtor_93BE: STA MsState+$006a ; original $93be
MsCtor_93C0: STA MsState+$006b ; original $93c0
MsCtor_93C2: STA MsState+$0713 ; original $93c2
MsCtor_93C5: LDA #$07 ; original $93c5
MsCtor_93C7: STA MsState+$04e0 ; original $93c7
MsCtor_93CA: LDA #$02 ; original $93ca
MsCtor_93CC: STA MsState+$04f8 ; original $93cc
MsCtor_93CF: LDA MsState+$04b0 ; original $93cf
MsCtor_93D2: jne MsCtor_93D7 ; original $93d2
MsCtor_93D4: JSR MsNativePlacement ; original $93d4
MsCtor_93D7: LDA #$80 ; original $93d7
MsCtor_93D9: STA MsState+$0715 ; original $93d9
MsCtor_93DC: LDA #$00 ; original $93dc
MsCtor_93DE: STA MsState+$075f ; original $93de
MsCtor_93E1: STA MsState+$0710 ; original $93e1
MsCtor_93E4: STA MsState+$0711 ; original $93e4
MsCtor_93E7: STA MsState+$05b8 ; original $93e7
MsCtor_93EA: JSR Ms_B08F ; original $93ea
 rts ; native boundary before donor scene script8874
MsCtor_9431: LDA #$00 ; original $9431
MsCtor_9433: LDX #$05 ; original $9433
MsCtor_9435: STA MsState+$06f8,X ; original $9435
MsCtor_9438: DEX ; original $9438
MsCtor_9439: jne MsCtor_9435 ; original $9439
MsCtor_943B: RTS ; original $943b
MsCtor_943C: LDA #$00 ; original $943c
MsCtor_943E: STA MsState+$0734 ; original $943e
MsCtor_9441: LDA MsState+$0540 ; original $9441
MsCtor_9444: AND #$3f ; original $9444
MsCtor_9446: STA MsState+$0540 ; original $9446
MsCtor_9449: RTS ; original $9449
MsCtor_E2C4: LDA MsState+$0558,Y ; original $e2c4
MsCtor_E2C7: jeq MsCtor_E2D8 ; original $e2c7
MsCtor_E2C9: jpl MsCtor_E2D9 ; original $e2c9
MsCtor_E2CB: LDA MsState+$0059 ; original $e2cb
MsCtor_E2CD: ORA #$0f ; original $e2cd
MsCtor_E2CF: CLC ; original $e2cf
MsCtor_E2D0: ADC #$01 ; original $e2d0
MsCtor_E2D2: STA MsState+$0059 ; original $e2d2
MsCtor_E2D4: jcc MsCtor_E2D8 ; original $e2d4
MsCtor_E2D6: INC MsState+$005a ; original $e2d6
MsCtor_E2D8: RTS ; original $e2d8
MsCtor_E2D9: LDA MsState+$0059 ; original $e2d9
MsCtor_E2DB: AND #$f0 ; original $e2db
MsCtor_E2DD: SEC ; original $e2dd
MsCtor_E2DE: SBC #$01 ; original $e2de
MsCtor_E2E0: STA MsState+$0059 ; original $e2e0
MsCtor_E2E2: jcs MsCtor_E2E6 ; original $e2e2
MsCtor_E2E4: DEC MsState+$005a ; original $e2e4
MsCtor_E2E6: RTS ; original $e2e6
MsCtor_E2E7: LDA MsState+$0570,Y ; original $e2e7
MsCtor_E2EA: jeq MsCtor_E2FF ; original $e2ea
MsCtor_E2EC: jpl MsCtor_E312 ; original $e2ec
MsCtor_E2EE: LDA MsState+$005b ; original $e2ee
MsCtor_E2F0: ORA #$0f ; original $e2f0
MsCtor_E2F2: CLC ; original $e2f2
MsCtor_E2F3: ADC #$01 ; original $e2f3
MsCtor_E2F5: STA MsState+$005b ; original $e2f5
MsCtor_E2F7: LDY MsState+$0050 ; original $e2f7
MsCtor_E2F9: jne MsCtor_E300 ; original $e2f9
MsCtor_E2FB: jcc MsCtor_E2FF ; original $e2fb
MsCtor_E2FD: INC MsState+$005c ; original $e2fd
MsCtor_E2FF: RTS ; original $e2ff
MsCtor_E300: CMP #$f0 ; original $e300
MsCtor_E302: jcc MsCtor_E2FF ; original $e302
MsCtor_E304: SBC #$f0 ; original $e304
MsCtor_E306: STA MsState+$005b ; original $e306
MsCtor_E308: RTS ; original $e308
MsCtor_E309: CMP #$f0 ; original $e309
MsCtor_E30B: jcc MsCtor_E2FF ; original $e30b
MsCtor_E30D: SBC #$10 ; original $e30d
MsCtor_E30F: STA MsState+$005b ; original $e30f
MsCtor_E311: RTS ; original $e311
MsCtor_E312: LDA MsState+$005b ; original $e312
MsCtor_E314: AND #$f0 ; original $e314
MsCtor_E316: SEC ; original $e316
MsCtor_E317: SBC #$01 ; original $e317
MsCtor_E319: STA MsState+$005b ; original $e319
MsCtor_E31B: LDY MsState+$0050 ; original $e31b
MsCtor_E31D: jne MsCtor_E309 ; original $e31d
MsCtor_E31F: jcs MsCtor_E323 ; original $e31f
MsCtor_E321: DEC MsState+$005c ; original $e321
MsCtor_E323: RTS ; original $e323
MsCtor_DA71: LDA MsState+$005b ; original $da71
MsCtor_DA73: jcc MsCtor_DA77 ; original $da73
MsCtor_DA75: SBC #$f0 ; original $da75
MsCtor_DA77: CMP #$f0 ; original $da77
MsCtor_DA79: jcc MsCtor_DA7D ; original $da79
MsCtor_DA7B: SBC #$f0 ; original $da7b
MsCtor_DA7D: STA MsState+$005b ; original $da7d
MsCtor_DA7F: RTS ; original $da7f
MsCtor_8AE8: .byte $02
MsCtor_8AE9: .byte $02
MsCtor_8AEA: .byte $00
MsCtor_8AEB: .byte $0e
MsCtor_8AEC: .byte $0e
MsCtor_8AED: .byte $0e
MsCtor_8AEE: .byte $3e
MsCtor_8AEF: .byte $3e
MsCtor_8AF0: .byte $00
MsCtor_8AF1: .byte $18
MsCtor_8AF2: .byte $18
MsCtor_8AF3: .byte $18
MsCtor_8AF4: .byte $18
MsCtor_8AF5: .byte $40
MsCtor_8AF6: .byte $40
MsCtor_8AF7: .byte $00
MsCtor_8AF8: .byte $0c
MsCtor_8AF9: .byte $0c
MsCtor_8AFA: .byte $0c
MsCtor_8AFB: .byte $46
MsCtor_8AFC: .byte $00
MsCtor_8AFD: .byte $46
MsCtor_8AFE: .byte $0e
MsCtor_8AFF: .byte $46
MsCtor_8B00: .byte $00
MsCtor_8B01: .byte $46
MsCtor_8B02: .byte $18
MsCtor_8B03: .byte $46
MsCtor_8B04: .byte $00
MsCtor_8B05: .byte $46
MsCtor_8B06: .byte $0c
MsCtor_8B07: .byte $46
MsCtor_8B08: .byte $00
MsCtor_8B4B: .byte $78
MsCtor_8B4C: .byte $00
MsCtor_8B4D: .byte $04
MsCtor_8B4E: .byte $00
MsCtor_8B4F: .byte $10
MsCtor_8B50: .byte $b0
MsCtor_8B51: .byte $78
MsCtor_8B52: .byte $00
MsCtor_8B53: .byte $04
MsCtor_8B54: .byte $00
MsCtor_8B55: .byte $04
MsCtor_8B56: .byte $90
MsCtor_8B57: .byte $78
MsCtor_8B58: .byte $00
MsCtor_8B59: .byte $04
MsCtor_8B5A: .byte $00
MsCtor_8B5B: .byte $10
MsCtor_8B5C: .byte $b0
MsCtor_8B5D: .byte $78
MsCtor_8B5E: .byte $00
MsCtor_8B5F: .byte $40
MsCtor_8B60: .byte $90
MsCtor_8B61: .byte $78
MsCtor_8B62: .byte $00
MsCtor_8B63: .byte $50
MsCtor_8B64: .byte $90
MsCtor_8B65: .byte $78
MsCtor_8B66: .byte $00
MsCtor_8B67: .byte $04
MsCtor_8B68: .byte $00
MsCtor_8B69: .byte $10
MsCtor_8B6A: .byte $00
MsCtor_8B6B: .byte $78
MsCtor_8B6C: .byte $00
MsCtor_8B6D: .byte $04
MsCtor_8B6E: .byte $00
MsCtor_8B6F: .byte $30
MsCtor_8B70: .byte $80
MsCtor_8B71: .byte $78
MsCtor_8B72: .byte $00
MsCtor_8B73: .byte $10
MsCtor_8B74: .byte $b0
MsCtor_8B75: .byte $04
MsCtor_8B76: .byte $00
MsCtor_8B77: .byte $04
MsCtor_8B78: .byte $90
MsCtor_8B79: .byte $04
MsCtor_8B7A: .byte $00
MsCtor_8B7B: .byte $10
MsCtor_8B7C: .byte $b0
MsCtor_8B7D: .byte $04
MsCtor_8B7E: .byte $00
MsCtor_8B7F: .byte $50
MsCtor_8B80: .byte $90
MsCtor_8B81: .byte $04
MsCtor_8B82: .byte $00
MsCtor_8B83: .byte $10
MsCtor_8B84: .byte $00
MsCtor_8B85: .byte $04
MsCtor_8B86: .byte $00
MsCtor_8B87: .byte $30
MsCtor_8B88: .byte $80
MsCtor_8B89: .byte $04
MsCtor_8B8A: .byte $00
MsCtor_8B8B: .byte $30
MsCtor_8B8C: .byte $00
MsNativeFF33=MsCtor_E2C4
MsNativeFF36=MsCtor_E2E7
MsNativeFF3F=MsCtor_DA71

; Bound include C:\Users\kando\Documents\ChatGPT\SMB Crossover\build\metal-storm-objects-host-1101-v6\terrain-adapter.inc
; Metal Storm original-actor constructor/terrain component. Not host admission.
; Include after frozen v4 actor/host adapter. MsState=C000, MsPointer=03/04.
; The generated donor leaves keep their instruction order and signed240Y.
; R0/R1 are foreground-only. NMI00..02 and R2..R7 are never borrowed.
.global Block_Buffer_1,BlockBufferAddr,MTileAttribute
.global Player_X_Position,Player_PageLoc,Player_Y_Position,Player_Y_HighPos
.export MsNativeConstruct,MsNativeTileQuery,MsNativePlacement,MsNativeApplyDelta
.export MsNativeFF33,MsNativeFF36,MsNativeFF3F,MsTerrainHostEnd
MsTileFlags=$c810
MsTileId=$c811
MsTileColumn=$c812
MsPlacementBudget=$c813
MsDeltaAppliedEpoch=$c814
MsDeltaAppliedValid=$c815
MsCtorBoundLo=$c816
MsCtorBoundHi=$c817

; FF1E replacement: source59/5A worldX,5B screenY -> (R0/R1),Y=0
; points at one private semantic byte. X retained; A/Y/P volatile, coordinates
; unchanged; native object positions, R2..R7, queues and buffers unchanged.
; Original wall probes require flags&E0=E0. Support probes require bit80.
; Native SOLID without CLIMB mapsE0; air/coins/vines/flagpole map00.
; No unsupported donor hazard/ladder/type bits are manufactured.
MsNativeTileQuery:
 txa
 pha
 lda #0
 sta MsTileFlags
 sta MsTileId
 lda MsState+$5a
 bmi TileDone
 cmp MsState+$733
 bcc TileInBounds
 bne TileDone
 lda MsState+$59
 cmp MsState+$732
 bcc TileInBounds
 beq TileInBounds
 bcs TileDone
TileInBounds:
 lda MsState+$5b
 cmp #$20
 bcc TileDone
 cmp #$f0
 bcs TileDone
 and #$f0
 sec
 sbc #$20
 tay
 lda MsState+$59
 lsr a
 lsr a
 lsr a
 lsr a
 sta MsTileColumn
 lda MsState+$5a
 and #1
 tax
 lda #>Block_Buffer_1
 sta MsPointer+1
 lda MsTileColumn
 clc
 adc BlockBufferAddr,x
 sta MsPointer
 lda (MsPointer),y
 sta MsTileId
 tax
 lda MTileAttribute,x
 and #3
 cmp #1
 bne TileDone
 lda #$e0
 sta MsTileFlags
TileDone:
 pla
 tax
 lda #<MsTileFlags
 sta MsPointer
 lda #>MsTileFlags
 sta MsPointer+1
 ldy #0
 rts

; Native form of original944A..94AB's upward initial placement scan.
; Original startsY=D0 and moves one16px map row at a time. The pointer walk
; becomes typed FF1E queries because native maps use16-column rows, not20.
; All legal source cases preserve scan order/Y/state. A16-row ceiling bounds
; a malformed all-solid native column; C0 indicates that host-only failure.
MsNativePlacement:
 lda #$d0
 sta MsState+$4b0
 lda #0
 sta MsState+$4c8
 sta MsState+$588
 lda #16
 sta MsPlacementBudget
PlacementSeekSolid:
 jsr PlacementQuery
 lda MsTileFlags
 bmi PlacementSeekAir
 jsr PlacementUp
 bcs PlacementSeekSolid
 rts
PlacementSeekAir:
 jsr PlacementUp
 bcc PlacementFailed
 jsr PlacementQuery
 lda MsTileFlags
 bmi PlacementSeekAir
 lda #7
 sta MsState+$4e0
 lda #2
 sta MsState+$4f8
 sec
 rts
PlacementUp:
 dec MsPlacementBudget
 beq PlacementFailed
 lda MsState+$4b0
 sec
 sbc #$10
 sta MsState+$4b0
 sec
 rts
PlacementFailed:
 clc
 rts
PlacementQuery:
 lda MsState+$480
 sta MsState+$59
 lda MsState+$498
 sta MsState+$5a
 lda MsState+$4b0
 clc
 adc #$10 ; donor944A startsmaprowE0 while actorY=D0 (foot-side probe)
 sta MsState+$5b
 jmp MsNativeTileQuery

; Cold/re-entry constructor; caller authenticates both complete owner cookies
; and grants C2 before entry. No captured RAM state is used. The clear is cold
; donor reset equivalence, followed by real911B slots,90EB activation,9371
; pure actor constructor, and943C gravity reset. Donor scene/OAM/PPU/audio
; setup and map scripts remain HOST boundaries, not called or simulated here.
; Source area0 supplies original actor-art profile, not SMB campaign metadata.
; After source-map placement, bind native spawn: sourceX=nativeX-8, sourceY=
; nativeY.32px source body and16px SMB anchor share their center/feet.
; Only normal native YHigh1 entry is admitted. AXYP retained except Cresult.
MsNativeConstruct:
 php
 pha
 txa
 pha
 tya
 pha
 lda #0
 sta MsHostReady
 lda Player_Y_HighPos
 cmp #1
 jne ConstructReject
 lda MsState+$732
 sta MsCtorBoundLo
 lda MsState+$733
 sta MsCtorBoundHi
 ldx #0
 lda #0
ConstructClear:
 .repeat 8,I
 sta MsState+I*$100,x
 .endrepeat
 inx
 bne ConstructClear
 ; Fresh source pointer pair saved AFTER reset, never donor NMI scratch.
 lda MsPointer
 sta MsSaved0
 lda MsPointer+1
 sta MsSaved1
 jsr MsCtor_911B
 sta MsState+$510
 sta MsState+$70
 lda #$80
 sta MsState+$43f
 lda MsCtorBoundLo
 sta MsState+$732
 lda MsCtorBoundHi
 sta MsState+$733
 jsr ConstructBindX
 jsr MsCtor_9371
 jsr MsCtor_943C
 jsr MsObj_FC5E ; original reset validates gravity-control pair119/11A
 jsr MsNativeAnimationMask ; initial original renderer pose metadata
 jsr ConstructBindX
 lda Player_Y_Position
 sta MsState+$4b0
 lda #0
 sta MsState+$4c8
 sta MsHostHaveEpoch
 sta MsDeltaAppliedValid
 lda MsSaved0
 sta MsPointer
 lda MsSaved1
 sta MsPointer+1
 lda #$a7
 sta MsHostReady
 tsx
 lda $0104,x
 ora #1
 bne ConstructStatus
ConstructReject:
 tsx
 lda $0104,x
 and #$fe
ConstructStatus:
 sta $0104,x
 pla
 tay
 pla
 tax
 pla
 plp
 rts
ConstructBindX:
 lda Player_X_Position
 sec
 sbc #8
 sta MsState+$480
 lda Player_PageLoc
 sbc #0
 sta MsState+$498
 rts

; Apply accepted source world displacement exactly once per source epoch.
; Host camera runs afterward, once. ScreenLeft is never subtracted here;
; source coordinates and native PageLoc/X are WORLD coordinates. Source
; fractions/velocity/jump latch/gravity remain untouched. AXYP preserved.
MsNativeApplyDelta:
 php
 pha
 lda MsHostHaveEpoch
 beq ApplyDone
 lda MsDeltaAppliedValid
 beq ApplyNew
 lda MsHostEpoch
 cmp MsDeltaAppliedEpoch
 beq ApplyDone
ApplyNew:
 lda Player_X_Position
 clc
 adc MsHostDeltaX
 sta Player_X_Position
 lda Player_PageLoc
 adc MsHostDeltaX+1
 sta Player_PageLoc
 lda Player_Y_Position
 clc
 adc MsHostDeltaY
 sta Player_Y_Position
 lda Player_Y_HighPos
 adc MsHostDeltaY+1
 sta Player_Y_HighPos
 lda MsHostEpoch
 sta MsDeltaAppliedEpoch
 lda #1
 sta MsDeltaAppliedValid
ApplyDone:
 pla
 plp
 rts
MsTerrainHostEnd:
; Bound include C:\Users\kando\Documents\ChatGPT\SMB Crossover\build\metal-storm-render-host-1101-v7\object-leaves.inc
MsObj_8BCF: LDX #$17 ; original $8bcf
MsObj_8BD1: LDA #$00 ; original $8bd1
MsObj_8BD3: STA MsState+$0113 ; original $8bd3
MsObj_8BD6: STA MsState+$0114 ; original $8bd6
MsObj_8BD9: STA MsState+$0115 ; original $8bd9
MsObj_8BDC: STA MsState+$0116 ; original $8bdc
MsObj_8BDF: LDA MsState+$0510,X ; original $8bdf
MsObj_8BE2: beq MsObj_8BF1 ; original $8be2
MsObj_8BE4: LDA MsState+$0600,X ; original $8be4
MsObj_8BE7: AND #$20 ; original $8be7
MsObj_8BE9: beq MsObj_8BF1 ; original $8be9
MsObj_8BEB: JSR MsObjectUnsupported ; original $8beb
MsObj_8BEE: JSR MsObjectUnsupported ; original $8bee
MsObj_8BF1: DEX ; original $8bf1
MsObj_8BF2: CPX #$03 ; original $8bf2
MsObj_8BF4: bcs MsObj_8BDF ; original $8bf4
MsObj_8BF6: JMP Ms_AB53 ; original $8bf6
MsObj_D783: STA MsState+$003a ; original $d783
MsObj_D785: LDA #$80 ; original $d785
MsObj_D787: STA MsState+$0058 ; original $d787
MsObj_D789: LDA MsState+$003a ; original $d789
MsObj_D78B: ASL A ; original $d78b
MsObj_D78C: STA MsState+$005e ; original $d78c
MsObj_D78E: LDA #$06 ; original $d78e
MsObj_D790: STA MsState+$005d ; original $d790
MsObj_D792: LDA MsState+$005d ; original $d792
MsObj_D794: STA MsDonorMapperSelect ; original $d794
MsObj_D797: LDA MsState+$005e ; original $d797
MsObj_D799: STA MsDonorMapperData ; original $d799
MsObj_D79C: INC MsState+$005d ; original $d79c
MsObj_D79E: INC MsState+$005e ; original $d79e
MsObj_D7A0: LDA MsState+$005d ; original $d7a0
MsObj_D7A2: STA MsDonorMapperSelect ; original $d7a2
MsObj_D7A5: LDA MsState+$005e ; original $d7a5
MsObj_D7A7: STA MsDonorMapperData ; original $d7a7
MsObj_D7AA: LDA #$00 ; original $d7aa
MsObj_D7AC: STA MsState+$0058 ; original $d7ac
MsObj_D7AE: RTS ; original $d7ae
MsObj_DA8F: LDY MsState+$0050 ; original $da8f
MsObj_DA91: bne MsObj_DAB0 ; original $da91
MsObj_DA93: LDA MsState+$04c8,X ; original $da93
MsObj_DA96: beq MsObj_DAB0 ; original $da96
MsObj_DA98: CMP #$01 ; original $da98
MsObj_DA9A: beq MsObj_DAA9 ; original $da9a
MsObj_DA9C: CMP #$ff ; original $da9c
MsObj_DA9E: bne MsObj_DAE7 ; original $da9e
MsObj_DAA0: LDA MsState+$04b0,X ; original $daa0
MsObj_DAA3: CMP #$c0 ; original $daa3
MsObj_DAA5: bcc MsObj_DAE7 ; original $daa5
MsObj_DAA7: bcs MsObj_DAB0 ; original $daa7
MsObj_DAA9: LDA MsState+$04b0,X ; original $daa9
MsObj_DAAC: CMP #$40 ; original $daac
MsObj_DAAE: bcs MsObj_DAE7 ; original $daae
MsObj_DAB0: LDA MsState+$0078 ; original $dab0
MsObj_DAB2: bpl MsObj_DABB ; original $dab2
MsObj_DAB4: LDA MsState+$0498,X ; original $dab4
MsObj_DAB7: bpl MsObj_DAC4 ; original $dab7
MsObj_DAB9: bmi MsObj_DAE7 ; original $dab9
MsObj_DABB: LDA MsState+$0498,X ; original $dabb
MsObj_DABE: CMP MsState+$0078 ; original $dabe
MsObj_DAC0: bcc MsObj_DAE7 ; original $dac0
MsObj_DAC2: beq MsObj_DACC ; original $dac2
MsObj_DAC4: CMP MsState+$0076 ; original $dac4
MsObj_DAC6: beq MsObj_DAD5 ; original $dac6
MsObj_DAC8: bcc MsObj_DADC ; original $dac8
MsObj_DACA: bcs MsObj_DAE7 ; original $daca
MsObj_DACC: LDA MsState+$0480,X ; original $dacc
MsObj_DACF: CMP MsState+$0077 ; original $dacf
MsObj_DAD1: bcc MsObj_DAE7 ; original $dad1
MsObj_DAD3: bcs MsObj_DADC ; original $dad3
MsObj_DAD5: LDA MsState+$0480,X ; original $dad5
MsObj_DAD8: CMP MsState+$0075 ; original $dad8
MsObj_DADA: bcs MsObj_DAE7 ; original $dada
MsObj_DADC: LDA MsState+$0510,X ; original $dadc
MsObj_DADF: bne MsObj_DAE6 ; original $dadf
MsObj_DAE1: LDA #$80 ; original $dae1
MsObj_DAE3: STA MsState+$0510,X ; original $dae3
MsObj_DAE6: RTS ; original $dae6
MsObj_DAE7: LDA MsState+$06a8,X ; original $dae7
MsObj_DAEA: bmi MsObj_DAE6 ; original $daea
MsObj_DAEC: LDA MsState+$0510,X ; original $daec
MsObj_DAEF: beq MsObj_DB0D ; original $daef
MsObj_DAF1: bpl MsObj_DB15 ; original $daf1
MsObj_DAF3: LDA #$00 ; original $daf3
MsObj_DAF5: STA MsState+$0510,X ; original $daf5
MsObj_DAF8: LDA #$80 ; original $daf8
MsObj_DAFA: STA MsState+$0498,X ; original $dafa
MsObj_DAFD: STA MsState+$05e8,X ; original $dafd
MsObj_DB00: LDY MsState+$0528,X ; original $db00
MsObj_DB03: bmi MsObj_DB0D ; original $db03
MsObj_DB05: LDA MsObj_DB1B,Y ; original $db05
MsObj_DB08: beq MsObj_DB0D ; original $db08
MsObj_DB0A: DEC MsState+$0433 ; original $db0a
MsObj_DB0D: LDA #$00 ; original $db0d
MsObj_DB0F: STA MsState+$0558,X ; original $db0f
MsObj_DB12: STA MsState+$0570,X ; original $db12
MsObj_DB15: LDA #$00 ; original $db15
MsObj_DB17: STA MsState+$06a8,X ; original $db17
MsObj_DB1A: RTS ; original $db1a
MsObj_DB9B: LDA MsState+$06a8,X ; original $db9b
MsObj_DB9E: jpl MsObjReturn ; original $db9e
 lda MsState+$600,x ; original DB A0 qualified positiveflags
 jpl MsObjReturn
 jmp MsObjectUnsupported ; ineligible source object path
MsObj_DCAE: INC MsState+$0053 ; original $dcae
MsObj_DCB0: LDA MsState+$0710 ; original $dcb0
MsObj_DCB3: SEC ; original $dcb3
MsObj_DCB4: SBC #$40 ; original $dcb4
MsObj_DCB6: STA MsState+$0077 ; original $dcb6
MsObj_DCB8: LDA MsState+$0711 ; original $dcb8
MsObj_DCBB: SBC #$00 ; original $dcbb
MsObj_DCBD: STA MsState+$0078 ; original $dcbd
MsObj_DCBF: LDA MsState+$0710 ; original $dcbf
MsObj_DCC2: CLC ; original $dcc2
MsObj_DCC3: ADC #$40 ; original $dcc3
MsObj_DCC5: STA MsState+$0075 ; original $dcc5
MsObj_DCC7: LDA MsState+$0711 ; original $dcc7
MsObj_DCCA: ADC #$01 ; original $dcca
MsObj_DCCC: STA MsState+$0076 ; original $dccc
MsObj_DCCE: LDA MsState+$003a ; original $dcce
MsObj_DCD0: PHA ; original $dcd0
MsObj_DCD1: LDA #$06 ; original $dcd1
MsObj_DCD3: JSR MsObj_D783 ; original $dcd3
MsObj_DCD6: LDX #$17 ; original $dcd6
MsObj_DCD8: LDA MsState+$0510,X ; original $dcd8
MsObj_DCDB: beq MsObj_DCF0 ; original $dcdb
MsObj_DCDD: bpl MsObj_DCE2 ; original $dcdd
MsObj_DCDF: JSR MsObj_DA8F ; original $dcdf
MsObj_DCE2: LDA MsState+$0510,X ; original $dce2
MsObj_DCE5: beq MsObj_DCF0 ; original $dce5
MsObj_DCE7: JSR MsObj_DD48 ; original $dce7
MsObj_DCEA: JSR MsObj_E32B ; original $dcea
MsObj_DCED: JSR MsObj_DB9B ; original $dced
MsObj_DCF0: DEX ; original $dcf0
MsObj_DCF1: bne MsObj_DCD8 ; original $dcf1
MsObj_DCF3: PLA ; original $dcf3
MsObj_DCF4: JMP MsObj_D783 ; original $dcf4
MsObj_DD06: LDA MsState+$0528,X ; original $dd06
MsObj_DD09: jpl MsObjectUnsupported ; original $dd09
MsObj_DD0B: RTS ; original $dd0b
MsObj_DD48: JSR MsObj_DD06 ; original $dd48
MsObj_DD4B: LDA #$00 ; original $dd4b
MsObj_DD4D: STA MsState+$0753 ; original $dd4d
MsObj_DD50: LDA MsState+$0510,X ; original $dd50
MsObj_DD53: bne MsObj_DD58 ; original $dd53
MsObj_DD55: JMP MsObj_DE0F ; original $dd55
MsObj_DD58: LDA MsState+$0440 ; original $dd58
MsObj_DD5B: bpl MsObj_DD64 ; original $dd5b
MsObj_DD5D: CPX #$04 ; original $dd5d
MsObj_DD5F: bcc MsObj_DD64 ; original $dd5f
MsObj_DD61: JMP MsObj_DE0F ; original $dd61
MsObj_DD64: LDA MsState+$0558,X ; original $dd64
MsObj_DD67: beq MsObj_DD99 ; original $dd67
MsObj_DD69: bmi MsObj_DD7A ; original $dd69
MsObj_DD6B: CLC ; original $dd6b
MsObj_DD6C: ADC MsState+$0480,X ; original $dd6c
MsObj_DD6F: STA MsState+$0480,X ; original $dd6f
MsObj_DD72: bcc MsObj_DD8E ; original $dd72
MsObj_DD74: INC MsState+$0498,X ; original $dd74
MsObj_DD77: JMP MsObj_DD8E ; original $dd77
MsObj_DD7A: EOR #$ff ; original $dd7a
MsObj_DD7C: STA MsState+$0071 ; original $dd7c
MsObj_DD7E: INC MsState+$0071 ; original $dd7e
MsObj_DD80: LDA MsState+$0480,X ; original $dd80
MsObj_DD83: SEC ; original $dd83
MsObj_DD84: SBC MsState+$0071 ; original $dd84
MsObj_DD86: STA MsState+$0480,X ; original $dd86
MsObj_DD89: bcs MsObj_DD8E ; original $dd89
MsObj_DD8B: DEC MsState+$0498,X ; original $dd8b
MsObj_DD8E: LDA MsState+$0528,X ; original $dd8e
MsObj_DD91: bmi MsObj_DD96 ; original $dd91
MsObj_DD93: JSR MsObjectUnsupported ; original $dd93
MsObj_DD96: JSR MsObj_DE91 ; original $dd96
MsObj_DD99: LDA MsState+$0050 ; original $dd99
MsObj_DD9B: bne MsObj_DDCA ; original $dd9b
MsObj_DD9D: LDA MsState+$0570,X ; original $dd9d
MsObj_DDA0: beq MsObj_DDF8 ; original $dda0
MsObj_DDA2: bmi MsObj_DDB3 ; original $dda2
MsObj_DDA4: CLC ; original $dda4
MsObj_DDA5: ADC MsState+$04b0,X ; original $dda5
MsObj_DDA8: STA MsState+$04b0,X ; original $dda8
MsObj_DDAB: bcc MsObj_DDED ; original $ddab
MsObj_DDAD: INC MsState+$04c8,X ; original $ddad
MsObj_DDB0: JMP MsObj_DDED ; original $ddb0
MsObj_DDB3: EOR #$ff ; original $ddb3
MsObj_DDB5: STA MsState+$0071 ; original $ddb5
MsObj_DDB7: INC MsState+$0071 ; original $ddb7
MsObj_DDB9: LDA MsState+$04b0,X ; original $ddb9
MsObj_DDBC: SEC ; original $ddbc
MsObj_DDBD: SBC MsState+$0071 ; original $ddbd
MsObj_DDBF: STA MsState+$04b0,X ; original $ddbf
MsObj_DDC2: bcs MsObj_DDED ; original $ddc2
MsObj_DDC4: DEC MsState+$04c8,X ; original $ddc4
MsObj_DDC7: JMP MsObj_DDED ; original $ddc7
MsObj_DDCA: LDA MsState+$0570,X ; original $ddca
MsObj_DDCD: beq MsObj_DDF8 ; original $ddcd
MsObj_DDCF: CLC ; original $ddcf
MsObj_DDD0: ADC MsState+$04b0,X ; original $ddd0
MsObj_DDD3: STA MsState+$04b0,X ; original $ddd3
MsObj_DDD6: CMP #$f0 ; original $ddd6
MsObj_DDD8: bcc MsObj_DDED ; original $ddd8
MsObj_DDDA: LDY MsState+$0570,X ; original $ddda
MsObj_DDDD: bmi MsObj_DDE7 ; original $dddd
MsObj_DDDF: SBC #$f0 ; original $dddf
MsObj_DDE1: STA MsState+$04b0,X ; original $dde1
MsObj_DDE4: JMP MsObj_DDED ; original $dde4
MsObj_DDE7: CLC ; original $dde7
MsObj_DDE8: ADC #$f0 ; original $dde8
MsObj_DDEA: STA MsState+$04b0,X ; original $ddea
MsObj_DDED: LDA MsState+$0528,X ; original $dded
MsObj_DDF0: bmi MsObj_DDF5 ; original $ddf0
MsObj_DDF2: JSR MsObjectUnsupported ; original $ddf2
MsObj_DDF5: JSR MsObj_E04C ; original $ddf5
MsObj_DDF8: LDA MsState+$0588,X ; original $ddf8
MsObj_DDFB: bpl MsObj_DE0F ; original $ddfb
MsObj_DDFD: LDA MsState+$0053 ; original $ddfd
MsObj_DDFF: AND MsState+$05a0,X ; original $ddff
MsObj_DE02: bne MsObj_DE0F ; original $de02
MsObj_DE04: INC MsState+$04f8,X ; original $de04
MsObj_DE07: LDA MsState+$04f8,X ; original $de07
MsObj_DE0A: AND #$07 ; original $de0a
MsObj_DE0C: STA MsState+$04f8,X ; original $de0c
MsObj_DE0F: RTS ; original $de0f
MsObj_DE91: LDA MsState+$0600,X ; original $de91
MsObj_DE94: AND #$40 ; original $de94
MsObj_DE96: jne MsObjectUnsupported ; original $de96
MsObj_DE98: LDA MsState+$0600,X ; original $de98
MsObj_DE9B: AND #$08 ; original $de9b
MsObj_DE9D: jeq MsObjReturn ; original $de9d
MsObj_DE9F: JMP MsObj_DF33 ; original $de9f
MsObj_DF33: LDA MsState+$0528,X ; original $df33
MsObj_DF36: AND #$7f ; original $df36
MsObj_DF38: TAY ; original $df38
MsObj_DF39: STY MsState+$007b ; original $df39
MsObj_DF3B: LDA MsState+$04b0,X ; original $df3b
MsObj_DF3E: CLC ; original $df3e
MsObj_DF3F: ADC MsObj_DFFB,Y ; original $df3f
MsObj_DF42: STA MsState+$005b ; original $df42
MsObj_DF44: LDY MsState+$0050 ; original $df44
MsObj_DF46: beq MsObj_DF51 ; original $df46
MsObj_DF48: JSR MsNativeFF3F ; original $df48
MsObj_DF4B: LDA #$00 ; original $df4b
MsObj_DF4D: STA MsState+$005c ; original $df4d
MsObj_DF4F: beq MsObj_DF58 ; original $df4f
MsObj_DF51: LDA MsState+$04c8,X ; original $df51
MsObj_DF54: ADC #$00 ; original $df54
MsObj_DF56: STA MsState+$005c ; original $df56
MsObj_DF58: LDY MsState+$007b ; original $df58
MsObj_DF5A: LDA MsState+$0558,X ; original $df5a
MsObj_DF5D: bpl MsObj_DF72 ; original $df5d
MsObj_DF5F: LDA MsState+$0480,X ; original $df5f
MsObj_DF62: CLC ; original $df62
MsObj_DF63: ADC MsObj_DFF3,Y ; original $df63
MsObj_DF66: STA MsState+$0059 ; original $df66
MsObj_DF68: LDA MsState+$0498,X ; original $df68
MsObj_DF6B: ADC #$00 ; original $df6b
MsObj_DF6D: STA MsState+$005a ; original $df6d
MsObj_DF6F: JMP MsObj_DF82 ; original $df6f
MsObj_DF72: LDA MsState+$0480,X ; original $df72
MsObj_DF75: CLC ; original $df75
MsObj_DF76: ADC MsObj_DFF7,Y ; original $df76
MsObj_DF79: STA MsState+$0059 ; original $df79
MsObj_DF7B: LDA MsState+$0498,X ; original $df7b
MsObj_DF7E: ADC #$00 ; original $df7e
MsObj_DF80: STA MsState+$005a ; original $df80
MsObj_DF82: LDA MsState+$04e0,X ; original $df82
MsObj_DF85: bmi MsObj_DF8B ; original $df85
MsObj_DF87: LDA #$08 ; original $df87
MsObj_DF89: bne MsObj_DF8D ; original $df89
MsObj_DF8B: LDA #$10 ; original $df8b
MsObj_DF8D: STA MsState+$007c ; original $df8d
MsObj_DF8F: LDA MsState+$005a ; original $df8f
MsObj_DF91: bpl MsObj_DF94 ; original $df91
MsObj_DF93: RTS ; original $df93
MsObj_DF94: CMP MsState+$0733 ; original $df94
MsObj_DF97: bcc MsObj_DF9B ; original $df97
MsObj_DF99: bne MsObj_DF93 ; original $df99
MsObj_DF9B: JSR MsNativeShotTileQuery ; original $df9b
MsObj_DF9E: LDY #$00 ; original $df9e
MsObj_DFA0: LDA (MsPointer),Y ; original $dfa0
MsObj_DFA2: AND MsState+$007c ; original $dfa2
MsObj_DFA4: beq MsObj_DFA9 ; original $dfa4
MsObj_DFA6: JMP MsObj_DFD4 ; original $dfa6
MsObj_DFA9: LDA MsState+$04b0,X ; original $dfa9
MsObj_DFAC: LDY MsState+$007b ; original $dfac
MsObj_DFAE: CLC ; original $dfae
MsObj_DFAF: ADC MsObj_DFFF,Y ; original $dfaf
MsObj_DFB2: STA MsState+$005b ; original $dfb2
MsObj_DFB4: LDY MsState+$0050 ; original $dfb4
MsObj_DFB6: beq MsObj_DFC1 ; original $dfb6
MsObj_DFB8: JSR MsNativeFF3F ; original $dfb8
MsObj_DFBB: LDA #$00 ; original $dfbb
MsObj_DFBD: STA MsState+$005c ; original $dfbd
MsObj_DFBF: beq MsObj_DFC8 ; original $dfbf
MsObj_DFC1: LDA MsState+$04c8,X ; original $dfc1
MsObj_DFC4: ADC #$00 ; original $dfc4
MsObj_DFC6: STA MsState+$005c ; original $dfc6
MsObj_DFC8: JSR MsNativeShotTileQuery ; original $dfc8
MsObj_DFCB: LDY #$00 ; original $dfcb
MsObj_DFCD: LDA (MsPointer),Y ; original $dfcd
MsObj_DFCF: AND MsState+$007c ; original $dfcf
MsObj_DFD1: bne MsObj_DFD4 ; original $dfd1
MsObj_DFD3: RTS ; original $dfd3
MsObj_DFD4: TXA ; original $dfd4
MsObj_DFD5: TAY ; original $dfd5
MsObj_DFD6: JSR MsNativeFF33 ; original $dfd6
MsObj_DFD9: LDA #$80 ; original $dfd9
MsObj_DFDB: STA MsState+$0618,X ; original $dfdb
MsObj_DFDE: LDA MsState+$0059 ; original $dfde
MsObj_DFE0: SEC ; original $dfe0
MsObj_DFE1: SBC #$08 ; original $dfe1
MsObj_DFE3: STA MsState+$0480,X ; original $dfe3
MsObj_DFE6: LDA MsState+$005a ; original $dfe6
MsObj_DFE8: SBC #$00 ; original $dfe8
MsObj_DFEA: STA MsState+$0498,X ; original $dfea
MsObj_DFED: LDA #$00 ; original $dfed
MsObj_DFEF: STA MsState+$0558,X ; original $dfef
MsObj_DFF2: RTS ; original $dff2
MsObj_E04C: LDA MsState+$0600,X ; original $e04c
MsObj_E04F: AND #$40 ; original $e04f
MsObj_E051: jne MsObjectUnsupported ; original $e051
MsObj_E053: LDA MsState+$0600,X ; original $e053
MsObj_E056: AND #$08 ; original $e056
MsObj_E058: beq MsObj_E05D ; original $e058
MsObj_E05A: JMP MsObj_E1ED ; original $e05a
MsObj_E05D: RTS ; original $e05d
MsObj_E1ED: LDA MsState+$0528,X ; original $e1ed
MsObj_E1F0: AND #$7f ; original $e1f0
MsObj_E1F2: TAY ; original $e1f2
MsObj_E1F3: STY MsState+$007b ; original $e1f3
MsObj_E1F5: LDA MsState+$0480,X ; original $e1f5
MsObj_E1F8: CLC ; original $e1f8
MsObj_E1F9: ADC MsObj_E1DD,Y ; original $e1f9
MsObj_E1FC: STA MsState+$0059 ; original $e1fc
MsObj_E1FE: LDA MsState+$0498,X ; original $e1fe
MsObj_E201: ADC #$00 ; original $e201
MsObj_E203: STA MsState+$005a ; original $e203
MsObj_E205: LDA MsState+$0570,X ; original $e205
MsObj_E208: bpl MsObj_E220 ; original $e208
MsObj_E20A: LDA MsState+$04b0,X ; original $e20a
MsObj_E20D: CLC ; original $e20d
MsObj_E20E: ADC MsObj_E1E5,Y ; original $e20e
MsObj_E211: STA MsState+$005b ; original $e211
MsObj_E213: LDY MsState+$0050 ; original $e213
MsObj_E215: beq MsObj_E236 ; original $e215
MsObj_E217: JSR MsNativeFF3F ; original $e217
MsObj_E21A: LDA #$00 ; original $e21a
MsObj_E21C: STA MsState+$005c ; original $e21c
MsObj_E21E: beq MsObj_E23D ; original $e21e
MsObj_E220: LDA MsState+$04b0,X ; original $e220
MsObj_E223: CLC ; original $e223
MsObj_E224: ADC MsObj_E1E9,Y ; original $e224
MsObj_E227: STA MsState+$005b ; original $e227
MsObj_E229: LDY MsState+$0050 ; original $e229
MsObj_E22B: beq MsObj_E236 ; original $e22b
MsObj_E22D: JSR MsNativeFF3F ; original $e22d
MsObj_E230: LDA #$00 ; original $e230
MsObj_E232: STA MsState+$005c ; original $e232
MsObj_E234: beq MsObj_E23D ; original $e234
MsObj_E236: LDA MsState+$04c8,X ; original $e236
MsObj_E239: ADC #$00 ; original $e239
MsObj_E23B: STA MsState+$005c ; original $e23b
MsObj_E23D: LDA MsState+$04e0,X ; original $e23d
MsObj_E240: bmi MsObj_E246 ; original $e240
MsObj_E242: LDA #$08 ; original $e242
MsObj_E244: bne MsObj_E248 ; original $e244
MsObj_E246: LDA #$10 ; original $e246
MsObj_E248: STA MsState+$007c ; original $e248
MsObj_E24A: JSR MsNativeShotTileQuery ; original $e24a
MsObj_E24D: LDY #$00 ; original $e24d
MsObj_E24F: LDA (MsPointer),Y ; original $e24f
MsObj_E251: AND MsState+$007c ; original $e251
MsObj_E253: beq MsObj_E258 ; original $e253
MsObj_E255: JMP MsObj_E276 ; original $e255
MsObj_E258: LDA MsState+$0480,X ; original $e258
MsObj_E25B: LDY MsState+$007b ; original $e25b
MsObj_E25D: CLC ; original $e25d
MsObj_E25E: ADC MsObj_E1E1,Y ; original $e25e
MsObj_E261: STA MsState+$0059 ; original $e261
MsObj_E263: LDA MsState+$0498,X ; original $e263
MsObj_E266: ADC #$00 ; original $e266
MsObj_E268: STA MsState+$005a ; original $e268
MsObj_E26A: JSR MsNativeShotTileQuery ; original $e26a
MsObj_E26D: LDY #$00 ; original $e26d
MsObj_E26F: LDA (MsPointer),Y ; original $e26f
MsObj_E271: AND MsState+$007c ; original $e271
MsObj_E273: bne MsObj_E276 ; original $e273
MsObj_E275: RTS ; original $e275
MsObj_E276: TXA ; original $e276
MsObj_E277: TAY ; original $e277
MsObj_E278: JSR MsNativeFF36 ; original $e278
MsObj_E27B: LDA #$80 ; original $e27b
MsObj_E27D: STA MsState+$0618,X ; original $e27d
MsObj_E280: LDA #$00 ; original $e280
MsObj_E282: STA MsState+$0570,X ; original $e282
MsObj_E285: LDA MsState+$005b ; original $e285
MsObj_E287: SEC ; original $e287
MsObj_E288: SBC #$08 ; original $e288
MsObj_E28A: STA MsState+$04b0,X ; original $e28a
MsObj_E28D: LDY MsState+$0050 ; original $e28d
MsObj_E28F: bne MsObj_E29B ; original $e28f
MsObj_E291: LDA MsState+$005c ; original $e291
MsObj_E293: SBC #$00 ; original $e293
MsObj_E295: STA MsState+$04c8,X ; original $e295
MsObj_E298: JMP MsObj_E2AD ; original $e298
MsObj_E29B: bcs MsObj_E29F ; original $e29b
MsObj_E29D: ADC #$f0 ; original $e29d
MsObj_E29F: CMP #$f0 ; original $e29f
MsObj_E2A1: bcc MsObj_E2A5 ; original $e2a1
MsObj_E2A3: SBC #$f0 ; original $e2a3
MsObj_E2A5: STA MsState+$04b0,X ; original $e2a5
MsObj_E2A8: LDA #$00 ; original $e2a8
MsObj_E2AA: STA MsState+$04c8,X ; original $e2aa
MsObj_E2AD: LDA MsState+$0718 ; original $e2ad
MsObj_E2B0: bmi MsObj_E2C3 ; original $e2b0
MsObj_E2B2: LDA MsState+$0480,X ; original $e2b2
MsObj_E2B5: SEC ; original $e2b5
MsObj_E2B6: SBC #$04 ; original $e2b6
MsObj_E2B8: STA MsState+$0480,X ; original $e2b8
MsObj_E2BB: LDA MsState+$0498,X ; original $e2bb
MsObj_E2BE: SBC #$00 ; original $e2be
MsObj_E2C0: STA MsState+$0498,X ; original $e2c0
MsObj_E2C3: RTS ; original $e2c3
MsObj_E32B: CPX #$04 ; original $e32b
MsObj_E32D: jcc Ms_E32A ; original $e32d
 jmp MsObjectUnsupported ; ineligible source object path
MsObj_FC5E: LDA MsState+$0119 ; original $fc5e
MsObj_FC61: ORA MsState+$011a ; original $fc61
MsObj_FC64: AND #$7f ; original $fc64
MsObj_FC66: beq MsObj_FC72 ; original $fc66
MsObj_FC68: LDA #$00 ; original $fc68
MsObj_FC6A: STA MsState+$0119 ; original $fc6a
MsObj_FC6D: LDA #$80 ; original $fc6d
MsObj_FC6F: STA MsState+$011a ; original $fc6f
MsObj_FC72: LDA MsState+$0119 ; original $fc72
MsObj_FC75: EOR #$80 ; original $fc75
MsObj_FC77: CMP MsState+$011a ; original $fc77
MsObj_FC7A: jeq MsObjReturn ; original $fc7a
MsObj_FC7C: LDA MsState+$011f ; original $fc7c
MsObj_FC7F: AND #$7f ; original $fc7f
MsObj_FC81: bne MsObj_FC68 ; original $fc81
MsObj_FC83: LDA MsState+$011f ; original $fc83
MsObj_FC86: STA MsState+$0119 ; original $fc86
MsObj_FC89: EOR #$80 ; original $fc89
MsObj_FC8B: STA MsState+$011a ; original $fc8b
 rts ; pure reset control-option leaf boundary
MsObj_DB1B: .byte $00
MsObj_DB1C: .byte $00
MsObj_DB1D: .byte $00
MsObj_DB1E: .byte $00
MsObj_DB1F: .byte $00
MsObj_DB20: .byte $00
MsObj_DB21: .byte $00
MsObj_DB22: .byte $00
MsObj_DB23: .byte $00
MsObj_DB24: .byte $00
MsObj_DB25: .byte $00
MsObj_DB26: .byte $80
MsObj_DB27: .byte $80
MsObj_DB28: .byte $00
MsObj_DB29: .byte $00
MsObj_DB2A: .byte $00
MsObj_DB2B: .byte $00
MsObj_DB2C: .byte $00
MsObj_DB2D: .byte $00
MsObj_DB2E: .byte $00
MsObj_DB2F: .byte $00
MsObj_DB30: .byte $00
MsObj_DB31: .byte $00
MsObj_DB32: .byte $00
MsObj_DB33: .byte $00
MsObj_DB34: .byte $00
MsObj_DB35: .byte $00
MsObj_DB36: .byte $00
MsObj_DB37: .byte $00
MsObj_DB38: .byte $00
MsObj_DB39: .byte $00
MsObj_DB3A: .byte $00
MsObj_DB3B: .byte $00
MsObj_DB3C: .byte $00
MsObj_DB3D: .byte $00
MsObj_DB3E: .byte $00
MsObj_DB3F: .byte $00
MsObj_DB40: .byte $00
MsObj_DB41: .byte $00
MsObj_DB42: .byte $00
MsObj_DB43: .byte $00
MsObj_DB44: .byte $00
MsObj_DB45: .byte $00
MsObj_DB46: .byte $00
MsObj_DB47: .byte $00
MsObj_DB48: .byte $00
MsObj_DB49: .byte $00
MsObj_DB4A: .byte $00
MsObj_DB4B: .byte $00
MsObj_DB4C: .byte $00
MsObj_DB4D: .byte $00
MsObj_DB4E: .byte $00
MsObj_DB4F: .byte $00
MsObj_DB50: .byte $00
MsObj_DB51: .byte $00
MsObj_DB52: .byte $00
MsObj_DB53: .byte $00
MsObj_DB54: .byte $00
MsObj_DB55: .byte $00
MsObj_DB56: .byte $00
MsObj_DB57: .byte $00
MsObj_DB58: .byte $00
MsObj_DB59: .byte $00
MsObj_DB5A: .byte $00
MsObj_DB5B: .byte $00
MsObj_DB5C: .byte $80
MsObj_DB5D: .byte $80
MsObj_DB5E: .byte $00
MsObj_DB5F: .byte $00
MsObj_DB60: .byte $00
MsObj_DB61: .byte $00
MsObj_DB62: .byte $00
MsObj_DB63: .byte $00
MsObj_DB64: .byte $00
MsObj_DB65: .byte $00
MsObj_DB66: .byte $00
MsObj_DB67: .byte $00
MsObj_DB68: .byte $00
MsObj_DB69: .byte $00
MsObj_DB6A: .byte $00
MsObj_DB6B: .byte $00
MsObj_DB6C: .byte $00
MsObj_DB6D: .byte $00
MsObj_DB6E: .byte $00
MsObj_DB6F: .byte $00
MsObj_DB70: .byte $00
MsObj_DB71: .byte $00
MsObj_DB72: .byte $00
MsObj_DB73: .byte $00
MsObj_DB74: .byte $00
MsObj_DB75: .byte $00
MsObj_DB76: .byte $80
MsObj_DB77: .byte $00
MsObj_DB78: .byte $00
MsObj_DB79: .byte $00
MsObj_DB7A: .byte $00
MsObj_DB7B: .byte $00
MsObj_DB7C: .byte $00
MsObj_DB7D: .byte $00
MsObj_DB7E: .byte $00
MsObj_DB7F: .byte $00
MsObj_DB80: .byte $00
MsObj_DB81: .byte $00
MsObj_DB82: .byte $00
MsObj_DB83: .byte $00
MsObj_DB84: .byte $00
MsObj_DB85: .byte $00
MsObj_DB86: .byte $00
MsObj_DB87: .byte $00
MsObj_DB88: .byte $00
MsObj_DB89: .byte $00
MsObj_DB8A: .byte $00
MsObj_DB8B: .byte $00
MsObj_DB8C: .byte $00
MsObj_DB8D: .byte $00
MsObj_DB8E: .byte $00
MsObj_DB8F: .byte $00
MsObj_DB90: .byte $00
MsObj_DB91: .byte $00
MsObj_DB92: .byte $00
MsObj_DB93: .byte $00
MsObj_DB94: .byte $00
MsObj_DB95: .byte $00
MsObj_DB96: .byte $00
MsObj_DB97: .byte $00
MsObj_DB98: .byte $00
MsObj_DB99: .byte $00
MsObj_DB9A: .byte $00
MsObj_DFF3: .byte $02
MsObj_DFF4: .byte $05
MsObj_DFF5: .byte $00
MsObj_DFF6: .byte $00
MsObj_DFF7: .byte $05
MsObj_DFF8: .byte $0a
MsObj_DFF9: .byte $00
MsObj_DFFA: .byte $00
MsObj_DFFB: .byte $06
MsObj_DFFC: .byte $04
MsObj_DFFD: .byte $00
MsObj_DFFE: .byte $00
MsObj_DFFF: .byte $09
MsObj_E000: .byte $0b
MsObj_E001: .byte $00
MsObj_E002: .byte $00
MsObj_E1DD: .byte $02
MsObj_E1DE: .byte $04
MsObj_E1DF: .byte $00
MsObj_E1E0: .byte $00
MsObj_E1E1: .byte $05
MsObj_E1E2: .byte $0b
MsObj_E1E3: .byte $00
MsObj_E1E4: .byte $00
MsObj_E1E5: .byte $06
MsObj_E1E6: .byte $08
MsObj_E1E7: .byte $00
MsObj_E1E8: .byte $00
MsObj_E1E9: .byte $09
MsObj_E1EA: .byte $0e
MsObj_E1EB: .byte $00
MsObj_E1EC: .byte $00
MsObjReturn:rts
MsActorAnimationMasks:.byte $03,$03,$01,$01,$01,$01,$01,$01
.export MsObj_DCAE,MsObj_8BCF,MsObj_DD48,MsObj_DA8F,MsObj_D783

; Bound include C:\Users\kando\Documents\ChatGPT\SMB Crossover\build\metal-storm-render-host-1101-v7\objects-ready.inc
; Original FF27/8BCF capsule eligibility, not a selectable admission.
; Negative original projectile types80/81 in source slots1..3 only.
; Original enemy/GravityFire metadata is deliberately outside this component.
.export MsNativeObjectsReady,MsNativeShotTileQuery,MsNativeAnimationMask,MsObjectsHostEnd
.global MsObjectUnsupported
MsDonorMapperSelect=$c818
MsDonorMapperData=$c819
MsNativeObjectsReady:
 php
 pha
 txa
 pha
 lda MsState+$717
 bmi BadObject ; GravityFire can create unsupportedslot1 later in actor step
 ldx #23
CheckObject:
 lda MsState+$510,x
 beq NextObject
 cpx #4
 bcs BadObject
 lda MsState+$528,x
 cmp #$83
 beq CheckImpactFlags
 cmp #$80
 beq CheckObjectFlags
 cmp #$81
 bne BadObject
CheckObjectFlags:
 lda MsState+$600,x
 cmp #$0a
 bne BadObject
 beq NextObject
CheckImpactFlags:
 lda MsState+$600,x
 cmp #5
 bne BadObject
 lda MsState+$618,x
 bne BadObject
 lda MsState+$630,x
 cmp #3
 bcs BadObject
NextObject:
 dex
 bne CheckObject
 tsx
 lda $0103,x
 ora #1
 bne ObjectResult
BadObject:
 tsx
 lda $0103,x
 and #$fe
ObjectResult:
 sta $0103,x
 pla
 tax
 pla
 plp
 rts

; The original shot collision code tests separate normal/upgraded bits08/10.
; Native fully solid terrain admits both contact masks; actor FF1E remainsE0.
; Bit02/04 donor hazard flags remain clear. X retained, Y=0, A/P volatile.
MsNativeShotTileQuery:
 jsr MsNativeTileQuery
 lda MsTileFlags
 beq :+
 ora #$18
 sta MsTileFlags
:rts

; Original rendererF2EA..F2F7 reads byte(state+5) from original actor metadata.
; Keep that exact source animation mask even before native OAM integration.
; Call after actor step (renderer ordering), and for the first ctor pose.
; All AXYP retained; no source/host pointer or PPU accesses.
MsNativeAnimationMask:
 php
 pha
 txa
 pha
 lda MsState+$4e0
 cmp #8
 bcs :+
 tax
 lda MsActorAnimationMasks,x
 sta MsState+$5a0
:pla
 tax
 pla
 plp
 rts
MsObjectsHostEnd:

.export MsState


; Bound include C:\Users\kando\Documents\ChatGPT\SMB Crossover\build\metal-storm-owning-graft-1101-v11\renderer.inc
; Bound include C:\Users\kando\Documents\ChatGPT\SMB Crossover\tools\reference\metal_storm_palette_host_1101_v9.inc
; Intentional NES palette adaptation for the selected Metal Storm player only.
; The original body uses P0 and the original shots P1. SMB keeps P1/P2/P3
; for native actors, so remapped body/shot bitplanes share this one P0.
; No shape/alpha/geometry change and no native-world palette/CHR edit.
; Invoke these two macros at the exact source sites verified by the v9 recipe.
; Neither macro grants PRG/CHR/RAM ownership or supplies a cold-loader gate.
.global Ms9Color1,Ms9Color2,Ms9Color3
.macro Ms9ShotPalette0
 and #$fc                  ; retain every non-palette attribute, including H/V
.endmacro
.macro Ms9PalettePacket
 .byte $3f,$10,4,0
 .lobytes Ms9Color1,Ms9Color2,Ms9Color3
.endmacro

; Separate proposed C2 renderer/lifecycle. Source actorA3 remains underBFE0.
; No runtime resource grant is implied. ROM frontgate must authenticate BOTH
; complete C2/C3 headers before any C2 opcode. All native calls are actual APIs.
.global MetaspriteRenderLoop,X5SetPhysicalChr,FarCallCommon
.global SafecallA_SMC,FarcallJmpTarget_SMC,CurrentBank,CurrentBankC
.global ScreenLeft_X_Pos,ScreenLeft_PageLoc,Player_SprAttrib
.global CurrentOAMOffset,SsChrActive,VRAM_Buffer1,VRAM_Buffer1_Offset
.global ObjectMetasprite,SmPosePtr
.global SelectedCharacter,OperMode,GameEngineSubroutine
.global MsBodyPhysical0,MsBodyPhysical1,MsBodyPhysical2,MsBodyPhysical3,MsBodyPhysical4,MsShotPhysical
.global MS_NATIVE_DRAW_BANK,MS_NATIVE_CHR_BANK
.globalzp R0,R1,R2,R3,R4,R5,R6,R7
.export MsRenderGraphics,MsRenderDraw,MsRenderColors,MsObjectLifecycle,MsRenderEnd
MsRS=$c81a
MsSmc=$c826
MsSlot=$c829
MsBits=$c82a
MsCount=$c82b
MsIndex=$c82c
MsBaseLo=$c82d
MsBaseHi=$c82e
MsPage0=$c82f
MsPage1=$c830
MsCellDx=$c831
MsCellDy=$c832
MsCellPattern=$c833
MsCellAttr=$c834
MsPacketAt=$c835
MsOrderLo=$c836
MsOrderHi=$c837
MsYMulLo=$c838
MsYMulHi=$c839
MsTemp=$c83a
MsFlip=$c83b
MsPriority=$c83c
MsPacket=$c880

.macro MsRFar Target,Bank
 sta SafecallA_SMC+1
 lda #<Target
 sta FarcallJmpTarget_SMC+1
 lda #>Target
 sta FarcallJmpTarget_SMC+2
 lda #<Bank
 jsr FarCallCommon
.endmacro

.segment "MS11_RENDER"
MsRSave:
 sta MsRS
 stx MsRS+1
 sty MsRS+2
 php
 pla
 sta MsRS+3
 ldx #7
:lda R0,x
 sta MsRS+4,x
 dex
 bpl :-
 lda SafecallA_SMC+1
 sta MsSmc
 lda FarcallJmpTarget_SMC+1
 sta MsSmc+1
 lda FarcallJmpTarget_SMC+2
 sta MsSmc+2
 rts
MsRRestore:
 lda MsSmc
 sta SafecallA_SMC+1
 lda MsSmc+1
 sta FarcallJmpTarget_SMC+1
 lda MsSmc+2
 sta FarcallJmpTarget_SMC+2
 ldx #7
:lda MsRS+4,x
 sta R0,x
 dex
 bpl :-
 lda MsRS+3
 pha
 lda MsRS
 ldx MsRS+1
 ldy MsRS+2
 plp
 sec
 rts

; Native world anchors, not an additional source/world camera integration.
; Source signed240Y is converted exactly to nativeYHigh1 domain.
MsRPosition:
 ldx MsSlot
 lda MsState+$480,x
 sec
 sbc ScreenLeft_X_Pos
 sta R4
 lda MsState+$498,x
 sbc ScreenLeft_PageLoc
 sta R5
 lda MsState+$4c8,x
 sta MsYMulLo
 lda #0
 bit MsYMulLo
 bpl :+
 lda #$ff
:sta MsYMulHi
 .repeat 4
 asl MsYMulLo
 rol MsYMulHi
 .endrepeat
 lda MsState+$4b0,x
 sec
 sbc MsYMulLo
 sta R6
 lda MsState+$4c8,x
 sbc MsYMulHi
 clc
 adc #1
 sta R7
 rts

MsRenderDraw:
 jsr MsRenderGraphics
 jsr MsRSave
 lda #0
 sta SsChrActive             ; selected owner removes stale window4 override
 lda MsState+$53
 and #1
 bne MsOddOrder
 jsr MsRBody
 lda #1
 sta MsSlot
MsEvenShot:
 jsr MsRShot
 inc MsSlot
 lda MsSlot
 cmp #4
 bcc MsEvenShot
 jmp MsRRestore

MsRenderGraphics:
 jsr MsRSave
 lda #0
 sta SsChrActive
 sta ObjectMetasprite
 lda #<ObjectMetasprite
 sta SmPosePtr
 lda #>ObjectMetasprite
 sta SmPosePtr+1
 jmp MsRRestore
MsOddOrder:
 lda #3
 sta MsSlot
MsOddShot:
 jsr MsRShot
 dec MsSlot
 bne MsOddShot
 jsr MsRBody
 jmp MsRRestore

MsRBody:
 lda MsState+$528
 cmp #2
 jne Ms34LiveBody
 rts
Ms34LiveBody:
 lda MsState+$510
 jpl MsBodyDone
 lda MsState+$4e0
 cmp #8
 jcs MsBodyDone
 asl a
 asl a
 asl a
 sta MsTemp
 lda MsState+$4f8
 and #7
 ora MsTemp
 tax
 lda MsBodyMap,x
 cmp #$ff
 jeq MsBodyDone
 tax
 lda MsBodyCounts,x
 sta MsCount
 asl a
 asl a
 sta MsPacket
 lda MsBodyOffsets,x
 clc
 adc #<MsBodyCells
 sta MsBaseLo
 lda #0
 adc #>MsBodyCells
 sta MsBaseHi
 lda MsState+$540
 and #$c0
 sta MsFlip
 .repeat 6
 lsr a
 .endrepeat
 sta MsBits
 ldx MsCount
 cpx #6
 bne MsOrderEight
 asl a
 sta MsTemp
 asl a
 clc
 adc MsTemp
 clc
 adc #<MsBodyOrders6
 sta MsOrderLo
 lda #>MsBodyOrders6
 adc #0
 jmp MsOrderHigh
MsOrderEight:
 asl a
 asl a
 asl a
 clc
 adc #<MsBodyOrders8
 sta MsOrderLo
 lda #>MsBodyOrders8
 adc #0
MsOrderHigh:
 sta MsOrderHi
 lda #$ff
 sta MsPage0
 sta MsPage1
 lda #0
 sta MsIndex
MsBodyCell:
 lda MsOrderLo
 sta R0
 lda MsOrderHi
 sta R1
 ldy MsIndex
 lda (R0),y
 tay
 tax
 lda MsCount
 cmp #8
 bne Ms29Coordinate
 txa
 clc
 adc #6
 tax
Ms29Coordinate:
 lda Ms29Dx,x
 sta MsCellDx
 lda Ms29Dy,x
 sta MsCellDy
 lda MsBaseLo
 sta R0
 lda MsBaseHi
 sta R1
 lda (R0),y
 sta MsCellPattern
 lda MsFlip
 sta MsCellAttr
 lda MsIndex
 asl a
 asl a
 clc
 adc #1
 sta MsPacketAt
 lda MsCellPattern
 .repeat 5
 lsr a
 .endrepeat
 cmp MsPage0
 beq MsTileFirst
 ldx MsPage0
 cpx #$ff
 bne MsTileSecond
 sta MsPage0
 jmp MsTileFirst
MsTileSecond:
 cmp MsPage1
 beq MsTileSecondReady
 ldx MsPage1
 cpx #$ff
 jne MsBodyDone              ; frozen source packets never require3pages
 sta MsPage1
MsTileSecondReady:
 lda MsCellPattern
 and #31
 asl a
 ora #$41                   ; odd tile: spriteP1/window5, preserving worldP0
 bne MsTileStore
MsTileFirst:
 lda MsCellPattern
 and #31
 asl a
 ora #0                     ; selected-player P0/window0; world4 retained
MsTileStore:
 ldy MsPacketAt
 sta MsPacket,y
 iny
 lda MsCellAttr
 sta MsPacket,y
 iny
 lda MsBits
 and #2
 beq MsDyPlain
 lda #18
 sec
 sbc MsCellDy
 jmp MsDyReady
MsDyPlain:lda MsCellDy
MsDyReady:
 sec
 sbc #1                     ; source metadata dy includes OAMY+1
 sta MsPacket,y
 iny
 lda MsBits
 and #1
 beq MsDxPlain
 lda #24
 sec
 sbc MsCellDx
 jmp MsDxReady
MsDxPlain:lda MsCellDx
MsDxReady:sta MsPacket,y
 inc MsIndex
 lda MsIndex
 cmp MsCount
 jne MsBodyCell
 ldx MsPage0
 lda MsBodyPhysicalLo,x
 ldy MsBodyPhysicalHi,x
 sty MsTemp
 ldx MsTemp
 ldy #0
 MsRFar X5SetPhysicalChr,MS_NATIVE_CHR_BANK
 ldx MsPage1
 cpx #$ff
 beq MsBodyMapped
 lda MsBodyPhysicalLo,x
 ldy MsBodyPhysicalHi,x
 sty MsTemp
 ldx MsTemp
 ldy #5
 MsRFar X5SetPhysicalChr,MS_NATIVE_CHR_BANK
MsBodyMapped:
 lda #0
 sta MsSlot
 jsr MsRPosition
 lda Player_SprAttrib
 and #$20
 sta R3
 jsr MsEmitPacket
MsBodyDone:rts

MsRShot:
 ldx MsSlot
 lda MsState+$510,x
 jpl MsShotDone
 lda MsState+$648,x
 jne MsShotDone
 lda MsState+$528,x
 cmp #$80
 beq MsShotNormal
 cmp #$81
 beq MsShotUpgraded
 cmp #$83
 jne MsShotDone
 lda MsState+$630,x
 cmp #2
 bcc MsShotImpact
 jne MsShotDone             ; unreachable post-terminator metadata not admitted
 jsr MsLife_EEAE            ; exact source impact termination fields
 rts
MsShotImpact:
 clc
 adc #3
 bne MsShotIndex
MsShotNormal:lda #0
 beq MsShotIndex
MsShotUpgraded:
 lda #1
 ldy MsState+$558,x
 bne MsShotIndex
 lda #2
MsShotIndex:
 sta MsPriority
 tax
 lda MsShotOffsets,x
 clc
 adc #<MsShotMeta
 sta R0
 lda #>MsShotMeta
 adc #0
 sta R1
 ldy #0
 lda (R0),y
 sta MsPacket
 tay
MsShotCopy:
 lda (R0),y
 sta MsPacket,y
 dey
 bne MsShotCopy
 lda MsPacket
 sta MsCount
 lda #1
 sta MsPacketAt
 ldx MsSlot
 lda MsState+$540,x
 sta MsFlip
 lda MsPriority
 cmp #3
 bcc MsShotMoving
 lda #0                     ; source impact metadata ignores shot orientation
 sta MsFlip
 beq MsShotCell
MsShotMoving:
 cmp #2
 bne MsShotCell
 lda MsFlip
 and #$bf                  ; source vertical first clearsH; second forcesH
 sta MsFlip
MsShotCell:
 ldy MsPacketAt
 lda MsPacket,y
 asl a
 ora #$a1                   ; window6, last bodypage patterns16..20, worldP0 andBG unaffected
 sta MsPacket,y
 iny
 lda MsPacket,y
 Ms9ShotPalette0
 ora MsFlip
 sta MsPacket,y
 lda MsPacketAt
 clc
 adc #4
 sta MsPacketAt
 cmp MsCount
 bcc MsShotCell
 lda #<MsShotPhysical
 ldx #>MsShotPhysical
 ldy #6
 MsRFar X5SetPhysicalChr,MS_NATIVE_CHR_BANK
 jsr MsRPosition
 lda #0
 sta R3
 jsr MsEmitPacket
MsShotDone:rts

MsEmitPacket:
 lda CurrentOAMOffset
 sta MsPriority             ; source F274 visibility is cursor-change based
 lda #<MsPacket
 sta R0
 lda #>MsPacket
 sta R1
 MsRFar MetaspriteRenderLoop,MS_NATIVE_DRAW_BANK
 lda CurrentOAMOffset
 cmp MsPriority
 beq :+
 lda #$80
 bne :++
:lda #0
:ldx MsSlot
 sta MsState+$6a8,x
 rts

MsRenderColors:
 jsr MsRSave
 ldx VRAM_Buffer1_Offset
 cpx #72
 bcs MsColorsDone
 ldy #0
MsPaletteByte:
 lda MsPalettePacket,y
 sta VRAM_Buffer1,x
 inx
 iny
 cpy #7
 bcc MsPaletteByte
 ldy BackgroundColorCtrl
 bne :+
 ldy AreaType
:lda Ms19BackgroundColors,y
 sta VRAM_Buffer1-4,x
 lda #0
 sta VRAM_Buffer1,x
 stx VRAM_Buffer1_Offset
MsColorsDone:jmp MsRRestore

; Real original entityAI runs after AD8C/FF27 and before source rendering.
; Called once by accepted source step-tail, never by repeated draw epochs.
MsObjectLifecycle:
 php
 pha
 txa
 pha
 tya
 pha
 ldx #3
MsLifeLoop:
 lda MsState+$510,x
 bpl MsLifeNext
 lda MsState+$528,x
 cmp #$80
 beq MsLifeShot
 cmp #$81
 beq MsLifeShot
 cmp #$83
 bne MsLifeNext
 jsr MsLife_8E54
 jmp MsLifeNext
MsLifeShot:jsr MsLife_8EAE
MsLifeNext:
 dex
 bne MsLifeLoop
 pla
 tay
 pla
 tax
 pla
 plp
 rts
; Bound include C:\Users\kando\Documents\ChatGPT\SMB Crossover\build\metal-storm-render-host-1101-v7\render-life.inc
MsLife_8E54: LDA MsState+$0618,X ; original $8e54
MsLife_8E57: jne MsLife_8E63 ; original $8e57
MsLife_8E59: LDA MsState+$0053 ; original $8e59
MsLife_8E5B: AND #$01 ; original $8e5b
MsLife_8E5D: jne MsLife_8E62 ; original $8e5d
MsLife_8E5F: INC MsState+$0630,X ; original $8e5f
MsLife_8E62: RTS ; original $8e62
MsLife_8E63: CMP #$01 ; original $8e63
MsLife_8E65: jne MsLife_8E59 ; original $8e65
MsLife_8E67: LDA MsState+$0053 ; original $8e67
MsLife_8E69: AND #$01 ; original $8e69
MsLife_8E6B: jne MsLife_8E62 ; original $8e6b
MsLife_8E6D: INC MsState+$0630,X ; original $8e6d
MsLife_8E70: LDA MsState+$0630,X ; original $8e70
MsLife_8E73: CMP #$04 ; original $8e73
MsLife_8E75: jne MsLife_8E62 ; original $8e75
MsLife_8E77: LDA #$00 ; original $8e77
MsLife_8E79: STA MsState+$0630,X ; original $8e79
MsLife_8E7C: INC MsState+$0618,X ; original $8e7c
MsLife_8E7F: LDA MsState+$0480,X ; original $8e7f
MsLife_8E82: SEC ; original $8e82
MsLife_8E83: SBC #$08 ; original $8e83
MsLife_8E85: STA MsState+$0480,X ; original $8e85
MsLife_8E88: jcs MsLife_8E8D ; original $8e88
MsLife_8E8A: DEC MsState+$0498,X ; original $8e8a
MsLife_8E8D: LDA MsState+$04b0,X ; original $8e8d
MsLife_8E90: SEC ; original $8e90
MsLife_8E91: SBC #$08 ; original $8e91
MsLife_8E93: STA MsState+$04b0,X ; original $8e93
MsLife_8E96: LDY MsState+$0050 ; original $8e96
MsLife_8E98: jpl MsLife_8EA8 ; original $8e98
MsLife_8E9A: jcs MsLife_8E9E ; original $8e9a
MsLife_8E9C: ADC #$f0 ; original $8e9c
MsLife_8E9E: CMP #$f0 ; original $8e9e
MsLife_8EA0: jcc MsLife_8EA4 ; original $8ea0
MsLife_8EA2: SBC #$f0 ; original $8ea2
MsLife_8EA4: STA MsState+$04b0,X ; original $8ea4
MsLife_8EA7: RTS ; original $8ea7
MsLife_8EA8: jcs MsLife_8E62 ; original $8ea8
MsLife_8EAA: DEC MsState+$04c8,X ; original $8eaa
MsLife_8EAD: RTS ; original $8ead
MsLife_8EAE: LDA MsState+$0648,X ; original $8eae
MsLife_8EB1: jeq MsLife_8EB6 ; original $8eb1
MsLife_8EB3: DEC MsState+$0648,X ; original $8eb3
MsLife_8EB6: LDA MsState+$0618,X ; original $8eb6
MsLife_8EB9: jmi MsLife_8EC1 ; original $8eb9
MsLife_8EBB: DEC MsState+$0660,X ; original $8ebb
MsLife_8EBE: jeq MsLife_8EE8 ; original $8ebe
MsLife_8EC0: RTS ; original $8ec0
MsLife_8EC1: AND #$0f ; original $8ec1
MsLife_8EC3: STA MsState+$0618,X ; original $8ec3
MsLife_8EC6: LDA MsState+$0480,X ; original $8ec6
MsLife_8EC9: SEC ; original $8ec9
MsLife_8ECA: SBC MsState+$0618,X ; original $8eca
MsLife_8ECD: STA MsState+$0480,X ; original $8ecd
MsLife_8ED0: jcs MsLife_8ED5 ; original $8ed0
MsLife_8ED2: DEC MsState+$0498,X ; original $8ed2
MsLife_8ED5: LDA #$00 ; original $8ed5
MsLife_8ED7: STA MsState+$0618,X ; original $8ed7
MsLife_8EDA: STA MsState+$0630,X ; original $8eda
MsLife_8EDD: LDA #$83 ; original $8edd
MsLife_8EDF: STA MsState+$0528,X ; original $8edf
MsLife_8EE2: LDA #$05 ; original $8ee2
MsLife_8EE4: STA MsState+$0600,X ; original $8ee4
MsLife_8EE7: RTS ; original $8ee7
MsLife_8EE8: LDA #$00 ; original $8ee8
MsLife_8EEA: STA MsState+$0510,X ; original $8eea
MsLife_8EED: LDA #$80 ; original $8eed
MsLife_8EEF: STA MsState+$0498,X ; original $8eef
MsLife_8EF2: RTS ; original $8ef2
MsLife_EEAE: LDA MsState+$0648,X ; original $eeae
MsLife_EEB1: jne MsLifeUnsupported ; original $eeb1
MsLife_EEB3: LDA #$80 ; original $eeb3
MsLife_EEB5: STA MsState+$0498,X ; original $eeb5
MsLife_EEB8: STA MsState+$05e8,X ; original $eeb8
MsLife_EEBB: LDA #$00 ; original $eebb
MsLife_EEBD: STA MsState+$0510,X ; original $eebd
MsLife_EEC0: STA MsState+$06a8,X ; original $eec0
MsLife_EEC3: LDY MsState+$0061 ; original $eec3
MsLife_EEC5: RTS ; original $eec5

MsBodyMap:.incbin "body-compact.bin"
MsBodyOffsets=MsBodyMap+64
MsBodyCounts=MsBodyMap+97
MsBodyCells=MsBodyMap+130
MsBodyOrders6=MsBodyMap+334
MsBodyOrders8=MsBodyMap+358
Ms29Dx:.byte 4,12,20,4,12,20,0,8,16,24,0,8,16,24
Ms29Dy:.byte 1,1,1,17,17,17,1,1,1,1,17,17,17,17
MsShotMeta:.incbin "shot-meta.bin"
MsShotOffsets:.byte 0,5,10,19,28,37
MsBodyPhysicalLo:.lobytes MsBodyPhysical0,MsBodyPhysical1,MsBodyPhysical2,MsBodyPhysical3,MsBodyPhysical4
MsBodyPhysicalHi:.hibytes MsBodyPhysical0,MsBodyPhysical1,MsBodyPhysical2,MsBodyPhysical3,MsBodyPhysical4
MsPalettePacket:Ms9PalettePacket
Ms19BackgroundColors:.byte 34,34,15,15,15,34,15,15
MsEmptyPose:.byte 0
MsRenderEnd:


; Authenticated C2 workers. This is the actual original actor/terrain/render
; bridge, not a Mario velocity replacement. Unfinished original health,
; GravityFire and native enemy/block-effect callbacks remain explicit gates.
.global CurrentPlayer,NumberofLives,Player_Pos_ForScroll,Player_X_Scroll
.global Player_X_Speed,Player_XSpeedAbsolute,Player_Y_Speed,Player_State
.global PlayerSize,CrouchingFlag,PlayerFacingDir,Player_BoundBoxCtrl
.export Ms12CacheRows,Ms12WorkersEnd,Ms12Movement,Ms12Camera,Ms12Fresh
.export Ms12SourceEffect,Ms12Unsupported
Ms12Player=$c83d
Ms12Lives=$c83e
Ms12Effect=$c83f

Ms12CacheRows:
.repeat 37,I
 .if I=0
  jmp Ms12Movement
 .elseif I=1
  jmp MsRenderGraphics
 .elseif I=2
  jmp MsRenderDraw
 .elseif I=34
  jmp Ms35Weapons
 .elseif I=5
  jmp Ms24Injury
 .elseif I=6
  jmp Ms22InjuryStatus
 .elseif I=7
  jmp Ms34DeathStart
 .elseif I=8
  jmp Ms34DeathTick
 .elseif I=11
  jmp Ms12BodyPolicy
 .elseif I=12
  jmp Ms12Adder
 .elseif I=15
  jmp Ms12Fresh
 .elseif I=24
  jmp Ms25Pickup
 .elseif I=26
  jmp MsRenderColors
 .else
  jmp Ms12Reject
 .endif
.endrepeat
Ms12Reject:clc
 rts

; Constructor runs from genuine native spawn coordinates, on first accepted
; movement after new-life/owner transition. Full cold-ROM header ownership is
; a prerequisite, not inferred from this ready marker or selected identity.
Ms12Movement:
 jsr MsRenderGraphics
 jsr MsRSave
 lda OperMode
 cmp #1
 jne Ms12MoveRejected
 lda GameEngineSubroutine
 cmp #8
 jne Ms12MoveRejected
 lda MsState+$6f8
 jmi Ms12MoveRejected          ; original scripted scene not yet host-mapped
 lda $c800
 cmp #$a7
 bne Ms12NeedConstructor
 lda CurrentPlayer
 cmp Ms12Player
 bne Ms12NeedConstructor
 lda NumberofLives
 cmp Ms12Lives
 beq Ms12BeforeStep
Ms12NeedConstructor:
 lda #$ff
 ldx #$7f                    ; no artificial one-screen source world bound
 MsRFar MsHostSetBounds,3
 MsRFar MsNativeConstruct,3
 jcc Ms12MoveRejected
 lda CurrentPlayer
 sta Ms12Player
 lda NumberofLives
 sta Ms12Lives
Ms12BeforeStep:
 jsr Ms24HurtTick
 jcs Ms24Frozen
 ; Account for native camera-edge/platform X correction once, at the source
 ; boundary. Original fractions/velocities/gravity/jump latches stay source.
 lda Player_X_Position
 sec
 sbc ScreenLeft_X_Pos
 sta Player_Pos_ForScroll
 lda Player_X_Position
 sec
 sbc #8
 sta MsState+$480
 lda Player_PageLoc
 sbc #0
 sta MsState+$498
 MsRFar MsHostStep,3
 bcc Ms12MoveRejected
 MsRFar MsNativeApplyDelta,3
 lda MsHostDeltaX
 sta Player_X_Scroll
 asl
 asl
 asl
 asl
 sta Player_X_Speed
 bpl :+
 eor #$ff
 clc
 adc #1
:sta Player_XSpeedAbsolute
 lda MsHostDeltaY
 sta Player_Y_Speed
 lda #1
 bit MsState+$540
 bvc :+
 lda #2
:sta PlayerFacingDir
 lda #0
 sta PlayerSize
 sta CrouchingFlag
 lda MsState+$570
 beq :+
 lda #2
:sta Player_State
 jsr MsRRestore
 sec
 rts
Ms12MoveRejected:
 jsr MsRRestore
 clc
 rts

; Donor8874 dispatches the donor scene/CHR mapper. Host owns those domains;
; the adapted boundary supplies the actual pre-scroll host camera only.
; The unchanged following donor B08F still performs its real scratch update.
Ms12Camera:
 lda ScreenLeft_X_Pos
 sta MsState+$710
 lda ScreenLeft_PageLoc
 sta MsState+$711
 lda #0
 sta MsState+$712
 sta MsState+$713
 rts

Ms12Fresh:
 lda #0
 sta $c800
 sec
 rts
Ms12BodyPolicy:
 lda #0
 sta PlayerSize
 sta CrouchingFlag
 sta Player_BoundBoxCtrl
 clc                           ; native easy/hard body policy follows
 rts
Ms12Adder:
 ; Worker entry stack offset18 is original nativeY in the ROM frontgate:
 ; commonJSR/Core/A3bridge/C2JSR frames are real, not elided test callbacks.
 ; Update only that authorized output slot; nativeNMI scratch is untouched.
 tsx
 lda #3                        ; actual native32px Mega collision-probe group
 sta $0112,x
 sec
 rts

; Explicit unfinished source callback boundaries, with no donor PPU/script
; dispatch and no port5000 execution. They record an event, not a claim of
; implemented brick effects, injury, audio or scene transitions.
Ms12SourceEffect:
 php
 pha
 lda #1
 sta Ms12Effect
 pla
 plp
 rts
Ms12Unsupported:
 php
 pha
 lda #$80
 sta Ms12Effect
 pla
 plp
 rts
Ms12WorkersEnd:


; Bound include C:\Users\kando\Documents\ChatGPT\SMB Crossover\build\metal-storm-owning-graft-1101-v11\loader.inc
; Split ROM-only cold loader. Every segment has an audited physical FF-hole
; proposal, not a resource grant. Source caches execute no opcode while loading.
.global CurrentBankC,ReloadCHRBank,SelectedCharacter,OperMode,FamilyMainCommit
.global DisableScreenFlag,Mirror_PPUMASK,Mirror_PPUCTRL,NmiDisable,GameEngineSubroutine
.global HorizontalScroll,VerticalScroll,X5PublishChr,FarCallCommon
.global SafecallA_SMC,FarcallJmpTarget_SMC,NextBank_SMC,SafereturnA_SMC
.global MsRenderGraphics,MsRenderDraw,MsRenderColors
.globalzp R0,R1,R2,R3,R4,R5,R6,R7
.export Ms8Load,Ms8Auth,Ms8EntryEnd,Ms8WorkEnd,Ms8CheckEnd,Ms8AuthEnd
.export Ms8ZeroEnd,Ms8CopyEnd,Ms8MapEnd,Ms8FinishEnd

.macro Ms8Far Target,Bank
 sta SafecallA_SMC+1
 lda #<Target
 sta FarcallJmpTarget_SMC+1
 lda #>Target
 sta FarcallJmpTarget_SMC+2
 lda #($80|Bank)
 jsr FarCallCommon
.endmacro

; Actual warm typed-native transport. A-ROM veneers stay mapped while the
; C-ROM common authenticates both complete owner headers. No C2 opcode is
; fetched until authentication. The common's temporary A3 child always returns
; with the C-ROM common bank restored. R0..R7 are never touched by transport.
.global CurrentBankC,SelectedCharacter,FarCallCommon
.global SafecallA_SMC,FarcallJmpTarget_SMC,NextBank_SMC,SafereturnA_SMC
.global Ms8Auth,MsHostServiceRows,Ms12CacheRows
.global Ms12RetireHeaders
.export Ms12Veneers,Ms12Enter,Ms12Return,Ms12GateEnd
.export Ms12Common,Ms12CommonEnd,Ms12ActorBridge,Ms12ActorBridgeEnd

.macro Ms12Far Target,Bank
 sta SafecallA_SMC+1
 lda #<Target
 sta FarcallJmpTarget_SMC+1
 lda #>Target
 sta FarcallJmpTarget_SMC+2
 lda #($80|Bank)
 jsr FarCallCommon
.endmacro

.segment "MS11_GATE"
Ms12Veneers:
.repeat 37,I
 .if I=10
 jmp BlockBufferColli_Head
 .elseif I=14
 jmp BlockBufferColli_Side
 .else
 jmp Ms12Enter
 .endif
.endrepeat
Ms12Enter:
 php
 pha
 txa
 pha
 tya
 pha
 lda CurrentBankC
 pha
 lda #($80|95)
 sta CurrentBankC
 sta $5116
 jmp Ms12Common
Ms12Return:
 pla
 sta CurrentBankC
 sta $5116
 pla
 tay
 pla
 tax
 pla
 plp
 rts
Ms12GateEnd:
.assert Ms12GateEnd-Ms12Veneers<=147,lderror,"Granted Metal A-ROM gate"

.segment "MS12_COMMON"
Ms12Common:
 ldx #251
Ms12SaveSmc:
 ldy Ms12Smc-251,x
 lda $0100,y
 pha
 inx
 bne Ms12SaveSmc
 lda SelectedCharacter
 cmp #35
 bne Ms12Rejected
 Ms12Far Ms8Auth,25
 bcc Ms12Rejected
 ; Five SMC bytes, oldC, Y/X/A/P are on this exact ROM frame. The transport
 ; target names the original111-byte veneer range; subtracting its base gives
 ; the real3*row A3 entry offset, no alias to legacy native owner tables.
 tsx
 lda $0103,x
 sbc #<Ms12Veneers
 cmp #57                     ; typed reset row19, before any C2 opcode
 beq Ms12Retire
 sta FarcallJmpTarget_SMC+1
 lda #>MsHostServiceRows
 sta FarcallJmpTarget_SMC+2
 lda $0109,x
 sta SafecallA_SMC+1
 ldy $0107,x
 lda $0108,x
 tax
 lda #3
 jsr FarCallCommon
 jmp Ms12Result
Ms12Retire:
 ; Authenticated reset is ROM-only. Source cache opcodes cannot execute
 ; after either header is revoked. Helper restores this C-ROM before return.
 lda #<Ms12RetireHeaders
 sta FarcallJmpTarget_SMC+1
 lda #>Ms12RetireHeaders
 sta FarcallJmpTarget_SMC+2
 lda #($80|94)
 jsr FarCallCommon
 bne Ms12Result              ; helper returnsA1/C1 from exact finalCPX1
Ms12Rejected:
 clc
Ms12Result:
 tsx
 lda $010a,x
 and #$fe
 adc #0                     ; preserve original flags except handled carry
 sta $010a,x
 ldx #4
Ms12RestoreSmc:
 ldy Ms12Smc,x
 pla
 sta $0100,y
 dex
 bpl Ms12RestoreSmc
 jmp Ms12Return
Ms12Smc:.byte <(NextBank_SMC+1),<(SafecallA_SMC+1),<(FarcallJmpTarget_SMC+1),<(FarcallJmpTarget_SMC+2),<(SafereturnA_SMC+1)
Ms12CommonEnd:

.segment "MS12_BRIDGE"
Ms12ActorBridge:
 lda CurrentBankC
 pha
 lda #2
 sta CurrentBankC
 sta $5116
 lda FarcallJmpTarget_SMC+1
 clc
 adc #<Ms12CacheRows
 sta FarcallJmpTarget_SMC+1
 lda #>Ms12CacheRows
 sta FarcallJmpTarget_SMC+2
 lda #3
 jsr FarCallCommon
 ; C-ROM child caller needs only the handler's resultC; its native caller's
 ; original AXYP frame is preserved outside the full-header boundary.
 php
 pla
 tay
 pla
 sta CurrentBankC
 sta $5116
 tya
 pha
 plp
 rts
Ms12ActorBridgeEnd:
.assert Ms12ActorBridgeEnd-Ms12ActorBridge<=77,lderror,"Actor preheader gap"

.segment "MS12_COLD"
; AXYP except carry retained, all foreground R0..R7 and5public SMC retained.
Ms8Load:
 php
 pha
 txa
 pha
 tya
 pha
 ldx #0
Ms8SaveZp:
 lda R0,x
 pha
 inx
 cpx #8
 bne Ms8SaveZp
 ldx #0
Ms8SaveSmc:
 ldy Ms8SmcOffsets,x
 lda $0100,y
 pha
 inx
 cpx #5
 bne Ms8SaveSmc
 lda CurrentBankC
 pha
 lda ReloadCHRBank
 pha
 Ms8Far Ms8Work,37
 tsx
 bcc Ms8ResultNo
 lda $0113,x
 ora #1
 bne Ms8Result
Ms8ResultNo:
 lda $0113,x
 and #$fe
Ms8Result:
 sta $0113,x
 pla
 sta ReloadCHRBank
 pla
 sta CurrentBankC
 sta $5116
 ldx #4
Ms8RestoreSmc:
 ldy Ms8SmcOffsets,x
 pla
 sta $0100,y
 dex
 bpl Ms8RestoreSmc
 ldx #7
Ms8RestoreZp:
 pla
 sta R0,x
 dex
 bpl Ms8RestoreZp
 pla
 tay
 pla
 tax
 pla
 plp
 rts
Ms8SmcOffsets:.byte <(NextBank_SMC+1),<(SafecallA_SMC+1),<(FarcallJmpTarget_SMC+1),<(FarcallJmpTarget_SMC+2),<(SafereturnA_SMC+1)
Ms8EntryEnd:

.segment "MS11_WORK"
Ms8Work:
 Ms8Far Ms8Check,21
 bcc Ms8WorkNo
 cmp #1
 beq Ms8WorkYes
 Ms8Far Ms8Zero,94
 bcc Ms8WorkNo
 Ms8Far Ms8Copy,36
 lda #0
 rol a                       ; failure0/success1 passed through real farcall
 Ms8Far Ms8Finish,99
 bcc Ms8WorkNo
Ms8WorkYes:
 Ms8Far Ms13Fresh,36
 rts
Ms8WorkNo:clc
 rts
Ms8WorkEnd:

.segment "MS11_CHECK"
Ms8Check:
 lda SelectedCharacter
 cmp #35
 bne Ms8CheckNo
 lda OperMode
 cmp #1
 bne Ms8CheckNo
 lda FamilyMainCommit
 and #1
 beq Ms8CheckNo
 lda DisableScreenFlag
 beq Ms8CheckNo
 lda Mirror_PPUMASK
 and #$18
 bne Ms8CheckNo
 lda NmiDisable
 bpl Ms8CheckNo
 Ms8Far Ms8Auth,25
 lda #0
 bcc Ms8ColdAllowed
 lda #1
Ms8ColdAllowed:sec
 rts
Ms8CheckNo:clc
 rts
Ms8CheckEnd:

.segment "MS11_AUTH"
; Complete shared revision fingerprint for both banks, no foreign-state read.
Ms8WarmAuth:
 lda SelectedCharacter
 cmp #35
 bne Ms8WarmNo
 lda OperMode
 cmp #1
 bne Ms8WarmNo
 lda GameEngineSubroutine
 cmp #8
 bne Ms8WarmNo
 lda CurrentBankC
 cmp #2
 beq Ms8Auth
Ms8WarmNo:clc
 rts
Ms8Auth:
 lda CurrentBankC
 pha
 ldx #3
Ms8AuthBank:
 stx CurrentBankC
 stx $5116
 ldy #15
Ms8AuthByte:
 lda $dfe0,y
 cmp Ms8AuthCookie,y
 bne Ms8AuthNo
 dey
 bpl Ms8AuthByte
 ldx CurrentBankC
 dex
 cpx #1
 bne Ms8AuthBank
 pla
 sta CurrentBankC
 sta $5116
 sec
 rts
Ms8AuthNo:
 pla
 sta CurrentBankC
 sta $5116
 clc
 rts
Ms8AuthCookie:.incbin "native-cookie.bin"
Ms8AuthEnd:

.segment "MS12_ZERO"
Ms8Zero:
 sei
 lda #0
 sta ReloadCHRBank
 Ms8Far X5PublishChr,62
 ; Revoke both owners before zeroing state or writing code.
 jsr Ms12InvalidateBoth
 lda #0
 sta R0
 lda #$c0
 sta R1
 ldy #0
 ldx #32
Ms8ZeroPage:
 lda #0
Ms8ZeroByte:
 sta (R0),y
 cmp (R0),y
 bne Ms8ZeroNo
 iny
 bne Ms8ZeroByte
 inc R1
 dex
 bne Ms8ZeroPage
 lda Mirror_PPUCTRL
 and #$fb
 ora #$20
 sta $2000
 sec
 rts
Ms8ZeroNo:clc
 rts
Ms8ZeroEnd:


Ms12RetireHeaders:
 lda CurrentBankC
 pha
 jsr Ms12InvalidateBoth
 pla
 sta CurrentBankC
 sta $5116
 txa                         ; exact finalX1 also givesA1, CPX leftC1
 rts
Ms12InvalidateBoth:
 ldx #3
Ms12InvalidateLoop:
 stx CurrentBankC
 stx $5116
 lda #0
 sta $dfe0
 dex
 cpx #1
 bne Ms12InvalidateLoop
 rts
Ms12ZeroEnd:
.assert Ms12ZeroEnd-Ms8Zero<=104,lderror,"New94 coldzero partition"

.segment "MS11_COPY"
Ms8Copy:
 lda #0
 sta R2
Ms8CopyRow:
 Ms8Far Ms8Map,34
 ldx #4
Ms8CopyPage:
 lda $2007
 sta (R0),y
 iny
 bne Ms8CopyPage
 inc R1
 dex
 bne Ms8CopyPage
 Ms8Far Ms8Map,34             ; restarts both RAM and buffered CHR row
 ldx #4
Ms8VerifyPage:
 lda $2007
 cmp (R0),y
 bne Ms8CopyNo
 iny
 bne Ms8VerifyPage
 inc R1
 dex
 bne Ms8VerifyPage
 inc R2
 lda R2
 cmp #12
 bne Ms8CopyRow
 sec
 rts
Ms8CopyNo:clc
 rts
Ms8CopyEnd:

.segment "MS11_MAP"
Ms8Map:
 ldx R2
 lda Ms8DestHi,x
 sta R1
 lda #0
 sta R0
 lda #3
 cpx #8
 bcc :+
 lda #2
:sta CurrentBankC
 sta $5116
 lda Ms8CarrierHi,x
 sta $5130
 lda Ms8CarrierLo,x
 sta $512b
 bit $2002
 lda #$0c
 sta $2006
 lda #0
 sta $2006
 lda $2007                   ; exact PPU read-buffer dummy
 ldy #0
 rts
Ms8DestHi:.byte $c0,$c4,$c8,$cc,$d0,$d4,$d8,$dc,$cd,$d1,$d5,$d9
Ms8CarrierLo:.lobytes 247,248,249,250,827,828,829,830,831,500,494,499
Ms8CarrierHi:.hibytes 247,248,249,250,827,828,829,830,831,500,494,499
Ms8MapEnd:

.segment "MS11_FINISH"
; InputA1: verified all11 rows. A0: revoke both after any copy failure.
Ms8Finish:
 sta R3
 beq Ms8Failed
 ldx #3
Ms8PublishBank:
 stx CurrentBankC
 stx $5116
 lda #0
 sta $dfe0
 ldy #15
Ms8PublishByte:
 lda Ms8PublishCookie,y
 sta $dfe0,y
 dey
 bne Ms8PublishByte
 ldx CurrentBankC
 dex
 cpx #1
 bne Ms8PublishBank
 ldx #3
Ms8Release:
 stx CurrentBankC
 stx $5116
 lda #$a7
 sta $dfe0
 dex
 cpx #1
 bne Ms8Release
 jmp Ms8RestorePpu
Ms8Failed:
 ldx #3
Ms8Revoke:
 stx CurrentBankC
 stx $5116
 lda #0
 sta $dfe0
 dex
 cpx #1
 bne Ms8Revoke
Ms8RestorePpu:
 Ms8Far X5PublishChr,62
 lda Mirror_PPUCTRL
 sta $2000
 bit $2002
 lda HorizontalScroll
 sta $2005
 lda VerticalScroll
 sta $2005
 lda R3
 cmp #1
 rts
Ms8PublishCookie:.incbin "native-cookie.bin"
Ms8FinishEnd:

.export SelectedCharacter=$6002
.export SavedJoypadBits=$00dc
.export FrameCounter=$000e
.export GamePauseStatus=$0777
.export OperMode=$0771
.export GameEngineSubroutine=$000f
.export CrossoverMenuIndex=$7309
.export FmAlts=$5fe5
.export Block_Buffer_1=$0300
.export BlockBufferAddr=$95d8
.export MTileAttribute=$ef36
.export Player_X_Position=$0075
.export Player_PageLoc=$005c
.export Player_Y_Position=$00bd
.export Player_Y_HighPos=$00a4
MsExternal_8874=Ms12Camera
MsExternal_9ED7=Ms12Unsupported
MsExternal_FF18=Ms12SourceEffect
MsExternal_FF39=MsObjectLifecycle
MsObjectUnsupported=Ms12Unsupported
.export MetaspriteRenderLoop=$a5ba
.export X5SetPhysicalChr=$a275
.export FarCallCommon=$015a
.export SafecallA_SMC=$0169
.export FarcallJmpTarget_SMC=$016b
.export CurrentBank=$0145
.export CurrentBankC=$7da1
.export ScreenLeft_X_Pos=$071f
.export ScreenLeft_PageLoc=$071d
.export Player_SprAttrib=$0587
.export CurrentOAMOffset=$06de
.export SsChrActive=$7e05
.export VRAM_Buffer1=$04af
.export VRAM_Buffer1_Offset=$04ae
.export ObjectMetasprite=$06e1
.export SmPosePtr=$6b06
.exportzp R0=$03
.exportzp R1=$04
.exportzp R2=$05
.exportzp R3=$06
.exportzp R4=$07
.exportzp R5=$08
.exportzp R6=$09
.exportzp R7=$0a
.export MsBodyPhysical0=495
.export MsBodyPhysical1=496
.export MsBodyPhysical2=497
.export MsBodyPhysical3=498
.export MsBodyPhysical4=499
.export MsShotPhysical=499
.export MS_NATIVE_DRAW_BANK=$84
.export MS_NATIVE_CHR_BANK=$be
MsLifeUnsupported=Ms12Unsupported
.export FamilyMainCommit=$5fff
.export DisableScreenFlag=$0775
.export Mirror_PPUMASK=$077a
.export Mirror_PPUCTRL=$0779
.export NmiDisable=$0139
.export HorizontalScroll=$0742
.export VerticalScroll=$0743
.export NextBank_SMC=$0161
.export SafereturnA_SMC=$0178
.export X5PublishChr=$a03d
.export ReloadCHRBank=$0146
.export Ms9Color1=38
.export Ms9Color2=32
.export Ms9Color3=15


.export Ms12Host_CurrentPlayer=$0758
.export Ms12Host_NumberofLives=$075f
.export Ms12Host_Player_Pos_ForScroll=$075a
.export Ms12Host_Player_X_Scroll=$0701
.export Ms12Host_Player_X_Speed=$0046
.export Ms12Host_Player_XSpeedAbsolute=$0702
.export Ms12Host_Player_Y_Speed=$008e
.export Ms12Host_Player_State=$001e
.export Ms12Host_PlayerSize=$0759
.export Ms12Host_CrouchingFlag=$0717
.export Ms12Host_PlayerFacingDir=$053e
.export Ms12Host_Player_BoundBoxCtrl=$0645

KrSceneInit=$b921
; Foreground scene ingress in the unused tail of Metal's granted bank21.
; Preserve the complete existing scene chain, including Mario the Tank.
.export Ms13Scene
.segment "MS11_CHECK"
Ms13Scene:
 Ms8Far KrSceneInit,29
 php
 pha
 lda SelectedCharacter
 cmp #35
 bne Ms13SceneDone
 Ms8Far Ms8Load,116
Ms13SceneDone:
 pla
 plp
 rts
Ms13SceneEnd:
.assert Ms13SceneEnd-Ms8Check<=118,lderror,"Metal bank21 scene/check lease"

; ROM-only state reset after a successful cold or authenticated warm load.
; No source RAM opcode executes here. The constructor runs on next movement.
.export Ms13Fresh
.segment "MS11_COPY"
Ms13Fresh:
 lda CurrentBankC
 pha
 lda #2
 sta CurrentBankC
 sta $5116
 lda #0
 sta $c800
 pla
 sta CurrentBankC
 sta $5116
 sec
 rts
Ms13FreshEnd:
.assert Ms13FreshEnd-Ms8Copy<=122,lderror,"Metal bank36 copy/reset lease"

.segment "MS11_RENDER"
; Typed HuInjuryStatus result across the existing authenticated transport.
; Worker SP+18 is native Y (see Ms12Adder); +20 is A and +21 is P.
; Source armor is05D0, hurt immunity0648, barrier0660, GravityFire0630.
; Special-state contacts must reach the injury handler instead of the native
; unconditional unarmored death path. The handler itself is integrated next.

.export Ms22InjuryStatus
Ms22InjuryStatus:
 lda MsState+$5d0
 bne Ms22StatusOne
 lda MsState+$648
 ora MsState+$660
 ora MsState+$630
 and #$80
 beq Ms22StatusZero
Ms22StatusOne:
 lda #1
Ms22StatusZero:
 tsx
 sta $0114,x
 tay
 lda $0115,x
 and #$7d
 cpy #0
 bne Ms22StatusFlags
 ora #2
Ms22StatusFlags:
 sta $0115,x
 sec
 rts

.segment "MS11_RENDER"
; Original Metal Storm injury leaves. Caller owns scene timing and host effects.
; No cartridge allocation or service admission is implied by this component.
; Ms21HurtBlink is donor9548..9566: incoming A is the original scene clock.
; Native-enemy flashing at9567 is a separate host contact boundary.
; Ms21ArmorReturn is donor95BB..95D5: enemy release/palette follows separately.

.export Ms21HurtBlink,Ms21ArmorReturn
Ms21HurtBlink:
 and #$02
 bne Ms21HurtVisible
 lda MsState+$33
 cmp #$10
 bcc Ms21HurtVisible
 lda MsState+$540
 and #$f0
 ora #$01
 sta MsState+$540
 jmp Ms21HurtDone
Ms21HurtVisible:
 lda MsState+$540
 and #$f0
 sta MsState+$540
Ms21HurtDone:
 rts
Ms21ArmorReturn:
 lda #$00
 sta MsState+$5d0
 sta MsState+$528
 lda #$b4
 sta MsState+$74b
 lda MsState+$750
 sta MsState+$34
 lda MsState+$751
 sta MsState+$35
 lda #$80
 sta MsState+$70
 rts

.segment "MS11_RENDER"
; Exact original bank4 $8471..$848E. Called once per active source update,
; including the armor-return frame, AFTER Ms21ArmorReturn sets074B=B4.
; No pause/epoch ownership here; host movement owns that qualification.

.export Ms23ArmorTimer
Ms23ArmorTimer:
 lda MsState+$648
 bpl Ms23ArmorTimerDone
 dec MsState+$74b
 bne Ms23ArmorTimerToggle
 lda #$00
 sta MsState+$648
 lda #$80
 sta MsState+$70
 sta MsState+$74e
 rts
Ms23ArmorTimerToggle:
 lda MsState+$70
 eor #$80
 sta MsState+$70
Ms23ArmorTimerDone:
 rts

.segment "MS11_RENDER"
; A3 is still mapped by Ms12ActorBridge while this C2 worker runs.
; Original BA1A owns terrain-style injury admission and armor scene state.
; Enemy-specific destruction/flashing and source audio playback remain separate.
Ms24Injury:
 lda MsState+$648
 bmi Ms24Handled
 lda MsState+$630
 bmi Ms24Handled
 jsr Ms_BA1A
 lda MsState+$34
 cmp #2
 bne Ms24Handled
 lda #8
 sta MsState+$7e7
Ms24Handled:sec
 rts

; C1 freezes the actor this callback. C0 permits the original movement step.
; Shared source epoch prevents duplicate callbacks and preserves pause clocks.
Ms24HurtTick:
 lda GamePauseStatus
 and #1
 bne Ms24Phase
 lda MsHostHaveEpoch
 beq Ms24New
 lda FrameCounter
 cmp MsHostEpoch
 beq Ms24Phase
Ms24New:
 lda MsState+$34
 cmp #2
 bne Ms24Timer
 lda MsState+$5d0
 bpl Ms24Phase
 lda MsState+$33
 cmp #32
 bcs Ms24Return
 jsr Ms21HurtBlink
 inc MsState+$33
 jmp Ms24Mark
Ms24Return:
 jsr Ms21ArmorReturn
 jsr Ms23ArmorTimer
Ms24Mark:
 lda FrameCounter
 sta MsHostEpoch
 lda #1
 sta MsHostHaveEpoch
 sec
 rts
Ms24Timer:
 jsr Ms23ArmorTimer
 clc
 rts
Ms24Phase:
 lda MsState+$34
 cmp #2
 beq Ms24Handled
 clc
 rts
Ms24Frozen:
 lda #0
 sta Player_X_Scroll
 sta Player_X_Speed
 sta Player_XSpeedAbsolute
 sta Player_Y_Speed
 jmp MsRRestore

.segment "MS25_EXTRA"
; Mushroom is the SMB adaptation of original Metal Storm armor item E8BE.
; Star/1UP retain the native Mario collectible behavior. Weapon items follow.
Ms25Pickup:
 cpx #6
 bcs Ms25No
 lda $c800
 cmp #$a7
 bne Ms25No
 lda Enemy_Flag,x
 beq Ms25No
 lda Enemy_ID,x
 cmp #$2e
 bne Ms25No
 lda Enemy_State,x
 bpl Ms25No
 lda PowerUpType,x
 cmp #2
 bcs Ms25Native
 cmp #0
 bne Ms25No
 ; Original E8BE..E8CD state writes, with host collection effects below.
 lda #$80
 sta MsState+$5d0
 lda #$30
 sta MsState+$528
 lda #$0a
 sta MsState+$7e7
 lda #1
 sta PlayerStatus
 lda #0
 sta PlayerSize
 lda #Sfx_PowerUpGrab
 sta Square2SoundQueue
 jsr EraseEnemyObject
 lda #0
 sta InvPickupOwner,x
 sta InvPickup,x
 sta InvRisePhase,x
 sta InvPickupSaveLo,x
 sta InvPickupSaveHi,x
 lda #6
 jsr SetupFloateyNumber
 sec
 rts
Ms25No:clc
 rts
Ms25Native:
 MsRFar MarioSourcePowerupCollision,MS25_NATIVE_PICKUP_BANK
 sec
 rts

.segment "MS11_RENDER"
; Original bank 0:$966A..$9735 and data $9736..$9744.
; Entry excludes the original moving-platform coordinate adjustment at $9634.
; Graphics upload requests remain donor state, requiring host renderer mapping.
Ms27DeathInit:
 ldx #$17
@clear:
 lda #0
 sta MsState+$510,x
 lda #$80
 sta MsState+$498,x
 dex
 bne @clear
 lda #0
 sta MsState+$648
 sta MsState+$74b
 lda #$80
 sta MsState+$70
 lda #2
 sta MsState+$528
 lda MsState+$480
 sec
 sbc #$10
 sta MsState+$480
 bcs @y
 dec MsState+$498
@y:
 lda MsState+$4b0
 sec
 sbc #$10
 sta MsState+$4b0
 ldy MsState+$50
 bne @wrap
 bcs @pose
 dec MsState+$4c8
 jmp @pose
@wrap:
 bcs @normalize
 adc #$f0
@normalize:
 cmp #$f0
 bcc @store
 sbc #$f0
@store:
 sta MsState+$4b0
 lda #0
 sta MsState+$4c8
@pose:
 lda #0
 sta MsState+$4e0
 sta MsState+$4f8
 lda #3
 sta MsState+$53
 lda #$a3
 sta MsState+$759
 lda Ms27DeathChrLo
 sta MsState+$75a
 lda Ms27DeathChrHi
 sta MsState+$75b
 lda #1
 sta MsState+$540
 lda #$80
 sta MsState+$755
 sta MsState+$715
 inc MsState+$35
 rts

Ms27DeathAnimate:
 dec MsState+$53
 beq @advance
 rts
@advance:
 lda #3
 sta MsState+$53
 inc MsState+$4f8
 ldx MsState+$4e0
 lda MsState+$4f8
 cmp Ms27DeathCounts,x
 beq @next
 rts
@next:
 lda #0
 sta MsState+$4f8
 inc MsState+$4e0
 ldx MsState+$4e0
 cpx #5
 beq @done
 lda Ms27DeathChrLo,x
 sta MsState+$75a
 lda Ms27DeathChrHi,x
 sta MsState+$75b
 lda #$80
 sta MsState+$755
 rts
@done:
 inc MsState+$35
 lda #4
 sta MsState+$4e0
 lda #0
 sta MsState+$4f8
 lda #$3c
 sta MsState+$53
 rts
Ms27DeathCounts:
 .byte 5,3,4,3,1
Ms27DeathChrLo:
 .byte $a1,$a5,$a9,$ad,$b1
Ms27DeathChrHi:
 .byte $a3,$a7,$ab,$af,$b1

; Source death timing with native life-loss handoff. Explosion graphics pending.
Ms34DeathStart:
 lda #0
 sta MsState+$33
 sta MsState+$35
 sta MsState+$5d0
 lda #2
 sta MsState+$34
 lda #8
 sta MsState+$7e7
 lda FrameCounter
 sta MsHostEpoch
 lda #1
 sta MsHostHaveEpoch
 sec
 rts

Ms34DeathTick:
 lda GamePauseStatus
 and #1
 bne Ms34Done
 lda FrameCounter
 cmp MsHostEpoch
 beq Ms34Done
 sta MsHostEpoch
 lda MsState+$35
 beq Ms34Freeze
 cmp #1
 beq Ms34BeginExplosion
 cmp #2
 beq Ms34Explosion
 cmp #3
 bne Ms34Done
 dec MsState+$53
 bne Ms34Done
 inc MsState+$35
 ; Native engine6 owns losing one life, game-over and level restart.
 lda #6
 sta GameEngineSubroutine
Ms34Done:
 sec
 rts
Ms34Freeze:
 lda MsState+$33
 cmp #32
 bcs Ms34Next
 jsr Ms21HurtBlink
 inc MsState+$33
 sec
 rts
Ms34Next:
 inc MsState+$35
 sec
 rts
Ms34BeginExplosion:
 jsr Ms27DeathInit
 sec
 rts
Ms34Explosion:
 jsr Ms27DeathAnimate
 sec
 rts

; Source shot rectangles E8CE/E92E/E98E/E9EE; native enemy transaction.
; Render scratch is ephemeral here and never persists across an update.
Ms35Enemy=MsPacket
Ms35Object=MsPacket+1
Ms35Left=MsPacket+2
Ms35Right=MsPacket+3
Ms35Top=MsPacket+4
Ms35Bottom=MsPacket+5
Ms35EnemyX=MsPacket+6
.segment "MS11_RENDER"
Ms35Weapons:
 lda MsState+$512
 ora MsState+$513
 bmi Ms41Active
 sec
 rts
Ms41Active:
 jsr MsRSave
 lda GamePauseStatus
 and #1
 jne Ms35Return
 lda GameEngineSubroutine
 cmp #8
 jne Ms35Return
 lda ObjectOffset
 sta Ms35Object
 lda #2
 sta MsSlot
Ms35Shot:
 ldx MsSlot
 lda MsState+$510,x
 jpl Ms35NextShot
 lda MsState+$528,x
 cmp #$80
 beq Ms35Normal
 cmp #$81
 jne Ms35NextShot
 lda #0
 sta Ms35Left
 sta Ms35Top
 lda #15
 sta Ms35Bottom
 sta Ms35Right
 cpx #2
 beq Ms35Bounds
 lda #7
 sta Ms35Right
 bne Ms35Bounds
Ms35Normal:
 lda #2
 sta Ms35Left
 lda #5
 sta Ms35Right
 lda #6
 sta Ms35Top
 lda #9
 sta Ms35Bottom
Ms35Bounds:
 jsr MsRPosition
 lda R7
 cmp #1
 jne Ms35NextShot
 lda R5
 jne Ms35NextShot
 lda #5
 sta Ms35Enemy
 jsr Ms35Enemies
Ms35NextShot:
 inc MsSlot
 lda MsSlot
 cmp #4
 bcc Ms35Shot
 lda Ms35Object
 sta ObjectOffset
Ms35Return:
 jmp MsRRestore

.segment "MS25_EXTRA"
Ms35Enemies:
 ldx Ms35Enemy
 lda Enemy_Flag,x
 beq Ms35NextEnemy
 bmi Ms35NextEnemy
 lda Enemy_State,x
 and #$20
 bne Ms35NextEnemy
 lda Enemy_ID,x
 cmp #$15
 bcs Ms35NextEnemy          ; platforms/firebars/items are not victims
 cmp #6
 bne :+
 lda Enemy_State,x
 cmp #2
 bcs Ms35NextEnemy
:
 lda Enemy_Y_HighPos,x
 cmp #1
 bne Ms35NextEnemy
 lda Enemy_X_Position,x
 sec
 sbc ScreenLeft_X_Pos
 sta Ms35EnemyX
 lda Enemy_PageLoc,x
 sbc ScreenLeft_PageLoc
 bne Ms35NextEnemy
 ; Inclusive interval overlap, without wrapping a screen-edge rectangle.
 lda R4
 clc
 adc Ms35Right
 bcs :+
 cmp Ms35EnemyX
 bcc Ms35NextEnemy
:
 lda Ms35EnemyX
 clc
 adc #15
 bcs :+
 sec
 sbc R4
 bcc Ms35NextEnemy
 cmp Ms35Left
 bcc Ms35NextEnemy
:
 lda R6
 clc
 adc Ms35Bottom
 bcs :+
 cmp Enemy_Y_Position,x
 bcc Ms35NextEnemy
:
 lda Enemy_Y_Position,x
 clc
 adc #23
 bcs :+
 sec
 sbc R6
 bcc Ms35NextEnemy
 cmp Ms35Top
 bcc Ms35NextEnemy
:
 stx ObjectOffset
 stx R1
 jsr HandleEnemyFBallCol
 ; Original E53C..E543 shot retirement on accepted contact.
 ldx MsSlot
 lda #0
 sta MsState+$510,x
 lda #$80
 sta MsState+$498,x
 rts
Ms35NextEnemy:
 dec Ms35Enemy
 jpl Ms35Enemies
 rts
