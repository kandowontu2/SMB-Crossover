"""Root-owned exact9cf delivery and sidecar-free actual Downloads replay."""
import argparse,json,re,sys
from pathlib import Path
from prepare_selected_native_packet_v1 import R,prepare,sha
from nightly_patch_guard_v1 import check

O=R/'build/bub-menu-candidate-1102-v2'
D=Path('C:/Users/kando/Downloads/SMB-Crossover-Latest-WIP-MMC5.nes')
PIN='9cf99b438e6f5bc614dc4ccc433707a3796702b7f33a04318a428a1155397f15'
PARENT='16a9de64b18370a03885ff503141fc08edd25f3bd026d480854a1754efa1490b'
read=lambda p:json.loads(Path(p).read_text())


def main():
    ap=argparse.ArgumentParser();ap.add_argument('--install',action='store_true',help='Root only, after both exact candidate full1-1 runs pass. No emulator is launched.');args=ap.parse_args()
    rom=O/'combined-current-landing.nes';assert sha(rom)==PIN
    manifest=O/'combined-current-landing.json';m=read(manifest)
    assert m['expected_rebased_ROM_sha256']==PIN and m['delivered_parent_sha256']==PARENT and m['actual_changed_bytes_over_delivered_parent']==370
    assert m['exact_Sunny_five_patches_preserved']and m['patch_intervals_disjoint']and not m['installed']
    for rel,h in m['bindings'].items():assert sha(R/rel)==h,rel
    sunny=R/'docs/qa/checkpoints/2026-11-02/sunny-palette-v9/receipt.json';s=read(sunny);raw=rom.read_bytes()
    assert s['installed']and s['ROM_sha256']==PARENT and len(s['patches'])==5
    for p in s['patches']:
        a=p['offset'];new=bytes.fromhex(p['new']);assert raw[a:a+len(new)]==new
    runs=[];refs=[Path(__file__),manifest,sunny]
    for identity in['bub','bob']:
        p=O/('native-current-landing-'+identity+'-full11-castle-stairs')
        q=read(p/'ready.json');binding=read(p/'capture/binding.json');result=read(p/'capture/full11.json');obs=read(p/'capture/bub-observer.json')
        assert q['ROM_sha256']==binding['ROM_sha256']==obs['ROM_sha256']==PIN
        assert binding['exit_code']==0 and binding['ready_sha256']==sha(p/'ready.json')
        assert result['passed']and result['full_stage']and result['why']=='actual-active1-2-all-four-pipes-three-pits'
        assert result['world']==0 and result['level']==1 and result['engine']==8 and result['initial_lives']==result['final_lives']==2
        assert obs['passed']and obs['failures']==0 and obs['checks']>0
        assert [(v['kind'],v['left'],v['right_exclusive'])for v in result['clears']]==[
            ('pipe',448,480),('pipe',608,640),('pipe',736,768),('pipe',912,944),
            ('pit',1104,1136),('pit',1376,1424),('pit',2448,2480)]
        assert not result['helpers_added']and len(result['actual_normal_pit_jump_entries'])==2
        for e in result['actual_normal_pit_jump_entries']+result['actual_stair_jump_entries']:
            assert e['native_state']==0 and(e['foot'][1]['solid']or e['foot'][3]['solid'])and not e['support_marker']and e['source_held']&128
        for name,h in q['bindings'].items():assert sha(name)==h,name
        runs.append(dict(identity=identity,path=p.relative_to(R).as_posix(),ROM_sha256=PIN,
            frames=obs['frames']if'frames'in obs else read(p/'capture/result.json')['frames'],
            completed_Main=obs['completed_Main'],checks=obs['checks'],failures=obs['failures'],
            original_rides=obs['source_bubble_ride_restarts'],native_pops=obs['pops'],
            initial_lives=2,final_lives=2,full1_1=True,active1_2=True))
        refs += [p/'ready.json',p/'controller.lua',p/'capture/binding.json',p/'capture/full11.json',p/'capture/bub-observer.json']
    before=check(D);assert before['ROM_sha256']in[PARENT,PIN]
    out=dict(passed=True,review_only=not args.install,installed=False,ROM_sha256=PIN,previous_sha256=before['ROM_sha256'],
        candidate=str(rom),destination=str(D),backup_created=False,matching_candidate_bytes=True,
        Sunny_five_patches_exact=True,actual_Bub_changed_bytes=370,original_landing_adapter_bytes=18,
        source_physics_changed=False,helpers_added=False,candidate_full11=runs,downloads_launch_verified=False,
        remaining='Idle/walk roughly half-rate; source-faithful bridge optimization and broader powerup/audio qualification remain incomplete.',
        before=before,bindings={p.relative_to(R).as_posix():sha(p)for p in refs})
    if args.install:
        # Direct replacement is explicitly requested. No backup, patch,
        # symbol or debug sidecar is created alongside the Downloads ROM.
        D.write_bytes(raw);after=check(D);assert sha(D)==PIN and after['passed']
        assert not any(D.with_suffix(ext).exists()for ext in['.lbl','.dbg','.dbg.gz'])
        source=O/'native-current-landing-bob-full11-castle-stairs/controller.lua';controller=source.read_text()
        labels={}
        for line in rom.with_suffix('.lbl').read_text().splitlines():
            match=re.fullmatch(r'al ([0-9A-Fa-f]+) \.([\w]+)',line)
            if match:labels[match[2]]=int(match[1],16)
        explicit={name:int(val)for name,val in re.findall(r'L\["(\w+)"\]=(\d+)',controller)}
        needed=set(re.findall(r'\bL\.(\w+)',controller))|set(re.findall(r"\br\(['\"](\w+)['\"]",controller))
        # Physical observers already embed exact bank/memory/PC tuples.
        # This controller has no dynamic B lookup or native symbol API.
        assert not re.search(r'\bB[.\[]',controller)and'getLabelAddress'not in controller
        prefix=['L=L or{}','B=B or{}']
        for name in sorted(needed):
            assert name in labels or name in explicit,name
            value=labels.get(name,explicit.get(name));assert name not in explicit or explicit[name]==value,name
            prefix.append(f'L["{name}"]={value}')
        controller='\n'.join(prefix)+'\n'+controller
        sys.path.insert(0,str(R/'build/smb2-final62-observer-lua-deps-v1'));from lupa.lua54 import LuaRuntime
        assert LuaRuntime().eval('function(s)local f,e=load(s);assert(f,e);return true end')(controller)
        packet=O/'native-downloads-bob-full11-landing';assert not packet.exists()
        prepare(packet,rom,controller,[Path(__file__),source,D,manifest,sunny],expected=PIN,timeout=240,
            allow_interactive=True,scope='Actual Downloads launch context, exact full Bob1-1 non-shortcut controller replay after both candidate identities pass. ExplicitL/Bprefix and physicalobserver tuples, no Downloads debug/label/patch sidecars. Same originalrides/2supportedfinalpitjumps/stairretreats/naturalcombat/sourceart/header/RGB/OAM/noinjury/lives/active1-2 guards; no emulatorwrites or helper additions.')
        ready=read(packet/'ready.json');ready['ROM']=str(D);(packet/'ready.json').write_text(json.dumps(ready,indent=2)+'\n')
        assert all(sha(name)==h for name,h in ready['bindings'].items())
        out.update(review_only=False,installed=True,after=after,downloads_packet=packet.relative_to(R).as_posix(),
            downloads_ready_sha256=sha(packet/'ready.json'),explicit_L_symbols=len(needed),emulator_launched=False)
    dst=O/('landing-delivery-v40.json'if args.install else'landing-delivery-plan-v40.json');assert not dst.exists()
    dst.write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps({k:v for k,v in out.items()if k not in['bindings']}))


if __name__=='__main__':main()
