; Generated solely from authenticated DK Jr original instructions.
; Code origin A000 and private RAM C000 are MEASUREMENT addresses, not host grants.
.setcpu "6502"
.macpack longbranch
.segment "DKJR"
.export DkjrInitialize
DkjrInitialize=D_ca82
.export DkjrInput
DkjrInput=D_ce6c
.export DkjrLandPose
DkjrLandPose=D_cea2
.export DkjrDefeatTick
DkjrDefeatTick=D_cf37
.export DkjrClock
DkjrClock=D_f1af
.export DkjrFruitHit
DkjrFruitHit=D_d1ae
.export DkjrTransition
DkjrTransition=D_d251
.export DkjrBounds
DkjrBounds=D_d2bd
.export DkjrDamage
DkjrDamage=D_d405
.export DkjrMove
DkjrMove=D_d412
.export DkjrFruitCollision
DkjrFruitCollision=D_d43a
.export DkjrJump
DkjrJump=D_d913
.export DkjrFruitTouch
DkjrFruitTouch=D_d955
.export DkjrFallDistance
DkjrFallDistance=D_da34
.export DkjrLand
DkjrLand=D_daa5
.export DkjrDetachVine
DkjrDetachVine=D_dad7
.export DkjrDefeatDrop
DkjrDefeatDrop=D_daf7
.export DkjrDefeatPose
DkjrDefeatPose=D_db20
.export DkjrFruitAdvance
DkjrFruitAdvance=D_dbb3
.export DkjrRepeat
DkjrRepeat=D_e98b
.export DkjrGravity
DkjrGravity=D_e9ae
.export DkjrPose
DkjrPose=D_e9ee
.export DkjrRect
DkjrRect=D_eb69
D_ca82: ; original $CA82: lda #$00
 lda #$00
D_ca84: ; original $CA84: ldx #$53
 ldx #$53
D_ca86: ; original $CA86: sta $00,x
 sta $c000,x
D_ca88: ; original $CA88: inx
 inx
D_ca89: ; original $CA89: cpx #$e9
 cpx #$e9
D_ca8b: ; original $CA8B: bne $ca86
 jne D_ca86
D_ca8d: ; original $CA8D: lda #$01
 lda #$01
D_ca8f: ; original $CA8F: sta $6b
 sta $c06b
D_ca91: ; original $CA91: sta $9a
 sta $c09a
D_ca93: ; original $CA93: sta $9b
 sta $c09b
D_ca95: ; original $CA95: sta $9c
 sta $c09c
D_ca97: ; original $CA97: sta $9d
 sta $c09d
D_ca99: ; original $CA99: sta $87
 sta $c087
D_ca9b: ; original $CA9B: sta $89
 sta $c089
D_ca9d: ; original $CA9D: lda $4a
 lda $c04a
D_ca9f: ; original $CA9F: and #$01
 and #$01
D_caa1: ; original $CAA1: eor #$01
 eor #$01
D_caa3: ; original $CAA3: sta $6d
 sta $c06d
D_caa5: ; original $CAA5: lda #$02
 lda #$02
D_caa7: ; original $CAA7: sta $7a
 sta $c07a
D_caa9: ; original $CAA9: lda #$60
 lda #$60
D_caab: ; original $CAAB: sta $86
 sta $c086
D_caad: ; original $CAAD: sta $88
 sta $c088
D_caaf: ; original $CAAF: lda #$a0
 lda #$a0
D_cab1: ; original $CAB1: sta $7c
 sta $c07c
D_cab3: ; original $CAB3: lda #$16
 lda #$16
D_cab5: ; original $CAB5: sta $7b
 sta $c07b
D_cab7: ; original $CAB7: lda #$32
 lda #$32
D_cab9: ; original $CAB9: sta $64
 sta $c064
D_cabb: ; original $CABB: lda #$24
 lda #$24
D_cabd: ; original $CABD: sta $65
 sta $c065
 rts ; typed return before original stage art/UI initialization
D_ce6c: ; original $CE6C: lda $49
 lda $c049
D_ce6e: ; original $CE6E: asl a
 asl a
D_ce6f: ; original $CE6F: tax
 tax
D_ce70: ; original $CE70: inx
 inx
D_ce71: ; original $CE71: ldy #$00
 ldy #$00
D_ce73: ; original $CE73: lda $14,x
 lda $c014,x
D_ce75: ; original $CE75: and #$0f
 and #$0f
D_ce77: ; original $CE77: beq $ce8d
 jeq D_ce8d
D_ce79: ; original $CE79: cmp #$08
 cmp #$08
D_ce7b: ; original $CE7B: beq $ce8c
 jeq D_ce8c
D_ce7d: ; original $CE7D: cmp #$04
 cmp #$04
D_ce7f: ; original $CE7F: beq $ce8b
 jeq D_ce8b
D_ce81: ; original $CE81: cmp #$02
 cmp #$02
D_ce83: ; original $CE83: beq $ce8a
 jeq D_ce8a
D_ce85: ; original $CE85: cmp #$01
 cmp #$01
D_ce87: ; original $CE87: bne $ce8d
 jne D_ce8d
D_ce89: ; original $CE89: iny
 iny
D_ce8a: ; original $CE8A: iny
 iny
D_ce8b: ; original $CE8B: iny
 iny
D_ce8c: ; original $CE8C: iny
 iny
D_ce8d: ; original $CE8D: sty $54
 sty $c054
D_ce8f: ; original $CE8F: lda $6b
 lda $c06b
D_ce91: ; original $CE91: cmp #$02
 cmp #$02
D_ce93: ; original $CE93: beq $cea1
 jeq D_cea1
D_ce95: ; original $CE95: lda $14,x
 lda $c014,x
D_ce97: ; original $CE97: and #$80
 and #$80
D_ce99: ; original $CE99: cmp #$00
 cmp #$00
D_ce9b: ; original $CE9B: beq $cea1
 jeq D_cea1
D_ce9d: ; original $CE9D: lda #$03
 lda #$03
D_ce9f: ; original $CE9F: sta $6b
 sta $c06b
D_cea1: ; original $CEA1: rts
 rts
D_cea2: ; original $CEA2: lda $63
 lda $c063
D_cea4: ; original $CEA4: beq $cebf
 jeq D_cebf
D_cea6: ; original $CEA6: lda $0213
 lda $c213
D_cea9: ; original $CEA9: sta $00
 sta $c000
D_ceab: ; original $CEAB: lda $0210
 lda $c210
D_ceae: ; original $CEAE: sta $01
 sta $c001
D_ceb0: ; original $CEB0: lda #$08
 lda #$08
D_ceb2: ; original $CEB2: sta $02
 sta $c002
D_ceb4: ; original $CEB4: lda $6d
 lda $c06d
D_ceb6: ; original $CEB6: eor #$01
 eor #$01
D_ceb8: ; original $CEB8: jsr $e9ee
 jsr D_e9ee
D_cebb: ; original $CEBB: lda #$00
 lda #$00
D_cebd: ; original $CEBD: sta $63
 sta $c063
D_cebf: ; original $CEBF: lda $38
 lda $c038
D_cec1: ; original $CEC1: bne $cec8
 jne D_cec8
D_cec3: ; original $CEC3: lda #$ff
 lda #$ff
D_cec5: ; original $CEC5: sta $0208
 sta $c208
D_cec8: ; original $CEC8: rts
 rts
D_cf37: ; original $CF37: lda #$00
 lda #$00
D_cf39: ; original $CF39: sta $fc
 sta $c0fc
D_cf3b: ; original $CF3B: lda $64
 lda $c064
D_cf3d: ; original $CF3D: bne $cf58
 jne D_cf58
D_cf3f: ; original $CF3F: lda $65
 lda $c065
D_cf41: ; original $CF41: beq $cf49
 jeq D_cf49
D_cf43: ; original $CF43: jsr $db20
 jsr D_db20
D_cf46: ; original $CF46: jmp $cf5b
 jmp D_cf5b
D_cf49: ; original $CF49: jsr $e89f
 jsr DImport_e89f
D_cf4c: ; original $CF4C: cmp #$00
 cmp #$00
D_cf4e: ; original $CF4E: beq $cf54
 jeq D_cf54
D_cf50: ; original $CF50: jsr $cf62
 jsr DImport_cf62
D_cf53: ; original $CF53: rts
 rts
D_cf54: ; original $CF54: jsr $daf7
 jsr D_daf7
D_cf57: ; original $CF57: rts
 rts
D_cf58: ; original $CF58: dec $64
 dec $c064
D_cf5a: ; original $CF5A: rts
 rts
D_cf5b: ; original $CF5B: lda #$03
 lda #$03
D_cf5d: ; original $CF5D: sta $64
 sta $c064
D_cf5f: ; original $CF5F: dec $65
 dec $c065
D_cf61: ; original $CF61: rts
 rts
D_d1ae: ; original $D1AE: lda $66
 lda $c066
D_d1b0: ; original $D1B0: bne $d1b8
 jne D_d1b8
D_d1b2: ; original $D1B2: jsr $d1bc
 jsr D_d1bc
D_d1b5: ; original $D1B5: jmp $d1bb
 jmp D_d1bb
D_d1b8: ; original $D1B8: jsr $d218
 jsr D_d218
D_d1bb: ; original $D1BB: rts
 rts
D_d1bc: ; original $D1BC: lda #$01
 lda #$01
D_d1be: ; original $D1BE: sta $fe
 sta $c0fe
D_d1c0: ; original $D1C0: ldx $69
 ldx $c069
D_d1c2: ; original $D1C2: lda $68
 lda $c068
D_d1c4: ; original $D1C4: cmp #$01
 cmp #$01
D_d1c6: ; original $D1C6: beq $d1e9
 jeq D_d1e9
D_d1c8: ; original $D1C8: lda $0240,x
 lda $c240,x
D_d1cb: ; original $D1CB: sta $0208
 sta $c208
D_d1ce: ; original $D1CE: lda #$ff
 lda #$ff
D_d1d0: ; original $D1D0: sta $0240,x
 sta $c240,x
D_d1d3: ; original $D1D3: lda $0243,x
 lda $c243,x
D_d1d6: ; original $D1D6: sta $020b
 sta $c20b
D_d1d9: ; original $D1D9: ldy #$03
 ldy #$03
D_d1db: ; original $D1DB: lda #$ff
 lda #$ff
D_d1dd: ; original $D1DD: sta $0244,x
 sta $c244,x
D_d1e0: ; original $D1E0: sta $0248,x
 sta $c248,x
D_d1e3: ; original $D1E3: sta $024c,x
 sta $c24c,x
D_d1e6: ; original $D1E6: jmp $d1ff
 jmp D_d1ff
D_d1e9: ; original $D1E9: lda $02c0,x
 lda $c2c0,x
D_d1ec: ; original $D1EC: sta $0208
 sta $c208
D_d1ef: ; original $D1EF: lda #$ff
 lda #$ff
D_d1f1: ; original $D1F1: sta $02c0,x
 sta $c2c0,x
D_d1f4: ; original $D1F4: lda $02c3,x
 lda $c2c3,x
D_d1f7: ; original $D1F7: sta $020b
 sta $c20b
D_d1fa: ; original $D1FA: lda #$ff
 lda #$ff
D_d1fc: ; original $D1FC: sta $02c4,x
 sta $c2c4,x
D_d1ff: ; original $D1FF: lda #$90
 lda #$90
D_d201: ; original $D201: sta $0209
 sta $c209
D_d204: ; original $D204: lda #$00
 lda #$00
D_d206: ; original $D206: sta $020a
 sta $c20a
D_d209: ; original $D209: lda #$07
 lda #$07
D_d20b: ; original $D20B: sta $09
 sta $c009
D_d20d: ; original $D20D: lda #$04
 lda #$04
D_d20f: ; original $D20F: sta $08
 sta $c008
D_d211: ; original $D211: lda #$01
 lda #$01
D_d213: ; original $D213: sta $66
 sta $c066
D_d215: ; original $D215: sta $67
 sta $c067
D_d217: ; original $D217: rts
 rts
D_d218: ; original $D218: dec $08
 dec $c008
D_d21a: ; original $D21A: bpl $d250
 jpl D_d250
D_d21c: ; original $D21C: dec $09
 dec $c009
D_d21e: ; original $D21E: bne $d237
 jne D_d237
D_d220: ; original $D220: lda #$ff
 lda #$ff
D_d222: ; original $D222: sta $0200
 sta $c200
D_d225: ; original $D225: jsr $ed44
 jsr DImport_ed44
D_d228: ; original $D228: ldx #$40
 ldx #$40
D_d22a: ; original $D22A: stx $38
 stx $c038
D_d22c: ; original $D22C: lda #$00
 lda #$00
D_d22e: ; original $D22E: sta $66
 sta $c066
D_d230: ; original $D230: sta $68
 sta $c068
D_d232: ; original $D232: ldx #$93
 ldx #$93
D_d234: ; original $D234: jmp $d243
 jmp D_d243
D_d237: ; original $D237: ldx $0209
 ldx $c209
D_d23a: ; original $D23A: lda $67
 lda $c067
D_d23c: ; original $D23C: beq $d242
 jeq D_d242
D_d23e: ; original $D23E: inx
 inx
D_d23f: ; original $D23F: jmp $d243
 jmp D_d243
D_d242: ; original $D242: dex
 dex
D_d243: ; original $D243: lda $09
 lda $c009
D_d245: ; original $D245: and #$02
 and #$02
D_d247: ; original $D247: sta $67
 sta $c067
D_d249: ; original $D249: stx $0209
 stx $c209
D_d24c: ; original $D24C: lda #$08
 lda #$08
D_d24e: ; original $D24E: sta $08
 sta $c008
D_d250: ; original $D250: rts
 rts
D_d251: ; original $D251: lda $6b
 lda $c06b
D_d253: ; original $D253: cmp $6c
 cmp $c06c
D_d255: ; original $D255: beq $d2bc
 jeq D_d2bc
D_d257: ; original $D257: lda #$00
 lda #$00
D_d259: ; original $D259: sta $56
 sta $c056
D_d25b: ; original $D25B: sta $78
 sta $c078
D_d25d: ; original $D25D: lda $6b
 lda $c06b
D_d25f: ; original $D25F: cmp #$01
 cmp #$01
D_d261: ; original $D261: beq $d27b
 jeq D_d27b
D_d263: ; original $D263: cmp #$02
 cmp #$02
D_d265: ; original $D265: beq $d288
 jeq D_d288
D_d267: ; original $D267: cmp #$03
 cmp #$03
D_d269: ; original $D269: beq $d291
 jeq D_d291
D_d26b: ; original $D26B: cmp #$04
 cmp #$04
D_d26d: ; original $D26D: beq $d2a4
 jeq D_d2a4
D_d26f: ; original $D26F: lda $6c
 lda $c06c
D_d271: ; original $D271: cmp #$04
 cmp #$04
D_d273: ; original $D273: bne $d2b8
 jne D_d2b8
D_d275: ; original $D275: jsr $daa5
 jsr D_daa5
D_d278: ; original $D278: jmp $d2b4
 jmp D_d2b4
D_d27b: ; original $D27B: lda #$00
 lda #$00
D_d27d: ; original $D27D: sta $75
 sta $c075
D_d27f: ; original $D27F: sta $02
 sta $c002
D_d281: ; original $D281: sta $70
 sta $c070
D_d283: ; original $D283: sta $6f
 sta $c06f
D_d285: ; original $D285: jmp $d2b8
 jmp D_d2b8
D_d288: ; original $D288: lda #$01
 lda #$01
D_d28a: ; original $D28A: sta $71
 sta $c071
D_d28c: ; original $D28C: sta $79
 sta $c079
D_d28e: ; original $D28E: jmp $d2b8
 jmp D_d2b8
D_d291: ; original $D291: lda #$00
 lda #$00
D_d293: ; original $D293: sta $7e
 sta $c07e
D_d295: ; original $D295: sta $05c6
 sta $c5c6
D_d298: ; original $D298: lda #$40
 lda #$40
D_d29a: ; original $D29A: sta $ff
 sta $c0ff
D_d29c: ; original $D29C: lda $0210
 lda $c210
D_d29f: ; original $D29F: sta $76
 sta $c076
D_d2a1: ; original $D2A1: jmp $d2b8
 jmp D_d2b8
D_d2a4: ; original $D2A4: lda $0210
 lda $c210
D_d2a7: ; original $D2A7: sta $76
 sta $c076
D_d2a9: ; original $D2A9: lda #$01
 lda #$01
D_d2ab: ; original $D2AB: sta $09
 sta $c009
D_d2ad: ; original $D2AD: lda #$00
 lda #$00
D_d2af: ; original $D2AF: sta $71
 sta $c071
D_d2b1: ; original $D2B1: jmp $d2b8
 jmp D_d2b8
D_d2b4: ; original $D2B4: lda #$01
 lda #$01
D_d2b6: ; original $D2B6: sta $ff
 sta $c0ff
D_d2b8: ; original $D2B8: lda $6b
 lda $c06b
D_d2ba: ; original $D2BA: sta $6c
 sta $c06c
D_d2bc: ; original $D2BC: rts
 rts
D_d2bd: ; original $D2BD: lda $0210
 lda $c210
D_d2c0: ; original $D2C0: sta $01
 sta $c001
D_d2c2: ; original $D2C2: lda $0213
 lda $c213
D_d2c5: ; original $D2C5: sta $00
 sta $c000
D_d2c7: ; original $D2C7: lda $6b
 lda $c06b
D_d2c9: ; original $D2C9: cmp #$04
 cmp #$04
D_d2cb: ; original $D2CB: bmi $d2cf
 jmi D_d2cf
D_d2cd: ; original $D2CD: lda #$01
 lda #$01
D_d2cf: ; original $D2CF: sec
 sec
D_d2d0: ; original $D2D0: sbc #$01
 sbc #$01
D_d2d2: ; original $D2D2: asl a
 asl a
D_d2d3: ; original $D2D3: asl a
 asl a
D_d2d4: ; original $D2D4: clc
 clc
D_d2d5: ; original $D2D5: ldx $6d
 ldx $c06d
D_d2d7: ; original $D2D7: bne $d2db
 jne D_d2db
D_d2d9: ; original $D2D9: adc #$02
 adc #$02
D_d2db: ; original $D2DB: ldx $71
 ldx $c071
D_d2dd: ; original $D2DD: cpx #$02
 cpx #$02
D_d2df: ; original $D2DF: bne $d2e3
 jne D_d2e3
D_d2e1: ; original $D2E1: adc #$07
 adc #$07
D_d2e3: ; original $D2E3: tax
 tax
D_d2e4: ; original $D2E4: lda $c369,x
 lda DData_c369,x
D_d2e7: ; original $D2E7: sta $02
 sta $c002
D_d2e9: ; original $D2E9: lda $c36a,x
 lda DData_c36a,x
D_d2ec: ; original $D2EC: sta $03
 sta $c003
D_d2ee: ; original $D2EE: jsr $eb69
 jsr D_eb69
D_d2f1: ; original $D2F1: ldx #$03
 ldx #$03
D_d2f3: ; original $D2F3: lda $3e,x
 lda $c03e,x
D_d2f5: ; original $D2F5: sta $05fc,x
 sta $c5fc,x
D_d2f8: ; original $D2F8: dex
 dex
D_d2f9: ; original $D2F9: bpl $d2f3
 jpl D_d2f3
D_d2fb: ; original $D2FB: rts
 rts
D_d405: ; original $D405: lda #$05
 lda #$05
D_d407: ; original $D407: sta $6b
 sta $c06b
D_d409: ; original $D409: lda #$04
 lda #$04
D_d40b: ; original $D40B: sta $ff
 sta $c0ff
D_d40d: ; original $D40D: lda #$01
 lda #$01
D_d40f: ; original $D40F: sta $09
 sta $c009
D_d411: ; original $D411: rts
 rts
D_d412: ; original $D412: jsr $d2bd
 jsr D_d2bd
D_d415: ; original $D415: lda $6b
 lda $c06b
D_d417: ; original $D417: cmp #$01
 cmp #$01
D_d419: ; original $D419: beq $d427
 jeq D_d427
D_d41b: ; original $D41B: cmp #$02
 cmp #$02
D_d41d: ; original $D41D: beq $d42d
 jeq D_d42d
D_d41f: ; original $D41F: cmp #$03
 cmp #$03
D_d421: ; original $D421: beq $d433
 jeq D_d433
D_d423: ; original $D423: jsr $d631
 jsr D_d631
D_d426: ; original $D426: rts
 rts
D_d427: ; original $D427: jsr $d56e
 jsr D_d56e
D_d42a: ; original $D42A: jmp $d436
 jmp D_d436
D_d42d: ; original $D42D: jsr $d58c
 jsr D_d58c
D_d430: ; original $D430: jmp $d436
 jmp D_d436
D_d433: ; original $D433: jsr $d5d7
 jsr D_d5d7
D_d436: ; original $D436: jsr $d955
 jsr D_d955
D_d439: ; original $D439: rts
 rts
D_d43a: ; original $D43A: lda $8c
 lda $c08c
D_d43c: ; original $D43C: beq $d476
 jeq D_d476
D_d43e: ; original $D43E: lda $0230
 lda $c230
D_d441: ; original $D441: sta $01
 sta $c001
D_d443: ; original $D443: lda $0233
 lda $c233
D_d446: ; original $D446: sta $00
 sta $c000
D_d448: ; original $D448: lda #$dd
 lda #<DData_c2dd
D_d44a: ; original $D44A: sta $02
 sta $c002
D_d44c: ; original $D44C: lda #$c2
 lda #>DData_c2dd
D_d44e: ; original $D44E: sta $03
 sta $c003
D_d450: ; original $D450: jsr $eb69
 jsr D_eb69
D_d453: ; original $D453: lda $4a
 lda $c04a
D_d455: ; original $D455: cmp #$01
 cmp #$01
D_d457: ; original $D457: beq $d467
 jeq D_d467
D_d459: ; original $D459: cmp #$02
 cmp #$02
D_d45b: ; original $D45B: beq $d46d
 jeq D_d46d
D_d45d: ; original $D45D: cmp #$03
 cmp #$03
D_d45f: ; original $D45F: beq $d473
 jeq D_d473
D_d461: ; original $D461: jsr $d4b8
 jsr D_d4b8
D_d464: ; original $D464: jmp $d476
 jmp D_d476
D_d467: ; original $D467: jsr $d479
 jsr D_d479
D_d46a: ; original $D46A: jmp $d476
 jmp D_d476
D_d46d: ; original $D46D: jsr $d496
 jsr D_d496
D_d470: ; original $D470: jmp $d476
 jmp D_d476
D_d473: ; original $D473: jsr $d49a
 jsr D_d49a
D_d476: ; original $D476: sta $68
 sta $c068
D_d478: ; original $D478: rts
 rts
D_d479: ; original $D479: ldx $a0
 ldx $c0a0
D_d47b: ; original $D47B: ldy #$00
 ldy #$00
D_d47d: ; original $D47D: jsr $d4d6
 jsr D_d4d6
D_d480: ; original $D480: cmp #$00
 cmp #$00
D_d482: ; original $D482: bne $d491
 jne D_d491
D_d484: ; original $D484: ldx $b0
 ldx $c0b0
D_d486: ; original $D486: ldy #$20
 ldy #$20
D_d488: ; original $D488: jsr $d4d6
 jsr D_d4d6
D_d48b: ; original $D48B: cmp #$00
 cmp #$00
D_d48d: ; original $D48D: beq $d495
 jeq D_d495
D_d48f: ; original $D48F: dec $b1
 dec $c0b1
D_d491: ; original $D491: lda #$01
 lda #$01
D_d493: ; original $D493: sty $69
 sty $c069
D_d495: ; original $D495: rts
 rts
D_d496: ; original $D496: jsr $d4c3
 jsr D_d4c3
D_d499: ; original $D499: rts
 rts
D_d49a: ; original $D49A: ldx $a0
 ldx $c0a0
D_d49c: ; original $D49C: ldy #$00
 ldy #$00
D_d49e: ; original $D49E: jsr $d51e
 jsr D_d51e
D_d4a1: ; original $D4A1: cmp #$00
 cmp #$00
D_d4a3: ; original $D4A3: bne $d4b2
 jne D_d4b2
D_d4a5: ; original $D4A5: ldx $b0
 ldx $c0b0
D_d4a7: ; original $D4A7: ldy #$60
 ldy #$60
D_d4a9: ; original $D4A9: jsr $d51e
 jsr D_d51e
D_d4ac: ; original $D4AC: cmp #$00
 cmp #$00
D_d4ae: ; original $D4AE: beq $d4b7
 jeq D_d4b7
D_d4b0: ; original $D4B0: dec $b1
 dec $c0b1
D_d4b2: ; original $D4B2: clc
 clc
D_d4b3: ; original $D4B3: adc #$01
 adc #$01
D_d4b5: ; original $D4B5: sty $69
 sty $c069
D_d4b7: ; original $D4B7: rts
 rts
D_d4b8: ; original $D4B8: ldx $a0
 ldx $c0a0
D_d4ba: ; original $D4BA: ldy #$00
 ldy #$00
D_d4bc: ; original $D4BC: jsr $d4d6
 jsr D_d4d6
D_d4bf: ; original $D4BF: cmp #$00
 cmp #$00
D_d4c1: ; original $D4C1: bne $d4d3
 jne D_d4d3
D_d4c3: ; original $D4C3: ldx $b0
 ldx $c0b0
D_d4c5: ; original $D4C5: ldy #$00
 ldy #$00
D_d4c7: ; original $D4C7: jsr $d51e
 jsr D_d51e
D_d4ca: ; original $D4CA: cmp #$00
 cmp #$00
D_d4cc: ; original $D4CC: beq $d4d5
 jeq D_d4d5
D_d4ce: ; original $D4CE: clc
 clc
D_d4cf: ; original $D4CF: adc #$01
 adc #$01
D_d4d1: ; original $D4D1: dec $b1
 dec $c0b1
D_d4d3: ; original $D4D3: sty $69
 sty $c069
D_d4d5: ; original $D4D5: rts
 rts
D_d4d6: ; original $D4D6: stx $05
 stx $c005
D_d4d8: ; original $D4D8: ldx #$00
 ldx #$00
D_d4da: ; original $D4DA: cpy #$20
 cpy #$20
D_d4dc: ; original $D4DC: bpl $d4e3
 jpl D_d4e3
D_d4de: ; original $D4DE: lda $a3,x
 lda $c0a3,x
D_d4e0: ; original $D4E0: jmp $d4e5
 jmp D_d4e5
D_d4e3: ; original $D4E3: lda $b4,x
 lda $c0b4,x
D_d4e5: ; original $D4E5: cmp #$02
 cmp #$02
D_d4e7: ; original $D4E7: bpl $d4f4
 jpl D_d4f4
D_d4e9: ; original $D4E9: lda #$91
 lda #<DData_c391
D_d4eb: ; original $D4EB: sta $02
 sta $c002
D_d4ed: ; original $D4ED: lda #$c3
 lda #>DData_c391
D_d4ef: ; original $D4EF: sta $03
 sta $c003
D_d4f1: ; original $D4F1: jmp $d4fc
 jmp D_d4fc
D_d4f4: ; original $D4F4: lda #$95
 lda #<DData_c395
D_d4f6: ; original $D4F6: sta $02
 sta $c002
D_d4f8: ; original $D4F8: lda #$c3
 lda #>DData_c395
D_d4fa: ; original $D4FA: sta $03
 sta $c003
D_d4fc: ; original $D4FC: lda $02c0,y
 lda $c2c0,y
D_d4ff: ; original $D4FF: cmp #$ff
 cmp #$ff
D_d501: ; original $D501: beq $d511
 jeq D_d511
D_d503: ; original $D503: sta $01
 sta $c001
D_d505: ; original $D505: lda $02c3,y
 lda $c2c3,y
D_d508: ; original $D508: sta $00
 sta $c000
D_d50a: ; original $D50A: jsr $eb6e
 jsr D_eb6e
D_d50d: ; original $D50D: cmp #$00
 cmp #$00
D_d50f: ; original $D50F: bne $d51d
 jne D_d51d
D_d511: ; original $D511: tya
 tya
D_d512: ; original $D512: clc
 clc
D_d513: ; original $D513: adc #$08
 adc #$08
D_d515: ; original $D515: tay
 tay
D_d516: ; original $D516: inx
 inx
D_d517: ; original $D517: cpx $05
 cpx $c005
D_d519: ; original $D519: bne $d4da
 jne D_d4da
D_d51b: ; original $D51B: lda #$00
 lda #$00
D_d51d: ; original $D51D: rts
 rts
D_d51e: ; original $D51E: lda #$b1
 lda #<DData_c3b1
D_d520: ; original $D520: sta $02
 sta $c002
D_d522: ; original $D522: lda #$c3
 lda #>DData_c3b1
D_d524: ; original $D524: sta $03
 sta $c003
D_d526: ; original $D526: lda $0240,y
 lda $c240,y
D_d529: ; original $D529: cmp #$ff
 cmp #$ff
D_d52b: ; original $D52B: beq $d53b
 jeq D_d53b
D_d52d: ; original $D52D: sta $01
 sta $c001
D_d52f: ; original $D52F: lda $0243,y
 lda $c243,y
D_d532: ; original $D532: sta $00
 sta $c000
D_d534: ; original $D534: jsr $eb6e
 jsr D_eb6e
D_d537: ; original $D537: cmp #$00
 cmp #$00
D_d539: ; original $D539: bne $d544
 jne D_d544
D_d53b: ; original $D53B: tya
 tya
D_d53c: ; original $D53C: clc
 clc
D_d53d: ; original $D53D: adc #$10
 adc #$10
D_d53f: ; original $D53F: tay
 tay
D_d540: ; original $D540: dex
 dex
D_d541: ; original $D541: bne $d526
 jne D_d526
D_d543: ; original $D543: txa
 txa
D_d544: ; original $D544: rts
 rts
D_d545: ; original $D545: lda $020f
 lda $c20f
D_d548: ; original $D548: sta $00
 sta $c000
D_d54a: ; original $D54A: lda $020c
 lda $c20c
D_d54d: ; original $D54D: sta $01
 sta $c001
D_d54f: ; original $D54F: lda #$b5
 lda #<DData_c3b5
D_d551: ; original $D551: sta $02
 sta $c002
D_d553: ; original $D553: lda #$c3
 lda #>DData_c3b5
D_d555: ; original $D555: sta $03
 sta $c003
D_d557: ; original $D557: jsr $eb6e
 jsr D_eb6e
D_d55a: ; original $D55A: rts
 rts
D_d56e: ; original $D56E: jsr $e893
 jsr DImport_e893
D_d571: ; original $D571: cmp #$00
 cmp #$00
D_d573: ; original $D573: bne $d581
 jne D_d581
D_d575: ; original $D575: jsr $e89f
 jsr DImport_e89f
D_d578: ; original $D578: cmp #$00
 cmp #$00
D_d57a: ; original $D57A: bne $d585
 jne D_d585
D_d57c: ; original $D57C: lda #$04
 lda #$04
D_d57e: ; original $D57E: sta $6b
 sta $c06b
D_d580: ; original $D580: rts
 rts
D_d581: ; original $D581: jsr $d612
 jsr D_d612
D_d584: ; original $D584: rts
 rts
D_d585: ; original $D585: jsr $da14
 jsr D_da14
D_d588: ; original $D588: jsr $d681
 jsr D_d681
D_d58b: ; original $D58B: rts
 rts
D_d58c: ; original $D58C: lda $79
 lda $c079
D_d58e: ; original $D58E: bne $d5cb
 jne D_d5cb
D_d590: ; original $D590: jsr $da14
 jsr D_da14
D_d593: ; original $D593: jsr $e89f
 jsr DImport_e89f
D_d596: ; original $D596: beq $d5a2
 jeq D_d5a2
D_d598: ; original $D598: lda $54
 lda $c054
D_d59a: ; original $D59A: cmp #$02
 cmp #$02
D_d59c: ; original $D59C: bne $d5a2
 jne D_d5a2
D_d59e: ; original $D59E: eor #$02
 eor #$02
D_d5a0: ; original $D5A0: sta $54
 sta $c054
D_d5a2: ; original $D5A2: inc $ea
 inc $c0ea
D_d5a4: ; original $D5A4: jsr $e893
 jsr DImport_e893
D_d5a7: ; original $D5A7: cmp #$00
 cmp #$00
D_d5a9: ; original $D5A9: beq $d5c6
 jeq D_d5c6
D_d5ab: ; original $D5AB: lda $71
 lda $c071
D_d5ad: ; original $D5AD: cmp #$01
 cmp #$01
D_d5af: ; original $D5AF: beq $d5c2
 jeq D_d5c2
D_d5b1: ; original $D5B1: jsr $e897
 jsr DImport_e897
D_d5b4: ; original $D5B4: sta $72
 sta $c072
D_d5b6: ; original $D5B6: cmp #$11
 cmp #$11
D_d5b8: ; original $D5B8: bne $d5be
 jne D_d5be
D_d5ba: ; original $D5BA: jsr $d87e
 jsr D_d87e
D_d5bd: ; original $D5BD: rts
 rts
D_d5be: ; original $D5BE: jsr $d82c
 jsr D_d82c
D_d5c1: ; original $D5C1: rts
 rts
D_d5c2: ; original $D5C2: jsr $d71b
 jsr D_d71b
D_d5c5: ; original $D5C5: rts
 rts
D_d5c6: ; original $D5C6: lda #$04
 lda #$04
D_d5c8: ; original $D5C8: sta $6b
 sta $c06b
D_d5ca: ; original $D5CA: rts
 rts
D_d5cb: ; original $D5CB: lda $77
 lda $c077
D_d5cd: ; original $D5CD: sta $00
 sta $c000
D_d5cf: ; original $D5CF: jsr $da66
 jsr D_da66
D_d5d2: ; original $D5D2: lda #$00
 lda #$00
D_d5d4: ; original $D5D4: sta $79
 sta $c079
D_d5d6: ; original $D5D6: rts
 rts
D_d5d7: ; original $D5D7: jsr $e893
 jsr DImport_e893
D_d5da: ; original $D5DA: cmp #$00
 cmp #$00
D_d5dc: ; original $D5DC: bne $d600
 jne D_d600
D_d5de: ; original $D5DE: jsr $ecb7
 jsr DImport_ecb7
D_d5e1: ; original $D5E1: lda $7e
 lda $c07e
D_d5e3: ; original $D5E3: cmp #$03
 cmp #$03
D_d5e5: ; original $D5E5: bcc $d5ee
 jcc D_d5ee
D_d5e7: ; original $D5E7: jsr $e89f
 jsr DImport_e89f
D_d5ea: ; original $D5EA: cmp #$00
 cmp #$00
D_d5ec: ; original $D5EC: bne $d604
 jne D_d604
D_d5ee: ; original $D5EE: jsr $e89b
 jsr DImport_e89b
D_d5f1: ; original $D5F1: cmp #$00
 cmp #$00
D_d5f3: ; original $D5F3: bne $d608
 jne D_d608
D_d5f5: ; original $D5F5: lda $0210
 lda $c210
D_d5f8: ; original $D5F8: cmp #$d8
 cmp #$d8
D_d5fa: ; original $D5FA: bcs $d60d
 jcs D_d60d
D_d5fc: ; original $D5FC: jsr $d913
 jsr D_d913
D_d5ff: ; original $D5FF: rts
 rts
D_d600: ; original $D600: jsr $d612
 jsr D_d612
D_d603: ; original $D603: rts
 rts
D_d604: ; original $D604: jsr $da22
 jsr D_da22
D_d607: ; original $D607: rts
 rts
D_d608: ; original $D608: lda #$04
 lda #$04
D_d60a: ; original $D60A: sta $6b
 sta $c06b
D_d60c: ; original $D60C: rts
 rts
D_d60d: ; original $D60D: lda #$05
 lda #$05
D_d60f: ; original $D60F: sta $6b
 sta $c06b
D_d611: ; original $D611: rts
 rts
D_d612: ; original $D612: lda $42
 lda $c042
D_d614: ; original $D614: sec
 sec
D_d615: ; original $D615: sbc #$10
 sbc #$10
D_d617: ; original $D617: sta $77
 sta $c077
D_d619: ; original $D619: lda #$02
 lda #$02
D_d61b: ; original $D61B: sta $6b
 sta $c06b
D_d61d: ; original $D61D: lda $42
 lda $c042
D_d61f: ; original $D61F: cmp #$14
 cmp #$14
D_d621: ; original $D621: beq $d62c
 jeq D_d62c
D_d623: ; original $D623: cmp #$ec
 cmp #$ec
D_d625: ; original $D625: bne $d630
 jne D_d630
D_d627: ; original $D627: lda #$01
 lda #$01
D_d629: ; original $D629: sta $6d
 sta $c06d
D_d62b: ; original $D62B: rts
 rts
D_d62c: ; original $D62C: lda #$00
 lda #$00
D_d62e: ; original $D62E: sta $6d
 sta $c06d
D_d630: ; original $D630: rts
 rts
D_d631: ; original $D631: jsr $e89f
 jsr DImport_e89f
D_d634: ; original $D634: cmp #$00
 cmp #$00
D_d636: ; original $D636: beq $d640
 jeq D_d640
D_d638: ; original $D638: jsr $da22
 jsr D_da22
D_d63b: ; original $D63B: lda #$10
 lda #$10
D_d63d: ; original $D63D: sta $ff
 sta $c0ff
D_d63f: ; original $D63F: rts
 rts
D_d640: ; original $D640: lda $0210
 lda $c210
D_d643: ; original $D643: cmp #$d8
 cmp #$d8
D_d645: ; original $D645: bcc $d650
 jcc D_d650
D_d647: ; original $D647: lda #$10
 lda #$10
D_d649: ; original $D649: sta $ff
 sta $c0ff
D_d64b: ; original $D64B: lda #$05
 lda #$05
D_d64d: ; original $D64D: sta $6b
 sta $c06b
D_d64f: ; original $D64F: rts
 rts
D_d650: ; original $D650: jsr $da34
 jsr D_da34
D_d653: ; original $D653: beq $d65d
 jeq D_d65d
D_d655: ; original $D655: lda $09
 lda $c009
D_d657: ; original $D657: sta $ff
 sta $c0ff
D_d659: ; original $D659: lda #$00
 lda #$00
D_d65b: ; original $D65B: sta $09
 sta $c009
D_d65d: ; original $D65D: lda $0213
 lda $c213
D_d660: ; original $D660: sta $00
 sta $c000
D_d662: ; original $D662: lda $0210
 lda $c210
D_d665: ; original $D665: clc
 clc
D_d666: ; original $D666: adc $7a
 adc $c07a
D_d668: ; original $D668: sta $01
 sta $c001
D_d66a: ; original $D66A: lda $0211
 lda $c211
D_d66d: ; original $D66D: ldx $0212
 ldx $c212
D_d670: ; original $D670: cpx #$40
 cpx #$40
D_d672: ; original $D672: bmi $d677
 jmi D_d677
D_d674: ; original $D674: sec
 sec
D_d675: ; original $D675: sbc #$06
 sbc #$06
D_d677: ; original $D677: sta $02
 sta $c002
D_d679: ; original $D679: lda $6d
 lda $c06d
D_d67b: ; original $D67B: eor #$01
 eor #$01
D_d67d: ; original $D67D: jsr $e9ee
 jsr D_e9ee
D_d680: ; original $D680: rts
 rts
D_d681: ; original $D681: lda $0210
 lda $c210
D_d684: ; original $D684: sta $01
 sta $c001
D_d686: ; original $D686: lda $54
 lda $c054
D_d688: ; original $D688: cmp #$03
 cmp #$03
D_d68a: ; original $D68A: beq $d696
 jeq D_d696
D_d68c: ; original $D68C: cmp #$04
 cmp #$04
D_d68e: ; original $D68E: bne $d6b8
 jne D_d6b8
D_d690: ; original $D690: jsr $d6b9
 jsr D_d6b9
D_d693: ; original $D693: jmp $d699
 jmp D_d699
D_d696: ; original $D696: jsr $d6d7
 jsr D_d6d7
D_d699: ; original $D699: sta $00
 sta $c000
D_d69b: ; original $D69B: and #$02
 and #$02
D_d69d: ; original $D69D: pha
 pha
D_d69e: ; original $D69E: cmp $6f
 cmp $c06f
D_d6a0: ; original $D6A0: beq $d6a5
 jeq D_d6a5
D_d6a2: ; original $D6A2: jsr $d6f5
 jsr D_d6f5
D_d6a5: ; original $D6A5: pla
 pla
D_d6a6: ; original $D6A6: sta $6f
 sta $c06f
D_d6a8: ; original $D6A8: lda $75
 lda $c075
D_d6aa: ; original $D6AA: sta $02
 sta $c002
D_d6ac: ; original $D6AC: lda $0210
 lda $c210
D_d6af: ; original $D6AF: sta $01
 sta $c001
D_d6b1: ; original $D6B1: lda $6d
 lda $c06d
D_d6b3: ; original $D6B3: eor #$01
 eor #$01
D_d6b5: ; original $D6B5: jsr $e9ee
 jsr D_e9ee
D_d6b8: ; original $D6B8: rts
 rts
D_d6b9: ; original $D6B9: lda #$01
 lda #$01
D_d6bb: ; original $D6BB: sta $6d
 sta $c06d
D_d6bd: ; original $D6BD: lda $78
 lda $c078
D_d6bf: ; original $D6BF: cmp #$04
 cmp #$04
D_d6c1: ; original $D6C1: beq $d6d0
 jeq D_d6d0
D_d6c3: ; original $D6C3: lda $56
 lda $c056
D_d6c5: ; original $D6C5: clc
 clc
D_d6c6: ; original $D6C6: adc #$a0
 adc #$a0
D_d6c8: ; original $D6C8: sta $56
 sta $c056
D_d6ca: ; original $D6CA: lda $0213
 lda $c213
D_d6cd: ; original $D6CD: adc #$00
 adc #$00
D_d6cf: ; original $D6CF: rts
 rts
D_d6d0: ; original $D6D0: lda $0213
 lda $c213
D_d6d3: ; original $D6D3: sec
 sec
D_d6d4: ; original $D6D4: sbc #$02
 sbc #$02
D_d6d6: ; original $D6D6: rts
 rts
D_d6d7: ; original $D6D7: lda #$00
 lda #$00
D_d6d9: ; original $D6D9: sta $6d
 sta $c06d
D_d6db: ; original $D6DB: lda $78
 lda $c078
D_d6dd: ; original $D6DD: cmp #$03
 cmp #$03
D_d6df: ; original $D6DF: beq $d6ee
 jeq D_d6ee
D_d6e1: ; original $D6E1: lda $56
 lda $c056
D_d6e3: ; original $D6E3: sec
 sec
D_d6e4: ; original $D6E4: sbc #$a0
 sbc #$a0
D_d6e6: ; original $D6E6: sta $56
 sta $c056
D_d6e8: ; original $D6E8: lda $0213
 lda $c213
D_d6eb: ; original $D6EB: sbc #$00
 sbc #$00
D_d6ed: ; original $D6ED: rts
 rts
D_d6ee: ; original $D6EE: lda $0213
 lda $c213
D_d6f1: ; original $D6F1: clc
 clc
D_d6f2: ; original $D6F2: adc #$02
 adc #$02
D_d6f4: ; original $D6F4: rts
 rts
D_d6f5: ; original $D6F5: lda $75
 lda $c075
D_d6f7: ; original $D6F7: beq $d709
 jeq D_d709
D_d6f9: ; original $D6F9: cmp #$10
 cmp #$10
D_d6fb: ; original $D6FB: bpl $d701
 jpl D_d701
D_d6fd: ; original $D6FD: ldx $70
 ldx $c070
D_d6ff: ; original $D6FF: beq $d709
 jeq D_d709
D_d701: ; original $D701: sec
 sec
D_d702: ; original $D702: sbc #$08
 sbc #$08
D_d704: ; original $D704: ldx #$01
 ldx #$01
D_d706: ; original $D706: jmp $d70e
 jmp D_d70e
D_d709: ; original $D709: clc
 clc
D_d70a: ; original $D70A: adc #$08
 adc #$08
D_d70c: ; original $D70C: ldx #$00
 ldx #$00
D_d70e: ; original $D70E: stx $70
 stx $c070
D_d710: ; original $D710: sta $75
 sta $c075
D_d712: ; original $D712: lda $6d
 lda $c06d
D_d714: ; original $D714: sta $6e
 sta $c06e
D_d716: ; original $D716: lda #$80
 lda #$80
D_d718: ; original $D718: sta $ff
 sta $c0ff
D_d71a: ; original $D71A: rts
 rts
D_d71b: ; original $D71B: lda $54
 lda $c054
D_d71d: ; original $D71D: beq $d72a
 jeq D_d72a
D_d71f: ; original $D71F: cmp #$03
 cmp #$03
D_d721: ; original $D721: bmi $d727
 jmi D_d727
D_d723: ; original $D723: jsr $d79c
 jsr D_d79c
D_d726: ; original $D726: rts
 rts
D_d727: ; original $D727: jsr $d72b
 jsr D_d72b
D_d72a: ; original $D72A: rts
 rts
D_d72b: ; original $D72B: lda $0213
 lda $c213
D_d72e: ; original $D72E: sta $00
 sta $c000
D_d730: ; original $D730: lda $54
 lda $c054
D_d732: ; original $D732: cmp #$01
 cmp #$01
D_d734: ; original $D734: bne $d73c
 jne D_d73c
D_d736: ; original $D736: jsr $d75a
 jsr D_d75a
D_d739: ; original $D739: jmp $d73f
 jmp D_d73f
D_d73c: ; original $D73C: jsr $d77e
 jsr D_d77e
D_d73f: ; original $D73F: sta $01
 sta $c001
D_d741: ; original $D741: and #$01
 and #$01
D_d743: ; original $D743: beq $d74a
 jeq D_d74a
D_d745: ; original $D745: lda #$28
 lda #$28
D_d747: ; original $D747: jmp $d74c
 jmp D_d74c
D_d74a: ; original $D74A: lda #$30
 lda #$30
D_d74c: ; original $D74C: sta $02
 sta $c002
D_d74e: ; original $D74E: lda $6d
 lda $c06d
D_d750: ; original $D750: eor #$01
 eor #$01
D_d752: ; original $D752: jsr $e9ee
 jsr D_e9ee
D_d755: ; original $D755: lda #$01
 lda #$01
D_d757: ; original $D757: sta $71
 sta $c071
D_d759: ; original $D759: rts
 rts
D_d75a: ; original $D75A: lda $ea
 lda $c0ea
D_d75c: ; original $D75C: and #$0a
 and #$0a
D_d75e: ; original $D75E: bne $d764
 jne D_d764
D_d760: ; original $D760: lda #$20
 lda #$20
D_d762: ; original $D762: sta $ff
 sta $c0ff
D_d764: ; original $D764: lda $78
 lda $c078
D_d766: ; original $D766: cmp #$01
 cmp #$01
D_d768: ; original $D768: beq $d777
 jeq D_d777
D_d76a: ; original $D76A: lda $56
 lda $c056
D_d76c: ; original $D76C: sec
 sec
D_d76d: ; original $D76D: sbc #$40
 sbc #$40
D_d76f: ; original $D76F: sta $56
 sta $c056
D_d771: ; original $D771: lda $0210
 lda $c210
D_d774: ; original $D774: sbc #$00
 sbc #$00
D_d776: ; original $D776: rts
 rts
D_d777: ; original $D777: lda $0210
 lda $c210
D_d77a: ; original $D77A: clc
 clc
D_d77b: ; original $D77B: adc #$01
 adc #$01
D_d77d: ; original $D77D: rts
 rts
D_d77e: ; original $D77E: lda $78
 lda $c078
D_d780: ; original $D780: cmp #$02
 cmp #$02
D_d782: ; original $D782: bne $d78b
 jne D_d78b
D_d784: ; original $D784: sec
 sec
D_d785: ; original $D785: lda $0210
 lda $c210
D_d788: ; original $D788: sbc #$01
 sbc #$01
D_d78a: ; original $D78A: rts
 rts
D_d78b: ; original $D78B: clc
 clc
D_d78c: ; original $D78C: lda $56
 lda $c056
D_d78e: ; original $D78E: adc #$50
 adc #$50
D_d790: ; original $D790: sta $56
 sta $c056
D_d792: ; original $D792: lda $0210
 lda $c210
D_d795: ; original $D795: adc #$01
 adc #$01
D_d797: ; original $D797: ldx #$20
 ldx #$20
D_d799: ; original $D799: stx $ff
 stx $c0ff
D_d79b: ; original $D79B: rts
 rts
D_d79c: ; original $D79C: jsr $d7d3
 jsr D_d7d3
D_d79f: ; original $D79F: beq $d7a2
 jeq D_d7a2
D_d7a1: ; original $D7A1: rts
 rts
D_d7a2: ; original $D7A2: lda #$0b
 lda #$0b
D_d7a4: ; original $D7A4: ldx #$00
 ldx #$00
D_d7a6: ; original $D7A6: jsr $e98b
 jsr D_e98b
D_d7a9: ; original $D7A9: bne $d7ac
 jne D_d7ac
D_d7ab: ; original $D7AB: rts
 rts
D_d7ac: ; original $D7AC: lda $54
 lda $c054
D_d7ae: ; original $D7AE: cmp #$04
 cmp #$04
D_d7b0: ; original $D7B0: bne $d7bf
 jne D_d7bf
D_d7b2: ; original $D7B2: lda $6d
 lda $c06d
D_d7b4: ; original $D7B4: beq $d7bb
 jeq D_d7bb
D_d7b6: ; original $D7B6: lda #$00
 lda #$00
D_d7b8: ; original $D7B8: jmp $d7c9
 jmp D_d7c9
D_d7bb: ; original $D7BB: jsr $da76
 jsr D_da76
D_d7be: ; original $D7BE: rts
 rts
D_d7bf: ; original $D7BF: lda $6d
 lda $c06d
D_d7c1: ; original $D7C1: beq $d7c7
 jeq D_d7c7
D_d7c3: ; original $D7C3: jsr $da76
 jsr D_da76
D_d7c6: ; original $D7C6: rts
 rts
D_d7c7: ; original $D7C7: lda #$01
 lda #$01
D_d7c9: ; original $D7C9: sta $6d
 sta $c06d
D_d7cb: ; original $D7CB: jsr $da48
 jsr D_da48
D_d7ce: ; original $D7CE: lda #$20
 lda #$20
D_d7d0: ; original $D7D0: sta $ff
 sta $c0ff
D_d7d2: ; original $D7D2: rts
 rts
D_d7d3: ; original $D7D3: lda $3e
 lda $c03e
D_d7d5: ; original $D7D5: pha
 pha
D_d7d6: ; original $D7D6: lda $40
 lda $c040
D_d7d8: ; original $D7D8: pha
 pha
D_d7d9: ; original $D7D9: lda $54
 lda $c054
D_d7db: ; original $D7DB: cmp #$03
 cmp #$03
D_d7dd: ; original $D7DD: beq $d7e5
 jeq D_d7e5
D_d7df: ; original $D7DF: jsr $d7f8
 jsr D_d7f8
D_d7e2: ; original $D7E2: jmp $d7e8
 jmp D_d7e8
D_d7e5: ; original $D7E5: jsr $d810
 jsr D_d810
D_d7e8: ; original $D7E8: cmp #$00
 cmp #$00
D_d7ea: ; original $D7EA: bne $d7ef
 jne D_d7ef
D_d7ec: ; original $D7EC: jsr $e89b
 jsr DImport_e89b
D_d7ef: ; original $D7EF: pla
 pla
D_d7f0: ; original $D7F0: sta $40
 sta $c040
D_d7f2: ; original $D7F2: pla
 pla
D_d7f3: ; original $D7F3: sta $3e
 sta $c03e
D_d7f5: ; original $D7F5: lda $0f
 lda $c00f
D_d7f7: ; original $D7F7: rts
 rts
D_d7f8: ; original $D7F8: lda $40
 lda $c040
D_d7fa: ; original $D7FA: sec
 sec
D_d7fb: ; original $D7FB: sbc $3e
 sbc $c03e
D_d7fd: ; original $D7FD: clc
 clc
D_d7fe: ; original $D7FE: adc $40
 adc $c040
D_d800: ; original $D800: bcs $d80d
 jcs D_d80d
D_d802: ; original $D802: ldx $40
 ldx $c040
D_d804: ; original $D804: sta $40
 sta $c040
D_d806: ; original $D806: stx $3e
 stx $c03e
D_d808: ; original $D808: inc $41
 inc $c041
D_d80a: ; original $D80A: lda #$00
 lda #$00
D_d80c: ; original $D80C: rts
 rts
D_d80d: ; original $D80D: lda #$01
 lda #$01
D_d80f: ; original $D80F: rts
 rts
D_d810: ; original $D810: lda $40
 lda $c040
D_d812: ; original $D812: sec
 sec
D_d813: ; original $D813: sbc $3e
 sbc $c03e
D_d815: ; original $D815: sta $40
 sta $c040
D_d817: ; original $D817: lda $3e
 lda $c03e
D_d819: ; original $D819: sec
 sec
D_d81a: ; original $D81A: sbc $40
 sbc $c040
D_d81c: ; original $D81C: bcc $d829
 jcc D_d829
D_d81e: ; original $D81E: ldx $3e
 ldx $c03e
D_d820: ; original $D820: sta $3e
 sta $c03e
D_d822: ; original $D822: stx $40
 stx $c040
D_d824: ; original $D824: inc $41
 inc $c041
D_d826: ; original $D826: lda #$00
 lda #$00
D_d828: ; original $D828: rts
 rts
D_d829: ; original $D829: lda #$01
 lda #$01
D_d82b: ; original $D82B: rts
 rts
D_d82c: ; original $D82C: lda $54
 lda $c054
D_d82e: ; original $D82E: cmp #$02
 cmp #$02
D_d830: ; original $D830: bmi $d83e
 jmi D_d83e
D_d832: ; original $D832: lda #$0f
 lda #$0f
D_d834: ; original $D834: ldx #$00
 ldx #$00
D_d836: ; original $D836: jsr $e98b
 jsr D_e98b
D_d839: ; original $D839: beq $d83e
 jeq D_d83e
D_d83b: ; original $D83B: jsr $d83f
 jsr D_d83f
D_d83e: ; original $D83E: rts
 rts
D_d83f: ; original $D83F: lda $54
 lda $c054
D_d841: ; original $D841: cmp #$02
 cmp #$02
D_d843: ; original $D843: beq $d856
 jeq D_d856
D_d845: ; original $D845: cmp #$03
 cmp #$03
D_d847: ; original $D847: beq $d869
 jeq D_d869
D_d849: ; original $D849: lda #$01
 lda #$01
D_d84b: ; original $D84B: sta $6d
 sta $c06d
D_d84d: ; original $D84D: lda $72
 lda $c072
D_d84f: ; original $D84F: cmp #$01
 cmp #$01
D_d851: ; original $D851: beq $d87a
 jeq D_d87a
D_d853: ; original $D853: jmp $d876
 jmp D_d876
D_d856: ; original $D856: lda $72
 lda $c072
D_d858: ; original $D858: cmp #$01
 cmp #$01
D_d85a: ; original $D85A: beq $d861
 jeq D_d861
D_d85c: ; original $D85C: lda #$00
 lda #$00
D_d85e: ; original $D85E: jmp $d863
 jmp D_d863
D_d861: ; original $D861: lda #$01
 lda #$01
D_d863: ; original $D863: sta $6d
 sta $c06d
D_d865: ; original $D865: jsr $da48
 jsr D_da48
D_d868: ; original $D868: rts
 rts
D_d869: ; original $D869: lda #$00
 lda #$00
D_d86b: ; original $D86B: sta $6d
 sta $c06d
D_d86d: ; original $D86D: lda $72
 lda $c072
D_d86f: ; original $D86F: cmp #$01
 cmp #$01
D_d871: ; original $D871: beq $d876
 jeq D_d876
D_d873: ; original $D873: jmp $d87a
 jmp D_d87a
D_d876: ; original $D876: jsr $dad7
 jsr D_dad7
D_d879: ; original $D879: rts
 rts
D_d87a: ; original $D87A: jsr $da48
 jsr D_da48
D_d87d: ; original $D87D: rts
 rts
D_d87e: ; original $D87E: lda $54
 lda $c054
D_d880: ; original $D880: bne $d883
 jne D_d883
D_d882: ; original $D882: rts
 rts
D_d883: ; original $D883: cmp #$03
 cmp #$03
D_d885: ; original $D885: bpl $d88b
 jpl D_d88b
D_d887: ; original $D887: jsr $d8a3
 jsr D_d8a3
D_d88a: ; original $D88A: rts
 rts
D_d88b: ; original $D88B: lda #$0b
 lda #$0b
D_d88d: ; original $D88D: ldx #$00
 ldx #$00
D_d88f: ; original $D88F: jsr $e98b
 jsr D_e98b
D_d892: ; original $D892: beq $d8a2
 jeq D_d8a2
D_d894: ; original $D894: lda $54
 lda $c054
D_d896: ; original $D896: sec
 sec
D_d897: ; original $D897: sbc #$03
 sbc #$03
D_d899: ; original $D899: sta $6d
 sta $c06d
D_d89b: ; original $D89B: jsr $da48
 jsr D_da48
D_d89e: ; original $D89E: lda #$20
 lda #$20
D_d8a0: ; original $D8A0: sta $ff
 sta $c0ff
D_d8a2: ; original $D8A2: rts
 rts
D_d8a3: ; original $D8A3: lda $0213
 lda $c213
D_d8a6: ; original $D8A6: sta $00
 sta $c000
D_d8a8: ; original $D8A8: lda #$38
 lda #$38
D_d8aa: ; original $D8AA: sta $02
 sta $c002
D_d8ac: ; original $D8AC: lda $54
 lda $c054
D_d8ae: ; original $D8AE: cmp #$01
 cmp #$01
D_d8b0: ; original $D8B0: beq $d8b8
 jeq D_d8b8
D_d8b2: ; original $D8B2: jsr $d8ef
 jsr D_d8ef
D_d8b5: ; original $D8B5: jmp $d8bb
 jmp D_d8bb
D_d8b8: ; original $D8B8: jsr $d8cb
 jsr D_d8cb
D_d8bb: ; original $D8BB: sta $01
 sta $c001
D_d8bd: ; original $D8BD: lda $01
 lda $c001
D_d8bf: ; original $D8BF: and #$04
 and #$04
D_d8c1: ; original $D8C1: lsr a
 lsr a
D_d8c2: ; original $D8C2: lsr a
 lsr a
D_d8c3: ; original $D8C3: jsr $e9ee
 jsr D_e9ee
D_d8c6: ; original $D8C6: lda #$02
 lda #$02
D_d8c8: ; original $D8C8: sta $71
 sta $c071
D_d8ca: ; original $D8CA: rts
 rts
D_d8cb: ; original $D8CB: lda $ea
 lda $c0ea
D_d8cd: ; original $D8CD: and #$08
 and #$08
D_d8cf: ; original $D8CF: bne $d8d5
 jne D_d8d5
D_d8d1: ; original $D8D1: lda #$20
 lda #$20
D_d8d3: ; original $D8D3: sta $ff
 sta $c0ff
D_d8d5: ; original $D8D5: lda $78
 lda $c078
D_d8d7: ; original $D8D7: cmp #$01
 cmp #$01
D_d8d9: ; original $D8D9: beq $d8e8
 jeq D_d8e8
D_d8db: ; original $D8DB: lda $56
 lda $c056
D_d8dd: ; original $D8DD: sec
 sec
D_d8de: ; original $D8DE: sbc #$a0
 sbc #$a0
D_d8e0: ; original $D8E0: sta $56
 sta $c056
D_d8e2: ; original $D8E2: lda $0210
 lda $c210
D_d8e5: ; original $D8E5: sbc #$00
 sbc #$00
D_d8e7: ; original $D8E7: rts
 rts
D_d8e8: ; original $D8E8: lda $0210
 lda $c210
D_d8eb: ; original $D8EB: clc
 clc
D_d8ec: ; original $D8EC: adc #$01
 adc #$01
D_d8ee: ; original $D8EE: rts
 rts
D_d8ef: ; original $D8EF: lda $78
 lda $c078
D_d8f1: ; original $D8F1: cmp #$02
 cmp #$02
D_d8f3: ; original $D8F3: bne $d8fc
 jne D_d8fc
D_d8f5: ; original $D8F5: lda $0210
 lda $c210
D_d8f8: ; original $D8F8: sec
 sec
D_d8f9: ; original $D8F9: sbc #$01
 sbc #$01
D_d8fb: ; original $D8FB: rts
 rts
D_d8fc: ; original $D8FC: lda $ea
 lda $c0ea
D_d8fe: ; original $D8FE: and #$09
 and #$09
D_d900: ; original $D900: bne $d906
 jne D_d906
D_d902: ; original $D902: lda #$20
 lda #$20
D_d904: ; original $D904: sta $ff
 sta $c0ff
D_d906: ; original $D906: lda $56
 lda $c056
D_d908: ; original $D908: clc
 clc
D_d909: ; original $D909: adc #$90
 adc #$90
D_d90b: ; original $D90B: sta $56
 sta $c056
D_d90d: ; original $D90D: lda $0210
 lda $c210
D_d910: ; original $D910: adc #$00
 adc #$00
D_d912: ; original $D912: rts
 rts
D_d913: ; original $D913: lda $0210
 lda $c210
D_d916: ; original $D916: sta $01
 sta $c001
D_d918: ; original $D918: lda #$00
 lda #$00
D_d91a: ; original $D91A: jsr $e9ae
 jsr D_e9ae
D_d91d: ; original $D91D: lda $54
 lda $c054
D_d91f: ; original $D91F: cmp #$03
 cmp #$03
D_d921: ; original $D921: bpl $d929
 jpl D_d929
D_d923: ; original $D923: lda $0213
 lda $c213
D_d926: ; original $D926: jmp $d947
 jmp D_d947
D_d929: ; original $D929: clc
 clc
D_d92a: ; original $D92A: lda $56
 lda $c056
D_d92c: ; original $D92C: adc $7c
 adc $c07c
D_d92e: ; original $D92E: sta $56
 sta $c056
D_d930: ; original $D930: lda #$00
 lda #$00
D_d932: ; original $D932: rol a
 rol a
D_d933: ; original $D933: sta $00
 sta $c000
D_d935: ; original $D935: lda $0213
 lda $c213
D_d938: ; original $D938: ldx $54
 ldx $c054
D_d93a: ; original $D93A: cpx #$03
 cpx #$03
D_d93c: ; original $D93C: beq $d944
 jeq D_d944
D_d93e: ; original $D93E: clc
 clc
D_d93f: ; original $D93F: adc $00
 adc $c000
D_d941: ; original $D941: jmp $d947
 jmp D_d947
D_d944: ; original $D944: sec
 sec
D_d945: ; original $D945: sbc $00
 sbc $c000
D_d947: ; original $D947: sta $00
 sta $c000
D_d949: ; original $D949: lda #$18
 lda #$18
D_d94b: ; original $D94B: sta $02
 sta $c002
D_d94d: ; original $D94D: lda $6d
 lda $c06d
D_d94f: ; original $D94F: eor #$01
 eor #$01
D_d951: ; original $D951: jsr $e9ee
 jsr D_e9ee
D_d954: ; original $D954: rts
 rts
D_d955: ; original $D955: lda $0591
 lda $c591
D_d958: ; original $D958: bne $d95e
 jne D_d95e
D_d95a: ; original $D95A: lda $8c
 lda $c08c
D_d95c: ; original $D95C: beq $d95f
 jeq D_d95f
D_d95e: ; original $D95E: rts
 rts
D_d95f: ; original $D95F: lda #$e1
 lda #<DData_c2e1
D_d961: ; original $D961: sta $02
 sta $c002
D_d963: ; original $D963: lda #$c2
 lda #>DData_c2e1
D_d965: ; original $D965: sta $03
 sta $c003
D_d967: ; original $D967: lda #$00
 lda #$00
D_d969: ; original $D969: sta $8c
 sta $c08c
D_d96b: ; original $D96B: ldx #$00
 ldx #$00
D_d96d: ; original $D96D: ldy #$01
 ldy #$01
D_d96f: ; original $D96F: lda $9a,x
 lda $c09a,x
D_d971: ; original $D971: beq $d986
 jeq D_d986
D_d973: ; original $D973: lda ($91),y
 php
 pha
 lda $c091
 sta DIndirect_d973+1
 lda $c092
 cmp #8
 bcs DIndirect_d973_rom
 ora #$c0
DIndirect_d973_rom:
 sta DIndirect_d973+2
 pla
 plp
DIndirect_d973: lda $ffff,y
D_d975: ; original $D975: sta $00
 sta $c000
D_d977: ; original $D977: iny
 iny
D_d978: ; original $D978: lda ($91),y
 php
 pha
 lda $c091
 sta DIndirect_d978+1
 lda $c092
 cmp #8
 bcs DIndirect_d978_rom
 ora #$c0
DIndirect_d978_rom:
 sta DIndirect_d978+2
 pla
 plp
DIndirect_d978: lda $ffff,y
D_d97a: ; original $D97A: sta $01
 sta $c001
D_d97c: ; original $D97C: jsr $eb6e
 jsr D_eb6e
D_d97f: ; original $D97F: cmp #$00
 cmp #$00
D_d981: ; original $D981: bne $d992
 jne D_d992
D_d983: ; original $D983: jmp $d987
 jmp D_d987
D_d986: ; original $D986: iny
 iny
D_d987: ; original $D987: inx
 inx
D_d988: ; original $D988: tya
 tya
D_d989: ; original $D989: clc
 clc
D_d98a: ; original $D98A: adc #$06
 adc #$06
D_d98c: ; original $D98C: tay
 tay
D_d98d: ; original $D98D: cpy $93
 cpy $c093
D_d98f: ; original $D98F: bcc $d96f
 jcc D_d96f
D_d991: ; original $D991: rts
 rts
D_d992: ; original $D992: lda #$02
 lda #$02
D_d994: ; original $D994: sta $fe
 sta $c0fe
D_d996: ; original $D996: lda #$ff
 lda #$ff
D_d998: ; original $D998: sta $0200
 sta $c200
D_d99b: ; original $D99B: lda $8d,x
 lda $c08d,x
D_d99d: ; original $D99D: sta $02
 sta $c002
D_d99f: ; original $D99F: lda #$04
 lda #$04
D_d9a1: ; original $D9A1: sta $03
 sta $c003
D_d9a3: ; original $D9A3: lda #$30
 lda #$30
D_d9a5: ; original $D9A5: sta $04
 sta $c004
D_d9a7: ; original $D9A7: jsr $ea06
 jsr D_ea06
D_d9aa: ; original $D9AA: lda #$00
 lda #$00
D_d9ac: ; original $D9AC: sta $9a,x
 sta $c09a,x
D_d9ae: ; original $D9AE: txa
 txa
D_d9af: ; original $D9AF: pha
 pha
D_d9b0: ; original $D9B0: inx
 inx
D_d9b1: ; original $D9B1: stx $8c
 stx $c08c
D_d9b3: ; original $D9B3: stx $9e
 stx $c09e
D_d9b5: ; original $D9B5: iny
 iny
D_d9b6: ; original $D9B6: lda ($91),y
 php
 pha
 lda $c091
 sta DIndirect_d9b6+1
 lda $c092
 cmp #8
 bcs DIndirect_d9b6_rom
 ora #$c0
DIndirect_d9b6_rom:
 sta DIndirect_d9b6+2
 pla
 plp
DIndirect_d9b6: lda $ffff,y
D_d9b8: ; original $D9B8: sta $02
 sta $c002
D_d9ba: ; original $D9BA: lda #$22
 lda #$22
D_d9bc: ; original $D9BC: sta $95
 sta $c095
D_d9be: ; original $D9BE: sta $03
 sta $c003
D_d9c0: ; original $D9C0: dex
 dex
D_d9c1: ; original $D9C1: jsr $e9fc
 jsr D_e9fc
D_d9c4: ; original $D9C4: ldx #$02
 ldx #$02
D_d9c6: ; original $D9C6: iny
 iny
D_d9c7: ; original $D9C7: lda ($91),y
 php
 pha
 lda $c091
 sta DIndirect_d9c7+1
 lda $c092
 cmp #8
 bcs DIndirect_d9c7_rom
 ora #$c0
DIndirect_d9c7_rom:
 sta DIndirect_d9c7+2
 pla
 plp
DIndirect_d9c7: lda $ffff,y
D_d9c9: ; original $D9C9: sta $94,x
 sta $c094,x
D_d9cb: ; original $D9CB: inx
 inx
D_d9cc: ; original $D9CC: cpx #$06
 cpx #$06
D_d9ce: ; original $D9CE: bne $d9c6
 jne D_d9c6
D_d9d0: ; original $D9D0: pla
 pla
D_d9d1: ; original $D9D1: asl a
 asl a
D_d9d2: ; original $D9D2: sta $01
 sta $c001
D_d9d4: ; original $D9D4: ldx $4a
 ldx $c04a
D_d9d6: ; original $D9D6: dex
 dex
D_d9d7: ; original $D9D7: txa
 txa
D_d9d8: ; original $D9D8: asl a
 asl a
D_d9d9: ; original $D9D9: sta $09
 sta $c009
D_d9db: ; original $D9DB: asl a
 asl a
D_d9dc: ; original $D9DC: asl a
 asl a
D_d9dd: ; original $D9DD: clc
 clc
D_d9de: ; original $D9DE: adc $01
 adc $c001
D_d9e0: ; original $D9E0: tax
 tax
D_d9e1: ; original $D9E1: lda $c2ed,x
 lda DData_c2ed,x
D_d9e4: ; original $D9E4: sta $00
 sta $c000
D_d9e6: ; original $D9E6: lda $c2ee,x
 lda DData_c2ee,x
D_d9e9: ; original $D9E9: sta $01
 sta $c001
D_d9eb: ; original $D9EB: lda #$95
 lda #$95
D_d9ed: ; original $D9ED: sta $02
 sta $c002
D_d9ef: ; original $D9EF: lda #$00
 lda #$00
D_d9f1: ; original $D9F1: sta $03
 sta $c003
D_d9f3: ; original $D9F3: jsr $efce
 jsr DImport_efce
D_d9f6: ; original $D9F6: ldx $8c
 ldx $c08c
D_d9f8: ; original $D9F8: cpx #$03
 cpx #$03
D_d9fa: ; original $D9FA: bpl $da10
 jpl D_da10
D_d9fc: ; original $D9FC: dex
 dex
D_d9fd: ; original $D9FD: txa
 txa
D_d9fe: ; original $D9FE: clc
 clc
D_d9ff: ; original $D9FF: adc $09
 adc $c009
D_da01: ; original $DA01: tax
 tax
D_da02: ; original $DA02: lda $c2e5,x
 lda DData_c2e5,x
D_da05: ; original $DA05: sta $00
 sta $c000
D_da07: ; original $DA07: ldy #$00
 ldy #$00
D_da09: ; original $DA09: lda #$23
 lda #$23
D_da0b: ; original $DA0B: sta $01
 sta $c001
D_da0d: ; original $DA0D: jsr $f1c5
 jsr DImport_f1c5
D_da10: ; original $DA10: jsr $ed7b
 jsr DImport_ed7b
D_da13: ; original $DA13: rts
 rts
D_da14: ; original $DA14: jsr $e89b
 jsr DImport_e89b
D_da17: ; original $DA17: cmp #$00
 cmp #$00
D_da19: ; original $DA19: beq $da1f
 jeq D_da1f
D_da1b: ; original $DA1B: lda $55
 lda $c055
D_da1d: ; original $DA1D: sta $54
 sta $c054
D_da1f: ; original $DA1F: sta $78
 sta $c078
D_da21: ; original $DA21: rts
 rts
D_da22: ; original $DA22: jsr $da34
 jsr D_da34
D_da25: ; original $DA25: bne $da2f
 jne D_da2f
D_da27: ; original $DA27: jsr $daa5
 jsr D_daa5
D_da2a: ; original $DA2A: lda #$01
 lda #$01
D_da2c: ; original $DA2C: jmp $da31
 jmp D_da31
D_da2f: ; original $DA2F: lda #$05
 lda #$05
D_da31: ; original $DA31: sta $6b
 sta $c06b
D_da33: ; original $DA33: rts
 rts
D_da34: ; original $DA34: lda $0210
 lda $c210
D_da37: ; original $DA37: cmp $76
 cmp $c076
D_da39: ; original $DA39: bcc $da42
 jcc D_da42
D_da3b: ; original $DA3B: sec
 sec
D_da3c: ; original $DA3C: sbc $76
 sbc $c076
D_da3e: ; original $DA3E: cmp $7b
 cmp $c07b
D_da40: ; original $DA40: bcs $da45
 jcs D_da45
D_da42: ; original $DA42: lda #$00
 lda #$00
D_da44: ; original $DA44: rts
 rts
D_da45: ; original $DA45: lda #$01
 lda #$01
D_da47: ; original $DA47: rts
 rts
D_da48: ; original $DA48: lda $0210
 lda $c210
D_da4b: ; original $DA4B: sta $01
 sta $c001
D_da4d: ; original $DA4D: lda $0213
 lda $c213
D_da50: ; original $DA50: ldx $71
 ldx $c071
D_da52: ; original $DA52: cpx #$02
 cpx #$02
D_da54: ; original $DA54: bne $da64
 jne D_da64
D_da56: ; original $DA56: ldx $6d
 ldx $c06d
D_da58: ; original $DA58: beq $da5f
 jeq D_da5f
D_da5a: ; original $DA5A: lda $73
 lda $c073
D_da5c: ; original $DA5C: jmp $da61
 jmp D_da61
D_da5f: ; original $DA5F: lda $74
 lda $c074
D_da61: ; original $DA61: sec
 sec
D_da62: ; original $DA62: sbc #$10
 sbc #$10
D_da64: ; original $DA64: sta $00
 sta $c000
D_da66: ; original $DA66: lda #$28
 lda #$28
D_da68: ; original $DA68: sta $02
 sta $c002
D_da6a: ; original $DA6A: lda $6d
 lda $c06d
D_da6c: ; original $DA6C: eor #$01
 eor #$01
D_da6e: ; original $DA6E: jsr $e9ee
 jsr D_e9ee
D_da71: ; original $DA71: lda #$01
 lda #$01
D_da73: ; original $DA73: sta $71
 sta $c071
D_da75: ; original $DA75: rts
 rts
D_da76: ; original $DA76: txa
 txa
D_da77: ; original $DA77: pha
 pha
D_da78: ; original $DA78: lda $0210
 lda $c210
D_da7b: ; original $DA7B: sta $01
 sta $c001
D_da7d: ; original $DA7D: lda $0213
 lda $c213
D_da80: ; original $DA80: ldx $6d
 ldx $c06d
D_da82: ; original $DA82: beq $da8c
 jeq D_da8c
D_da84: ; original $DA84: sec
 sec
D_da85: ; original $DA85: sbc #$0c
 sbc #$0c
D_da87: ; original $DA87: sta $00
 sta $c000
D_da89: ; original $DA89: jmp $da91
 jmp D_da91
D_da8c: ; original $DA8C: clc
 clc
D_da8d: ; original $DA8D: adc #$0c
 adc #$0c
D_da8f: ; original $DA8F: sta $00
 sta $c000
D_da91: ; original $DA91: lda #$38
 lda #$38
D_da93: ; original $DA93: sta $02
 sta $c002
D_da95: ; original $DA95: lda $6d
 lda $c06d
D_da97: ; original $DA97: eor #$01
 eor #$01
D_da99: ; original $DA99: jsr $e9ee
 jsr D_e9ee
D_da9c: ; original $DA9C: lda #$02
 lda #$02
D_da9e: ; original $DA9E: sta $71
 sta $c071
D_daa0: ; original $DAA0: sta $6b
 sta $c06b
D_daa2: ; original $DAA2: pla
 pla
D_daa3: ; original $DAA3: tax
 tax
D_daa4: ; original $DAA4: rts
 rts
D_daa5: ; original $DAA5: lda $43
 lda $c043
D_daa7: ; original $DAA7: sec
 sec
D_daa8: ; original $DAA8: sbc #$11
 sbc #$11
D_daaa: ; original $DAAA: sta $01
 sta $c001
D_daac: ; original $DAAC: lda $0213
 lda $c213
D_daaf: ; original $DAAF: sta $00
 sta $c000
D_dab1: ; original $DAB1: lda #$20
 lda #$20
D_dab3: ; original $DAB3: sta $02
 sta $c002
D_dab5: ; original $DAB5: sta $63
 sta $c063
D_dab7: ; original $DAB7: lda $6d
 lda $c06d
D_dab9: ; original $DAB9: eor #$01
 eor #$01
D_dabb: ; original $DABB: jsr $e9ee
 jsr D_e9ee
D_dabe: ; original $DABE: lda #$60
 lda #$60
D_dac0: ; original $DAC0: sta $86
 sta $c086
D_dac2: ; original $DAC2: lda #$01
 lda #$01
D_dac4: ; original $DAC4: sta $87
 sta $c087
D_dac6: ; original $DAC6: lda #$02
 lda #$02
D_dac8: ; original $DAC8: sta $7a
 sta $c07a
D_daca: ; original $DACA: lda #$18
 lda #$18
D_dacc: ; original $DACC: sta $7b
 sta $c07b
D_dace: ; original $DACE: lda #$a0
 lda #$a0
D_dad0: ; original $DAD0: sta $7c
 sta $c07c
D_dad2: ; original $DAD2: lda #$10
 lda #$10
D_dad4: ; original $DAD4: sta $ff
 sta $c0ff
D_dad6: ; original $DAD6: rts
 rts
D_dad7: ; original $DAD7: lda $0210
 lda $c210
D_dada: ; original $DADA: sta $01
 sta $c001
D_dadc: ; original $DADC: sta $76
 sta $c076
D_dade: ; original $DADE: lda $0213
 lda $c213
D_dae1: ; original $DAE1: sta $00
 sta $c000
D_dae3: ; original $DAE3: lda #$18
 lda #$18
D_dae5: ; original $DAE5: sta $02
 sta $c002
D_dae7: ; original $DAE7: lda $6d
 lda $c06d
D_dae9: ; original $DAE9: eor #$01
 eor #$01
D_daeb: ; original $DAEB: jsr $e9ee
 jsr D_e9ee
D_daee: ; original $DAEE: lda #$00
 lda #$00
D_daf0: ; original $DAF0: sta $71
 sta $c071
D_daf2: ; original $DAF2: lda #$04
 lda #$04
D_daf4: ; original $DAF4: sta $6b
 sta $c06b
D_daf6: ; original $DAF6: rts
 rts
D_daf7: ; original $DAF7: lda $0210
 lda $c210
D_dafa: ; original $DAFA: cmp #$d8
 cmp #$d8
D_dafc: ; original $DAFC: bcs $db18
 jcs D_db18
D_dafe: ; original $DAFE: clc
 clc
D_daff: ; original $DAFF: adc #$02
 adc #$02
D_db01: ; original $DB01: sta $01
 sta $c001
D_db03: ; original $DB03: lda $09
 lda $c009
D_db05: ; original $DB05: sta $ff
 sta $c0ff
D_db07: ; original $DB07: lda $0213
 lda $c213
D_db0a: ; original $DB0A: sta $00
 sta $c000
D_db0c: ; original $DB0C: lda #$40
 lda #$40
D_db0e: ; original $DB0E: sta $02
 sta $c002
D_db10: ; original $DB10: lda #$00
 lda #$00
D_db12: ; original $DB12: sta $09
 sta $c009
D_db14: ; original $DB14: jsr $e9ee
 jsr D_e9ee
D_db17: ; original $DB17: rts
 rts
D_db18: ; original $DB18: lda $08
 lda $c008
D_db1a: ; original $DB1A: sta $ff
 sta $c0ff
D_db1c: ; original $DB1C: jsr $cf62
 jsr DImport_cf62
D_db1f: ; original $DB1F: rts
 rts
D_db20: ; original $DB20: lda $65
 lda $c065
D_db22: ; original $DB22: cmp #$24
 cmp #$24
D_db24: ; original $DB24: bne $db2a
 jne D_db2a
D_db26: ; original $DB26: lda #$02
 lda #$02
D_db28: ; original $DB28: sta $ff
 sta $c0ff
D_db2a: ; original $DB2A: lda $0210
 lda $c210
D_db2d: ; original $DB2D: sta $01
 sta $c001
D_db2f: ; original $DB2F: lda $0213
 lda $c213
D_db32: ; original $DB32: sta $00
 sta $c000
D_db34: ; original $DB34: ldx #$40
 ldx #$40
D_db36: ; original $DB36: lda $65
 lda $c065
D_db38: ; original $DB38: and #$02
 and #$02
D_db3a: ; original $DB3A: bne $db3e
 jne D_db3e
D_db3c: ; original $DB3C: ldx #$48
 ldx #$48
D_db3e: ; original $DB3E: stx $02
 stx $c002
D_db40: ; original $DB40: lda #$00
 lda #$00
D_db42: ; original $DB42: jsr $e9ee
 jsr D_e9ee
D_db45: ; original $DB45: lda #$20
 lda #$20
D_db47: ; original $DB47: sta $39
 sta $c039
D_db49: ; original $DB49: lda $0210
 lda $c210
D_db4c: ; original $DB4C: cmp #$d8
 cmp #$d8
D_db4e: ; original $DB4E: bcs $db55
 jcs D_db55
D_db50: ; original $DB50: lda #$10
 lda #$10
D_db52: ; original $DB52: jmp $db57
 jmp D_db57
D_db55: ; original $DB55: lda #$00
 lda #$00
D_db57: ; original $DB57: sta $08
 sta $c008
D_db59: ; original $DB59: rts
 rts
D_dbb3: ; original $DBB3: ldx $8c
 ldx $c08c
D_dbb5: ; original $DBB5: beq $dbe8
 jeq D_dbe8
D_dbb7: ; original $DBB7: lda #$30
 lda #$30
D_dbb9: ; original $DBB9: sta $04
 sta $c004
D_dbbb: ; original $DBBB: lda $0230
 lda $c230
D_dbbe: ; original $DBBE: cmp #$d8
 cmp #$d8
D_dbc0: ; original $DBC0: bcs $dbcd
 jcs D_dbcd
D_dbc2: ; original $DBC2: clc
 clc
D_dbc3: ; original $DBC3: adc #$02
 adc #$02
D_dbc5: ; original $DBC5: sta $01
 sta $c001
D_dbc7: ; original $DBC7: lda #$00
 lda #$00
D_dbc9: ; original $DBC9: pha
 pha
D_dbca: ; original $DBCA: jmp $dbd6
 jmp D_dbd6
D_dbcd: ; original $DBCD: lda #$00
 lda #$00
D_dbcf: ; original $DBCF: sta $8c
 sta $c08c
D_dbd1: ; original $DBD1: lda #$ff
 lda #$ff
D_dbd3: ; original $DBD3: sta $01
 sta $c001
D_dbd5: ; original $DBD5: pha
 pha
D_dbd6: ; original $DBD6: lda $0231
 lda $c231
D_dbd9: ; original $DBD9: sta $02
 sta $c002
D_dbdb: ; original $DBDB: lda #$22
 lda #$22
D_dbdd: ; original $DBDD: sta $03
 sta $c003
D_dbdf: ; original $DBDF: lda $0233
 lda $c233
D_dbe2: ; original $DBE2: sta $00
 sta $c000
D_dbe4: ; original $DBE4: pla
 pla
D_dbe5: ; original $DBE5: jsr $ea08
 jsr D_ea08
D_dbe8: ; original $DBE8: rts
 rts
D_e98b: ; original $E98B: sta $05e0
 sta $c5e0
D_e98e: ; original $E98E: lda $55
 lda $c055
D_e990: ; original $E990: cmp $54
 cmp $c054
D_e992: ; original $E992: bne $e9a2
 jne D_e9a2
D_e994: ; original $E994: dec $05e1,x
 dec $c5e1,x
D_e997: ; original $E997: lda $05e1,x
 lda $c5e1,x
D_e99a: ; original $E99A: cmp #$ff
 cmp #$ff
D_e99c: ; original $E99C: beq $e9a2
 jeq D_e9a2
D_e99e: ; original $E99E: cmp #$00
 cmp #$00
D_e9a0: ; original $E9A0: bne $e9ab
 jne D_e9ab
D_e9a2: ; original $E9A2: lda $05e0
 lda $c5e0
D_e9a5: ; original $E9A5: sta $05e1,x
 sta $c5e1,x
D_e9a8: ; original $E9A8: lda #$01
 lda #$01
D_e9aa: ; original $E9AA: rts
 rts
D_e9ab: ; original $E9AB: lda #$00
 lda #$00
D_e9ad: ; original $E9AD: rts
 rts
D_e9ae: ; original $E9AE: stx $0f
 stx $c00f
D_e9b0: ; original $E9B0: asl a
 asl a
D_e9b1: ; original $E9B1: tax
 tax
D_e9b2: ; original $E9B2: lda $7e,x
 lda $c07e,x
D_e9b4: ; original $E9B4: bne $e9c3
 jne D_e9c3
D_e9b6: ; original $E9B6: sta $83,x
 sta $c083,x
D_e9b8: ; original $E9B8: lda #$08
 lda #$08
D_e9ba: ; original $E9BA: sta $82,x
 sta $c082,x
D_e9bc: ; original $E9BC: lda #$f0
 lda #$f0
D_e9be: ; original $E9BE: sta $7f,x
 sta $c07f,x
D_e9c0: ; original $E9C0: jmp $e9cf
 jmp D_e9cf
D_e9c3: ; original $E9C3: lda $82,x
 lda $c082,x
D_e9c5: ; original $E9C5: adc #$10
 adc #$10
D_e9c7: ; original $E9C7: sta $82,x
 sta $c082,x
D_e9c9: ; original $E9C9: lda $83,x
 lda $c083,x
D_e9cb: ; original $E9CB: adc #$00
 adc #$00
D_e9cd: ; original $E9CD: sta $83,x
 sta $c083,x
D_e9cf: ; original $E9CF: lda $7f,x
 lda $c07f,x
D_e9d1: ; original $E9D1: sec
 sec
D_e9d2: ; original $E9D2: sbc $86,x
 sbc $c086,x
D_e9d4: ; original $E9D4: sta $7f,x
 sta $c07f,x
D_e9d6: ; original $E9D6: lda $01
 lda $c001
D_e9d8: ; original $E9D8: sbc $87,x
 sbc $c087,x
D_e9da: ; original $E9DA: sta $01
 sta $c001
D_e9dc: ; original $E9DC: clc
 clc
D_e9dd: ; original $E9DD: lda $7f,x
 lda $c07f,x
D_e9df: ; original $E9DF: adc $82,x
 adc $c082,x
D_e9e1: ; original $E9E1: sta $7f,x
 sta $c07f,x
D_e9e3: ; original $E9E3: lda $01
 lda $c001
D_e9e5: ; original $E9E5: adc $83,x
 adc $c083,x
D_e9e7: ; original $E9E7: sta $01
 sta $c001
D_e9e9: ; original $E9E9: inc $7e,x
 inc $c07e,x
D_e9eb: ; original $E9EB: ldx $0f
 ldx $c00f
D_e9ed: ; original $E9ED: rts
 rts
D_e9ee: ; original $E9EE: pha
 pha
D_e9ef: ; original $E9EF: lda #$24
 lda #$24
D_e9f1: ; original $E9F1: sta $03
 sta $c003
D_e9f3: ; original $E9F3: lda #$10
 lda #$10
D_e9f5: ; original $E9F5: sta $04
 sta $c004
D_e9f7: ; original $E9F7: pla
 pla
D_e9f8: ; original $E9F8: jsr $ea08
 jsr D_ea08
D_e9fb: ; original $E9FB: rts
 rts
D_e9fc: ; original $E9FC: lda #$00
 lda #$00
D_e9fe: ; original $E9FE: jmp $ea08
 jmp D_ea08
D_ea01: ; original $EA01: lda #$01
 lda #$01
D_ea03: ; original $EA03: jmp $ea08
 jmp D_ea08
D_ea06: ; original $EA06: lda #$04
 lda #$04
D_ea08: ; original $EA08: pha
 pha
D_ea09: ; original $EA09: sta $0f
 sta $c00f
D_ea0b: ; original $EA0B: txa
 txa
D_ea0c: ; original $EA0C: pha
 pha
D_ea0d: ; original $EA0D: tya
 tya
D_ea0e: ; original $EA0E: pha
 pha
D_ea0f: ; original $EA0F: lda $00
 lda $c000
D_ea11: ; original $EA11: pha
 pha
D_ea12: ; original $EA12: lda $01
 lda $c001
D_ea14: ; original $EA14: pha
 pha
D_ea15: ; original $EA15: lda $05
 lda $c005
D_ea17: ; original $EA17: pha
 pha
D_ea18: ; original $EA18: lda $06
 lda $c006
D_ea1a: ; original $EA1A: pha
 pha
D_ea1b: ; original $EA1B: lda $07
 lda $c007
D_ea1d: ; original $EA1D: pha
 pha
D_ea1e: ; original $EA1E: lda $08
 lda $c008
D_ea20: ; original $EA20: pha
 pha
D_ea21: ; original $EA21: lda $09
 lda $c009
D_ea23: ; original $EA23: pha
 pha
D_ea24: ; original $EA24: lda #$02
 lda #$02
D_ea26: ; original $EA26: sta $05
 sta $c005
D_ea28: ; original $EA28: lda $0f
 lda $c00f
D_ea2a: ; original $EA2A: cmp #$04
 cmp #$04
D_ea2c: ; original $EA2C: beq $ea71
 jeq D_ea71
D_ea2e: ; original $EA2E: lda #$0f
 lda #$0f
D_ea30: ; original $EA30: and $03
 and $c003
D_ea32: ; original $EA32: sta $07
 sta $c007
D_ea34: ; original $EA34: lda $03
 lda $c003
D_ea36: ; original $EA36: lsr a
 lsr a
D_ea37: ; original $EA37: lsr a
 lsr a
D_ea38: ; original $EA38: lsr a
 lsr a
D_ea39: ; original $EA39: lsr a
 lsr a
D_ea3a: ; original $EA3A: sta $06
 sta $c006
D_ea3c: ; original $EA3C: tax
 tax
D_ea3d: ; original $EA3D: lda #$00
 lda #$00
D_ea3f: ; original $EA3F: clc
 clc
D_ea40: ; original $EA40: adc $07
 adc $c007
D_ea42: ; original $EA42: dex
 dex
D_ea43: ; original $EA43: bne $ea40
 jne D_ea40
D_ea45: ; original $EA45: sta $08
 sta $c008
D_ea47: ; original $EA47: lda $0f
 lda $c00f
D_ea49: ; original $EA49: bne $ea51
 jne D_ea51
D_ea4b: ; original $EA4B: jsr $ea9f
 jsr D_ea9f
D_ea4e: ; original $EA4E: jmp $ea6b
 jmp D_ea6b
D_ea51: ; original $EA51: cmp #$01
 cmp #$01
D_ea53: ; original $EA53: beq $ea5f
 jeq D_ea5f
D_ea55: ; original $EA55: cmp #$02
 cmp #$02
D_ea57: ; original $EA57: beq $ea65
 jeq D_ea65
D_ea59: ; original $EA59: jsr $eb4a
 jsr D_eb4a
D_ea5c: ; original $EA5C: jmp $ea74
 jmp D_ea74
D_ea5f: ; original $EA5F: jsr $eae0
 jsr D_eae0
D_ea62: ; original $EA62: jmp $ea6b
 jmp D_ea6b
D_ea65: ; original $EA65: jsr $eb14
 jsr D_eb14
D_ea68: ; original $EA68: jmp $ea6b
 jmp D_ea6b
D_ea6b: ; original $EA6B: jsr $eaba
 jsr D_eaba
D_ea6e: ; original $EA6E: jmp $ea74
 jmp D_ea74
D_ea71: ; original $EA71: jsr $ea8f
 jsr D_ea8f
D_ea74: ; original $EA74: pla
 pla
D_ea75: ; original $EA75: sta $09
 sta $c009
D_ea77: ; original $EA77: pla
 pla
D_ea78: ; original $EA78: sta $08
 sta $c008
D_ea7a: ; original $EA7A: pla
 pla
D_ea7b: ; original $EA7B: sta $07
 sta $c007
D_ea7d: ; original $EA7D: pla
 pla
D_ea7e: ; original $EA7E: sta $06
 sta $c006
D_ea80: ; original $EA80: pla
 pla
D_ea81: ; original $EA81: sta $05
 sta $c005
D_ea83: ; original $EA83: pla
 pla
D_ea84: ; original $EA84: sta $01
 sta $c001
D_ea86: ; original $EA86: pla
 pla
D_ea87: ; original $EA87: sta $00
 sta $c000
D_ea89: ; original $EA89: pla
 pla
D_ea8a: ; original $EA8A: tay
 tay
D_ea8b: ; original $EA8B: pla
 pla
D_ea8c: ; original $EA8C: tax
 tax
D_ea8d: ; original $EA8D: pla
 pla
D_ea8e: ; original $EA8E: rts
 rts
D_ea8f: ; original $EA8F: lda $02
 lda $c002
D_ea91: ; original $EA91: ldx $03
 ldx $c003
D_ea93: ; original $EA93: ldy #$02
 ldy #$02
D_ea95: ; original $EA95: sta ($04),y
 php
 pha
 lda $c004
 sta DIndirect_ea95+1
 lda $c005
 cmp #8
 bcs DIndirect_ea95_rom
 ora #$c0
DIndirect_ea95_rom:
 sta DIndirect_ea95+2
 pla
 plp
DIndirect_ea95: sta $ffff,y
D_ea97: ; original $EA97: iny
 iny
D_ea98: ; original $EA98: iny
 iny
D_ea99: ; original $EA99: iny
 iny
D_ea9a: ; original $EA9A: iny
 iny
D_ea9b: ; original $EA9B: dex
 dex
D_ea9c: ; original $EA9C: bne $ea95
 jne D_ea95
D_ea9e: ; original $EA9E: rts
 rts
D_ea9f: ; original $EA9F: lda $02
 lda $c002
D_eaa1: ; original $EAA1: ldx $08
 ldx $c008
D_eaa3: ; original $EAA3: ldy #$01
 ldy #$01
D_eaa5: ; original $EAA5: sta ($04),y
 php
 pha
 lda $c004
 sta DIndirect_eaa5+1
 lda $c005
 cmp #8
 bcs DIndirect_eaa5_rom
 ora #$c0
DIndirect_eaa5_rom:
 sta DIndirect_eaa5+2
 pla
 plp
DIndirect_eaa5: sta $ffff,y
D_eaa7: ; original $EAA7: clc
 clc
D_eaa8: ; original $EAA8: adc #$01
 adc #$01
D_eaaa: ; original $EAAA: iny
 iny
D_eaab: ; original $EAAB: pha
 pha
D_eaac: ; original $EAAC: lda ($04),y
 php
 pha
 lda $c004
 sta DIndirect_eaac+1
 lda $c005
 cmp #8
 bcs DIndirect_eaac_rom
 ora #$c0
DIndirect_eaac_rom:
 sta DIndirect_eaac+2
 pla
 plp
DIndirect_eaac: lda $ffff,y
D_eaae: ; original $EAAE: and #$3f
 and #$3f
D_eab0: ; original $EAB0: sta ($04),y
 php
 pha
 lda $c004
 sta DIndirect_eab0+1
 lda $c005
 cmp #8
 bcs DIndirect_eab0_rom
 ora #$c0
DIndirect_eab0_rom:
 sta DIndirect_eab0+2
 pla
 plp
DIndirect_eab0: sta $ffff,y
D_eab2: ; original $EAB2: pla
 pla
D_eab3: ; original $EAB3: iny
 iny
D_eab4: ; original $EAB4: iny
 iny
D_eab5: ; original $EAB5: iny
 iny
D_eab6: ; original $EAB6: dex
 dex
D_eab7: ; original $EAB7: bne $eaa5
 jne D_eaa5
D_eab9: ; original $EAB9: rts
 rts
D_eaba: ; original $EABA: ldy #$00
 ldy #$00
D_eabc: ; original $EABC: ldx $06
 ldx $c006
D_eabe: ; original $EABE: lda $01
 lda $c001
D_eac0: ; original $EAC0: sta $09
 sta $c009
D_eac2: ; original $EAC2: lda $09
 lda $c009
D_eac4: ; original $EAC4: sta ($04),y
 php
 pha
 lda $c004
 sta DIndirect_eac4+1
 lda $c005
 cmp #8
 bcs DIndirect_eac4_rom
 ora #$c0
DIndirect_eac4_rom:
 sta DIndirect_eac4+2
 pla
 plp
DIndirect_eac4: sta $ffff,y
D_eac6: ; original $EAC6: clc
 clc
D_eac7: ; original $EAC7: adc #$08
 adc #$08
D_eac9: ; original $EAC9: sta $09
 sta $c009
D_eacb: ; original $EACB: iny
 iny
D_eacc: ; original $EACC: iny
 iny
D_eacd: ; original $EACD: iny
 iny
D_eace: ; original $EACE: lda $00
 lda $c000
D_ead0: ; original $EAD0: sta ($04),y
 php
 pha
 lda $c004
 sta DIndirect_ead0+1
 lda $c005
 cmp #8
 bcs DIndirect_ead0_rom
 ora #$c0
DIndirect_ead0_rom:
 sta DIndirect_ead0+2
 pla
 plp
DIndirect_ead0: sta $ffff,y
D_ead2: ; original $EAD2: iny
 iny
D_ead3: ; original $EAD3: dex
 dex
D_ead4: ; original $EAD4: bne $eac2
 jne D_eac2
D_ead6: ; original $EAD6: clc
 clc
D_ead7: ; original $EAD7: adc #$08
 adc #$08
D_ead9: ; original $EAD9: sta $00
 sta $c000
D_eadb: ; original $EADB: dec $07
 dec $c007
D_eadd: ; original $EADD: bne $eabc
 jne D_eabc
D_eadf: ; original $EADF: rts
 rts
D_eae0: ; original $EAE0: ldy #$01
 ldy #$01
D_eae2: ; original $EAE2: sty $0a
 sty $c00a
D_eae4: ; original $EAE4: lda $08
 lda $c008
D_eae6: ; original $EAE6: sec
 sec
D_eae7: ; original $EAE7: sbc $06
 sbc $c006
D_eae9: ; original $EAE9: tay
 tay
D_eaea: ; original $EAEA: sta $0b
 sta $c00b
D_eaec: ; original $EAEC: ldx $06
 ldx $c006
D_eaee: ; original $EAEE: tya
 tya
D_eaef: ; original $EAEF: pha
 pha
D_eaf0: ; original $EAF0: clc
 clc
D_eaf1: ; original $EAF1: tya
 tya
D_eaf2: ; original $EAF2: adc $02
 adc $c002
D_eaf4: ; original $EAF4: ldy $0a
 ldy $c00a
D_eaf6: ; original $EAF6: sta ($04),y
 php
 pha
 lda $c004
 sta DIndirect_eaf6+1
 lda $c005
 cmp #8
 bcs DIndirect_eaf6_rom
 ora #$c0
DIndirect_eaf6_rom:
 sta DIndirect_eaf6+2
 pla
 plp
DIndirect_eaf6: sta $ffff,y
D_eaf8: ; original $EAF8: iny
 iny
D_eaf9: ; original $EAF9: lda ($04),y
 php
 pha
 lda $c004
 sta DIndirect_eaf9+1
 lda $c005
 cmp #8
 bcs DIndirect_eaf9_rom
 ora #$c0
DIndirect_eaf9_rom:
 sta DIndirect_eaf9+2
 pla
 plp
DIndirect_eaf9: lda $ffff,y
D_eafb: ; original $EAFB: and #$3f
 and #$3f
D_eafd: ; original $EAFD: eor #$40
 eor #$40
D_eaff: ; original $EAFF: sta ($04),y
 php
 pha
 lda $c004
 sta DIndirect_eaff+1
 lda $c005
 cmp #8
 bcs DIndirect_eaff_rom
 ora #$c0
DIndirect_eaff_rom:
 sta DIndirect_eaff+2
 pla
 plp
DIndirect_eaff: sta $ffff,y
D_eb01: ; original $EB01: iny
 iny
D_eb02: ; original $EB02: iny
 iny
D_eb03: ; original $EB03: iny
 iny
D_eb04: ; original $EB04: sty $0a
 sty $c00a
D_eb06: ; original $EB06: pla
 pla
D_eb07: ; original $EB07: tay
 tay
D_eb08: ; original $EB08: iny
 iny
D_eb09: ; original $EB09: dex
 dex
D_eb0a: ; original $EB0A: bne $eaee
 jne D_eaee
D_eb0c: ; original $EB0C: lda $0b
 lda $c00b
D_eb0e: ; original $EB0E: sec
 sec
D_eb0f: ; original $EB0F: sbc $06
 sbc $c006
D_eb11: ; original $EB11: bpl $eae9
 jpl D_eae9
D_eb13: ; original $EB13: rts
 rts
D_eb14: ; original $EB14: lda #$01
 lda #$01
D_eb16: ; original $EB16: sta $0a
 sta $c00a
D_eb18: ; original $EB18: lda $06
 lda $c006
D_eb1a: ; original $EB1A: sec
 sec
D_eb1b: ; original $EB1B: sbc #$01
 sbc #$01
D_eb1d: ; original $EB1D: tay
 tay
D_eb1e: ; original $EB1E: sta $0b
 sta $c00b
D_eb20: ; original $EB20: ldx $06
 ldx $c006
D_eb22: ; original $EB22: tya
 tya
D_eb23: ; original $EB23: pha
 pha
D_eb24: ; original $EB24: clc
 clc
D_eb25: ; original $EB25: tya
 tya
D_eb26: ; original $EB26: adc $02
 adc $c002
D_eb28: ; original $EB28: ldy $0a
 ldy $c00a
D_eb2a: ; original $EB2A: sta ($04),y
 php
 pha
 lda $c004
 sta DIndirect_eb2a+1
 lda $c005
 cmp #8
 bcs DIndirect_eb2a_rom
 ora #$c0
DIndirect_eb2a_rom:
 sta DIndirect_eb2a+2
 pla
 plp
DIndirect_eb2a: sta $ffff,y
D_eb2c: ; original $EB2C: iny
 iny
D_eb2d: ; original $EB2D: lda ($04),y
 php
 pha
 lda $c004
 sta DIndirect_eb2d+1
 lda $c005
 cmp #8
 bcs DIndirect_eb2d_rom
 ora #$c0
DIndirect_eb2d_rom:
 sta DIndirect_eb2d+2
 pla
 plp
DIndirect_eb2d: lda $ffff,y
D_eb2f: ; original $EB2F: and #$3f
 and #$3f
D_eb31: ; original $EB31: ora #$80
 ora #$80
D_eb33: ; original $EB33: sta ($04),y
 php
 pha
 lda $c004
 sta DIndirect_eb33+1
 lda $c005
 cmp #8
 bcs DIndirect_eb33_rom
 ora #$c0
DIndirect_eb33_rom:
 sta DIndirect_eb33+2
 pla
 plp
DIndirect_eb33: sta $ffff,y
D_eb35: ; original $EB35: iny
 iny
D_eb36: ; original $EB36: iny
 iny
D_eb37: ; original $EB37: iny
 iny
D_eb38: ; original $EB38: sty $0a
 sty $c00a
D_eb3a: ; original $EB3A: pla
 pla
D_eb3b: ; original $EB3B: tay
 tay
D_eb3c: ; original $EB3C: dey
 dey
D_eb3d: ; original $EB3D: dex
 dex
D_eb3e: ; original $EB3E: bne $eb22
 jne D_eb22
D_eb40: ; original $EB40: lda $0b
 lda $c00b
D_eb42: ; original $EB42: clc
 clc
D_eb43: ; original $EB43: adc $06
 adc $c006
D_eb45: ; original $EB45: cmp $08
 cmp $c008
D_eb47: ; original $EB47: bmi $eb1d
 jmi D_eb1d
D_eb49: ; original $EB49: rts
 rts
D_eb4a: ; original $EB4A: ldy #$00
 ldy #$00
D_eb4c: ; original $EB4C: ldx $06
 ldx $c006
D_eb4e: ; original $EB4E: lda $01
 lda $c001
D_eb50: ; original $EB50: sta $09
 sta $c009
D_eb52: ; original $EB52: lda #$ff
 lda #$ff
D_eb54: ; original $EB54: sta ($04),y
 php
 pha
 lda $c004
 sta DIndirect_eb54+1
 lda $c005
 cmp #8
 bcs DIndirect_eb54_rom
 ora #$c0
DIndirect_eb54_rom:
 sta DIndirect_eb54+2
 pla
 plp
DIndirect_eb54: sta $ffff,y
D_eb56: ; original $EB56: iny
 iny
D_eb57: ; original $EB57: iny
 iny
D_eb58: ; original $EB58: iny
 iny
D_eb59: ; original $EB59: iny
 iny
D_eb5a: ; original $EB5A: dex
 dex
D_eb5b: ; original $EB5B: bne $eb54
 jne D_eb54
D_eb5d: ; original $EB5D: lda $00
 lda $c000
D_eb5f: ; original $EB5F: clc
 clc
D_eb60: ; original $EB60: adc #$08
 adc #$08
D_eb62: ; original $EB62: sta $00
 sta $c000
D_eb64: ; original $EB64: dec $07
 dec $c007
D_eb66: ; original $EB66: bne $eb4c
 jne D_eb4c
D_eb68: ; original $EB68: rts
 rts
D_eb69: ; original $EB69: lda #$00
 lda #$00
D_eb6b: ; original $EB6B: jmp $eb75
 jmp D_eb75
D_eb6e: ; original $EB6E: lda #$01
 lda #$01
D_eb70: ; original $EB70: jmp $eb75
 jmp D_eb75
D_eb73: ; original $EB73: lda #$02
 lda #$02
D_eb75: ; original $EB75: sta $0f
 sta $c00f
D_eb77: ; original $EB77: txa
 txa
D_eb78: ; original $EB78: pha
 pha
D_eb79: ; original $EB79: tya
 tya
D_eb7a: ; original $EB7A: pha
 pha
D_eb7b: ; original $EB7B: ldy #$00
 ldy #$00
D_eb7d: ; original $EB7D: lda $0f
 lda $c00f
D_eb7f: ; original $EB7F: cmp #$02
 cmp #$02
D_eb81: ; original $EB81: beq $eb96
 jeq D_eb96
D_eb83: ; original $EB83: cmp #$01
 cmp #$01
D_eb85: ; original $EB85: beq $eb8d
 jeq D_eb8d
D_eb87: ; original $EB87: jsr $ebc1
 jsr D_ebc1
D_eb8a: ; original $EB8A: jmp $ebba
 jmp D_ebba
D_eb8d: ; original $EB8D: jsr $ebc1
 jsr D_ebc1
D_eb90: ; original $EB90: jsr $ebe3
 jsr D_ebe3
D_eb93: ; original $EB93: jmp $ebb8
 jmp D_ebb8
D_eb96: ; original $EB96: lda ($02),y
 php
 pha
 lda $c002
 sta DIndirect_eb96+1
 lda $c003
 cmp #8
 bcs DIndirect_eb96_rom
 ora #$c0
DIndirect_eb96_rom:
 sta DIndirect_eb96+2
 pla
 plp
DIndirect_eb96: lda $ffff,y
D_eb98: ; original $EB98: cmp #$ff
 cmp #$ff
D_eb9a: ; original $EB9A: beq $ebb6
 jeq D_ebb6
D_eb9c: ; original $EB9C: sta $42
 sta $c042
D_eb9e: ; original $EB9E: iny
 iny
D_eb9f: ; original $EB9F: lda ($02),y
 php
 pha
 lda $c002
 sta DIndirect_eb9f+1
 lda $c003
 cmp #8
 bcs DIndirect_eb9f_rom
 ora #$c0
DIndirect_eb9f_rom:
 sta DIndirect_eb9f+2
 pla
 plp
DIndirect_eb9f: lda $ffff,y
D_eba1: ; original $EBA1: sta $43
 sta $c043
D_eba3: ; original $EBA3: iny
 iny
D_eba4: ; original $EBA4: lda ($02),y
 php
 pha
 lda $c002
 sta DIndirect_eba4+1
 lda $c003
 cmp #8
 bcs DIndirect_eba4_rom
 ora #$c0
DIndirect_eba4_rom:
 sta DIndirect_eba4+2
 pla
 plp
DIndirect_eba4: lda $ffff,y
D_eba6: ; original $EBA6: sta $44
 sta $c044
D_eba8: ; original $EBA8: iny
 iny
D_eba9: ; original $EBA9: lda ($02),y
 php
 pha
 lda $c002
 sta DIndirect_eba9+1
 lda $c003
 cmp #8
 bcs DIndirect_eba9_rom
 ora #$c0
DIndirect_eba9_rom:
 sta DIndirect_eba9+2
 pla
 plp
DIndirect_eba9: lda $ffff,y
D_ebab: ; original $EBAB: sta $45
 sta $c045
D_ebad: ; original $EBAD: iny
 iny
D_ebae: ; original $EBAE: jsr $ebe3
 jsr D_ebe3
D_ebb1: ; original $EBB1: beq $eb96
 jeq D_eb96
D_ebb3: ; original $EBB3: jmp $ebb8
 jmp D_ebb8
D_ebb6: ; original $EBB6: lda #$00
 lda #$00
D_ebb8: ; original $EBB8: sta $0f
 sta $c00f
D_ebba: ; original $EBBA: pla
 pla
D_ebbb: ; original $EBBB: tay
 tay
D_ebbc: ; original $EBBC: pla
 pla
D_ebbd: ; original $EBBD: tax
 tax
D_ebbe: ; original $EBBE: lda $0f
 lda $c00f
D_ebc0: ; original $EBC0: rts
 rts
D_ebc1: ; original $EBC1: ldx #$00
 ldx #$00
D_ebc3: ; original $EBC3: lda $0f
 lda $c00f
D_ebc5: ; original $EBC5: beq $ebc9
 jeq D_ebc9
D_ebc7: ; original $EBC7: ldx #$04
 ldx #$04
D_ebc9: ; original $EBC9: jsr $ebcd
 jsr D_ebcd
D_ebcc: ; original $EBCC: rts
 rts
D_ebcd: ; original $EBCD: jsr $ebd0
 jsr D_ebd0
D_ebd0: ; original $EBD0: lda ($02),y
 php
 pha
 lda $c002
 sta DIndirect_ebd0+1
 lda $c003
 cmp #8
 bcs DIndirect_ebd0_rom
 ora #$c0
DIndirect_ebd0_rom:
 sta DIndirect_ebd0+2
 pla
 plp
DIndirect_ebd0: lda $ffff,y
D_ebd2: ; original $EBD2: clc
 clc
D_ebd3: ; original $EBD3: adc $00
 adc $c000
D_ebd5: ; original $EBD5: sta $3e,x
 sta $c03e,x
D_ebd7: ; original $EBD7: inx
 inx
D_ebd8: ; original $EBD8: iny
 iny
D_ebd9: ; original $EBD9: lda ($02),y
 php
 pha
 lda $c002
 sta DIndirect_ebd9+1
 lda $c003
 cmp #8
 bcs DIndirect_ebd9_rom
 ora #$c0
DIndirect_ebd9_rom:
 sta DIndirect_ebd9+2
 pla
 plp
DIndirect_ebd9: lda $ffff,y
D_ebdb: ; original $EBDB: clc
 clc
D_ebdc: ; original $EBDC: adc $01
 adc $c001
D_ebde: ; original $EBDE: sta $3e,x
 sta $c03e,x
D_ebe0: ; original $EBE0: inx
 inx
D_ebe1: ; original $EBE1: iny
 iny
D_ebe2: ; original $EBE2: rts
 rts
D_ebe3: ; original $EBE3: lda $3e
 lda $c03e
D_ebe5: ; original $EBE5: cmp $42
 cmp $c042
D_ebe7: ; original $EBE7: bcc $ebf4
 jcc D_ebf4
D_ebe9: ; original $EBE9: beq $ebfa
 jeq D_ebfa
D_ebeb: ; original $EBEB: cmp $44
 cmp $c044
D_ebed: ; original $EBED: bcc $ebfa
 jcc D_ebfa
D_ebef: ; original $EBEF: beq $ebfa
 jeq D_ebfa
D_ebf1: ; original $EBF1: lda #$00
 lda #$00
D_ebf3: ; original $EBF3: rts
 rts
D_ebf4: ; original $EBF4: lda $40
 lda $c040
D_ebf6: ; original $EBF6: cmp $42
 cmp $c042
D_ebf8: ; original $EBF8: bcc $ec14
 jcc D_ec14
D_ebfa: ; original $EBFA: lda $3f
 lda $c03f
D_ebfc: ; original $EBFC: cmp $43
 cmp $c043
D_ebfe: ; original $EBFE: bcc $ec0b
 jcc D_ec0b
D_ec00: ; original $EC00: beq $ec11
 jeq D_ec11
D_ec02: ; original $EC02: cmp $45
 cmp $c045
D_ec04: ; original $EC04: bcc $ec11
 jcc D_ec11
D_ec06: ; original $EC06: beq $ec11
 jeq D_ec11
D_ec08: ; original $EC08: lda #$00
 lda #$00
D_ec0a: ; original $EC0A: rts
 rts
D_ec0b: ; original $EC0B: lda $41
 lda $c041
D_ec0d: ; original $EC0D: cmp $43
 cmp $c043
D_ec0f: ; original $EC0F: bcc $ec14
 jcc D_ec14
D_ec11: ; original $EC11: lda #$01
 lda #$01
D_ec13: ; original $EC13: rts
 rts
D_ec14: ; original $EC14: lda #$00
 lda #$00
D_ec16: ; original $EC16: rts
 rts
D_f1af: ; original $F1AF: ldx #$03
 ldx #$03
D_f1b1: ; original $F1B1: dec $34
 dec $c034
D_f1b3: ; original $F1B3: bpl $f1bb
 jpl D_f1bb
D_f1b5: ; original $F1B5: lda #$0a
 lda #$0a
D_f1b7: ; original $F1B7: sta $34
 sta $c034
D_f1b9: ; original $F1B9: ldx #$08
 ldx #$08
D_f1bb: ; original $F1BB: lda $35,x
 lda $c035,x
D_f1bd: ; original $F1BD: beq $f1c1
 jeq D_f1c1
D_f1bf: ; original $F1BF: dec $35,x
 dec $c035,x
D_f1c1: ; original $F1C1: dex
 dex
D_f1c2: ; original $F1C2: bpl $f1bb
 jpl D_f1bb
D_f1c4: ; original $F1C4: rts
 rts
.export DImport_cf62
DImport_cf62: jmp DImport_cf62 ; closed local trap until typed host binding
.export DImport_e893
DImport_e893: jmp DImport_e893 ; closed local trap until typed host binding
.export DImport_e897
DImport_e897: jmp DImport_e897 ; closed local trap until typed host binding
.export DImport_e89b
DImport_e89b: jmp DImport_e89b ; closed local trap until typed host binding
.export DImport_e89f
DImport_e89f: jmp DImport_e89f ; closed local trap until typed host binding
.export DImport_ecb7
DImport_ecb7: jmp DImport_ecb7 ; closed local trap until typed host binding
.export DImport_ed44
DImport_ed44: jmp DImport_ed44 ; closed local trap until typed host binding
.export DImport_ed7b
DImport_ed7b: jmp DImport_ed7b ; closed local trap until typed host binding
.export DImport_efce
DImport_efce: jmp DImport_efce ; closed local trap until typed host binding
.export DImport_f1c5
DImport_f1c5: jmp DImport_f1c5 ; closed local trap until typed host binding
.export DkjrSourceData
DData_c2cd:
DkjrSourceData:
 .byte $02
DData_c2ce:
 .byte $00
DData_c2cf:
 .byte $02
DData_c2d0:
 .byte $02
DData_c2d1:
 .byte $02
DData_c2d2:
 .byte $00
DData_c2d3:
 .byte $02
DData_c2d4:
 .byte $00
DData_c2d5:
 .byte $00
DData_c2d6:
 .byte $00
DData_c2d7:
 .byte $00
DData_c2d8:
 .byte $00
DData_c2d9:
 .byte $00
DData_c2da:
 .byte $00
DData_c2db:
 .byte $00
DData_c2dc:
 .byte $00
DData_c2dd:
 .byte $00
DData_c2de:
 .byte $02
DData_c2df:
 .byte $10
DData_c2e0:
 .byte $0f
DData_c2e1:
 .byte $03
DData_c2e2:
 .byte $03
DData_c2e3:
 .byte $0d
DData_c2e4:
 .byte $0a
DData_c2e5:
 .byte $d1
DData_c2e6:
 .byte $d3
DData_c2e7:
 .byte $d1
DData_c2e8:
 .byte $d2
DData_c2e9:
 .byte $eb
DData_c2ea:
 .byte $d4
DData_c2eb:
 .byte $da
DData_c2ec:
 .byte $dd
DData_c2ed:
 .byte $44
DData_c2ee:
 .byte $21
DData_c2ef:
 .byte $4c
DData_c2f0:
 .byte $21
DData_c2f1:
 .byte $51
DData_c2f2:
 .byte $22
DData_c2f3:
 .byte $93
DData_c2f4:
 .byte $21
DData_c2f5:
 .byte $45
DData_c2f6:
 .byte $21
DData_c2f7:
 .byte $4a
DData_c2f8:
 .byte $21
DData_c2f9:
 .byte $d3
DData_c2fa:
 .byte $21
DData_c2fb:
 .byte $00
DData_c2fc:
 .byte $00
DData_c2fd:
 .byte $8c
DData_c2fe:
 .byte $22
DData_c2ff:
 .byte $12
DData_c300:
 .byte $22
DData_c301:
 .byte $4e
DData_c302:
 .byte $21
DData_c303:
 .byte $00
DData_c304:
 .byte $00
DData_c305:
 .byte $c8
DData_c306:
 .byte $21
DData_c307:
 .byte $d6
DData_c308:
 .byte $21
DData_c309:
 .word DData_c311
DData_c30a=DData_c309+1
DData_c30b:
 .word DData_c32e
DData_c30c=DData_c30b+1
DData_c30d:
 .word DData_c344
DData_c30e=DData_c30d+1
DData_c30f:
 .word DData_c35a
DData_c310=DData_c30f+1
DData_c311:
 .byte $1c
DData_c312:
 .byte $20
DData_c313:
 .byte $50
DData_c314:
 .byte $ac
DData_c315:
 .byte $24
DData_c316:
 .byte $24
DData_c317:
 .byte $5d
DData_c318:
 .byte $5c
DData_c319:
 .byte $60
DData_c31a:
 .byte $50
DData_c31b:
 .byte $a4
DData_c31c:
 .byte $24
DData_c31d:
 .byte $24
DData_c31e:
 .byte $5c
DData_c31f:
 .byte $5d
DData_c320:
 .byte $88
DData_c321:
 .byte $90
DData_c322:
 .byte $a8
DData_c323:
 .byte $24
DData_c324:
 .byte $24
DData_c325:
 .byte $24
DData_c326:
 .byte $24
DData_c327:
 .byte $98
DData_c328:
 .byte $60
DData_c329:
 .byte $ac
DData_c32a:
 .byte $24
DData_c32b:
 .byte $24
DData_c32c:
 .byte $5c
DData_c32d:
 .byte $5c
DData_c32e:
 .byte $15
DData_c32f:
 .byte $28
DData_c330:
 .byte $50
DData_c331:
 .byte $a8
DData_c332:
 .byte $65
DData_c333:
 .byte $65
DData_c334:
 .byte $24
DData_c335:
 .byte $24
DData_c336:
 .byte $50
DData_c337:
 .byte $50
DData_c338:
 .byte $a4
DData_c339:
 .byte $24
DData_c33a:
 .byte $24
DData_c33b:
 .byte $65
DData_c33c:
 .byte $65
DData_c33d:
 .byte $98
DData_c33e:
 .byte $70
DData_c33f:
 .byte $ac
DData_c340:
 .byte $24
DData_c341:
 .byte $24
DData_c342:
 .byte $65
DData_c343:
 .byte $65
DData_c344:
 .byte $15
DData_c345:
 .byte $60
DData_c346:
 .byte $a0
DData_c347:
 .byte $a4
DData_c348:
 .byte $79
DData_c349:
 .byte $24
DData_c34a:
 .byte $79
DData_c34b:
 .byte $24
DData_c34c:
 .byte $90
DData_c34d:
 .byte $80
DData_c34e:
 .byte $a4
DData_c34f:
 .byte $24
DData_c350:
 .byte $24
DData_c351:
 .byte $24
DData_c352:
 .byte $24
DData_c353:
 .byte $70
DData_c354:
 .byte $50
DData_c355:
 .byte $a4
DData_c356:
 .byte $24
DData_c357:
 .byte $24
DData_c358:
 .byte $24
DData_c359:
 .byte $24
DData_c35a:
 .byte $0e
DData_c35b:
 .byte $40
DData_c35c:
 .byte $70
DData_c35d:
 .byte $a4
DData_c35e:
 .byte $65
DData_c35f:
 .byte $65
DData_c360:
 .byte $24
DData_c361:
 .byte $24
DData_c362:
 .byte $b0
DData_c363:
 .byte $70
DData_c364:
 .byte $a4
DData_c365:
 .byte $24
DData_c366:
 .byte $24
DData_c367:
 .byte $65
DData_c368:
 .byte $65
DData_c369:
 .word DData_c379
DData_c36a=DData_c369+1
DData_c36b:
 .word DData_c379
DData_c36c=DData_c36b+1
DData_c36d:
 .word DData_c37d
DData_c36e=DData_c36d+1
DData_c36f:
 .word DData_c381
DData_c370=DData_c36f+1
DData_c371:
 .word DData_c389
DData_c372=DData_c371+1
DData_c373:
 .word DData_c38d
DData_c374=DData_c373+1
DData_c375:
 .word DData_c385
DData_c376=DData_c375+1
DData_c377:
 .word DData_c385
DData_c378=DData_c377+1
DData_c379:
 .byte $07
DData_c37a:
 .byte $00
DData_c37b:
 .byte $18
DData_c37c:
 .byte $0f
DData_c37d:
 .byte $03
DData_c37e:
 .byte $00
DData_c37f:
 .byte $11
DData_c380:
 .byte $10
DData_c381:
 .byte $0f
DData_c382:
 .byte $00
DData_c383:
 .byte $1b
DData_c384:
 .byte $10
DData_c385:
 .byte $03
DData_c386:
 .byte $00
DData_c387:
 .byte $1d
DData_c388:
 .byte $10
DData_c389:
 .byte $09
DData_c38a:
 .byte $00
DData_c38b:
 .byte $19
DData_c38c:
 .byte $0f
DData_c38d:
 .byte $05
DData_c38e:
 .byte $00
DData_c38f:
 .byte $18
DData_c390:
 .byte $0f
DData_c391:
 .byte $07
DData_c392:
 .byte $04
DData_c393:
 .byte $08
DData_c394:
 .byte $07
DData_c395:
 .byte $03
DData_c396:
 .byte $07
DData_c397:
 .byte $04
DData_c398:
 .byte $08
DData_c399:
 .byte $08
DData_c39a:
 .byte $09
DData_c39b:
 .byte $08
DData_c39c:
 .byte $09
DData_c39d:
 .byte $03
DData_c39e:
 .byte $09
DData_c39f:
 .byte $03
DData_c3a0:
 .byte $09
DData_c3a1:
 .byte $04
DData_c3a2:
 .byte $00
DData_c3a3:
 .byte $04
DData_c3a4:
 .byte $03
DData_c3a5:
 .byte $04
DData_c3a6:
 .byte $01
DData_c3a7:
 .byte $0c
DData_c3a8:
 .byte $01
DData_c3a9:
 .byte $00
DData_c3aa:
 .byte $01
DData_c3ab:
 .byte $1f
DData_c3ac:
 .byte $01
DData_c3ad:
 .byte $04
DData_c3ae:
 .byte $01
DData_c3af:
 .byte $0c
DData_c3b0:
 .byte $04
DData_c3b1:
 .byte $07
DData_c3b2:
 .byte $08
DData_c3b3:
 .byte $07
DData_c3b4:
 .byte $09
DData_c3b5:
 .byte $01
DData_c3b6:
 .byte $01
DData_c3b7:
 .byte $04
DData_c3b8:
 .byte $01
DData_c3b9:
 .byte $00
DData_c3ba:
 .byte $00
DData_c3bb:
 .byte $10
DData_c3bc:
 .byte $58
DData_c3bd:
 .byte $8e
DData_c3be:
 .byte $f3
DData_c3bf:
 .byte $6c
DData_c3c0:
 .byte $f7
DData_c3c1:
 .byte $47
DData_c3c2:
 .byte $f6
DData_c3c3:
 .byte $ee
DData_c3c4:
 .byte $f4
DData_c3c5:
 .byte $12
DData_c3c6:
 .byte $c8
DData_c3c7:
 .byte $c9
DData_c3c8:
 .byte $12
DData_c3c9:
 .byte $24
DData_c3ca:
 .byte $24
DData_c3cb:
 .byte $42
DData_c3cc:
 .byte $d0
DkjrComponentEnd:
.export DkjrComponentEnd
