.setcpu "6502"
.macpack longbranch
.segment "BB_VECTORS"
.export BbServices,BbReject,BbImports,BbCodeEnd
BbServices:
.repeat 37
 jmp BbReject
.endrepeat
BbReject:clc
 rts
.segment "BB_IMPORTS"
BbImports:
.export BbImportScore
BbImportScore: jmp BbReject
.export BbImportLivesUI
BbImportLivesUI: jmp BbReject
.export BbImportYield
BbImportYield: jmp BbReject
.export BbImportStageEffects
BbImportStageEffects: jmp BbReject
.export BbImportSpecialAbility
BbImportSpecialAbility: jmp BbReject
.export BbImportStageBubbles
BbImportStageBubbles: jmp BbReject
.export BbImportSpecialPop
BbImportSpecialPop: jmp BbReject
.export BbImportSound
BbImportSound: jmp BbReject
.export BbImportBossPlayer
BbImportBossPlayer: jmp BbReject
.export BbImportBossDeath
BbImportBossDeath: jmp BbReject
.export BbImportEnemyDraw
BbImportEnemyDraw: jmp BbReject
.export BbImportEnemyRelease
BbImportEnemyRelease: jmp BbReject
.export BbImportFoodUpdate
BbImportFoodUpdate: jmp BbReject
.export BbImportElementalUpdate
BbImportElementalUpdate: jmp BbReject
.export BbImportTile23
BbImportTile23: jmp BbReject
.export BbImportTile84
BbImportTile84: jmp BbReject
.segment "BB_CODE"
.export BbSourceClock
BbSourceClock=BbOriginal_CE30
.export BbSourceInit
BbSourceInit=BbOriginal_D18A
.export BbSourceSprites
BbSourceSprites=BbOriginal_D28E
.export BbInput
BbInput=BbOriginal_D1A0
.export BbPlayerStep
BbPlayerStep=BbOriginal_D1E7
.export BbBubbleStep
BbBubbleStep=BbOriginal_D887
.export BbTrappedEnemyStep
BbTrappedEnemyStep=BbOriginal_9528
.export BbPoseStep
BbPoseStep=BbOriginal_D580
.export BbHurtBub
BbHurtBub=BbOriginal_D54E
.export BbHurtBob
BbHurtBob=BbOriginal_D578
.export BbJumpStart
BbJumpStart=BbOriginal_D365
.export BbJumpAscent
BbJumpAscent=BbOriginal_D386
.export BbShotRequest
BbShotRequest=BbOriginal_D530
.export BbBubbleContact
BbBubbleContact=BbOriginal_DC55
.export BbPopChain
BbPopChain=BbOriginal_DD6D
.export BbBubbleSupport
BbBubbleSupport=BbOriginal_D331
; Original bank7 $C38F..$C3A7
.export BbOriginal_C38F
BbOriginal_C38F:
 lda $c101,y ; source$C38F: LDA $0201,Y
.export BbOriginal_C392
BbOriginal_C392:
 pha  ; source$C392: PHA
.export BbOriginal_C393
BbOriginal_C393:
 lda $c105,y ; source$C393: LDA $0205,Y
.export BbOriginal_C396
BbOriginal_C396:
 sta $c101,y ; source$C396: STA $0201,Y
.export BbOriginal_C399
BbOriginal_C399:
 pla  ; source$C399: PLA
.export BbOriginal_C39A
BbOriginal_C39A:
 sta $c105,y ; source$C39A: STA $0205,Y
.export BbOriginal_C39D
BbOriginal_C39D:
 rts  ; source$C39D: RTS
.export BbOriginal_C39E
BbOriginal_C39E:
 inx  ; source$C39E: INX
.export BbOriginal_C39F
BbOriginal_C39F:
 inx  ; source$C39F: INX
.export BbOriginal_C3A0
BbOriginal_C3A0:
 inx  ; source$C3A0: INX
.export BbOriginal_C3A1
BbOriginal_C3A1:
 inx  ; source$C3A1: INX
.export BbOriginal_C3A2
BbOriginal_C3A2:
 tya  ; source$C3A2: TYA
.export BbOriginal_C3A3
BbOriginal_C3A3:
 clc  ; source$C3A3: CLC
.export BbOriginal_C3A4
BbOriginal_C3A4:
 adc #$08 ; source$C3A4: ADC #$08
.export BbOriginal_C3A6
BbOriginal_C3A6:
 tay  ; source$C3A6: TAY
.export BbOriginal_C3A7
BbOriginal_C3A7:
 rts  ; source$C3A7: RTS
; Original bank7 $C43E..$C46F
.export BbOriginal_C43E
BbOriginal_C43E:
 sta $c267 ; source$C43E: STA $0467
.export BbOriginal_C441
BbOriginal_C441:
 lda $c103,y ; source$C441: LDA $0203,Y
.export BbOriginal_C444
BbOriginal_C444:
 cmp $c022 ; source$C444: CMP $22
.export BbOriginal_C446
BbOriginal_C446:
 jcc BbOriginal_C44D ; source$C446: BCC $c44d
.export BbOriginal_C448
BbOriginal_C448:
 sbc $c022 ; source$C448: SBC $22
.export BbOriginal_C44A
BbOriginal_C44A:
 jmp BbOriginal_C453 ; source$C44A: JMP $c453
.export BbOriginal_C44D
BbOriginal_C44D:
 sec  ; source$C44D: SEC
.export BbOriginal_C44E
BbOriginal_C44E:
 lda $c022 ; source$C44E: LDA $22
.export BbOriginal_C450
BbOriginal_C450:
 sbc $c103,y ; source$C450: SBC $0203,Y
.export BbOriginal_C453
BbOriginal_C453:
 sta $c023 ; source$C453: STA $23
.export BbOriginal_C455
BbOriginal_C455:
 cmp $c267 ; source$C455: CMP $0467
.export BbOriginal_C458
BbOriginal_C458:
 jcs BbOriginal_C466 ; source$C458: BCS $c466
.export BbOriginal_C45A
BbOriginal_C45A:
 lda $c100,y ; source$C45A: LDA $0200,Y
.export BbOriginal_C45D
BbOriginal_C45D:
 cmp $c021 ; source$C45D: CMP $21
.export BbOriginal_C45F
BbOriginal_C45F:
 jcc BbOriginal_C467 ; source$C45F: BCC $c467
.export BbOriginal_C461
BbOriginal_C461:
 sbc $c021 ; source$C461: SBC $21
.export BbOriginal_C463
BbOriginal_C463:
 cmp $c267 ; source$C463: CMP $0467
.export BbOriginal_C466
BbOriginal_C466:
 rts  ; source$C466: RTS
.export BbOriginal_C467
BbOriginal_C467:
 sec  ; source$C467: SEC
.export BbOriginal_C468
BbOriginal_C468:
 lda $c021 ; source$C468: LDA $21
.export BbOriginal_C46A
BbOriginal_C46A:
 sbc $c100,y ; source$C46A: SBC $0200,Y
.export BbOriginal_C46D
BbOriginal_C46D:
 jmp BbOriginal_C463 ; source$C46D: JMP $c463
; Original bank7 $CE30..$CE4C
.export BbOriginal_CE30
BbOriginal_CE30:
 inc $c01f ; source$CE30: INC $1f
.export BbOriginal_CE32
BbOriginal_CE32:
 ldx #$27 ; source$CE32: LDX #$27
.export BbOriginal_CE34
BbOriginal_CE34:
 ldy #$2b ; source$CE34: LDY #$2b
.export BbOriginal_CE36
BbOriginal_CE36:
 dec $c000,x ; source$CE36: DEC $00,X
.export BbOriginal_CE38
BbOriginal_CE38:
 jpl BbOriginal_CE40 ; source$CE38: BPL $ce40
.export BbOriginal_CE3A
BbOriginal_CE3A:
 lda #$09 ; source$CE3A: LDA #$09
.export BbOriginal_CE3C
BbOriginal_CE3C:
 sta $c000,x ; source$CE3C: STA $00,X
.export BbOriginal_CE3E
BbOriginal_CE3E:
 ldy #$2d ; source$CE3E: LDY #$2d
.export BbOriginal_CE40
BbOriginal_CE40:
 tya  ; source$CE40: TYA
.export BbOriginal_CE41
BbOriginal_CE41:
 tax  ; source$CE41: TAX
.export BbOriginal_CE42
BbOriginal_CE42:
 lda $c000,x ; source$CE42: LDA $00,X
.export BbOriginal_CE44
BbOriginal_CE44:
 jeq BbOriginal_CE48 ; source$CE44: BEQ $ce48
.export BbOriginal_CE46
BbOriginal_CE46:
 dec $c000,x ; source$CE46: DEC $00,X
.export BbOriginal_CE48
BbOriginal_CE48:
 dex  ; source$CE48: DEX
.export BbOriginal_CE49
BbOriginal_CE49:
 cpx #$27 ; source$CE49: CPX #$27
.export BbOriginal_CE4B
BbOriginal_CE4B:
 jne BbOriginal_CE42 ; source$CE4B: BNE $ce42
.export BbOriginal_CE4D
BbOriginal_CE4D: rts ; original post-clock audio seam
; Original bank7 $D0BE..$D161
.export BbOriginal_D0BE
BbOriginal_D0BE:
 lda #$00 ; source$D0BE: LDA $cfb5
.export BbOriginal_D0C1
BbOriginal_D0C1:
 sta $c023 ; source$D0C1: STA $23
.export BbOriginal_D0C3
BbOriginal_D0C3:
 lda #$05 ; source$D0C3: LDA $cfb6
.export BbOriginal_D0C6
BbOriginal_D0C6:
 sta $c024 ; source$D0C6: STA $24
.export BbOriginal_D0C8
BbOriginal_D0C8:
 lda $c021 ; source$D0C8: LDA $21
.export BbOriginal_D0CA
BbOriginal_D0CA:
 and #$f8 ; source$D0CA: AND #$f8
.export BbOriginal_D0CC
BbOriginal_D0CC:
 sec  ; source$D0CC: SEC
.export BbOriginal_D0CD
BbOriginal_D0CD:
 sbc #$20 ; source$D0CD: SBC #$20
.export BbOriginal_D0CF
BbOriginal_D0CF:
 asl a ; source$D0CF: ASL A
.export BbOriginal_D0D0
BbOriginal_D0D0:
 jcc BbOriginal_D0D6 ; source$D0D0: BCC $d0d6
.export BbOriginal_D0D2
BbOriginal_D0D2:
 inc $c024 ; source$D0D2: INC $24
.export BbOriginal_D0D4
BbOriginal_D0D4:
 inc $c024 ; source$D0D4: INC $24
.export BbOriginal_D0D6
BbOriginal_D0D6:
 asl a ; source$D0D6: ASL A
.export BbOriginal_D0D7
BbOriginal_D0D7:
 jcc BbOriginal_D0DB ; source$D0D7: BCC $d0db
.export BbOriginal_D0D9
BbOriginal_D0D9:
 inc $c024 ; source$D0D9: INC $24
.export BbOriginal_D0DB
BbOriginal_D0DB:
 clc  ; source$D0DB: CLC
.export BbOriginal_D0DC
BbOriginal_D0DC:
 adc $c023 ; source$D0DC: ADC $23
.export BbOriginal_D0DE
BbOriginal_D0DE:
 sta $c023 ; source$D0DE: STA $23
.export BbOriginal_D0E0
BbOriginal_D0E0:
 lda $c022 ; source$D0E0: LDA $22
.export BbOriginal_D0E2
BbOriginal_D0E2:
 lsr a ; source$D0E2: LSR A
.export BbOriginal_D0E3
BbOriginal_D0E3:
 lsr a ; source$D0E3: LSR A
.export BbOriginal_D0E4
BbOriginal_D0E4:
 lsr a ; source$D0E4: LSR A
.export BbOriginal_D0E5
BbOriginal_D0E5:
 clc  ; source$D0E5: CLC
.export BbOriginal_D0E6
BbOriginal_D0E6:
 adc $c023 ; source$D0E6: ADC $23
.export BbOriginal_D0E8
BbOriginal_D0E8:
 sta $c023 ; source$D0E8: STA $23
.export BbOriginal_D0EA
BbOriginal_D0EA:
 lda $c024 ; source$D0EA: LDA $24
.export BbOriginal_D0EC
BbOriginal_D0EC:
 cmp #$09 ; source$D0EC: CMP #$09
.export BbOriginal_D0EE
BbOriginal_D0EE:
 jne BbOriginal_D0F4 ; source$D0EE: BNE $d0f4
.export BbOriginal_D0F0
BbOriginal_D0F0:
 lda #$05 ; source$D0F0: LDA #$05
.export BbOriginal_D0F2
BbOriginal_D0F2:
 sta $c024 ; source$D0F2: STA $24
.export BbOriginal_D0F4
BbOriginal_D0F4:
 cmp #$05 ; source$D0F4: CMP #$05
.export BbOriginal_D0F6
BbOriginal_D0F6:
 jcc BbOriginal_D107 ; source$D0F6: BCC $d107
.export BbOriginal_D0F8
BbOriginal_D0F8:
 cmp #$08 ; source$D0F8: CMP #$08
.export BbOriginal_D0FA
BbOriginal_D0FA:
 jcs BbOriginal_D107 ; source$D0FA: BCS $d107
.export BbOriginal_D0FC
BbOriginal_D0FC:
 stx $c025 ; source$D0FC: STX $25
.export BbOriginal_D0FE
BbOriginal_D0FE:
 ldx #$00 ; source$D0FE: LDX #$00
.export BbOriginal_D100
BbOriginal_D100:
 jsr BbImportTile23 ; source$D100: LDA ($23,X)
.export BbOriginal_D102
BbOriginal_D102:
 php  ; source$D102: PHP
.export BbOriginal_D103
BbOriginal_D103:
 ldx $c025 ; source$D103: LDX $25
.export BbOriginal_D105
BbOriginal_D105:
 plp  ; source$D105: PLP
.export BbOriginal_D106
BbOriginal_D106:
 rts  ; source$D106: RTS
.export BbOriginal_D107
BbOriginal_D107:
 lda #$07 ; source$D107: LDA #$07
.export BbOriginal_D109
BbOriginal_D109:
 sta $c085 ; source$D109: STA $85
.export BbOriginal_D10B
BbOriginal_D10B:
 lda $c023 ; source$D10B: LDA $23
.export BbOriginal_D10D
BbOriginal_D10D:
 and #$1f ; source$D10D: AND #$1f
.export BbOriginal_D10F
BbOriginal_D10F:
 ora #$e0 ; source$D10F: ORA #$e0
.export BbOriginal_D111
BbOriginal_D111:
 sta $c084 ; source$D111: STA $84
.export BbOriginal_D113
BbOriginal_D113:
 stx $c025 ; source$D113: STX $25
.export BbOriginal_D115
BbOriginal_D115:
 ldx #$00 ; source$D115: LDX #$00
.export BbOriginal_D117
BbOriginal_D117:
 jsr BbImportTile84 ; source$D117: LDA ($84,X)
.export BbOriginal_D119
BbOriginal_D119:
 php  ; source$D119: PHP
.export BbOriginal_D11A
BbOriginal_D11A:
 ldx $c025 ; source$D11A: LDX $25
.export BbOriginal_D11C
BbOriginal_D11C:
 plp  ; source$D11C: PLP
.export BbOriginal_D11D
BbOriginal_D11D:
 rts  ; source$D11D: RTS
.export BbOriginal_D11E
BbOriginal_D11E:
 inc $c023 ; source$D11E: INC $23
.export BbOriginal_D120
BbOriginal_D120:
 jmp BbOriginal_D0EA ; source$D120: JMP $d0ea
.export BbOriginal_D123
BbOriginal_D123:
 inc $c023 ; source$D123: INC $23
.export BbOriginal_D125
BbOriginal_D125:
 inc $c023 ; source$D125: INC $23
.export BbOriginal_D127
BbOriginal_D127:
 jmp BbOriginal_D0EA ; source$D127: JMP $d0ea
.export BbOriginal_D12A
BbOriginal_D12A:
 lda #$20 ; source$D12A: LDA #$20
.export BbOriginal_D12C
BbOriginal_D12C:
 jne BbOriginal_D130 ; source$D12C: BNE $d130
.export BbOriginal_D12E
BbOriginal_D12E:
 lda #$40 ; source$D12E: LDA #$40
.export BbOriginal_D130
BbOriginal_D130:
 clc  ; source$D130: CLC
.export BbOriginal_D131
BbOriginal_D131:
 adc $c023 ; source$D131: ADC $23
.export BbOriginal_D133
BbOriginal_D133:
 sta $c023 ; source$D133: STA $23
.export BbOriginal_D135
BbOriginal_D135:
 lda #$00 ; source$D135: LDA #$00
.export BbOriginal_D137
BbOriginal_D137:
 adc $c024 ; source$D137: ADC $24
.export BbOriginal_D139
BbOriginal_D139:
 sta $c024 ; source$D139: STA $24
.export BbOriginal_D13B
BbOriginal_D13B:
 jmp BbOriginal_D0EA ; source$D13B: JMP $d0ea
.export BbOriginal_D13E
BbOriginal_D13E:
 sec  ; source$D13E: SEC
.export BbOriginal_D13F
BbOriginal_D13F:
 lda $c023 ; source$D13F: LDA $23
.export BbOriginal_D141
BbOriginal_D141:
 sbc #$20 ; source$D141: SBC #$20
.export BbOriginal_D143
BbOriginal_D143:
 jmp BbOriginal_D14B ; source$D143: JMP $d14b
.export BbOriginal_D146
BbOriginal_D146:
 sec  ; source$D146: SEC
.export BbOriginal_D147
BbOriginal_D147:
 lda $c023 ; source$D147: LDA $23
.export BbOriginal_D149
BbOriginal_D149:
 sbc #$40 ; source$D149: SBC #$40
.export BbOriginal_D14B
BbOriginal_D14B:
 sta $c023 ; source$D14B: STA $23
.export BbOriginal_D14D
BbOriginal_D14D:
 lda $c024 ; source$D14D: LDA $24
.export BbOriginal_D14F
BbOriginal_D14F:
 sbc #$00 ; source$D14F: SBC #$00
.export BbOriginal_D151
BbOriginal_D151:
 sta $c024 ; source$D151: STA $24
.export BbOriginal_D153
BbOriginal_D153:
 jmp BbOriginal_D0EA ; source$D153: JMP $d0ea
.export BbOriginal_D156
BbOriginal_D156:
 dec $c023 ; source$D156: DEC $23
.export BbOriginal_D158
BbOriginal_D158:
 jmp BbOriginal_D0EA ; source$D158: JMP $d0ea
.export BbOriginal_D15B
BbOriginal_D15B:
 dec $c023 ; source$D15B: DEC $23
.export BbOriginal_D15D
BbOriginal_D15D:
 dec $c023 ; source$D15D: DEC $23
.export BbOriginal_D15F
BbOriginal_D15F:
 jmp BbOriginal_D0EA ; source$D15F: JMP $d0ea
; Original bank7 $D18A..$D770
.export BbOriginal_D18A
BbOriginal_D18A:
 ldx #$2e ; source$D18A: LDX #$2e
.export BbOriginal_D18C
BbOriginal_D18C:
 jsr BbOriginal_D191 ; source$D18C: JSR $d191
.export BbOriginal_D18F
BbOriginal_D18F:
 ldx #$42 ; source$D18F: LDX #$42
.export BbOriginal_D191
BbOriginal_D191:
 lda #$00 ; source$D191: LDA #$00
.export BbOriginal_D193
BbOriginal_D193:
 sta $c003,x ; source$D193: STA $03,X
.export BbOriginal_D195
BbOriginal_D195:
 sta $c006,x ; source$D195: STA $06,X
.export BbOriginal_D197
BbOriginal_D197:
 sta $c013,x ; source$D197: STA $13,X
.export BbOriginal_D199
BbOriginal_D199:
 lda $c002,x ; source$D199: LDA $02,X
.export BbOriginal_D19B
BbOriginal_D19B:
 and #$3f ; source$D19B: AND #$3f
.export BbOriginal_D19D
BbOriginal_D19D:
 sta $c002,x ; source$D19D: STA $02,X
.export BbOriginal_D19F
BbOriginal_D19F:
 rts  ; source$D19F: RTS
.export BbOriginal_D1A0
BbOriginal_D1A0:
 lda $c000,y ; source$D1A0: LDA $0000,Y
.export BbOriginal_D1A3
BbOriginal_D1A3:
 and #$c0 ; source$D1A3: AND #$c0
.export BbOriginal_D1A5
BbOriginal_D1A5:
 lsr a ; source$D1A5: LSR A
.export BbOriginal_D1A6
BbOriginal_D1A6:
 lsr a ; source$D1A6: LSR A
.export BbOriginal_D1A7
BbOriginal_D1A7:
 sta $c001,x ; source$D1A7: STA $01,X
.export BbOriginal_D1A9
BbOriginal_D1A9:
 lda $c000,y ; source$D1A9: LDA $0000,Y
.export BbOriginal_D1AC
BbOriginal_D1AC:
 and #$03 ; source$D1AC: AND #$03
.export BbOriginal_D1AE
BbOriginal_D1AE:
 asl a ; source$D1AE: ASL A
.export BbOriginal_D1AF
BbOriginal_D1AF:
 asl a ; source$D1AF: ASL A
.export BbOriginal_D1B0
BbOriginal_D1B0:
 ora $c001,x ; source$D1B0: ORA $01,X
.export BbOriginal_D1B2
BbOriginal_D1B2:
 sta $c001,x ; source$D1B2: STA $01,X
.export BbOriginal_D1B4
BbOriginal_D1B4:
 lda $c002,y ; source$D1B4: LDA $0002,Y
.export BbOriginal_D1B7
BbOriginal_D1B7:
 and #$c3 ; source$D1B7: AND #$c3
.export BbOriginal_D1B9
BbOriginal_D1B9:
 ora $c001,x ; source$D1B9: ORA $01,X
.export BbOriginal_D1BB
BbOriginal_D1BB:
 sta $c001,x ; source$D1BB: STA $01,X
.export BbOriginal_D1BD
BbOriginal_D1BD:
 rts  ; source$D1BD: RTS
.export BbOriginal_D1BE
BbOriginal_D1BE:
 lda #$01 ; source$D1BE: LDA #$01
.export BbOriginal_D1C0
BbOriginal_D1C0:
 jsr BbImportYield ; source$D1C0: JSR $cee3
.export BbOriginal_D1C3
BbOriginal_D1C3:
 jsr BbOriginal_D28E ; source$D1C3: JSR $d28e
.export BbOriginal_D1C6
BbOriginal_D1C6:
 lda #$01 ; source$D1C6: LDA #$01
.export BbOriginal_D1C8
BbOriginal_D1C8:
 jsr BbImportYield ; source$D1C8: JSR $cee3
.export BbOriginal_D1CB
BbOriginal_D1CB:
 jsr BbOriginal_D24D ; source$D1CB: JSR $d24d
.export BbOriginal_D1CE
BbOriginal_D1CE:
 lda $c028 ; source$D1CE: LDA $28
.export BbOriginal_D1D0
BbOriginal_D1D0:
 jne BbOriginal_D1D6 ; source$D1D0: BNE $d1d6
.export BbOriginal_D1D2
BbOriginal_D1D2:
 lda #$03 ; source$D1D2: LDA #$03
.export BbOriginal_D1D4
BbOriginal_D1D4:
 sta $c028 ; source$D1D4: STA $28
.export BbOriginal_D1D6
BbOriginal_D1D6:
 ldx #$2e ; source$D1D6: LDX #$2e
.export BbOriginal_D1D8
BbOriginal_D1D8:
 ldy #$00 ; source$D1D8: LDY #$00
.export BbOriginal_D1DA
BbOriginal_D1DA:
 jsr BbOriginal_D1E7 ; source$D1DA: JSR $d1e7
.export BbOriginal_D1DD
BbOriginal_D1DD:
 ldx #$42 ; source$D1DD: LDX #$42
.export BbOriginal_D1DF
BbOriginal_D1DF:
 ldy #$08 ; source$D1DF: LDY #$08
.export BbOriginal_D1E1
BbOriginal_D1E1:
 jsr BbOriginal_D1E7 ; source$D1E1: JSR $d1e7
.export BbOriginal_D1E4
BbOriginal_D1E4:
 jmp BbOriginal_D1C6 ; source$D1E4: JMP $d1c6
.export BbOriginal_D1E7
BbOriginal_D1E7:
 lda $c013,x ; source$D1E7: LDA $13,X
.export BbOriginal_D1E9
BbOriginal_D1E9:
 jeq BbOriginal_D1F5 ; source$D1E9: BEQ $d1f5
.export BbOriginal_D1EB
BbOriginal_D1EB:
 dec $c013,x ; source$D1EB: DEC $13,X
.export BbOriginal_D1ED
BbOriginal_D1ED:
 lda #$16 ; source$D1ED: LDA #$16
.export BbOriginal_D1EF
BbOriginal_D1EF:
 jsr BbOriginal_D695 ; source$D1EF: JSR $d695
.export BbOriginal_D1F2
BbOriginal_D1F2:
 jmp BbOriginal_D709 ; source$D1F2: JMP $d709
.export BbOriginal_D1F5
BbOriginal_D1F5:
 lda $c000,x ; source$D1F5: LDA $00,X
.export BbOriginal_D1F7
BbOriginal_D1F7:
 jeq BbOriginal_D24C ; source$D1F7: BEQ $d24c
.export BbOriginal_D1F9
BbOriginal_D1F9:
 lda $c261 ; source$D1F9: LDA $0461
.export BbOriginal_D1FC
BbOriginal_D1FC:
 jne BbOriginal_D20D ; source$D1FC: BNE $d20d
.export BbOriginal_D1FE
BbOriginal_D1FE:
 tya  ; source$D1FE: TYA
.export BbOriginal_D1FF
BbOriginal_D1FF:
 pha  ; source$D1FF: PHA
.export BbOriginal_D200
BbOriginal_D200:
 ldy #$f5 ; source$D200: LDY #$f5
.export BbOriginal_D202
BbOriginal_D202:
 cmp #$00 ; source$D202: CMP #$00
.export BbOriginal_D204
BbOriginal_D204:
 jeq BbOriginal_D208 ; source$D204: BEQ $d208
.export BbOriginal_D206
BbOriginal_D206:
 ldy #$f6 ; source$D206: LDY #$f6
.export BbOriginal_D208
BbOriginal_D208:
 jsr BbOriginal_D1A0 ; source$D208: JSR $d1a0
.export BbOriginal_D20B
BbOriginal_D20B:
 pla  ; source$D20B: PLA
.export BbOriginal_D20C
BbOriginal_D20C:
 tay  ; source$D20C: TAY
.export BbOriginal_D20D
BbOriginal_D20D:
 lda $c003,x ; source$D20D: LDA $03,X
.export BbOriginal_D20F
BbOriginal_D20F:
 jmi BbOriginal_D22B ; source$D20F: BMI $d22b
.export BbOriginal_D211
BbOriginal_D211:
 jsr BbOriginal_D2C1 ; source$D211: JSR $d2c1
.export BbOriginal_D214
BbOriginal_D214:
 jsr BbOriginal_D457 ; source$D214: JSR $d457
.export BbOriginal_D217
BbOriginal_D217:
 jsr BbOriginal_D324 ; source$D217: JSR $d324
.export BbOriginal_D21A
BbOriginal_D21A:
 lda $c002,x ; source$D21A: LDA $02,X
.export BbOriginal_D21C
BbOriginal_D21C:
 and #$81 ; source$D21C: AND #$81
.export BbOriginal_D21E
BbOriginal_D21E:
 jeq BbOriginal_D223 ; source$D21E: BEQ $d223
.export BbOriginal_D220
BbOriginal_D220:
 jsr BbOriginal_D324 ; source$D220: JSR $d324
.export BbOriginal_D223
BbOriginal_D223:
 lda $c25f ; source$D223: LDA $045f
.export BbOriginal_D226
BbOriginal_D226:
 jeq BbOriginal_D22B ; source$D226: BEQ $d22b
.export BbOriginal_D228
BbOriginal_D228:
 jsr BbImportSpecialAbility ; source$D228: JSR $ee70
.export BbOriginal_D22B
BbOriginal_D22B:
 jsr BbOriginal_D40C ; source$D22B: JSR $d40c
.export BbOriginal_D22E
BbOriginal_D22E:
 jsr BbOriginal_D580 ; source$D22E: JSR $d580
.export BbOriginal_D231
BbOriginal_D231:
 lda $c012,x ; source$D231: LDA $12,X
.export BbOriginal_D233
BbOriginal_D233:
 jeq BbOriginal_D244 ; source$D233: BEQ $d244
.export BbOriginal_D235
BbOriginal_D235:
 cmp #$0a ; source$D235: CMP #$0a
.export BbOriginal_D237
BbOriginal_D237:
 jcc BbOriginal_D23D ; source$D237: BCC $d23d
.export BbOriginal_D239
BbOriginal_D239:
 sbc #$0a ; source$D239: SBC #$0a
.export BbOriginal_D23B
BbOriginal_D23B:
 ora #$10 ; source$D23B: ORA #$10
.export BbOriginal_D23D
BbOriginal_D23D:
 jsr BbImportScore ; source$D23D: JSR $c0a4
.export BbOriginal_D240
BbOriginal_D240:
 lda #$00 ; source$D240: LDA #$00
.export BbOriginal_D242
BbOriginal_D242:
 sta $c012,x ; source$D242: STA $12,X
.export BbOriginal_D244
BbOriginal_D244:
 lda $c262 ; source$D244: LDA $0462
.export BbOriginal_D247
BbOriginal_D247:
 jeq BbOriginal_D24C ; source$D247: BEQ $d24c
.export BbOriginal_D249
BbOriginal_D249:
 jsr BbImportBossPlayer ; source$D249: JSR $8153
.export BbOriginal_D24C
BbOriginal_D24C:
 rts  ; source$D24C: RTS
.export BbOriginal_D24D
BbOriginal_D24D:
 lda $c256 ; source$D24D: LDA $0456
.export BbOriginal_D250
BbOriginal_D250:
 jeq BbOriginal_D264 ; source$D250: BEQ $d264
.export BbOriginal_D252
BbOriginal_D252:
 lda $c029 ; source$D252: LDA $29
.export BbOriginal_D254
BbOriginal_D254:
 jne BbOriginal_D264 ; source$D254: BNE $d264
.export BbOriginal_D256
BbOriginal_D256:
 lda #$00 ; source$D256: LDA #$00
.export BbOriginal_D258
BbOriginal_D258:
 sta $c256 ; source$D258: STA $0456
.export BbOriginal_D25B
BbOriginal_D25B:
 lda $c257 ; source$D25B: LDA $0457
.export BbOriginal_D25E
BbOriginal_D25E:
 sta $c258 ; source$D25E: STA $0458
.export BbOriginal_D261
BbOriginal_D261:
 jsr BbOriginal_D278 ; source$D261: JSR $d278
.export BbOriginal_D264
BbOriginal_D264:
 lda $c259 ; source$D264: LDA $0459
.export BbOriginal_D267
BbOriginal_D267:
 jeq BbOriginal_D28D ; source$D267: BEQ $d28d
.export BbOriginal_D269
BbOriginal_D269:
 lda $c02a ; source$D269: LDA $2a
.export BbOriginal_D26B
BbOriginal_D26B:
 jne BbOriginal_D28D ; source$D26B: BNE $d28d
.export BbOriginal_D26D
BbOriginal_D26D:
 lda #$00 ; source$D26D: LDA #$00
.export BbOriginal_D26F
BbOriginal_D26F:
 sta $c259 ; source$D26F: STA $0459
.export BbOriginal_D272
BbOriginal_D272:
 lda $c25a ; source$D272: LDA $045a
.export BbOriginal_D275
BbOriginal_D275:
 sta $c25b ; source$D275: STA $045b
.export BbOriginal_D278
BbOriginal_D278:
 sec  ; source$D278: SEC
.export BbOriginal_D279
BbOriginal_D279:
 sbc #$03 ; source$D279: SBC #$03
.export BbOriginal_D27B
BbOriginal_D27B:
 jcc BbOriginal_D28D ; source$D27B: BCC $d28d
.export BbOriginal_D27D
BbOriginal_D27D:
 ldx $c02e ; source$D27D: LDX $2e
.export BbOriginal_D27F
BbOriginal_D27F:
 jeq BbOriginal_D286 ; source$D27F: BEQ $d286
.export BbOriginal_D281
BbOriginal_D281:
 ldx $c042 ; source$D281: LDX $42
.export BbOriginal_D283
BbOriginal_D283:
 jeq BbOriginal_D286 ; source$D283: BEQ $d286
.export BbOriginal_D285
BbOriginal_D285:
 asl a ; source$D285: ASL A
.export BbOriginal_D286
BbOriginal_D286:
 sec  ; source$D286: SEC
.export BbOriginal_D287
BbOriginal_D287:
 adc $c205 ; source$D287: ADC $0405
.export BbOriginal_D28A
BbOriginal_D28A:
 sta $c205 ; source$D28A: STA $0405
.export BbOriginal_D28D
BbOriginal_D28D:
 rts  ; source$D28D: RTS
.export BbOriginal_D28E
BbOriginal_D28E:
 lda $c02e ; source$D28E: LDA $2e
.export BbOriginal_D290
BbOriginal_D290:
 jeq BbOriginal_D29F ; source$D290: BEQ $d29f
.export BbOriginal_D292
BbOriginal_D292:
 ldx #$00 ; source$D292: LDX #$00
.export BbOriginal_D294
BbOriginal_D294:
 lda BbOriginal_D2B1,x ; source$D294: LDA $d2b1,X
.export BbOriginal_D297
BbOriginal_D297:
 sta $c100,x ; source$D297: STA $0200,X
.export BbOriginal_D29A
BbOriginal_D29A:
 inx  ; source$D29A: INX
.export BbOriginal_D29B
BbOriginal_D29B:
 cpx #$08 ; source$D29B: CPX #$08
.export BbOriginal_D29D
BbOriginal_D29D:
 jne BbOriginal_D294 ; source$D29D: BNE $d294
.export BbOriginal_D29F
BbOriginal_D29F:
 lda $c042 ; source$D29F: LDA $42
.export BbOriginal_D2A1
BbOriginal_D2A1:
 jeq BbOriginal_D2B0 ; source$D2A1: BEQ $d2b0
.export BbOriginal_D2A3
BbOriginal_D2A3:
 ldx #$00 ; source$D2A3: LDX #$00
.export BbOriginal_D2A5
BbOriginal_D2A5:
 lda BbOriginal_D2B9,x ; source$D2A5: LDA $d2b9,X
.export BbOriginal_D2A8
BbOriginal_D2A8:
 sta $c108,x ; source$D2A8: STA $0208,X
.export BbOriginal_D2AB
BbOriginal_D2AB:
 inx  ; source$D2AB: INX
.export BbOriginal_D2AC
BbOriginal_D2AC:
 cpx #$08 ; source$D2AC: CPX #$08
.export BbOriginal_D2AE
BbOriginal_D2AE:
 jne BbOriginal_D2A5 ; source$D2AE: BNE $d2a5
.export BbOriginal_D2B0
BbOriginal_D2B0:
 rts  ; source$D2B0: RTS
.export BbOriginal_D2B1
BbOriginal_D2B1:
 .byte $60
.export BbOriginal_D2B2
BbOriginal_D2B2:
 .byte $0a
.export BbOriginal_D2B3
BbOriginal_D2B3:
 .byte $43
.export BbOriginal_D2B4
BbOriginal_D2B4:
 .byte $60
.export BbOriginal_D2B5
BbOriginal_D2B5:
 .byte $60
.export BbOriginal_D2B6
BbOriginal_D2B6:
 .byte $00
.export BbOriginal_D2B7
BbOriginal_D2B7:
 .byte $43
.export BbOriginal_D2B8
BbOriginal_D2B8:
 .byte $68
.export BbOriginal_D2B9
BbOriginal_D2B9:
 .byte $80
.export BbOriginal_D2BA
BbOriginal_D2BA:
 .byte $00
.export BbOriginal_D2BB
BbOriginal_D2BB:
 .byte $00
.export BbOriginal_D2BC
BbOriginal_D2BC:
 .byte $90
.export BbOriginal_D2BD
BbOriginal_D2BD:
 .byte $80
.export BbOriginal_D2BE
BbOriginal_D2BE:
 .byte $0a
.export BbOriginal_D2BF
BbOriginal_D2BF:
 .byte $00
.export BbOriginal_D2C0
BbOriginal_D2C0:
 .byte $98
.export BbOriginal_D2C1
BbOriginal_D2C1:
 lda $c001,x ; source$D2C1: LDA $01,X
.export BbOriginal_D2C3
BbOriginal_D2C3:
 and #$10 ; source$D2C3: AND #$10
.export BbOriginal_D2C5
BbOriginal_D2C5:
 jeq BbOriginal_D2CA ; source$D2C5: BEQ $d2ca
.export BbOriginal_D2C7
BbOriginal_D2C7:
 jsr BbOriginal_D530 ; source$D2C7: JSR $d530
.export BbOriginal_D2CA
BbOriginal_D2CA:
 lda $c009,x ; source$D2CA: LDA $09,X
.export BbOriginal_D2CC
BbOriginal_D2CC:
 jeq BbOriginal_D2D5 ; source$D2CC: BEQ $d2d5
.export BbOriginal_D2CE
BbOriginal_D2CE:
 jsr BbOriginal_D331 ; source$D2CE: JSR $d331
.export BbOriginal_D2D1
BbOriginal_D2D1:
 lda #$00 ; source$D2D1: LDA #$00
.export BbOriginal_D2D3
BbOriginal_D2D3:
 sta $c009,x ; source$D2D3: STA $09,X
.export BbOriginal_D2D5
BbOriginal_D2D5:
 rts  ; source$D2D5: RTS
.export BbOriginal_D2D6
BbOriginal_D2D6:
 .byte $1c
.export BbOriginal_D2D7
BbOriginal_D2D7:
 .byte $00
.export BbOriginal_D2D8
BbOriginal_D2D8:
 .byte $00
.export BbOriginal_D2D9
BbOriginal_D2D9:
 .byte $00
.export BbOriginal_D2DA
BbOriginal_D2DA:
 .byte $01
.export BbOriginal_D2DB
BbOriginal_D2DB:
 .byte $00
.export BbOriginal_D2DC
BbOriginal_D2DC:
 .byte $01
.export BbOriginal_D2DD
BbOriginal_D2DD:
 .byte $01
.export BbOriginal_D2DE
BbOriginal_D2DE:
 .byte $01
.export BbOriginal_D2DF
BbOriginal_D2DF:
 .byte $01
.export BbOriginal_D2E0
BbOriginal_D2E0:
 .byte $01
.export BbOriginal_D2E1
BbOriginal_D2E1:
 .byte $01
.export BbOriginal_D2E2
BbOriginal_D2E2:
 .byte $01
.export BbOriginal_D2E3
BbOriginal_D2E3:
 .byte $01
.export BbOriginal_D2E4
BbOriginal_D2E4:
 .byte $02
.export BbOriginal_D2E5
BbOriginal_D2E5:
 .byte $02
.export BbOriginal_D2E6
BbOriginal_D2E6:
 .byte $02
.export BbOriginal_D2E7
BbOriginal_D2E7:
 .byte $02
.export BbOriginal_D2E8
BbOriginal_D2E8:
 .byte $02
.export BbOriginal_D2E9
BbOriginal_D2E9:
 .byte $02
.export BbOriginal_D2EA
BbOriginal_D2EA:
 .byte $02
.export BbOriginal_D2EB
BbOriginal_D2EB:
 .byte $02
.export BbOriginal_D2EC
BbOriginal_D2EC:
 .byte $02
.export BbOriginal_D2ED
BbOriginal_D2ED:
 .byte $02
.export BbOriginal_D2EE
BbOriginal_D2EE:
 .byte $03
.export BbOriginal_D2EF
BbOriginal_D2EF:
 .byte $03
.export BbOriginal_D2F0
BbOriginal_D2F0:
 .byte $03
.export BbOriginal_D2F1
BbOriginal_D2F1:
 .byte $03
.export BbOriginal_D2F2
BbOriginal_D2F2:
 .byte $02
.export BbOriginal_D2F3
BbOriginal_D2F3:
 lda $c004,x ; source$D2F3: LDA $04,X
.export BbOriginal_D2F5
BbOriginal_D2F5:
 stx $c026 ; source$D2F5: STX $26
.export BbOriginal_D2F7
BbOriginal_D2F7:
 tax  ; source$D2F7: TAX
.export BbOriginal_D2F8
BbOriginal_D2F8:
 lda BbOriginal_D2D7,x ; source$D2F8: LDA $d2d7,X
.export BbOriginal_D2FB
BbOriginal_D2FB:
 jeq BbOriginal_D314 ; source$D2FB: BEQ $d314
.export BbOriginal_D2FD
BbOriginal_D2FD:
 sta $c277 ; source$D2FD: STA $0477
.export BbOriginal_D300
BbOriginal_D300:
 ldx $c026 ; source$D300: LDX $26
.export BbOriginal_D302
BbOriginal_D302:
 lda $c100,y ; source$D302: LDA $0200,Y
.export BbOriginal_D305
BbOriginal_D305:
 and #$07 ; source$D305: AND #$07
.export BbOriginal_D307
BbOriginal_D307:
 jne BbOriginal_D30C ; source$D307: BNE $d30c
.export BbOriginal_D309
BbOriginal_D309:
 jsr BbOriginal_D3A7 ; source$D309: JSR $d3a7
.export BbOriginal_D30C
BbOriginal_D30C:
 jsr BbOriginal_D44E ; source$D30C: JSR $d44e
.export BbOriginal_D30F
BbOriginal_D30F:
 dec $c277 ; source$D30F: DEC $0477
.export BbOriginal_D312
BbOriginal_D312:
 jne BbOriginal_D302 ; source$D312: BNE $d302
.export BbOriginal_D314
BbOriginal_D314:
 ldx $c026 ; source$D314: LDX $26
.export BbOriginal_D316
BbOriginal_D316:
 inc $c004,x ; source$D316: INC $04,X
.export BbOriginal_D318
BbOriginal_D318:
 lda BbOriginal_D2D6 ; source$D318: LDA $d2d6
.export BbOriginal_D31B
BbOriginal_D31B:
 cmp $c004,x ; source$D31B: CMP $04,X
.export BbOriginal_D31D
BbOriginal_D31D:
 jne BbOriginal_D321 ; source$D31D: BNE $d321
.export BbOriginal_D31F
BbOriginal_D31F:
 inc $c003,x ; source$D31F: INC $03,X
.export BbOriginal_D321
BbOriginal_D321:
 jmp BbOriginal_D518 ; source$D321: JMP $d518
.export BbOriginal_D324
BbOriginal_D324:
 lda $c003,x ; source$D324: LDA $03,X
.export BbOriginal_D326
BbOriginal_D326:
 jeq BbOriginal_D365 ; source$D326: BEQ $d365
.export BbOriginal_D328
BbOriginal_D328:
 cmp #$01 ; source$D328: CMP #$01
.export BbOriginal_D32A
BbOriginal_D32A:
 jeq BbOriginal_D386 ; source$D32A: BEQ $d386
.export BbOriginal_D32C
BbOriginal_D32C:
 cmp #$02 ; source$D32C: CMP #$02
.export BbOriginal_D32E
BbOriginal_D32E:
 jeq BbOriginal_D2F3 ; source$D32E: BEQ $d2f3
.export BbOriginal_D330
BbOriginal_D330:
 rts  ; source$D330: RTS
.export BbOriginal_D331
BbOriginal_D331:
 lda $c003,x ; source$D331: LDA $03,X
.export BbOriginal_D333
BbOriginal_D333:
 jeq BbOriginal_D34E ; source$D333: BEQ $d34e
.export BbOriginal_D335
BbOriginal_D335:
 jmi BbOriginal_D34D ; source$D335: BMI $d34d
.export BbOriginal_D337
BbOriginal_D337:
 cmp #$01 ; source$D337: CMP #$01
.export BbOriginal_D339
BbOriginal_D339:
 jeq BbOriginal_D34D ; source$D339: BEQ $d34d
.export BbOriginal_D33B
BbOriginal_D33B:
 lda $c001,x ; source$D33B: LDA $01,X
.export BbOriginal_D33D
BbOriginal_D33D:
 and #$80 ; source$D33D: AND #$80
.export BbOriginal_D33F
BbOriginal_D33F:
 jeq BbOriginal_D34D ; source$D33F: BEQ $d34d
.export BbOriginal_D341
BbOriginal_D341:
 lda #$00 ; source$D341: LDA #$00
.export BbOriginal_D343
BbOriginal_D343:
 sta $c003,x ; source$D343: STA $03,X
.export BbOriginal_D345
BbOriginal_D345:
 inc $c237 ; source$D345: INC $0437
.export BbOriginal_D348
BbOriginal_D348:
 inc $c012,x ; source$D348: INC $12,X
.export BbOriginal_D34A
BbOriginal_D34A:
 jsr BbOriginal_D36B ; source$D34A: JSR $d36b
.export BbOriginal_D34D
BbOriginal_D34D:
 rts  ; source$D34D: RTS
.export BbOriginal_D34E
BbOriginal_D34E:
 lda $c009,x ; source$D34E: LDA $09,X
.export BbOriginal_D350
BbOriginal_D350:
 jpl BbOriginal_D34D ; source$D350: BPL $d34d
.export BbOriginal_D352
BbOriginal_D352:
 lda $c001,x ; source$D352: LDA $01,X
.export BbOriginal_D354
BbOriginal_D354:
 and #$03 ; source$D354: AND #$03
.export BbOriginal_D356
BbOriginal_D356:
 jne BbOriginal_D34D ; source$D356: BNE $d34d
.export BbOriginal_D358
BbOriginal_D358:
 lda $c102,y ; source$D358: LDA $0202,Y
.export BbOriginal_D35B
BbOriginal_D35B:
 and #$40 ; source$D35B: AND #$40
.export BbOriginal_D35D
BbOriginal_D35D:
 jne BbOriginal_D362 ; source$D35D: BNE $d362
.export BbOriginal_D35F
BbOriginal_D35F:
 jmp BbOriginal_D4BE ; source$D35F: JMP $d4be
.export BbOriginal_D362
BbOriginal_D362:
 jmp BbOriginal_D46D ; source$D362: JMP $d46d
.export BbOriginal_D365
BbOriginal_D365:
 lda $c001,x ; source$D365: LDA $01,X
.export BbOriginal_D367
BbOriginal_D367:
 and #$20 ; source$D367: AND #$20
.export BbOriginal_D369
BbOriginal_D369:
 jeq BbOriginal_D385 ; source$D369: BEQ $d385
.export BbOriginal_D36B
BbOriginal_D36B:
 lda $c001,x ; source$D36B: LDA $01,X
.export BbOriginal_D36D
BbOriginal_D36D:
 and #$03 ; source$D36D: AND #$03
.export BbOriginal_D36F
BbOriginal_D36F:
 sta $c005,x ; source$D36F: STA $05,X
.export BbOriginal_D371
BbOriginal_D371:
 inc $c003,x ; source$D371: INC $03,X
.export BbOriginal_D373
BbOriginal_D373:
 tya  ; source$D373: TYA
.export BbOriginal_D374
BbOriginal_D374:
 pha  ; source$D374: PHA
.export BbOriginal_D375
BbOriginal_D375:
 txa  ; source$D375: TXA
.export BbOriginal_D376
BbOriginal_D376:
 pha  ; source$D376: PHA
.export BbOriginal_D377
BbOriginal_D377:
 lda #$19 ; source$D377: LDA #$19
.export BbOriginal_D379
BbOriginal_D379:
 jsr BbImportSound ; source$D379: JSR $fa81
.export BbOriginal_D37C
BbOriginal_D37C:
 pla  ; source$D37C: PLA
.export BbOriginal_D37D
BbOriginal_D37D:
 tax  ; source$D37D: TAX
.export BbOriginal_D37E
BbOriginal_D37E:
 pla  ; source$D37E: PLA
.export BbOriginal_D37F
BbOriginal_D37F:
 tay  ; source$D37F: TAY
.export BbOriginal_D380
BbOriginal_D380:
 lda BbOriginal_D2D6 ; source$D380: LDA $d2d6
.export BbOriginal_D383
BbOriginal_D383:
 sta $c004,x ; source$D383: STA $04,X
.export BbOriginal_D385
BbOriginal_D385:
 rts  ; source$D385: RTS
.export BbOriginal_D386
BbOriginal_D386:
 lda $c004,x ; source$D386: LDA $04,X
.export BbOriginal_D388
BbOriginal_D388:
 stx $c025 ; source$D388: STX $25
.export BbOriginal_D38A
BbOriginal_D38A:
 tax  ; source$D38A: TAX
.export BbOriginal_D38B
BbOriginal_D38B:
 sec  ; source$D38B: SEC
.export BbOriginal_D38C
BbOriginal_D38C:
 lda $c100,y ; source$D38C: LDA $0200,Y
.export BbOriginal_D38F
BbOriginal_D38F:
 sbc BbOriginal_D2D6,x ; source$D38F: SBC $d2d6,X
.export BbOriginal_D392
BbOriginal_D392:
 sta $c100,y ; source$D392: STA $0200,Y
.export BbOriginal_D395
BbOriginal_D395:
 sta $c104,y ; source$D395: STA $0204,Y
.export BbOriginal_D398
BbOriginal_D398:
 ldx $c025 ; source$D398: LDX $25
.export BbOriginal_D39A
BbOriginal_D39A:
 dec $c004,x ; source$D39A: DEC $04,X
.export BbOriginal_D39C
BbOriginal_D39C:
 jne BbOriginal_D3A4 ; source$D39C: BNE $d3a4
.export BbOriginal_D39E
BbOriginal_D39E:
 inc $c003,x ; source$D39E: INC $03,X
.export BbOriginal_D3A0
BbOriginal_D3A0:
 lda #$00 ; source$D3A0: LDA #$00
.export BbOriginal_D3A2
BbOriginal_D3A2:
 sta $c009,x ; source$D3A2: STA $09,X
.export BbOriginal_D3A4
BbOriginal_D3A4:
 jmp BbOriginal_D518 ; source$D3A4: JMP $d518
.export BbOriginal_D3A7
BbOriginal_D3A7:
 jsr BbOriginal_D3C1 ; source$D3A7: JSR $d3c1
.export BbOriginal_D3AA
BbOriginal_D3AA:
 jeq BbOriginal_D3B4 ; source$D3AA: BEQ $d3b4
.export BbOriginal_D3AC
BbOriginal_D3AC:
 ldx $c026 ; source$D3AC: LDX $26
.export BbOriginal_D3AE
BbOriginal_D3AE:
 lda #$00 ; source$D3AE: LDA #$00
.export BbOriginal_D3B0
BbOriginal_D3B0:
 sta $c003,x ; source$D3B0: STA $03,X
.export BbOriginal_D3B2
BbOriginal_D3B2:
 pla  ; source$D3B2: PLA
.export BbOriginal_D3B3
BbOriginal_D3B3:
 pla  ; source$D3B3: PLA
.export BbOriginal_D3B4
BbOriginal_D3B4:
 rts  ; source$D3B4: RTS
.export BbOriginal_D3B5
BbOriginal_D3B5:
 lda $c100,y ; source$D3B5: LDA $0200,Y
.export BbOriginal_D3B8
BbOriginal_D3B8:
 cmp #$d0 ; source$D3B8: CMP #$d0
.export BbOriginal_D3BA
BbOriginal_D3BA:
 jcs BbOriginal_D42B ; source$D3BA: BCS $d42b
.export BbOriginal_D3BC
BbOriginal_D3BC:
 cmp #$10 ; source$D3BC: CMP #$10
.export BbOriginal_D3BE
BbOriginal_D3BE:
 jcc BbOriginal_D42B ; source$D3BE: BCC $d42b
.export BbOriginal_D3C0
BbOriginal_D3C0:
 rts  ; source$D3C0: RTS
.export BbOriginal_D3C1
BbOriginal_D3C1:
 jsr BbOriginal_D3B5 ; source$D3C1: JSR $d3b5
.export BbOriginal_D3C4
BbOriginal_D3C4:
 lda $c100,y ; source$D3C4: LDA $0200,Y
.export BbOriginal_D3C7
BbOriginal_D3C7:
 and #$07 ; source$D3C7: AND #$07
.export BbOriginal_D3C9
BbOriginal_D3C9:
 jne BbOriginal_D3F4 ; source$D3C9: BNE $d3f4
.export BbOriginal_D3CB
BbOriginal_D3CB:
 lda $c100,y ; source$D3CB: LDA $0200,Y
.export BbOriginal_D3CE
BbOriginal_D3CE:
 clc  ; source$D3CE: CLC
.export BbOriginal_D3CF
BbOriginal_D3CF:
 adc #$08 ; source$D3CF: ADC #$08
.export BbOriginal_D3D1
BbOriginal_D3D1:
 sta $c021 ; source$D3D1: STA $21
.export BbOriginal_D3D3
BbOriginal_D3D3:
 lda $c103,y ; source$D3D3: LDA $0203,Y
.export BbOriginal_D3D6
BbOriginal_D3D6:
 sta $c022 ; source$D3D6: STA $22
.export BbOriginal_D3D8
BbOriginal_D3D8:
 inc $c022 ; source$D3D8: INC $22
.export BbOriginal_D3DA
BbOriginal_D3DA:
 jsr BbOriginal_D0BE ; source$D3DA: JSR $d0be
.export BbOriginal_D3DD
BbOriginal_D3DD:
 jeq BbOriginal_D3F4 ; source$D3DD: BEQ $d3f4
.export BbOriginal_D3DF
BbOriginal_D3DF:
 jsr BbOriginal_D11E ; source$D3DF: JSR $d11e
.export BbOriginal_D3E2
BbOriginal_D3E2:
 jeq BbOriginal_D3F4 ; source$D3E2: BEQ $d3f4
.export BbOriginal_D3E4
BbOriginal_D3E4:
 lda $c022 ; source$D3E4: LDA $22
.export BbOriginal_D3E6
BbOriginal_D3E6:
 and #$04 ; source$D3E6: AND #$04
.export BbOriginal_D3E8
BbOriginal_D3E8:
 jne BbOriginal_D3FA ; source$D3E8: BNE $d3fa
.export BbOriginal_D3EA
BbOriginal_D3EA:
 jsr BbOriginal_D12A ; source$D3EA: JSR $d12a
.export BbOriginal_D3ED
BbOriginal_D3ED:
 jeq BbOriginal_D3F7 ; source$D3ED: BEQ $d3f7
.export BbOriginal_D3EF
BbOriginal_D3EF:
 jsr BbOriginal_D156 ; source$D3EF: JSR $d156
.export BbOriginal_D3F2
BbOriginal_D3F2:
 jeq BbOriginal_D3F7 ; source$D3F2: BEQ $d3f7
.export BbOriginal_D3F4
BbOriginal_D3F4:
 lda #$00 ; source$D3F4: LDA #$00
.export BbOriginal_D3F6
BbOriginal_D3F6:
 rts  ; source$D3F6: RTS
.export BbOriginal_D3F7
BbOriginal_D3F7:
 lda #$01 ; source$D3F7: LDA #$01
.export BbOriginal_D3F9
BbOriginal_D3F9:
 rts  ; source$D3F9: RTS
.export BbOriginal_D3FA
BbOriginal_D3FA:
 jsr BbOriginal_D11E ; source$D3FA: JSR $d11e
.export BbOriginal_D3FD
BbOriginal_D3FD:
 jeq BbOriginal_D3F4 ; source$D3FD: BEQ $d3f4
.export BbOriginal_D3FF
BbOriginal_D3FF:
 jsr BbOriginal_D12A ; source$D3FF: JSR $d12a
.export BbOriginal_D402
BbOriginal_D402:
 jeq BbOriginal_D3F7 ; source$D402: BEQ $d3f7
.export BbOriginal_D404
BbOriginal_D404:
 jsr BbOriginal_D156 ; source$D404: JSR $d156
.export BbOriginal_D407
BbOriginal_D407:
 jeq BbOriginal_D3F7 ; source$D407: BEQ $d3f7
.export BbOriginal_D409
BbOriginal_D409:
 jmp BbOriginal_D3EF ; source$D409: JMP $d3ef
.export BbOriginal_D40C
BbOriginal_D40C:
 lda $c003,x ; source$D40C: LDA $03,X
.export BbOriginal_D40E
BbOriginal_D40E:
 and #$7f ; source$D40E: AND #$7f
.export BbOriginal_D410
BbOriginal_D410:
 jeq BbOriginal_D417 ; source$D410: BEQ $d417
.export BbOriginal_D412
BbOriginal_D412:
 cmp #$03 ; source$D412: CMP #$03
.export BbOriginal_D414
BbOriginal_D414:
 jeq BbOriginal_D417 ; source$D414: BEQ $d417
.export BbOriginal_D416
BbOriginal_D416:
 rts  ; source$D416: RTS
.export BbOriginal_D417
BbOriginal_D417:
 jsr BbOriginal_D3C1 ; source$D417: JSR $d3c1
.export BbOriginal_D41A
BbOriginal_D41A:
 jeq BbOriginal_D423 ; source$D41A: BEQ $d423
.export BbOriginal_D41C
BbOriginal_D41C:
 lda $c003,x ; source$D41C: LDA $03,X
.export BbOriginal_D41E
BbOriginal_D41E:
 and #$80 ; source$D41E: AND #$80
.export BbOriginal_D420
BbOriginal_D420:
 sta $c003,x ; source$D420: STA $03,X
.export BbOriginal_D422
BbOriginal_D422:
 rts  ; source$D422: RTS
.export BbOriginal_D423
BbOriginal_D423:
 lda $c003,x ; source$D423: LDA $03,X
.export BbOriginal_D425
BbOriginal_D425:
 and #$80 ; source$D425: AND #$80
.export BbOriginal_D427
BbOriginal_D427:
 ora #$03 ; source$D427: ORA #$03
.export BbOriginal_D429
BbOriginal_D429:
 sta $c003,x ; source$D429: STA $03,X
.export BbOriginal_D42B
BbOriginal_D42B:
 lda $c100,y ; source$D42B: LDA $0200,Y
.export BbOriginal_D42E
BbOriginal_D42E:
 sta $c084 ; source$D42E: STA $84
.export BbOriginal_D430
BbOriginal_D430:
 inc $c084 ; source$D430: INC $84
.export BbOriginal_D432
BbOriginal_D432:
 lda $c002,x ; source$D432: LDA $02,X
.export BbOriginal_D434
BbOriginal_D434:
 and #$81 ; source$D434: AND #$81
.export BbOriginal_D436
BbOriginal_D436:
 jeq BbOriginal_D43E ; source$D436: BEQ $d43e
.export BbOriginal_D438
BbOriginal_D438:
 inc $c084 ; source$D438: INC $84
.export BbOriginal_D43A
BbOriginal_D43A:
 lsr $c084 ; source$D43A: LSR $84
.export BbOriginal_D43C
BbOriginal_D43C:
 asl $c084 ; source$D43C: ASL $84
.export BbOriginal_D43E
BbOriginal_D43E:
 lda $c084 ; source$D43E: LDA $84
.export BbOriginal_D440
BbOriginal_D440:
 sta $c100,y ; source$D440: STA $0200,Y
.export BbOriginal_D443
BbOriginal_D443:
 sta $c104,y ; source$D443: STA $0204,Y
.export BbOriginal_D446
BbOriginal_D446:
 cmp #$f4 ; source$D446: CMP #$f4
.export BbOriginal_D448
BbOriginal_D448:
 jne BbOriginal_D44D ; source$D448: BNE $d44d
.export BbOriginal_D44A
BbOriginal_D44A:
 inc $c23a ; source$D44A: INC $043a
.export BbOriginal_D44D
BbOriginal_D44D:
 rts  ; source$D44D: RTS
.export BbOriginal_D44E
BbOriginal_D44E:
 lda $c100,y ; source$D44E: LDA $0200,Y
.export BbOriginal_D451
BbOriginal_D451:
 clc  ; source$D451: CLC
.export BbOriginal_D452
BbOriginal_D452:
 adc #$01 ; source$D452: ADC #$01
.export BbOriginal_D454
BbOriginal_D454:
 jmp BbOriginal_D440 ; source$D454: JMP $d440
.export BbOriginal_D457
BbOriginal_D457:
 lda $c003,x ; source$D457: LDA $03,X
.export BbOriginal_D459
BbOriginal_D459:
 jmi BbOriginal_D4B8 ; source$D459: BMI $d4b8
.export BbOriginal_D45B
BbOriginal_D45B:
 jeq BbOriginal_D463 ; source$D45B: BEQ $d463
.export BbOriginal_D45D
BbOriginal_D45D:
 lda $c028 ; source$D45D: LDA $28
.export BbOriginal_D45F
BbOriginal_D45F:
 cmp #$01 ; source$D45F: CMP #$01
.export BbOriginal_D461
BbOriginal_D461:
 jne BbOriginal_D4B8 ; source$D461: BNE $d4b8
.export BbOriginal_D463
BbOriginal_D463:
 lda $c001,x ; source$D463: LDA $01,X
.export BbOriginal_D465
BbOriginal_D465:
 and #$03 ; source$D465: AND #$03
.export BbOriginal_D467
BbOriginal_D467:
 jeq BbOriginal_D4B8 ; source$D467: BEQ $d4b8
.export BbOriginal_D469
BbOriginal_D469:
 cmp #$01 ; source$D469: CMP #$01
.export BbOriginal_D46B
BbOriginal_D46B:
 jeq BbOriginal_D4BE ; source$D46B: BEQ $d4be
.export BbOriginal_D46D
BbOriginal_D46D:
 lda $c103,y ; source$D46D: LDA $0203,Y
.export BbOriginal_D470
BbOriginal_D470:
 sta $c022 ; source$D470: STA $22
.export BbOriginal_D472
BbOriginal_D472:
 dec $c022 ; source$D472: DEC $22
.export BbOriginal_D474
BbOriginal_D474:
 lda $c003,x ; source$D474: LDA $03,X
.export BbOriginal_D476
BbOriginal_D476:
 jne BbOriginal_D484 ; source$D476: BNE $d484
.export BbOriginal_D478
BbOriginal_D478:
 lda $c002,x ; source$D478: LDA $02,X
.export BbOriginal_D47A
BbOriginal_D47A:
 and #$81 ; source$D47A: AND #$81
.export BbOriginal_D47C
BbOriginal_D47C:
 jeq BbOriginal_D484 ; source$D47C: BEQ $d484
.export BbOriginal_D47E
BbOriginal_D47E:
 dec $c022 ; source$D47E: DEC $22
.export BbOriginal_D480
BbOriginal_D480:
 lsr $c022 ; source$D480: LSR $22
.export BbOriginal_D482
BbOriginal_D482:
 asl $c022 ; source$D482: ASL $22
.export BbOriginal_D484
BbOriginal_D484:
 lda $c100,y ; source$D484: LDA $0200,Y
.export BbOriginal_D487
BbOriginal_D487:
 cmp #$18 ; source$D487: CMP #$18
.export BbOriginal_D489
BbOriginal_D489:
 jcc BbOriginal_D4A9 ; source$D489: BCC $d4a9
.export BbOriginal_D48B
BbOriginal_D48B:
 cmp #$d0 ; source$D48B: CMP #$d0
.export BbOriginal_D48D
BbOriginal_D48D:
 jcs BbOriginal_D4A9 ; source$D48D: BCS $d4a9
.export BbOriginal_D48F
BbOriginal_D48F:
 clc  ; source$D48F: CLC
.export BbOriginal_D490
BbOriginal_D490:
 adc #$0f ; source$D490: ADC #$0f
.export BbOriginal_D492
BbOriginal_D492:
 sta $c021 ; source$D492: STA $21
.export BbOriginal_D494
BbOriginal_D494:
 jsr BbOriginal_D0BE ; source$D494: JSR $d0be
.export BbOriginal_D497
BbOriginal_D497:
 jne BbOriginal_D4A9 ; source$D497: BNE $d4a9
.export BbOriginal_D499
BbOriginal_D499:
 lda $c003,x ; source$D499: LDA $03,X
.export BbOriginal_D49B
BbOriginal_D49B:
 cmp #$01 ; source$D49B: CMP #$01
.export BbOriginal_D49D
BbOriginal_D49D:
 jne BbOriginal_D4B9 ; source$D49D: BNE $d4b9
.export BbOriginal_D49F
BbOriginal_D49F:
 jsr BbOriginal_D12A ; source$D49F: JSR $d12a
.export BbOriginal_D4A2
BbOriginal_D4A2:
 jeq BbOriginal_D4B9 ; source$D4A2: BEQ $d4b9
.export BbOriginal_D4A4
BbOriginal_D4A4:
 jsr BbOriginal_D146 ; source$D4A4: JSR $d146
.export BbOriginal_D4A7
BbOriginal_D4A7:
 jeq BbOriginal_D4B9 ; source$D4A7: BEQ $d4b9
.export BbOriginal_D4A9
BbOriginal_D4A9:
 lda $c022 ; source$D4A9: LDA $22
.export BbOriginal_D4AB
BbOriginal_D4AB:
 cmp #$11 ; source$D4AB: CMP #$11
.export BbOriginal_D4AD
BbOriginal_D4AD:
 jcc BbOriginal_D4B9 ; source$D4AD: BCC $d4b9
.export BbOriginal_D4AF
BbOriginal_D4AF:
 sta $c103,y ; source$D4AF: STA $0203,Y
.export BbOriginal_D4B2
BbOriginal_D4B2:
 clc  ; source$D4B2: CLC
.export BbOriginal_D4B3
BbOriginal_D4B3:
 adc #$08 ; source$D4B3: ADC #$08
.export BbOriginal_D4B5
BbOriginal_D4B5:
 sta $c107,y ; source$D4B5: STA $0207,Y
.export BbOriginal_D4B8
BbOriginal_D4B8:
 rts  ; source$D4B8: RTS
.export BbOriginal_D4B9
BbOriginal_D4B9:
 lda #$00 ; source$D4B9: LDA #$00
.export BbOriginal_D4BB
BbOriginal_D4BB:
 sta $c005,x ; source$D4BB: STA $05,X
.export BbOriginal_D4BD
BbOriginal_D4BD:
 rts  ; source$D4BD: RTS
.export BbOriginal_D4BE
BbOriginal_D4BE:
 lda $c103,y ; source$D4BE: LDA $0203,Y
.export BbOriginal_D4C1
BbOriginal_D4C1:
 clc  ; source$D4C1: CLC
.export BbOriginal_D4C2
BbOriginal_D4C2:
 adc #$0f ; source$D4C2: ADC #$0f
.export BbOriginal_D4C4
BbOriginal_D4C4:
 sta $c022 ; source$D4C4: STA $22
.export BbOriginal_D4C6
BbOriginal_D4C6:
 inc $c022 ; source$D4C6: INC $22
.export BbOriginal_D4C8
BbOriginal_D4C8:
 lda $c003,x ; source$D4C8: LDA $03,X
.export BbOriginal_D4CA
BbOriginal_D4CA:
 jne BbOriginal_D4D8 ; source$D4CA: BNE $d4d8
.export BbOriginal_D4CC
BbOriginal_D4CC:
 lda $c002,x ; source$D4CC: LDA $02,X
.export BbOriginal_D4CE
BbOriginal_D4CE:
 and #$81 ; source$D4CE: AND #$81
.export BbOriginal_D4D0
BbOriginal_D4D0:
 jeq BbOriginal_D4D8 ; source$D4D0: BEQ $d4d8
.export BbOriginal_D4D2
BbOriginal_D4D2:
 inc $c022 ; source$D4D2: INC $22
.export BbOriginal_D4D4
BbOriginal_D4D4:
 lsr $c022 ; source$D4D4: LSR $22
.export BbOriginal_D4D6
BbOriginal_D4D6:
 asl $c022 ; source$D4D6: ASL $22
.export BbOriginal_D4D8
BbOriginal_D4D8:
 lda $c100,y ; source$D4D8: LDA $0200,Y
.export BbOriginal_D4DB
BbOriginal_D4DB:
 cmp #$18 ; source$D4DB: CMP #$18
.export BbOriginal_D4DD
BbOriginal_D4DD:
 jcc BbOriginal_D4FD ; source$D4DD: BCC $d4fd
.export BbOriginal_D4DF
BbOriginal_D4DF:
 cmp #$d0 ; source$D4DF: CMP #$d0
.export BbOriginal_D4E1
BbOriginal_D4E1:
 jcs BbOriginal_D4FD ; source$D4E1: BCS $d4fd
.export BbOriginal_D4E3
BbOriginal_D4E3:
 clc  ; source$D4E3: CLC
.export BbOriginal_D4E4
BbOriginal_D4E4:
 adc #$0f ; source$D4E4: ADC #$0f
.export BbOriginal_D4E6
BbOriginal_D4E6:
 sta $c021 ; source$D4E6: STA $21
.export BbOriginal_D4E8
BbOriginal_D4E8:
 jsr BbOriginal_D0BE ; source$D4E8: JSR $d0be
.export BbOriginal_D4EB
BbOriginal_D4EB:
 jne BbOriginal_D4FD ; source$D4EB: BNE $d4fd
.export BbOriginal_D4ED
BbOriginal_D4ED:
 lda $c003,x ; source$D4ED: LDA $03,X
.export BbOriginal_D4EF
BbOriginal_D4EF:
 cmp #$01 ; source$D4EF: CMP #$01
.export BbOriginal_D4F1
BbOriginal_D4F1:
 jne BbOriginal_D4B9 ; source$D4F1: BNE $d4b9
.export BbOriginal_D4F3
BbOriginal_D4F3:
 jsr BbOriginal_D12A ; source$D4F3: JSR $d12a
.export BbOriginal_D4F6
BbOriginal_D4F6:
 jeq BbOriginal_D4B9 ; source$D4F6: BEQ $d4b9
.export BbOriginal_D4F8
BbOriginal_D4F8:
 jsr BbOriginal_D146 ; source$D4F8: JSR $d146
.export BbOriginal_D4FB
BbOriginal_D4FB:
 jeq BbOriginal_D4B9 ; source$D4FB: BEQ $d4b9
.export BbOriginal_D4FD
BbOriginal_D4FD:
 lda $c022 ; source$D4FD: LDA $22
.export BbOriginal_D4FF
BbOriginal_D4FF:
 cmp #$f0 ; source$D4FF: CMP #$f0
.export BbOriginal_D501
BbOriginal_D501:
 jcs BbOriginal_D4B9 ; source$D501: BCS $d4b9
.export BbOriginal_D503
BbOriginal_D503:
 sbc #$06 ; source$D503: SBC #$06
.export BbOriginal_D505
BbOriginal_D505:
 sta $c107,y ; source$D505: STA $0207,Y
.export BbOriginal_D508
BbOriginal_D508:
 sec  ; source$D508: SEC
.export BbOriginal_D509
BbOriginal_D509:
 sbc #$08 ; source$D509: SBC #$08
.export BbOriginal_D50B
BbOriginal_D50B:
 sta $c103,y ; source$D50B: STA $0203,Y
.export BbOriginal_D50E
BbOriginal_D50E:
 rts  ; source$D50E: RTS
.export BbOriginal_D50F
BbOriginal_D50F:
 lda $c005,x ; source$D50F: LDA $05,X
.export BbOriginal_D511
BbOriginal_D511:
 cmp #$01 ; source$D511: CMP #$01
.export BbOriginal_D513
BbOriginal_D513:
 jeq BbOriginal_D4BE ; source$D513: BEQ $d4be
.export BbOriginal_D515
BbOriginal_D515:
 jmp BbOriginal_D46D ; source$D515: JMP $d46d
.export BbOriginal_D518
BbOriginal_D518:
 lda $c005,x ; source$D518: LDA $05,X
.export BbOriginal_D51A
BbOriginal_D51A:
 jeq BbOriginal_D528 ; source$D51A: BEQ $d528
.export BbOriginal_D51C
BbOriginal_D51C:
 lda $c002,x ; source$D51C: LDA $02,X
.export BbOriginal_D51E
BbOriginal_D51E:
 and #$81 ; source$D51E: AND #$81
.export BbOriginal_D520
BbOriginal_D520:
 jne BbOriginal_D529 ; source$D520: BNE $d529
.export BbOriginal_D522
BbOriginal_D522:
 lda $c01f ; source$D522: LDA $1f
.export BbOriginal_D524
BbOriginal_D524:
 and #$01 ; source$D524: AND #$01
.export BbOriginal_D526
BbOriginal_D526:
 jne BbOriginal_D50F ; source$D526: BNE $d50f
.export BbOriginal_D528
BbOriginal_D528:
 rts  ; source$D528: RTS
.export BbOriginal_D529
BbOriginal_D529:
 lda $c01f ; source$D529: LDA $1f
.export BbOriginal_D52B
BbOriginal_D52B:
 and #$03 ; source$D52B: AND #$03
.export BbOriginal_D52D
BbOriginal_D52D:
 jne BbOriginal_D50F ; source$D52D: BNE $d50f
.export BbOriginal_D52F
BbOriginal_D52F:
 rts  ; source$D52F: RTS
.export BbOriginal_D530
BbOriginal_D530:
 lda $c008,x ; source$D530: LDA $08,X
.export BbOriginal_D532
BbOriginal_D532:
 jne BbOriginal_D54D ; source$D532: BNE $d54d
.export BbOriginal_D534
BbOriginal_D534:
 lda #$19 ; source$D534: LDA #$19
.export BbOriginal_D536
BbOriginal_D536:
 sta $c008,x ; source$D536: STA $08,X
.export BbOriginal_D538
BbOriginal_D538:
 lda $c002,x ; source$D538: LDA $02,X
.export BbOriginal_D53A
BbOriginal_D53A:
 and #$04 ; source$D53A: AND #$04
.export BbOriginal_D53C
BbOriginal_D53C:
 jeq BbOriginal_D540 ; source$D53C: BEQ $d540
.export BbOriginal_D53E
BbOriginal_D53E:
 lsr $c008,x ; source$D53E: LSR $08,X
.export BbOriginal_D540
BbOriginal_D540:
 lda #$80 ; source$D540: LDA #$80
.export BbOriginal_D542
BbOriginal_D542:
 cpx #$2e ; source$D542: CPX #$2e
.export BbOriginal_D544
BbOriginal_D544:
 jeq BbOriginal_D547 ; source$D544: BEQ $d547
.export BbOriginal_D546
BbOriginal_D546:
 lsr a ; source$D546: LSR A
.export BbOriginal_D547
BbOriginal_D547:
 ora $c264 ; source$D547: ORA $0464
.export BbOriginal_D54A
BbOriginal_D54A:
 sta $c264 ; source$D54A: STA $0464
.export BbOriginal_D54D
BbOriginal_D54D:
 rts  ; source$D54D: RTS
.export BbOriginal_D54E
BbOriginal_D54E:
 stx $c278 ; source$D54E: STX $0478
.export BbOriginal_D551
BbOriginal_D551:
 ldx #$2e ; source$D551: LDX #$2e
.export BbOriginal_D553
BbOriginal_D553:
 lda $c011,x ; source$D553: LDA $11,X
.export BbOriginal_D555
BbOriginal_D555:
 jne BbOriginal_D574 ; source$D555: BNE $d574
.export BbOriginal_D557
BbOriginal_D557:
 lda #$c8 ; source$D557: LDA #$c8
.export BbOriginal_D559
BbOriginal_D559:
 sta $c011,x ; source$D559: STA $11,X
.export BbOriginal_D55B
BbOriginal_D55B:
 lda #$80 ; source$D55B: LDA #$80
.export BbOriginal_D55D
BbOriginal_D55D:
 sta $c003,x ; source$D55D: STA $03,X
.export BbOriginal_D55F
BbOriginal_D55F:
 lda #$00 ; source$D55F: LDA #$00
.export BbOriginal_D561
BbOriginal_D561:
 sta $c007,x ; source$D561: STA $07,X
.export BbOriginal_D563
BbOriginal_D563:
 lda #$0a ; source$D563: LDA #$0a
.export BbOriginal_D565
BbOriginal_D565:
 sta $c006,x ; source$D565: STA $06,X
.export BbOriginal_D567
BbOriginal_D567:
 tya  ; source$D567: TYA
.export BbOriginal_D568
BbOriginal_D568:
 pha  ; source$D568: PHA
.export BbOriginal_D569
BbOriginal_D569:
 txa  ; source$D569: TXA
.export BbOriginal_D56A
BbOriginal_D56A:
 pha  ; source$D56A: PHA
.export BbOriginal_D56B
BbOriginal_D56B:
 lda #$11 ; source$D56B: LDA #$11
.export BbOriginal_D56D
BbOriginal_D56D:
 jsr BbImportSound ; source$D56D: JSR $fa81
.export BbOriginal_D570
BbOriginal_D570:
 pla  ; source$D570: PLA
.export BbOriginal_D571
BbOriginal_D571:
 tax  ; source$D571: TAX
.export BbOriginal_D572
BbOriginal_D572:
 pla  ; source$D572: PLA
.export BbOriginal_D573
BbOriginal_D573:
 tay  ; source$D573: TAY
.export BbOriginal_D574
BbOriginal_D574:
 ldx $c278 ; source$D574: LDX $0478
.export BbOriginal_D577
BbOriginal_D577:
 rts  ; source$D577: RTS
.export BbOriginal_D578
BbOriginal_D578:
 stx $c278 ; source$D578: STX $0478
.export BbOriginal_D57B
BbOriginal_D57B:
 ldx #$42 ; source$D57B: LDX #$42
.export BbOriginal_D57D
BbOriginal_D57D:
 jmp BbOriginal_D553 ; source$D57D: JMP $d553
.export BbOriginal_D580
BbOriginal_D580:
 jsr BbOriginal_D5D4 ; source$D580: JSR $d5d4
.export BbOriginal_D583
BbOriginal_D583:
 inc $c007,x ; source$D583: INC $07,X
.export BbOriginal_D585
BbOriginal_D585:
 lda $c006,x ; source$D585: LDA $06,X
.export BbOriginal_D587
BbOriginal_D587:
 cmp #$0b ; source$D587: CMP #$0b
.export BbOriginal_D589
BbOriginal_D589:
 jcs BbOriginal_D5C2 ; source$D589: BCS $d5c2
.export BbOriginal_D58B
BbOriginal_D58B:
 jsr BbOriginal_D709 ; source$D58B: JSR $d709
.export BbOriginal_D58E
BbOriginal_D58E:
 lda $c011,x ; source$D58E: LDA $11,X
.export BbOriginal_D590
BbOriginal_D590:
 jeq BbOriginal_D5A4 ; source$D590: BEQ $d5a4
.export BbOriginal_D592
BbOriginal_D592:
 dec $c011,x ; source$D592: DEC $11,X
.export BbOriginal_D594
BbOriginal_D594:
 and #$01 ; source$D594: AND #$01
.export BbOriginal_D596
BbOriginal_D596:
 jne BbOriginal_D5A4 ; source$D596: BNE $d5a4
.export BbOriginal_D598
BbOriginal_D598:
 lda #$27 ; source$D598: LDA #$27
.export BbOriginal_D59A
BbOriginal_D59A:
 sta $c101,y ; source$D59A: STA $0201,Y
.export BbOriginal_D59D
BbOriginal_D59D:
 sta $c105,y ; source$D59D: STA $0205,Y
.export BbOriginal_D5A0
BbOriginal_D5A0:
 lda #$0b ; source$D5A0: LDA #$0b
.export BbOriginal_D5A2
BbOriginal_D5A2:
 sta $c006,x ; source$D5A2: STA $06,X
.export BbOriginal_D5A4
BbOriginal_D5A4:
 lda $c01f ; source$D5A4: LDA $1f
.export BbOriginal_D5A6
BbOriginal_D5A6:
 and #$04 ; source$D5A6: AND #$04
.export BbOriginal_D5A8
BbOriginal_D5A8:
 jeq BbOriginal_D5C2 ; source$D5A8: BEQ $d5c2
.export BbOriginal_D5AA
BbOriginal_D5AA:
 lda $c002,x ; source$D5AA: LDA $02,X
.export BbOriginal_D5AC
BbOriginal_D5AC:
 and #$80 ; source$D5AC: AND #$80
.export BbOriginal_D5AE
BbOriginal_D5AE:
 jeq BbOriginal_D5C3 ; source$D5AE: BEQ $d5c3
.export BbOriginal_D5B0
BbOriginal_D5B0:
 lda $c102,y ; source$D5B0: LDA $0202,Y
.export BbOriginal_D5B3
BbOriginal_D5B3:
 ror a ; source$D5B3: ROR A
.export BbOriginal_D5B4
BbOriginal_D5B4:
 jcc BbOriginal_D5BA ; source$D5B4: BCC $d5ba
.export BbOriginal_D5B6
BbOriginal_D5B6:
 clc  ; source$D5B6: CLC
.export BbOriginal_D5B7
BbOriginal_D5B7:
 jmp BbOriginal_D5BB ; source$D5B7: JMP $d5bb
.export BbOriginal_D5BA
BbOriginal_D5BA:
 sec  ; source$D5BA: SEC
.export BbOriginal_D5BB
BbOriginal_D5BB:
 rol a ; source$D5BB: ROL A
.export BbOriginal_D5BC
BbOriginal_D5BC:
 sta $c102,y ; source$D5BC: STA $0202,Y
.export BbOriginal_D5BF
BbOriginal_D5BF:
 sta $c106,y ; source$D5BF: STA $0206,Y
.export BbOriginal_D5C2
BbOriginal_D5C2:
 rts  ; source$D5C2: RTS
.export BbOriginal_D5C3
BbOriginal_D5C3:
 lda $c102,y ; source$D5C3: LDA $0202,Y
.export BbOriginal_D5C6
BbOriginal_D5C6:
 ror a ; source$D5C6: ROR A
.export BbOriginal_D5C7
BbOriginal_D5C7:
 ror a ; source$D5C7: ROR A
.export BbOriginal_D5C8
BbOriginal_D5C8:
 lda $c102,y ; source$D5C8: LDA $0202,Y
.export BbOriginal_D5CB
BbOriginal_D5CB:
 and #$fc ; source$D5CB: AND #$fc
.export BbOriginal_D5CD
BbOriginal_D5CD:
 jcc BbOriginal_D5BC ; source$D5CD: BCC $d5bc
.export BbOriginal_D5CF
BbOriginal_D5CF:
 ora #$03 ; source$D5CF: ORA #$03
.export BbOriginal_D5D1
BbOriginal_D5D1:
 jmp BbOriginal_D5BC ; source$D5D1: JMP $d5bc
.export BbOriginal_D5D4
BbOriginal_D5D4:
 lda $c008,x ; source$D5D4: LDA $08,X
.export BbOriginal_D5D6
BbOriginal_D5D6:
 jne BbOriginal_D608 ; source$D5D6: BNE $d608
.export BbOriginal_D5D8
BbOriginal_D5D8:
 lda $c003,x ; source$D5D8: LDA $03,X
.export BbOriginal_D5DA
BbOriginal_D5DA:
 jmi BbOriginal_D628 ; source$D5DA: BMI $d628
.export BbOriginal_D5DC
BbOriginal_D5DC:
 jeq BbOriginal_D615 ; source$D5DC: BEQ $d615
.export BbOriginal_D5DE
BbOriginal_D5DE:
 cmp #$01 ; source$D5DE: CMP #$01
.export BbOriginal_D5E0
BbOriginal_D5E0:
 jeq BbOriginal_D5EB ; source$D5E0: BEQ $d5eb
.export BbOriginal_D5E2
BbOriginal_D5E2:
 lda $c007,x ; source$D5E2: LDA $07,X
.export BbOriginal_D5E4
BbOriginal_D5E4:
 and #$10 ; source$D5E4: AND #$10
.export BbOriginal_D5E6
BbOriginal_D5E6:
 ora #$80 ; source$D5E6: ORA #$80
.export BbOriginal_D5E8
BbOriginal_D5E8:
 jmp BbOriginal_D61F ; source$D5E8: JMP $d61f
.export BbOriginal_D5EB
BbOriginal_D5EB:
 lda $c007,x ; source$D5EB: LDA $07,X
.export BbOriginal_D5ED
BbOriginal_D5ED:
 and #$10 ; source$D5ED: AND #$10
.export BbOriginal_D5EF
BbOriginal_D5EF:
 ora #$60 ; source$D5EF: ORA #$60
.export BbOriginal_D5F1
BbOriginal_D5F1:
 jmp BbOriginal_D61F ; source$D5F1: JMP $d61f
.export BbOriginal_D5F4
BbOriginal_D5F4:
 and #$0c ; source$D5F4: AND #$0c
.export BbOriginal_D5F6
BbOriginal_D5F6:
 jeq BbOriginal_D5FC ; source$D5F6: BEQ $d5fc
.export BbOriginal_D5F8
BbOriginal_D5F8:
 lda #$00 ; source$D5F8: LDA #$00
.export BbOriginal_D5FA
BbOriginal_D5FA:
 sta $c007,x ; source$D5FA: STA $07,X
.export BbOriginal_D5FC
BbOriginal_D5FC:
 lda $c007,x ; source$D5FC: LDA $07,X
.export BbOriginal_D5FE
BbOriginal_D5FE:
 and #$18 ; source$D5FE: AND #$18
.export BbOriginal_D600
BbOriginal_D600:
 lsr a ; source$D600: LSR A
.export BbOriginal_D601
BbOriginal_D601:
 lsr a ; source$D601: LSR A
.export BbOriginal_D602
BbOriginal_D602:
 lsr a ; source$D602: LSR A
.export BbOriginal_D603
BbOriginal_D603:
 adc #$01 ; source$D603: ADC #$01
.export BbOriginal_D605
BbOriginal_D605:
 jmp BbOriginal_D623 ; source$D605: JMP $d623
.export BbOriginal_D608
BbOriginal_D608:
 dec $c008,x ; source$D608: DEC $08,X
.export BbOriginal_D60A
BbOriginal_D60A:
 lda $c008,x ; source$D60A: LDA $08,X
.export BbOriginal_D60C
BbOriginal_D60C:
 and #$f8 ; source$D60C: AND #$f8
.export BbOriginal_D60E
BbOriginal_D60E:
 jeq BbOriginal_D5D8 ; source$D60E: BEQ $d5d8
.export BbOriginal_D610
BbOriginal_D610:
 lda #$0a ; source$D610: LDA #$0a
.export BbOriginal_D612
BbOriginal_D612:
 jmp BbOriginal_D623 ; source$D612: JMP $d623
.export BbOriginal_D615
BbOriginal_D615:
 lda $c001,x ; source$D615: LDA $01,X
.export BbOriginal_D617
BbOriginal_D617:
 and #$0f ; source$D617: AND #$0f
.export BbOriginal_D619
BbOriginal_D619:
 jne BbOriginal_D5F4 ; source$D619: BNE $d5f4
.export BbOriginal_D61B
BbOriginal_D61B:
 lda $c007,x ; source$D61B: LDA $07,X
.export BbOriginal_D61D
BbOriginal_D61D:
 and #$10 ; source$D61D: AND #$10
.export BbOriginal_D61F
BbOriginal_D61F:
 lsr a ; source$D61F: LSR A
.export BbOriginal_D620
BbOriginal_D620:
 lsr a ; source$D620: LSR A
.export BbOriginal_D621
BbOriginal_D621:
 lsr a ; source$D621: LSR A
.export BbOriginal_D622
BbOriginal_D622:
 lsr a ; source$D622: LSR A
.export BbOriginal_D623
BbOriginal_D623:
 cmp $c006,x ; source$D623: CMP $06,X
.export BbOriginal_D625
BbOriginal_D625:
 jne BbOriginal_D693 ; source$D625: BNE $d693
.export BbOriginal_D627
BbOriginal_D627:
 rts  ; source$D627: RTS
.export BbOriginal_D628
BbOriginal_D628:
 lda $c007,x ; source$D628: LDA $07,X
.export BbOriginal_D62A
BbOriginal_D62A:
 and #$07 ; source$D62A: AND #$07
.export BbOriginal_D62C
BbOriginal_D62C:
 jne BbOriginal_D627 ; source$D62C: BNE $d627
.export BbOriginal_D62E
BbOriginal_D62E:
 inc $c006,x ; source$D62E: INC $06,X
.export BbOriginal_D630
BbOriginal_D630:
 lda $c006,x ; source$D630: LDA $06,X
.export BbOriginal_D632
BbOriginal_D632:
 cmp #$16 ; source$D632: CMP #$16
.export BbOriginal_D634
BbOriginal_D634:
 jne BbOriginal_D6AF ; source$D634: BNE $d6af
.export BbOriginal_D636
BbOriginal_D636:
 lda #$00 ; source$D636: LDA #$00
.export BbOriginal_D638
BbOriginal_D638:
 sta $c002,x ; source$D638: STA $02,X
.export BbOriginal_D63A
BbOriginal_D63A:
 dec $c000,x ; source$D63A: DEC $00,X
.export BbOriginal_D63C
BbOriginal_D63C:
 jeq BbOriginal_D65B ; source$D63C: BEQ $d65b
.export BbOriginal_D63E
BbOriginal_D63E:
 cpx #$2e ; source$D63E: CPX #$2e
.export BbOriginal_D640
BbOriginal_D640:
 jne BbOriginal_D64C ; source$D640: BNE $d64c
.export BbOriginal_D642
BbOriginal_D642:
 lda #$18 ; source$D642: LDA #$18
.export BbOriginal_D644
BbOriginal_D644:
 sta $c103,y ; source$D644: STA $0203,Y
.export BbOriginal_D647
BbOriginal_D647:
 lda #$20 ; source$D647: LDA #$20
.export BbOriginal_D649
BbOriginal_D649:
 jmp BbOriginal_D653 ; source$D649: JMP $d653
.export BbOriginal_D64C
BbOriginal_D64C:
 lda #$d8 ; source$D64C: LDA #$d8
.export BbOriginal_D64E
BbOriginal_D64E:
 sta $c103,y ; source$D64E: STA $0203,Y
.export BbOriginal_D651
BbOriginal_D651:
 lda #$e0 ; source$D651: LDA #$e0
.export BbOriginal_D653
BbOriginal_D653:
 sta $c107,y ; source$D653: STA $0207,Y
.export BbOriginal_D656
BbOriginal_D656:
 lda #$c0 ; source$D656: LDA #$c0
.export BbOriginal_D658
BbOriginal_D658:
 jmp BbOriginal_D66A ; source$D658: JMP $d66a
.export BbOriginal_D65B
BbOriginal_D65B:
 cpx #$2e ; source$D65B: CPX #$2e
.export BbOriginal_D65D
BbOriginal_D65D:
 jeq BbOriginal_D665 ; source$D65D: BEQ $d665
.export BbOriginal_D65F
BbOriginal_D65F:
 sta $c2a2 ; source$D65F: STA $04a2
.export BbOriginal_D662
BbOriginal_D662:
 jmp BbOriginal_D668 ; source$D662: JMP $d668
.export BbOriginal_D665
BbOriginal_D665:
 sta $c2a1 ; source$D665: STA $04a1
.export BbOriginal_D668
BbOriginal_D668:
 lda #$f4 ; source$D668: LDA #$f4
.export BbOriginal_D66A
BbOriginal_D66A:
 sta $c100,y ; source$D66A: STA $0200,Y
.export BbOriginal_D66D
BbOriginal_D66D:
 sta $c104,y ; source$D66D: STA $0204,Y
.export BbOriginal_D670
BbOriginal_D670:
 lda #$00 ; source$D670: LDA #$00
.export BbOriginal_D672
BbOriginal_D672:
 sta $c003,x ; source$D672: STA $03,X
.export BbOriginal_D674
BbOriginal_D674:
 lda #$43 ; source$D674: LDA #$43
.export BbOriginal_D676
BbOriginal_D676:
 cpx #$2e ; source$D676: CPX #$2e
.export BbOriginal_D678
BbOriginal_D678:
 jeq BbOriginal_D67C ; source$D678: BEQ $d67c
.export BbOriginal_D67A
BbOriginal_D67A:
 lda #$00 ; source$D67A: LDA #$00
.export BbOriginal_D67C
BbOriginal_D67C:
 sta $c102,y ; source$D67C: STA $0202,Y
.export BbOriginal_D67F
BbOriginal_D67F:
 sta $c106,y ; source$D67F: STA $0206,Y
.export BbOriginal_D682
BbOriginal_D682:
 lda #$16 ; source$D682: LDA #$16
.export BbOriginal_D684
BbOriginal_D684:
 jsr BbOriginal_D693 ; source$D684: JSR $d693
.export BbOriginal_D687
BbOriginal_D687:
 jsr BbImportLivesUI ; source$D687: JSR $c470
.export BbOriginal_D68A
BbOriginal_D68A:
 lda $c262 ; source$D68A: LDA $0462
.export BbOriginal_D68D
BbOriginal_D68D:
 jeq BbOriginal_D692 ; source$D68D: BEQ $d692
.export BbOriginal_D68F
BbOriginal_D68F:
 jmp BbImportBossDeath ; source$D68F: JMP $8156
.export BbOriginal_D692
BbOriginal_D692:
 rts  ; source$D692: RTS
.export BbOriginal_D693
BbOriginal_D693:
 sta $c006,x ; source$D693: STA $06,X
.export BbOriginal_D695
BbOriginal_D695:
 stx $c026 ; source$D695: STX $26
.export BbOriginal_D697
BbOriginal_D697:
 asl a ; source$D697: ASL A
.export BbOriginal_D698
BbOriginal_D698:
 tax  ; source$D698: TAX
.export BbOriginal_D699
BbOriginal_D699:
 lda $c102,y ; source$D699: LDA $0202,Y
.export BbOriginal_D69C
BbOriginal_D69C:
 and #$40 ; source$D69C: AND #$40
.export BbOriginal_D69E
BbOriginal_D69E:
 jne BbOriginal_D6E7 ; source$D69E: BNE $d6e7
.export BbOriginal_D6A0
BbOriginal_D6A0:
 lda BbOriginal_D743,x ; source$D6A0: LDA $d743,X
.export BbOriginal_D6A3
BbOriginal_D6A3:
 sta $c101,y ; source$D6A3: STA $0201,Y
.export BbOriginal_D6A6
BbOriginal_D6A6:
 lda BbOriginal_D744,x ; source$D6A6: LDA $d744,X
.export BbOriginal_D6A9
BbOriginal_D6A9:
 sta $c105,y ; source$D6A9: STA $0205,Y
.export BbOriginal_D6AC
BbOriginal_D6AC:
 ldx $c026 ; source$D6AC: LDX $26
.export BbOriginal_D6AE
BbOriginal_D6AE:
 rts  ; source$D6AE: RTS
.export BbOriginal_D6AF
BbOriginal_D6AF:
 sta $c006,x ; source$D6AF: STA $06,X
.export BbOriginal_D6B1
BbOriginal_D6B1:
 stx $c026 ; source$D6B1: STX $26
.export BbOriginal_D6B3
BbOriginal_D6B3:
 asl a ; source$D6B3: ASL A
.export BbOriginal_D6B4
BbOriginal_D6B4:
 tax  ; source$D6B4: TAX
.export BbOriginal_D6B5
BbOriginal_D6B5:
 lda BbOriginal_D744,x ; source$D6B5: LDA $d744,X
.export BbOriginal_D6B8
BbOriginal_D6B8:
 cmp #$ff ; source$D6B8: CMP #$ff
.export BbOriginal_D6BA
BbOriginal_D6BA:
 jeq BbOriginal_D6F3 ; source$D6BA: BEQ $d6f3
.export BbOriginal_D6BC
BbOriginal_D6BC:
 lda $c102,y ; source$D6BC: LDA $0202,Y
.export BbOriginal_D6BF
BbOriginal_D6BF:
 and #$03 ; source$D6BF: AND #$03
.export BbOriginal_D6C1
BbOriginal_D6C1:
 ora BbOriginal_D744,x ; source$D6C1: ORA $d744,X
.export BbOriginal_D6C4
BbOriginal_D6C4:
 sta $c102,y ; source$D6C4: STA $0202,Y
.export BbOriginal_D6C7
BbOriginal_D6C7:
 sta $c106,y ; source$D6C7: STA $0206,Y
.export BbOriginal_D6CA
BbOriginal_D6CA:
 jmi BbOriginal_D6D8 ; source$D6CA: BMI $d6d8
.export BbOriginal_D6CC
BbOriginal_D6CC:
 lda BbOriginal_D743,x ; source$D6CC: LDA $d743,X
.export BbOriginal_D6CF
BbOriginal_D6CF:
 sta $c101,y ; source$D6CF: STA $0201,Y
.export BbOriginal_D6D2
BbOriginal_D6D2:
 clc  ; source$D6D2: CLC
.export BbOriginal_D6D3
BbOriginal_D6D3:
 adc #$02 ; source$D6D3: ADC #$02
.export BbOriginal_D6D5
BbOriginal_D6D5:
 jmp BbOriginal_D6A9 ; source$D6D5: JMP $d6a9
.export BbOriginal_D6D8
BbOriginal_D6D8:
 lda BbOriginal_D743,x ; source$D6D8: LDA $d743,X
.export BbOriginal_D6DB
BbOriginal_D6DB:
 sta $c105,y ; source$D6DB: STA $0205,Y
.export BbOriginal_D6DE
BbOriginal_D6DE:
 clc  ; source$D6DE: CLC
.export BbOriginal_D6DF
BbOriginal_D6DF:
 adc #$02 ; source$D6DF: ADC #$02
.export BbOriginal_D6E1
BbOriginal_D6E1:
 sta $c101,y ; source$D6E1: STA $0201,Y
.export BbOriginal_D6E4
BbOriginal_D6E4:
 ldx $c026 ; source$D6E4: LDX $26
.export BbOriginal_D6E6
BbOriginal_D6E6:
 rts  ; source$D6E6: RTS
.export BbOriginal_D6E7
BbOriginal_D6E7:
 lda BbOriginal_D744,x ; source$D6E7: LDA $d744,X
.export BbOriginal_D6EA
BbOriginal_D6EA:
 sta $c101,y ; source$D6EA: STA $0201,Y
.export BbOriginal_D6ED
BbOriginal_D6ED:
 lda BbOriginal_D743,x ; source$D6ED: LDA $d743,X
.export BbOriginal_D6F0
BbOriginal_D6F0:
 jmp BbOriginal_D6A9 ; source$D6F0: JMP $d6a9
.export BbOriginal_D6F3
BbOriginal_D6F3:
 lda $c102,y ; source$D6F3: LDA $0202,Y
.export BbOriginal_D6F6
BbOriginal_D6F6:
 and #$03 ; source$D6F6: AND #$03
.export BbOriginal_D6F8
BbOriginal_D6F8:
 sta $c102,y ; source$D6F8: STA $0202,Y
.export BbOriginal_D6FB
BbOriginal_D6FB:
 ora #$40 ; source$D6FB: ORA #$40
.export BbOriginal_D6FD
BbOriginal_D6FD:
 sta $c106,y ; source$D6FD: STA $0206,Y
.export BbOriginal_D700
BbOriginal_D700:
 lda BbOriginal_D743,x ; source$D700: LDA $d743,X
.export BbOriginal_D703
BbOriginal_D703:
 sta $c101,y ; source$D703: STA $0201,Y
.export BbOriginal_D706
BbOriginal_D706:
 jmp BbOriginal_D6A9 ; source$D706: JMP $d6a9
.export BbOriginal_D709
BbOriginal_D709:
 lda $c001,x ; source$D709: LDA $01,X
.export BbOriginal_D70B
BbOriginal_D70B:
 and #$03 ; source$D70B: AND #$03
.export BbOriginal_D70D
BbOriginal_D70D:
 jeq BbOriginal_D733 ; source$D70D: BEQ $d733
.export BbOriginal_D70F
BbOriginal_D70F:
 cmp #$01 ; source$D70F: CMP #$01
.export BbOriginal_D711
BbOriginal_D711:
 jeq BbOriginal_D734 ; source$D711: BEQ $d734
.export BbOriginal_D713
BbOriginal_D713:
 lda $c102,y ; source$D713: LDA $0202,Y
.export BbOriginal_D716
BbOriginal_D716:
 and #$40 ; source$D716: AND #$40
.export BbOriginal_D718
BbOriginal_D718:
 jeq BbOriginal_D733 ; source$D718: BEQ $d733
.export BbOriginal_D71A
BbOriginal_D71A:
 lda $c102,y ; source$D71A: LDA $0202,Y
.export BbOriginal_D71D
BbOriginal_D71D:
 and #$bf ; source$D71D: AND #$bf
.export BbOriginal_D71F
BbOriginal_D71F:
 sta $c102,y ; source$D71F: STA $0202,Y
.export BbOriginal_D722
BbOriginal_D722:
 sta $c106,y ; source$D722: STA $0206,Y
.export BbOriginal_D725
BbOriginal_D725:
 lda $c101,y ; source$D725: LDA $0201,Y
.export BbOriginal_D728
BbOriginal_D728:
 pha  ; source$D728: PHA
.export BbOriginal_D729
BbOriginal_D729:
 lda $c105,y ; source$D729: LDA $0205,Y
.export BbOriginal_D72C
BbOriginal_D72C:
 sta $c101,y ; source$D72C: STA $0201,Y
.export BbOriginal_D72F
BbOriginal_D72F:
 pla  ; source$D72F: PLA
.export BbOriginal_D730
BbOriginal_D730:
 sta $c105,y ; source$D730: STA $0205,Y
.export BbOriginal_D733
BbOriginal_D733:
 rts  ; source$D733: RTS
.export BbOriginal_D734
BbOriginal_D734:
 lda $c102,y ; source$D734: LDA $0202,Y
.export BbOriginal_D737
BbOriginal_D737:
 and #$40 ; source$D737: AND #$40
.export BbOriginal_D739
BbOriginal_D739:
 jne BbOriginal_D733 ; source$D739: BNE $d733
.export BbOriginal_D73B
BbOriginal_D73B:
 lda $c102,y ; source$D73B: LDA $0202,Y
.export BbOriginal_D73E
BbOriginal_D73E:
 ora #$40 ; source$D73E: ORA #$40
.export BbOriginal_D740
BbOriginal_D740:
 jmp BbOriginal_D71F ; source$D740: JMP $d71f
.export BbOriginal_D743
BbOriginal_D743:
 .byte $00
.export BbOriginal_D744
BbOriginal_D744:
 .byte $0a
.export BbOriginal_D745
BbOriginal_D745:
 .byte $00
.export BbOriginal_D746
BbOriginal_D746:
 .byte $0c
.export BbOriginal_D747
BbOriginal_D747:
 .byte $00
.export BbOriginal_D748
BbOriginal_D748:
 .byte $0a
.export BbOriginal_D749
BbOriginal_D749:
 .byte $02
.export BbOriginal_D74A
BbOriginal_D74A:
 .byte $0c
.export BbOriginal_D74B
BbOriginal_D74B:
 .byte $04
.export BbOriginal_D74C
BbOriginal_D74C:
 .byte $0a
.export BbOriginal_D74D
BbOriginal_D74D:
 .byte $02
.export BbOriginal_D74E
BbOriginal_D74E:
 .byte $0c
.export BbOriginal_D74F
BbOriginal_D74F:
 .byte $06
.export BbOriginal_D750
BbOriginal_D750:
 .byte $0a
.export BbOriginal_D751
BbOriginal_D751:
 .byte $06
.export BbOriginal_D752
BbOriginal_D752:
 .byte $0e
.export BbOriginal_D753
BbOriginal_D753:
 .byte $08
.export BbOriginal_D754
BbOriginal_D754:
 .byte $0a
.export BbOriginal_D755
BbOriginal_D755:
 .byte $08
.export BbOriginal_D756
BbOriginal_D756:
 .byte $0e
.export BbOriginal_D757
BbOriginal_D757:
 .byte $10
.export BbOriginal_D758
BbOriginal_D758:
 .byte $12
.export BbOriginal_D759
BbOriginal_D759:
 .byte $14
.export BbOriginal_D75A
BbOriginal_D75A:
 .byte $00
.export BbOriginal_D75B
BbOriginal_D75B:
 .byte $18
.export BbOriginal_D75C
BbOriginal_D75C:
 .byte $00
.export BbOriginal_D75D
BbOriginal_D75D:
 .byte $14
.export BbOriginal_D75E
BbOriginal_D75E:
 .byte $c0
.export BbOriginal_D75F
BbOriginal_D75F:
 .byte $18
.export BbOriginal_D760
BbOriginal_D760:
 .byte $c0
.export BbOriginal_D761
BbOriginal_D761:
 .byte $14
.export BbOriginal_D762
BbOriginal_D762:
 .byte $00
.export BbOriginal_D763
BbOriginal_D763:
 .byte $18
.export BbOriginal_D764
BbOriginal_D764:
 .byte $00
.export BbOriginal_D765
BbOriginal_D765:
 .byte $14
.export BbOriginal_D766
BbOriginal_D766:
 .byte $c0
.export BbOriginal_D767
BbOriginal_D767:
 .byte $18
.export BbOriginal_D768
BbOriginal_D768:
 .byte $c0
.export BbOriginal_D769
BbOriginal_D769:
 .byte $1c
.export BbOriginal_D76A
BbOriginal_D76A:
 .byte $ff
.export BbOriginal_D76B
BbOriginal_D76B:
 .byte $1e
.export BbOriginal_D76C
BbOriginal_D76C:
 .byte $ff
.export BbOriginal_D76D
BbOriginal_D76D:
 .byte $27
.export BbOriginal_D76E
BbOriginal_D76E:
 .byte $ff
.export BbOriginal_D76F
BbOriginal_D76F:
 .byte $14
.export BbOriginal_D770
BbOriginal_D770:
 .byte $16
; Original bank7 $D882..$E008
.export BbOriginal_D882
BbOriginal_D882:
 lda #$01 ; source$D882: LDA #$01
.export BbOriginal_D884
BbOriginal_D884:
 jsr BbImportYield ; source$D884: JSR $cee3
.export BbOriginal_D887
BbOriginal_D887:
 ldx #$88 ; source$D887: LDX #$88
.export BbOriginal_D889
BbOriginal_D889:
 ldy #$88 ; source$D889: LDY #$88
.export BbOriginal_D88B
BbOriginal_D88B:
 lda $c000,x ; source$D88B: LDA $00,X
.export BbOriginal_D88D
BbOriginal_D88D:
 jeq BbOriginal_D900 ; source$D88D: BEQ $d900
.export BbOriginal_D88F
BbOriginal_D88F:
 cmp #$ff ; source$D88F: CMP #$ff
.export BbOriginal_D891
BbOriginal_D891:
 jeq BbImportFoodUpdate ; source$D891: BEQ $d870
.export BbOriginal_D893
BbOriginal_D893:
 cmp #$f6 ; source$D893: CMP #$f6
.export BbOriginal_D895
BbOriginal_D895:
 jeq BbImportElementalUpdate ; source$D895: BEQ $d873
.export BbOriginal_D897
BbOriginal_D897:
 cmp #$f7 ; source$D897: CMP #$f7
.export BbOriginal_D899
BbOriginal_D899:
 jeq BbImportElementalUpdate ; source$D899: BEQ $d873
.export BbOriginal_D89B
BbOriginal_D89B:
 cmp #$f8 ; source$D89B: CMP #$f8
.export BbOriginal_D89D
BbOriginal_D89D:
 jeq BbImportElementalUpdate ; source$D89D: BEQ $d873
.export BbOriginal_D89F
BbOriginal_D89F:
 jsr BbOriginal_DA00 ; source$D89F: JSR $da00
.export BbOriginal_D8A2
BbOriginal_D8A2:
 jsr BbOriginal_DAD7 ; source$D8A2: JSR $dad7
.export BbOriginal_D8A5
BbOriginal_D8A5:
 lda $c000,x ; source$D8A5: LDA $00,X
.export BbOriginal_D8A7
BbOriginal_D8A7:
 jpl BbOriginal_D8B3 ; source$D8A7: BPL $d8b3
.export BbOriginal_D8A9
BbOriginal_D8A9:
 lda $c100,y ; source$D8A9: LDA $0200,Y
.export BbOriginal_D8AC
BbOriginal_D8AC:
 cmp #$f4 ; source$D8AC: CMP #$f4
.export BbOriginal_D8AE
BbOriginal_D8AE:
 jne BbOriginal_D8B3 ; source$D8AE: BNE $d8b3
.export BbOriginal_D8B0
BbOriginal_D8B0:
 jsr BbOriginal_DAA4 ; source$D8B0: JSR $daa4
.export BbOriginal_D8B3
BbOriginal_D8B3:
 jsr BbOriginal_C39E ; source$D8B3: JSR $c39e
.export BbOriginal_D8B6
BbOriginal_D8B6:
 cpx #$c4 ; source$D8B6: CPX #$c4
.export BbOriginal_D8B8
BbOriginal_D8B8:
 jne BbOriginal_D88B ; source$D8B8: BNE $d88b
.export BbOriginal_D8BA
BbOriginal_D8BA:
 lda $c262 ; source$D8BA: LDA $0462
.export BbOriginal_D8BD
BbOriginal_D8BD:
 jne BbOriginal_D8D7 ; source$D8BD: BNE $d8d7
.export BbOriginal_D8BF
BbOriginal_D8BF:
 ldx #$68 ; source$D8BF: LDX #$68
.export BbOriginal_D8C1
BbOriginal_D8C1:
 ldy #$10 ; source$D8C1: LDY #$10
.export BbOriginal_D8C3
BbOriginal_D8C3:
 lda $c000,x ; source$D8C3: LDA $00,X
.export BbOriginal_D8C5
BbOriginal_D8C5:
 jeq BbOriginal_D8D0 ; source$D8C5: BEQ $d8d0
.export BbOriginal_D8C7
BbOriginal_D8C7:
 lda $c002,x ; source$D8C7: LDA $02,X
.export BbOriginal_D8C9
BbOriginal_D8C9:
 and #$10 ; source$D8C9: AND #$10
.export BbOriginal_D8CB
BbOriginal_D8CB:
 jeq BbOriginal_D8D0 ; source$D8CB: BEQ $d8d0
.export BbOriginal_D8CD
BbOriginal_D8CD:
 jsr BbOriginal_DAE4 ; source$D8CD: JSR $dae4
.export BbOriginal_D8D0
BbOriginal_D8D0:
 jsr BbOriginal_C39E ; source$D8D0: JSR $c39e
.export BbOriginal_D8D3
BbOriginal_D8D3:
 cpx #$84 ; source$D8D3: CPX #$84
.export BbOriginal_D8D5
BbOriginal_D8D5:
 jne BbOriginal_D8C3 ; source$D8D5: BNE $d8c3
.export BbOriginal_D8D7
BbOriginal_D8D7:
 dec $c244 ; source$D8D7: DEC $0444
.export BbOriginal_D8DA
BbOriginal_D8DA:
 jpl BbOriginal_D8E7 ; source$D8DA: BPL $d8e7
.export BbOriginal_D8DC
BbOriginal_D8DC:
 lda $c25d ; source$D8DC: LDA $045d
.export BbOriginal_D8DF
BbOriginal_D8DF:
 sta $c244 ; source$D8DF: STA $0444
.export BbOriginal_D8E2
BbOriginal_D8E2:
 jpl BbOriginal_D8E7 ; source$D8E2: BPL $d8e7
.export BbOriginal_D8E4
BbOriginal_D8E4:
 inc $c244 ; source$D8E4: INC $0444
.export BbOriginal_D8E7
BbOriginal_D8E7:
 lda $c207 ; source$D8E7: LDA $0407
.export BbOriginal_D8EA
BbOriginal_D8EA:
 jeq BbOriginal_D8F4 ; source$D8EA: BEQ $d8f4
.export BbOriginal_D8EC
BbOriginal_D8EC:
 jsr BbImportStageEffects ; source$D8EC: JSR $e009
.export BbOriginal_D8EF
BbOriginal_D8EF:
 lda #$00 ; source$D8EF: LDA #$00
.export BbOriginal_D8F1
BbOriginal_D8F1:
 sta $c207 ; source$D8F1: STA $0407
.export BbOriginal_D8F4
BbOriginal_D8F4:
 jsr BbOriginal_DD6D ; source$D8F4: JSR $dd6d
.export BbOriginal_D8F7
BbOriginal_D8F7:
 jsr BbOriginal_DD24 ; source$D8F7: JSR $dd24
.export BbOriginal_D8FA
BbOriginal_D8FA:
 jsr BbImportStageBubbles ; source$D8FA: JSR $f01e
.export BbOriginal_D8FD
BbOriginal_D8FD:
 rts ; source tick tail JMP $D882 becomes one bounded update return
.export BbOriginal_D900
BbOriginal_D900:
 lda $c264 ; source$D900: LDA $0464
.export BbOriginal_D903
BbOriginal_D903:
 jeq BbOriginal_D8B3 ; source$D903: BEQ $d8b3
.export BbOriginal_D905
BbOriginal_D905:
 jpl BbOriginal_D957 ; source$D905: BPL $d957
.export BbOriginal_D907
BbOriginal_D907:
 and #$7f ; source$D907: AND #$7f
.export BbOriginal_D909
BbOriginal_D909:
 sta $c264 ; source$D909: STA $0464
.export BbOriginal_D90C
BbOriginal_D90C:
 inc $c000,x ; source$D90C: INC $00,X
.export BbOriginal_D90E
BbOriginal_D90E:
 lda $c260 ; source$D90E: LDA $0460
.export BbOriginal_D911
BbOriginal_D911:
 jeq BbOriginal_D919 ; source$D911: BEQ $d919
.export BbOriginal_D913
BbOriginal_D913:
 lda $c030 ; source$D913: LDA $30
.export BbOriginal_D915
BbOriginal_D915:
 and #$08 ; source$D915: AND #$08
.export BbOriginal_D917
BbOriginal_D917:
 jne BbOriginal_D98C ; source$D917: BNE $d98c
.export BbOriginal_D919
BbOriginal_D919:
 lda #$03 ; source$D919: LDA #$03
.export BbOriginal_D91B
BbOriginal_D91B:
 sta $c102,y ; source$D91B: STA $0202,Y
.export BbOriginal_D91E
BbOriginal_D91E:
 sta $c106,y ; source$D91E: STA $0206,Y
.export BbOriginal_D921
BbOriginal_D921:
 lda $c100 ; source$D921: LDA $0200
.export BbOriginal_D924
BbOriginal_D924:
 sta $c100,y ; source$D924: STA $0200,Y
.export BbOriginal_D927
BbOriginal_D927:
 sta $c104,y ; source$D927: STA $0204,Y
.export BbOriginal_D92A
BbOriginal_D92A:
 lda $c103 ; source$D92A: LDA $0203
.export BbOriginal_D92D
BbOriginal_D92D:
 sta $c103,y ; source$D92D: STA $0203,Y
.export BbOriginal_D930
BbOriginal_D930:
 lda $c107 ; source$D930: LDA $0207
.export BbOriginal_D933
BbOriginal_D933:
 sta $c107,y ; source$D933: STA $0207,Y
.export BbOriginal_D936
BbOriginal_D936:
 lda $c102 ; source$D936: LDA $0202
.export BbOriginal_D939
BbOriginal_D939:
 and #$40 ; source$D939: AND #$40
.export BbOriginal_D93B
BbOriginal_D93B:
 sta $c001,x ; source$D93B: STA $01,X
.export BbOriginal_D93D
BbOriginal_D93D:
 lda #$08 ; source$D93D: LDA #$08
.export BbOriginal_D93F
BbOriginal_D93F:
 sta $c003,x ; source$D93F: STA $03,X
.export BbOriginal_D941
BbOriginal_D941:
 tya  ; source$D941: TYA
.export BbOriginal_D942
BbOriginal_D942:
 pha  ; source$D942: PHA
.export BbOriginal_D943
BbOriginal_D943:
 txa  ; source$D943: TXA
.export BbOriginal_D944
BbOriginal_D944:
 pha  ; source$D944: PHA
.export BbOriginal_D945
BbOriginal_D945:
 lda #$16 ; source$D945: LDA #$16
.export BbOriginal_D947
BbOriginal_D947:
 jsr BbImportSound ; source$D947: JSR $fa81
.export BbOriginal_D94A
BbOriginal_D94A:
 pla  ; source$D94A: PLA
.export BbOriginal_D94B
BbOriginal_D94B:
 tax  ; source$D94B: TAX
.export BbOriginal_D94C
BbOriginal_D94C:
 pla  ; source$D94C: PLA
.export BbOriginal_D94D
BbOriginal_D94D:
 tay  ; source$D94D: TAY
.export BbOriginal_D94E
BbOriginal_D94E:
 inc $c235 ; source$D94E: INC $0435
.export BbOriginal_D951
BbOriginal_D951:
 jsr BbOriginal_DF54 ; source$D951: JSR $df54
.export BbOriginal_D954
BbOriginal_D954:
 jmp BbOriginal_D89F ; source$D954: JMP $d89f
.export BbOriginal_D957
BbOriginal_D957:
 and #$bf ; source$D957: AND #$bf
.export BbOriginal_D959
BbOriginal_D959:
 sta $c264 ; source$D959: STA $0464
.export BbOriginal_D95C
BbOriginal_D95C:
 inc $c000,x ; source$D95C: INC $00,X
.export BbOriginal_D95E
BbOriginal_D95E:
 lda $c260 ; source$D95E: LDA $0460
.export BbOriginal_D961
BbOriginal_D961:
 jeq BbOriginal_D969 ; source$D961: BEQ $d969
.export BbOriginal_D963
BbOriginal_D963:
 lda $c044 ; source$D963: LDA $44
.export BbOriginal_D965
BbOriginal_D965:
 and #$08 ; source$D965: AND #$08
.export BbOriginal_D967
BbOriginal_D967:
 jne BbOriginal_D9DF ; source$D967: BNE $d9df
.export BbOriginal_D969
BbOriginal_D969:
 lda #$00 ; source$D969: LDA #$00
.export BbOriginal_D96B
BbOriginal_D96B:
 sta $c102,y ; source$D96B: STA $0202,Y
.export BbOriginal_D96E
BbOriginal_D96E:
 sta $c106,y ; source$D96E: STA $0206,Y
.export BbOriginal_D971
BbOriginal_D971:
 lda $c108 ; source$D971: LDA $0208
.export BbOriginal_D974
BbOriginal_D974:
 sta $c100,y ; source$D974: STA $0200,Y
.export BbOriginal_D977
BbOriginal_D977:
 sta $c104,y ; source$D977: STA $0204,Y
.export BbOriginal_D97A
BbOriginal_D97A:
 lda $c10b ; source$D97A: LDA $020b
.export BbOriginal_D97D
BbOriginal_D97D:
 sta $c103,y ; source$D97D: STA $0203,Y
.export BbOriginal_D980
BbOriginal_D980:
 lda $c10f ; source$D980: LDA $020f
.export BbOriginal_D983
BbOriginal_D983:
 sta $c107,y ; source$D983: STA $0207,Y
.export BbOriginal_D986
BbOriginal_D986:
 lda $c10a ; source$D986: LDA $020a
.export BbOriginal_D989
BbOriginal_D989:
 jmp BbOriginal_D939 ; source$D989: JMP $d939
.export BbOriginal_D98C
BbOriginal_D98C:
 lda $c100 ; source$D98C: LDA $0200
.export BbOriginal_D98F
BbOriginal_D98F:
 sta $c100,y ; source$D98F: STA $0200,Y
.export BbOriginal_D992
BbOriginal_D992:
 sta $c104,y ; source$D992: STA $0204,Y
.export BbOriginal_D995
BbOriginal_D995:
 lda $c103 ; source$D995: LDA $0203
.export BbOriginal_D998
BbOriginal_D998:
 sta $c103,y ; source$D998: STA $0203,Y
.export BbOriginal_D99B
BbOriginal_D99B:
 lda $c107 ; source$D99B: LDA $0207
.export BbOriginal_D99E
BbOriginal_D99E:
 sta $c107,y ; source$D99E: STA $0207,Y
.export BbOriginal_D9A1
BbOriginal_D9A1:
 lda $c102 ; source$D9A1: LDA $0202
.export BbOriginal_D9A4
BbOriginal_D9A4:
 and #$40 ; source$D9A4: AND #$40
.export BbOriginal_D9A6
BbOriginal_D9A6:
 sta $c001,x ; source$D9A6: STA $01,X
.export BbOriginal_D9A8
BbOriginal_D9A8:
 ora #$01 ; source$D9A8: ORA #$01
.export BbOriginal_D9AA
BbOriginal_D9AA:
 sta $c102,y ; source$D9AA: STA $0202,Y
.export BbOriginal_D9AD
BbOriginal_D9AD:
 sta $c106,y ; source$D9AD: STA $0206,Y
.export BbOriginal_D9B0
BbOriginal_D9B0:
 lda $c001,x ; source$D9B0: LDA $01,X
.export BbOriginal_D9B2
BbOriginal_D9B2:
 jne BbOriginal_D9BE ; source$D9B2: BNE $d9be
.export BbOriginal_D9B4
BbOriginal_D9B4:
 lda #$44 ; source$D9B4: LDA #$44
.export BbOriginal_D9B6
BbOriginal_D9B6:
 sta $c101,y ; source$D9B6: STA $0201,Y
.export BbOriginal_D9B9
BbOriginal_D9B9:
 lda #$46 ; source$D9B9: LDA #$46
.export BbOriginal_D9BB
BbOriginal_D9BB:
 jmp BbOriginal_D9C5 ; source$D9BB: JMP $d9c5
.export BbOriginal_D9BE
BbOriginal_D9BE:
 lda #$46 ; source$D9BE: LDA #$46
.export BbOriginal_D9C0
BbOriginal_D9C0:
 sta $c101,y ; source$D9C0: STA $0201,Y
.export BbOriginal_D9C3
BbOriginal_D9C3:
 lda #$44 ; source$D9C3: LDA #$44
.export BbOriginal_D9C5
BbOriginal_D9C5:
 sta $c105,y ; source$D9C5: STA $0205,Y
.export BbOriginal_D9C8
BbOriginal_D9C8:
 lda #$ff ; source$D9C8: LDA #$ff
.export BbOriginal_D9CA
BbOriginal_D9CA:
 sta $c002,x ; source$D9CA: STA $02,X
.export BbOriginal_D9CC
BbOriginal_D9CC:
 tya  ; source$D9CC: TYA
.export BbOriginal_D9CD
BbOriginal_D9CD:
 pha  ; source$D9CD: PHA
.export BbOriginal_D9CE
BbOriginal_D9CE:
 txa  ; source$D9CE: TXA
.export BbOriginal_D9CF
BbOriginal_D9CF:
 pha  ; source$D9CF: PHA
.export BbOriginal_D9D0
BbOriginal_D9D0:
 lda #$10 ; source$D9D0: LDA #$10
.export BbOriginal_D9D2
BbOriginal_D9D2:
 jsr BbImportSound ; source$D9D2: JSR $fa81
.export BbOriginal_D9D5
BbOriginal_D9D5:
 pla  ; source$D9D5: PLA
.export BbOriginal_D9D6
BbOriginal_D9D6:
 tax  ; source$D9D6: TAX
.export BbOriginal_D9D7
BbOriginal_D9D7:
 pla  ; source$D9D7: PLA
.export BbOriginal_D9D8
BbOriginal_D9D8:
 tay  ; source$D9D8: TAY
.export BbOriginal_D9D9
BbOriginal_D9D9:
 dec $c260 ; source$D9D9: DEC $0460
.export BbOriginal_D9DC
BbOriginal_D9DC:
 jmp BbOriginal_D89F ; source$D9DC: JMP $d89f
.export BbOriginal_D9DF
BbOriginal_D9DF:
 lda $c108 ; source$D9DF: LDA $0208
.export BbOriginal_D9E2
BbOriginal_D9E2:
 sta $c100,y ; source$D9E2: STA $0200,Y
.export BbOriginal_D9E5
BbOriginal_D9E5:
 sta $c104,y ; source$D9E5: STA $0204,Y
.export BbOriginal_D9E8
BbOriginal_D9E8:
 lda $c10b ; source$D9E8: LDA $020b
.export BbOriginal_D9EB
BbOriginal_D9EB:
 sta $c103,y ; source$D9EB: STA $0203,Y
.export BbOriginal_D9EE
BbOriginal_D9EE:
 lda $c10f ; source$D9EE: LDA $020f
.export BbOriginal_D9F1
BbOriginal_D9F1:
 sta $c107,y ; source$D9F1: STA $0207,Y
.export BbOriginal_D9F4
BbOriginal_D9F4:
 lda $c10a ; source$D9F4: LDA $020a
.export BbOriginal_D9F7
BbOriginal_D9F7:
 jmp BbOriginal_D9A4 ; source$D9F7: JMP $d9a4
.export BbOriginal_D9FA
BbOriginal_D9FA:
 jsr BbOriginal_DE99 ; source$D9FA: JSR $de99
.export BbOriginal_D9FD
BbOriginal_D9FD:
 jmp BbOriginal_DA77 ; source$D9FD: JMP $da77
.export BbOriginal_DA00
BbOriginal_DA00:
 lda $c000,x ; source$DA00: LDA $00,X
.export BbOriginal_DA02
BbOriginal_DA02:
 cmp #$01 ; source$DA02: CMP #$01
.export BbOriginal_DA04
BbOriginal_DA04:
 jeq BbOriginal_DA15 ; source$DA04: BEQ $da15
.export BbOriginal_DA06
BbOriginal_DA06:
 cmp #$04 ; source$DA06: CMP #$04
.export BbOriginal_DA08
BbOriginal_DA08:
 jeq BbOriginal_DA14 ; source$DA08: BEQ $da14
.export BbOriginal_DA0A
BbOriginal_DA0A:
 cmp #$05 ; source$DA0A: CMP #$05
.export BbOriginal_DA0C
BbOriginal_DA0C:
 jeq BbOriginal_DA81 ; source$DA0C: BEQ $da81
.export BbOriginal_DA0E
BbOriginal_DA0E:
 jsr BbOriginal_DB7F ; source$DA0E: JSR $db7f
.export BbOriginal_DA11
BbOriginal_DA11:
 jsr BbOriginal_DC55 ; source$DA11: JSR $dc55
.export BbOriginal_DA14
BbOriginal_DA14:
 rts  ; source$DA14: RTS
.export BbOriginal_DA15
BbOriginal_DA15:
 lda $c002,x ; source$DA15: LDA $02,X
.export BbOriginal_DA17
BbOriginal_DA17:
 cmp #$ff ; source$DA17: CMP #$ff
.export BbOriginal_DA19
BbOriginal_DA19:
 jeq BbOriginal_D9FA ; source$DA19: BEQ $d9fa
.export BbOriginal_DA1B
BbOriginal_DA1B:
 dec $c003,x ; source$DA1B: DEC $03,X
.export BbOriginal_DA1D
BbOriginal_DA1D:
 lda $c003,x ; source$DA1D: LDA $03,X
.export BbOriginal_DA1F
BbOriginal_DA1F:
 jne BbOriginal_DA52 ; source$DA1F: BNE $da52
.export BbOriginal_DA21
BbOriginal_DA21:
 lda #$08 ; source$DA21: LDA #$08
.export BbOriginal_DA23
BbOriginal_DA23:
 sta $c003,x ; source$DA23: STA $03,X
.export BbOriginal_DA25
BbOriginal_DA25:
 inc $c002,x ; source$DA25: INC $02,X
.export BbOriginal_DA27
BbOriginal_DA27:
 jsr BbOriginal_DF54 ; source$DA27: JSR $df54
.export BbOriginal_DA2A
BbOriginal_DA2A:
 lda $c002,x ; source$DA2A: LDA $02,X
.export BbOriginal_DA2C
BbOriginal_DA2C:
 cmp #$03 ; source$DA2C: CMP #$03
.export BbOriginal_DA2E
BbOriginal_DA2E:
 jne BbOriginal_DA52 ; source$DA2E: BNE $da52
.export BbOriginal_DA30
BbOriginal_DA30:
 lda $c102,y ; source$DA30: LDA $0202,Y
.export BbOriginal_DA33
BbOriginal_DA33:
 lsr a ; source$DA33: LSR A
.export BbOriginal_DA34
BbOriginal_DA34:
 lda $c030 ; source$DA34: LDA $30
.export BbOriginal_DA36
BbOriginal_DA36:
 jcs BbOriginal_DA3A ; source$DA36: BCS $da3a
.export BbOriginal_DA38
BbOriginal_DA38:
 lda $c044 ; source$DA38: LDA $44
.export BbOriginal_DA3A
BbOriginal_DA3A:
 and #$40 ; source$DA3A: AND #$40
.export BbOriginal_DA3C
BbOriginal_DA3C:
 jeq BbOriginal_DA4C ; source$DA3C: BEQ $da4c
.export BbOriginal_DA3E
BbOriginal_DA3E:
 lda #$f5 ; source$DA3E: LDA #$f5
.export BbOriginal_DA40
BbOriginal_DA40:
 sta $c000,x ; source$DA40: STA $00,X
.export BbOriginal_DA42
BbOriginal_DA42:
 lda #$30 ; source$DA42: LDA #$30
.export BbOriginal_DA44
BbOriginal_DA44:
 sta $c101,y ; source$DA44: STA $0201,Y
.export BbOriginal_DA47
BbOriginal_DA47:
 lda #$32 ; source$DA47: LDA #$32
.export BbOriginal_DA49
BbOriginal_DA49:
 sta $c105,y ; source$DA49: STA $0205,Y
.export BbOriginal_DA4C
BbOriginal_DA4C:
 inc $c000,x ; source$DA4C: INC $00,X
.export BbOriginal_DA4E
BbOriginal_DA4E:
 lda #$00 ; source$DA4E: LDA #$00
.export BbOriginal_DA50
BbOriginal_DA50:
 sta $c001,x ; source$DA50: STA $01,X
.export BbOriginal_DA52
BbOriginal_DA52:
 lda $c262 ; source$DA52: LDA $0462
.export BbOriginal_DA55
BbOriginal_DA55:
 jne BbOriginal_DA5A ; source$DA55: BNE $da5a
.export BbOriginal_DA57
BbOriginal_DA57:
 jsr BbOriginal_DE99 ; source$DA57: JSR $de99
.export BbOriginal_DA5A
BbOriginal_DA5A:
 lda $c100,y ; source$DA5A: LDA $0200,Y
.export BbOriginal_DA5D
BbOriginal_DA5D:
 adc #$08 ; source$DA5D: ADC #$08
.export BbOriginal_DA5F
BbOriginal_DA5F:
 sta $c021 ; source$DA5F: STA $21
.export BbOriginal_DA61
BbOriginal_DA61:
 lda $c103,y ; source$DA61: LDA $0203,Y
.export BbOriginal_DA64
BbOriginal_DA64:
 sta $c022 ; source$DA64: STA $22
.export BbOriginal_DA66
BbOriginal_DA66:
 lda $c001,x ; source$DA66: LDA $01,X
.export BbOriginal_DA68
BbOriginal_DA68:
 jeq BbOriginal_DA71 ; source$DA68: BEQ $da71
.export BbOriginal_DA6A
BbOriginal_DA6A:
 lda $c022 ; source$DA6A: LDA $22
.export BbOriginal_DA6C
BbOriginal_DA6C:
 clc  ; source$DA6C: CLC
.export BbOriginal_DA6D
BbOriginal_DA6D:
 adc #$0f ; source$DA6D: ADC #$0f
.export BbOriginal_DA6F
BbOriginal_DA6F:
 sta $c022 ; source$DA6F: STA $22
.export BbOriginal_DA71
BbOriginal_DA71:
 jsr BbOriginal_D0BE ; source$DA71: JSR $d0be
.export BbOriginal_DA74
BbOriginal_DA74:
 jne BbOriginal_DA77 ; source$DA74: BNE $da77
.export BbOriginal_DA76
BbOriginal_DA76:
 rts  ; source$DA76: RTS
.export BbOriginal_DA77
BbOriginal_DA77:
 lda $c001,x ; source$DA77: LDA $01,X
.export BbOriginal_DA79
BbOriginal_DA79:
 jeq BbOriginal_DA7E ; source$DA79: BEQ $da7e
.export BbOriginal_DA7B
BbOriginal_DA7B:
 jmp BbOriginal_DFB5 ; source$DA7B: JMP $dfb5
.export BbOriginal_DA7E
BbOriginal_DA7E:
 jmp BbOriginal_DF8D ; source$DA7E: JMP $df8d
.export BbOriginal_DA81
BbOriginal_DA81:
 lda $c01f ; source$DA81: LDA $1f
.export BbOriginal_DA83
BbOriginal_DA83:
 and #$03 ; source$DA83: AND #$03
.export BbOriginal_DA85
BbOriginal_DA85:
 jne BbOriginal_DAC4 ; source$DA85: BNE $dac4
.export BbOriginal_DA87
BbOriginal_DA87:
 lda $c002,x ; source$DA87: LDA $02,X
.export BbOriginal_DA89
BbOriginal_DA89:
 cmp #$06 ; source$DA89: CMP #$06
.export BbOriginal_DA8B
BbOriginal_DA8B:
 jcc BbOriginal_DA91 ; source$DA8B: BCC $da91
.export BbOriginal_DA8D
BbOriginal_DA8D:
 lda #$03 ; source$DA8D: LDA #$03
.export BbOriginal_DA8F
BbOriginal_DA8F:
 sta $c002,x ; source$DA8F: STA $02,X
.export BbOriginal_DA91
BbOriginal_DA91:
 inc $c002,x ; source$DA91: INC $02,X
.export BbOriginal_DA93
BbOriginal_DA93:
 jsr BbOriginal_DF54 ; source$DA93: JSR $df54
.export BbOriginal_DA96
BbOriginal_DA96:
 lda $c002,x ; source$DA96: LDA $02,X
.export BbOriginal_DA98
BbOriginal_DA98:
 cmp #$04 ; source$DA98: CMP #$04
.export BbOriginal_DA9A
BbOriginal_DA9A:
 jeq BbOriginal_DAC5 ; source$DA9A: BEQ $dac5
.export BbOriginal_DA9C
BbOriginal_DA9C:
 cmp #$05 ; source$DA9C: CMP #$05
.export BbOriginal_DA9E
BbOriginal_DA9E:
 jeq BbOriginal_DACE ; source$DA9E: BEQ $dace
.export BbOriginal_DAA0
BbOriginal_DAA0:
 cmp #$06 ; source$DAA0: CMP #$06
.export BbOriginal_DAA2
BbOriginal_DAA2:
 jne BbOriginal_DAC4 ; source$DAA2: BNE $dac4
.export BbOriginal_DAA4
BbOriginal_DAA4:
 lda $c000,x ; source$DAA4: LDA $00,X
.export BbOriginal_DAA6
BbOriginal_DAA6:
 cmp #$f6 ; source$DAA6: CMP #$f6
.export BbOriginal_DAA8
BbOriginal_DAA8:
 jcc BbOriginal_DAB2 ; source$DAA8: BCC $dab2
.export BbOriginal_DAAA
BbOriginal_DAAA:
 dec $c206 ; source$DAAA: DEC $0406
.export BbOriginal_DAAD
BbOriginal_DAAD:
 jpl BbOriginal_DAB2 ; source$DAAD: BPL $dab2
.export BbOriginal_DAAF
BbOriginal_DAAF:
 inc $c206 ; source$DAAF: INC $0406
.export BbOriginal_DAB2
BbOriginal_DAB2:
 lda #$00 ; source$DAB2: LDA #$00
.export BbOriginal_DAB4
BbOriginal_DAB4:
 sta $c000,x ; source$DAB4: STA $00,X
.export BbOriginal_DAB6
BbOriginal_DAB6:
 sta $c001,x ; source$DAB6: STA $01,X
.export BbOriginal_DAB8
BbOriginal_DAB8:
 sta $c002,x ; source$DAB8: STA $02,X
.export BbOriginal_DABA
BbOriginal_DABA:
 sta $c003,x ; source$DABA: STA $03,X
.export BbOriginal_DABC
BbOriginal_DABC:
 lda #$f4 ; source$DABC: LDA #$f4
.export BbOriginal_DABE
BbOriginal_DABE:
 sta $c100,y ; source$DABE: STA $0200,Y
.export BbOriginal_DAC1
BbOriginal_DAC1:
 sta $c104,y ; source$DAC1: STA $0204,Y
.export BbOriginal_DAC4
BbOriginal_DAC4:
 rts  ; source$DAC4: RTS
.export BbOriginal_DAC5
BbOriginal_DAC5:
 lda $c106,y ; source$DAC5: LDA $0206,Y
.export BbOriginal_DAC8
BbOriginal_DAC8:
 ora #$40 ; source$DAC8: ORA #$40
.export BbOriginal_DACA
BbOriginal_DACA:
 sta $c106,y ; source$DACA: STA $0206,Y
.export BbOriginal_DACD
BbOriginal_DACD:
 rts  ; source$DACD: RTS
.export BbOriginal_DACE
BbOriginal_DACE:
 lda $c106,y ; source$DACE: LDA $0206,Y
.export BbOriginal_DAD1
BbOriginal_DAD1:
 and #$bf ; source$DAD1: AND #$bf
.export BbOriginal_DAD3
BbOriginal_DAD3:
 sta $c106,y ; source$DAD3: STA $0206,Y
.export BbOriginal_DAD6
BbOriginal_DAD6:
 rts  ; source$DAD6: RTS
.export BbOriginal_DAD7
BbOriginal_DAD7:
 lda $c000,x ; source$DAD7: LDA $00,X
.export BbOriginal_DAD9
BbOriginal_DAD9:
 jmi BbOriginal_DAE4 ; source$DAD9: BMI $dae4
.export BbOriginal_DADB
BbOriginal_DADB:
 cmp #$02 ; source$DADB: CMP #$02
.export BbOriginal_DADD
BbOriginal_DADD:
 jeq BbOriginal_DAE4 ; source$DADD: BEQ $dae4
.export BbOriginal_DADF
BbOriginal_DADF:
 cmp #$03 ; source$DADF: CMP #$03
.export BbOriginal_DAE1
BbOriginal_DAE1:
 jeq BbOriginal_DAE4 ; source$DAE1: BEQ $dae4
.export BbOriginal_DAE3
BbOriginal_DAE3:
 rts  ; source$DAE3: RTS
.export BbOriginal_DAE4
BbOriginal_DAE4:
 dec $c263 ; source$DAE4: DEC $0463
.export BbOriginal_DAE7
BbOriginal_DAE7:
 jne BbOriginal_DB43 ; source$DAE7: BNE $db43
.export BbOriginal_DAE9
BbOriginal_DAE9:
 lda #$05 ; source$DAE9: LDA #$05
.export BbOriginal_DAEB
BbOriginal_DAEB:
 sta $c263 ; source$DAEB: STA $0463
.export BbOriginal_DAEE
BbOriginal_DAEE:
 lda $c254 ; source$DAEE: LDA $0454
.export BbOriginal_DAF1
BbOriginal_DAF1:
 jmi BbOriginal_DAF6 ; source$DAF1: BMI $daf6
.export BbOriginal_DAF3
BbOriginal_DAF3:
 inc $c263 ; source$DAF3: INC $0463
.export BbOriginal_DAF6
BbOriginal_DAF6:
 lda $c062 ; source$DAF6: LDA $62
.export BbOriginal_DAF8
BbOriginal_DAF8:
 jmi BbOriginal_DAFD ; source$DAF8: BMI $dafd
.export BbOriginal_DAFA
BbOriginal_DAFA:
 inc $c263 ; source$DAFA: INC $0463
.export BbOriginal_DAFD
BbOriginal_DAFD:
 stx $c025 ; source$DAFD: STX $25
.export BbOriginal_DAFF
BbOriginal_DAFF:
 sty $c026 ; source$DAFF: STY $26
.export BbOriginal_DB01
BbOriginal_DB01:
 lda $c100,y ; source$DB01: LDA $0200,Y
.export BbOriginal_DB04
BbOriginal_DB04:
 sta $c021 ; source$DB04: STA $21
.export BbOriginal_DB06
BbOriginal_DB06:
 lda $c103,y ; source$DB06: LDA $0203,Y
.export BbOriginal_DB09
BbOriginal_DB09:
 sta $c022 ; source$DB09: STA $22
.export BbOriginal_DB0B
BbOriginal_DB0B:
 ldx #$88 ; source$DB0B: LDX #$88
.export BbOriginal_DB0D
BbOriginal_DB0D:
 ldy #$88 ; source$DB0D: LDY #$88
.export BbOriginal_DB0F
BbOriginal_DB0F:
 cpx $c025 ; source$DB0F: CPX $25
.export BbOriginal_DB11
BbOriginal_DB11:
 jeq BbOriginal_DB1F ; source$DB11: BEQ $db1f
.export BbOriginal_DB13
BbOriginal_DB13:
 lda $c000,x ; source$DB13: LDA $00,X
.export BbOriginal_DB15
BbOriginal_DB15:
 jmi BbOriginal_DB4E ; source$DB15: BMI $db4e
.export BbOriginal_DB17
BbOriginal_DB17:
 cmp #$02 ; source$DB17: CMP #$02
.export BbOriginal_DB19
BbOriginal_DB19:
 jeq BbOriginal_DB4E ; source$DB19: BEQ $db4e
.export BbOriginal_DB1B
BbOriginal_DB1B:
 cmp #$03 ; source$DB1B: CMP #$03
.export BbOriginal_DB1D
BbOriginal_DB1D:
 jeq BbOriginal_DB4E ; source$DB1D: BEQ $db4e
.export BbOriginal_DB1F
BbOriginal_DB1F:
 jsr BbOriginal_C39E ; source$DB1F: JSR $c39e
.export BbOriginal_DB22
BbOriginal_DB22:
 cpx #$c4 ; source$DB22: CPX #$c4
.export BbOriginal_DB24
BbOriginal_DB24:
 jne BbOriginal_DB0F ; source$DB24: BNE $db0f
.export BbOriginal_DB26
BbOriginal_DB26:
 ldx #$68 ; source$DB26: LDX #$68
.export BbOriginal_DB28
BbOriginal_DB28:
 ldy #$10 ; source$DB28: LDY #$10
.export BbOriginal_DB2A
BbOriginal_DB2A:
 cpx $c025 ; source$DB2A: CPX $25
.export BbOriginal_DB2C
BbOriginal_DB2C:
 jeq BbOriginal_DB38 ; source$DB2C: BEQ $db38
.export BbOriginal_DB2E
BbOriginal_DB2E:
 lda $c000,x ; source$DB2E: LDA $00,X
.export BbOriginal_DB30
BbOriginal_DB30:
 jeq BbOriginal_DB38 ; source$DB30: BEQ $db38
.export BbOriginal_DB32
BbOriginal_DB32:
 lda $c002,x ; source$DB32: LDA $02,X
.export BbOriginal_DB34
BbOriginal_DB34:
 and #$10 ; source$DB34: AND #$10
.export BbOriginal_DB36
BbOriginal_DB36:
 jne BbOriginal_DB44 ; source$DB36: BNE $db44
.export BbOriginal_DB38
BbOriginal_DB38:
 jsr BbOriginal_C39E ; source$DB38: JSR $c39e
.export BbOriginal_DB3B
BbOriginal_DB3B:
 cpx #$84 ; source$DB3B: CPX #$84
.export BbOriginal_DB3D
BbOriginal_DB3D:
 jne BbOriginal_DB2A ; source$DB3D: BNE $db2a
.export BbOriginal_DB3F
BbOriginal_DB3F:
 ldx $c025 ; source$DB3F: LDX $25
.export BbOriginal_DB41
BbOriginal_DB41:
 ldy $c026 ; source$DB41: LDY $26
.export BbOriginal_DB43
BbOriginal_DB43:
 rts  ; source$DB43: RTS
.export BbOriginal_DB44
BbOriginal_DB44:
 lda #$0b ; source$DB44: LDA #$0b
.export BbOriginal_DB46
BbOriginal_DB46:
 jsr BbOriginal_C43E ; source$DB46: JSR $c43e
.export BbOriginal_DB49
BbOriginal_DB49:
 jcs BbOriginal_DB38 ; source$DB49: BCS $db38
.export BbOriginal_DB4B
BbOriginal_DB4B:
 jmp BbOriginal_DB55 ; source$DB4B: JMP $db55
.export BbOriginal_DB4E
BbOriginal_DB4E:
 lda #$0b ; source$DB4E: LDA #$0b
.export BbOriginal_DB50
BbOriginal_DB50:
 jsr BbOriginal_C43E ; source$DB50: JSR $c43e
.export BbOriginal_DB53
BbOriginal_DB53:
 jcs BbOriginal_DB1F ; source$DB53: BCS $db1f
.export BbOriginal_DB55
BbOriginal_DB55:
 lda $c100,y ; source$DB55: LDA $0200,Y
.export BbOriginal_DB58
BbOriginal_DB58:
 ldx $c025 ; source$DB58: LDX $25
.export BbOriginal_DB5A
BbOriginal_DB5A:
 ldy $c026 ; source$DB5A: LDY $26
.export BbOriginal_DB5C
BbOriginal_DB5C:
 cmp $c021 ; source$DB5C: CMP $21
.export BbOriginal_DB5E
BbOriginal_DB5E:
 jcc BbOriginal_DB69 ; source$DB5E: BCC $db69
.export BbOriginal_DB60
BbOriginal_DB60:
 lda $c100,y ; source$DB60: LDA $0200,Y
.export BbOriginal_DB63
BbOriginal_DB63:
 sec  ; source$DB63: SEC
.export BbOriginal_DB64
BbOriginal_DB64:
 sbc #$02 ; source$DB64: SBC #$02
.export BbOriginal_DB66
BbOriginal_DB66:
 jmp BbOriginal_DB6F ; source$DB66: JMP $db6f
.export BbOriginal_DB69
BbOriginal_DB69:
 lda $c100,y ; source$DB69: LDA $0200,Y
.export BbOriginal_DB6C
BbOriginal_DB6C:
 clc  ; source$DB6C: CLC
.export BbOriginal_DB6D
BbOriginal_DB6D:
 adc #$02 ; source$DB6D: ADC #$02
.export BbOriginal_DB6F
BbOriginal_DB6F:
 sta $c100,y ; source$DB6F: STA $0200,Y
.export BbOriginal_DB72
BbOriginal_DB72:
 sta $c104,y ; source$DB72: STA $0204,Y
.export BbOriginal_DB75
BbOriginal_DB75:
 lda $c063 ; source$DB75: LDA $63
.export BbOriginal_DB77
BbOriginal_DB77:
 jpl BbOriginal_DB7C ; source$DB77: BPL $db7c
.export BbOriginal_DB79
BbOriginal_DB79:
 jmp BbOriginal_DF99 ; source$DB79: JMP $df99
.export BbOriginal_DB7C
BbOriginal_DB7C:
 jmp BbOriginal_DFBD ; source$DB7C: JMP $dfbd
.export BbOriginal_DB7F
BbOriginal_DB7F:
 lda $c244 ; source$DB7F: LDA $0444
.export BbOriginal_DB82
BbOriginal_DB82:
 jeq BbOriginal_DB8A ; source$DB82: BEQ $db8a
.export BbOriginal_DB84
BbOriginal_DB84:
 rts  ; source$DB84: RTS
.export BbOriginal_DB85
BbOriginal_DB85:
 lda #$05 ; source$DB85: LDA #$05
.export BbOriginal_DB87
BbOriginal_DB87:
 sta $c000,x ; source$DB87: STA $00,X
.export BbOriginal_DB89
BbOriginal_DB89:
 rts  ; source$DB89: RTS
.export BbOriginal_DB8A
BbOriginal_DB8A:
 lda $c000,x ; source$DB8A: LDA $00,X
.export BbOriginal_DB8C
BbOriginal_DB8C:
 jmi BbOriginal_DBAB ; source$DB8C: BMI $dbab
.export BbOriginal_DB8E
BbOriginal_DB8E:
 dec $c001,x ; source$DB8E: DEC $01,X
.export BbOriginal_DB90
BbOriginal_DB90:
 jne BbOriginal_DBAB ; source$DB90: BNE $dbab
.export BbOriginal_DB92
BbOriginal_DB92:
 lda $c000,x ; source$DB92: LDA $00,X
.export BbOriginal_DB94
BbOriginal_DB94:
 cmp #$03 ; source$DB94: CMP #$03
.export BbOriginal_DB96
BbOriginal_DB96:
 jeq BbOriginal_DB85 ; source$DB96: BEQ $db85
.export BbOriginal_DB98
BbOriginal_DB98:
 inc $c000,x ; source$DB98: INC $00,X
.export BbOriginal_DB9A
BbOriginal_DB9A:
 lda $c102,y ; source$DB9A: LDA $0202,Y
.export BbOriginal_DB9D
BbOriginal_DB9D:
 and #$fc ; source$DB9D: AND #$fc
.export BbOriginal_DB9F
BbOriginal_DB9F:
 ora #$01 ; source$DB9F: ORA #$01
.export BbOriginal_DBA1
BbOriginal_DBA1:
 sta $c102,y ; source$DBA1: STA $0202,Y
.export BbOriginal_DBA4
BbOriginal_DBA4:
 sta $c106,y ; source$DBA4: STA $0206,Y
.export BbOriginal_DBA7
BbOriginal_DBA7:
 lda #$b4 ; source$DBA7: LDA #$b4
.export BbOriginal_DBA9
BbOriginal_DBA9:
 sta $c001,x ; source$DBA9: STA $01,X
.export BbOriginal_DBAB
BbOriginal_DBAB:
 jsr BbOriginal_DC33 ; source$DBAB: JSR $dc33
.export BbOriginal_DBAE
BbOriginal_DBAE:
 stx $c026 ; source$DBAE: STX $26
.export BbOriginal_DBB0
BbOriginal_DBB0:
 tya  ; source$DBB0: TYA
.export BbOriginal_DBB1
BbOriginal_DBB1:
 tax  ; source$DBB1: TAX
.export BbOriginal_DBB2
BbOriginal_DBB2:
 lda $c100,y ; source$DBB2: LDA $0200,Y
.export BbOriginal_DBB5
BbOriginal_DBB5:
 adc #$08 ; source$DBB5: ADC #$08
.export BbOriginal_DBB7
BbOriginal_DBB7:
 sta $c021 ; source$DBB7: STA $21
.export BbOriginal_DBB9
BbOriginal_DBB9:
 lda $c103,y ; source$DBB9: LDA $0203,Y
.export BbOriginal_DBBC
BbOriginal_DBBC:
 adc #$08 ; source$DBBC: ADC #$08
.export BbOriginal_DBBE
BbOriginal_DBBE:
 sta $c022 ; source$DBBE: STA $22
.export BbOriginal_DBC0
BbOriginal_DBC0:
 jsr BbOriginal_D0BE ; source$DBC0: JSR $d0be
.export BbOriginal_DBC3
BbOriginal_DBC3:
 and #$07 ; source$DBC3: AND #$07
.export BbOriginal_DBC5
BbOriginal_DBC5:
 cmp #$03 ; source$DBC5: CMP #$03
.export BbOriginal_DBC7
BbOriginal_DBC7:
 jeq BbOriginal_DC04 ; source$DBC7: BEQ $dc04
.export BbOriginal_DBC9
BbOriginal_DBC9:
 cmp #$04 ; source$DBC9: CMP #$04
.export BbOriginal_DBCB
BbOriginal_DBCB:
 jeq BbOriginal_DBE9 ; source$DBCB: BEQ $dbe9
.export BbOriginal_DBCD
BbOriginal_DBCD:
 cmp #$02 ; source$DBCD: CMP #$02
.export BbOriginal_DBCF
BbOriginal_DBCF:
 jeq BbOriginal_DC1F ; source$DBCF: BEQ $dc1f
.export BbOriginal_DBD1
BbOriginal_DBD1:
 cmp #$07 ; source$DBD1: CMP #$07
.export BbOriginal_DBD3
BbOriginal_DBD3:
 jeq BbOriginal_DC1F ; source$DBD3: BEQ $dc1f
.export BbOriginal_DBD5
BbOriginal_DBD5:
 dec $c100,x ; source$DBD5: DEC $0200,X
.export BbOriginal_DBD8
BbOriginal_DBD8:
 dec $c104,x ; source$DBD8: DEC $0204,X
.export BbOriginal_DBDB
BbOriginal_DBDB:
 lda $c25d ; source$DBDB: LDA $045d
.export BbOriginal_DBDE
BbOriginal_DBDE:
 jpl BbOriginal_DBE6 ; source$DBDE: BPL $dbe6
.export BbOriginal_DBE0
BbOriginal_DBE0:
 dec $c100,x ; source$DBE0: DEC $0200,X
.export BbOriginal_DBE3
BbOriginal_DBE3:
 dec $c104,x ; source$DBE3: DEC $0204,X
.export BbOriginal_DBE6
BbOriginal_DBE6:
 ldx $c026 ; source$DBE6: LDX $26
.export BbOriginal_DBE8
BbOriginal_DBE8:
 rts  ; source$DBE8: RTS
.export BbOriginal_DBE9
BbOriginal_DBE9:
 lda $c103,x ; source$DBE9: LDA $0203,X
.export BbOriginal_DBEC
BbOriginal_DBEC:
 cmp #$11 ; source$DBEC: CMP #$11
.export BbOriginal_DBEE
BbOriginal_DBEE:
 jcc BbOriginal_DBE6 ; source$DBEE: BCC $dbe6
.export BbOriginal_DBF0
BbOriginal_DBF0:
 dec $c103,x ; source$DBF0: DEC $0203,X
.export BbOriginal_DBF3
BbOriginal_DBF3:
 dec $c107,x ; source$DBF3: DEC $0207,X
.export BbOriginal_DBF6
BbOriginal_DBF6:
 lda $c25d ; source$DBF6: LDA $045d
.export BbOriginal_DBF9
BbOriginal_DBF9:
 jpl BbOriginal_DBE6 ; source$DBF9: BPL $dbe6
.export BbOriginal_DBFB
BbOriginal_DBFB:
 dec $c103,x ; source$DBFB: DEC $0203,X
.export BbOriginal_DBFE
BbOriginal_DBFE:
 dec $c107,x ; source$DBFE: DEC $0207,X
.export BbOriginal_DC01
BbOriginal_DC01:
 jmp BbOriginal_DBE6 ; source$DC01: JMP $dbe6
.export BbOriginal_DC04
BbOriginal_DC04:
 lda $c103,x ; source$DC04: LDA $0203,X
.export BbOriginal_DC07
BbOriginal_DC07:
 cmp #$e0 ; source$DC07: CMP #$e0
.export BbOriginal_DC09
BbOriginal_DC09:
 jcs BbOriginal_DBE6 ; source$DC09: BCS $dbe6
.export BbOriginal_DC0B
BbOriginal_DC0B:
 inc $c103,x ; source$DC0B: INC $0203,X
.export BbOriginal_DC0E
BbOriginal_DC0E:
 inc $c107,x ; source$DC0E: INC $0207,X
.export BbOriginal_DC11
BbOriginal_DC11:
 lda $c25d ; source$DC11: LDA $045d
.export BbOriginal_DC14
BbOriginal_DC14:
 jpl BbOriginal_DBE6 ; source$DC14: BPL $dbe6
.export BbOriginal_DC16
BbOriginal_DC16:
 inc $c103,x ; source$DC16: INC $0203,X
.export BbOriginal_DC19
BbOriginal_DC19:
 inc $c107,x ; source$DC19: INC $0207,X
.export BbOriginal_DC1C
BbOriginal_DC1C:
 jmp BbOriginal_DBE6 ; source$DC1C: JMP $dbe6
.export BbOriginal_DC1F
BbOriginal_DC1F:
 inc $c100,x ; source$DC1F: INC $0200,X
.export BbOriginal_DC22
BbOriginal_DC22:
 inc $c104,x ; source$DC22: INC $0204,X
.export BbOriginal_DC25
BbOriginal_DC25:
 lda $c25d ; source$DC25: LDA $045d
.export BbOriginal_DC28
BbOriginal_DC28:
 jpl BbOriginal_DBE6 ; source$DC28: BPL $dbe6
.export BbOriginal_DC2A
BbOriginal_DC2A:
 inc $c100,x ; source$DC2A: INC $0200,X
.export BbOriginal_DC2D
BbOriginal_DC2D:
 inc $c104,x ; source$DC2D: INC $0204,X
.export BbOriginal_DC30
BbOriginal_DC30:
 jmp BbOriginal_DBE6 ; source$DC30: JMP $dbe6
.export BbOriginal_DC33
BbOriginal_DC33:
 cpx #$84 ; source$DC33: CPX #$84
.export BbOriginal_DC35
BbOriginal_DC35:
 jcc BbOriginal_DC54 ; source$DC35: BCC $dc54
.export BbOriginal_DC37
BbOriginal_DC37:
 lda $c000,x ; source$DC37: LDA $00,X
.export BbOriginal_DC39
BbOriginal_DC39:
 cmp #$03 ; source$DC39: CMP #$03
.export BbOriginal_DC3B
BbOriginal_DC3B:
 jne BbOriginal_DC54 ; source$DC3B: BNE $dc54
.export BbOriginal_DC3D
BbOriginal_DC3D:
 lda $c001,x ; source$DC3D: LDA $01,X
.export BbOriginal_DC3F
BbOriginal_DC3F:
 cmp #$50 ; source$DC3F: CMP #$50
.export BbOriginal_DC41
BbOriginal_DC41:
 jcs BbOriginal_DC54 ; source$DC41: BCS $dc54
.export BbOriginal_DC43
BbOriginal_DC43:
 and #$01 ; source$DC43: AND #$01
.export BbOriginal_DC45
BbOriginal_DC45:
 sta $c084 ; source$DC45: STA $84
.export BbOriginal_DC47
BbOriginal_DC47:
 lda $c102,y ; source$DC47: LDA $0202,Y
.export BbOriginal_DC4A
BbOriginal_DC4A:
 and #$fc ; source$DC4A: AND #$fc
.export BbOriginal_DC4C
BbOriginal_DC4C:
 ora $c084 ; source$DC4C: ORA $84
.export BbOriginal_DC4E
BbOriginal_DC4E:
 sta $c102,y ; source$DC4E: STA $0202,Y
.export BbOriginal_DC51
BbOriginal_DC51:
 sta $c106,y ; source$DC51: STA $0206,Y
.export BbOriginal_DC54
BbOriginal_DC54:
 rts  ; source$DC54: RTS
.export BbOriginal_DC55
BbOriginal_DC55:
 lda #$2e ; source$DC55: LDA #$2e
.export BbOriginal_DC57
BbOriginal_DC57:
 sta $c024 ; source$DC57: STA $24
.export BbOriginal_DC59
BbOriginal_DC59:
 lda #$00 ; source$DC59: LDA #$00
.export BbOriginal_DC5B
BbOriginal_DC5B:
 sta $c025 ; source$DC5B: STA $25
.export BbOriginal_DC5D
BbOriginal_DC5D:
 jsr BbOriginal_DC68 ; source$DC5D: JSR $dc68
.export BbOriginal_DC60
BbOriginal_DC60:
 lda #$42 ; source$DC60: LDA #$42
.export BbOriginal_DC62
BbOriginal_DC62:
 sta $c024 ; source$DC62: STA $24
.export BbOriginal_DC64
BbOriginal_DC64:
 lda #$08 ; source$DC64: LDA #$08
.export BbOriginal_DC66
BbOriginal_DC66:
 sta $c025 ; source$DC66: STA $25
.export BbOriginal_DC68
BbOriginal_DC68:
 stx $c026 ; source$DC68: STX $26
.export BbOriginal_DC6A
BbOriginal_DC6A:
 ldx $c024 ; source$DC6A: LDX $24
.export BbOriginal_DC6C
BbOriginal_DC6C:
 lda $c000,x ; source$DC6C: LDA $00,X
.export BbOriginal_DC6E
BbOriginal_DC6E:
 jeq BbOriginal_DCDE ; source$DC6E: BEQ $dcde
.export BbOriginal_DC70
BbOriginal_DC70:
 ldx $c025 ; source$DC70: LDX $25
.export BbOriginal_DC72
BbOriginal_DC72:
 lda $c100,x ; source$DC72: LDA $0200,X
.export BbOriginal_DC75
BbOriginal_DC75:
 sta $c021 ; source$DC75: STA $21
.export BbOriginal_DC77
BbOriginal_DC77:
 lda $c103,x ; source$DC77: LDA $0203,X
.export BbOriginal_DC7A
BbOriginal_DC7A:
 sta $c022 ; source$DC7A: STA $22
.export BbOriginal_DC7C
BbOriginal_DC7C:
 lda #$10 ; source$DC7C: LDA #$10
.export BbOriginal_DC7E
BbOriginal_DC7E:
 jsr BbOriginal_C43E ; source$DC7E: JSR $c43e
.export BbOriginal_DC81
BbOriginal_DC81:
 jcs BbOriginal_DCDE ; source$DC81: BCS $dcde
.export BbOriginal_DC83
BbOriginal_DC83:
 cmp #$0a ; source$DC83: CMP #$0a
.export BbOriginal_DC85
BbOriginal_DC85:
 jcs BbOriginal_DC90 ; source$DC85: BCS $dc90
.export BbOriginal_DC87
BbOriginal_DC87:
 lda $c023 ; source$DC87: LDA $23
.export BbOriginal_DC89
BbOriginal_DC89:
 cmp #$0a ; source$DC89: CMP #$0a
.export BbOriginal_DC8B
BbOriginal_DC8B:
 jcs BbOriginal_DCA4 ; source$DC8B: BCS $dca4
.export BbOriginal_DC8D
BbOriginal_DC8D:
 jmp BbOriginal_DCE1 ; source$DC8D: JMP $dce1
.export BbOriginal_DC90
BbOriginal_DC90:
 lda $c021 ; source$DC90: LDA $21
.export BbOriginal_DC92
BbOriginal_DC92:
 cmp $c100,y ; source$DC92: CMP $0200,Y
.export BbOriginal_DC95
BbOriginal_DC95:
 jcs BbOriginal_DCA4 ; source$DC95: BCS $dca4
.export BbOriginal_DC97
BbOriginal_DC97:
 lda $c023 ; source$DC97: LDA $23
.export BbOriginal_DC99
BbOriginal_DC99:
 cmp #$0a ; source$DC99: CMP #$0a
.export BbOriginal_DC9B
BbOriginal_DC9B:
 jcs BbOriginal_DCA4 ; source$DC9B: BCS $dca4
.export BbOriginal_DC9D
BbOriginal_DC9D:
 ldx $c024 ; source$DC9D: LDX $24
.export BbOriginal_DC9F
BbOriginal_DC9F:
 inc $c009,x ; source$DC9F: INC $09,X
.export BbOriginal_DCA1
BbOriginal_DCA1:
 jmp BbOriginal_DCDE ; source$DCA1: JMP $dcde
.export BbOriginal_DCA4
BbOriginal_DCA4:
 ldx $c025 ; source$DCA4: LDX $25
.export BbOriginal_DCA6
BbOriginal_DCA6:
 sec  ; source$DCA6: SEC
.export BbOriginal_DCA7
BbOriginal_DCA7:
 lda $c102,x ; source$DCA7: LDA $0202,X
.export BbOriginal_DCAA
BbOriginal_DCAA:
 and #$40 ; source$DCAA: AND #$40
.export BbOriginal_DCAC
BbOriginal_DCAC:
 jne BbOriginal_DCC6 ; source$DCAC: BNE $dcc6
.export BbOriginal_DCAE
BbOriginal_DCAE:
 lda $c022 ; source$DCAE: LDA $22
.export BbOriginal_DCB0
BbOriginal_DCB0:
 sbc $c103,y ; source$DCB0: SBC $0203,Y
.export BbOriginal_DCB3
BbOriginal_DCB3:
 jcc BbOriginal_DCDE ; source$DCB3: BCC $dcde
.export BbOriginal_DCB5
BbOriginal_DCB5:
 cmp #$0d ; source$DCB5: CMP #$0d
.export BbOriginal_DCB7
BbOriginal_DCB7:
 jcs BbOriginal_DCDE ; source$DCB7: BCS $dcde
.export BbOriginal_DCB9
BbOriginal_DCB9:
 ldx $c024 ; source$DCB9: LDX $24
.export BbOriginal_DCBB
BbOriginal_DCBB:
 lda $c009,x ; source$DCBB: LDA $09,X
.export BbOriginal_DCBD
BbOriginal_DCBD:
 ora #$80 ; source$DCBD: ORA #$80
.export BbOriginal_DCBF
BbOriginal_DCBF:
 sta $c009,x ; source$DCBF: STA $09,X
.export BbOriginal_DCC1
BbOriginal_DCC1:
 ldx $c026 ; source$DCC1: LDX $26
.export BbOriginal_DCC3
BbOriginal_DCC3:
 jmp BbOriginal_DFA2 ; source$DCC3: JMP $dfa2
.export BbOriginal_DCC6
BbOriginal_DCC6:
 lda $c103,y ; source$DCC6: LDA $0203,Y
.export BbOriginal_DCC9
BbOriginal_DCC9:
 sbc $c022 ; source$DCC9: SBC $22
.export BbOriginal_DCCB
BbOriginal_DCCB:
 jcc BbOriginal_DCDE ; source$DCCB: BCC $dcde
.export BbOriginal_DCCD
BbOriginal_DCCD:
 cmp #$0d ; source$DCCD: CMP #$0d
.export BbOriginal_DCCF
BbOriginal_DCCF:
 jcs BbOriginal_DCDE ; source$DCCF: BCS $dcde
.export BbOriginal_DCD1
BbOriginal_DCD1:
 ldx $c024 ; source$DCD1: LDX $24
.export BbOriginal_DCD3
BbOriginal_DCD3:
 lda $c009,x ; source$DCD3: LDA $09,X
.export BbOriginal_DCD5
BbOriginal_DCD5:
 ora #$80 ; source$DCD5: ORA #$80
.export BbOriginal_DCD7
BbOriginal_DCD7:
 sta $c009,x ; source$DCD7: STA $09,X
.export BbOriginal_DCD9
BbOriginal_DCD9:
 ldx $c026 ; source$DCD9: LDX $26
.export BbOriginal_DCDB
BbOriginal_DCDB:
 jmp BbOriginal_DFC2 ; source$DCDB: JMP $dfc2
.export BbOriginal_DCDE
BbOriginal_DCDE:
 ldx $c026 ; source$DCDE: LDX $26
.export BbOriginal_DCE0
BbOriginal_DCE0:
 rts  ; source$DCE0: RTS
.export BbOriginal_DCE1
BbOriginal_DCE1:
 lda #$00 ; source$DCE1: LDA #$00
.export BbOriginal_DCE3
BbOriginal_DCE3:
 cpx #$00 ; source$DCE3: CPX #$00
.export BbOriginal_DCE5
BbOriginal_DCE5:
 jeq BbOriginal_DCE9 ; source$DCE5: BEQ $dce9
.export BbOriginal_DCE7
BbOriginal_DCE7:
 lda #$80 ; source$DCE7: LDA #$80
.export BbOriginal_DCE9
BbOriginal_DCE9:
 ldx $c026 ; source$DCE9: LDX $26
.export BbOriginal_DCEB
BbOriginal_DCEB:
 cpx #$88 ; source$DCEB: CPX #$88
.export BbOriginal_DCED
BbOriginal_DCED:
 jcc BbOriginal_DD05 ; source$DCED: BCC $dd05
.export BbOriginal_DCEF
BbOriginal_DCEF:
 sta $c001,x ; source$DCEF: STA $01,X
.export BbOriginal_DCF1
BbOriginal_DCF1:
 lda $c000,x ; source$DCF1: LDA $00,X
.export BbOriginal_DCF3
BbOriginal_DCF3:
 cmp #$f6 ; source$DCF3: CMP #$f6
.export BbOriginal_DCF5
BbOriginal_DCF5:
 jeq BbOriginal_DD16 ; source$DCF5: BEQ $dd16
.export BbOriginal_DCF7
BbOriginal_DCF7:
 cmp #$f7 ; source$DCF7: CMP #$f7
.export BbOriginal_DCF9
BbOriginal_DCF9:
 jeq BbOriginal_DD16 ; source$DCF9: BEQ $dd16
.export BbOriginal_DCFB
BbOriginal_DCFB:
 cmp #$f8 ; source$DCFB: CMP #$f8
.export BbOriginal_DCFD
BbOriginal_DCFD:
 jeq BbOriginal_DD16 ; source$DCFD: BEQ $dd16
.export BbOriginal_DCFF
BbOriginal_DCFF:
 jsr BbOriginal_EFD9 ; source$DCFF: JSR $efd9
.export BbOriginal_DD02
BbOriginal_DD02:
 jmp BbOriginal_DD0E ; source$DD02: JMP $dd0e
.export BbOriginal_DD05
BbOriginal_DD05:
 asl a ; source$DD05: ASL A
.export BbOriginal_DD06
BbOriginal_DD06:
 jcc BbOriginal_DD0E ; source$DD06: BCC $dd0e
.export BbOriginal_DD08
BbOriginal_DD08:
 lda $c002,x ; source$DD08: LDA $02,X
.export BbOriginal_DD0A
BbOriginal_DD0A:
 ora #$20 ; source$DD0A: ORA #$20
.export BbOriginal_DD0C
BbOriginal_DD0C:
 sta $c002,x ; source$DD0C: STA $02,X
.export BbOriginal_DD0E
BbOriginal_DD0E:
 lda #$04 ; source$DD0E: LDA #$04
.export BbOriginal_DD10
BbOriginal_DD10:
 sta $c000,x ; source$DD10: STA $00,X
.export BbOriginal_DD12
BbOriginal_DD12:
 inc $c236 ; source$DD12: INC $0436
.export BbOriginal_DD15
BbOriginal_DD15:
 rts  ; source$DD15: RTS
.export BbOriginal_DD16
BbOriginal_DD16:
 lda $c001,x ; source$DD16: LDA $01,X
.export BbOriginal_DD18
BbOriginal_DD18:
 ora #$01 ; source$DD18: ORA #$01
.export BbOriginal_DD1A
BbOriginal_DD1A:
 sta $c001,x ; source$DD1A: STA $01,X
.export BbOriginal_DD1C
BbOriginal_DD1C:
 dec $c206 ; source$DD1C: DEC $0406
.export BbOriginal_DD1F
BbOriginal_DD1F:
 lda #$00 ; source$DD1F: LDA #$00
.export BbOriginal_DD21
BbOriginal_DD21:
 sta $c003,x ; source$DD21: STA $03,X
.export BbOriginal_DD23
BbOriginal_DD23:
 rts  ; source$DD23: RTS
.export BbOriginal_DD24
BbOriginal_DD24:
 lda $c264 ; source$DD24: LDA $0464
.export BbOriginal_DD27
BbOriginal_DD27:
 jne BbOriginal_DD30 ; source$DD27: BNE $dd30
.export BbOriginal_DD29
BbOriginal_DD29:
 lda $c254 ; source$DD29: LDA $0454
.export BbOriginal_DD2C
BbOriginal_DD2C:
 cmp #$0a ; source$DD2C: CMP #$0a
.export BbOriginal_DD2E
BbOriginal_DD2E:
 jcs BbOriginal_DD3D ; source$DD2E: BCS $dd3d
.export BbOriginal_DD30
BbOriginal_DD30:
 lda #$03 ; source$DD30: LDA #$03
.export BbOriginal_DD32
BbOriginal_DD32:
 jsr BbOriginal_DD3E ; source$DD32: JSR $dd3e
.export BbOriginal_DD35
BbOriginal_DD35:
 jsr BbOriginal_DD4E ; source$DD35: JSR $dd4e
.export BbOriginal_DD38
BbOriginal_DD38:
 lda #$00 ; source$DD38: LDA #$00
.export BbOriginal_DD3A
BbOriginal_DD3A:
 sta $c264 ; source$DD3A: STA $0464
.export BbOriginal_DD3D
BbOriginal_DD3D:
 rts  ; source$DD3D: RTS
.export BbOriginal_DD3E
BbOriginal_DD3E:
 ldx #$88 ; source$DD3E: LDX #$88
.export BbOriginal_DD40
BbOriginal_DD40:
 ldy #$88 ; source$DD40: LDY #$88
.export BbOriginal_DD42
BbOriginal_DD42:
 cmp $c000,x ; source$DD42: CMP $00,X
.export BbOriginal_DD44
BbOriginal_DD44:
 jeq BbOriginal_DD68 ; source$DD44: BEQ $dd68
.export BbOriginal_DD46
BbOriginal_DD46:
 jsr BbOriginal_C39E ; source$DD46: JSR $c39e
.export BbOriginal_DD49
BbOriginal_DD49:
 cpx #$c4 ; source$DD49: CPX #$c4
.export BbOriginal_DD4B
BbOriginal_DD4B:
 jne BbOriginal_DD42 ; source$DD4B: BNE $dd42
.export BbOriginal_DD4D
BbOriginal_DD4D:
 rts  ; source$DD4D: RTS
.export BbOriginal_DD4E
BbOriginal_DD4E:
 ldx #$88 ; source$DD4E: LDX #$88
.export BbOriginal_DD50
BbOriginal_DD50:
 ldy #$88 ; source$DD50: LDY #$88
.export BbOriginal_DD52
BbOriginal_DD52:
 lda #$02 ; source$DD52: LDA #$02
.export BbOriginal_DD54
BbOriginal_DD54:
 cmp $c000,x ; source$DD54: CMP $00,X
.export BbOriginal_DD56
BbOriginal_DD56:
 jne BbOriginal_DD60 ; source$DD56: BNE $dd60
.export BbOriginal_DD58
BbOriginal_DD58:
 lda $c001,x ; source$DD58: LDA $01,X
.export BbOriginal_DD5A
BbOriginal_DD5A:
 jeq BbOriginal_DD60 ; source$DD5A: BEQ $dd60
.export BbOriginal_DD5C
BbOriginal_DD5C:
 cmp #$c8 ; source$DD5C: CMP #$c8
.export BbOriginal_DD5E
BbOriginal_DD5E:
 jcc BbOriginal_DD68 ; source$DD5E: BCC $dd68
.export BbOriginal_DD60
BbOriginal_DD60:
 jsr BbOriginal_C39E ; source$DD60: JSR $c39e
.export BbOriginal_DD63
BbOriginal_DD63:
 cpx #$c4 ; source$DD63: CPX #$c4
.export BbOriginal_DD65
BbOriginal_DD65:
 jne BbOriginal_DD52 ; source$DD65: BNE $dd52
.export BbOriginal_DD67
BbOriginal_DD67:
 rts  ; source$DD67: RTS
.export BbOriginal_DD68
BbOriginal_DD68:
 pla  ; source$DD68: PLA
.export BbOriginal_DD69
BbOriginal_DD69:
 pla  ; source$DD69: PLA
.export BbOriginal_DD6A
BbOriginal_DD6A:
 jmp BbOriginal_DAB2 ; source$DD6A: JMP $dab2
.export BbOriginal_DD6D
BbOriginal_DD6D:
 ldx #$88 ; source$DD6D: LDX #$88
.export BbOriginal_DD6F
BbOriginal_DD6F:
 ldy #$88 ; source$DD6F: LDY #$88
.export BbOriginal_DD71
BbOriginal_DD71:
 lda $c000,x ; source$DD71: LDA $00,X
.export BbOriginal_DD73
BbOriginal_DD73:
 cmp #$04 ; source$DD73: CMP #$04
.export BbOriginal_DD75
BbOriginal_DD75:
 jeq BbOriginal_DDB2 ; source$DD75: BEQ $ddb2
.export BbOriginal_DD77
BbOriginal_DD77:
 lda $c000,x ; source$DD77: LDA $00,X
.export BbOriginal_DD79
BbOriginal_DD79:
 jpl BbOriginal_DD88 ; source$DD79: BPL $dd88
.export BbOriginal_DD7B
BbOriginal_DD7B:
 cmp #$ff ; source$DD7B: CMP #$ff
.export BbOriginal_DD7D
BbOriginal_DD7D:
 jeq BbOriginal_DD88 ; source$DD7D: BEQ $dd88
.export BbOriginal_DD7F
BbOriginal_DD7F:
 lda $c001,x ; source$DD7F: LDA $01,X
.export BbOriginal_DD81
BbOriginal_DD81:
 lsr a ; source$DD81: LSR A
.export BbOriginal_DD82
BbOriginal_DD82:
 jcc BbOriginal_DD88 ; source$DD82: BCC $dd88
.export BbOriginal_DD84
BbOriginal_DD84:
 lda $c003,x ; source$DD84: LDA $03,X
.export BbOriginal_DD86
BbOriginal_DD86:
 jeq BbOriginal_DDB2 ; source$DD86: BEQ $ddb2
.export BbOriginal_DD88
BbOriginal_DD88:
 jsr BbOriginal_C39E ; source$DD88: JSR $c39e
.export BbOriginal_DD8B
BbOriginal_DD8B:
 cpx #$c4 ; source$DD8B: CPX #$c4
.export BbOriginal_DD8D
BbOriginal_DD8D:
 jne BbOriginal_DD71 ; source$DD8D: BNE $dd71
.export BbOriginal_DD8F
BbOriginal_DD8F:
 ldx #$68 ; source$DD8F: LDX #$68
.export BbOriginal_DD91
BbOriginal_DD91:
 ldy #$10 ; source$DD91: LDY #$10
.export BbOriginal_DD93
BbOriginal_DD93:
 lda $c002,x ; source$DD93: LDA $02,X
.export BbOriginal_DD95
BbOriginal_DD95:
 and #$10 ; source$DD95: AND #$10
.export BbOriginal_DD97
BbOriginal_DD97:
 jeq BbOriginal_DD9F ; source$DD97: BEQ $dd9f
.export BbOriginal_DD99
BbOriginal_DD99:
 lda $c003,x ; source$DD99: LDA $03,X
.export BbOriginal_DD9B
BbOriginal_DD9B:
 cmp #$04 ; source$DD9B: CMP #$04
.export BbOriginal_DD9D
BbOriginal_DD9D:
 jeq BbOriginal_DDA7 ; source$DD9D: BEQ $dda7
.export BbOriginal_DD9F
BbOriginal_DD9F:
 jsr BbOriginal_C39E ; source$DD9F: JSR $c39e
.export BbOriginal_DDA2
BbOriginal_DDA2:
 cpx #$84 ; source$DDA2: CPX #$84
.export BbOriginal_DDA4
BbOriginal_DDA4:
 jne BbOriginal_DD93 ; source$DDA4: BNE $dd93
.export BbOriginal_DDA6
BbOriginal_DDA6:
 rts  ; source$DDA6: RTS
.export BbOriginal_DDA7
BbOriginal_DDA7:
 stx $c025 ; source$DDA7: STX $25
.export BbOriginal_DDA9
BbOriginal_DDA9:
 lda $c002,x ; source$DDA9: LDA $02,X
.export BbOriginal_DDAB
BbOriginal_DDAB:
 and #$20 ; source$DDAB: AND #$20
.export BbOriginal_DDAD
BbOriginal_DDAD:
 asl a ; source$DDAD: ASL A
.export BbOriginal_DDAE
BbOriginal_DDAE:
 asl a ; source$DDAE: ASL A
.export BbOriginal_DDAF
BbOriginal_DDAF:
 jmp BbOriginal_DDB6 ; source$DDAF: JMP $ddb6
.export BbOriginal_DDB2
BbOriginal_DDB2:
 stx $c025 ; source$DDB2: STX $25
.export BbOriginal_DDB4
BbOriginal_DDB4:
 lda $c001,x ; source$DDB4: LDA $01,X
.export BbOriginal_DDB6
BbOriginal_DDB6:
 sta $c026 ; source$DDB6: STA $26
.export BbOriginal_DDB8
BbOriginal_DDB8:
 lda $c100,y ; source$DDB8: LDA $0200,Y
.export BbOriginal_DDBB
BbOriginal_DDBB:
 sta $c021 ; source$DDBB: STA $21
.export BbOriginal_DDBD
BbOriginal_DDBD:
 lda $c103,y ; source$DDBD: LDA $0203,Y
.export BbOriginal_DDC0
BbOriginal_DDC0:
 sta $c022 ; source$DDC0: STA $22
.export BbOriginal_DDC2
BbOriginal_DDC2:
 ldx #$88 ; source$DDC2: LDX #$88
.export BbOriginal_DDC4
BbOriginal_DDC4:
 ldy #$88 ; source$DDC4: LDY #$88
.export BbOriginal_DDC6
BbOriginal_DDC6:
 lda $c000,x ; source$DDC6: LDA $00,X
.export BbOriginal_DDC8
BbOriginal_DDC8:
 jmi BbOriginal_DE2D ; source$DDC8: BMI $de2d
.export BbOriginal_DDCA
BbOriginal_DDCA:
 cmp #$02 ; source$DDCA: CMP #$02
.export BbOriginal_DDCC
BbOriginal_DDCC:
 jeq BbOriginal_DE2D ; source$DDCC: BEQ $de2d
.export BbOriginal_DDCE
BbOriginal_DDCE:
 cmp #$03 ; source$DDCE: CMP #$03
.export BbOriginal_DDD0
BbOriginal_DDD0:
 jeq BbOriginal_DE2D ; source$DDD0: BEQ $de2d
.export BbOriginal_DDD2
BbOriginal_DDD2:
 jsr BbOriginal_C39E ; source$DDD2: JSR $c39e
.export BbOriginal_DDD5
BbOriginal_DDD5:
 cpx #$c4 ; source$DDD5: CPX #$c4
.export BbOriginal_DDD7
BbOriginal_DDD7:
 jne BbOriginal_DDC6 ; source$DDD7: BNE $ddc6
.export BbOriginal_DDD9
BbOriginal_DDD9:
 ldx #$68 ; source$DDD9: LDX #$68
.export BbOriginal_DDDB
BbOriginal_DDDB:
 ldy #$10 ; source$DDDB: LDY #$10
.export BbOriginal_DDDD
BbOriginal_DDDD:
 lda $c002,x ; source$DDDD: LDA $02,X
.export BbOriginal_DDDF
BbOriginal_DDDF:
 and #$10 ; source$DDDF: AND #$10
.export BbOriginal_DDE1
BbOriginal_DDE1:
 jeq BbOriginal_DE02 ; source$DDE1: BEQ $de02
.export BbOriginal_DDE3
BbOriginal_DDE3:
 lda $c003,x ; source$DDE3: LDA $03,X
.export BbOriginal_DDE5
BbOriginal_DDE5:
 cmp #$04 ; source$DDE5: CMP #$04
.export BbOriginal_DDE7
BbOriginal_DDE7:
 jeq BbOriginal_DE02 ; source$DDE7: BEQ $de02
.export BbOriginal_DDE9
BbOriginal_DDE9:
 cmp #$05 ; source$DDE9: CMP #$05
.export BbOriginal_DDEB
BbOriginal_DDEB:
 jeq BbOriginal_DE02 ; source$DDEB: BEQ $de02
.export BbOriginal_DDED
BbOriginal_DDED:
 lda #$0f ; source$DDED: LDA #$0f
.export BbOriginal_DDEF
BbOriginal_DDEF:
 jsr BbOriginal_C43E ; source$DDEF: JSR $c43e
.export BbOriginal_DDF2
BbOriginal_DDF2:
 jcs BbOriginal_DE02 ; source$DDF2: BCS $de02
.export BbOriginal_DDF4
BbOriginal_DDF4:
 lda #$04 ; source$DDF4: LDA #$04
.export BbOriginal_DDF6
BbOriginal_DDF6:
 sta $c003,x ; source$DDF6: STA $03,X
.export BbOriginal_DDF8
BbOriginal_DDF8:
 lda $c026 ; source$DDF8: LDA $26
.export BbOriginal_DDFA
BbOriginal_DDFA:
 jpl BbOriginal_DE02 ; source$DDFA: BPL $de02
.export BbOriginal_DDFC
BbOriginal_DDFC:
 lda $c002,x ; source$DDFC: LDA $02,X
.export BbOriginal_DDFE
BbOriginal_DDFE:
 ora #$20 ; source$DDFE: ORA #$20
.export BbOriginal_DE00
BbOriginal_DE00:
 sta $c002,x ; source$DE00: STA $02,X
.export BbOriginal_DE02
BbOriginal_DE02:
 jsr BbOriginal_C39E ; source$DE02: JSR $c39e
.export BbOriginal_DE05
BbOriginal_DE05:
 cpx #$84 ; source$DE05: CPX #$84
.export BbOriginal_DE07
BbOriginal_DE07:
 jne BbOriginal_DDDD ; source$DE07: BNE $dddd
.export BbOriginal_DE09
BbOriginal_DE09:
 ldx $c025 ; source$DE09: LDX $25
.export BbOriginal_DE0B
BbOriginal_DE0B:
 cpx #$88 ; source$DE0B: CPX #$88
.export BbOriginal_DE0D
BbOriginal_DE0D:
 jcc BbOriginal_DE21 ; source$DE0D: BCC $de21
.export BbOriginal_DE0F
BbOriginal_DE0F:
 lda $c000,x ; source$DE0F: LDA $00,X
.export BbOriginal_DE11
BbOriginal_DE11:
 jmi BbOriginal_DE28 ; source$DE11: BMI $de28
.export BbOriginal_DE13
BbOriginal_DE13:
 lda #$05 ; source$DE13: LDA #$05
.export BbOriginal_DE15
BbOriginal_DE15:
 sta $c000,x ; source$DE15: STA $00,X
.export BbOriginal_DE17
BbOriginal_DE17:
 lda $c001,x ; source$DE17: LDA $01,X
.export BbOriginal_DE19
BbOriginal_DE19:
 jpl BbOriginal_DE1E ; source$DE19: BPL $de1e
.export BbOriginal_DE1B
BbOriginal_DE1B:
 inc $c054 ; source$DE1B: INC $54
.export BbOriginal_DE1D
BbOriginal_DE1D:
 rts  ; source$DE1D: RTS
.export BbOriginal_DE1E
BbOriginal_DE1E:
 inc $c040 ; source$DE1E: INC $40
.export BbOriginal_DE20
BbOriginal_DE20:
 rts  ; source$DE20: RTS
.export BbOriginal_DE21
BbOriginal_DE21:
 lda #$05 ; source$DE21: LDA #$05
.export BbOriginal_DE23
BbOriginal_DE23:
 sta $c003,x ; source$DE23: STA $03,X
.export BbOriginal_DE25
BbOriginal_DE25:
 jmp BbOriginal_DE69 ; source$DE25: JMP $de69
.export BbOriginal_DE28
BbOriginal_DE28:
 lda #$ff ; source$DE28: LDA #$ff
.export BbOriginal_DE2A
BbOriginal_DE2A:
 sta $c003,x ; source$DE2A: STA $03,X
.export BbOriginal_DE2C
BbOriginal_DE2C:
 rts  ; source$DE2C: RTS
.export BbOriginal_DE2D
BbOriginal_DE2D:
 cmp #$ff ; source$DE2D: CMP #$ff
.export BbOriginal_DE2F
BbOriginal_DE2F:
 jeq BbOriginal_DDD2 ; source$DE2F: BEQ $ddd2
.export BbOriginal_DE31
BbOriginal_DE31:
 lda #$0f ; source$DE31: LDA #$0f
.export BbOriginal_DE33
BbOriginal_DE33:
 jsr BbOriginal_C43E ; source$DE33: JSR $c43e
.export BbOriginal_DE36
BbOriginal_DE36:
 jcs BbOriginal_DDD2 ; source$DE36: BCS $ddd2
.export BbOriginal_DE38
BbOriginal_DE38:
 lda $c000,x ; source$DE38: LDA $00,X
.export BbOriginal_DE3A
BbOriginal_DE3A:
 cmp #$f6 ; source$DE3A: CMP #$f6
.export BbOriginal_DE3C
BbOriginal_DE3C:
 jeq BbOriginal_DE54 ; source$DE3C: BEQ $de54
.export BbOriginal_DE3E
BbOriginal_DE3E:
 cmp #$f7 ; source$DE3E: CMP #$f7
.export BbOriginal_DE40
BbOriginal_DE40:
 jeq BbOriginal_DE54 ; source$DE40: BEQ $de54
.export BbOriginal_DE42
BbOriginal_DE42:
 cmp #$f8 ; source$DE42: CMP #$f8
.export BbOriginal_DE44
BbOriginal_DE44:
 jeq BbOriginal_DE54 ; source$DE44: BEQ $de54
.export BbOriginal_DE46
BbOriginal_DE46:
 lda $c026 ; source$DE46: LDA $26
.export BbOriginal_DE48
BbOriginal_DE48:
 sta $c001,x ; source$DE48: STA $01,X
.export BbOriginal_DE4A
BbOriginal_DE4A:
 jsr BbOriginal_EFD9 ; source$DE4A: JSR $efd9
.export BbOriginal_DE4D
BbOriginal_DE4D:
 lda #$04 ; source$DE4D: LDA #$04
.export BbOriginal_DE4F
BbOriginal_DE4F:
 sta $c000,x ; source$DE4F: STA $00,X
.export BbOriginal_DE51
BbOriginal_DE51:
 jmp BbOriginal_DDD2 ; source$DE51: JMP $ddd2
.export BbOriginal_DE54
BbOriginal_DE54:
 lda $c001,x ; source$DE54: LDA $01,X
.export BbOriginal_DE56
BbOriginal_DE56:
 lsr a ; source$DE56: LSR A
.export BbOriginal_DE57
BbOriginal_DE57:
 jcs BbOriginal_DE66 ; source$DE57: BCS $de66
.export BbOriginal_DE59
BbOriginal_DE59:
 lda $c026 ; source$DE59: LDA $26
.export BbOriginal_DE5B
BbOriginal_DE5B:
 ora #$01 ; source$DE5B: ORA #$01
.export BbOriginal_DE5D
BbOriginal_DE5D:
 sta $c001,x ; source$DE5D: STA $01,X
.export BbOriginal_DE5F
BbOriginal_DE5F:
 dec $c206 ; source$DE5F: DEC $0406
.export BbOriginal_DE62
BbOriginal_DE62:
 lda #$00 ; source$DE62: LDA #$00
.export BbOriginal_DE64
BbOriginal_DE64:
 sta $c002,x ; source$DE64: STA $02,X
.export BbOriginal_DE66
BbOriginal_DE66:
 jmp BbOriginal_DDD2 ; source$DE66: JMP $ddd2
.export BbOriginal_DE69
BbOriginal_DE69:
 lda $c002,x ; source$DE69: LDA $02,X
.export BbOriginal_DE6B
BbOriginal_DE6B:
 and #$20 ; source$DE6B: AND #$20
.export BbOriginal_DE6D
BbOriginal_DE6D:
 jne BbOriginal_DE84 ; source$DE6D: BNE $de84
.export BbOriginal_DE6F
BbOriginal_DE6F:
 lda $c256 ; source$DE6F: LDA $0456
.export BbOriginal_DE72
BbOriginal_DE72:
 jne BbOriginal_DE80 ; source$DE72: BNE $de80
.export BbOriginal_DE74
BbOriginal_DE74:
 inc $c256 ; source$DE74: INC $0456
.export BbOriginal_DE77
BbOriginal_DE77:
 lda #$00 ; source$DE77: LDA #$00
.export BbOriginal_DE79
BbOriginal_DE79:
 sta $c257 ; source$DE79: STA $0457
.export BbOriginal_DE7C
BbOriginal_DE7C:
 lda #$14 ; source$DE7C: LDA #$14
.export BbOriginal_DE7E
BbOriginal_DE7E:
 sta $c029 ; source$DE7E: STA $29
.export BbOriginal_DE80
BbOriginal_DE80:
 inc $c257 ; source$DE80: INC $0457
.export BbOriginal_DE83
BbOriginal_DE83:
 rts  ; source$DE83: RTS
.export BbOriginal_DE84
BbOriginal_DE84:
 lda $c259 ; source$DE84: LDA $0459
.export BbOriginal_DE87
BbOriginal_DE87:
 jne BbOriginal_DE95 ; source$DE87: BNE $de95
.export BbOriginal_DE89
BbOriginal_DE89:
 inc $c259 ; source$DE89: INC $0459
.export BbOriginal_DE8C
BbOriginal_DE8C:
 lda #$00 ; source$DE8C: LDA #$00
.export BbOriginal_DE8E
BbOriginal_DE8E:
 sta $c25a ; source$DE8E: STA $045a
.export BbOriginal_DE91
BbOriginal_DE91:
 lda #$14 ; source$DE91: LDA #$14
.export BbOriginal_DE93
BbOriginal_DE93:
 sta $c02a ; source$DE93: STA $2a
.export BbOriginal_DE95
BbOriginal_DE95:
 inc $c25a ; source$DE95: INC $045a
.export BbOriginal_DE98
BbOriginal_DE98:
 rts  ; source$DE98: RTS
.export BbOriginal_DE99
BbOriginal_DE99:
 stx $c025 ; source$DE99: STX $25
.export BbOriginal_DE9B
BbOriginal_DE9B:
 sty $c026 ; source$DE9B: STY $26
.export BbOriginal_DE9D
BbOriginal_DE9D:
 lda $c100,y ; source$DE9D: LDA $0200,Y
.export BbOriginal_DEA0
BbOriginal_DEA0:
 sta $c021 ; source$DEA0: STA $21
.export BbOriginal_DEA2
BbOriginal_DEA2:
 lda $c103,y ; source$DEA2: LDA $0203,Y
.export BbOriginal_DEA5
BbOriginal_DEA5:
 sta $c022 ; source$DEA5: STA $22
.export BbOriginal_DEA7
BbOriginal_DEA7:
 lda $c002,x ; source$DEA7: LDA $02,X
.export BbOriginal_DEA9
BbOriginal_DEA9:
 sta $c084 ; source$DEA9: STA $84
.export BbOriginal_DEAB
BbOriginal_DEAB:
 ldx #$68 ; source$DEAB: LDX #$68
.export BbOriginal_DEAD
BbOriginal_DEAD:
 ldy #$10 ; source$DEAD: LDY #$10
.export BbOriginal_DEAF
BbOriginal_DEAF:
 lda $c000,x ; source$DEAF: LDA $00,X
.export BbOriginal_DEB1
BbOriginal_DEB1:
 jeq BbOriginal_DED1 ; source$DEB1: BEQ $ded1
.export BbOriginal_DEB3
BbOriginal_DEB3:
 lda $c084 ; source$DEB3: LDA $84
.export BbOriginal_DEB5
BbOriginal_DEB5:
 jpl BbOriginal_DEBC ; source$DEB5: BPL $debc
.export BbOriginal_DEB7
BbOriginal_DEB7:
 lda #$08 ; source$DEB7: LDA #$08
.export BbOriginal_DEB9
BbOriginal_DEB9:
 jmp BbOriginal_DEBE ; source$DEB9: JMP $debe
.export BbOriginal_DEBC
BbOriginal_DEBC:
 lda #$18 ; source$DEBC: LDA #$18
.export BbOriginal_DEBE
BbOriginal_DEBE:
 and $c002,x ; source$DEBE: AND $02,X
.export BbOriginal_DEC0
BbOriginal_DEC0:
 jne BbOriginal_DED1 ; source$DEC0: BNE $ded1
.export BbOriginal_DEC2
BbOriginal_DEC2:
 lda $c001,x ; source$DEC2: LDA $01,X
.export BbOriginal_DEC4
BbOriginal_DEC4:
 and #$0f ; source$DEC4: AND #$0f
.export BbOriginal_DEC6
BbOriginal_DEC6:
 cmp #$0f ; source$DEC6: CMP #$0f
.export BbOriginal_DEC8
BbOriginal_DEC8:
 jeq BbOriginal_DED1 ; source$DEC8: BEQ $ded1
.export BbOriginal_DECA
BbOriginal_DECA:
 lda #$0c ; source$DECA: LDA #$0c
.export BbOriginal_DECC
BbOriginal_DECC:
 jsr BbOriginal_C43E ; source$DECC: JSR $c43e
.export BbOriginal_DECF
BbOriginal_DECF:
 jcc BbOriginal_DEDD ; source$DECF: BCC $dedd
.export BbOriginal_DED1
BbOriginal_DED1:
 jsr BbOriginal_C39E ; source$DED1: JSR $c39e
.export BbOriginal_DED4
BbOriginal_DED4:
 cpx #$84 ; source$DED4: CPX #$84
.export BbOriginal_DED6
BbOriginal_DED6:
 jne BbOriginal_DEAF ; source$DED6: BNE $deaf
.export BbOriginal_DED8
BbOriginal_DED8:
 ldx $c025 ; source$DED8: LDX $25
.export BbOriginal_DEDA
BbOriginal_DEDA:
 ldy $c026 ; source$DEDA: LDY $26
.export BbOriginal_DEDC
BbOriginal_DEDC:
 rts  ; source$DEDC: RTS
.export BbOriginal_DEDD
BbOriginal_DEDD:
 lda $c084 ; source$DEDD: LDA $84
.export BbOriginal_DEDF
BbOriginal_DEDF:
 jmi BbOriginal_DF3C ; source$DEDF: BMI $df3c
.export BbOriginal_DEE1
BbOriginal_DEE1:
 lda $c20a ; source$DEE1: LDA $040a
.export BbOriginal_DEE4
BbOriginal_DEE4:
 sta $c1ab,x ; source$DEE4: STA $03ab,X
.export BbOriginal_DEE7
BbOriginal_DEE7:
 lda $c002,x ; source$DEE7: LDA $02,X
.export BbOriginal_DEE9
BbOriginal_DEE9:
 and #$08 ; source$DEE9: AND #$08
.export BbOriginal_DEEB
BbOriginal_DEEB:
 jne BbOriginal_DF21 ; source$DEEB: BNE $df21
.export BbOriginal_DEED
BbOriginal_DEED:
 lda $c021 ; source$DEED: LDA $21
.export BbOriginal_DEEF
BbOriginal_DEEF:
 sta $c100,y ; source$DEEF: STA $0200,Y
.export BbOriginal_DEF2
BbOriginal_DEF2:
 sta $c104,y ; source$DEF2: STA $0204,Y
.export BbOriginal_DEF5
BbOriginal_DEF5:
 lda $c022 ; source$DEF5: LDA $22
.export BbOriginal_DEF7
BbOriginal_DEF7:
 sta $c103,y ; source$DEF7: STA $0203,Y
.export BbOriginal_DEFA
BbOriginal_DEFA:
 clc  ; source$DEFA: CLC
.export BbOriginal_DEFB
BbOriginal_DEFB:
 adc #$08 ; source$DEFB: ADC #$08
.export BbOriginal_DEFD
BbOriginal_DEFD:
 sta $c107,y ; source$DEFD: STA $0207,Y
.export BbOriginal_DF00
BbOriginal_DF00:
 lda $c002,x ; source$DF00: LDA $02,X
.export BbOriginal_DF02
BbOriginal_DF02:
 ora #$10 ; source$DF02: ORA #$10
.export BbOriginal_DF04
BbOriginal_DF04:
 and #$d0 ; source$DF04: AND #$d0
.export BbOriginal_DF06
BbOriginal_DF06:
 sta $c002,x ; source$DF06: STA $02,X
.export BbOriginal_DF08
BbOriginal_DF08:
 lda #$00 ; source$DF08: LDA #$00
.export BbOriginal_DF0A
BbOriginal_DF0A:
 sta $c003,x ; source$DF0A: STA $03,X
.export BbOriginal_DF0C
BbOriginal_DF0C:
 lda $c001,x ; source$DF0C: LDA $01,X
.export BbOriginal_DF0E
BbOriginal_DF0E:
 and #$03 ; source$DF0E: AND #$03
.export BbOriginal_DF10
BbOriginal_DF10:
 sta $c001,x ; source$DF10: STA $01,X
.export BbOriginal_DF12
BbOriginal_DF12:
 ldy $c026 ; source$DF12: LDY $26
.export BbOriginal_DF14
BbOriginal_DF14:
 lda $c102,y ; source$DF14: LDA $0202,Y
.export BbOriginal_DF17
BbOriginal_DF17:
 and #$03 ; source$DF17: AND #$03
.export BbOriginal_DF19
BbOriginal_DF19:
 jeq BbOriginal_DF21 ; source$DF19: BEQ $df21
.export BbOriginal_DF1B
BbOriginal_DF1B:
 lda $c002,x ; source$DF1B: LDA $02,X
.export BbOriginal_DF1D
BbOriginal_DF1D:
 ora #$01 ; source$DF1D: ORA #$01
.export BbOriginal_DF1F
BbOriginal_DF1F:
 sta $c002,x ; source$DF1F: STA $02,X
.export BbOriginal_DF21
BbOriginal_DF21:
 ldx $c025 ; source$DF21: LDX $25
.export BbOriginal_DF23
BbOriginal_DF23:
 ldy $c026 ; source$DF23: LDY $26
.export BbOriginal_DF25
BbOriginal_DF25:
 lda $c002,x ; source$DF25: LDA $02,X
.export BbOriginal_DF27
BbOriginal_DF27:
 cmp #$ff ; source$DF27: CMP #$ff
.export BbOriginal_DF29
BbOriginal_DF29:
 jeq BbOriginal_DF3B ; source$DF29: BEQ $df3b
.export BbOriginal_DF2B
BbOriginal_DF2B:
 lda #$00 ; source$DF2B: LDA #$00
.export BbOriginal_DF2D
BbOriginal_DF2D:
 sta $c000,x ; source$DF2D: STA $00,X
.export BbOriginal_DF2F
BbOriginal_DF2F:
 sta $c002,x ; source$DF2F: STA $02,X
.export BbOriginal_DF31
BbOriginal_DF31:
 lda #$f4 ; source$DF31: LDA #$f4
.export BbOriginal_DF33
BbOriginal_DF33:
 sta $c100,y ; source$DF33: STA $0200,Y
.export BbOriginal_DF36
BbOriginal_DF36:
 sta $c104,y ; source$DF36: STA $0204,Y
.export BbOriginal_DF39
BbOriginal_DF39:
 pla  ; source$DF39: PLA
.export BbOriginal_DF3A
BbOriginal_DF3A:
 pla  ; source$DF3A: PLA
.export BbOriginal_DF3B
BbOriginal_DF3B:
 rts  ; source$DF3B: RTS
.export BbOriginal_DF3C
BbOriginal_DF3C:
 lda $c002,x ; source$DF3C: LDA $02,X
.export BbOriginal_DF3E
BbOriginal_DF3E:
 and #$10 ; source$DF3E: AND #$10
.export BbOriginal_DF40
BbOriginal_DF40:
 jne BbOriginal_DF47 ; source$DF40: BNE $df47
.export BbOriginal_DF42
BbOriginal_DF42:
 lda #$21 ; source$DF42: LDA #$21
.export BbOriginal_DF44
BbOriginal_DF44:
 jmp BbOriginal_DF49 ; source$DF44: JMP $df49
.export BbOriginal_DF47
BbOriginal_DF47:
 lda #$16 ; source$DF47: LDA #$16
.export BbOriginal_DF49
BbOriginal_DF49:
 sta $c1ad,x ; source$DF49: STA $03ad,X
.export BbOriginal_DF4C
BbOriginal_DF4C:
 jsr BbOriginal_95D0 ; source$DF4C: JSR $95d0
.export BbOriginal_DF4F
BbOriginal_DF4F:
 ldx $c025 ; source$DF4F: LDX $25
.export BbOriginal_DF51
BbOriginal_DF51:
 ldy $c026 ; source$DF51: LDY $26
.export BbOriginal_DF53
BbOriginal_DF53:
 rts  ; source$DF53: RTS
.export BbOriginal_DF54
BbOriginal_DF54:
 lda $c002,x ; source$DF54: LDA $02,X
.export BbOriginal_DF56
BbOriginal_DF56:
 asl a ; source$DF56: ASL A
.export BbOriginal_DF57
BbOriginal_DF57:
 stx $c026 ; source$DF57: STX $26
.export BbOriginal_DF59
BbOriginal_DF59:
 tax  ; source$DF59: TAX
.export BbOriginal_DF5A
BbOriginal_DF5A:
 lda BbBubbleTileTable,x ; source$DF5A: LDA $df81,X
.export BbOriginal_DF5D
BbOriginal_DF5D:
 sta $c101,y ; source$DF5D: STA $0201,Y
.export BbOriginal_DF60
BbOriginal_DF60:
 lda BbBubbleTileTable+1,x ; source$DF60: LDA $df82,X
.export BbOriginal_DF63
BbOriginal_DF63:
 sta $c105,y ; source$DF63: STA $0205,Y
.export BbOriginal_DF66
BbOriginal_DF66:
 cmp $c101,y ; source$DF66: CMP $0201,Y
.export BbOriginal_DF69
BbOriginal_DF69:
 jne BbOriginal_DF76 ; source$DF69: BNE $df76
.export BbOriginal_DF6B
BbOriginal_DF6B:
 lda $c106,y ; source$DF6B: LDA $0206,Y
.export BbOriginal_DF6E
BbOriginal_DF6E:
 ora #$c0 ; source$DF6E: ORA #$c0
.export BbOriginal_DF70
BbOriginal_DF70:
 sta $c106,y ; source$DF70: STA $0206,Y
.export BbOriginal_DF73
BbOriginal_DF73:
 ldx $c026 ; source$DF73: LDX $26
.export BbOriginal_DF75
BbOriginal_DF75:
 rts  ; source$DF75: RTS
.export BbOriginal_DF76
BbOriginal_DF76:
 lda $c106,y ; source$DF76: LDA $0206,Y
.export BbOriginal_DF79
BbOriginal_DF79:
 and #$3f ; source$DF79: AND #$3f
.export BbOriginal_DF7B
BbOriginal_DF7B:
 sta $c106,y ; source$DF7B: STA $0206,Y
.export BbOriginal_DF7E
BbOriginal_DF7E:
 ldx $c026 ; source$DF7E: LDX $26
.export BbOriginal_DF80
BbOriginal_DF80:
 rts  ; source$DF80: RTS
.export BbOriginal_DF81
BbOriginal_DF81:
 .byte $20
.export BbOriginal_DF82
BbOriginal_DF82:
 .byte $20
.export BbOriginal_DF83
BbOriginal_DF83:
 .byte $22
.export BbOriginal_DF84
BbOriginal_DF84:
 .byte $22
.export BbOriginal_DF85
BbOriginal_DF85:
 .byte $24
.export BbOriginal_DF86
BbOriginal_DF86:
 .byte $24
.export BbOriginal_DF87
BbOriginal_DF87:
 .byte $26
.export BbOriginal_DF88
BbOriginal_DF88:
 .byte $28
.export BbOriginal_DF89
BbOriginal_DF89:
 .byte $2a
.export BbOriginal_DF8A
BbOriginal_DF8A:
 .byte $2a
.export BbOriginal_DF8B
BbOriginal_DF8B:
 .byte $2c
.export BbOriginal_DF8C
BbOriginal_DF8C:
 .byte $2e
.export BbOriginal_DF8D
BbOriginal_DF8D:
 jsr BbOriginal_DFDF ; source$DF8D: JSR $dfdf
.export BbOriginal_DF90
BbOriginal_DF90:
 sec  ; source$DF90: SEC
.export BbOriginal_DF91
BbOriginal_DF91:
 lda $c107,y ; source$DF91: LDA $0207,Y
.export BbOriginal_DF94
BbOriginal_DF94:
 sbc $c021 ; source$DF94: SBC $21
.export BbOriginal_DF96
BbOriginal_DF96:
 jmp BbOriginal_DFA8 ; source$DF96: JMP $dfa8
.export BbOriginal_DF99
BbOriginal_DF99:
 sec  ; source$DF99: SEC
.export BbOriginal_DF9A
BbOriginal_DF9A:
 lda $c107,y ; source$DF9A: LDA $0207,Y
.export BbOriginal_DF9D
BbOriginal_DF9D:
 sbc #$03 ; source$DF9D: SBC #$03
.export BbOriginal_DF9F
BbOriginal_DF9F:
 jmp BbOriginal_DFA8 ; source$DF9F: JMP $dfa8
.export BbOriginal_DFA2
BbOriginal_DFA2:
 sec  ; source$DFA2: SEC
.export BbOriginal_DFA3
BbOriginal_DFA3:
 lda $c107,y ; source$DFA3: LDA $0207,Y
.export BbOriginal_DFA6
BbOriginal_DFA6:
 sbc #$01 ; source$DFA6: SBC #$01
.export BbOriginal_DFA8
BbOriginal_DFA8:
 cmp #$17 ; source$DFA8: CMP #$17
.export BbOriginal_DFAA
BbOriginal_DFAA:
 jcc BbOriginal_DFD5 ; source$DFAA: BCC $dfd5
.export BbOriginal_DFAC
BbOriginal_DFAC:
 sta $c107,y ; source$DFAC: STA $0207,Y
.export BbOriginal_DFAF
BbOriginal_DFAF:
 sbc #$08 ; source$DFAF: SBC #$08
.export BbOriginal_DFB1
BbOriginal_DFB1:
 sta $c103,y ; source$DFB1: STA $0203,Y
.export BbOriginal_DFB4
BbOriginal_DFB4:
 rts  ; source$DFB4: RTS
.export BbOriginal_DFB5
BbOriginal_DFB5:
 jsr BbOriginal_DFDF ; source$DFB5: JSR $dfdf
.export BbOriginal_DFB8
BbOriginal_DFB8:
 lda $c021 ; source$DFB8: LDA $21
.export BbOriginal_DFBA
BbOriginal_DFBA:
 jmp BbOriginal_DFC4 ; source$DFBA: JMP $dfc4
.export BbOriginal_DFBD
BbOriginal_DFBD:
 lda #$03 ; source$DFBD: LDA #$03
.export BbOriginal_DFBF
BbOriginal_DFBF:
 jmp BbOriginal_DFC4 ; source$DFBF: JMP $dfc4
.export BbOriginal_DFC2
BbOriginal_DFC2:
 lda #$01 ; source$DFC2: LDA #$01
.export BbOriginal_DFC4
BbOriginal_DFC4:
 clc  ; source$DFC4: CLC
.export BbOriginal_DFC5
BbOriginal_DFC5:
 adc $c103,y ; source$DFC5: ADC $0203,Y
.export BbOriginal_DFC8
BbOriginal_DFC8:
 cmp #$e7 ; source$DFC8: CMP #$e7
.export BbOriginal_DFCA
BbOriginal_DFCA:
 jcs BbOriginal_DFD5 ; source$DFCA: BCS $dfd5
.export BbOriginal_DFCC
BbOriginal_DFCC:
 sta $c103,y ; source$DFCC: STA $0203,Y
.export BbOriginal_DFCF
BbOriginal_DFCF:
 adc #$08 ; source$DFCF: ADC #$08
.export BbOriginal_DFD1
BbOriginal_DFD1:
 sta $c107,y ; source$DFD1: STA $0207,Y
.export BbOriginal_DFD4
BbOriginal_DFD4:
 rts  ; source$DFD4: RTS
.export BbOriginal_DFD5
BbOriginal_DFD5:
 lda $c002,x ; source$DFD5: LDA $02,X
.export BbOriginal_DFD7
BbOriginal_DFD7:
 cmp #$ff ; source$DFD7: CMP #$ff
.export BbOriginal_DFD9
BbOriginal_DFD9:
 jne BbOriginal_DFDE ; source$DFD9: BNE $dfde
.export BbOriginal_DFDB
BbOriginal_DFDB:
 jsr BbOriginal_DAA4 ; source$DFDB: JSR $daa4
.export BbOriginal_DFDE
BbOriginal_DFDE:
 rts  ; source$DFDE: RTS
.export BbOriginal_DFDF
BbOriginal_DFDF:
 lda $c102,y ; source$DFDF: LDA $0202,Y
.export BbOriginal_DFE2
BbOriginal_DFE2:
 jeq BbOriginal_DFE9 ; source$DFE2: BEQ $dfe9
.export BbOriginal_DFE4
BbOriginal_DFE4:
 lda $c030 ; source$DFE4: LDA $30
.export BbOriginal_DFE6
BbOriginal_DFE6:
 jmp BbOriginal_DFEB ; source$DFE6: JMP $dfeb
.export BbOriginal_DFE9
BbOriginal_DFE9:
 lda $c044 ; source$DFE9: LDA $44
.export BbOriginal_DFEB
BbOriginal_DFEB:
 and #$02 ; source$DFEB: AND #$02
.export BbOriginal_DFED
BbOriginal_DFED:
 clc  ; source$DFED: CLC
.export BbOriginal_DFEE
BbOriginal_DFEE:
 adc #$03 ; source$DFEE: ADC #$03
.export BbOriginal_DFF0
BbOriginal_DFF0:
 sta $c021 ; source$DFF0: STA $21
.export BbOriginal_DFF2
BbOriginal_DFF2:
 rts  ; source$DFF2: RTS
.export BbOriginal_DFF3
BbOriginal_DFF3:
 ldx #$88 ; source$DFF3: LDX #$88
.export BbOriginal_DFF5
BbOriginal_DFF5:
 lda $c000,x ; source$DFF5: LDA $00,X
.export BbOriginal_DFF7
BbOriginal_DFF7:
 jeq BbOriginal_E001 ; source$DFF7: BEQ $e001
.export BbOriginal_DFF9
BbOriginal_DFF9:
 cmp #$f0 ; source$DFF9: CMP #$f0
.export BbOriginal_DFFB
BbOriginal_DFFB:
 jcs BbOriginal_E001 ; source$DFFB: BCS $e001
.export BbOriginal_DFFD
BbOriginal_DFFD:
 lda #$05 ; source$DFFD: LDA #$05
.export BbOriginal_DFFF
BbOriginal_DFFF:
 sta $c000,x ; source$DFFF: STA $00,X
.export BbOriginal_E001
BbOriginal_E001:
 jsr BbOriginal_C39E ; source$E001: JSR $c39e
.export BbOriginal_E004
BbOriginal_E004:
 cpx #$c4 ; source$E004: CPX #$c4
.export BbOriginal_E006
BbOriginal_E006:
 jne BbOriginal_DFF5 ; source$E006: BNE $dff5
.export BbOriginal_E008
BbOriginal_E008:
 rts  ; source$E008: RTS
; Original bank6 $9528..$9602
.export BbOriginal_9528
BbOriginal_9528:
 lda $c003,x ; source$9528: LDA $03,X
.export BbOriginal_952A
BbOriginal_952A:
 cmp #$05 ; source$952A: CMP #$05
.export BbOriginal_952C
BbOriginal_952C:
 jne BbOriginal_9534 ; source$952C: BNE $9534
.export BbOriginal_952E
BbOriginal_952E:
 jsr BbOriginal_95D0 ; source$952E: JSR $95d0
.export BbOriginal_9531
BbOriginal_9531:
 jmp BbImportEnemyDraw ; source$9531: JMP $97c9
.export BbOriginal_9534
BbOriginal_9534:
 lda $c244 ; source$9534: LDA $0444
.export BbOriginal_9537
BbOriginal_9537:
 jne BbOriginal_953C ; source$9537: BNE $953c
.export BbOriginal_9539
BbOriginal_9539:
 jsr BbOriginal_DBAB ; source$9539: JSR $dbab
.export BbOriginal_953C
BbOriginal_953C:
 lda $c003,x ; source$953C: LDA $03,X
.export BbOriginal_953E
BbOriginal_953E:
 pha  ; source$953E: PHA
.export BbOriginal_953F
BbOriginal_953F:
 lda $c000,x ; source$953F: LDA $00,X
.export BbOriginal_9541
BbOriginal_9541:
 sta $c003,x ; source$9541: STA $03,X
.export BbOriginal_9543
BbOriginal_9543:
 pla  ; source$9543: PLA
.export BbOriginal_9544
BbOriginal_9544:
 sta $c000,x ; source$9544: STA $00,X
.export BbOriginal_9546
BbOriginal_9546:
 jsr BbOriginal_DC55 ; source$9546: JSR $dc55
.export BbOriginal_9549
BbOriginal_9549:
 lda $c000,x ; source$9549: LDA $00,X
.export BbOriginal_954B
BbOriginal_954B:
 pha  ; source$954B: PHA
.export BbOriginal_954C
BbOriginal_954C:
 lda $c003,x ; source$954C: LDA $03,X
.export BbOriginal_954E
BbOriginal_954E:
 sta $c000,x ; source$954E: STA $00,X
.export BbOriginal_9550
BbOriginal_9550:
 pla  ; source$9550: PLA
.export BbOriginal_9551
BbOriginal_9551:
 sta $c003,x ; source$9551: STA $03,X
.export BbOriginal_9553
BbOriginal_9553:
 lda $c291 ; source$9553: LDA $0491
.export BbOriginal_9556
BbOriginal_9556:
 jne BbOriginal_955D ; source$9556: BNE $955d
.export BbOriginal_9558
BbOriginal_9558:
 dec $c1ab,x ; source$9558: DEC $03ab,X
.export BbOriginal_955B
BbOriginal_955B:
 jeq BbOriginal_957A ; source$955B: BEQ $957a
.export BbOriginal_955D
BbOriginal_955D:
 lda $c1ab,x ; source$955D: LDA $03ab,X
.export BbOriginal_9560
BbOriginal_9560:
 cmp #$02 ; source$9560: CMP #$02
.export BbOriginal_9562
BbOriginal_9562:
 jcc BbOriginal_95B4 ; source$9562: BCC $95b4
.export BbOriginal_9564
BbOriginal_9564:
 cmp #$04 ; source$9564: CMP #$04
.export BbOriginal_9566
BbOriginal_9566:
 jcc BbOriginal_9571 ; source$9566: BCC $9571
.export BbOriginal_9568
BbOriginal_9568:
 lda $c002,x ; source$9568: LDA $02,X
.export BbOriginal_956A
BbOriginal_956A:
 and #$fb ; source$956A: AND #$fb
.export BbOriginal_956C
BbOriginal_956C:
 sta $c002,x ; source$956C: STA $02,X
.export BbOriginal_956E
BbOriginal_956E:
 jmp BbOriginal_95B1 ; source$956E: JMP $95b1
.export BbOriginal_9571
BbOriginal_9571:
 lda $c002,x ; source$9571: LDA $02,X
.export BbOriginal_9573
BbOriginal_9573:
 ora #$04 ; source$9573: ORA #$04
.export BbOriginal_9575
BbOriginal_9575:
 sta $c002,x ; source$9575: STA $02,X
.export BbOriginal_9577
BbOriginal_9577:
 jmp BbOriginal_95B1 ; source$9577: JMP $95b1
.export BbOriginal_957A
BbOriginal_957A:
 lda #$80 ; source$957A: LDA #$80
.export BbOriginal_957C
BbOriginal_957C:
 sta $c003,x ; source$957C: STA $03,X
.export BbOriginal_957E
BbOriginal_957E:
 lda $c002,x ; source$957E: LDA $02,X
.export BbOriginal_9580
BbOriginal_9580:
 and #$ef ; source$9580: AND #$ef
.export BbOriginal_9582
BbOriginal_9582:
 sta $c002,x ; source$9582: STA $02,X
.export BbOriginal_9584
BbOriginal_9584:
 lda $c001,x ; source$9584: LDA $01,X
.export BbOriginal_9586
BbOriginal_9586:
 and #$03 ; source$9586: AND #$03
.export BbOriginal_9588
BbOriginal_9588:
 ora #$8c ; source$9588: ORA #$8c
.export BbOriginal_958A
BbOriginal_958A:
 sta $c001,x ; source$958A: STA $01,X
.export BbOriginal_958C
BbOriginal_958C:
 lda $c103,y ; source$958C: LDA $0203,Y
.export BbOriginal_958F
BbOriginal_958F:
 cmp #$11 ; source$958F: CMP #$11
.export BbOriginal_9591
BbOriginal_9591:
 jcs BbOriginal_9598 ; source$9591: BCS $9598
.export BbOriginal_9593
BbOriginal_9593:
 lda #$10 ; source$9593: LDA #$10
.export BbOriginal_9595
BbOriginal_9595:
 jmp BbOriginal_959E ; source$9595: JMP $959e
.export BbOriginal_9598
BbOriginal_9598:
 cmp #$e1 ; source$9598: CMP #$e1
.export BbOriginal_959A
BbOriginal_959A:
 jcc BbOriginal_95A1 ; source$959A: BCC $95a1
.export BbOriginal_959C
BbOriginal_959C:
 lda #$e0 ; source$959C: LDA #$e0
.export BbOriginal_959E
BbOriginal_959E:
 sta $c103,y ; source$959E: STA $0203,Y
.export BbOriginal_95A1
BbOriginal_95A1:
 lda $c000,x ; source$95A1: LDA $00,X
.export BbOriginal_95A3
BbOriginal_95A3:
 and #$0f ; source$95A3: AND #$0f
.export BbOriginal_95A5
BbOriginal_95A5:
 cmp #$06 ; source$95A5: CMP #$06
.export BbOriginal_95A7
BbOriginal_95A7:
 jne BbOriginal_95AE ; source$95A7: BNE $95ae
.export BbOriginal_95A9
BbOriginal_95A9:
 lda #$80 ; source$95A9: LDA #$80
.export BbOriginal_95AB
BbOriginal_95AB:
 sta $c1ac,x ; source$95AB: STA $03ac,X
.export BbOriginal_95AE
BbOriginal_95AE:
 jmp BbImportEnemyRelease ; source$95AE: JMP $9603
.export BbOriginal_95B1
BbOriginal_95B1:
 jmp BbImportEnemyDraw ; source$95B1: JMP $97c9
.export BbOriginal_95B4
BbOriginal_95B4:
 lda $c291 ; source$95B4: LDA $0491
.export BbOriginal_95B7
BbOriginal_95B7:
 jeq BbOriginal_95B1 ; source$95B7: BEQ $95b1
.export BbOriginal_95B9
BbOriginal_95B9:
 cmp #$0a ; source$95B9: CMP #$0a
.export BbOriginal_95BB
BbOriginal_95BB:
 jcs BbOriginal_95B1 ; source$95BB: BCS $95b1
.export BbOriginal_95BD
BbOriginal_95BD:
 lda #$2c ; source$95BD: LDA #$2c
.export BbOriginal_95BF
BbOriginal_95BF:
 sta $c101,y ; source$95BF: STA $0201,Y
.export BbOriginal_95C2
BbOriginal_95C2:
 lda #$2e ; source$95C2: LDA #$2e
.export BbOriginal_95C4
BbOriginal_95C4:
 sta $c105,y ; source$95C4: STA $0205,Y
.export BbOriginal_95C7
BbOriginal_95C7:
 lda #$01 ; source$95C7: LDA #$01
.export BbOriginal_95C9
BbOriginal_95C9:
 sta $c102,y ; source$95C9: STA $0202,Y
.export BbOriginal_95CC
BbOriginal_95CC:
 sta $c106,y ; source$95CC: STA $0206,Y
.export BbOriginal_95CF
BbOriginal_95CF:
 rts  ; source$95CF: RTS
.export BbOriginal_95D0
BbOriginal_95D0:
 tya  ; source$95D0: TYA
.export BbOriginal_95D1
BbOriginal_95D1:
 pha  ; source$95D1: PHA
.export BbOriginal_95D2
BbOriginal_95D2:
 txa  ; source$95D2: TXA
.export BbOriginal_95D3
BbOriginal_95D3:
 pha  ; source$95D3: PHA
.export BbOriginal_95D4
BbOriginal_95D4:
 lda #$0a ; source$95D4: LDA #$0a
.export BbOriginal_95D6
BbOriginal_95D6:
 jsr BbImportSound ; source$95D6: JSR $fa81
.export BbOriginal_95D9
BbOriginal_95D9:
 pla  ; source$95D9: PLA
.export BbOriginal_95DA
BbOriginal_95DA:
 tax  ; source$95DA: TAX
.export BbOriginal_95DB
BbOriginal_95DB:
 pla  ; source$95DB: PLA
.export BbOriginal_95DC
BbOriginal_95DC:
 tay  ; source$95DC: TAY
.export BbOriginal_95DD
BbOriginal_95DD:
 lda $c002,x ; source$95DD: LDA $02,X
.export BbOriginal_95DF
BbOriginal_95DF:
 and #$20 ; source$95DF: AND #$20
.export BbOriginal_95E1
BbOriginal_95E1:
 ora #$18 ; source$95E1: ORA #$18
.export BbOriginal_95E3
BbOriginal_95E3:
 sta $c002,x ; source$95E3: STA $02,X
.export BbOriginal_95E5
BbOriginal_95E5:
 lda $c000,x ; source$95E5: LDA $00,X
.export BbOriginal_95E7
BbOriginal_95E7:
 and #$7f ; source$95E7: AND #$7f
.export BbOriginal_95E9
BbOriginal_95E9:
 sta $c003,x ; source$95E9: STA $03,X
.export BbOriginal_95EB
BbOriginal_95EB:
 lda $c000,x ; source$95EB: LDA $00,X
.export BbOriginal_95ED
BbOriginal_95ED:
 and #$7f ; source$95ED: AND #$7f
.export BbOriginal_95EF
BbOriginal_95EF:
 sta $c000,x ; source$95EF: STA $00,X
.export BbOriginal_95F1
BbOriginal_95F1:
 inc $c276 ; source$95F1: INC $0476
.export BbOriginal_95F4
BbOriginal_95F4:
 lda $c276 ; source$95F4: LDA $0476
.export BbOriginal_95F7
BbOriginal_95F7:
 and #$01 ; source$95F7: AND #$01
.export BbOriginal_95F9
BbOriginal_95F9:
 sta $c001,x ; source$95F9: STA $01,X
.export BbOriginal_95FB
BbOriginal_95FB:
 lda $c276 ; source$95FB: LDA $0476
.export BbOriginal_95FE
BbOriginal_95FE:
 and #$02 ; source$95FE: AND #$02
.export BbOriginal_9600
BbOriginal_9600:
 sta $c003,x ; source$9600: STA $03,X
.export BbOriginal_9602
BbOriginal_9602:
 rts  ; source$9602: RTS
; Original bank7 $EFD9..$F01D
.export BbOriginal_EFD9
BbOriginal_EFD9:
 lda $c000,x ; source$EFD9: LDA $00,X
.export BbOriginal_EFDB
BbOriginal_EFDB:
 jpl BbOriginal_F01D ; source$EFDB: BPL $f01d
.export BbOriginal_EFDD
BbOriginal_EFDD:
 and #$07 ; source$EFDD: AND #$07
.export BbOriginal_EFDF
BbOriginal_EFDF:
 cmp #$06 ; source$EFDF: CMP #$06
.export BbOriginal_EFE1
BbOriginal_EFE1:
 jcs BbOriginal_F01D ; source$EFE1: BCS $f01d
.export BbOriginal_EFE3
BbOriginal_EFE3:
 inc $c243 ; source$EFE3: INC $0443
.export BbOriginal_EFE6
BbOriginal_EFE6:
 sta $c000 ; source$EFE6: STA $00
.export BbOriginal_EFE8
BbOriginal_EFE8:
 lda #$00 ; source$EFE8: LDA #$00
.export BbOriginal_EFEA
BbOriginal_EFEA:
 sec  ; source$EFEA: SEC
.export BbOriginal_EFEB
BbOriginal_EFEB:
 rol a ; source$EFEB: ROL A
.export BbOriginal_EFEC
BbOriginal_EFEC:
 dec $c000 ; source$EFEC: DEC $00
.export BbOriginal_EFEE
BbOriginal_EFEE:
 jpl BbOriginal_EFEB ; source$EFEE: BPL $efeb
.export BbOriginal_EFF0
BbOriginal_EFF0:
 sta $c000 ; source$EFF0: STA $00
.export BbOriginal_EFF2
BbOriginal_EFF2:
 txa  ; source$EFF2: TXA
.export BbOriginal_EFF3
BbOriginal_EFF3:
 pha  ; source$EFF3: PHA
.export BbOriginal_EFF4
BbOriginal_EFF4:
 lda $c001,x ; source$EFF4: LDA $01,X
.export BbOriginal_EFF6
BbOriginal_EFF6:
 jmi BbOriginal_EFFD ; source$EFF6: BMI $effd
.export BbOriginal_EFF8
BbOriginal_EFF8:
 ldx #$2e ; source$EFF8: LDX #$2e
.export BbOriginal_EFFA
BbOriginal_EFFA:
 jmp BbOriginal_EFFF ; source$EFFA: JMP $efff
.export BbOriginal_EFFD
BbOriginal_EFFD:
 ldx #$42 ; source$EFFD: LDX #$42
.export BbOriginal_EFFF
BbOriginal_EFFF:
 lda $c000,x ; source$EFFF: LDA $00,X
.export BbOriginal_F001
BbOriginal_F001:
 jeq BbOriginal_F01B ; source$F001: BEQ $f01b
.export BbOriginal_F003
BbOriginal_F003:
 lda $c000 ; source$F003: LDA $00
.export BbOriginal_F005
BbOriginal_F005:
 ora $c010,x ; source$F005: ORA $10,X
.export BbOriginal_F007
BbOriginal_F007:
 sta $c010,x ; source$F007: STA $10,X
.export BbOriginal_F009
BbOriginal_F009:
 lda $c000 ; source$F009: LDA $00
.export BbOriginal_F00B
BbOriginal_F00B:
 jsr BbImportSpecialPop ; source$F00B: JSR $f272
.export BbOriginal_F00E
BbOriginal_F00E:
 tya  ; source$F00E: TYA
.export BbOriginal_F00F
BbOriginal_F00F:
 pha  ; source$F00F: PHA
.export BbOriginal_F010
BbOriginal_F010:
 txa  ; source$F010: TXA
.export BbOriginal_F011
BbOriginal_F011:
 pha  ; source$F011: PHA
.export BbOriginal_F012
BbOriginal_F012:
 lda #$15 ; source$F012: LDA #$15
.export BbOriginal_F014
BbOriginal_F014:
 jsr BbImportSound ; source$F014: JSR $fa81
.export BbOriginal_F017
BbOriginal_F017:
 pla  ; source$F017: PLA
.export BbOriginal_F018
BbOriginal_F018:
 tax  ; source$F018: TAX
.export BbOriginal_F019
BbOriginal_F019:
 pla  ; source$F019: PLA
.export BbOriginal_F01A
BbOriginal_F01A:
 tay  ; source$F01A: TAY
.export BbOriginal_F01B
BbOriginal_F01B:
 pla  ; source$F01B: PLA
.export BbOriginal_F01C
BbOriginal_F01C:
 tax  ; source$F01C: TAX
.export BbOriginal_F01D
BbOriginal_F01D:
 rts  ; source$F01D: RTS
.export BbBubbleTileTable
BbBubbleTileTable: .byte $20,$20,$22,$22,$24,$24,$26,$28,$2a,$2a,$2c,$2e,$20,$df
BbCodeEnd:
