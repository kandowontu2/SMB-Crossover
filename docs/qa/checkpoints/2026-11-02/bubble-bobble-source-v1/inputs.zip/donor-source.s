; Bubble Bobble USA, exact original instruction/data slices.
; Recovered labels are semantic annotations, not a claim of original source names.
.setcpu "6502"

.segment "OAM_HELPERS"
.org $c38f
; Original physical PRG16K bank 7, $C38F..$C3A7.
 LDA $0201,Y ; 7:C38F b9 01 02
 PHA ; 7:C392 48
 LDA $0205,Y ; 7:C393 b9 05 02
 STA $0201,Y ; 7:C396 99 01 02
 PLA ; 7:C399 68
 STA $0205,Y ; 7:C39A 99 05 02
 RTS ; 7:C39D 60
 INX ; 7:C39E e8
 INX ; 7:C39F e8
 INX ; 7:C3A0 e8
 INX ; 7:C3A1 e8
 TYA ; 7:C3A2 98
 CLC ; 7:C3A3 18
 ADC #$08 ; 7:C3A4 69 08
 TAY ; 7:C3A6 a8
 RTS ; 7:C3A7 60

.segment "DISTANCE"
.org $c43e
; Original physical PRG16K bank 7, $C43E..$C46F.
 STA $0467 ; 7:C43E 8d 67 04
 LDA $0203,Y ; 7:C441 b9 03 02
 CMP $22 ; 7:C444 c5 22
 BCC $c44d ; 7:C446 90 05
 SBC $22 ; 7:C448 e5 22
 JMP $c453 ; 7:C44A 4c 53 c4
 SEC ; 7:C44D 38
 LDA $22 ; 7:C44E a5 22
 SBC $0203,Y ; 7:C450 f9 03 02
 STA $23 ; 7:C453 85 23
 CMP $0467 ; 7:C455 cd 67 04
 BCS $c466 ; 7:C458 b0 0c
 LDA $0200,Y ; 7:C45A b9 00 02
 CMP $21 ; 7:C45D c5 21
 BCC $c467 ; 7:C45F 90 06
 SBC $21 ; 7:C461 e5 21
 CMP $0467 ; 7:C463 cd 67 04
 RTS ; 7:C466 60
 SEC ; 7:C467 38
 LDA $21 ; 7:C468 a5 21
 SBC $0200,Y ; 7:C46A f9 00 02
 JMP $c463 ; 7:C46D 4c 63 c4

.segment "SOURCE_CLOCK"
.org $ce30
; Original physical PRG16K bank 7, $CE30..$CE4C.
 INC $1f ; 7:CE30 e6 1f
 LDX #$27 ; 7:CE32 a2 27
 LDY #$2b ; 7:CE34 a0 2b
 DEC $00,X ; 7:CE36 d6 00
 BPL $ce40 ; 7:CE38 10 06
 LDA #$09 ; 7:CE3A a9 09
 STA $00,X ; 7:CE3C 95 00
 LDY #$2d ; 7:CE3E a0 2d
 TYA ; 7:CE40 98
 TAX ; 7:CE41 aa
 LDA $00,X ; 7:CE42 b5 00
 BEQ $ce48 ; 7:CE44 f0 02
 DEC $00,X ; 7:CE46 d6 00
 DEX ; 7:CE48 ca
 CPX #$27 ; 7:CE49 e0 27
 BNE $ce42 ; 7:CE4B d0 f5

.segment "TILE_QUERIES"
.org $d0be
; Original physical PRG16K bank 7, $D0BE..$D161.
 LDA $cfb5 ; 7:D0BE ad b5 cf
 STA $23 ; 7:D0C1 85 23
 LDA $cfb6 ; 7:D0C3 ad b6 cf
 STA $24 ; 7:D0C6 85 24
 LDA $21 ; 7:D0C8 a5 21
 AND #$f8 ; 7:D0CA 29 f8
 SEC ; 7:D0CC 38
 SBC #$20 ; 7:D0CD e9 20
 ASL A ; 7:D0CF 0a
 BCC $d0d6 ; 7:D0D0 90 04
 INC $24 ; 7:D0D2 e6 24
 INC $24 ; 7:D0D4 e6 24
 ASL A ; 7:D0D6 0a
 BCC $d0db ; 7:D0D7 90 02
 INC $24 ; 7:D0D9 e6 24
 CLC ; 7:D0DB 18
 ADC $23 ; 7:D0DC 65 23
 STA $23 ; 7:D0DE 85 23
 LDA $22 ; 7:D0E0 a5 22
 LSR A ; 7:D0E2 4a
 LSR A ; 7:D0E3 4a
 LSR A ; 7:D0E4 4a
 CLC ; 7:D0E5 18
 ADC $23 ; 7:D0E6 65 23
 STA $23 ; 7:D0E8 85 23
 LDA $24 ; 7:D0EA a5 24
 CMP #$09 ; 7:D0EC c9 09
 BNE $d0f4 ; 7:D0EE d0 04
 LDA #$05 ; 7:D0F0 a9 05
 STA $24 ; 7:D0F2 85 24
 CMP #$05 ; 7:D0F4 c9 05
 BCC $d107 ; 7:D0F6 90 0f
 CMP #$08 ; 7:D0F8 c9 08
 BCS $d107 ; 7:D0FA b0 0b
 STX $25 ; 7:D0FC 86 25
 LDX #$00 ; 7:D0FE a2 00
 LDA ($23,X) ; 7:D100 a1 23
 PHP ; 7:D102 08
 LDX $25 ; 7:D103 a6 25
 PLP ; 7:D105 28
 RTS ; 7:D106 60
 LDA #$07 ; 7:D107 a9 07
 STA $85 ; 7:D109 85 85
 LDA $23 ; 7:D10B a5 23
 AND #$1f ; 7:D10D 29 1f
 ORA #$e0 ; 7:D10F 09 e0
 STA $84 ; 7:D111 85 84
 STX $25 ; 7:D113 86 25
 LDX #$00 ; 7:D115 a2 00
 LDA ($84,X) ; 7:D117 a1 84
 PHP ; 7:D119 08
 LDX $25 ; 7:D11A a6 25
 PLP ; 7:D11C 28
 RTS ; 7:D11D 60
 INC $23 ; 7:D11E e6 23
 JMP $d0ea ; 7:D120 4c ea d0
 INC $23 ; 7:D123 e6 23
 INC $23 ; 7:D125 e6 23
 JMP $d0ea ; 7:D127 4c ea d0
 LDA #$20 ; 7:D12A a9 20
 BNE $d130 ; 7:D12C d0 02
 LDA #$40 ; 7:D12E a9 40
 CLC ; 7:D130 18
 ADC $23 ; 7:D131 65 23
 STA $23 ; 7:D133 85 23
 LDA #$00 ; 7:D135 a9 00
 ADC $24 ; 7:D137 65 24
 STA $24 ; 7:D139 85 24
 JMP $d0ea ; 7:D13B 4c ea d0
 SEC ; 7:D13E 38
 LDA $23 ; 7:D13F a5 23
 SBC #$20 ; 7:D141 e9 20
 JMP $d14b ; 7:D143 4c 4b d1
 SEC ; 7:D146 38
 LDA $23 ; 7:D147 a5 23
 SBC #$40 ; 7:D149 e9 40
 STA $23 ; 7:D14B 85 23
 LDA $24 ; 7:D14D a5 24
 SBC #$00 ; 7:D14F e9 00
 STA $24 ; 7:D151 85 24
 JMP $d0ea ; 7:D153 4c ea d0
 DEC $23 ; 7:D156 c6 23
 JMP $d0ea ; 7:D158 4c ea d0
 DEC $23 ; 7:D15B c6 23
 DEC $23 ; 7:D15D c6 23
 JMP $d0ea ; 7:D15F 4c ea d0

.segment "PLAYERS"
.org $d18a
; Original physical PRG16K bank 7, $D18A..$D770.
 LDX #$2e ; 7:D18A a2 2e
 JSR $d191 ; 7:D18C 20 91 d1
 LDX #$42 ; 7:D18F a2 42
 LDA #$00 ; 7:D191 a9 00
 STA $03,X ; 7:D193 95 03
 STA $06,X ; 7:D195 95 06
 STA $13,X ; 7:D197 95 13
 LDA $02,X ; 7:D199 b5 02
 AND #$3f ; 7:D19B 29 3f
 STA $02,X ; 7:D19D 95 02
 RTS ; 7:D19F 60
 LDA a:$0000,Y ; 7:D1A0 b9 00 00
 AND #$c0 ; 7:D1A3 29 c0
 LSR A ; 7:D1A5 4a
 LSR A ; 7:D1A6 4a
 STA $01,X ; 7:D1A7 95 01
 LDA a:$0000,Y ; 7:D1A9 b9 00 00
 AND #$03 ; 7:D1AC 29 03
 ASL A ; 7:D1AE 0a
 ASL A ; 7:D1AF 0a
 ORA $01,X ; 7:D1B0 15 01
 STA $01,X ; 7:D1B2 95 01
 LDA a:$0002,Y ; 7:D1B4 b9 02 00
 AND #$c3 ; 7:D1B7 29 c3
 ORA $01,X ; 7:D1B9 15 01
 STA $01,X ; 7:D1BB 95 01
 RTS ; 7:D1BD 60
 LDA #$01 ; 7:D1BE a9 01
 JSR $cee3 ; 7:D1C0 20 e3 ce
 JSR $d28e ; 7:D1C3 20 8e d2
 LDA #$01 ; 7:D1C6 a9 01
 JSR $cee3 ; 7:D1C8 20 e3 ce
 JSR $d24d ; 7:D1CB 20 4d d2
 LDA $28 ; 7:D1CE a5 28
 BNE $d1d6 ; 7:D1D0 d0 04
 LDA #$03 ; 7:D1D2 a9 03
 STA $28 ; 7:D1D4 85 28
 LDX #$2e ; 7:D1D6 a2 2e
 LDY #$00 ; 7:D1D8 a0 00
 JSR $d1e7 ; 7:D1DA 20 e7 d1
 LDX #$42 ; 7:D1DD a2 42
 LDY #$08 ; 7:D1DF a0 08
 JSR $d1e7 ; 7:D1E1 20 e7 d1
 JMP $d1c6 ; 7:D1E4 4c c6 d1
 LDA $13,X ; 7:D1E7 b5 13
 BEQ $d1f5 ; 7:D1E9 f0 0a
 DEC $13,X ; 7:D1EB d6 13
 LDA #$16 ; 7:D1ED a9 16
 JSR $d695 ; 7:D1EF 20 95 d6
 JMP $d709 ; 7:D1F2 4c 09 d7
 LDA $00,X ; 7:D1F5 b5 00
 BEQ $d24c ; 7:D1F7 f0 53
 LDA $0461 ; 7:D1F9 ad 61 04
 BNE $d20d ; 7:D1FC d0 0f
 TYA ; 7:D1FE 98
 PHA ; 7:D1FF 48
 LDY #$f5 ; 7:D200 a0 f5
 CMP #$00 ; 7:D202 c9 00
 BEQ $d208 ; 7:D204 f0 02
 LDY #$f6 ; 7:D206 a0 f6
 JSR $d1a0 ; 7:D208 20 a0 d1
 PLA ; 7:D20B 68
 TAY ; 7:D20C a8
 LDA $03,X ; 7:D20D b5 03
 BMI $d22b ; 7:D20F 30 1a
 JSR $d2c1 ; 7:D211 20 c1 d2
 JSR $d457 ; 7:D214 20 57 d4
 JSR $d324 ; 7:D217 20 24 d3
 LDA $02,X ; 7:D21A b5 02
 AND #$81 ; 7:D21C 29 81
 BEQ $d223 ; 7:D21E f0 03
 JSR $d324 ; 7:D220 20 24 d3
 LDA $045f ; 7:D223 ad 5f 04
 BEQ $d22b ; 7:D226 f0 03
 JSR $ee70 ; 7:D228 20 70 ee
 JSR $d40c ; 7:D22B 20 0c d4
 JSR $d580 ; 7:D22E 20 80 d5
 LDA $12,X ; 7:D231 b5 12
 BEQ $d244 ; 7:D233 f0 0f
 CMP #$0a ; 7:D235 c9 0a
 BCC $d23d ; 7:D237 90 04
 SBC #$0a ; 7:D239 e9 0a
 ORA #$10 ; 7:D23B 09 10
 JSR $c0a4 ; 7:D23D 20 a4 c0
 LDA #$00 ; 7:D240 a9 00
 STA $12,X ; 7:D242 95 12
 LDA $0462 ; 7:D244 ad 62 04
 BEQ $d24c ; 7:D247 f0 03
 JSR $8153 ; 7:D249 20 53 81
 RTS ; 7:D24C 60
 LDA $0456 ; 7:D24D ad 56 04
 BEQ $d264 ; 7:D250 f0 12
 LDA $29 ; 7:D252 a5 29
 BNE $d264 ; 7:D254 d0 0e
 LDA #$00 ; 7:D256 a9 00
 STA $0456 ; 7:D258 8d 56 04
 LDA $0457 ; 7:D25B ad 57 04
 STA $0458 ; 7:D25E 8d 58 04
 JSR $d278 ; 7:D261 20 78 d2
 LDA $0459 ; 7:D264 ad 59 04
 BEQ $d28d ; 7:D267 f0 24
 LDA $2a ; 7:D269 a5 2a
 BNE $d28d ; 7:D26B d0 20
 LDA #$00 ; 7:D26D a9 00
 STA $0459 ; 7:D26F 8d 59 04
 LDA $045a ; 7:D272 ad 5a 04
 STA $045b ; 7:D275 8d 5b 04
 SEC ; 7:D278 38
 SBC #$03 ; 7:D279 e9 03
 BCC $d28d ; 7:D27B 90 10
 LDX $2e ; 7:D27D a6 2e
 BEQ $d286 ; 7:D27F f0 05
 LDX $42 ; 7:D281 a6 42
 BEQ $d286 ; 7:D283 f0 01
 ASL A ; 7:D285 0a
 SEC ; 7:D286 38
 ADC $0405 ; 7:D287 6d 05 04
 STA $0405 ; 7:D28A 8d 05 04
 RTS ; 7:D28D 60
 LDA $2e ; 7:D28E a5 2e
 BEQ $d29f ; 7:D290 f0 0d
 LDX #$00 ; 7:D292 a2 00
 LDA $d2b1,X ; 7:D294 bd b1 d2
 STA $0200,X ; 7:D297 9d 00 02
 INX ; 7:D29A e8
 CPX #$08 ; 7:D29B e0 08
 BNE $d294 ; 7:D29D d0 f5
 LDA $42 ; 7:D29F a5 42
 BEQ $d2b0 ; 7:D2A1 f0 0d
 LDX #$00 ; 7:D2A3 a2 00
 LDA $d2b9,X ; 7:D2A5 bd b9 d2
 STA $0208,X ; 7:D2A8 9d 08 02
 INX ; 7:D2AB e8
 CPX #$08 ; 7:D2AC e0 08
 BNE $d2a5 ; 7:D2AE d0 f5
 RTS ; 7:D2B0 60
 .byte $60,$0a,$43,$60,$60,$00,$43,$68,$80,$00,$00,$90,$80,$0a,$00,$98 ; 7:D2B1 data/unclassified
 LDA $01,X ; 7:D2C1 b5 01
 AND #$10 ; 7:D2C3 29 10
 BEQ $d2ca ; 7:D2C5 f0 03
 JSR $d530 ; 7:D2C7 20 30 d5
 LDA $09,X ; 7:D2CA b5 09
 BEQ $d2d5 ; 7:D2CC f0 07
 JSR $d331 ; 7:D2CE 20 31 d3
 LDA #$00 ; 7:D2D1 a9 00
 STA $09,X ; 7:D2D3 95 09
 RTS ; 7:D2D5 60
 .byte $1c,$00,$00,$00,$01,$00,$01,$01,$01,$01,$01,$01,$01,$01,$02,$02 ; 7:D2D6 data/unclassified
 .byte $02,$02,$02,$02,$02,$02,$02,$02,$03,$03,$03,$03,$02 ; 7:D2E6 data/unclassified
 LDA $04,X ; 7:D2F3 b5 04
 STX $26 ; 7:D2F5 86 26
 TAX ; 7:D2F7 aa
 LDA $d2d7,X ; 7:D2F8 bd d7 d2
 BEQ $d314 ; 7:D2FB f0 17
 STA $0477 ; 7:D2FD 8d 77 04
 LDX $26 ; 7:D300 a6 26
 LDA $0200,Y ; 7:D302 b9 00 02
 AND #$07 ; 7:D305 29 07
 BNE $d30c ; 7:D307 d0 03
 JSR $d3a7 ; 7:D309 20 a7 d3
 JSR $d44e ; 7:D30C 20 4e d4
 DEC $0477 ; 7:D30F ce 77 04
 BNE $d302 ; 7:D312 d0 ee
 LDX $26 ; 7:D314 a6 26
 INC $04,X ; 7:D316 f6 04
 LDA $d2d6 ; 7:D318 ad d6 d2
 CMP $04,X ; 7:D31B d5 04
 BNE $d321 ; 7:D31D d0 02
 INC $03,X ; 7:D31F f6 03
 JMP $d518 ; 7:D321 4c 18 d5
 LDA $03,X ; 7:D324 b5 03
 BEQ $d365 ; 7:D326 f0 3d
 CMP #$01 ; 7:D328 c9 01
 BEQ $d386 ; 7:D32A f0 5a
 CMP #$02 ; 7:D32C c9 02
 BEQ $d2f3 ; 7:D32E f0 c3
 RTS ; 7:D330 60
 LDA $03,X ; 7:D331 b5 03
 BEQ $d34e ; 7:D333 f0 19
 BMI $d34d ; 7:D335 30 16
 CMP #$01 ; 7:D337 c9 01
 BEQ $d34d ; 7:D339 f0 12
 LDA $01,X ; 7:D33B b5 01
 AND #$80 ; 7:D33D 29 80
 BEQ $d34d ; 7:D33F f0 0c
 LDA #$00 ; 7:D341 a9 00
 STA $03,X ; 7:D343 95 03
 INC $0437 ; 7:D345 ee 37 04
 INC $12,X ; 7:D348 f6 12
 JSR $d36b ; 7:D34A 20 6b d3
 RTS ; 7:D34D 60
 LDA $09,X ; 7:D34E b5 09
 BPL $d34d ; 7:D350 10 fb
 LDA $01,X ; 7:D352 b5 01
 AND #$03 ; 7:D354 29 03
 BNE $d34d ; 7:D356 d0 f5
 LDA $0202,Y ; 7:D358 b9 02 02
 AND #$40 ; 7:D35B 29 40
 BNE $d362 ; 7:D35D d0 03
 JMP $d4be ; 7:D35F 4c be d4
 JMP $d46d ; 7:D362 4c 6d d4
 LDA $01,X ; 7:D365 b5 01
 AND #$20 ; 7:D367 29 20
 BEQ $d385 ; 7:D369 f0 1a
 LDA $01,X ; 7:D36B b5 01
 AND #$03 ; 7:D36D 29 03
 STA $05,X ; 7:D36F 95 05
 INC $03,X ; 7:D371 f6 03
 TYA ; 7:D373 98
 PHA ; 7:D374 48
 TXA ; 7:D375 8a
 PHA ; 7:D376 48
 LDA #$19 ; 7:D377 a9 19
 JSR $fa81 ; 7:D379 20 81 fa
 PLA ; 7:D37C 68
 TAX ; 7:D37D aa
 PLA ; 7:D37E 68
 TAY ; 7:D37F a8
 LDA $d2d6 ; 7:D380 ad d6 d2
 STA $04,X ; 7:D383 95 04
 RTS ; 7:D385 60
 LDA $04,X ; 7:D386 b5 04
 STX $25 ; 7:D388 86 25
 TAX ; 7:D38A aa
 SEC ; 7:D38B 38
 LDA $0200,Y ; 7:D38C b9 00 02
 SBC $d2d6,X ; 7:D38F fd d6 d2
 STA $0200,Y ; 7:D392 99 00 02
 STA $0204,Y ; 7:D395 99 04 02
 LDX $25 ; 7:D398 a6 25
 DEC $04,X ; 7:D39A d6 04
 BNE $d3a4 ; 7:D39C d0 06
 INC $03,X ; 7:D39E f6 03
 LDA #$00 ; 7:D3A0 a9 00
 STA $09,X ; 7:D3A2 95 09
 JMP $d518 ; 7:D3A4 4c 18 d5
 JSR $d3c1 ; 7:D3A7 20 c1 d3
 BEQ $d3b4 ; 7:D3AA f0 08
 LDX $26 ; 7:D3AC a6 26
 LDA #$00 ; 7:D3AE a9 00
 STA $03,X ; 7:D3B0 95 03
 PLA ; 7:D3B2 68
 PLA ; 7:D3B3 68
 RTS ; 7:D3B4 60
 LDA $0200,Y ; 7:D3B5 b9 00 02
 CMP #$d0 ; 7:D3B8 c9 d0
 BCS $d42b ; 7:D3BA b0 6f
 CMP #$10 ; 7:D3BC c9 10
 BCC $d42b ; 7:D3BE 90 6b
 RTS ; 7:D3C0 60
 JSR $d3b5 ; 7:D3C1 20 b5 d3
 LDA $0200,Y ; 7:D3C4 b9 00 02
 AND #$07 ; 7:D3C7 29 07
 BNE $d3f4 ; 7:D3C9 d0 29
 LDA $0200,Y ; 7:D3CB b9 00 02
 CLC ; 7:D3CE 18
 ADC #$08 ; 7:D3CF 69 08
 STA $21 ; 7:D3D1 85 21
 LDA $0203,Y ; 7:D3D3 b9 03 02
 STA $22 ; 7:D3D6 85 22
 INC $22 ; 7:D3D8 e6 22
 JSR $d0be ; 7:D3DA 20 be d0
 BEQ $d3f4 ; 7:D3DD f0 15
 JSR $d11e ; 7:D3DF 20 1e d1
 BEQ $d3f4 ; 7:D3E2 f0 10
 LDA $22 ; 7:D3E4 a5 22
 AND #$04 ; 7:D3E6 29 04
 BNE $d3fa ; 7:D3E8 d0 10
 JSR $d12a ; 7:D3EA 20 2a d1
 BEQ $d3f7 ; 7:D3ED f0 08
 JSR $d156 ; 7:D3EF 20 56 d1
 BEQ $d3f7 ; 7:D3F2 f0 03
 LDA #$00 ; 7:D3F4 a9 00
 RTS ; 7:D3F6 60
 LDA #$01 ; 7:D3F7 a9 01
 RTS ; 7:D3F9 60
 JSR $d11e ; 7:D3FA 20 1e d1
 BEQ $d3f4 ; 7:D3FD f0 f5
 JSR $d12a ; 7:D3FF 20 2a d1
 BEQ $d3f7 ; 7:D402 f0 f3
 JSR $d156 ; 7:D404 20 56 d1
 BEQ $d3f7 ; 7:D407 f0 ee
 JMP $d3ef ; 7:D409 4c ef d3
 LDA $03,X ; 7:D40C b5 03
 AND #$7f ; 7:D40E 29 7f
 BEQ $d417 ; 7:D410 f0 05
 CMP #$03 ; 7:D412 c9 03
 BEQ $d417 ; 7:D414 f0 01
 RTS ; 7:D416 60
 JSR $d3c1 ; 7:D417 20 c1 d3
 BEQ $d423 ; 7:D41A f0 07
 LDA $03,X ; 7:D41C b5 03
 AND #$80 ; 7:D41E 29 80
 STA $03,X ; 7:D420 95 03
 RTS ; 7:D422 60
 LDA $03,X ; 7:D423 b5 03
 AND #$80 ; 7:D425 29 80
 ORA #$03 ; 7:D427 09 03
 STA $03,X ; 7:D429 95 03
 LDA $0200,Y ; 7:D42B b9 00 02
 STA $84 ; 7:D42E 85 84
 INC $84 ; 7:D430 e6 84
 LDA $02,X ; 7:D432 b5 02
 AND #$81 ; 7:D434 29 81
 BEQ $d43e ; 7:D436 f0 06
 INC $84 ; 7:D438 e6 84
 LSR $84 ; 7:D43A 46 84
 ASL $84 ; 7:D43C 06 84
 LDA $84 ; 7:D43E a5 84
 STA $0200,Y ; 7:D440 99 00 02
 STA $0204,Y ; 7:D443 99 04 02
 CMP #$f4 ; 7:D446 c9 f4
 BNE $d44d ; 7:D448 d0 03
 INC $043a ; 7:D44A ee 3a 04
 RTS ; 7:D44D 60
 LDA $0200,Y ; 7:D44E b9 00 02
 CLC ; 7:D451 18
 ADC #$01 ; 7:D452 69 01
 JMP $d440 ; 7:D454 4c 40 d4
 LDA $03,X ; 7:D457 b5 03
 BMI $d4b8 ; 7:D459 30 5d
 BEQ $d463 ; 7:D45B f0 06
 LDA $28 ; 7:D45D a5 28
 CMP #$01 ; 7:D45F c9 01
 BNE $d4b8 ; 7:D461 d0 55
 LDA $01,X ; 7:D463 b5 01
 AND #$03 ; 7:D465 29 03
 BEQ $d4b8 ; 7:D467 f0 4f
 CMP #$01 ; 7:D469 c9 01
 BEQ $d4be ; 7:D46B f0 51
 LDA $0203,Y ; 7:D46D b9 03 02
 STA $22 ; 7:D470 85 22
 DEC $22 ; 7:D472 c6 22
 LDA $03,X ; 7:D474 b5 03
 BNE $d484 ; 7:D476 d0 0c
 LDA $02,X ; 7:D478 b5 02
 AND #$81 ; 7:D47A 29 81
 BEQ $d484 ; 7:D47C f0 06
 DEC $22 ; 7:D47E c6 22
 LSR $22 ; 7:D480 46 22
 ASL $22 ; 7:D482 06 22
 LDA $0200,Y ; 7:D484 b9 00 02
 CMP #$18 ; 7:D487 c9 18
 BCC $d4a9 ; 7:D489 90 1e
 CMP #$d0 ; 7:D48B c9 d0
 BCS $d4a9 ; 7:D48D b0 1a
 CLC ; 7:D48F 18
 ADC #$0f ; 7:D490 69 0f
 STA $21 ; 7:D492 85 21
 JSR $d0be ; 7:D494 20 be d0
 BNE $d4a9 ; 7:D497 d0 10
 LDA $03,X ; 7:D499 b5 03
 CMP #$01 ; 7:D49B c9 01
 BNE $d4b9 ; 7:D49D d0 1a
 JSR $d12a ; 7:D49F 20 2a d1
 BEQ $d4b9 ; 7:D4A2 f0 15
 JSR $d146 ; 7:D4A4 20 46 d1
 BEQ $d4b9 ; 7:D4A7 f0 10
 LDA $22 ; 7:D4A9 a5 22
 CMP #$11 ; 7:D4AB c9 11
 BCC $d4b9 ; 7:D4AD 90 0a
 STA $0203,Y ; 7:D4AF 99 03 02
 CLC ; 7:D4B2 18
 ADC #$08 ; 7:D4B3 69 08
 STA $0207,Y ; 7:D4B5 99 07 02
 RTS ; 7:D4B8 60
 LDA #$00 ; 7:D4B9 a9 00
 STA $05,X ; 7:D4BB 95 05
 RTS ; 7:D4BD 60
 LDA $0203,Y ; 7:D4BE b9 03 02
 CLC ; 7:D4C1 18
 ADC #$0f ; 7:D4C2 69 0f
 STA $22 ; 7:D4C4 85 22
 INC $22 ; 7:D4C6 e6 22
 LDA $03,X ; 7:D4C8 b5 03
 BNE $d4d8 ; 7:D4CA d0 0c
 LDA $02,X ; 7:D4CC b5 02
 AND #$81 ; 7:D4CE 29 81
 BEQ $d4d8 ; 7:D4D0 f0 06
 INC $22 ; 7:D4D2 e6 22
 LSR $22 ; 7:D4D4 46 22
 ASL $22 ; 7:D4D6 06 22
 LDA $0200,Y ; 7:D4D8 b9 00 02
 CMP #$18 ; 7:D4DB c9 18
 BCC $d4fd ; 7:D4DD 90 1e
 CMP #$d0 ; 7:D4DF c9 d0
 BCS $d4fd ; 7:D4E1 b0 1a
 CLC ; 7:D4E3 18
 ADC #$0f ; 7:D4E4 69 0f
 STA $21 ; 7:D4E6 85 21
 JSR $d0be ; 7:D4E8 20 be d0
 BNE $d4fd ; 7:D4EB d0 10
 LDA $03,X ; 7:D4ED b5 03
 CMP #$01 ; 7:D4EF c9 01
 BNE $d4b9 ; 7:D4F1 d0 c6
 JSR $d12a ; 7:D4F3 20 2a d1
 BEQ $d4b9 ; 7:D4F6 f0 c1
 JSR $d146 ; 7:D4F8 20 46 d1
 BEQ $d4b9 ; 7:D4FB f0 bc
 LDA $22 ; 7:D4FD a5 22
 CMP #$f0 ; 7:D4FF c9 f0
 BCS $d4b9 ; 7:D501 b0 b6
 SBC #$06 ; 7:D503 e9 06
 STA $0207,Y ; 7:D505 99 07 02
 SEC ; 7:D508 38
 SBC #$08 ; 7:D509 e9 08
 STA $0203,Y ; 7:D50B 99 03 02
 RTS ; 7:D50E 60
 LDA $05,X ; 7:D50F b5 05
 CMP #$01 ; 7:D511 c9 01
 BEQ $d4be ; 7:D513 f0 a9
 JMP $d46d ; 7:D515 4c 6d d4
 LDA $05,X ; 7:D518 b5 05
 BEQ $d528 ; 7:D51A f0 0c
 LDA $02,X ; 7:D51C b5 02
 AND #$81 ; 7:D51E 29 81
 BNE $d529 ; 7:D520 d0 07
 LDA $1f ; 7:D522 a5 1f
 AND #$01 ; 7:D524 29 01
 BNE $d50f ; 7:D526 d0 e7
 RTS ; 7:D528 60
 LDA $1f ; 7:D529 a5 1f
 AND #$03 ; 7:D52B 29 03
 BNE $d50f ; 7:D52D d0 e0
 RTS ; 7:D52F 60
 LDA $08,X ; 7:D530 b5 08
 BNE $d54d ; 7:D532 d0 19
 LDA #$19 ; 7:D534 a9 19
 STA $08,X ; 7:D536 95 08
 LDA $02,X ; 7:D538 b5 02
 AND #$04 ; 7:D53A 29 04
 BEQ $d540 ; 7:D53C f0 02
 LSR $08,X ; 7:D53E 56 08
 LDA #$80 ; 7:D540 a9 80
 CPX #$2e ; 7:D542 e0 2e
 BEQ $d547 ; 7:D544 f0 01
 LSR A ; 7:D546 4a
 ORA $0464 ; 7:D547 0d 64 04
 STA $0464 ; 7:D54A 8d 64 04
 RTS ; 7:D54D 60
 STX $0478 ; 7:D54E 8e 78 04
 LDX #$2e ; 7:D551 a2 2e
 LDA $11,X ; 7:D553 b5 11
 BNE $d574 ; 7:D555 d0 1d
 LDA #$c8 ; 7:D557 a9 c8
 STA $11,X ; 7:D559 95 11
 LDA #$80 ; 7:D55B a9 80
 STA $03,X ; 7:D55D 95 03
 LDA #$00 ; 7:D55F a9 00
 STA $07,X ; 7:D561 95 07
 LDA #$0a ; 7:D563 a9 0a
 STA $06,X ; 7:D565 95 06
 TYA ; 7:D567 98
 PHA ; 7:D568 48
 TXA ; 7:D569 8a
 PHA ; 7:D56A 48
 LDA #$11 ; 7:D56B a9 11
 JSR $fa81 ; 7:D56D 20 81 fa
 PLA ; 7:D570 68
 TAX ; 7:D571 aa
 PLA ; 7:D572 68
 TAY ; 7:D573 a8
 LDX $0478 ; 7:D574 ae 78 04
 RTS ; 7:D577 60
 STX $0478 ; 7:D578 8e 78 04
 LDX #$42 ; 7:D57B a2 42
 JMP $d553 ; 7:D57D 4c 53 d5
 JSR $d5d4 ; 7:D580 20 d4 d5
 INC $07,X ; 7:D583 f6 07
 LDA $06,X ; 7:D585 b5 06
 CMP #$0b ; 7:D587 c9 0b
 BCS $d5c2 ; 7:D589 b0 37
 JSR $d709 ; 7:D58B 20 09 d7
 LDA $11,X ; 7:D58E b5 11
 BEQ $d5a4 ; 7:D590 f0 12
 DEC $11,X ; 7:D592 d6 11
 AND #$01 ; 7:D594 29 01
 BNE $d5a4 ; 7:D596 d0 0c
 LDA #$27 ; 7:D598 a9 27
 STA $0201,Y ; 7:D59A 99 01 02
 STA $0205,Y ; 7:D59D 99 05 02
 LDA #$0b ; 7:D5A0 a9 0b
 STA $06,X ; 7:D5A2 95 06
 LDA $1f ; 7:D5A4 a5 1f
 AND #$04 ; 7:D5A6 29 04
 BEQ $d5c2 ; 7:D5A8 f0 18
 LDA $02,X ; 7:D5AA b5 02
 AND #$80 ; 7:D5AC 29 80
 BEQ $d5c3 ; 7:D5AE f0 13
 LDA $0202,Y ; 7:D5B0 b9 02 02
 ROR A ; 7:D5B3 6a
 BCC $d5ba ; 7:D5B4 90 04
 CLC ; 7:D5B6 18
 JMP $d5bb ; 7:D5B7 4c bb d5
 SEC ; 7:D5BA 38
 ROL A ; 7:D5BB 2a
 STA $0202,Y ; 7:D5BC 99 02 02
 STA $0206,Y ; 7:D5BF 99 06 02
 RTS ; 7:D5C2 60
 LDA $0202,Y ; 7:D5C3 b9 02 02
 ROR A ; 7:D5C6 6a
 ROR A ; 7:D5C7 6a
 LDA $0202,Y ; 7:D5C8 b9 02 02
 AND #$fc ; 7:D5CB 29 fc
 BCC $d5bc ; 7:D5CD 90 ed
 ORA #$03 ; 7:D5CF 09 03
 JMP $d5bc ; 7:D5D1 4c bc d5
 LDA $08,X ; 7:D5D4 b5 08
 BNE $d608 ; 7:D5D6 d0 30
 LDA $03,X ; 7:D5D8 b5 03
 BMI $d628 ; 7:D5DA 30 4c
 BEQ $d615 ; 7:D5DC f0 37
 CMP #$01 ; 7:D5DE c9 01
 BEQ $d5eb ; 7:D5E0 f0 09
 LDA $07,X ; 7:D5E2 b5 07
 AND #$10 ; 7:D5E4 29 10
 ORA #$80 ; 7:D5E6 09 80
 JMP $d61f ; 7:D5E8 4c 1f d6
 LDA $07,X ; 7:D5EB b5 07
 AND #$10 ; 7:D5ED 29 10
 ORA #$60 ; 7:D5EF 09 60
 JMP $d61f ; 7:D5F1 4c 1f d6
 AND #$0c ; 7:D5F4 29 0c
 BEQ $d5fc ; 7:D5F6 f0 04
 LDA #$00 ; 7:D5F8 a9 00
 STA $07,X ; 7:D5FA 95 07
 LDA $07,X ; 7:D5FC b5 07
 AND #$18 ; 7:D5FE 29 18
 LSR A ; 7:D600 4a
 LSR A ; 7:D601 4a
 LSR A ; 7:D602 4a
 ADC #$01 ; 7:D603 69 01
 JMP $d623 ; 7:D605 4c 23 d6
 DEC $08,X ; 7:D608 d6 08
 LDA $08,X ; 7:D60A b5 08
 AND #$f8 ; 7:D60C 29 f8
 BEQ $d5d8 ; 7:D60E f0 c8
 LDA #$0a ; 7:D610 a9 0a
 JMP $d623 ; 7:D612 4c 23 d6
 LDA $01,X ; 7:D615 b5 01
 AND #$0f ; 7:D617 29 0f
 BNE $d5f4 ; 7:D619 d0 d9
 LDA $07,X ; 7:D61B b5 07
 AND #$10 ; 7:D61D 29 10
 LSR A ; 7:D61F 4a
 LSR A ; 7:D620 4a
 LSR A ; 7:D621 4a
 LSR A ; 7:D622 4a
 CMP $06,X ; 7:D623 d5 06
 BNE $d693 ; 7:D625 d0 6c
 RTS ; 7:D627 60
 LDA $07,X ; 7:D628 b5 07
 AND #$07 ; 7:D62A 29 07
 BNE $d627 ; 7:D62C d0 f9
 INC $06,X ; 7:D62E f6 06
 LDA $06,X ; 7:D630 b5 06
 CMP #$16 ; 7:D632 c9 16
 BNE $d6af ; 7:D634 d0 79
 LDA #$00 ; 7:D636 a9 00
 STA $02,X ; 7:D638 95 02
 DEC $00,X ; 7:D63A d6 00
 BEQ $d65b ; 7:D63C f0 1d
 CPX #$2e ; 7:D63E e0 2e
 BNE $d64c ; 7:D640 d0 0a
 LDA #$18 ; 7:D642 a9 18
 STA $0203,Y ; 7:D644 99 03 02
 LDA #$20 ; 7:D647 a9 20
 JMP $d653 ; 7:D649 4c 53 d6
 LDA #$d8 ; 7:D64C a9 d8
 STA $0203,Y ; 7:D64E 99 03 02
 LDA #$e0 ; 7:D651 a9 e0
 STA $0207,Y ; 7:D653 99 07 02
 LDA #$c0 ; 7:D656 a9 c0
 JMP $d66a ; 7:D658 4c 6a d6
 CPX #$2e ; 7:D65B e0 2e
 BEQ $d665 ; 7:D65D f0 06
 STA $04a2 ; 7:D65F 8d a2 04
 JMP $d668 ; 7:D662 4c 68 d6
 STA $04a1 ; 7:D665 8d a1 04
 LDA #$f4 ; 7:D668 a9 f4
 STA $0200,Y ; 7:D66A 99 00 02
 STA $0204,Y ; 7:D66D 99 04 02
 LDA #$00 ; 7:D670 a9 00
 STA $03,X ; 7:D672 95 03
 LDA #$43 ; 7:D674 a9 43
 CPX #$2e ; 7:D676 e0 2e
 BEQ $d67c ; 7:D678 f0 02
 LDA #$00 ; 7:D67A a9 00
 STA $0202,Y ; 7:D67C 99 02 02
 STA $0206,Y ; 7:D67F 99 06 02
 LDA #$16 ; 7:D682 a9 16
 JSR $d693 ; 7:D684 20 93 d6
 JSR $c470 ; 7:D687 20 70 c4
 LDA $0462 ; 7:D68A ad 62 04
 BEQ $d692 ; 7:D68D f0 03
 JMP $8156 ; 7:D68F 4c 56 81
 RTS ; 7:D692 60
 STA $06,X ; 7:D693 95 06
 STX $26 ; 7:D695 86 26
 ASL A ; 7:D697 0a
 TAX ; 7:D698 aa
 LDA $0202,Y ; 7:D699 b9 02 02
 AND #$40 ; 7:D69C 29 40
 BNE $d6e7 ; 7:D69E d0 47
 LDA $d743,X ; 7:D6A0 bd 43 d7
 STA $0201,Y ; 7:D6A3 99 01 02
 LDA $d744,X ; 7:D6A6 bd 44 d7
 STA $0205,Y ; 7:D6A9 99 05 02
 LDX $26 ; 7:D6AC a6 26
 RTS ; 7:D6AE 60
 STA $06,X ; 7:D6AF 95 06
 STX $26 ; 7:D6B1 86 26
 ASL A ; 7:D6B3 0a
 TAX ; 7:D6B4 aa
 LDA $d744,X ; 7:D6B5 bd 44 d7
 CMP #$ff ; 7:D6B8 c9 ff
 BEQ $d6f3 ; 7:D6BA f0 37
 LDA $0202,Y ; 7:D6BC b9 02 02
 AND #$03 ; 7:D6BF 29 03
 ORA $d744,X ; 7:D6C1 1d 44 d7
 STA $0202,Y ; 7:D6C4 99 02 02
 STA $0206,Y ; 7:D6C7 99 06 02
 BMI $d6d8 ; 7:D6CA 30 0c
 LDA $d743,X ; 7:D6CC bd 43 d7
 STA $0201,Y ; 7:D6CF 99 01 02
 CLC ; 7:D6D2 18
 ADC #$02 ; 7:D6D3 69 02
 JMP $d6a9 ; 7:D6D5 4c a9 d6
 LDA $d743,X ; 7:D6D8 bd 43 d7
 STA $0205,Y ; 7:D6DB 99 05 02
 CLC ; 7:D6DE 18
 ADC #$02 ; 7:D6DF 69 02
 STA $0201,Y ; 7:D6E1 99 01 02
 LDX $26 ; 7:D6E4 a6 26
 RTS ; 7:D6E6 60
 LDA $d744,X ; 7:D6E7 bd 44 d7
 STA $0201,Y ; 7:D6EA 99 01 02
 LDA $d743,X ; 7:D6ED bd 43 d7
 JMP $d6a9 ; 7:D6F0 4c a9 d6
 LDA $0202,Y ; 7:D6F3 b9 02 02
 AND #$03 ; 7:D6F6 29 03
 STA $0202,Y ; 7:D6F8 99 02 02
 ORA #$40 ; 7:D6FB 09 40
 STA $0206,Y ; 7:D6FD 99 06 02
 LDA $d743,X ; 7:D700 bd 43 d7
 STA $0201,Y ; 7:D703 99 01 02
 JMP $d6a9 ; 7:D706 4c a9 d6
 LDA $01,X ; 7:D709 b5 01
 AND #$03 ; 7:D70B 29 03
 BEQ $d733 ; 7:D70D f0 24
 CMP #$01 ; 7:D70F c9 01
 BEQ $d734 ; 7:D711 f0 21
 LDA $0202,Y ; 7:D713 b9 02 02
 AND #$40 ; 7:D716 29 40
 BEQ $d733 ; 7:D718 f0 19
 LDA $0202,Y ; 7:D71A b9 02 02
 AND #$bf ; 7:D71D 29 bf
 STA $0202,Y ; 7:D71F 99 02 02
 STA $0206,Y ; 7:D722 99 06 02
 LDA $0201,Y ; 7:D725 b9 01 02
 PHA ; 7:D728 48
 LDA $0205,Y ; 7:D729 b9 05 02
 STA $0201,Y ; 7:D72C 99 01 02
 PLA ; 7:D72F 68
 STA $0205,Y ; 7:D730 99 05 02
 RTS ; 7:D733 60
 LDA $0202,Y ; 7:D734 b9 02 02
 AND #$40 ; 7:D737 29 40
 BNE $d733 ; 7:D739 d0 f8
 LDA $0202,Y ; 7:D73B b9 02 02
 ORA #$40 ; 7:D73E 09 40
 JMP $d71f ; 7:D740 4c 1f d7
 .byte $00,$0a,$00,$0c,$00,$0a,$02,$0c,$04,$0a,$02,$0c,$06,$0a,$06,$0e ; 7:D743 data/unclassified
 .byte $08,$0a,$08,$0e,$10,$12,$14,$00,$18,$00,$14,$c0,$18,$c0,$14,$00 ; 7:D753 data/unclassified
 .byte $18,$00,$14,$c0,$18,$c0,$1c,$ff,$1e,$ff,$27,$ff,$14,$16 ; 7:D763 data/unclassified

.segment "BUBBLES"
.org $d882
; Original physical PRG16K bank 7, $D882..$E008.
 LDA #$01 ; 7:D882 a9 01
 JSR $cee3 ; 7:D884 20 e3 ce
 LDX #$88 ; 7:D887 a2 88
 LDY #$88 ; 7:D889 a0 88
 LDA $00,X ; 7:D88B b5 00
 BEQ $d900 ; 7:D88D f0 71
 CMP #$ff ; 7:D88F c9 ff
 BEQ $d870 ; 7:D891 f0 dd
 CMP #$f6 ; 7:D893 c9 f6
 BEQ $d873 ; 7:D895 f0 dc
 CMP #$f7 ; 7:D897 c9 f7
 BEQ $d873 ; 7:D899 f0 d8
 CMP #$f8 ; 7:D89B c9 f8
 BEQ $d873 ; 7:D89D f0 d4
 JSR $da00 ; 7:D89F 20 00 da
 JSR $dad7 ; 7:D8A2 20 d7 da
 LDA $00,X ; 7:D8A5 b5 00
 BPL $d8b3 ; 7:D8A7 10 0a
 LDA $0200,Y ; 7:D8A9 b9 00 02
 CMP #$f4 ; 7:D8AC c9 f4
 BNE $d8b3 ; 7:D8AE d0 03
 JSR $daa4 ; 7:D8B0 20 a4 da
 JSR $c39e ; 7:D8B3 20 9e c3
 CPX #$c4 ; 7:D8B6 e0 c4
 BNE $d88b ; 7:D8B8 d0 d1
 LDA $0462 ; 7:D8BA ad 62 04
 BNE $d8d7 ; 7:D8BD d0 18
 LDX #$68 ; 7:D8BF a2 68
 LDY #$10 ; 7:D8C1 a0 10
 LDA $00,X ; 7:D8C3 b5 00
 BEQ $d8d0 ; 7:D8C5 f0 09
 LDA $02,X ; 7:D8C7 b5 02
 AND #$10 ; 7:D8C9 29 10
 BEQ $d8d0 ; 7:D8CB f0 03
 JSR $dae4 ; 7:D8CD 20 e4 da
 JSR $c39e ; 7:D8D0 20 9e c3
 CPX #$84 ; 7:D8D3 e0 84
 BNE $d8c3 ; 7:D8D5 d0 ec
 DEC $0444 ; 7:D8D7 ce 44 04
 BPL $d8e7 ; 7:D8DA 10 0b
 LDA $045d ; 7:D8DC ad 5d 04
 STA $0444 ; 7:D8DF 8d 44 04
 BPL $d8e7 ; 7:D8E2 10 03
 INC $0444 ; 7:D8E4 ee 44 04
 LDA $0407 ; 7:D8E7 ad 07 04
 BEQ $d8f4 ; 7:D8EA f0 08
 JSR $e009 ; 7:D8EC 20 09 e0
 LDA #$00 ; 7:D8EF a9 00
 STA $0407 ; 7:D8F1 8d 07 04
 JSR $dd6d ; 7:D8F4 20 6d dd
 JSR $dd24 ; 7:D8F7 20 24 dd
 JSR $f01e ; 7:D8FA 20 1e f0
 JMP $d882 ; 7:D8FD 4c 82 d8
 LDA $0464 ; 7:D900 ad 64 04
 BEQ $d8b3 ; 7:D903 f0 ae
 BPL $d957 ; 7:D905 10 50
 AND #$7f ; 7:D907 29 7f
 STA $0464 ; 7:D909 8d 64 04
 INC $00,X ; 7:D90C f6 00
 LDA $0460 ; 7:D90E ad 60 04
 BEQ $d919 ; 7:D911 f0 06
 LDA $30 ; 7:D913 a5 30
 AND #$08 ; 7:D915 29 08
 BNE $d98c ; 7:D917 d0 73
 LDA #$03 ; 7:D919 a9 03
 STA $0202,Y ; 7:D91B 99 02 02
 STA $0206,Y ; 7:D91E 99 06 02
 LDA $0200 ; 7:D921 ad 00 02
 STA $0200,Y ; 7:D924 99 00 02
 STA $0204,Y ; 7:D927 99 04 02
 LDA $0203 ; 7:D92A ad 03 02
 STA $0203,Y ; 7:D92D 99 03 02
 LDA $0207 ; 7:D930 ad 07 02
 STA $0207,Y ; 7:D933 99 07 02
 LDA $0202 ; 7:D936 ad 02 02
 AND #$40 ; 7:D939 29 40
 STA $01,X ; 7:D93B 95 01
 LDA #$08 ; 7:D93D a9 08
 STA $03,X ; 7:D93F 95 03
 TYA ; 7:D941 98
 PHA ; 7:D942 48
 TXA ; 7:D943 8a
 PHA ; 7:D944 48
 LDA #$16 ; 7:D945 a9 16
 JSR $fa81 ; 7:D947 20 81 fa
 PLA ; 7:D94A 68
 TAX ; 7:D94B aa
 PLA ; 7:D94C 68
 TAY ; 7:D94D a8
 INC $0435 ; 7:D94E ee 35 04
 JSR $df54 ; 7:D951 20 54 df
 JMP $d89f ; 7:D954 4c 9f d8
 AND #$bf ; 7:D957 29 bf
 STA $0464 ; 7:D959 8d 64 04
 INC $00,X ; 7:D95C f6 00
 LDA $0460 ; 7:D95E ad 60 04
 BEQ $d969 ; 7:D961 f0 06
 LDA $44 ; 7:D963 a5 44
 AND #$08 ; 7:D965 29 08
 BNE $d9df ; 7:D967 d0 76
 LDA #$00 ; 7:D969 a9 00
 STA $0202,Y ; 7:D96B 99 02 02
 STA $0206,Y ; 7:D96E 99 06 02
 LDA $0208 ; 7:D971 ad 08 02
 STA $0200,Y ; 7:D974 99 00 02
 STA $0204,Y ; 7:D977 99 04 02
 LDA $020b ; 7:D97A ad 0b 02
 STA $0203,Y ; 7:D97D 99 03 02
 LDA $020f ; 7:D980 ad 0f 02
 STA $0207,Y ; 7:D983 99 07 02
 LDA $020a ; 7:D986 ad 0a 02
 JMP $d939 ; 7:D989 4c 39 d9
 LDA $0200 ; 7:D98C ad 00 02
 STA $0200,Y ; 7:D98F 99 00 02
 STA $0204,Y ; 7:D992 99 04 02
 LDA $0203 ; 7:D995 ad 03 02
 STA $0203,Y ; 7:D998 99 03 02
 LDA $0207 ; 7:D99B ad 07 02
 STA $0207,Y ; 7:D99E 99 07 02
 LDA $0202 ; 7:D9A1 ad 02 02
 AND #$40 ; 7:D9A4 29 40
 STA $01,X ; 7:D9A6 95 01
 ORA #$01 ; 7:D9A8 09 01
 STA $0202,Y ; 7:D9AA 99 02 02
 STA $0206,Y ; 7:D9AD 99 06 02
 LDA $01,X ; 7:D9B0 b5 01
 BNE $d9be ; 7:D9B2 d0 0a
 LDA #$44 ; 7:D9B4 a9 44
 STA $0201,Y ; 7:D9B6 99 01 02
 LDA #$46 ; 7:D9B9 a9 46
 JMP $d9c5 ; 7:D9BB 4c c5 d9
 LDA #$46 ; 7:D9BE a9 46
 STA $0201,Y ; 7:D9C0 99 01 02
 LDA #$44 ; 7:D9C3 a9 44
 STA $0205,Y ; 7:D9C5 99 05 02
 LDA #$ff ; 7:D9C8 a9 ff
 STA $02,X ; 7:D9CA 95 02
 TYA ; 7:D9CC 98
 PHA ; 7:D9CD 48
 TXA ; 7:D9CE 8a
 PHA ; 7:D9CF 48
 LDA #$10 ; 7:D9D0 a9 10
 JSR $fa81 ; 7:D9D2 20 81 fa
 PLA ; 7:D9D5 68
 TAX ; 7:D9D6 aa
 PLA ; 7:D9D7 68
 TAY ; 7:D9D8 a8
 DEC $0460 ; 7:D9D9 ce 60 04
 JMP $d89f ; 7:D9DC 4c 9f d8
 LDA $0208 ; 7:D9DF ad 08 02
 STA $0200,Y ; 7:D9E2 99 00 02
 STA $0204,Y ; 7:D9E5 99 04 02
 LDA $020b ; 7:D9E8 ad 0b 02
 STA $0203,Y ; 7:D9EB 99 03 02
 LDA $020f ; 7:D9EE ad 0f 02
 STA $0207,Y ; 7:D9F1 99 07 02
 LDA $020a ; 7:D9F4 ad 0a 02
 JMP $d9a4 ; 7:D9F7 4c a4 d9
 JSR $de99 ; 7:D9FA 20 99 de
 JMP $da77 ; 7:D9FD 4c 77 da
 LDA $00,X ; 7:DA00 b5 00
 CMP #$01 ; 7:DA02 c9 01
 BEQ $da15 ; 7:DA04 f0 0f
 CMP #$04 ; 7:DA06 c9 04
 BEQ $da14 ; 7:DA08 f0 0a
 CMP #$05 ; 7:DA0A c9 05
 BEQ $da81 ; 7:DA0C f0 73
 JSR $db7f ; 7:DA0E 20 7f db
 JSR $dc55 ; 7:DA11 20 55 dc
 RTS ; 7:DA14 60
 LDA $02,X ; 7:DA15 b5 02
 CMP #$ff ; 7:DA17 c9 ff
 BEQ $d9fa ; 7:DA19 f0 df
 DEC $03,X ; 7:DA1B d6 03
 LDA $03,X ; 7:DA1D b5 03
 BNE $da52 ; 7:DA1F d0 31
 LDA #$08 ; 7:DA21 a9 08
 STA $03,X ; 7:DA23 95 03
 INC $02,X ; 7:DA25 f6 02
 JSR $df54 ; 7:DA27 20 54 df
 LDA $02,X ; 7:DA2A b5 02
 CMP #$03 ; 7:DA2C c9 03
 BNE $da52 ; 7:DA2E d0 22
 LDA $0202,Y ; 7:DA30 b9 02 02
 LSR A ; 7:DA33 4a
 LDA $30 ; 7:DA34 a5 30
 BCS $da3a ; 7:DA36 b0 02
 LDA $44 ; 7:DA38 a5 44
 AND #$40 ; 7:DA3A 29 40
 BEQ $da4c ; 7:DA3C f0 0e
 LDA #$f5 ; 7:DA3E a9 f5
 STA $00,X ; 7:DA40 95 00
 LDA #$30 ; 7:DA42 a9 30
 STA $0201,Y ; 7:DA44 99 01 02
 LDA #$32 ; 7:DA47 a9 32
 STA $0205,Y ; 7:DA49 99 05 02
 INC $00,X ; 7:DA4C f6 00
 LDA #$00 ; 7:DA4E a9 00
 STA $01,X ; 7:DA50 95 01
 LDA $0462 ; 7:DA52 ad 62 04
 BNE $da5a ; 7:DA55 d0 03
 JSR $de99 ; 7:DA57 20 99 de
 LDA $0200,Y ; 7:DA5A b9 00 02
 ADC #$08 ; 7:DA5D 69 08
 STA $21 ; 7:DA5F 85 21
 LDA $0203,Y ; 7:DA61 b9 03 02
 STA $22 ; 7:DA64 85 22
 LDA $01,X ; 7:DA66 b5 01
 BEQ $da71 ; 7:DA68 f0 07
 LDA $22 ; 7:DA6A a5 22
 CLC ; 7:DA6C 18
 ADC #$0f ; 7:DA6D 69 0f
 STA $22 ; 7:DA6F 85 22
 JSR $d0be ; 7:DA71 20 be d0
 BNE $da77 ; 7:DA74 d0 01
 RTS ; 7:DA76 60
 LDA $01,X ; 7:DA77 b5 01
 BEQ $da7e ; 7:DA79 f0 03
 JMP $dfb5 ; 7:DA7B 4c b5 df
 JMP $df8d ; 7:DA7E 4c 8d df
 LDA $1f ; 7:DA81 a5 1f
 AND #$03 ; 7:DA83 29 03
 BNE $dac4 ; 7:DA85 d0 3d
 LDA $02,X ; 7:DA87 b5 02
 CMP #$06 ; 7:DA89 c9 06
 BCC $da91 ; 7:DA8B 90 04
 LDA #$03 ; 7:DA8D a9 03
 STA $02,X ; 7:DA8F 95 02
 INC $02,X ; 7:DA91 f6 02
 JSR $df54 ; 7:DA93 20 54 df
 LDA $02,X ; 7:DA96 b5 02
 CMP #$04 ; 7:DA98 c9 04
 BEQ $dac5 ; 7:DA9A f0 29
 CMP #$05 ; 7:DA9C c9 05
 BEQ $dace ; 7:DA9E f0 2e
 CMP #$06 ; 7:DAA0 c9 06
 BNE $dac4 ; 7:DAA2 d0 20
 LDA $00,X ; 7:DAA4 b5 00
 CMP #$f6 ; 7:DAA6 c9 f6
 BCC $dab2 ; 7:DAA8 90 08
 DEC $0406 ; 7:DAAA ce 06 04
 BPL $dab2 ; 7:DAAD 10 03
 INC $0406 ; 7:DAAF ee 06 04
 LDA #$00 ; 7:DAB2 a9 00
 STA $00,X ; 7:DAB4 95 00
 STA $01,X ; 7:DAB6 95 01
 STA $02,X ; 7:DAB8 95 02
 STA $03,X ; 7:DABA 95 03
 LDA #$f4 ; 7:DABC a9 f4
 STA $0200,Y ; 7:DABE 99 00 02
 STA $0204,Y ; 7:DAC1 99 04 02
 RTS ; 7:DAC4 60
 LDA $0206,Y ; 7:DAC5 b9 06 02
 ORA #$40 ; 7:DAC8 09 40
 STA $0206,Y ; 7:DACA 99 06 02
 RTS ; 7:DACD 60
 LDA $0206,Y ; 7:DACE b9 06 02
 AND #$bf ; 7:DAD1 29 bf
 STA $0206,Y ; 7:DAD3 99 06 02
 RTS ; 7:DAD6 60
 LDA $00,X ; 7:DAD7 b5 00
 BMI $dae4 ; 7:DAD9 30 09
 CMP #$02 ; 7:DADB c9 02
 BEQ $dae4 ; 7:DADD f0 05
 CMP #$03 ; 7:DADF c9 03
 BEQ $dae4 ; 7:DAE1 f0 01
 RTS ; 7:DAE3 60
 DEC $0463 ; 7:DAE4 ce 63 04
 BNE $db43 ; 7:DAE7 d0 5a
 LDA #$05 ; 7:DAE9 a9 05
 STA $0463 ; 7:DAEB 8d 63 04
 LDA $0454 ; 7:DAEE ad 54 04
 BMI $daf6 ; 7:DAF1 30 03
 INC $0463 ; 7:DAF3 ee 63 04
 LDA $62 ; 7:DAF6 a5 62
 BMI $dafd ; 7:DAF8 30 03
 INC $0463 ; 7:DAFA ee 63 04
 STX $25 ; 7:DAFD 86 25
 STY $26 ; 7:DAFF 84 26
 LDA $0200,Y ; 7:DB01 b9 00 02
 STA $21 ; 7:DB04 85 21
 LDA $0203,Y ; 7:DB06 b9 03 02
 STA $22 ; 7:DB09 85 22
 LDX #$88 ; 7:DB0B a2 88
 LDY #$88 ; 7:DB0D a0 88
 CPX $25 ; 7:DB0F e4 25
 BEQ $db1f ; 7:DB11 f0 0c
 LDA $00,X ; 7:DB13 b5 00
 BMI $db4e ; 7:DB15 30 37
 CMP #$02 ; 7:DB17 c9 02
 BEQ $db4e ; 7:DB19 f0 33
 CMP #$03 ; 7:DB1B c9 03
 BEQ $db4e ; 7:DB1D f0 2f
 JSR $c39e ; 7:DB1F 20 9e c3
 CPX #$c4 ; 7:DB22 e0 c4
 BNE $db0f ; 7:DB24 d0 e9
 LDX #$68 ; 7:DB26 a2 68
 LDY #$10 ; 7:DB28 a0 10
 CPX $25 ; 7:DB2A e4 25
 BEQ $db38 ; 7:DB2C f0 0a
 LDA $00,X ; 7:DB2E b5 00
 BEQ $db38 ; 7:DB30 f0 06
 LDA $02,X ; 7:DB32 b5 02
 AND #$10 ; 7:DB34 29 10
 BNE $db44 ; 7:DB36 d0 0c
 JSR $c39e ; 7:DB38 20 9e c3
 CPX #$84 ; 7:DB3B e0 84
 BNE $db2a ; 7:DB3D d0 eb
 LDX $25 ; 7:DB3F a6 25
 LDY $26 ; 7:DB41 a4 26
 RTS ; 7:DB43 60
 LDA #$0b ; 7:DB44 a9 0b
 JSR $c43e ; 7:DB46 20 3e c4
 BCS $db38 ; 7:DB49 b0 ed
 JMP $db55 ; 7:DB4B 4c 55 db
 LDA #$0b ; 7:DB4E a9 0b
 JSR $c43e ; 7:DB50 20 3e c4
 BCS $db1f ; 7:DB53 b0 ca
 LDA $0200,Y ; 7:DB55 b9 00 02
 LDX $25 ; 7:DB58 a6 25
 LDY $26 ; 7:DB5A a4 26
 CMP $21 ; 7:DB5C c5 21
 BCC $db69 ; 7:DB5E 90 09
 LDA $0200,Y ; 7:DB60 b9 00 02
 SEC ; 7:DB63 38
 SBC #$02 ; 7:DB64 e9 02
 JMP $db6f ; 7:DB66 4c 6f db
 LDA $0200,Y ; 7:DB69 b9 00 02
 CLC ; 7:DB6C 18
 ADC #$02 ; 7:DB6D 69 02
 STA $0200,Y ; 7:DB6F 99 00 02
 STA $0204,Y ; 7:DB72 99 04 02
 LDA $63 ; 7:DB75 a5 63
 BPL $db7c ; 7:DB77 10 03
 JMP $df99 ; 7:DB79 4c 99 df
 JMP $dfbd ; 7:DB7C 4c bd df
 LDA $0444 ; 7:DB7F ad 44 04
 BEQ $db8a ; 7:DB82 f0 06
 RTS ; 7:DB84 60
 LDA #$05 ; 7:DB85 a9 05
 STA $00,X ; 7:DB87 95 00
 RTS ; 7:DB89 60
 LDA $00,X ; 7:DB8A b5 00
 BMI $dbab ; 7:DB8C 30 1d
 DEC $01,X ; 7:DB8E d6 01
 BNE $dbab ; 7:DB90 d0 19
 LDA $00,X ; 7:DB92 b5 00
 CMP #$03 ; 7:DB94 c9 03
 BEQ $db85 ; 7:DB96 f0 ed
 INC $00,X ; 7:DB98 f6 00
 LDA $0202,Y ; 7:DB9A b9 02 02
 AND #$fc ; 7:DB9D 29 fc
 ORA #$01 ; 7:DB9F 09 01
 STA $0202,Y ; 7:DBA1 99 02 02
 STA $0206,Y ; 7:DBA4 99 06 02
 LDA #$b4 ; 7:DBA7 a9 b4
 STA $01,X ; 7:DBA9 95 01
 JSR $dc33 ; 7:DBAB 20 33 dc
 STX $26 ; 7:DBAE 86 26
 TYA ; 7:DBB0 98
 TAX ; 7:DBB1 aa
 LDA $0200,Y ; 7:DBB2 b9 00 02
 ADC #$08 ; 7:DBB5 69 08
 STA $21 ; 7:DBB7 85 21
 LDA $0203,Y ; 7:DBB9 b9 03 02
 ADC #$08 ; 7:DBBC 69 08
 STA $22 ; 7:DBBE 85 22
 JSR $d0be ; 7:DBC0 20 be d0
 AND #$07 ; 7:DBC3 29 07
 CMP #$03 ; 7:DBC5 c9 03
 BEQ $dc04 ; 7:DBC7 f0 3b
 CMP #$04 ; 7:DBC9 c9 04
 BEQ $dbe9 ; 7:DBCB f0 1c
 CMP #$02 ; 7:DBCD c9 02
 BEQ $dc1f ; 7:DBCF f0 4e
 CMP #$07 ; 7:DBD1 c9 07
 BEQ $dc1f ; 7:DBD3 f0 4a
 DEC $0200,X ; 7:DBD5 de 00 02
 DEC $0204,X ; 7:DBD8 de 04 02
 LDA $045d ; 7:DBDB ad 5d 04
 BPL $dbe6 ; 7:DBDE 10 06
 DEC $0200,X ; 7:DBE0 de 00 02
 DEC $0204,X ; 7:DBE3 de 04 02
 LDX $26 ; 7:DBE6 a6 26
 RTS ; 7:DBE8 60
 LDA $0203,X ; 7:DBE9 bd 03 02
 CMP #$11 ; 7:DBEC c9 11
 BCC $dbe6 ; 7:DBEE 90 f6
 DEC $0203,X ; 7:DBF0 de 03 02
 DEC $0207,X ; 7:DBF3 de 07 02
 LDA $045d ; 7:DBF6 ad 5d 04
 BPL $dbe6 ; 7:DBF9 10 eb
 DEC $0203,X ; 7:DBFB de 03 02
 DEC $0207,X ; 7:DBFE de 07 02
 JMP $dbe6 ; 7:DC01 4c e6 db
 LDA $0203,X ; 7:DC04 bd 03 02
 CMP #$e0 ; 7:DC07 c9 e0
 BCS $dbe6 ; 7:DC09 b0 db
 INC $0203,X ; 7:DC0B fe 03 02
 INC $0207,X ; 7:DC0E fe 07 02
 LDA $045d ; 7:DC11 ad 5d 04
 BPL $dbe6 ; 7:DC14 10 d0
 INC $0203,X ; 7:DC16 fe 03 02
 INC $0207,X ; 7:DC19 fe 07 02
 JMP $dbe6 ; 7:DC1C 4c e6 db
 INC $0200,X ; 7:DC1F fe 00 02
 INC $0204,X ; 7:DC22 fe 04 02
 LDA $045d ; 7:DC25 ad 5d 04
 BPL $dbe6 ; 7:DC28 10 bc
 INC $0200,X ; 7:DC2A fe 00 02
 INC $0204,X ; 7:DC2D fe 04 02
 JMP $dbe6 ; 7:DC30 4c e6 db
 CPX #$84 ; 7:DC33 e0 84
 BCC $dc54 ; 7:DC35 90 1d
 LDA $00,X ; 7:DC37 b5 00
 CMP #$03 ; 7:DC39 c9 03
 BNE $dc54 ; 7:DC3B d0 17
 LDA $01,X ; 7:DC3D b5 01
 CMP #$50 ; 7:DC3F c9 50
 BCS $dc54 ; 7:DC41 b0 11
 AND #$01 ; 7:DC43 29 01
 STA $84 ; 7:DC45 85 84
 LDA $0202,Y ; 7:DC47 b9 02 02
 AND #$fc ; 7:DC4A 29 fc
 ORA $84 ; 7:DC4C 05 84
 STA $0202,Y ; 7:DC4E 99 02 02
 STA $0206,Y ; 7:DC51 99 06 02
 RTS ; 7:DC54 60
 LDA #$2e ; 7:DC55 a9 2e
 STA $24 ; 7:DC57 85 24
 LDA #$00 ; 7:DC59 a9 00
 STA $25 ; 7:DC5B 85 25
 JSR $dc68 ; 7:DC5D 20 68 dc
 LDA #$42 ; 7:DC60 a9 42
 STA $24 ; 7:DC62 85 24
 LDA #$08 ; 7:DC64 a9 08
 STA $25 ; 7:DC66 85 25
 STX $26 ; 7:DC68 86 26
 LDX $24 ; 7:DC6A a6 24
 LDA $00,X ; 7:DC6C b5 00
 BEQ $dcde ; 7:DC6E f0 6e
 LDX $25 ; 7:DC70 a6 25
 LDA $0200,X ; 7:DC72 bd 00 02
 STA $21 ; 7:DC75 85 21
 LDA $0203,X ; 7:DC77 bd 03 02
 STA $22 ; 7:DC7A 85 22
 LDA #$10 ; 7:DC7C a9 10
 JSR $c43e ; 7:DC7E 20 3e c4
 BCS $dcde ; 7:DC81 b0 5b
 CMP #$0a ; 7:DC83 c9 0a
 BCS $dc90 ; 7:DC85 b0 09
 LDA $23 ; 7:DC87 a5 23
 CMP #$0a ; 7:DC89 c9 0a
 BCS $dca4 ; 7:DC8B b0 17
 JMP $dce1 ; 7:DC8D 4c e1 dc
 LDA $21 ; 7:DC90 a5 21
 CMP $0200,Y ; 7:DC92 d9 00 02
 BCS $dca4 ; 7:DC95 b0 0d
 LDA $23 ; 7:DC97 a5 23
 CMP #$0a ; 7:DC99 c9 0a
 BCS $dca4 ; 7:DC9B b0 07
 LDX $24 ; 7:DC9D a6 24
 INC $09,X ; 7:DC9F f6 09
 JMP $dcde ; 7:DCA1 4c de dc
 LDX $25 ; 7:DCA4 a6 25
 SEC ; 7:DCA6 38
 LDA $0202,X ; 7:DCA7 bd 02 02
 AND #$40 ; 7:DCAA 29 40
 BNE $dcc6 ; 7:DCAC d0 18
 LDA $22 ; 7:DCAE a5 22
 SBC $0203,Y ; 7:DCB0 f9 03 02
 BCC $dcde ; 7:DCB3 90 29
 CMP #$0d ; 7:DCB5 c9 0d
 BCS $dcde ; 7:DCB7 b0 25
 LDX $24 ; 7:DCB9 a6 24
 LDA $09,X ; 7:DCBB b5 09
 ORA #$80 ; 7:DCBD 09 80
 STA $09,X ; 7:DCBF 95 09
 LDX $26 ; 7:DCC1 a6 26
 JMP $dfa2 ; 7:DCC3 4c a2 df
 LDA $0203,Y ; 7:DCC6 b9 03 02
 SBC $22 ; 7:DCC9 e5 22
 BCC $dcde ; 7:DCCB 90 11
 CMP #$0d ; 7:DCCD c9 0d
 BCS $dcde ; 7:DCCF b0 0d
 LDX $24 ; 7:DCD1 a6 24
 LDA $09,X ; 7:DCD3 b5 09
 ORA #$80 ; 7:DCD5 09 80
 STA $09,X ; 7:DCD7 95 09
 LDX $26 ; 7:DCD9 a6 26
 JMP $dfc2 ; 7:DCDB 4c c2 df
 LDX $26 ; 7:DCDE a6 26
 RTS ; 7:DCE0 60
 LDA #$00 ; 7:DCE1 a9 00
 CPX #$00 ; 7:DCE3 e0 00
 BEQ $dce9 ; 7:DCE5 f0 02
 LDA #$80 ; 7:DCE7 a9 80
 LDX $26 ; 7:DCE9 a6 26
 CPX #$88 ; 7:DCEB e0 88
 BCC $dd05 ; 7:DCED 90 16
 STA $01,X ; 7:DCEF 95 01
 LDA $00,X ; 7:DCF1 b5 00
 CMP #$f6 ; 7:DCF3 c9 f6
 BEQ $dd16 ; 7:DCF5 f0 1f
 CMP #$f7 ; 7:DCF7 c9 f7
 BEQ $dd16 ; 7:DCF9 f0 1b
 CMP #$f8 ; 7:DCFB c9 f8
 BEQ $dd16 ; 7:DCFD f0 17
 JSR $efd9 ; 7:DCFF 20 d9 ef
 JMP $dd0e ; 7:DD02 4c 0e dd
 ASL A ; 7:DD05 0a
 BCC $dd0e ; 7:DD06 90 06
 LDA $02,X ; 7:DD08 b5 02
 ORA #$20 ; 7:DD0A 09 20
 STA $02,X ; 7:DD0C 95 02
 LDA #$04 ; 7:DD0E a9 04
 STA $00,X ; 7:DD10 95 00
 INC $0436 ; 7:DD12 ee 36 04
 RTS ; 7:DD15 60
 LDA $01,X ; 7:DD16 b5 01
 ORA #$01 ; 7:DD18 09 01
 STA $01,X ; 7:DD1A 95 01
 DEC $0406 ; 7:DD1C ce 06 04
 LDA #$00 ; 7:DD1F a9 00
 STA $03,X ; 7:DD21 95 03
 RTS ; 7:DD23 60
 LDA $0464 ; 7:DD24 ad 64 04
 BNE $dd30 ; 7:DD27 d0 07
 LDA $0454 ; 7:DD29 ad 54 04
 CMP #$0a ; 7:DD2C c9 0a
 BCS $dd3d ; 7:DD2E b0 0d
 LDA #$03 ; 7:DD30 a9 03
 JSR $dd3e ; 7:DD32 20 3e dd
 JSR $dd4e ; 7:DD35 20 4e dd
 LDA #$00 ; 7:DD38 a9 00
 STA $0464 ; 7:DD3A 8d 64 04
 RTS ; 7:DD3D 60
 LDX #$88 ; 7:DD3E a2 88
 LDY #$88 ; 7:DD40 a0 88
 CMP $00,X ; 7:DD42 d5 00
 BEQ $dd68 ; 7:DD44 f0 22
 JSR $c39e ; 7:DD46 20 9e c3
 CPX #$c4 ; 7:DD49 e0 c4
 BNE $dd42 ; 7:DD4B d0 f5
 RTS ; 7:DD4D 60
 LDX #$88 ; 7:DD4E a2 88
 LDY #$88 ; 7:DD50 a0 88
 LDA #$02 ; 7:DD52 a9 02
 CMP $00,X ; 7:DD54 d5 00
 BNE $dd60 ; 7:DD56 d0 08
 LDA $01,X ; 7:DD58 b5 01
 BEQ $dd60 ; 7:DD5A f0 04
 CMP #$c8 ; 7:DD5C c9 c8
 BCC $dd68 ; 7:DD5E 90 08
 JSR $c39e ; 7:DD60 20 9e c3
 CPX #$c4 ; 7:DD63 e0 c4
 BNE $dd52 ; 7:DD65 d0 eb
 RTS ; 7:DD67 60
 PLA ; 7:DD68 68
 PLA ; 7:DD69 68
 JMP $dab2 ; 7:DD6A 4c b2 da
 LDX #$88 ; 7:DD6D a2 88
 LDY #$88 ; 7:DD6F a0 88
 LDA $00,X ; 7:DD71 b5 00
 CMP #$04 ; 7:DD73 c9 04
 BEQ $ddb2 ; 7:DD75 f0 3b
 LDA $00,X ; 7:DD77 b5 00
 BPL $dd88 ; 7:DD79 10 0d
 CMP #$ff ; 7:DD7B c9 ff
 BEQ $dd88 ; 7:DD7D f0 09
 LDA $01,X ; 7:DD7F b5 01
 LSR A ; 7:DD81 4a
 BCC $dd88 ; 7:DD82 90 04
 LDA $03,X ; 7:DD84 b5 03
 BEQ $ddb2 ; 7:DD86 f0 2a
 JSR $c39e ; 7:DD88 20 9e c3
 CPX #$c4 ; 7:DD8B e0 c4
 BNE $dd71 ; 7:DD8D d0 e2
 LDX #$68 ; 7:DD8F a2 68
 LDY #$10 ; 7:DD91 a0 10
 LDA $02,X ; 7:DD93 b5 02
 AND #$10 ; 7:DD95 29 10
 BEQ $dd9f ; 7:DD97 f0 06
 LDA $03,X ; 7:DD99 b5 03
 CMP #$04 ; 7:DD9B c9 04
 BEQ $dda7 ; 7:DD9D f0 08
 JSR $c39e ; 7:DD9F 20 9e c3
 CPX #$84 ; 7:DDA2 e0 84
 BNE $dd93 ; 7:DDA4 d0 ed
 RTS ; 7:DDA6 60
 STX $25 ; 7:DDA7 86 25
 LDA $02,X ; 7:DDA9 b5 02
 AND #$20 ; 7:DDAB 29 20
 ASL A ; 7:DDAD 0a
 ASL A ; 7:DDAE 0a
 JMP $ddb6 ; 7:DDAF 4c b6 dd
 STX $25 ; 7:DDB2 86 25
 LDA $01,X ; 7:DDB4 b5 01
 STA $26 ; 7:DDB6 85 26
 LDA $0200,Y ; 7:DDB8 b9 00 02
 STA $21 ; 7:DDBB 85 21
 LDA $0203,Y ; 7:DDBD b9 03 02
 STA $22 ; 7:DDC0 85 22
 LDX #$88 ; 7:DDC2 a2 88
 LDY #$88 ; 7:DDC4 a0 88
 LDA $00,X ; 7:DDC6 b5 00
 BMI $de2d ; 7:DDC8 30 63
 CMP #$02 ; 7:DDCA c9 02
 BEQ $de2d ; 7:DDCC f0 5f
 CMP #$03 ; 7:DDCE c9 03
 BEQ $de2d ; 7:DDD0 f0 5b
 JSR $c39e ; 7:DDD2 20 9e c3
 CPX #$c4 ; 7:DDD5 e0 c4
 BNE $ddc6 ; 7:DDD7 d0 ed
 LDX #$68 ; 7:DDD9 a2 68
 LDY #$10 ; 7:DDDB a0 10
 LDA $02,X ; 7:DDDD b5 02
 AND #$10 ; 7:DDDF 29 10
 BEQ $de02 ; 7:DDE1 f0 1f
 LDA $03,X ; 7:DDE3 b5 03
 CMP #$04 ; 7:DDE5 c9 04
 BEQ $de02 ; 7:DDE7 f0 19
 CMP #$05 ; 7:DDE9 c9 05
 BEQ $de02 ; 7:DDEB f0 15
 LDA #$0f ; 7:DDED a9 0f
 JSR $c43e ; 7:DDEF 20 3e c4
 BCS $de02 ; 7:DDF2 b0 0e
 LDA #$04 ; 7:DDF4 a9 04
 STA $03,X ; 7:DDF6 95 03
 LDA $26 ; 7:DDF8 a5 26
 BPL $de02 ; 7:DDFA 10 06
 LDA $02,X ; 7:DDFC b5 02
 ORA #$20 ; 7:DDFE 09 20
 STA $02,X ; 7:DE00 95 02
 JSR $c39e ; 7:DE02 20 9e c3
 CPX #$84 ; 7:DE05 e0 84
 BNE $dddd ; 7:DE07 d0 d4
 LDX $25 ; 7:DE09 a6 25
 CPX #$88 ; 7:DE0B e0 88
 BCC $de21 ; 7:DE0D 90 12
 LDA $00,X ; 7:DE0F b5 00
 BMI $de28 ; 7:DE11 30 15
 LDA #$05 ; 7:DE13 a9 05
 STA $00,X ; 7:DE15 95 00
 LDA $01,X ; 7:DE17 b5 01
 BPL $de1e ; 7:DE19 10 03
 INC $54 ; 7:DE1B e6 54
 RTS ; 7:DE1D 60
 INC $40 ; 7:DE1E e6 40
 RTS ; 7:DE20 60
 LDA #$05 ; 7:DE21 a9 05
 STA $03,X ; 7:DE23 95 03
 JMP $de69 ; 7:DE25 4c 69 de
 LDA #$ff ; 7:DE28 a9 ff
 STA $03,X ; 7:DE2A 95 03
 RTS ; 7:DE2C 60
 CMP #$ff ; 7:DE2D c9 ff
 BEQ $ddd2 ; 7:DE2F f0 a1
 LDA #$0f ; 7:DE31 a9 0f
 JSR $c43e ; 7:DE33 20 3e c4
 BCS $ddd2 ; 7:DE36 b0 9a
 LDA $00,X ; 7:DE38 b5 00
 CMP #$f6 ; 7:DE3A c9 f6
 BEQ $de54 ; 7:DE3C f0 16
 CMP #$f7 ; 7:DE3E c9 f7
 BEQ $de54 ; 7:DE40 f0 12
 CMP #$f8 ; 7:DE42 c9 f8
 BEQ $de54 ; 7:DE44 f0 0e
 LDA $26 ; 7:DE46 a5 26
 STA $01,X ; 7:DE48 95 01
 JSR $efd9 ; 7:DE4A 20 d9 ef
 LDA #$04 ; 7:DE4D a9 04
 STA $00,X ; 7:DE4F 95 00
 JMP $ddd2 ; 7:DE51 4c d2 dd
 LDA $01,X ; 7:DE54 b5 01
 LSR A ; 7:DE56 4a
 BCS $de66 ; 7:DE57 b0 0d
 LDA $26 ; 7:DE59 a5 26
 ORA #$01 ; 7:DE5B 09 01
 STA $01,X ; 7:DE5D 95 01
 DEC $0406 ; 7:DE5F ce 06 04
 LDA #$00 ; 7:DE62 a9 00
 STA $02,X ; 7:DE64 95 02
 JMP $ddd2 ; 7:DE66 4c d2 dd
 LDA $02,X ; 7:DE69 b5 02
 AND #$20 ; 7:DE6B 29 20
 BNE $de84 ; 7:DE6D d0 15
 LDA $0456 ; 7:DE6F ad 56 04
 BNE $de80 ; 7:DE72 d0 0c
 INC $0456 ; 7:DE74 ee 56 04
 LDA #$00 ; 7:DE77 a9 00
 STA $0457 ; 7:DE79 8d 57 04
 LDA #$14 ; 7:DE7C a9 14
 STA $29 ; 7:DE7E 85 29
 INC $0457 ; 7:DE80 ee 57 04
 RTS ; 7:DE83 60
 LDA $0459 ; 7:DE84 ad 59 04
 BNE $de95 ; 7:DE87 d0 0c
 INC $0459 ; 7:DE89 ee 59 04
 LDA #$00 ; 7:DE8C a9 00
 STA $045a ; 7:DE8E 8d 5a 04
 LDA #$14 ; 7:DE91 a9 14
 STA $2a ; 7:DE93 85 2a
 INC $045a ; 7:DE95 ee 5a 04
 RTS ; 7:DE98 60
 STX $25 ; 7:DE99 86 25
 STY $26 ; 7:DE9B 84 26
 LDA $0200,Y ; 7:DE9D b9 00 02
 STA $21 ; 7:DEA0 85 21
 LDA $0203,Y ; 7:DEA2 b9 03 02
 STA $22 ; 7:DEA5 85 22
 LDA $02,X ; 7:DEA7 b5 02
 STA $84 ; 7:DEA9 85 84
 LDX #$68 ; 7:DEAB a2 68
 LDY #$10 ; 7:DEAD a0 10
 LDA $00,X ; 7:DEAF b5 00
 BEQ $ded1 ; 7:DEB1 f0 1e
 LDA $84 ; 7:DEB3 a5 84
 BPL $debc ; 7:DEB5 10 05
 LDA #$08 ; 7:DEB7 a9 08
 JMP $debe ; 7:DEB9 4c be de
 LDA #$18 ; 7:DEBC a9 18
 AND $02,X ; 7:DEBE 35 02
 BNE $ded1 ; 7:DEC0 d0 0f
 LDA $01,X ; 7:DEC2 b5 01
 AND #$0f ; 7:DEC4 29 0f
 CMP #$0f ; 7:DEC6 c9 0f
 BEQ $ded1 ; 7:DEC8 f0 07
 LDA #$0c ; 7:DECA a9 0c
 JSR $c43e ; 7:DECC 20 3e c4
 BCC $dedd ; 7:DECF 90 0c
 JSR $c39e ; 7:DED1 20 9e c3
 CPX #$84 ; 7:DED4 e0 84
 BNE $deaf ; 7:DED6 d0 d7
 LDX $25 ; 7:DED8 a6 25
 LDY $26 ; 7:DEDA a4 26
 RTS ; 7:DEDC 60
 LDA $84 ; 7:DEDD a5 84
 BMI $df3c ; 7:DEDF 30 5b
 LDA $040a ; 7:DEE1 ad 0a 04
 STA $03ab,X ; 7:DEE4 9d ab 03
 LDA $02,X ; 7:DEE7 b5 02
 AND #$08 ; 7:DEE9 29 08
 BNE $df21 ; 7:DEEB d0 34
 LDA $21 ; 7:DEED a5 21
 STA $0200,Y ; 7:DEEF 99 00 02
 STA $0204,Y ; 7:DEF2 99 04 02
 LDA $22 ; 7:DEF5 a5 22
 STA $0203,Y ; 7:DEF7 99 03 02
 CLC ; 7:DEFA 18
 ADC #$08 ; 7:DEFB 69 08
 STA $0207,Y ; 7:DEFD 99 07 02
 LDA $02,X ; 7:DF00 b5 02
 ORA #$10 ; 7:DF02 09 10
 AND #$d0 ; 7:DF04 29 d0
 STA $02,X ; 7:DF06 95 02
 LDA #$00 ; 7:DF08 a9 00
 STA $03,X ; 7:DF0A 95 03
 LDA $01,X ; 7:DF0C b5 01
 AND #$03 ; 7:DF0E 29 03
 STA $01,X ; 7:DF10 95 01
 LDY $26 ; 7:DF12 a4 26
 LDA $0202,Y ; 7:DF14 b9 02 02
 AND #$03 ; 7:DF17 29 03
 BEQ $df21 ; 7:DF19 f0 06
 LDA $02,X ; 7:DF1B b5 02
 ORA #$01 ; 7:DF1D 09 01
 STA $02,X ; 7:DF1F 95 02
 LDX $25 ; 7:DF21 a6 25
 LDY $26 ; 7:DF23 a4 26
 LDA $02,X ; 7:DF25 b5 02
 CMP #$ff ; 7:DF27 c9 ff
 BEQ $df3b ; 7:DF29 f0 10
 LDA #$00 ; 7:DF2B a9 00
 STA $00,X ; 7:DF2D 95 00
 STA $02,X ; 7:DF2F 95 02
 LDA #$f4 ; 7:DF31 a9 f4
 STA $0200,Y ; 7:DF33 99 00 02
 STA $0204,Y ; 7:DF36 99 04 02
 PLA ; 7:DF39 68
 PLA ; 7:DF3A 68
 RTS ; 7:DF3B 60
 LDA $02,X ; 7:DF3C b5 02
 AND #$10 ; 7:DF3E 29 10
 BNE $df47 ; 7:DF40 d0 05
 LDA #$21 ; 7:DF42 a9 21
 JMP $df49 ; 7:DF44 4c 49 df
 LDA #$16 ; 7:DF47 a9 16
 STA $03ad,X ; 7:DF49 9d ad 03
 JSR $95d0 ; 7:DF4C 20 d0 95
 LDX $25 ; 7:DF4F a6 25
 LDY $26 ; 7:DF51 a4 26
 RTS ; 7:DF53 60
 LDA $02,X ; 7:DF54 b5 02
 ASL A ; 7:DF56 0a
 STX $26 ; 7:DF57 86 26
 TAX ; 7:DF59 aa
 LDA $df81,X ; 7:DF5A bd 81 df
 STA $0201,Y ; 7:DF5D 99 01 02
 LDA $df82,X ; 7:DF60 bd 82 df
 STA $0205,Y ; 7:DF63 99 05 02
 CMP $0201,Y ; 7:DF66 d9 01 02
 BNE $df76 ; 7:DF69 d0 0b
 LDA $0206,Y ; 7:DF6B b9 06 02
 ORA #$c0 ; 7:DF6E 09 c0
 STA $0206,Y ; 7:DF70 99 06 02
 LDX $26 ; 7:DF73 a6 26
 RTS ; 7:DF75 60
 LDA $0206,Y ; 7:DF76 b9 06 02
 AND #$3f ; 7:DF79 29 3f
 STA $0206,Y ; 7:DF7B 99 06 02
 LDX $26 ; 7:DF7E a6 26
 RTS ; 7:DF80 60
 .byte $20,$20,$22,$22,$24,$24,$26,$28,$2a,$2a,$2c,$2e ; 7:DF81 data/unclassified
 JSR $dfdf ; 7:DF8D 20 df df
 SEC ; 7:DF90 38
 LDA $0207,Y ; 7:DF91 b9 07 02
 SBC $21 ; 7:DF94 e5 21
 JMP $dfa8 ; 7:DF96 4c a8 df
 SEC ; 7:DF99 38
 LDA $0207,Y ; 7:DF9A b9 07 02
 SBC #$03 ; 7:DF9D e9 03
 JMP $dfa8 ; 7:DF9F 4c a8 df
 SEC ; 7:DFA2 38
 LDA $0207,Y ; 7:DFA3 b9 07 02
 SBC #$01 ; 7:DFA6 e9 01
 CMP #$17 ; 7:DFA8 c9 17
 BCC $dfd5 ; 7:DFAA 90 29
 STA $0207,Y ; 7:DFAC 99 07 02
 SBC #$08 ; 7:DFAF e9 08
 STA $0203,Y ; 7:DFB1 99 03 02
 RTS ; 7:DFB4 60
 JSR $dfdf ; 7:DFB5 20 df df
 LDA $21 ; 7:DFB8 a5 21
 JMP $dfc4 ; 7:DFBA 4c c4 df
 LDA #$03 ; 7:DFBD a9 03
 JMP $dfc4 ; 7:DFBF 4c c4 df
 LDA #$01 ; 7:DFC2 a9 01
 CLC ; 7:DFC4 18
 ADC $0203,Y ; 7:DFC5 79 03 02
 CMP #$e7 ; 7:DFC8 c9 e7
 BCS $dfd5 ; 7:DFCA b0 09
 STA $0203,Y ; 7:DFCC 99 03 02
 ADC #$08 ; 7:DFCF 69 08
 STA $0207,Y ; 7:DFD1 99 07 02
 RTS ; 7:DFD4 60
 LDA $02,X ; 7:DFD5 b5 02
 CMP #$ff ; 7:DFD7 c9 ff
 BNE $dfde ; 7:DFD9 d0 03
 JSR $daa4 ; 7:DFDB 20 a4 da
 RTS ; 7:DFDE 60
 LDA $0202,Y ; 7:DFDF b9 02 02
 BEQ $dfe9 ; 7:DFE2 f0 05
 LDA $30 ; 7:DFE4 a5 30
 JMP $dfeb ; 7:DFE6 4c eb df
 LDA $44 ; 7:DFE9 a5 44
 AND #$02 ; 7:DFEB 29 02
 CLC ; 7:DFED 18
 ADC #$03 ; 7:DFEE 69 03
 STA $21 ; 7:DFF0 85 21
 RTS ; 7:DFF2 60
 LDX #$88 ; 7:DFF3 a2 88
 LDA $00,X ; 7:DFF5 b5 00
 BEQ $e001 ; 7:DFF7 f0 08
 CMP #$f0 ; 7:DFF9 c9 f0
 BCS $e001 ; 7:DFFB b0 04
 LDA #$05 ; 7:DFFD a9 05
 STA $00,X ; 7:DFFF 95 00
 JSR $c39e ; 7:E001 20 9e c3
 CPX #$c4 ; 7:E004 e0 c4
 BNE $dff5 ; 7:E006 d0 ed
 RTS ; 7:E008 60

.segment "TRAPPED_ENEMY"
.org $9528
; Original physical PRG16K bank 6, $9528..$9602.
 LDA $03,X ; 6:9528 b5 03
 CMP #$05 ; 6:952A c9 05
 BNE $9534 ; 6:952C d0 06
 JSR $95d0 ; 6:952E 20 d0 95
 JMP $97c9 ; 6:9531 4c c9 97
 LDA $0444 ; 6:9534 ad 44 04
 BNE $953c ; 6:9537 d0 03
 JSR $dbab ; 6:9539 20 ab db
 LDA $03,X ; 6:953C b5 03
 PHA ; 6:953E 48
 LDA $00,X ; 6:953F b5 00
 STA $03,X ; 6:9541 95 03
 PLA ; 6:9543 68
 STA $00,X ; 6:9544 95 00
 JSR $dc55 ; 6:9546 20 55 dc
 LDA $00,X ; 6:9549 b5 00
 PHA ; 6:954B 48
 LDA $03,X ; 6:954C b5 03
 STA $00,X ; 6:954E 95 00
 PLA ; 6:9550 68
 STA $03,X ; 6:9551 95 03
 LDA $0491 ; 6:9553 ad 91 04
 BNE $955d ; 6:9556 d0 05
 DEC $03ab,X ; 6:9558 de ab 03
 BEQ $957a ; 6:955B f0 1d
 LDA $03ab,X ; 6:955D bd ab 03
 CMP #$02 ; 6:9560 c9 02
 BCC $95b4 ; 6:9562 90 50
 CMP #$04 ; 6:9564 c9 04
 BCC $9571 ; 6:9566 90 09
 LDA $02,X ; 6:9568 b5 02
 AND #$fb ; 6:956A 29 fb
 STA $02,X ; 6:956C 95 02
 JMP $95b1 ; 6:956E 4c b1 95
 LDA $02,X ; 6:9571 b5 02
 ORA #$04 ; 6:9573 09 04
 STA $02,X ; 6:9575 95 02
 JMP $95b1 ; 6:9577 4c b1 95
 LDA #$80 ; 6:957A a9 80
 STA $03,X ; 6:957C 95 03
 LDA $02,X ; 6:957E b5 02
 AND #$ef ; 6:9580 29 ef
 STA $02,X ; 6:9582 95 02
 LDA $01,X ; 6:9584 b5 01
 AND #$03 ; 6:9586 29 03
 ORA #$8c ; 6:9588 09 8c
 STA $01,X ; 6:958A 95 01
 LDA $0203,Y ; 6:958C b9 03 02
 CMP #$11 ; 6:958F c9 11
 BCS $9598 ; 6:9591 b0 05
 LDA #$10 ; 6:9593 a9 10
 JMP $959e ; 6:9595 4c 9e 95
 CMP #$e1 ; 6:9598 c9 e1
 BCC $95a1 ; 6:959A 90 05
 LDA #$e0 ; 6:959C a9 e0
 STA $0203,Y ; 6:959E 99 03 02
 LDA $00,X ; 6:95A1 b5 00
 AND #$0f ; 6:95A3 29 0f
 CMP #$06 ; 6:95A5 c9 06
 BNE $95ae ; 6:95A7 d0 05
 LDA #$80 ; 6:95A9 a9 80
 STA $03ac,X ; 6:95AB 9d ac 03
 JMP $9603 ; 6:95AE 4c 03 96
 JMP $97c9 ; 6:95B1 4c c9 97
 LDA $0491 ; 6:95B4 ad 91 04
 BEQ $95b1 ; 6:95B7 f0 f8
 CMP #$0a ; 6:95B9 c9 0a
 BCS $95b1 ; 6:95BB b0 f4
 LDA #$2c ; 6:95BD a9 2c
 STA $0201,Y ; 6:95BF 99 01 02
 LDA #$2e ; 6:95C2 a9 2e
 STA $0205,Y ; 6:95C4 99 05 02
 LDA #$01 ; 6:95C7 a9 01
 STA $0202,Y ; 6:95C9 99 02 02
 STA $0206,Y ; 6:95CC 99 06 02
 RTS ; 6:95CF 60
 TYA ; 6:95D0 98
 PHA ; 6:95D1 48
 TXA ; 6:95D2 8a
 PHA ; 6:95D3 48
 LDA #$0a ; 6:95D4 a9 0a
 JSR $fa81 ; 6:95D6 20 81 fa
 PLA ; 6:95D9 68
 TAX ; 6:95DA aa
 PLA ; 6:95DB 68
 TAY ; 6:95DC a8
 LDA $02,X ; 6:95DD b5 02
 AND #$20 ; 6:95DF 29 20
 ORA #$18 ; 6:95E1 09 18
 STA $02,X ; 6:95E3 95 02
 LDA $00,X ; 6:95E5 b5 00
 AND #$7f ; 6:95E7 29 7f
 STA $03,X ; 6:95E9 95 03
 LDA $00,X ; 6:95EB b5 00
 AND #$7f ; 6:95ED 29 7f
 STA $00,X ; 6:95EF 95 00
 INC $0476 ; 6:95F1 ee 76 04
 LDA $0476 ; 6:95F4 ad 76 04
 AND #$01 ; 6:95F7 29 01
 STA $01,X ; 6:95F9 95 01
 LDA $0476 ; 6:95FB ad 76 04
 AND #$02 ; 6:95FE 29 02
 STA $03,X ; 6:9600 95 03
 RTS ; 6:9602 60

.segment "SPECIAL_POP"
.org $efd9
; Original physical PRG16K bank 7, $EFD9..$F01D.
 LDA $00,X ; 7:EFD9 b5 00
 BPL $f01d ; 7:EFDB 10 40
 AND #$07 ; 7:EFDD 29 07
 CMP #$06 ; 7:EFDF c9 06
 BCS $f01d ; 7:EFE1 b0 3a
 INC $0443 ; 7:EFE3 ee 43 04
 STA $00 ; 7:EFE6 85 00
 LDA #$00 ; 7:EFE8 a9 00
 SEC ; 7:EFEA 38
 ROL A ; 7:EFEB 2a
 DEC $00 ; 7:EFEC c6 00
 BPL $efeb ; 7:EFEE 10 fb
 STA $00 ; 7:EFF0 85 00
 TXA ; 7:EFF2 8a
 PHA ; 7:EFF3 48
 LDA $01,X ; 7:EFF4 b5 01
 BMI $effd ; 7:EFF6 30 05
 LDX #$2e ; 7:EFF8 a2 2e
 JMP $efff ; 7:EFFA 4c ff ef
 LDX #$42 ; 7:EFFD a2 42
 LDA $00,X ; 7:EFFF b5 00
 BEQ $f01b ; 7:F001 f0 18
 LDA $00 ; 7:F003 a5 00
 ORA $10,X ; 7:F005 15 10
 STA $10,X ; 7:F007 95 10
 LDA $00 ; 7:F009 a5 00
 JSR $f272 ; 7:F00B 20 72 f2
 TYA ; 7:F00E 98
 PHA ; 7:F00F 48
 TXA ; 7:F010 8a
 PHA ; 7:F011 48
 LDA #$15 ; 7:F012 a9 15
 JSR $fa81 ; 7:F014 20 81 fa
 PLA ; 7:F017 68
 TAX ; 7:F018 aa
 PLA ; 7:F019 68
 TAY ; 7:F01A a8
 PLA ; 7:F01B 68
 TAX ; 7:F01C aa
 RTS ; 7:F01D 60
