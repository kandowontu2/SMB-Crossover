PpNativeCall=$da2a
PpNativeCallKind=$da48
PpNativeCallSlot=$da59
PpNativeInit=$d963
PpNativeMotionExport=$daa3
PpNativePitDeath=$d9eb
PpNativeQuietMusic=$da88
PpNativeQuietSfx=$da79
PpNativeRetire=$d98f
PpNativeServicesEnd=$dad1
PpNativeTick=$d999
PpNativeUnpublishedMaterial=$daa2
PpNativeProxyIn=$ddc9
PpNativeProxyOut=$dea4
PpNativeColors=$df9d
PpNativeContact=$bd22
PpNativeHealthStatus=$bd3a
PpNativePacket=$c200
PpNativeAdder=$bd3e
PpNativeVerticalExport=$bd42
PpNativeFullBox=$c799
PpNativePickup=$c7b5
PpNativeColdPrefix=$c780
BlockBufferColli_Head=$9587
BlockBufferColli_Side=$958b
PpHostDraw=$bbc1
.setcpu "6502"
PpServiceTag=$c09e ; Source world SavedY; overwritten before its only read.
.segment "FRESH_PREFIX"
.export PpNativeFresh,PpNativeFreshEnd
PpNativeFresh:
 lda #0
 ldx #7
FreshGap:
 sta $c0f8,x
 dex
 bpl FreshGap
 jmp PpNativeResetTail
PpNativeFreshEnd:
.segment "PUBLIC"
.export PpNativeResetTail,PpNativeRoute,PpNativePublicEnd
PpNativeResetTail:
 ldx #$af
FreshPrefix:
 sta $c000,x
 dex
 cpx #$ff
 bne FreshPrefix
 ldx #$0f
FreshGap2:
 sta $c352,x
 dex
 bpl FreshGap2
 ldx #$0b
FreshGap3:
 sta $c3ff,x
 dex
 bpl FreshGap3
 ldx #$6d
FreshGap4:
 sta $c491,x
 dex
 bpl FreshGap4
 ldx #$f9
FreshActorPage:
 sta $c606,x
 dex
 cpx #$ff
 bne FreshActorPage
 ldx #0
FreshLastPage:
 sta $c700,x
 inx
 bpl FreshLastPage
 jmp PpNativeInit

PpNativeRoute:
 pha
 lda PpServiceTag
 sec
 sbc #30
 bcc Scalar
 cmp #21
 bcs Scalar
 clc
 adc #<NativeVector
 sta VectorJump+1
 pla
VectorJump:jmp NativeVector
Scalar:
 lda PpServiceTag
 beq Tick
 cmp #6
 beq Draw
 cmp #108
 beq Fresh
 cmp #3
 beq Yes
 cmp #27
 beq Yes
 cmp #69
 beq Yes
 cmp #15
 beq Contact
 cmp #18
 beq Status
 cmp #72
 beq Pickup
 cmp #78
 beq Colors
 pla
 clc
 rts
Tick:pla
 jmp PpNativeTick
Draw:pla
 jmp PpHostDraw
Fresh:pla
 jmp PpNativeFresh
Contact:pla
 jmp PpNativeContact
Status:pla
 jmp PpNativeHealthStatus
Pickup:pla
 jmp PpNativePickup
Colors:pla
 jmp PpNativeColors
Yes:pla
 sec
 rts
NativeVector:
 jmp BlockBufferColli_Head
 jmp PpNativeContact
 jmp PpNativeAdder
 ldy #0
 rts
 jmp BlockBufferColli_Side
 jmp PpNativeFresh
 jmp PpNativeFullBox
.assert >NativeVector=>(NativeVector+20),error,"Native seven-row vector crosses page"
PpNativePublicEnd:
