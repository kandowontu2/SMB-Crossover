.setcpu "6502"
.segment "VENEER"
.export PrNrRare,PrNrRareEnd
PrNrRare:
 cmp #38
 beq Own
 cmp #37
 bcs Legacy
Own:jmp $a2c2
Legacy:jmp $a24e
PrNrRareEnd:
