"""Freeze existing ink/toggle/overflow evidence, without changing the product."""
from pathlib import Path
import ast,json,zipfile
import arthur_shadow_ownership_controls_v2 as T
A=T.A;R=T.R;O=T.O
def main():
 assert not(O/'handoff.json').exists();receipts=[O/'controls.json',O/'saturation-v2.json'];files=set()
 for p in receipts:
  d=json.loads(p.read_text());assert d['passed']
  for path,h in d['bindings'].items():assert A.sha(path)==h,(p,path)
 files.update(p.resolve()for p in O.iterdir()if p.is_file())
 negative=R/'build/arthur-shadow-ownership-v1';files.update(p.resolve()for p in negative.iterdir()if p.is_file())
 tools=['arthur_shadow_ownership_controls_v1.py','arthur_shadow_ownership_controls_v2.py','arthur_shadow_saturation_v1.py','arthur_shadow_saturation_v2.py','arthur_shadow_freeze_v1.py'];pending=[R/'tools/audit'/n for n in tools];seen=set()
 while pending:
  p=pending.pop().resolve()
  if p in seen:continue
  seen.add(p);files.add(p)
  for node in ast.walk(ast.parse(p.read_text())):
   names=[v.name for v in node.names]if isinstance(node,ast.Import)else[node.module]if isinstance(node,ast.ImportFrom)and node.module else[]
   for name in names:
    rel=Path(*name.split('.')).with_suffix('.py');q=next((folder/rel for folder in[p.parent,R/'tools/audit',R/'tools',R]if(folder/rel).is_file()),None)
    if q is not None:pending.append(q)
 for rel in['build/arthur-host-probe-fast-v1/handoff.json','build/arthur-host-probe-fast-v1/source-closure.json','build/arthur-host-probe-fast-v1/native-handoff-v1.json','build/full-menu-final-art-v1/manifest.json','build/full-menu-final-art-v1/arthur.png','build/arthur-source-v1/art-source.json','build/arthur-source-v1/arthur-original-sprites.chr','build/arthur-palette-leaf-v6/atlas-proof.json','tools/Windows/NEXXT 3.0/defaults/nes.pal']:
  files.add((R/rel).resolve())
 for rel in['arthur/cache-wrapper.s','arthur/cache-runtime.s','arthur/host-adapter.s','arthur/palette.s','src/metasprite_engine.s','arthur-full-roster-menu.s','frozen-inputs/src/player_outlines.s','frozen-inputs/build/pit-retold-host-v3/src/expanded.s']:files.add((T.PRIVATE.parent/rel).resolve())
 closure=O/'source-closure.json';closure.write_text(json.dumps(dict(product_change=False,private_ROM_sha256=A.sha(T.PRIVATE),shared_menu_ROM_sha256=A.sha(T.SHARED),files={p.relative_to(R).as_posix():A.sha(p)for p in sorted(files)}),indent=2)+'\n')
 archive=O/'source-ink-proof.zip'
 with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
  for p in sorted(files):z.write(p,p.relative_to(R).as_posix())
  z.write(closure,closure.relative_to(R).as_posix())
 handoff=dict(status='SOURCE_AUTHENTIC_INK_RETAINED_BOTH_OPTIONS_HARDWARE_SATURATION_OPEN',product_change=False,native=False,private_ROM_sha256=A.sha(T.PRIVATE),shared_menu_ROM_sha256=A.sha(T.SHARED),source_archive_sha256=A.sha(archive),source_closure_sha256=A.sha(closure),archive_bytes=archive.stat().st_size,archive_members=len(files)+1,receipts={p.name:A.sha(p)for p in receipts},menu_source_black_pixels_retained_each_option=107,source_pose_area_cases_per_option=201,source_black_pixels_checked_per_option=6672,complete_Main_updates_per_option=96,first_hardware_opaque_black_loss=dict(update=37,pose=18,pixel=[110,177],OAM_slot=59,line_rank=11),body_or_weapon_peak_physical_scanline=17,limits=['No redundant gate or product modification: raw32 already bypasses optional legacy outline filtering; source cache/white masks ignore the option.','Both pending menu and real private lives/source gameplay retain actual source opaque black.','Crowded source weapon scene still loses intrinsic body pixels to the normal8sprite scanline limit. Readability fix remains required.','Separate v1 unhidden-OAM fixture negative and v1 unlimited-winner attribution negative retained.','No new native run, shared install, campaign, performance or palette admission.'])
 (O/'handoff.json').write_text(json.dumps(handoff,indent=2)+'\n');print(json.dumps({k:v for k,v in handoff.items()if k!='limits'}))
if __name__=='__main__':main()
