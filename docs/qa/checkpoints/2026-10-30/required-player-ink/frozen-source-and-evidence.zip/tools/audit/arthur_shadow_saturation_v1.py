"""Attribute first missing Arthur black pixel to physical OAM evaluation.

Source CPU scenes only; preserves the prior both-option equivalence receipt.
"""
import collections,json,traceback
from pathlib import Path
import arthur_shadow_ownership_controls_v2 as T
C=T.C;A=T.A;R=T.R;O=T.O
def main():
 out=O/'saturation.json';assert not out.exists();proof=O/'controls.json';assert json.loads(proof.read_text())['passed']
 b=A.scoped_load(T.PRIVATE);q=C.prepare(b);q.put(PlayerOutlinesOff=1)
 source=json.loads((R/'build/arthur-source-v1/art-source.json').read_text());records={z['pose']:z for z in source['records']};sourcechr=(R/'build/arthur-source-v1/arthur-original-sprites.chr').read_bytes();sourcepal=source['palette']['hardware_indices'][16:32]
 source_rows={p:8 for p in range(22)}|{p:2 for p in range(32,54)}|{22:2,24:1,26:1}
 rows=[];first=None;d=dict(passed=False,native=False,product_change=False)
 try:
  for age in range(96):
   keys=1|(128 if age in[6,16]else 0)|(64 if 24<=age<78 and age%18<6 else 0)
   q.put(SavedJoypadBits=keys,SavedJoypad1Bits=keys,ArHostPad=keys,ArHostDue=int(age%3==0),NmiDisable=255,VRAM_Buffer1_Offset=0)
   cpu,tr,mn,ann,events=A.M.run_linked(q,'GameLoop')
   pal=[15,54,24,18,15,26,48,39,15,22,48,39,15,15,54,23]
   unlimited,occ,_=T.raster(q,pal,False);limited,_,discarded=T.raster(q,pal,True)
   pose=q.get('ArR_0522');assert pose in source_rows
   src=T.S.raster(records[pose],source_rows[pose],sourcechr,sourcepal)
   sx=q.get('ArR_05AF')+256*q.get('ArR_0583')-q.get('ArR_0064')-256*q.get('ArR_0065')
   page=q.get('ArR_056D');page=page if page<128 else page-256;sy=q.get('ArR_0599')+240*page+1
   expected={(sx+x,sy+y)for(x,y),(color,priority)in src.items()if color==15 and 0<=sx+x<256 and 0<=sy+y<240}
   missing={p for p in expected if p not in limited or limited[p][0]!=(0,0,0)}
   hardware={p for p in missing if p in unlimited and unlimited[p][0]==(0,0,0)}
   earlier=missing-hardware
   assert not earlier,('Source black already missing before hardware evaluation; investigate',age,pose,sorted(earlier)[:8])
   row=dict(age=age,pose=pose,source_black=len(expected),missing_source_black=len(missing),hardware_hidden_black=len(hardware),max_sprite_occupancy=max(occ.values(),default=0))
   rows.append(row)
   if hardware and first is None:
    p=min(hardware,key=lambda z:(z[1],z[0]));actors=[]
    for slot in range(64):
     y,t,a,x=bytes(q.m[512+slot*4:516+slot*4])
     if y+1<=p[1]<y+17:actors.append(dict(slot=slot,x=x,y=y+1,tile=t,attributes=a,accepted=len(actors)<8))
    first=dict(**row,pixel=list(p),source_origin=[sx,sy],same_line_OAM_in_hardware_priority=actors,missing_pixels=sorted(map(list,hardware),key=lambda z:(z[1],z[0])))
    T.image({(x,y):v[0]for(x,y),v in unlimited.items()},(256,240),O/'first-overflow-unlimited.png')
    T.image({(x,y):v[0]for(x,y),v in limited.items()},(256,240),O/'first-overflow-eight-sprites.png')
    marked={(x,y):v[0]for(x,y),v in limited.items()};marked.update({p:(255,0,255)for p in hardware});T.image(marked,(256,240),O/'first-overflow-missing-black-marked.png')
   if not hardware and age==0:
    T.image({(x,y):v[0]for(x,y),v in limited.items()},(256,240),O/'source-ink-no-overflow.png')
  d.update(passed=True,rows=rows,first_actual_Arthur_opaque_black_loss=first,total_Arthur_black_pixels_hidden=sum(v['hardware_hidden_black']for v in rows),max_sprite_occupancy=max(v['max_sprite_occupancy']for v in rows),scope='Same both-option-equivalent96update legal CPU scene; genuine OAM/CHR plus normal first8 sprites/scanline. Not a native capture or a claim that all source poses/real routes overflow.')
 except Exception as e:d.update(failure=repr(e),traceback=traceback.format_exc())
 d['bindings']={str(p.resolve()):A.sha(p)for p in[Path(__file__),Path(T.__file__),proof,T.PRIVATE,T.PRIVATE.with_suffix('.dbg'),R/'build/arthur-source-v1/art-source.json',R/'build/arthur-source-v1/arthur-original-sprites.chr']};out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items()if k not in['rows','bindings','scope']}));assert d['passed']
if __name__=='__main__':main()
