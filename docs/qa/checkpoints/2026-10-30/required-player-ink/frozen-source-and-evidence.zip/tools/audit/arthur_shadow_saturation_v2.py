"""Classify Arthur ink occlusion without assuming every body pixel wins OAM.

The preserved v1 negative first showed an earlier opaque sprite at120,178.
This successor examines actual nontransparent candidate records and hardware
priority. Source-pixel and both-option assertions remain in controls.json.
"""
import json,traceback
from pathlib import Path
import arthur_shadow_ownership_controls_v2 as T
C=T.C;A=T.A;R=T.R;O=T.O
def contributors(q,p,palette):
 x,y=p;rows=[];line=0
 for slot in range(64):
  yy,t,a,xx=bytes(q.m[512+slot*4:516+slot*4]);dy=y-yy-1;dx=x-xx
  if not 0<=dy<16:continue
  accepted=line<8;line+=1
  if not 0<=dx<8:continue
  sy=15-dy if a&128 else dy;sx=7-dx if a&64 else dx
  window=(t&1)*4+(t>>6);page=q.get('CurrentCHRBank',window)+256*(q.get('X5ChrMode',window)&3)
  at=1048592+page*1024+(t&62)*16;pat=q.b['raw'][at:at+32]
  value=(pat[sy//8*16+sy%8]>>(7-sx)&1)|((pat[sy//8*16+sy%8+8]>>(7-sx)&1)<<1)
  if value:rows.append(dict(slot=slot,accepted=accepted,line_rank=line,x=xx,y=yy+1,tile=t,attributes=a,physical_page=page,color=palette[(a&3)*4+value],RGB=list(T.rgb(palette[(a&3)*4+value]))))
 return rows
def main():
 out=O/'saturation-v2.json';assert not out.exists();proof=O/'controls.json';assert json.loads(proof.read_text())['passed']
 b=A.scoped_load(T.PRIVATE);q=C.prepare(b);q.put(PlayerOutlinesOff=1)
 source=json.loads((R/'build/arthur-source-v1/art-source.json').read_text());records={z['pose']:z for z in source['records']};sourcechr=(R/'build/arthur-source-v1/arthur-original-sprites.chr').read_bytes();sourcepal=source['palette']['hardware_indices'][16:32]
 source_rows={p:8 for p in range(22)}|{p:2 for p in range(32,54)}|{22:2,24:1,26:1}
 rows=[];first_hardware=None;first_priority=None;d=dict(passed=False,native=False,product_change=False)
 try:
  for age in range(96):
   keys=1|(128 if age in[6,16]else 0)|(64 if 24<=age<78 and age%18<6 else 0)
   q.put(SavedJoypadBits=keys,SavedJoypad1Bits=keys,ArHostPad=keys,ArHostDue=int(age%3==0),NmiDisable=255,VRAM_Buffer1_Offset=0)
   cpu,tr,mn,ann,events=A.M.run_linked(q,'GameLoop')
   pal=[15,54,24,18,15,26,48,39,15,22,48,39,15,15,54,23]
   unlimited,occ,_=T.raster(q,pal,False);limited,_,discarded=T.raster(q,pal,True)
   pose=q.get('ArR_0522');src=T.S.raster(records[pose],source_rows[pose],sourcechr,sourcepal)
   sx=q.get('ArR_05AF')+256*q.get('ArR_0583')-q.get('ArR_0064')-256*q.get('ArR_0065');page=q.get('ArR_056D');page=page if page<128 else page-256;sy=q.get('ArR_0599')+240*page+1
   expected={(sx+x,sy+y)for(x,y),(color,priority)in src.items()if color==15 and 0<=sx+x<256 and 0<=sy+y<240}
   missing={p for p in expected if p not in limited or limited[p][0]!=(0,0,0)};hardware=[];priority=[]
   for p in sorted(missing,key=lambda z:(z[1],z[0])):
    parts=contributors(q,p,pal);black=[v for v in parts if v['RGB']==[0,0,0]]
    assert black,('No opaque source black record at expected body pixel',age,pose,p,parts)
    accepted=[v for v in parts if v['accepted']]
    if not any(v['accepted']for v in black):
     hardware.append(p)
     if first_hardware is None:first_hardware=dict(age=age,pose=pose,pixel=list(p),actual_covering_parts=parts)
    else:
     assert accepted and accepted[0]['RGB']!=[0,0,0],('Unclassified missing black',age,pose,p,parts)
     priority.append(p)
     if first_priority is None:first_priority=dict(age=age,pose=pose,pixel=list(p),actual_covering_parts=parts)
   row=dict(age=age,pose=pose,source_black=len(expected),missing_source_black=len(missing),eight_sprite_hidden_black=len(hardware),earlier_opaque_OAM_priority_pixels=len(priority),max_sprite_occupancy=max(occ.values(),default=0));rows.append(row)
   if (hardware or priority)and not(O/'first-black-occlusion-marked.png').exists():
    T.image({p:v[0]for p,v in unlimited.items()},(256,240),O/'first-black-occlusion-unlimited.png');T.image({p:v[0]for p,v in limited.items()},(256,240),O/'first-black-occlusion-eight-sprites.png');marked={p:v[0]for p,v in limited.items()};marked.update({p:(255,0,255)for p in missing});T.image(marked,(256,240),O/'first-black-occlusion-marked.png')
  d.update(passed=True,rows=rows,first_eight_sprite_Arthur_black_occlusion=first_hardware,first_earlier_OAM_priority_Arthur_black_occlusion=first_priority,total_Arthur_black_pixels_hidden_by_eight_sprite_limit=sum(v['eight_sprite_hidden_black']for v in rows),total_Arthur_black_pixels_covered_by_prior_opaque_sprite=sum(v['earlier_opaque_OAM_priority_pixels']for v in rows),max_sprite_occupancy=max(v['max_sprite_occupancy']for v in rows),all_expected_opaque_source_black_present_in_actual_OAM_patterns=True,scope='Actual source-generated OAM/CHR in the same96update both-option-equivalent legal CPU scene. Physical first8 scanline evaluation, earlier OAM opaque winner retained. Not a native capture or a claim that all poses/routes overflow.')
 except Exception as e:d.update(failure=repr(e),traceback=traceback.format_exc())
 d['bindings']={str(p.resolve()):A.sha(p)for p in[Path(__file__),Path(T.__file__),proof,O/'saturation.json',T.PRIVATE,T.PRIVATE.with_suffix('.dbg'),R/'build/arthur-source-v1/art-source.json',R/'build/arthur-source-v1/arthur-original-sprites.chr']};out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items()if k not in['rows','bindings','scope']}));assert d['passed']
if __name__=='__main__':main()
