"""Actual Main/DrawAll C93 ingress and real ISR cuts for metadata prototype."""
from pathlib import Path
import itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import ff_fx_world_marker_controls_v2 as K
import ff_host_pickups_vectors_v2 as V
from ff_wram_host_isr_v4 import clone
H,M,T=K.H,K.M,K.T
address,location,sha=K.address,K.location,K.sha
O=K.O;P=K.P


def scene(b,variant,off,skip):
    m=M.setup(b)
    H.put(m,FfVariant=variant,PlayerOutlinesOff=off,ShouldSkipDrawSprites=skip,
        NmiDisable=255,VRAM_Buffer1_Offset=0)
    for i,(kind,x)in enumerate([(0,176),(6,208)]):
        for n,v in [('Enemy_Flag',1),('Enemy_ID',kind),('Enemy_State',0),('Enemy_X_Position',x),
          ('Enemy_PageLoc',0),('Enemy_Y_Position',176),('Enemy_Y_HighPos',1),('Enemy_MovingDir',1)]:
            m[address(b,n)+i]=v
    return m


def full_main(old,new):
    rows=[]
    for variant,off,skip in itertools.product(range(4),[0,1],[0,1]):
        memories=[scene(b,variant,off,skip)for b in[old,new]]
        for tick in range(4):
            results=[]
            for m in memories:
                H.put(m,SavedJoypadBits=0,A_B_Buttons=0,Left_Right_Buttons=0,
                    NmiDisable=255,VRAM_Buffer1_Offset=0)
                entries=[];tagged=set()
                gate=address(m.bundle,'FwNativeFlashProbe')
                store=address(m.bundle,'FfMuxWorldDraw::Tag')+5 if'FfMuxWorldDraw'in m.bundle['syms']else-1
                def observer(mem,c,i):
                    if c.pc==gate:entries.append([mem.rawtags[1],mem.rawtags[2],c.y])
                    if c.pc==store:tagged.add(len(mem.writes))
                m.writes.clear();m.ram_writes.clear()
                c,low=M.invoke_main(m,observer)
                exclude=set(range(0x100,0x200))
                app=bytes((m[a]&239 if 512<=a<768 and a%4==2 else m[a])for a in range(0x8000)if a not in exclude)
                ordered=[(a,v&239 if 512<=a<768 and a%4==2 else v)for i,(a,v)in enumerate(m.writes)if a not in exclude and i not in tagged]
                results.append(dict(reg=(c.a,c.x,c.y,c.p,c.sp),state=app,ordered=ordered,
                    CPU=c.processorCycles,low=low,entries=entries,tagged=len(tagged)))
            a,z=results
            assert a['reg']==z['reg'] and a['state']==z['state']
            assert a['ordered']==z['ordered']
            assert a['entries']==z['entries']
            assert all(rawA==132 and rawC==221 and 1<=y<=6 for rawA,rawC,y in z['entries'])
            if not skip:assert z['entries'],(variant,off,skip,tick)
            rows.append(dict(variant=variant,outlines_off=off,skip=skip,tick=tick,
                native_probe_entries=z['entries'],tagged_parts=z['tagged'],
                extra_CPU=z['CPU']-a['CPU'],minimum_SP=z['low']))
    return dict(pairs=len(rows),rows=rows,actual_Main_source_and_native_DrawAll_hooks=True,
        all_genuine_FF_probe_ingress_C93=True,all_original_outputs_and_ordered_application_writes_except_metadata_exact=True,
        extra_CPU=[min(r['extra_CPU']for r in rows),max(r['extra_CPU']for r in rows)])


def vectors(new):
    m=K.fixture(new,22,address(new,'METASPRITE_POWERUP_FIREFLOWER'),6,0,252,1,2)
    c=K.start(m,address(new,'METASPRITE_POWERUP_FIREFLOWER'),6)
    begin=address(new,'FfMuxWorldDraw');end=address(new,'FfMuxWorldDrawEnd')
    samples=[];seen=set()
    def capture(mem,c,i):
        key=(c.pc,mem.rawtags[1],mem.rawtags[2])
        if (begin<=c.pc<end or c.pc==address(new,'SmFreezeNativeFlashEnemy'))and key not in seen:
            seen.add(key);samples.append((i,clone(mem,c)))
    H.finish(m,c,capture)
    rows=[]
    for step,(state,cpu)in samples:
        for kind,lag in [('NMI',0),('NMI',255),('IRQ',0),('IRQ',255)]:
            m,c=clone(state,cpu);H.put(m,NmiDisable=lag)
            if kind=='IRQ'and c.p&c.INTERRUPT:continue
            proof=V.interrupt(m,c,kind)
            H.finish(m,c)
            assert c.sp==224
            rows.append(dict(step=step,kind=kind,lag=lag,**proof))
    return dict(instruction_seams=len(samples),actual_vector_cases=len(rows),rows=rows,
       all33SMC_R01_live_page1_raw_A_C_and_AXYP_restored=True)


def main():
    out=O/'main-and-isr-controls-v1.json';assert not out.exists()
    p=dict(passed=False,native=False,admitted=False,metadata_only=True,checks={})
    try:
        old=H.C.qualified(P/'candidate.nes');new=H.C.qualified(H.O/'candidate.nes')
        p['checks']['actual_Main']=full_main(old,new);print('actual Main/DrawAll ingress PASS',flush=True)
        p['checks']['actual_vectors']=vectors(new);print('actual NMI/IRQ marker stack seams PASS',flush=True)
        p['passed']=True
    except Exception as e:p.update(error=repr(e),traceback=traceback.format_exc())
    p['bindings']={str(f.resolve()):sha(f)for f in[Path(__file__),Path(K.__file__),Path(M.__file__),Path(V.__file__),
       O/'source-closure.json',O/'marker-controls-v2.json',P/'candidate.nes',P/'candidate.dbg',H.O/'candidate.nes',H.O/'candidate.dbg']}
    t=out if p['passed']else O/'main-and-isr-negative-v1.json'
    t.write_text(json.dumps(p,indent=2)+'\n',newline='\n')
    print(json.dumps(dict(passed=p['passed'],path=str(t),error=p.get('error'))),flush=True);assert p['passed']


if __name__=='__main__':main()
