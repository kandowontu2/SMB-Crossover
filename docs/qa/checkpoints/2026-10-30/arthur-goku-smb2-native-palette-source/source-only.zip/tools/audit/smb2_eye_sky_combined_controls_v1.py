"""Targeted same repaired consumers on actual remap+S2 source union."""
from pathlib import Path
P=Path(__file__).with_name('smb2_eye_sky_controls_v1.py');s=P.read_text(encoding='utf-8')
s=s.replace('build/smb2-eye-sky-controls-v1','build/smb2-eye-sky-combined-controls-v1').replace("J=R/'build/smb2-eye-sky-v3/joint'","J=R/'build/arthur-goku-smb2-palette-v1/joint'")
s=s.replace('f0ce3d16fe0130924e6d1afeb541ed1c7cd8fe4bfd06c86621a5713fa73e979c','37210891ffbf79373bf3390d16ead891b0e8f43408603a07273f12297a36121a')
a=s.index("  a=scoped_load(P/'candidate.nes')");b=s.index('  bases=[seed(v)',a);s=s[:a]+s[b:]
a=s.index('  rows=[]\n  for off in range(85):');b=s.index('  rows=[]\n  for var,mode',a);s=s[:a]+s[b:]
a=s.index('  # Every emitted instruction');b=s.index("  q['passed']=True",a);s=s[:a]+s[b:]
s=s.replace("O.parent/'smb2-eye-sky-v3/source-proof.json'","R/'build/smb2-eye-sky-v3/source-proof.json'")
exec(compile(s,str(P),'exec'),{'__name__':'__main__','__file__':str(Path(__file__).resolve())})
