"""Real unchanged NMI/IRQ consumers, foreign parity and preflush budget."""
from pathlib import Path
import itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import ff_fx_palette_lifecycle_controls_v5 as L
from check_tmnt_render_oa import address
from ff_ram3_execution_controls_v2 import ordered
H,M,T,Q,V=L.H,L.M,L.T,L.Q,L.V
O=L.O

def fields(m):
    return bytes(m[i]for i in range(0x8000)if not 0x100<=i<0x200 and i!=0x5116)

def application_writes(m):
    return [(at,v)for at,v in m.writes if not 0x100<=at<0x200 and at!=0x5116]

def foreign(old,new):
    base=[M.setup(b)for b in[old,new]];rows=[]
    for selected,alts,lag,pending,kind in itertools.product(range(33),[0,32,64,96],[0,255],[0,128],['NMI','IRQ']):
        pair=[]
        for s in base:
            m=T.copy(s);Q.queue(m,0);Q.stage(m,[0x16,0x26,0x30])
            H.put(m,SelectedCharacter=selected,FmAlts=alts,NmiDisable=lag,SmFreezePalettePending=pending,
                SmFreezeRenderState=0,FamilyMainCommit=0)
            m.writes.clear();m.ppu_log.clear();c=H.start(m,'FwCheck')
            r=V.interrupt(m,c,kind);pair.append((m,c,r))
        (a,c,r),(z,d,t)=pair
        assert(c.a,c.x,c.y,c.p,c.sp)==(d.a,d.x,d.y,d.p,d.sp)
        assert a.rawtags==z.rawtags and fields(a)==fields(z),('foreign state',selected,alts,lag,pending,kind)
        assert application_writes(a)==application_writes(z),('foreign ordered writes',selected,alts,lag,pending,kind)
        assert a.ppu_log==z.ppu_log and bytes(a.vram)==bytes(z.vram)
        delta=t['CPU']-r['CPU'];assert delta==(41 if kind=='NMI'and not lag else 0),(selected,alts,lag,pending,kind,delta)
        rows.append(dict(selected=selected,alts=alts,lag=lag,pending=pending,kind=kind,parent_CPU=r['CPU'],new_CPU=t['CPU'],CPU_delta=delta,
            minimum_SP=t['minimum_SP']))
    return dict(cases=len(rows),rows=rows,full_AXYP_SP_live_page1_SMC33_maps_all_RAM_banks=True,
        ordered_application_writes_PPUs_exact=True,normal_NMI_foreign_added_CPU=41,lag_NMI_IRQ_added_CPU=0)

def retirement_budget(old,new):
    base=[M.setup(b)for b in[old,new]];rows=[]
    for selected,full,lag in itertools.product([0,2,9,22],[0,1],[0,255]):
        results=[]
        for i,s in enumerate(base):
            m=T.copy(s);Q.queue(m,full);Q.stage(m,[0x1a,0x30,0x27])
            H.put(m,SelectedCharacter=selected,FmAlts=32 if selected==9 else 0,
                SmFreezePalettePending=192 if i else 128,SmFreezeLastBlue=0,SmFreezeRenderState=0)
            results.append(Q.consume(m,lag))
        a,z=results
        assert a['P1']==z['P1']
        if lag:assert z['pending']==192 and z['CPU']==a['CPU']
        else:assert z['pending']==0
        rows.append(dict(selected=selected,queue_full=full,lag=lag,parent_native_post80_CPU=a['CPU'],new_preC0_CPU=z['CPU'],
            CPU_delta=z['CPU']-a['CPU'],source_PPU_data_writes=len(z['PPU_data_write_indices']),minimum_SP=z['minimum_SP']))
    return dict(cases=len(rows),rows=rows,limits=['Instruction-model CPU budget only. No physical native NMI deadline/cadence claim.'])

def cuts(new):
    base=M.setup(new);samples=[]
    # Discover real instruction states in the source-owned menu retirement
    # and actual InitScreen forced-blank chains. NmiDisable remains authentic.
    for entry in['MenuResolveCharacter','InitScreen']:
        m=T.copy(base);L.put_owner(m);Q.queue(m,1)
        H.put(m,SelectedCharacter=22,CrossoverMenuIndex=2,FmAlts=0,RdVariant=0,MarioVariant=0,
            Mirror_PPUMASK=0,DisableScreenFlag=1,ScreenRoutineTask=0,NmiDisable=255)
        c=H.start(m,entry);seen=set()
        for i in range(500000):
            if c.pc==0x5b00:break
            tag=m.rawtags[(c.pc-0x8000)//8192]if c.pc>=0x8000 else -1
            owned=(tag==0xdd and 0xbe2f<=c.pc<0xbe2f+223)or(tag==0xbe and 0xaeda<=c.pc<0xaf0e)
            op=bytes(m[c.pc:c.pc+3])
            if owned and(c.pc,tag)not in seen:
                seen.add((c.pc,tag));samples.append((entry,i,c.pc,L.clone(m,c)))
            assert m[c.pc]!=0,('source discovery BRK',entry,hex(c.pc));c.step()
        else:raise AssertionError('bounded actual lifecycle discovery')
    rows=[];masked=0
    for entry,step,pc,(state,cpu)in samples:
        assert H.get(state,'NmiDisable')==255
        for kind in['NMI','IRQ']:
            m,c=L.clone(state,cpu)
            if kind=='IRQ'and c.p&c.INTERRUPT:masked+=1;continue
            r=V.interrupt(m,c,kind);rows.append(dict(entry=entry,step=step,PC=pc,**r))
    return dict(real_vectors=len(rows),unique_actual_instruction_states=len(samples),masked_IRQ_requests=masked,rows=rows,
        genuine_busy_interval_preserved=True,no_fabricated_normal_NMI_inside_foreground=True)

def main():
    out=O/'preflush-vectors-v2.json';assert not out.exists()
    proof=dict(passed=False,native=False,admitted=False,scheduler=False,checks={})
    try:
        old=H.C.qualified(L.P/'candidate.nes');new=H.C.qualified(H.O/'candidate.nes')
        for name,fn in [('foreign_native_vectors',lambda:foreign(old,new)),('retirement_budget',lambda:retirement_budget(old,new)),('actual_lifecycle_instruction_cuts',lambda:cuts(new))]:
            proof['checks'][name]=fn();print(name,'PASS',flush=True)
        proof['passed']=True
    except Exception as e:proof.update(error=repr(e),traceback=traceback.format_exc())
    proof['bindings']={str(f.resolve()):L.sha(f)for f in[Path(__file__),Path(L.__file__),Path(M.__file__),Path(V.__file__),O/'source-closure.json',L.P/'candidate.nes',L.P/'candidate.dbg',H.O/'candidate.nes',H.O/'candidate.dbg']}
    out=out if proof['passed']else O/'preflush-vectors-negative-v2.json'
    out.write_text(json.dumps(proof,indent=2)+'\n',newline='\n');print(json.dumps(dict(passed=proof['passed'],error=proof.get('error'),path=str(out))),flush=True);assert proof['passed']

if __name__=='__main__':main()
