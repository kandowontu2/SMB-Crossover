"""Actual FF world probe marker against unchanged native draw/flash outputs."""
from pathlib import Path
import itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import ff_joint_actual_main_v2 as M
import ff_joint_typed_controls_v1 as T
from check_tmnt_render_oa import address,location
H=M.H;sha=M.sha
P=R/'build/ff-joint-native-flash-1030-v1/joint'
O=R/'build/ff-fx-world-marker-proposal-v1';H.O=O/'joint'
SEEDS={}


def start(m,x,y,p=0x71):return H.start(m,'DrawMetasprite',x=x,y=y,p=p)


def fixture(b,selected,pose,y,offset,rotation,face,flash):
    key=id(b)
    if key not in SEEDS:SEEDS[key]=M.setup(b)
    m=T.copy(SEEDS[key])
    H.put(m,SelectedCharacter=selected,CurrentBankC=221,CurrentOAMOffset=offset,
        GuestOamRotationActive=1,RgOamRotation=rotation,PlayerOutlinesOff=1)
    m.raw_page(2,221)
    # Genuine native object coordinates and per-object attributes are inputs.
    for n,v in [('SprObject_X_Position',120),('SprObject_PageLoc',0),('SprObject_Y_Position',160),
                 ('SprObject_Y_HighPos',1),('PlayerFacingDir',face),('SprObject_SprAttrib',0)]:
        m[address(b,n)+y]=v
    m[address(b,'Enemy_ID')+y-1]=6
    m[address(b,'Enemy_Flag')+y-1]=1
    m[address(b,'MmEnemyFlash')+y-1]=flash
    for i in range(256):m[512+i]=(248 if i%4==0 else (i*13+7)&239)
    m.writes.clear();m.ram_writes.clear()
    return m


def run(m,pose,y,p=0x71):
    tagged=set();entries=[]
    is_new='FfMuxWorldDraw'in m.bundle['syms']
    store=address(m.bundle,'FfMuxWorldDraw::Tag')+5 if is_new else -1
    gate=address(m.bundle,'FwNativeFlashProbe')
    def observe(mem,c,i):
        if c.pc==gate:entries.append(dict(rawC=mem.rawtags[2],source_y=c.y,R0=H.get(mem,'R0'),R1=H.get(mem,'R1')))
        if c.pc==store:tagged.add(len(mem.writes))
    c=start(m,pose,y,p);live=bytes(m[0x1e1:0x200])
    c,low=H.finish(m,c,observe)
    assert c.sp==224 and bytes(m[0x1e1:0x200])==live
    assert all(e['rawC']==221 for e in entries),entries
    exclude=set(range(0x100,0x200))
    writes=[(a,v)for i,(a,v)in enumerate(m.writes)if a not in exclude and i not in tagged]
    # Marker is the only intentional application change. Hardware ignores10.
    values=bytes((m[a]&239 if 512<=a<768 and a%4==2 else m[a])for a in range(0x8000)if a not in exclude)
    return dict(c=c,low=low,entries=entries,state=values,writes=writes,tag_writes=len(tagged))


def pair(old,new,selected,pose,y,offset,rotation,face,flash,p=0x71):
    states=[];mem=[]
    for b in [old,new]:
        m=fixture(b,selected,pose,y,offset,rotation,face,flash);r=run(m,pose,y,p);states.append(r);mem.append(m)
    a,z=states
    assert (a['c'].a,a['c'].x,a['c'].y,a['c'].p,a['c'].sp)==(z['c'].a,z['c'].x,z['c'].y,z['c'].p,z['c'].sp)
    assert a['state']==z['state'],('state',selected,pose,y,offset,rotation,face,flash)
    assert a['writes']==z['writes'],('ordered native application writes',selected,pose,y,offset,rotation,face,flash)
    assert mem[0].rawtags==mem[1].rawtags
    expected=list(mem[0][512:768]);end=H.get(mem[0],'CurrentOAMOffset')
    cursor=(offset+rotation)&255
    span=[(cursor+n)&255 for n in range(0,max(0,end-offset),4)]
    conflict=selected==22 and any(expected[at]<240 and expected[at+2]&3==1 for at in span)
    if conflict:
        for at in span:expected[at+2]|=16
    assert list(mem[1][512:768])==expected,('complete native object marker',selected,pose,y,offset,rotation,face,flash)
    assert z['tag_writes']==(len(span)if conflict else 0)
    return dict(selected=selected,pose=pose,y=y,offset=offset,rotation=rotation,face=face,flash=flash,p=p,
      native_parts=len(span),whole_object_tagged=conflict,extra_CPU=z['c'].processorCycles-a['c'].processorCycles,
      minimum_SP=z['low'],probe_entries=z['entries'])


def main():
    out=O/'marker-controls-v2.json';assert not out.exists()
    p=dict(passed=False,native=False,admitted=False,checks={},limits=[
      'Metadata-only prototype. Final palette scheduling, bit4 clear beforeDMA, fullqueue commit and lifecycle are not installed.',
      'Direct native drawing fixtures declare C93 mapped, matching FF DrawAll source; fullMain ingress proof follows separately.'])
    try:
        old=H.C.qualified(P/'candidate.nes');new=H.C.qualified(H.O/'candidate.nes')
        names=['KOOPA_WALKING_1','PIRANHA_MOUTH_OPEN','BOWSER_FRONT_MOUTH_OPEN','BOWSER_REAR_WALK_1',
          'POWERUP_MUSHROOM','POWERUP_1UP','POWERUP_FIREFLOWER','GOOMBA_WALKING_1']
        poses=[address(new,'METASPRITE_'+n)for n in names]
        rows=[]
        for pose,y,offset,rotation,face,flash in itertools.product(poses,[1,6],[0,224,252],[0,68,252],[1,2],[0,2,22]):
            rows.append(pair(old,new,22,pose,y,offset,rotation,face,flash))
        p['checks']['owned_objects']=dict(cases=len(rows),rows=rows,
          complete_mixed_fireflower_and_actual_flash_palette=True,native_draw_executed_once=True,
          AXYP_SP_all33SMC_R0_R7_all_state_and_ordered_native_writes_exact_except_metadata=True,
          additional_CPU=[min(r['extra_CPU']for r in rows),max(r['extra_CPU']for r in rows)])
        print('owned completed-span pairs PASS',flush=True)
        flags=[0x30|n for n in range(256)if n&0x30==0]
        rows=[]
        for off,face,flash,p0 in itertools.product([0,252],[1,2],[0,2],flags):
            rows.append(pair(old,new,22,poses[6],6,off,68,face,flash,p=p0))
        p['checks']['all_flags_mixed_object']=dict(cases=len(rows),rows=rows)
        foreign=[]
        for selected,pose,y,p0 in itertools.product([n for n in range(33)if n!=22],
               [poses[0],poses[6],poses[7]],[1,6],[0x30,0x71]):
            foreign.append(pair(old,new,selected,pose,y,0,68,1,2,p=p0))
        p['checks']['foreign']=dict(cases=len(foreign),rows=foreign,
          extra_CPU=[min(r['extra_CPU']for r in foreign),max(r['extra_CPU']for r in foreign)])
        print('flags and foreign pairs PASS',flush=True)
        p['passed']=True
    except Exception as e:p.update(error=repr(e),traceback=traceback.format_exc())
    p['bindings']={str(f.resolve()):sha(f)for f in[Path(__file__),Path(M.__file__),Path(T.__file__),Path(H.__file__),
      P/'candidate.nes',P/'candidate.dbg',O/'source-closure.json',H.O/'candidate.nes',H.O/'candidate.dbg']}
    target=out if p['passed']else O/'marker-controls-negative-v2.json'
    target.write_text(json.dumps(p,indent=2)+'\n',newline='\n')
    print(json.dumps(dict(passed=p['passed'],path=str(target),error=p.get('error'))),flush=True);assert p['passed']


if __name__=='__main__':main()
