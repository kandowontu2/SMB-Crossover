"""Read-only actual P1 mailbox consumers and retained FF ownership negatives.

Packets here are declared CPU consumer fixtures, never a scheduler/owner grant.
"""
from pathlib import Path
import itertools,json,re,sys,traceback
R=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import ff_joint_actual_main_v2 as M
import ff_joint_typed_controls_v1 as T
import ff_host_pickups_vectors_v2 as V
from check_tmnt_render_oa import address,location
H=M.H;sha=M.sha
P=R/'build/ff-upper-fx-windows-1030-v1';H.O=P/'joint'
O=R/'build/ff-fx-palette-mailbox-audit-v2'
FIELDS=['SmFreezePalettePacket','SmFreezePalettePending','SmFreezeLastBlue','SmFreezeTurn','SmFreezeRenderState','SmFreezePaletteControl']

def queue(m,full):
    # Real 83B full native queue: native P1 + 63B nametable + 8B nametable.
    packet=[0x3f,0x15,3,0x1a,0x30,0x27]
    if full:packet += [0x20,0,63]+[7]*63+[0x21,0,8]+[9]*8
    assert len(packet)==(83 if full else 6)
    at=address(m.bundle,'VRAM_Buffer1')
    for i,v in enumerate(packet+[0]):m[at+i]=v
    H.put(m,VRAM_Buffer1_Offset=len(packet),VRAM_Buffer_AddrCtrl=0)

def stage(m,colors):
    at=address(m.bundle,'SmFreezePalettePacket')
    for i,v in enumerate([0x3f,0x15,3,*colors,0]):m[at+i]=v
    H.put(m,SmFreezeLastBlue=0x81,SmFreezeTurn=1,SmFreezeRenderState=0,SmFreezePalettePending=0x80)

def consume(m,lag):
    H.put(m,NmiDisable=lag)
    m.writes.clear();m.ppu_log.clear()
    c=H.start(m,'FwCheck');proof=V.interrupt(m,c,'NMI')
    writes=list(m.writes)
    dma=[i for i,(a,v)in enumerate(writes)if a==0x4014]
    ppu=[i for i,(a,v)in enumerate(writes)if a==0x2007]
    if not lag:
        assert dma and ppu and max(ppu)<min(dma),('palette before paired OAM DMA',ppu,dma)
    else:assert not dma and not ppu
    H.finish(m,c)
    return dict(**proof,PPU_data_write_indices=ppu,OAM_DMA_write_indices=dma,
        P1=list(m.vram[0x3f15:0x3f18]),pending=H.get(m,'SmFreezePalettePending'))

def source_refs(b):
    refs={name:[]for name in FIELDS}
    for f in sorted((P/'joint').rglob('*')):
        if f.is_file()and f.suffix in['.s','.inc']:
            for line,text in enumerate(f.read_text(errors='replace').splitlines(),1):
                for name in FIELDS:
                    if re.search(r'\b'+name+r'\b',text):refs[name].append(dict(path=str(f.resolve()),line=line,text=text.strip()))
    scopes=['SamusFreezeInit','SamusFreezeRenderFinish','SamusFreezeFlushPalette','SamusFreezeUpdateScreen',
        'PnPaletteScreenUpdate','SamusFreezePaletteStoreA','SamusFreezePaletteStoreX','SamusHardEnemyAdmission',
        'FwNativeDrawAll','FwRetire','FwSceneInit','InventoryInit','SpecialRosterClear']
    return dict(all_current_producer_references=refs,
        actual_addresses={name:address(b,name)for name in FIELDS+scopes},
        source_seams=dict(normal_NMI='reset.s ContinueNMI calls SamusFreezeUpdateScreen before OAMandReadJoypad',
          lag_NMI='reset.s NmiDisable<0 bypasses update and OAM DMA',
          consumer='PnPaletteScreenUpdate -> original UpdateScreen -> ASL Pending -> SamusFreezeFlushPalette -> original UpdateScreen',
          lifetime='InventoryInit->SamusFreezeInit clears mailbox/state; SpecialRosterClear does not clear them',
          late_Samus_writer='FwNativeDrawAll latches SmFreezeRenderState regardless selected owner; acquisition must retire stale Samus state first'))

def main():
    O.mkdir(exist_ok=False)
    p=dict(passed=False,native=False,admitted=False,read_only=True,
        alias_adopted=False,fixture='Explicit packet consumer fixtures; no claim that a real FF scheduler produced them.',checks={})
    try:
        b=H.C.qualified(P/'joint/candidate.nes');base=M.setup(b)
        p['checks']['source_reference_closure']=source_refs(b)
        rows=[]
        for full,pause,colors in itertools.product([0,1],[0,1],[[0x16,0x26,0x30],[0x18,0x28,0x30],[0x12,0x21,0x30],[0x0c,0x1c,0x2c]]):
            m=T.copy(base);H.put(m,GamePauseStatus=pause);queue(m,full);stage(m,colors)
            before=list(m.vram[0x3f19:0x3f20]);r=consume(m,0)
            assert r['P1']==colors and r['pending']==0
            assert list(m.vram[0x3f19:0x3f20])==before
            assert H.get(m,'VRAM_Buffer1_Offset')==0
            rows.append(dict(queue_full=full,pause=pause,colors=colors,**r))
        p['checks']['actual_full_queue_normal_NMI']=dict(cases=len(rows),rows=rows,
            P1_one_shot_after_native_queue_before_DMA=True,P2_P3_unchanged=True)
        lag=[]
        for selected,full in itertools.product([22,2],[0,1]):
            m=T.copy(base);H.put(m,SelectedCharacter=selected);queue(m,full);stage(m,[0x16,0x26,0x30])
            old=bytes(m.vram);r=consume(m,255)
            assert bytes(m.vram)==old and r['pending']==128
            lag.append(dict(selected=selected,queue_full=full,**r))
        p['checks']['lag_retains_paired_packet']=dict(cases=len(lag),rows=lag)
        negatives=[]
        for selected in[0,2]:
            m=T.copy(base);queue(m,1);stage(m,[0x16,0x26,0x30]);H.put(m,SelectedCharacter=selected)
            H.invoke(m,'FwRetire');assert H.get(m,'SmFreezePalettePending')==128
            r=consume(m,0)
            assert r['P1']==[0x16,0x26,0x30]
            negatives.append(dict(negative='actual_FwRetire_does_not_retire_palette_mailbox',selected=selected,**r))
        p['checks']['retained_actual_protocol_negatives']=dict(cases=len(negatives),rows=negatives,
            source_is_not_safe_for_alias_yet=True,
            required_fix='Owner retirement before resolved SelectedCharacter/UI publication; stale Samus state retirement on FF acquisition, complete native restore packet commit before foreign DMA.')
        p['passed']=True
    except Exception as e:p.update(error=repr(e),traceback=traceback.format_exc())
    files=[Path(__file__),R/'tools/audit/ff_fx_palette_mailbox_audit_v1.py',R/'build/ff-fx-palette-mailbox-audit-v1/negative-controls.json',Path(M.__file__),Path(T.__file__),Path(H.__file__),Path(V.__file__),
        P/'source-closure.json',P/'joint/candidate.nes',P/'joint/candidate.dbg']
    files += [f for f in(P/'joint').rglob('*')if f.is_file()and f.suffix in['.s','.inc']]
    p['bindings']={str(f.resolve()):sha(f)for f in files}
    t=O/('controls.json'if p['passed']else'negative-controls.json')
    t.write_text(json.dumps(p,indent=2)+'\n',newline='\n')
    print(json.dumps(dict(passed=p['passed'],path=str(t),error=p.get('error'))),flush=True);assert p['passed']

if __name__=='__main__':main()
