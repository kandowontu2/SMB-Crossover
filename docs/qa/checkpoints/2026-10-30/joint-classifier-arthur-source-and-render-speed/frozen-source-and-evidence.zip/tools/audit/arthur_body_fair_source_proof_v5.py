"""Classify every source-linked byte change and retained private resource."""
from pathlib import Path
import hashlib,json
import arthur_body_fair_main_v5 as F
from arthur_probe_source_proof_v1 import word
A=F.A;R=F.R;O=F.O;OLD=F.P
def main():
 out=O/'source-proof-v5.json';assert not out.exists();old=A.scoped_load(OLD/'candidate.nes');b=A.scoped_load(O/'candidate.nes');ra,rb=old['raw'],b['raw'];assert ra[:16]==rb[:16]
 segments=lambda z:{g['name'].strip('"'):g for g in z['segs'].values()};sa,sb=segments(old),segments(b);exact=[];nearrelocs=[]
 for n,g in sa.items():
  if not n.startswith('ARTHUR_')or'ooffs'not in g or n in['ARTHUR_DRAW','ARTHUR_ADAPTER','ARTHUR_ART_TAIL','ARTHUR_CACHE_EXEC']:continue
  h=sb[n];assert int(g['size'],0)==int(h['size'],0);p,z,size=int(g['ooffs'],0),int(h['ooffs'],0),int(g['size'],0)
  diffs={j for j in range(size)if ra[p+j]!=rb[z+j]};covered=set()
  for j in range(size-2):
   if ra[p+j]not in [32,76]or ra[p+j]!=rb[z+j]or not diffs.intersection([j+1,j+2]):continue
   x,y=word(ra,p+j+1),word(rb,z+j+1)
   names=[name for name,s in old['syms'].items()if '::'not in name and name in b['syms']and'seg'in s and int(s['val'],0)==x and A.address(b,name)==y]
   if names:covered.update([j+1,j+2]);nearrelocs.append(dict(segment=n,offset=j,opcode=ra[p+j],before=x,after=y,same_genuine_source_symbols=names))
  assert diffs<=covered,('unplanned original Arthur segment change',n,sorted(diffs-covered));exact.append([n,size,'same_source_JSR_JMP_relocations'if diffs else 'byte_exact'])
 for name in['host-state.s','host-world.s','component.s','native-kernels.s','art.s','palette.s','cache-loader.s','cache-input.bin','chr.s']:
  assert(OLD/'arthur'/name).read_bytes()==(O/'arthur'/name).read_bytes(),('Unplanned retained source edit',name)
 prefix=608;assert ra[A.location(old,'HuStart'):A.location(old,'HuStart')+prefix]==rb[A.location(b,'HuStart'):A.location(b,'HuStart')+prefix]
 bodies=[]
 for name,nextname in zip(['Visible','Body','Adder','Box','Ui','Noop'],['HuLocalBody','HuLocalAdder','HuLocalBox','HuLocalUi','HuLocalNoop','HuPolicyReturn']):
  x,y=A.location(old,'HuLocal'+name),A.location(b,'HuLocal'+name)
  size=A.address(old,nextname)-A.address(old,'HuLocal'+name)
  assert ra[x:x+size]==rb[y:y+size]
  bodies.append(dict(original='HuLocal'+name,exact_body_bytes=size))
 orig=A.location(old,'X5SetPhysicalChr');size=A.location(old,'X5SetSpecialChr')-orig;fast=A.location(b,'ArCachePublishFast');assert ra[orig+size-1]==96
 assert rb[fast:fast+3]==bytes([72,162,3]);assert rb[fast+3:fast+3+size-1]==ra[orig:orig+size-1]and rb[fast+3+size-1:fast+3+size+1]==bytes([104,96])
 changedchr=sorted({(i-1048592)//1024 for i in range(1048592,len(ra))if ra[i]!=rb[i]});assert changedchr==[883]
 allowed=[(16+26*8192+0x132a,16+26*8192+0x1c00),(16+26*8192+0x1d32,16+26*8192+0x2000),(16+70*8192+0x19b8,16+70*8192+0x2000)]
 outside={i for i in range(16,1048592)if ra[i]!=rb[i]and not any(lo<=i<hi for lo,hi in allowed)};covered=set();relocations=[];arg=A.address(old,'SafecallA_SMC')+1;target=A.address(old,'FarcallJmpTarget_SMC')+1;far=A.address(old,'FarCallCommon');moved={}
 for n,s in old['syms'].items():
  if '::'in n or n not in b['syms']or'seg'not in s:continue
  try:x,y=A.point(old,n),A.point(b,n)
  except(KeyError,ValueError):continue
  if x!=y:moved.setdefault((x,y),[]).append(n)
 for p in range(16,1048592-18):
  if ra[p]!=141 or word(ra,p+1)!=arg or ra[p+3]!=169 or ra[p+5]!=141 or word(ra,p+6)!=target or ra[p+8]!=169 or ra[p+10]!=141 or word(ra,p+11)!=target+1 or ra[p+13]!=169 or ra[p+15]not in[32,76]or word(ra,p+16)!=far:continue
  if not outside.intersection(range(p,p+18)):continue
  changed=[i for i in range(p,p+18)if ra[i]!=rb[i]];assert set(changed)<=set([p+4,p+9]);before=(ra[p+14]&127,ra[p+4]+256*ra[p+9]);after=(rb[p+14]&127,rb[p+4]+256*rb[p+9]);names=moved.get((before,after));assert names,('Unbound external relocation',p,before,after);covered.update(changed);relocations.append(dict(file_offset=p,genuine_same_symbols=names,before=before,after=after))
 for at in sorted(outside-covered):
  for p in [at-1,at-2]:
   if ra[p]not in [32,76]or rb[p]!=ra[p]:continue
   before,after=word(ra,p+1),word(rb,p+1)
   names=[n for n,s in old['syms'].items()if '::'not in n and n in b['syms']and'seg'in s and int(s['val'],0)==before and A.address(b,n)==after]
   if not names:continue
   changes=[j for j in [p+1,p+2]if ra[j]!=rb[j]];covered.update(changes)
   relocations.append(dict(file_offset=p,opcode=ra[p],genuine_same_symbols=names,before=before,after=after,changed_operand_bytes=changes))
 # Existing typed resolver stores the actual relocated ArHostRelease pointer;
 # this is a source-linked callback operand, not new resident code/space.
 p=A.location(old,'HuResolve')+9;z=A.location(b,'HuResolve')+9
 expected=lambda v:bytes([169,A.address(v,'ArHostRelease')&255,141,A.address(v,'ArDrawPtr')&255,A.address(v,'ArDrawPtr')>>8,169,A.address(v,'ArHostRelease')>>8,141,(A.address(v,'ArDrawPtr')+1)&255,(A.address(v,'ArDrawPtr')+1)>>8])
 assert ra[p:p+10]==expected(old) and rb[z:z+10]==expected(b) and p==z
 changes=[j for j in range(p,p+10)if ra[j]!=rb[j]];assert set(changes)<=set([p+1,p+6]);covered.update(changes)
 relocations.append(dict(file_offset=p,genuine_same_symbols=['ArHostRelease'],source='HuResolve real selected32 retirement pointer',changed_operand_bytes=changes))
 p=A.location(old,'HuCommon::NotLocal')+5;z=A.location(b,'HuCommon::NotLocal')+5
 def direct(v):
  return bytes([169,A.address(v,'ArProbeDispatch')&255,141,target&255,target>>8,169,A.address(v,'ArProbeDispatch')>>8,141,(target+1)&255,(target+1)>>8,169,A.point(v,'ArProbeDispatch')[0]|128,141,(A.address(v,'NextBank_SMC')+1)&255,(A.address(v,'NextBank_SMC')+1)>>8])
 assert p==z and ra[p:p+15]==direct(old) and rb[z:z+15]==direct(b)
 changes=[j for j in range(p,p+15)if ra[j]!=rb[j]];assert set(changes)<=set([p+1,p+6]);covered.update(changes)
 relocations.append(dict(file_offset=p,genuine_same_symbols=['ArProbeDispatch'],source='HuCommon unchanged direct-probe pointer gate',changed_operand_bytes=changes))
 assert outside==covered,('Unclassified outside owned leases',sorted(outside-covered)[:20])
 mainused=sum(int(sb[n]['size'],0)for n in['ARTHUR_BODY','ARTHUR_LEAF','ARTHUR_DRAW']);union=int(sb['CHARACTER_HOST_UNION']['size'],0);runtime=A.address(b,'ArCacheExecEnd')-A.address(b,'ArCacheEmit');storage=2326+runtime
 tailused=sum(int(sb[n]['size'],0)for n in ['ARTHUR_PROBES','ARTHUR_COMBAT','ARTHUR_ADAPTER','ARTHUR_PALETTE_MODE'])
 assert mainused==2261<=2262 and tailused==714<=718 and union==1939<=2592 and runtime==550 and storage==2876<=3072
 # Genuine hardware HUD split is MMC5 IRQ31, not a physical OAM record0
 # marker. The source and actual linked native render/reset are unchanged.
 for name in ['src/reset.s','src/metasprite_engine.s','frozen-inputs/src/meta_knight.s']:
  assert(OLD/name).read_bytes()==(O/name).read_bytes()
 header=(O/'src/reset.s').read_text();assert 'Sprite0HitDetectFlag' in header and 'SetScanlineIRQ #$1f' in header
 aliases={n:A.address(b,n)for n in ['ArLayoutPtr','ArDrawPage','ArDrawHeader']}
 assert aliases==dict(ArLayoutPtr=0x5ca8,ArDrawPage=0x5caa,ArDrawHeader=0x5cab)
 refs=[]
 for p in (O/'arthur').glob('*.s'):
  for i,line in enumerate(p.read_text().splitlines(),1):
   if 'ArLayoutPtr' in line and not line.lstrip().startswith(('.import','.export')):refs.append([p.name,i,line])
 assert {z[0]for z in refs}=={'host-state.s','cache-loader.s','cache-runtime.s'}
 loader=(O/'arthur/cache-loader.s').read_text();assert loader.index('sta ArLayoutPtr')<loader.index('LoadKey:')<loader.index('lda ArLayoutPtr')
 d=dict(passed=True,native=False,parent_ROM_sha256=A.sha(OLD/'candidate.nes'),candidate_ROM_sha256=A.sha(O/'candidate.nes'),header_exact=True,unchanged_original_segments=exact,same_original_worker_near_relocations=nearrelocs,all36_public_entries_and_prefix_exact=prefix,policy_bodies_exact=bodies,publisher_exact_native_instruction_body_bytes=size-1,only_changed_CHR_pages=changedchr,all_original_body_projectile_art_868_880_and_canonical_cache_exact=True,owned_PRG_file_intervals=allowed,outside_owned_intervals_only_same_source_farcall_relocations=relocations,A26_main_used=mainused,A26_main_reserved=2262,A26_tail_used=tailused,A26_tail_reserved=718,A79_union_used=union,A79_union_reserved=2592,C2_runtime_bytes=runtime,own_CHR_storage_bytes=storage,own_CHR_storage_reserved=3072,total_Arthur_PRG_bytes=sum(int(g['size'],0)for n,g in sb.items()if n.startswith('ARTHUR_')and'ooffs'in g and int(g['ooffs'],0)<1048592),no_new_PRG_RAM_ZP_CHR_header_lease=True,aliases=aliases,actual_ArLayoutPtr_consumer_closure=refs,constructor_initializes_pointer_before_read=True,physics_witness_ArDrawHeader_unchanged=True,actual_native_sprite0_split_owner='Unchanged real MMC5 IRQ31; Sprite0HitDetectFlag arms native IRQ after OAM DMA. No fixed physical0 marker retained by this rotating guest route.',source_comment_correction='cache-runtime comment Header=origin is stale inherited wording; actual assembled operands are ArLayoutPtr.low. ArDrawHeader is untouched.',owner_contract='Only raw32 verified ready/cache body draw sets origin/count; wrapper resets count before Ensure, preventing stale body replay. Genuine native DrawAll actor loops finish before body-prefix permutation. Original mode2 white expansion runs afterward. All other selected profiles retain exact native CPU/ordered stores.')
 d['bindings']={str(p.resolve()):A.sha(p)for p in[Path(__file__),Path(F.__file__),O/'candidate.nes',O/'candidate.dbg',OLD/'candidate.nes',OLD/'candidate.dbg',O/'arthur-union.s',O/'arthur/cache-wrapper.s',O/'arthur/cache-runtime.s',O/'arthur/host-adapter.s',O/'source.patch',O/'arthur-build-proof.json',O/'cache-final-link-proof.json']};out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items()if k in['passed','candidate_ROM_sha256','A26_main_used','A26_tail_used','A79_union_used','C2_runtime_bytes','own_CHR_storage_bytes','total_Arthur_PRG_bytes']}))
if __name__=='__main__':main()
