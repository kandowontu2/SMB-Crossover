"""Bind differing final mode2 mask scratch to the unchanged actual C70 worker."""
from pathlib import Path
import json,sys
R=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import arthur_body_fair_main_v4 as M
from verify_native_relocation import NesMPU
from check_tmnt_render_oa import location
A=M.A;C=M.C;O=M.O;P=M.P

def main():
    out=O/'white-scratch-diagnosis-v5.json';assert not out.exists()
    old=A.scoped_load(P/'candidate.nes');new=A.scoped_load(O/'candidate.nes')
    # The entire original source-owned white worker through its lookup is
    # unchanged; compare actual linked segment bytes, not decoded prose.
    spans=[]
    for b in [old,new]:
        seg=next(s for s in b['segs'].values() if s['name']=='"ARTHUR_PALETTE_WHITE"')
        pos,size=(int(seg[n],0)for n in ['ooffs','size'])
        spans.append(bytes(b['raw'][pos:pos+size]))
    assert spans[0]==spans[1]
    rows=[];pair=[C.prepare(b)for b in [old,new]]
    for q in pair:q.put(AreaType=3,SmFreezePaletteControl=8,PlayerFacingDir=1)
    for age in range(30):
        keys=1|(128 if age in [6,16]else 0)|(64 if 24<=age<78 and age%18<6 else 0)
        item=[]
        for q in pair:
            q.put(SavedJoypadBits=keys,SavedJoypad1Bits=keys,ArHostPad=keys,ArHostDue=int(age%3==0),
                  PlayerOutlinesOff=int(age>=24),NmiDisable=255,VRAM_Buffer1_Offset=0)
            writes=[];saved=NesMPU.step;at=A.address(q.b,'ArTemp')
            def observe(cpu):
                if q.m[cpu.pc]==0x8d and q.m[cpu.pc+1]+256*q.m[cpu.pc+2]==at:
                    raw=q.m.rawtags[(cpu.pc-0x8000)//8192]
                    writes.append(dict(PC=cpu.pc,raw=raw,A=cpu.a,
                                       source=A.M.code_label(q.b,raw&127,cpu.pc)if raw&128 else 'verified RAM2 emitter'))
                saved(cpu)
            NesMPU.step=observe
            try:A.M.run_linked(q,'GameLoop')
            finally:NesMPU.step=saved
            assert writes and writes[-1]['raw']==0xc6
            segment=q.b['segs'][q.b['syms']['ArPalOamWhite']['seg']]
            start,size=(int(segment[n],0)for n in ['start','size'])
            assert start<=writes[-1]['PC']<start+size,writes[-1]
            item.append(dict(final=q.get('ArTemp'),writes=writes))
        rows.append(dict(age=age,parent=item[0],candidate=item[1]))
    assert [z['final']for z in [rows[-1]['parent'],rows[-1]['candidate']]]==[77,110]
    out.write_text(json.dumps(dict(passed=True,native=False,unchanged_white_segment_bytes=len(spans[0]),
        actual_last_store_inside_unchanged_native_white_worker=True,
        last_mask_is_render_scratch_only=True,rows=rows,
        bindings={str(p.resolve()):A.sha(p)for p in [Path(__file__),Path(M.__file__),O/'candidate.nes',O/'candidate.dbg',P/'candidate.nes',P/'candidate.dbg',O/'controls-v4.json']}),indent=2)+'\n')
    print('WHITE_SCRATCH_BOUND',out)
if __name__=='__main__':main()
