"""Exact policies, real C2 publisher, complete Main and loader source controls."""
from pathlib import Path
import argparse,itertools,json,traceback
import arthur_probe_fast_controls_v1 as C
import arthur_cache_host_controls_v1 as H
from sunny_integrated_controls_v1 import registers
from verify_native_relocation import NesMPU
A=C.A;R=C.R;OLD=C.O;O=R/'build/arthur-host-render-fast-v1'
POLICIES=['HuVisible','HuBody','HuAdder','HuBox','HuUi','HuMenuName','HuRise','HuPrivate','HuMature','HuBounceOnly','HuHeadWithinOnly','HuBounce','HuPowerup','HuWeaponTail','HuVine']
def signature_state(q):return(C.state(q),bytes(q.m[0x15a:0x17b]))
def policies(old,b):
 qa,qb=[C.seed(v)for v in[old,b]];rows=[]
 for name,p in itertools.product(POLICIES,range(256)):
  pair=[]
  for q in[qa,qb]:
   q.put(R0=55,R1=166);cpu,tr,mn=A.call(q,name,a=0x53,x=0x9b,y=0x17,p=p);pair.append((q,cpu,tr,mn,C.writes(q)))
  (qa,ca,ta,ma,wa),(qb,cb,tb,mb,wb)=pair
  assert registers(ca)==registers(cb),('policy AXYP/SP',name,p,registers(ca),registers(cb))
  assert signature_state(qa)==signature_state(qb),('policy application/raw maps/live page1/R0R1/all33SMC',name,p)
  assert wa==wb,('policy ordered application stores',name,p,wa,wb)
  assert not any(0x5114<=at<=0x5117 for at,v in qb.m.writes),('cheap selected route still maps bank',name)
  rows.append([name,p,ca.processorCycles,cb.processorCycles,min(ma,mb)])
 return dict(cases=len(rows),full256incoming_flags_each_policy=True,AXYP_SP_all_application_maps_live_stack_R0R1_and_all33SMC_exact=True,ordered_application_writes_exact=True,rows=rows,saved_cycles=[min(r[2]-r[3]for r in rows),max(r[2]-r[3]for r in rows)])
def raw_call(q,name,a,x,y,p):
 q.m.raw_page(1,154);q.put(CurrentBank=154);q.m.raw_page(2,2);q.put(CurrentBankC=2);q.m.writes=[]
 c=NesMPU(memory=q.m,pc=A.address(q.b,name));c.a,c.x,c.y,c.p,c.sp=a,x,y,p,253;c.stPushWord(0x5aff);trace=[]
 for i in range(1000):
  if c.pc==0x5b00:assert c.sp==253;return c,trace,253
  trace.append((q.m.rawtags[(c.pc-0x8000)//8192]&127,c.pc));c.step()
 raise AssertionError(('rawRAM2 publisher timeout',hex(c.pc)))
def publisher(old,b):
 qa,qb=[C.prepare(v)for v in[old,b]];rows=[]
 cases=[(y,lo,p)for y in[0,6,7]for lo in[100,108,109,112]for p in range(256)]
 cases +=[(y,lo,p)for y in range(12)for lo in[0,255]for p in[0,0x30,0x71,255]]
 for y,lo,p in cases:
  qa.m.raw_page(2,2);qa.put(CurrentBankC=2);ca,ta,ma=A.call(qa,'ArCachePublish',a=lo,x=0x9b,y=y,p=p)
  cb,tb,mb=raw_call(qb,'ArCachePublishFast',lo,0x9b,y,p)
  assert registers(ca)==registers(cb),('publisher AXYP/SP',y,lo,p,registers(ca),registers(cb))
  # Source caller C2/A26 are retained. Scratch/application writes and final
  # actual native CHR software state must match, excluding removed transport.
  assert C.state(qa)==C.state(qb),('publisher application/rawbanks/live stack',y,lo,p)
  assert C.writes(qa)==C.writes(qb),('publisher actual ordered native state stores',y,lo,p,C.writes(qa),C.writes(qb))
  assert not any(0x5114<=at<=0x5117 for at,v in qb.m.writes)
  rows.append([y,lo,p,ca.processorCycles,cb.processorCycles])
 return dict(cases=len(rows),all256incoming_flags_actual_windows0_6_7=True,all12publisher_windows_edges=True,original_AXYP_SP_native_CHR_and_ordered_stores_exact=True,old_cycles=sorted(set(r[3]for r in rows)),new_cycles=sorted(set(r[4]for r in rows)),rows=rows)
def main_updates(old,b):
 rows=[]
 for face,skip in itertools.product([1,2],[0,1]):
  qa,qb=[C.prepare(v)for v in[old,b]]
  for q in[qa,qb]:q.put(PlayerFacingDir=face,ShouldSkipDrawSprites=skip)
  for age in range(48):
   keys=(1 if face==1 else 2)|(128 if age in[6,16]else 0)|(64 if age in[24,36]else 0);pair=[]
   for q in[qa,qb]:
    q.put(SavedJoypadBits=keys,SavedJoypad1Bits=keys,ArHostPad=keys,ArHostDue=int(age%3==0),NmiDisable=255,VRAM_Buffer1_Offset=0)
    cache=bytes(q.m.ram[2]);c,tr,mn,ann,events=A.M.run_linked(q,'GameLoop');assert bytes(q.m.ram[2])==cache;pair.append((c,tr,mn,C.writes(q)))
   (ca,ta,ma,wa),(cb,tb,mb,wb)=pair
   assert registers(ca)==registers(cb)and signature_state(qa)==signature_state(qb),('Main AXYP/SP/application/OAM/CHR/live stack/rawbanks/all33SMC',face,skip,age)
   assert wa==wb,('Main ordered application writes',face,skip,age,[(i,x,y)for i,(x,y)in enumerate(zip(wa,wb))if x!=y][:6],len(wa),len(wb))
   rows.append([face,skip,age,ca.processorCycles,cb.processorCycles,min(ma,mb)])
 saved=[r[3]-r[4]for r in rows]
 return dict(actual_Main_updates=len(rows),rows=rows,AXYP_SP_all_application_OAM_CHR_live_stack_R0R1_rawbanks_all33SMC_and_ordered_writes_exact=True,selected_code_cache_immutable_each_update=True,saved_cycles=dict(min=min(saved),max=max(saved),mean=sum(saved)/len(saved)))
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);ap.add_argument('--only',default='policies,publisher,Main');args=ap.parse_args();assert not args.output.exists();old=A.scoped_load(OLD/'candidate.nes');b=A.scoped_load(O/'candidate.nes');d=dict(passed=False,native=False,checks={})
 try:
  for name in args.only.split(','):d['checks'][name]={'policies':policies,'publisher':publisher,'Main':main_updates}[name](old,b)
  d['passed']=True
 except Exception as e:d.update(failure=repr(e),traceback=traceback.format_exc())
 d['bindings']={str(p.resolve()):A.sha(p)for p in[Path(__file__),Path(C.__file__),Path(H.__file__),O/'candidate.nes',O/'candidate.dbg',O/'cache-final-link-proof.json',OLD/'candidate.nes',OLD/'candidate.dbg']};args.output.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(passed=d['passed'],checks=list(d['checks']),failure=d.get('failure'))));assert d['passed']
if __name__=='__main__':main()
