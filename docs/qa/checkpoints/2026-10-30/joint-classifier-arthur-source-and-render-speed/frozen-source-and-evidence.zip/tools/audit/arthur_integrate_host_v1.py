"""Actual private Arthur source link on qualified PN/Ice immutable producer overrides."""
from pathlib import Path
import hashlib,json,re,subprocess,sys
R=Path(__file__).resolve().parents[2];O=R/'build/arthur-host-integration-v1';P=R/'build/arthur-host-prep-v6';A=O/'arthur';D=O/'dense';T=O/'frozen-inputs'
sys.path.insert(0,str(Path(__file__).parent))
from link_pit_rygar_sophia_audit_cpu import scoped_load
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,newline='\n')
def prepare():
 assert (O/'dense-parent-reproduction.json').exists()
 A.mkdir(exist_ok=True);b=scoped_load(O/'dense-parent.nes')
 names=['native-kernels','component','host-state','host-world','host-render','palette','art','host-adapter']
 for n in names:save(A/(n+'.s'),(P/(n+'.s')).read_text())
 for n in ['native-context.inc','adapter-imports.inc']:save(A/n,(P/n).read_text())
 native=(A/'native-kernels.s').read_text();lo=native.index('.segment "ARTHUR_PTR"');hi=native.index('.segment "ARTHUR_SCALARS"')
 native=native[:lo]+'''.importzp R0,R1
.exportzp ArNativeZpStart,ArNativeZpEnd,ArR_009D,ArR_009E
ArNativeZpStart=R0
ArNativeZpEnd=R0+2
ArR_009D=R0
ArR_009E=R1
'''+native[hi:];save(A/'native-kernels.s',native)
 combined='\n'.join((A/(n+'.s')).read_text()for n in names)+'\n'+(A/'adapter-imports.inc').read_text()
 tokens=set(re.findall(r'\b[A-Za-z_][A-Za-z_0-9]*\b',re.sub(r';[^\n]*','',combined)))
 parent={n:row for n,row in b['syms'].items()if n in tokens and row.get('scope')=='1'and not n.startswith('ARTHUR_')}
 exports=['.export'+('zp 'if row.get('addrsize')=='zeropage'else' ')+n for n,row in sorted(parent.items())]
 exports += ['.import ArPalPoseIndex,ArHostEnsure','.exportzp ARTHUR_ART_PHASE_BANK,ARTHUR_NATIVE_PHASE_BANK','ARTHUR_ART_PHASE_BANK=.lobyte(.bank(ArPalPoseIndex)|$80)','ARTHUR_NATIVE_PHASE_BANK=.lobyte(.bank(ArHostEnsure)|$80)']
 save(O/'arthur-parent-exports.inc','\n'.join(exports)+'\n')
 entry=(O/'entrypoint.s').read_text()
 if '.include "arthur-parent-exports.inc"'not in entry:entry+='\n.include "arthur-parent-exports.inc"\n'
 save(O/'entrypoint.s',entry)
 # New source object contains actual CHR payload. Old192K producer is absent.
 save(A/'chr.s','.segment "ARTHUR_CHR"\n.incbin "'+(R/'build/arthur-palette-leaf-v6/arthur-lossless.chr').as_posix()+'"\n')
 # True normal-NMI completion: Pn is C116, gateway is C117. Replace exactly
 # the original prefix. UpdateScreen's fast copier needs C116 mapped.
 # The extra prefix byte is balanced by1 unreachable legacy Copy byte;
 # all external continuations now bind genuine labels rather than offsets.
 bells=(T/'src/parodius_bells.s').read_text()
 old=''' jsr UpdateScreen
 lda SelectedCharacter
 cmp #18
 bne Samus
 .if NEVER
'''.replace(' .if NEVER\n','')
 old+='''.if ::ENABLE_MMC5_EXPANDED && ::MAPPER_MMC5
 jmp PnHudCommitAfterVram
.else
 lda OperMode
.endif'''
 assert old in bells
 new=''' jsr UpdateScreen
 lda #>(ArPaletteScreenUpdate-1)
 pha
 lda #<(ArPaletteScreenUpdate-1)
 pha
 lda #.lobyte(.bank(ArPaletteScreenUpdate)|$80)
 jmp ArNmiPhysicalCWrite
 .assert *-PnPaletteScreenUpdate=14,error,"Actual C116 Vram/gateway prefix"
ArContinue:
'''
 bells=bells.replace(old,new,1)
 needle=' sta PnBombPaletteShadow,x\n inx\n cpx #32\n bne Copy\n lda #0';assert needle in bells
 bells=bells.replace(needle,' sta PnBombPaletteShadow,x\n .if !(::ENABLE_MMC5_EXPANDED && ::MAPPER_MMC5)\n inx\n .endif\n cpx #32\n bne Copy\nCaptureComplete:\n lda #0',1)
 bells+='\n.export ArPnAfterPalette\nArPnAfterPalette=PnPaletteScreenUpdate::Samus\n'
 save(D/'parodius_bells.s','.import ArPaletteScreenUpdate\n'+bells)
 hud=(T/'src/parodius_hud_queue.s').read_text();assert hud.count('PnPaletteScreenUpdate+13')==2
 save(D/'parodius_hud_queue.s',hud.replace('PnPaletteScreenUpdate+13','PnPaletteScreenUpdate::ArContinue'))
 fast=(T/'src/nmi_vram_fast.s').read_text();assert fast.count('PnPaletteScreenUpdate::Copy+11')==1
 save(D/'nmi_vram_fast.s',fast.replace('PnPaletteScreenUpdate::Copy+11','PnPaletteScreenUpdate::CaptureComplete'))
 # Label-only alias of the actual existing fixed hardware-store/RTS tail.
 mmc5=(O/'src/mmc5.s').read_text();needle='  sta CurrentBankC\n  sta MMC5_PRG_BANK_C\n  rts\n::DwResidentGraphicsBanks:';assert needle in mmc5
 save(D/'mmc5.s',mmc5.replace(needle,'  sta CurrentBankC\n.export ArNmiPhysicalCWrite\n::ArNmiPhysicalCWrite:\n  sta MMC5_PRG_BANK_C\n  rts\n::DwResidentGraphicsBanks:',1))
 # Authoritative current common512B family lease, no new resident space.
 nmi=(O/'gm-nmi.s').read_text();assert 'Tick:\n jsr GmNmiClock' in nmi
 nmi='.import ArHostNmiClock\n'+nmi.replace('Tick:\n jsr GmNmiClock','''Tick:
 lda SelectedCharacter
 cmp #32
 beq ArthurClock
 cmp #26
 bne SkipClock
 jsr GmNmiClock
 jmp SkipClock
ArthurClock:
 jsr ArHostNmiClock-$2000''',1);save(O/'arthur-gm-nmi.s',nmi)
 # Common rare routes retain every original sixteen-byte public entry.
 union=(O/'union.s').read_text();routes=re.findall(r'\.proc (Hu\w+)\n sta SafecallA_SMC\+1\n php\n tya\n pha\n ldy #(\d+)',union);assert len(routes)==36
 targets={n:'ArHostNoop'for n,i in routes}
 targets.update(HuMovement='ArHostMovement',HuGraphics='ArHostGraphics',HuDraw='ArHostDraw',HuPortrait='ArHostGraphics',HuWeapons='ArHostShotContacts',HuInjury='ArHostInjury',HuInjuryStatus='ArHostStatus',HuDeathStart='ArHostDeath',HuDeath='ArHostNativeDeath',HuVisible='ArHostVisible',HuHead='ArHostHead',HuBody='ArHostBodyPolicy',HuAdder='ArHostAdder',HuBox='ArHostBoxProfile',HuSide='ArHostSide',HuFresh='ArHostConstruct',HuFullBox='ArHostBox',HuMenuPortrait='ArHostPortrait',HuReset='ArHostReset',HuPrepare='ArHostPrepare',HuPickup='ArHostCollect',HuFullPower='ArHostFullPower',HuUi='ArHostUi',HuWorldPalette='ArHostWorldColors')
 targets.update(HuColors='ArHostColors',HuStatus='ArHostName')
 actual=[targets[n]for n,i in sorted(routes,key=lambda x:int(x[1]))]
 own=set(actual)|{'ArDrawPtr','ArDispatch','ArAfterTerrainDispatch','ArHostRelease','ArHostSelect','ArHostFoot','DkHostFeetRouter'}
 union='.import '+','.join(sorted(own))+'\n'+union
 union=union.replace('.proc HuCommon\n lda SelectedCharacter\n','''.proc HuCommon
 lda SelectedCharacter
 cmp #32
 bne Existing
 lda HuArthurLo,y
 sta ArDrawPtr
 lda HuArthurHi,y
 sta ArDrawPtr+1
 lda #<ArDispatch
 sta FarcallJmpTarget_SMC+1
 lda #>ArDispatch
 sta FarcallJmpTarget_SMC+2
 lda #.lobyte(.bank(ArDispatch)|$80)
 sta NextBank_SMC+1
 jmp RestoreCaller
Existing:
 lda SelectedCharacter
''',1)
 union=union.replace(' sta NextBank_SMC+1\n pla\n tay\n plp\n jmp FarCallCommon+3',' sta NextBank_SMC+1\nRestoreCaller:\n pla\n tay\n plp\n jmp FarCallCommon+3',1)
 tables=''
 for n,op in [('HuArthurLo','<'),('HuArthurHi','>')]:tables+=n+':\n .byte '+','.join(op+t for t in actual)+'\n'
 union=union.replace('HuLo:',tables+'HuLo:',1)
 union=union.replace('.proc HuAfterTerrainGate\n php\n pha\n','.proc HuAfterTerrainGate\n php\n pha\n lda SelectedCharacter\n cmp #32\n bne Existing\n pla\n plp\n farcall ArAfterTerrainDispatch,jmp\nExisting:\n',1)
 # Exit restoration executes while raw32 still owns the phase aliases.
 union=union.replace('.proc HuResolve\n php\n pha\n','''.proc HuResolve
 php
 pha
 lda SelectedCharacter
 cmp #32
 bne Existing
 lda #<ArHostRelease
 sta ArDrawPtr
 lda #>ArHostRelease
 sta ArDrawPtr+1
 farcall ArDispatch
Existing:
''',1)
 # Constructor is entered through the ordinary A gate, so load its C63
 # native companion before any scene/profile access.
 union=union.replace(' cmp #26\n beq Gimmick\n cmp #28',' cmp #32\n beq Arthur\n cmp #26\n beq Gimmick\n cmp #28',1)
 union=union.replace('Gimmick:\n pla','Arthur:\n pla\n pha\n lda #<ArHostSelect\n sta ArDrawPtr\n lda #>ArHostSelect\n sta ArDrawPtr+1\n pla\n farcall ArDispatch\n jmp Done\nGimmick:\n pla',1)
 feet='''.export HuArthurFeetGate
.proc HuArthurFeetGate
 lda SelectedCharacter
 cmp #32
 bne Legacy
 lda #<ArHostFoot
 sta ArDrawPtr
 lda #>ArHostFoot
 sta ArDrawPtr+1
 farcall ArDispatch,jmp
Legacy:
 farcall DkHostFeetRouter,jmp
.endproc
'''
 union=union.replace('HuEnd:',feet+'\nHuEnd:',1);save(O/'arthur-union.s',union)
 characters=(O/'src/characters.s').read_text();old='  cmp #CHARACTER_DONKEY_KONG\n  bne FootNative\nFootCold:\n  farcall DkHostFeetRouter,jmp'
 assert old in characters
 characters=characters.replace(old,'  cmp #CHARACTER_DONKEY_KONG\n  beq FootCold\n  cmp #32\n  bne FootNative\nFootCold:\n  farcall HuArthurFeetGate,jmp',1).replace('  .res 5,$ea\n  .assert *-CrossoverHeadProbe=62','  .res 1,$ea\n  .assert *-CrossoverHeadProbe=62',1)
 save(O/'arthur-characters.s',characters)
 # The real public Nr selectors must admit raw32 before any legacy owner
 # touches its selected-phase overlay. Keep every97B capsule and label PC.
 nr=(O/'src/new_roster_dispatch.s').read_text()
 start=nr.index('::GmNrIndex:');end=nr.index('.endscope',start)
 nr=nr[:start]+'''::GmNrIndex:
 lda SelectedCharacter
 cmp #24
 beq Rare
 cmp #28
 beq Rare
 cmp #32
 beq Rare
 cmp #20
 bcc Native
 cmp #27
 bcs Native
 tay
 lda Index-20,y
 tay
 rts
Native:ldy #0
 rts
Index:.byte 1,2,0,3,0,0,4
Rare:
 txa
 tay
 tsx
 lda $0101,x
 adc $0102,x
 jmp GmNrRare
 .res 3,$ff
'''+nr[end:]
 start=nr.index('::GmOnlyCommon:');end=nr.index('.endmacro',start)
 chunk=nr[start:end];assert chunk.count(' cmp #28\n beq Rare')==1
 nr=nr[:start]+chunk.replace(' cmp #28\n beq Rare',' cmp #28\n beq Rare\n cmp #32\n beq Rare')+nr[end:]
 nr=nr.replace('97,GmExtraNrPortrait,47,0','97,GmExtraNrPortrait,51,0',1)
 save(O/'arthur-new-roster-dispatch.s',nr)
 # Source completed DrawAll wrapper; no native OAM producer is bypassed.
 game=(O/'src/game.s').read_text();assert'farcall SamusFreezeDrawAll'in game
 save(O/'src/arthur_game.s',game.replace('farcall SamusFreezeDrawAll','farcall ArHostDrawAll'))
 rare=(O/'src/bill_native_rare.s').read_text();assert 'farcall SamusFreezeDrawAll'in rare
 save(O/'arthur-bill-native-rare.s',rare.replace('farcall SamusFreezeDrawAll','farcall ArHostDrawAll'))
 # Private test readiness. Shared menu and its archived80profile receipt stay
 # unchanged; admission still requires the actual native checks below.
 fm=(O/'src/full_roster_menu.s').read_text();needle=' cpx #25\n beq Ready\n';assert needle in fm
 fm=fm.replace(needle,needle+' cpx #31\n beq Ready\n',1)
 # Keep approved front-end art/name index30 even though the private Start
 # gate is ready. Menu palette ownership stays with the original UI.
 helper='''.proc FmArthurPreviewIndex
 ldx CrossoverMenuIndex
 cpx #31
 bne Native
 lda #30
 sec
 rts
Native:jmp FmPending
.endproc
.export FmArthurPreviewIndex
'''
 fm=fm.replace('.proc FmResolve',helper+'\n.proc FmResolve',1)
 for label in ['.proc FmQueueName','.proc FmDrawPreview']:
  start=fm.index(label);end=fm.index('.endproc',start)
  fm=fm[:start]+fm[start:end].replace('jsr FmPending','jsr FmArthurPreviewIndex',1)+fm[end:]
 save(O/'arthur-full-roster-menu.s',fm)
 select=(O/'src/character_select.s').read_text()
 for label in ['.proc QueueSelection','.proc DrawSelectionPreview']:
  start=select.index(label);end=select.index('.endproc',start)
  select=select[:start]+select[start:end].replace('farcall FmPending','farcall FmArthurPreviewIndex',1)+select[end:]
 save(O/'arthur-character-select.s',select)
 # Kept as separate derived source until the final build, so source parent
 # reproduction remains repeatable and immutable within this directory.
 save(O/'arthur-hooks.json',json.dumps(dict(routes=targets,parent_symbols=sorted(parent),source_names=names),indent=2)+'\n')
 print(json.dumps(dict(status='ACTUAL_HOST_SOURCES_PREPARED_PLACEMENT_REVIEW_PENDING',routes=len(routes),parent_exports=len(parent))))

def physical_config():
 s=(D/'compact.cfg').read_text()
 s=s.replace('    X5_NEW_3F: start=$a000, size=$2000, type=ro, file=%O, fill=yes, fillval=$ff, bank=$3f;','''    X5_NEW_3F:start=$a000,size=$1001,type=ro,file=%O,fill=yes,fillval=$ff,bank=$3f;
    AR_C63_SMALL:start=$d001,size=$3ff,type=ro,file=%O,fill=yes,fillval=$ff,bank=$3f;
    AR_C63_MID:start=$b400,size=$64c,type=ro,file=%O,fill=yes,fillval=$ff,bank=$3f;
    AR_C63_LARGE:start=$da4c,size=$5b4,type=ro,file=%O,fill=yes,fillval=$ff,bank=$3f;''')
 s=s.replace('ZELDA_WRAP_MEM:start=$dc00, size=$0400','ZELDA_WRAP_MEM:start=$dc00, size=$0132')
 key='    CV_MEM:start='
 at=s.index(key);s=s[:at]+'    AR_A26_TAIL:start=$bd32,size=$2ce,type=ro,file=%O,fill=yes,fillval=$ff,bank=$1a;\n'+s[at:]
 s=s.replace('    X5_NEW_75: start=$c000, size=$2000, type=ro, file=%O, fill=yes, fillval=$ff, bank=$75;','''    X5_NEW_75:start=$c000,size=$9c2,type=ro,file=%O,fill=yes,fillval=$ff,bank=$75;
    AR_NMI_GATE_MEM:start=$c9c2,size=$3e,type=ro,file=%O,fill=yes,fillval=$ff,bank=$75;
    AR_FUTURE_S2_AUDIO:start=$ca00,size=$1600,type=ro,file=%O,fill=yes,fillval=$ff,bank=$75;''')
 s=s.replace('    RECLAIMED_PARODIUS_CHR_MEM: start=$d9000,size=$27000,type=ro,fill=yes,file=%O,fillval=$00;','''    ARTHUR_CHR_MEM:start=$d9000,size=$4000,type=ro,fill=yes,file=%O,fillval=$00;
    RECLAIMED_PARODIUS_CHR_MEM:start=$dd000,size=$23000,type=ro,fill=yes,file=%O,fillval=$00;''')
 s=s.replace('MEMORY {','MEMORY {\n AR_ACTIVE:start=$5c00,size=$b0,type=rw,file="";\n AR_PROFILE:start=$5f90,size=$8,type=rw,file="";',1)
 s=s.replace('GIMMICK_COMMON_NMI:load=X5_NEW_3F','GIMMICK_COMMON_NMI:load=AR_C63_MID').replace('PALETTE_COALESCE:load=X5_NEW_3F','PALETTE_COALESCE:load=AR_C63_MID')
 segments='''
 ARTHUR_SCALARS:load=AR_ACTIVE,type=bss;
 ARTHUR_STATE:load=AR_ACTIVE,type=bss;
 ARTHUR_HOST_STATE:load=AR_ACTIVE,type=bss;
 ARTHUR_PROFILE:load=AR_PROFILE,type=bss;
 ARTHUR_WORLD:load=LEVEL_VARIANTS_MEM,type=ro,start=$a57a;
 ARTHUR_BODY:load=CROSSOVER_HELPERS_MEM,type=ro,start=$b32a;
 ARTHUR_LEAF:load=CROSSOVER_HELPERS_MEM,type=ro;
 ARTHUR_DRAW:load=CROSSOVER_HELPERS_MEM,type=ro;
 ARTHUR_PROBES:load=AR_A26_TAIL,type=ro;
 ARTHUR_COMBAT:load=AR_A26_TAIL,type=ro;
 ARTHUR_ADAPTER:load=AR_A26_TAIL,type=ro;
 ARTHUR_PALETTE_MODE:load=AR_A26_TAIL,type=ro;
 ARTHUR_SHOTS:load=AR_C63_SMALL,type=ro;
 ARTHUR_LIFECYCLE:load=AR_C63_SMALL,type=ro;
 ARTHUR_ADAPTER_COLLECT:load=AR_C63_SMALL,type=ro;
 ARTHUR_COMMON:load=AR_C63_LARGE,type=ro;
 ARTHUR_CLOCK:load=AR_C63_LARGE,type=ro;
 ARTHUR_PUBLISH:load=AR_C63_LARGE,type=ro;
 ARTHUR_ADAPTER_COLD:load=AR_C63_LARGE,type=ro;
 ARTHUR_NMI_GATEWAY:load=AR_NMI_GATE_MEM,type=ro;
 ARTHUR_CHR:load=ARTHUR_CHR_MEM,type=ro;
'''
 small='\n ARTHUR_ART_SMALL:load=X5_NEW_46,type=ro,start=$c58f;\n ARTHUR_PALETTE_NMI:load=X5_NEW_46,type=ro;\n ARTHUR_PALETTE_WHITE:load=X5_NEW_46,type=ro;\n'
 anchor='    ICE_CLIMBERS_ART: load=X5_NEW_46,type=ro,start=$c380,optional=yes;';assert anchor in s;s=s.replace(anchor,anchor+small,1)
 anchor='    RIVER_CITY_ART: load=X5_NEW_46,type=ro,start=$cb80,optional=yes;';assert anchor in s;s=s.replace(anchor,anchor+'\n ARTHUR_ART_TAIL:load=X5_NEW_46,type=ro,start=$d9b8;',1)
 at=s.index('\n}\nSYMBOLS');s=s[:at]+segments+s[at:];save(O/'arthur.cfg',s)

def build():
 grant=R/'docs/qa/checkpoints/2026-10-30/arthur-ice-alias-allocation/root-review-and-reservations.json';assert sha(grant)=='91a42027f666ede37f0ec6ab438a6ac908837c1ad4538836011fb331ccc1a0b6'
 ice=R/'build/ice-pose-aliases-v2'
 for n in ['ice_climbers.s','ice_climbers_art.inc']:save(D/n,(ice/n).read_text())
 physical_config()
 # Shadows derive exclusively from the private source parent copies.
 save(D/'characters.s',(O/'arthur-characters.s').read_text())
 save(D/'new_roster_dispatch.s',(O/'arthur-new-roster-dispatch.s').read_text())
 save(D/'game.s',(O/'src/arthur_game.s').read_text())
 save(D/'full_roster_menu.s',(O/'arthur-full-roster-menu.s').read_text())
 save(D/'character_select.s',(O/'arthur-character-select.s').read_text())
 save(D/'bill_native_rare.s',(O/'arthur-bill-native-rare.s').read_text())
 maincmd=json.loads((O/'dense-parent-reproduction.json').read_text())['commands'][0]['command'];maincmd=maincmd[:]
 # Main imports actual link symbols from the component rather than DBG PCs.
 prefix='.import ArHostDrawAll,HuArthurFeetGate\n'
 mainentry=(O/'entrypoint.s').read_text()
 if not mainentry.startswith(prefix):save(O/'entrypoint.s',prefix+mainentry)
 ca=R/'tools/Windows/cc65/bin/ca65.exe';commands=[]
 for n in ['native-kernels','component','host-state','host-world','host-render','palette','art','host-adapter','chr']:
  commands.append([str(ca),'-g','-I',str(A),'-o',str(A/(n+'.o')),str(A/(n+'.s'))])
 commands += [maincmd]
 commands += [[str(ca),'-g','-I',str(O),'-I',str(T),'-I',str(T/'src'),str(O/'arthur-union.s'),'-o',str(O/'arthur-union.o')]]
 # Use the original NMI object's exact include list/options and new source.
 oldcmd=next(c for c in json.loads((O/'parent-commands.json').read_text())if any(str(v).endswith('gm-nmi.s')for v in c));commands.append([str(O/'arthur-gm-nmi.s')if str(v).endswith('gm-nmi.s')else str(O/'arthur-gm-nmi.o')if str(v).endswith('gm-nmi.o')else v for v in oldcmd])
 link=json.loads((O/'dense-parent-reproduction.json').read_text())['commands'][1]['command'];link=link[:];link[link.index('-C')+1]=str(O/'arthur.cfg')
 link=[str(O/'arthur-union.o')if str(v).endswith('/union.o')or str(v).endswith('\\union.o')else str(O/'arthur-gm-nmi.o')if str(v).endswith('gm-nmi.o')else v for v in link]
 link +=[str(A/(n+'.o'))for n in ['native-kernels','component','host-state','host-world','host-render','palette','art','host-adapter','chr']];commands.append(link)
 logs=[]
 for cmd in commands:
  cp=subprocess.run(cmd,cwd=T,capture_output=True,text=True);logs.append(dict(command=cmd,rc=cp.returncode,stdout=cp.stdout,stderr=cp.stderr));save(O/'arthur-build-log.json',json.dumps(logs,indent=2)+'\n');assert not cp.returncode,cp.stderr[:14000]
 sys.path.insert(0,str(R/'tools'));from prepare_cv3_dmc_mirror import prepare as mirror
 mirror(R,O/'candidate.nes')
 result=dict(status='PRIVATE_ACTUAL_SOURCE_LINKED_ARTHUR_CANDIDATE_CPU_NATIVE_PENDING',candidate_sha256=sha(O/'candidate.nes'),commands=logs,limits='Private readiness only; native route/palette/death/lifecycle admission still pending.')
 save(O/'arthur-build-proof.json',json.dumps(result,indent=2)+'\n');print(json.dumps(dict(status=result['status'],sha256=result['candidate_sha256'])))
if __name__=='__main__':
 if '--build'in sys.argv:prepare();build()
 else:prepare()
