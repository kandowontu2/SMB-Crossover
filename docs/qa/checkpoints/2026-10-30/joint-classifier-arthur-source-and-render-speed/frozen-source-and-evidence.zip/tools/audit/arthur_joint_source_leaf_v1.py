"""Export genuine frozen Arthur producers and an exact fast-v6 link recipe.

Does not link a cartridge, install hooks, mutate a predecessor, or run Mesen.
"""
from pathlib import Path
import difflib, hashlib, json, re, shutil, subprocess, sys

R = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(R/'tools/audit'), str(R/'tools')]
from link_pit_rygar_sophia_audit_cpu import scoped_load

P = R/'build/arthur-body-fair-v3'
J = R/'build/character-host-union-rogue-fast-v6/joint'
V = R/'build/arthur-common-merge-plan-v3'
O = R/'build/arthur-joint-source-leaf-v1'
CC = R/'tools/Windows/cc65/bin'
MODULES = ['native-kernels','component','host-state','host-world','host-render',
           'palette','art','host-adapter','chr','own-services']
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()

def save(p, text):
    p = Path(p)
    assert p.resolve().is_relative_to(O.resolve()), p
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text, newline='\n')

def apply_config(text):
    def once(old, new):
        nonlocal text
        assert text.count(old) == 1, old
        text = text.replace(old, new, 1)
    once('MEMORY {', '''MEMORY {
 ARTHUR_CACHE_RUN:start=$d800,size=$7e0,type=rw,file="";
 AR_OWN_RUN:start=$bd00,size=$300,type=ro,file="",bank=$46;
 AR_ACTIVE:start=$5c00,size=$b0,type=rw,file="";
 AR_PROFILE:start=$5f90,size=$8,type=rw,file="";''')
    once('ZELDA_WRAP_MEM:start=$dc00, size=$0400', 'ZELDA_WRAP_MEM:start=$dc00, size=$0132')
    once('    CV_MEM:start=', '    AR_A26_TAIL:start=$bd32,size=$2ce,type=ro,file=%O,fill=yes,fillval=$ff,bank=$1a;\n    CV_MEM:start=')
    once('    X5_NEW_3F: start=$a000, size=$2000, type=ro, file=%O, fill=yes, fillval=$ff, bank=$3f;', '''    X5_NEW_3F:start=$a000,size=$1001,type=ro,file=%O,fill=yes,fillval=$ff,bank=$3f;
    AR_C63_SMALL:start=$d001,size=$3ff,type=ro,file=%O,fill=yes,fillval=$ff,bank=$3f;
    AR_C63_MID:start=$b400,size=$64c,type=ro,file=%O,fill=yes,fillval=$ff,bank=$3f;
    AR_C63_LARGE:start=$da4c,size=$5b4,type=ro,file=%O,fill=yes,fillval=$ff,bank=$3f;''')
    once('    X5_NEW_46: start=$c000, size=$2000, type=ro, file=%O, fill=yes, fillval=$ff, bank=$46;', '''    X5_NEW_46:start=$c000,size=$1d00,type=ro,file=%O,fill=yes,fillval=$ff,bank=$46;
    AR_OWN_LOAD:start=$dd00,size=$300,type=ro,file=%O,fill=yes,fillval=$ff,bank=$46;''')
    once('    X5_NEW_75: start=$c000, size=$2000, type=ro, file=%O, fill=yes, fillval=$ff, bank=$75;', '''    X5_NEW_75:start=$c000,size=$9c2,type=ro,file=%O,fill=yes,fillval=$ff,bank=$75;
    AR_NMI_GATE_MEM:start=$c9c2,size=$3e,type=ro,file=%O,fill=yes,fillval=$ff,bank=$75;
    AR_FUTURE_S2_AUDIO:start=$ca00,size=$1600,type=ro,file=%O,fill=yes,fillval=$ff,bank=$75;''')
    once('    RECLAIMED_PARODIUS_CHR_MEM: start=$d9000,size=$27000,type=ro,fill=yes,file=%O,fillval=$00;', '''    ARTHUR_CHR_MEM:start=$d9000,size=$3400,type=ro,fill=yes,file=%O,fillval=$00;
    ARTHUR_CACHE_STORAGE:start=$dc400,size=$c00,type=ro,fill=yes,file=%O,fillval=$00;
    RECLAIMED_PARODIUS_CHR_MEM:start=$dd000,size=$23000,type=ro,fill=yes,file=%O,fillval=$00;''')
    for name in ['ROGUE_SCHEDULER_COMMON','GIMMICK_COMMON_NMI','PALETTE_COALESCE']:
        once(name+':load=X5_NEW_3F', name+':load=AR_C63_MID')
    frozen = (P/'arthur.cfg').read_text()
    segments = re.findall(r'^ ARTHUR_[^\n]+;', frozen.split('SEGMENTS {',1)[1], re.M)
    assert len(segments) == 27, len(segments)
    once('SEGMENTS {', 'SEGMENTS {\n'+'\n'.join(segments)+'''\n ARTHUR_OWN_SERVICES:load=AR_OWN_LOAD,run=AR_OWN_RUN,type=ro,define=yes;
''')
    return text

def od_names(path, kind):
    p = subprocess.run([str(CC/'od65.exe'),'--dump-'+kind,str(path)],capture_output=True,text=True,check=True)
    return {m[1]: 'zeropage' if m[0]=='01' else 'absolute'
            for m in re.findall(r'Address size:\s+0x(\w+)[\s\S]*?Name:\s+"([^"]+)"', p.stdout)}

def main():
    assert not O.exists() or '--resume-unfrozen' in sys.argv, O
    assert sha(P/'candidate.nes') == '09237b6f1b88b50d9c3ba054092af36591daa435d43eb83bf21ed08ca856d671'
    assert sha(J/'candidate.nes') == '2ed6d9f8c05d08eac3a2df080df3f4d02fc301a9eaab0724e6d8a4581b753629'
    O.mkdir(exist_ok=True); a=O/'arthur'; a.mkdir(exist_ok=True)
    for src in (P/'arthur').iterdir():
        if src.suffix in ['.s','.inc','.bin']:
            shutil.copy2(src, a/src.name)
    body=R/'build/arthur-palette-leaf-v6/arthur-lossless.chr'
    shutil.copy2(body,a/'body.chr')
    save(a/'chr.s','.segment "ARTHUR_CHR"\n.incbin "body.chr"\n')
    services=(V/'own-services.s').read_text().replace('.importzp ArDispatchBank\n','')
    assert 'ArDispatchBank|$80' in services
    services=services.replace('ArDispatchBank|$80','.bank(ArDispatch)|$80')
    save(a/'own-services.s', services)
    logs=[]; imports={}; exports={}; modules=[]
    for name in MODULES:
        cmd=[str(CC/'ca65.exe'),'-g','-I',str(a),'-o',str(a/(name+'.o')),str(a/(name+'.s'))]
        p=subprocess.run(cmd,cwd=a,capture_output=True,text=True)
        logs.append(dict(command=cmd,rc=p.returncode,stdout=p.stdout,stderr=p.stderr))
        assert p.returncode==0,p.stderr
        ii=od_names(a/(name+'.o'),'imports'); ee=od_names(a/(name+'.o'),'exports')
        imports.update(ii); exports.update(ee)
        modules.append(dict(module=name,imports=ii,exports=ee))
    external={n:v for n,v in sorted(imports.items()) if n not in exports}
    linker={n:v for n,v in external.items() if n.startswith('__ARTHUR_')}
    banks={n:v for n,v in external.items() if n.startswith('ARTHUR_')}
    parent=scoped_load(J/'candidate.nes'); old=scoped_load(P/'candidate.nes')
    required={}; missing=[]; lines=[]
    for name, size in external.items():
        if name in linker or name in banks: continue
        symbol=parent['syms'].get(name)
        if symbol and symbol.get('scope')=='1':
            required[name]=dict(address=int(symbol['val'],0),addrsize=symbol.get('addrsize'),requested=size)
            lines.append(('.exportzp ' if size=='zeropage' else '.export ')+name)
        else: missing.append(name)
    assert sorted(missing)==['ArNmiPhysicalCWrite','ArPnAfterPalette'], missing
    lines += ['.import ArPalPoseIndex,ArHostEnsure',
              '.exportzp ARTHUR_ART_PHASE_BANK,ARTHUR_NATIVE_PHASE_BANK',
              'ARTHUR_ART_PHASE_BANK=.lobyte(.bank(ArPalPoseIndex)|$80)',
              'ARTHUR_NATIVE_PHASE_BANK=.lobyte(.bank(ArHostEnsure)|$80)']
    save(O/'parent-exports.inc','\n'.join(lines)+'\n')
    cfg=apply_config((J/'private.cfg').read_text()); save(O/'arthur-on-fast-v6.cfg',cfg)
    save(O/'config.patch',''.join(difflib.unified_diff((J/'private.cfg').read_text().splitlines(True),cfg.splitlines(True),fromfile='fast-v6/private.cfg',tofile='arthur-on-fast-v6.cfg')))
    # Actual frozen source placements, not a fill-only capacity assumption.
    placements=[]
    for seg in old['segs'].values():
        if seg['name'].startswith('"ARTHUR_') and 'ooffs' in seg:
            pos,sz=(int(seg[k],0)for k in ['ooffs','size'])
            if pos<0x100010:
                assert parent['raw'][pos:pos+sz] == bytes([255])*sz, seg['name']
                placements.append(dict(segment=seg['name'].strip('"'),ROM_offset=pos,bytes=sz,parent_FF=True))
    assert sum(z['bytes'] for z in placements)==7389
    assert parent['raw'][16+0x100000+868*1024:16+0x100000+884*1024]==bytes(16384)
    expected=P/'native/cold-fair-smoke-v7/actual-cache.bin'
    assert expected.stat().st_size==6130
    shutil.copy2(expected,O/'expected-cache.bin')
    report=dict(status='GENUINE_RELOCATABLE_PRODUCERS_AND_CONFIG_ONLY_NO_CARTRIDGE_OR_NATIVE',
      frozen_Arthur=sha(P/'candidate.nes'),joint_parent=sha(J/'candidate.nes'),modules=modules,
      required_native_exports=required,missing_source_label_exports=missing,
      linker_generated_imports=linker,link_time_bank_definitions=banks,
      private_PRG_preimages=placements,private_PRG_bytes=7389,
      own_services=dict(bytes=732,physical70_C_load=[0xdd00,0xdfdc],A_run=[0xbd00,0xbfdc],truebank=198,reject=0xbd6c,retained_API_receipt=str(V/'API-controls-v5.json')),
      resources=dict(active=[0x5c00,0x5cb0],profile=[0x5f90,0x5f98],C2_data=[0xc000,0xd7f2],C2_code=[0xd800,0xda26],cookie=[0xdfe0,0xdff0],CHR=[868,884],RAM1=False),
      source_deltas=dict(chr_s='Only .incbin pathname changed; exact original13KiB bytes.',own_services='ArDispatch bank is genuine .bank(ArDispatch) relocation; no numeric fixture imports.'),
      commands=logs)
    save(O/'source-component.json',json.dumps(report,indent=2)+'\n')
    print(json.dumps(dict(output=str(O),modules=len(modules),native_exports=len(required),missing_labels=missing,private_PRG=7389,own_services=732,component_sha256=sha(O/'source-component.json'))))

if __name__=='__main__': main()
