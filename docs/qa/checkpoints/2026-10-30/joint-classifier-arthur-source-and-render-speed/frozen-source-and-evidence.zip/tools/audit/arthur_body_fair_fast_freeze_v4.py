"""Bind exact source/PRG deltas for the separately qualified fair fast path."""
from pathlib import Path
import hashlib,json,sys,zipfile
import arthur_body_fair_fast_build_v4 as B
from link_pit_rygar_sophia_audit_cpu import scoped_load
from check_tmnt_render_oa import address,location
R=B.R;O=B.O;P=B.P
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
 assert not(O/'handoff-v4.json').exists()
 old=scoped_load(P/'candidate.nes');new=scoped_load(O/'candidate.nes')
 assert sha(O/'candidate.nes')=='1638426830ef3fea3d4dbc091e2e331f6665bf951547c8deb7b5c072318e20d0'
 assert old['raw'][:16]==new['raw'][:16]
 source=(O/'arthur/cache-runtime.s').read_text();assert source.count(B.FAST)==1
 assert source.replace(B.FAST,'')==(P/'arthur/cache-runtime.s').read_text()
 for name in ['native-kernels.s','component.s','host-state.s','host-world.s','host-render.s','palette.s','art.s','host-adapter.s','cache-loader.s','cache-wrapper.s','cache-input.bin','native-context.inc','adapter-imports.inc']:
  assert(O/'arthur'/name).read_bytes()==(P/'arthur'/name).read_bytes(),name
 oldsize=address(old,'ArCacheExecEnd')-address(old,'ArCacheEmit');newsize=address(new,'ArCacheExecEnd')-address(new,'ArCacheEmit')
 assert (oldsize,newsize)==(550,653)
 allowed=set();changes=[]
 # Exact source cookie comparison immediates, each following its authentic
 # AD DFE0+i / CMP immediate instruction sequence.
 start=location(old,'ArCacheEnsure');end=location(old,'ArCacheRetire')
 oldsig=old['raw'][location(old,'ArCacheLoad::Signature'):location(old,'ArCacheLoad::Signature')+16]
 newsig=new['raw'][location(new,'ArCacheLoad::Signature'):location(new,'ArCacheLoad::Signature')+16]
 for i in range(16):
  pat=bytes([0xad,0xe0+i,0xdf,0xc9,oldsig[i]])
  matches=[k for k in range(start,end-len(pat)+1)if old['raw'][k:k+len(pat)]==pat]
  assert len(matches)==1,(i,matches)
  at=matches[0]+4;assert new['raw'][at]==newsig[i]
  allowed.add(at)
 sig=location(old,'ArCacheLoad::Signature');assert sig==location(new,'ArCacheLoad::Signature')
 allowed.update(range(sig,sig+16))
 count=address(old,'ArDrawCount');part=address(old,'ArDrawPart')
 pat=bytes([0xa9,oldsize&255,0x8d,count&255,count>>8,0xa9,oldsize>>8,0x8d,part&255,part>>8])
 x=old['raw'].find(pat,location(old,'ArCacheLoad'),sig);assert x>=0
 assert new['raw'][x:x+len(pat)]==bytes([0xa9,newsize&255,0x8d,count&255,count>>8,0xa9,newsize>>8,0x8d,part&255,part>>8])
 allowed.update([x+1,x+6])
 diff={i for i in range(16,1048592)if old['raw'][i]!=new['raw'][i]}
 assert diff<=allowed,sorted(diff-allowed)
 pages=sorted({(i-1048592)//1024 for i in range(1048592,len(old['raw']))if old['raw'][i]!=new['raw'][i]});assert pages==[883]
 assert old['raw'][1048592+868*1024:1048592+881*1024]==new['raw'][1048592+868*1024:1048592+881*1024]
 assert (O/'arthur/cache-input.bin').read_bytes()==(P/'arthur/cache-input.bin').read_bytes()
 expected=(P/'native/cold-fair-smoke-v7/actual-cache.bin').read_bytes();assert len(expected)==6130
 code=new['raw'][location(new,'ArCacheEmit'):location(new,'ArCacheEmit')+newsize]
 assert newsig==bytes([167,32,0,1])+hashlib.sha256((O/'arthur/cache-input.bin').read_bytes()+code+expected).digest()[:12]
 proof=dict(passed=True,native=False,parent=sha(P/'candidate.nes'),candidate=sha(O/'candidate.nes'),header_exact=True,source_only_change='103B disjoint body/prefix fast path; exact old overlap/wrap fallback retained',all_original_workers_palette_physics_body_art_and_canonical_cache_exact=True,changed_PRG_bytes=len(diff),allowed_PRG_changes='Cookie CMP immediates/table and actual linked copy-code size operand only',changed_CHR_pages=pages,C2_runtime=newsize,carrier_used=2326+newsize,carrier_reserved=3072,new_RAM=0,new_leases=False)
 (O/'source-proof-v4.json').write_text(json.dumps(proof,indent=2)+'\n')
 docs={}
 for name in ['CPU-controls-v4.json','ISR-controls-v4.json']:
  d=json.loads((O/name).read_text());assert d['passed']
  for path,digest in d['bindings'].items():assert sha(path)==digest,(name,path)
  docs[name]=d
 # Recheck every bound predecessor source, then map only its copied source
 # paths into this new output. Shared/read-only dependencies stay bound.
 previous=json.loads((P/'source-closure.json').read_text());files=set()
 for relative,digest in previous['files'].items():
  p=R/relative;assert sha(p)==digest,relative
  try:newpath=O/p.relative_to(P)
  except ValueError:newpath=p
  files.add(newpath if newpath.exists()else p)
 for d in docs.values():files.update(Path(p)for p in d['bindings'])
 files.update([Path(__file__),Path(B.__file__),O/'source-proof-v4.json',O/'CPU-controls-v4.json',O/'ISR-controls-v4.json',O/'source.patch',O/'cache-final-link-proof.json',O/'candidate.nes',O/'candidate.dbg',O/'candidate.lbl',P/'handoff.json',P/'native-handoff-v7.json'])
 closure=O/'source-closure-v4.json';closure.write_text(json.dumps(dict(candidate=sha(O/'candidate.nes'),files={p.resolve().relative_to(R).as_posix():sha(p)for p in sorted(files)}),indent=2)+'\n')
 archive=O/'source-cpu-v4.zip'
 with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
  for p in sorted(files):z.write(p,p.resolve().relative_to(R).as_posix())
  z.write(closure,closure.relative_to(R).as_posix())
 cpu=docs['CPU-controls-v4.json']['checks'];main=cpu['complete_Main'];isr=docs['ISR-controls-v4.json']['checks']
 handoff=dict(status='PRIVATE_SOURCE_CPU_QUALIFIED_IDENTICAL_FAIR_OAM_FAST_PATH_NATIVE_PENDING_PERFORMANCE_HOLD',candidate=sha(O/'candidate.nes'),parent=sha(P/'candidate.nes'),source_proof=proof,checks={k:v for k,v in cpu.items()if k!='complete_Main'},complete_Main={k:v for k,v in main.items()if k!='rows'},ISR={k:v for k,v in isr.items()if k not in ['rows','nested']},resources=dict(C2_runtime=653,carrier_used=2979,carrier_free=93,new_RAM=0,new_PRG=0,RAM1=False),limits=['No native run, integration or cadence claim. Frozen09237 native216/400lag remains the actual measured fair-renderer result.','Same exact64-record permutation/bodyfirst8/tailfairness and strict full application/OAM/ArTemp/metadata results; no actor/weapon starvation or global rotation change.','CPU bounded improvement is partial; overlap/wrap retains old stack fallback and can add13cycles. Shared A79 composition still needs actual joint callback/ISR/native qualification.'],bindings={str(p.resolve()):sha(p)for p in [closure,archive,O/'candidate.nes',O/'candidate.dbg',O/'candidate.lbl',O/'source-proof-v4.json',O/'CPU-controls-v4.json',O/'ISR-controls-v4.json',P/'handoff.json',P/'native-handoff-v7.json']})
 (O/'handoff-v4.json').write_text(json.dumps(handoff,indent=2)+'\n')
 print(json.dumps(dict(handoff=sha(O/'handoff-v4.json'),archive_bytes=archive.stat().st_size,closure_files=len(files),runtime=653,carrier=2979)))
if __name__=='__main__':main()
