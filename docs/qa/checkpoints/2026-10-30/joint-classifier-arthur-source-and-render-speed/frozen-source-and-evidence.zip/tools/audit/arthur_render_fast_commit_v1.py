"""Observe the relocated genuine C2 publisher STORE through complete Main/NMI.

The retained old observer negative expects a call to ROM X5SetPhysicalChr;
the new source-equivalent publisher deliberately executes in rawRAM2. This
observer pins its actual STA CurrentCHRBank,Y and retains every later native
player-bank/normal-NMI/lag-NMI assertion.
"""
from pathlib import Path
import importlib.util,json,traceback
import arthur_render_fast_regressions_v2 as V
from verify_native_relocation import NesMPU
A=V.A;R=V.R;O=V.O
def run(b):
 spec=importlib.util.spec_from_file_location('render_fast_commit_nmi',R/'build/character-host-union-v5/gm_verify_nmi.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
 rows=[];at=A.address(b,'ArCachePublishFast');physical=A.location(b,'ArCachePublishFast');prefix=b['raw'][physical:physical+6]
 assert prefix==bytes([0x48,0xa2,3,0x99,A.address(b,'CurrentCHRBank')&255,A.address(b,'CurrentCHRBank')>>8]),('genuine source publisher store ABI',prefix)
 for mode,face in[(m,f)for m in range(3)for f in[1,2]]:
  q=V.G.setup(b);q.put(AreaType=1 if mode==0 else 3,SmFreezePaletteControl=8 if mode==2 else 4,PlayerFacingDir=face,DisableScreenFlag=0,Mirror_PPUCTRL=160,Mirror_PPUMASK=30)
  captured=[];old=NesMPU.step
  def step(c):
   if c.pc==at+3 and q.m.rawtags[2]==2 and c.y==0:
    assert c.x==3 and q.m[c.pc]==0x99 and q.m[c.pc+1]+256*q.m[c.pc+2]==A.address(b,'CurrentCHRBank')
    captured.append(c.a+256*(c.x&3))
   old(c)
  NesMPU.step=step
  try:
   for age in range(36):
    keys=(1 if face==1 else 2)|(128 if age in[6,16]else 0)|(64 if age in[24,30]else 0)
    q.put(SavedJoypadBits=keys,SavedJoypad1Bits=keys,ArHostPad=keys,ArHostDue=int(age%3==0),NmiDisable=255,VRAM_Buffer1_Offset=0)
    captured.clear();A.call(q,'GameLoop');assert captured,('actual C2 source body publisher missing',mode,face,age)
    expected=captured[-1];current=q.get('CurrentCHRBank')+(q.get('X5ChrMode')&3)*256
    assert current==expected and q.get('SmChrBank')==expected&255,('later native player-bank overwrite',mode,face,age,expected,current,q.get('SmChrBank'))
    q.put(NmiDisable=0);q.m.writes=[];z=g.nmi(q);upper=0;hardware={}
    for dest,value in q.m.writes:
     if dest==0x5130:upper=value&3
     elif 0x5120<=dest<=0x512b:hardware[dest-0x5120]=value+256*upper
    assert hardware[0]==expected,('real NMI body commit',mode,face,age,expected,hardware)
    assert hardware[6]in[877,879]and hardware[7]in[878,880]
    q.put(NmiDisable=255);q.m.writes=[];g.nmi(q);assert not any(0x5120<=dest<=0x512b for dest,value in q.m.writes),('lag cannot publish incomplete CHR')
    rows.append([mode,face,age,expected,hardware[0],hardware[6],hardware[7]])
  finally:NesMPU.step=old
 return dict(complete_Main_normal_lag_commits=len(rows),actual_source_publisher='ArCachePublishFast genuine STA CurrentCHRBank,Y in selected rawC2',actual_store_prefix=list(prefix),all_later_native_PlayerBankReady_and_actual_NMI_assertions_retained=True,rows=rows)
def main():
 out=O/'complete-commit-controls-v3.json';assert not out.exists();b=A.scoped_load(O/'candidate.nes');d=dict(passed=False,native=False)
 try:d['checks']=run(b);d['passed']=True
 except Exception as e:d.update(failure=repr(e),traceback=traceback.format_exc())
 d['bindings']={str(p.resolve()):A.sha(p)for p in[Path(__file__),Path(V.__file__),R/'tools/audit/arthur_host_commit_controls_v2.py',O/'candidate.nes',O/'candidate.dbg',O/'host-regressions-v2.json']};out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items()if k!='bindings'and k!='checks'}));assert d['passed']
if __name__=='__main__':main()
