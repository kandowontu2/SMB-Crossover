"""Lossless source-pixel coalescing experiment. Never edits a frozen component."""
from pathlib import Path
import hashlib,itertools,json,random
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'build/arthur-palette-leaf-v1';BASE=ROOT/'build/arthur-source-v1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def canonical(values):
 variants=[]
 for v,h in itertools.product([False,True],repeat=2):
  data=values[::-1]if v else values
  if h:data=[row[::-1]for row in data]
  code=bytes(sum(((data[half*8+y][x]>>bit)&1)<<(7-x)for x in range(8))for half in range(2)for bit in range(2)for y in range(8))
  variants.append((code,(128 if v else 0)|(64 if h else 0)))
 return min(variants)
def raster(r,row,source,palette):
 pixels={}
 for i in reversed(range(len(r['parts']))):
  p=r['parts'][i]
  if p['tile']==255:continue
  t=source[p['tile']*16:p['tile']*16+16];pal=r['attribute_rows'][str(row)]['values'][i]
  for y,x in itertools.product(range(8),repeat=2):
   sx=7-x if p['attribute']&64 else x;sy=7-y if p['attribute']&128 else y
   val=(t[sy]>>(7-sx)&1)|((t[sy+8]>>(7-sx)&1)<<1)
   if val:pixels[p['x']+x,p['y']+y]=(palette[pal*4+val],p['attribute']&32)
 return pixels
def choices(pixels,mapping):
 # Independent source color roles may use different tile origins. Trim empty
 # tiles but retain the real16-row hardware span of every surviving sprite.
 role={xy:(mapping[color],priority)for xy,(color,priority)in pixels.items()if color in mapping}
 if not role:return [[]]
 candidates=[];minimum=999
 for ox,oy in itertools.product(range(8),range(16)):
  cells={((x-ox)//8*8+ox,(y-oy)//16*16+oy,pr)for(x,y),(_,pr)in role.items()}
  if len(cells)>minimum:continue
  parts=[]
  for left,top,priority in sorted(cells,key=lambda q:(q[1],q[0],q[2])):
   values=[[role.get((left+x,top+y),(0,0))[0]if role.get((left+x,top+y),(0,0))[1]==priority else 0 for x in range(8)]for y in range(16)]
   pattern,flip=canonical(values);parts.append(dict(x=left,y=top,attribute=flip|priority,pattern=pattern))
  if len(parts)<minimum:minimum=len(parts);candidates=[]
  candidates.append(parts)
 # Equivalent origin choices collapse to the same actual sprite construction.
 unique={tuple((p['x'],p['y'],p['attribute'],p['pattern'])for p in parts):parts for parts in candidates}
 return list(unique.values())
def reconstruct(parts,palettes):
 pixels={}
 for p in reversed(parts):
  t=p['pattern'];a=p['attribute'];pal=palettes[a&3]
  for y,x in itertools.product(range(16),range(8)):
   sx=7-x if a&64 else x;sy=15-y if a&128 else y;half=sy//8;row=sy%8
   val=(t[half*16+row]>>(7-sx)&1)|((t[half*16+row+8]>>(7-sx)&1)<<1)
   if val:pixels[p['x']+x,p['y']+y]=(pal[val],a&32)
 return pixels
def main():
 OUT.mkdir(exist_ok=True)
 d=json.loads((BASE/'art-source.json').read_text());source=(BASE/'arthur-original-sprites.chr').read_bytes();pal=d['palette']['hardware_indices'][16:32]
 records={r['pose']:r for r in d['records']};roles={p:8 for p in range(0x16)}|{p:2 for p in range(0x20,0x36)}|{0x16:2,0x18:1,0x1a:1}
 world_WB=[[15,12,24,54],[15,26,48,39],[15,22,48,39],[15,15,54,23]]
 world_UC=[[15,15,24,12],[15,28,54,23],[15,22,48,39],[15,0,48,16]]
 plans={'WB':[(0,{24:2,54:3}),(3,{15:1}),(2,{22:1,32:2})],
        'UC':[(0,{15:1,24:2}),(1,{54:2}),(2,{22:1,32:2})]}
 allcases=[];patterns=set();dataset=[]
 for name,plan in plans.items():
  palettes=world_WB if name=='WB'else world_UC
  for pose,row in roles.items():
   original=raster(records[pose],row,source,pal);options=[sorted(choices(original,mapping),key=lambda ps:(len({p['pattern']for p in ps}-patterns),sum(abs(p['x'])+abs(p['y'])for p in ps)))[:8]for _,mapping in plan]
   best=None
   for combined in itertools.product(*options):
    parts=[p|dict(attribute=p['attribute']|plan[i][0])for i,group in enumerate(combined)for p in group]
    new={p['pattern']for p in parts};peak=max(sum(p['y']<=y<p['y']+16 for p in parts)for y in range(-48,48))
    score=(len(new-patterns),peak,len(parts),sum(abs(p['x'])+abs(p['y'])for p in parts))
    if best is None or score<best[0]:best=score,parts,new,peak
   _,parts,new,peak=best;patterns|=new
   wanted={xy:(48 if col==32 else col,priority)for xy,(col,priority)in original.items()}
   assert reconstruct(parts,palettes)==wanted,(name,pose)
   dataset.append(dict(key=f'{name}:{pose:02X}',patterns=new))
   allcases.append(dict(plan=name,pose=pose,source_row=row,count=len(parts),max_body_scanline=peak,
    parts=[p|dict(pattern=p['pattern'].hex())for p in parts],pixel_priority_exact=True))
 groups=[dict(keys=[p['key']],patterns=p['patterns'])for p in dataset]
 while True:
  matches=[(len(groups[i]['patterns']&groups[j]['patterns']),-len(groups[i]['patterns']|groups[j]['patterns']),-i,-j)for i in range(len(groups))for j in range(i)if len(groups[i]['patterns']|groups[j]['patterns'])<=32]
  if not matches:break
  _,_,ni,nj=max(matches);i,j=-ni,-nj;groups[j]=dict(keys=groups[i]['keys']+groups[j]['keys'],patterns=groups[i]['patterns']|groups[j]['patterns']);groups.pop(i)
 result=dict(status='LOSSLESS_COALESCED_AREA_ROLE_COST_NOT_ADOPTED',body_cases=len(allcases),distinct_pairs=len(patterns),
  body_pages=len(groups),page_pair_counts=[len(g['patterns'])for g in groups],worst_body_scanline=max(c['max_body_scanline']for c in allcases),
  worst_body_sprites=max(c['count']for c in allcases),cases=allcases,
  limits='Only normal body+ladder/hurt/death poses. Blue weapons and boss hammer-white remap not yet included; worldP1skin donor disappears atBowser. White20→30 RGB alias documented.',
  bindings={str(p.resolve()):sha(p)for p in[Path(__file__),BASE/'art-source.json',BASE/'arthur-original-sprites.chr',ROOT/'build/arthur-host-prep-v5/handoff.json']})
 p=OUT/'coalesced-cost.json';p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k not in ['cases','bindings']}|dict(receipt_sha256=sha(p))))
if __name__=='__main__':main()
