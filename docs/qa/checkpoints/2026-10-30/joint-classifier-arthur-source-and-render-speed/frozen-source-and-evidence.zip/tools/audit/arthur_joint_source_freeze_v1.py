"""Freeze source producers, exact native deltas, and open joint hook contracts."""
from pathlib import Path
import difflib, hashlib, json, subprocess, sys
import arthur_joint_source_leaf_v1 as B
R=B.R;P=B.P;J=B.J;O=B.O;A=O/'arthur';N=O/'native-overrides'
sys.path[:0]=[str(R/'tools/audit')]
from check_tmnt_render_oa import address,location

def delta(name, old, new):
 B.save(N/name,new)
 B.save(N/(name+'.patch'),''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='fast-v6/src/'+name,tofile='native-overrides/'+name)))

def main():
 assert not(O/'handoff.json').exists()
 current=B.scoped_load(J/'candidate.nes');frozen=B.scoped_load(P/'candidate.nes')
 checks=[]
 for name,end in [('X5SetPhysicalChr','X5SetSpecialChr')]:
  size=address(frozen,end)-address(frozen,name)
  assert size==20
  x,y=location(frozen,name),location(current,name)
  assert frozen['raw'][x:x+size]==current['raw'][y:y+size]
  checks.append(dict(name=name,bytes=size,old_PC=address(frozen,name),joint_PC=address(current,name),exact=True))
 runtime=(A/'cache-runtime.s').read_text()
 assert ' sta SmChrBank\n ldy #0\n jsr ArCachePublishFast' in runtime
 assert (A/'cache-runtime.s').read_bytes()==(P/'arthur/cache-runtime.s').read_bytes()
 # This is a genuine source-only rebase of the qualified normal-NMI gateway.
 # Ownership/busy checks are deliberately NOT silently added to frozen workers.
 text=(J/'src/mmc5.s').read_text()
 needle='  sta CurrentBankC\n  sta MMC5_PRG_BANK_C\n  rts\n::DwResidentGraphicsBanks:'
 assert text.count(needle)==1
 delta('mmc5.s',text,text.replace(needle,'  sta CurrentBankC\n.export ArNmiPhysicalCWrite\n::ArNmiPhysicalCWrite:\n  sta MMC5_PRG_BANK_C\n  rts\n::DwResidentGraphicsBanks:',1))
 text=(J/'src/parodius_bells.s').read_text()
 old=''' jsr UpdateScreen
 lda SelectedCharacter
 cmp #18
 bne Samus
.if ::ENABLE_MMC5_EXPANDED && ::MAPPER_MMC5
 jmp PnHudCommitAfterVram
.else
 lda OperMode
.endif'''
 assert text.count(old)==1
 new=''' jsr UpdateScreen
 lda #>(ArPaletteScreenUpdate-1)
 pha
 lda #<(ArPaletteScreenUpdate-1)
 pha
 lda #.lobyte(.bank(ArPaletteScreenUpdate)|$80)
 jmp ArNmiPhysicalCWrite
 .assert *-PnPaletteScreenUpdate=14,error,"Actual C116 Vram/gateway prefix"
ArContinue:
'''
 changed='.import ArPaletteScreenUpdate,ArNmiPhysicalCWrite\n'+text.replace(old,new,1)
 needle=' sta PnBombPaletteShadow,x\n inx\n cpx #32\n bne Copy\n lda #0'
 assert changed.count(needle)==1
 changed=changed.replace(needle,' sta PnBombPaletteShadow,x\n .if !(::ENABLE_MMC5_EXPANDED && ::MAPPER_MMC5)\n inx\n .endif\n cpx #32\n bne Copy\nCaptureComplete:\n lda #0',1)
 changed+='\n.export ArPnAfterPalette\nArPnAfterPalette=PnPaletteScreenUpdate::Samus\n'
 delta('parodius_bells.s',text,changed)
 for name,old,new,count in [('parodius_hud_queue.s','PnPaletteScreenUpdate+13','PnPaletteScreenUpdate::ArContinue',2),('nmi_vram_fast.s','PnPaletteScreenUpdate::Copy+11','PnPaletteScreenUpdate::CaptureComplete',1)]:
  text=(J/'src'/name).read_text();assert text.count(old)==count
  delta(name,text,text.replace(old,new))
 # ld65 parses the real complete config with genuine unresolved imports. No
 # fake host address object is supplied and no cartridge claim is possible.
 cmd=[str(B.CC/'ld65.exe'),'-C',str(O/'arthur-on-fast-v6.cfg'),'-o',str(O/'unresolved-probe.nes')]+[str(A/(n+'.o'))for n in B.MODULES]
 p=subprocess.run(cmd,cwd=O,capture_output=True,text=True)
 assert p.returncode!=0 and 'Unresolved external' in p.stderr,p.stderr
 assert not any(z in p.stderr for z in ['Attribute expected','Unexpected token','Memory area overflow','Segment overflow'])
 B.save(O/'unresolved-link-probe.json',json.dumps(dict(expected_unresolved=True,actual_cart_link=False,command=cmd,rc=p.returncode,stdout=p.stdout,stderr=p.stderr),indent=2)+'\n')
 # Real linked code is needed to derive the cookie; the old16B signature is
 # intentionally retained in objects until the composer has its final layout.
 B.save(O/'derive_signature.py','''"""Read-only final-link cookie derivation; caller reassembles and relinks."""
from pathlib import Path
import hashlib,sys
R=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(R/'tools/audit')]
from link_pit_rygar_sophia_audit_cpu import scoped_load
from check_tmnt_render_oa import address,location
def derive(rom,canonical,expected):
 b=scoped_load(Path(rom));pos=location(b,'ArCacheEmit')
 size=address(b,'ArCacheExecEnd')-address(b,'ArCacheEmit')
 assert size==550 and len(Path(canonical).read_bytes())==2326 and len(Path(expected).read_bytes())==6130
 code=b['raw'][pos:pos+size]
 signature=bytes([167,32,0,1])+hashlib.sha256(Path(canonical).read_bytes()+code+Path(expected).read_bytes()).digest()[:12]
 return signature,code
if __name__=='__main__':
 sig,code=derive(*sys.argv[1:]);print('\\n'.join(f'AR_CACHE_SIG{i}=${v:02x}'for i,v in enumerate(sig)))
''')
 hooks=[
 dict(route='36 public services',producer='own-services.s:ArOwnServices',contract='Use agreed actual55B22/32 common transport; restore originalY/P, sourceA from SafecallA, X untouched. Service36 is CLC/RTS reject. All legacy144 row identities remain. Rare ingress requires C=1.',status='732B own-ROM fragment assembled; API2304/all64flags and220invalid CPU proven on isolated genuine workers. Joint dispatcher/Main pending.'),
 dict(route='Owner acquisition/retirement',producer='host-state.s:ArHostSelect + host-adapter.s:ArHostRelease',contract='Retire old32 while selected32 still owns overlay; constructor after genuine IcGlobalInit and all shared clears. Saved oldselector must reach ArHostSelect inA; CrossoverContinue distinguishes own continue. New owner must not consume old PN bytes as A7 readiness.',status='Requires genuine joint source hooks; obsolete standalone HuResolve is excluded.'),
 dict(route='Fresh service15',producer='host-adapter.s:ArHostConstruct -> genuine CmHostFresh -> ArHostFresh',contract='Actual NrFreshGameInit already does IcGlobalInit before service15. Preserve order and source cache invalidation. Fresh uses8 persistent profile bytes only.',status='Actual retained source present; final joint constructor order needs execution proof.'),
 dict(route='DrawAll',producer='host-adapter.s:ArHostDrawAll',contract='Selected32 route calls original SamusFreezeDrawAll once, then exact64-record priority permutation and original mode2 white expansion. All native enemies/items/blocks/floating numbers must remain; otherowners keep original typedroute and one bankframe.',status='Qualified09237 source/CPU/native retained. Joint HuDrawAll must select this genuine target.'),
 dict(route='Terrain/feet',producer='ArAfterTerrainDispatch and ArHostFoot via original ArDispatch/ArProbeDispatch',contract='Own32 only; original native source feet anchors, default collision and all otherowner target/AXYP/CVDI contracts remain. New actual callsite routing has to be measured and proven.',status='Workers included; standalone53B feetgate/extra common not copied.'),
 dict(route='Normal/lag NMI clock',producer='host-state.s:ArHostNmiClock (74B)',contract='GmFamilyNmiGate must accept only genuine outer normal/lag Audio returnPCs. Before first Ar5C read reject FamilyMainCommit=$5FFF bit0 busy. This byte is Main busy/completed count, NOT an owner marker. Clock pause/currentplayer/raw32 guards retained.',status='Clock source retained unchanged; required joint busy-before-Ar5C source gate remains open. No unqualified NMI worker added.'),
 dict(route='Palette afterUpdateScreen',producer='native-overrides/* + ArPaletteScreenUpdate (62B)',contract='Genuine C116UpdateScreen first, C117 gateway then A70 paletteworker; preserve hardware rawA/C and native PPUSCROLL/latch/area-backdrop. Must reject shared busy before first Ar5C read, prove own constructor/retirement seams.',status='Exact qualified source rebase exported. Do not install without new busy/ownership tests.'),
 dict(route='Body physical bank later native commit',producer='cache-runtime.s:STA SmChrBank + ArCachePublishFast',contract='Retain source SmChrBank bodypage before true CurrentCHRBank/X5ChrMode publication; genuine later PlayerBankReady must retain physical868..880 and normal/lag NMI publications. Global A275 setter remains exact20B.',status='Retained source and global byte identity proven; final actual Main/ISR commit suite pending.'),
 dict(route='RAM2 cache/cookie/header',producer='cache-loader.s + derive_signature.py',contract='Private32KBWRAM header; RAM0 unchanged. Cold forcedblank loader copies canonical2326 to6130cache and550executable bytes, clearsDFE0 first/publishes16B version last; mapraw2 not82, retain protection. Warm ensure validates everycookiebyte. No RAM1.',status='Retained source. Recompute signature from actual final linked C2code; reassemble host-render and relink until code stable. Joint crossowner retirement/load proof pending.')]
 B.save(O/'hook-inventory.json',json.dumps(hooks,indent=2)+'\n')
 B.save(O/'README.md', '''This is a source component, not a playable joint cartridge.

Use actual fast-v6/2ed6 as the host producer. Add the ten arthur/*.o objects;
each has genuine imported symbols. Include parent-exports.inc in the actual
host entrypoint, never an object full of numeric PC aliases. Apply config.patch
to fast-v6 before independently composing the FF carrier893..<901 split. The
config preserves Rogue B400, Gimmick B600, palette B800 and all old public PCs.
ArOwnServices loads physical70/DD00 but runs through A70/BD00; reject isBD6C.
Do not overlay own-services.bin from the isolated ABI fixture.

The native-overrides files are genuine minimal source rebases of the qualified
palette gateway. They need shared-busy/owner checks before adoption; no blanket
claim that frozen09237's selected-only NMI guards suffice for a joint owner.
The exact required lifecycle/feet/terrain/DrawAll/NMI boundaries and remaining
acceptance work are in hook-inventory.json. Do not clone the old1939B A79 union,
its old HuResolve, or its old selector/helper capsules. Use the shared55B actual
22/32 transport and separately qualified current classifier together.

Current fast-v6 source header has8KB WRAM. Compose the genuine NES2 source
directive nes2wram $8000 for the private32KB experiment, as the FF producer does.
Retain bank0/global writes/protection; no RAM1 grant or migration is needed.

After actual full source link, call derive_signature.py with actual ROM,
arthur/cache-input.bin, and expected-cache.bin. Write its16 constant lines into
the NEW candidate's own cache-signature.inc, reassemble host-render.o and relink.
Require actual final550B C2 code stable and cookie matches that final link. Then
regenerate the fixed125 CV3 mirror by genuine prepare_cv3_dmc_mirror, and bind
the final cart/DBG/LBL/source and actual wholeMain/normal+lagNMI/IRQ controls.

Qualified09237 black contours/native8-sprite visibility are retained, but its
native400-frame run worsened lag212->216; this is a performance HOLD. New
fast1638 renderer CPU work remains separate and is not silently adopted here.
No shared source, Downloads, frozen packet, header, native process, or lease was
changed by this export.
''')
 negatives=dict(preparation_only=[dict(error='Expected30 Arthur config lines; actual27segments plus1memory entry exposed bad regex. Correct extractor restricts to SEGMENTS section beforefreeze.',native_launched=False)],producer_note='No falsely successful cart link: unresolved probe is expected and retained.',global_publisher_comparison=checks)
 B.save(O/'preparation-and-native-producer-proof.json',json.dumps(negatives,indent=2)+'\n')
 paths=[p for p in O.rglob('*')if p.is_file()]+[Path(__file__),Path(B.__file__),P/'handoff.json',P/'native-handoff-v7.json',P/'candidate.nes',P/'candidate.dbg',J/'candidate.nes',J/'candidate.dbg',J/'private.cfg',J/'entrypoint.s',B.V/'API-controls-v5.json',B.V/'API-controls-v6.json',B.V/'API-vectors-v8.json',B.V/'vector-diagnosis-v7.json']
 for name in ['mmc5.s','parodius_bells.s','parodius_hud_queue.s','nmi_vram_fast.s']:paths.append(J/'src'/name)
 d=dict(status='FROZEN_GENUINE_ARTHUR_SOURCE_COMPONENT_JOINT_LINK_AND_HOOK_QUALIFICATION_PENDING',source_component_sha256=B.sha(O/'source-component.json'),parent_SHA256=B.sha(J/'candidate.nes'),native_qualified_Arthur_SHA256=B.sha(P/'candidate.nes'),module_count=10,private_retained_PRG=7389,new_own_services=732,new_RAM=0,RAM1=False,common_agreed_increment=55,remaining_common_after_transport=54,bindings={str(p.resolve()):B.sha(p)for p in paths})
 B.save(O/'handoff.json',json.dumps(d,indent=2)+'\n')
 print(json.dumps(dict(handoff=B.sha(O/'handoff.json'),bindings=len(d['bindings']),status=d['status'])))

if __name__=='__main__':main()
