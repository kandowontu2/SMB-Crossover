"""Actual cache successor inherited mechanics/foreign/commit regressions."""
from pathlib import Path
import argparse,importlib.util,json,traceback
import arthur_cache_host_controls_v1 as H
A=H.A;R=H.R;O=H.O
import arthur_host_commit_controls_v2 as K
original_setup=A.setup
def setup(b,ch=32):
 q=original_setup(b,ch)
 if ch==32:
  q.put(OperMode=1,DisableScreenFlag=1,Mirror_PPUMASK=0,Mirror_PPUCTRL=160,NmiDisable=255)
  c,_,_=A.owned(q,'ArCacheEnsure');assert c.p&1
 return q
A.setup=setup

def cookie_execution_negative(b):
 old=A.scoped_load(O/'negative-incomplete-draw-cookie.nes');rows=[]
 for v,negative in[(old,True),(b,False)]:
  q=setup(v);q.put(DisableScreenFlag=0,Mirror_PPUMASK=30,CurrentOAMOffset=0)
  q.m.ram[2][0x1fe4]^=1
  _,tr,_=A.owned(q,'ArHostDraw');entered=(2,A.address(v,'ArCacheEmit'))in tr
  assert entered==negative,('full fingerprint must gate actual C2 execution',negative,entered)
  rows.append(dict(ROM_sha256=__import__('hashlib').sha256(v['raw']).hexdigest(),corrupt_fingerprint_still_executed=entered,expected_negative=negative))
 return dict(rows=rows,first_incomplete_draw_guard_negative_retained=True)

def raw_isr(b):
 spec=importlib.util.spec_from_file_location('cache_real_nmi',R/'build/character-host-union-v5/gm_verify_nmi.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
 rows=[]
 # Actual full Main interrupts when selected C2 code is running, and both
 # actual intermediate mapper publishers; no RAM instruction preload.
 for n,bank in [('ArCacheEmit',2),('ArCacheBodyPublish',26),('ArHostPublish',63),('X5SetPhysicalChr',62)]:
  q=setup(b);q.put(DisableScreenFlag=1,ArHostDue=1,ArHostPad=129,NmiDisable=255,VRAM_Buffer1_Offset=0,VRAM_Buffer_AddrCtrl=0)
  before=bytes(q.m.ram[2]);_,z=g.scheduler.invoke(q.m,'GameLoop',sp=240,cut=(A.address(b,n),bank,'NMI'))
  assert bytes(q.m.ram[2])==before
  assert q.m.rawtags[1]==q.get('CurrentBank')and q.m.rawtags[2]==q.get('CurrentBankC')
  rows.append(dict(entry=n,**g.scheduler.summary(z),ISR=g.scheduler.summary(z['interrupt'])))
 return dict(raw_RAM2_actual_Main_NMI_seams=rows,cache_and_code_immutable=True,scope='Actual vectors with all33SMC/live stack/AXYP/SP/live native ZP and raw mapper restoration. No hardware deadline claim.')

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);ap.add_argument('--only',default='cookie,selectors,mainloop,lifecycle,pickups,powerup_chooser,portrait,presentation,interrupts,raw_isr,foreign_nmi,cold_packets,foreign,commit');a=ap.parse_args();assert not a.output.exists()
 b=A.scoped_load(O/'candidate.nes');d=dict(passed=False,native_run=False,checks={})
 funcs=dict(cookie=cookie_execution_negative,raw_isr=raw_isr,commit=lambda b:K.run(b,False))
 try:
  for name in a.only.split(','):d['checks'][name]=funcs.get(name,getattr(A,name,None))(b)
  d['passed']=True
 except Exception as e:d.update(failure=repr(e),traceback=traceback.format_exc())
 d['bindings']={str(p.resolve()):A.sha(p)for p in[Path(__file__),Path(H.__file__),Path(A.__file__),O/'candidate.nes',O/'candidate.dbg']}
 a.output.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(passed=d['passed'],checks=list(d['checks']),failure=d.get('failure'))));assert d['passed']
if __name__=='__main__':main()
