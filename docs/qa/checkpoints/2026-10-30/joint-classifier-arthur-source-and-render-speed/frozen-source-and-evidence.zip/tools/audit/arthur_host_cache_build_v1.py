"""Private source-linked32KB WRAM cache successor of frozen Arthur4fb11bca."""
from pathlib import Path
import hashlib,json,shutil,sys
import arthur_integrate_host_v1 as B
R=Path(__file__).resolve().parents[2];OLD=R/'build/arthur-host-integration-v2';O=R/'build/arthur-host-cache-v1';A=O/'arthur';D=O/'dense';T=O/'frozen-inputs'
CACHE=R/'build/arthur-draw-cache-v2'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def prepare():
 assert sha(OLD/'candidate.nes')=='4fb11bca5ac7abfeffef461fd15de73d32b574bc3c60ae41573c45c15ce1a2b2'
 assert sha(R/'docs/qa/checkpoints/2026-10-30/mmc5-overlay-private-allocation/root-review-and-reservations.json')=='71e6d9bb97b6dea45da10c614589b3d0a22c5b0f87a294384edf8037c7076b96'
 assert not O.exists();O.mkdir()
 for folder in['frozen-inputs','src','dense','arthur']:shutil.copytree(OLD/folder,O/folder)
 for p in OLD.iterdir():
  if not p.is_file()or p.name.startswith(('candidate.','actual-','source-ready-','source-byte-','native-','arthur-private-source','arthur-source-closure','arthur-handoff')):continue
  if p.suffix in['.s','.inc','.cfg','.chr','.nam','.rle','.o','.d']or p.name in['parent-commands.json','parent-reproduction.json','dense-parent-reproduction.json']:shutil.copy2(p,O/p.name)
 for p in O.rglob('*'):
  if p.is_file()and p.suffix in['.s','.inc','.cfg','.d','.json']:
   s=p.read_text()
   for old,new in[(str(OLD),str(O)),(OLD.as_posix(),O.as_posix()),(str(OLD).replace('\\','\\\\'),str(O).replace('\\','\\\\'))]:s=s.replace(old,new)
   p.write_text(s,newline='\n')
 entry=(O/'entrypoint.s').read_text();assert entry.count('nes2wram $2000')==1;B.save(O/'entrypoint.s',entry.replace('nes2wram $2000','nes2wram $8000'))
 (A/'cache-input.bin').write_bytes((CACHE/'canonical-input.bin').read_bytes())
 # New actual implementation is deliberately kept separate from frozen prep.
 for name in['cache-wrapper.s','cache-runtime.s','cache-loader.s']:
  B.save(A/name,(R/'tools/audit'/('arthur_'+name.replace('-','_'))).read_text())
 B.save(A/'cache-signature.inc','\n'.join(f'AR_CACHE_SIG{i}=${v:02x}'for i,v in enumerate([167,32,0,1]+[0]*12))+'\n')
 # Exact retained world-mask lookup; body records/layouts now live inCHR.
 old=(A/'art.s').read_text();white=old[old.index('ArPalWhiteLookup:'):old.index('.segment "ARTHUR_ART_TAIL"',old.index('ArPalWhiteLookup:'))]
 B.save(A/'art.s','''.segment "ARTHUR_ART_SMALL"
.export ArPalPoseIndex,ArPalWhiteLookup,ArPalArtStart,ArPalArtEnd
ArPalArtStart:
ArPalPoseIndex:
'''+white+'ArPalArtEnd:\n.segment "ARTHUR_CACHE_INPUT"\n.incbin "cache-input.bin"\n')
 B.save(A/'host-render.s','.include "cache-wrapper.s"\n.include "cache-loader.s"\n.include "cache-runtime.s"\n')
 adapter=(A/'host-adapter.s').read_text();adapter='.import ArCacheEnsure,ArCacheRetire\n'+adapter
 adapter=adapter.replace(' jsr ArHostEnsure\n jsr ArHostStatusSync',' jsr ArHostEnsure\n jsr ArCacheEnsure\n jsr ArHostStatusSync',1)
 adapter=adapter.replace('.proc ArHostPortrait\n jsr ArHostEnsure\n','.proc ArHostPortrait\n jsr ArHostEnsure\n jsr ArCacheEnsure\n bcc Unavailable\n',1)
 adapter=adapter.replace(' jmp ArHostDraw\n.endproc',' jmp ArHostDraw\nUnavailable:rts\n.endproc',1)
 adapter=adapter.replace(' ArFar FmNativePrepare\n jmp ArHostEnsure',' ArFar FmNativePrepare\n jsr ArCacheEnsure\n jmp ArHostEnsure',1)
 adapter=adapter.replace('.proc ArHostStatusSync','.segment "ARTHUR_DRAW"\n.proc ArHostStatusSync',1).replace('.proc ArHostName','.segment "ARTHUR_ADAPTER_COLD"\n.proc ArHostName',1)
 adapter=adapter.replace(' bne Done\n ArFar FmNativePrepare\n lda AreaType',' bne Done\n jsr ArCacheRetire\n ArFar FmNativePrepare\n lda AreaType',1)
 B.save(A/'host-adapter.s',adapter)
 state=(A/'host-state.s').read_text();state='.import ArCacheRetire\n'+state
 state=state.replace('::ArHostFreshOwned:\n lda #0','::ArHostFreshOwned:\n jsr ArCacheRetire\n lda #0',1);B.save(A/'host-state.s',state)

def config():
 baseconfig();s=(O/'arthur.cfg').read_text()
 s=s.replace('ARTHUR_CHR_MEM:start=$d9000,size=$4000','ARTHUR_CHR_MEM:start=$d9000,size=$3400')
 s=s.replace('    RECLAIMED_PARODIUS_CHR_MEM:start=$dd000','    ARTHUR_CACHE_STORAGE:start=$dc400,size=$c00,type=ro,fill=yes,file=%O,fillval=$00;\n    RECLAIMED_PARODIUS_CHR_MEM:start=$dd000',1)
 s=s.replace('MEMORY {','MEMORY {\n ARTHUR_CACHE_RUN:start=$d800,size=$7e0,type=rw,file="";\n',1)
 s=s.replace(' ARTHUR_CHR:load=ARTHUR_CHR_MEM,type=ro;',' ARTHUR_CHR:load=ARTHUR_CHR_MEM,type=ro;\n ARTHUR_CACHE_INPUT:load=ARTHUR_CACHE_STORAGE,type=ro;\n ARTHUR_CACHE_EXEC:load=ARTHUR_CACHE_STORAGE,run=ARTHUR_CACHE_RUN,type=ro,define=yes;')
 B.save(O/'arthur.cfg',s)

def main():
 if '--finalize' in sys.argv:
  import arthur_actual_host_controls_v1 as C
  from arthur_draw_cache_controls_v1 import expected_cache
  b=C.scoped_load(O/'candidate.nes');start=C.location(b,'ArCacheEmit');size=C.address(b,'ArCacheExecEnd')-C.address(b,'ArCacheEmit')
  code=b['raw'][start:start+size];payload=(A/'cache-input.bin').read_bytes();expected=expected_cache(C.scoped_load(OLD/'candidate.nes'))
  fingerprint=hashlib.sha256(payload+code+expected).digest()[:12]
  B.save(A/'cache-signature.inc','\n'.join(f'AR_CACHE_SIG{i}=${v:02x}'for i,v in enumerate(bytes([167,32,0,1])+fingerprint))+'\n')
  proof=json.loads((O/'arthur-build-proof.json').read_text());cmds=proof['commands'];logs=[]
  for cmd in [next(x['command'] for x in cmds if any(str(y).endswith('host-render.s')for y in x['command'])),cmds[-1]['command']]:
   cp=B.subprocess.run(cmd,cwd=T,capture_output=True,text=True);logs.append(dict(command=cmd,rc=cp.returncode,stdout=cp.stdout,stderr=cp.stderr));assert cp.returncode==0,cp.stderr
  sys.path.insert(0,str(R/'tools'));from prepare_cv3_dmc_mirror import prepare as mirror
  mirror(R,O/'candidate.nes');new=C.scoped_load(O/'candidate.nes');newcode=new['raw'][C.location(new,'ArCacheEmit'):C.location(new,'ArCacheEmit')+size]
  if newcode!=code:
   # Absolute calls in the relocated emitter may move after wrapper edits.
   # Rebind the fingerprint to the actual final link, then relink once more.
   code=newcode;fingerprint=hashlib.sha256(payload+code+expected).digest()[:12]
   B.save(A/'cache-signature.inc','\n'.join(f'AR_CACHE_SIG{i}=${v:02x}'for i,v in enumerate(bytes([167,32,0,1])+fingerprint))+'\n')
   for cmd in [logs[0]['command'],logs[1]['command']]:
    cp=B.subprocess.run(cmd,cwd=T,capture_output=True,text=True);logs.append(dict(command=cmd,rc=cp.returncode,stdout=cp.stdout,stderr=cp.stderr));assert cp.returncode==0,cp.stderr
   mirror(R,O/'candidate.nes');new=C.scoped_load(O/'candidate.nes')
  assert new['raw'][C.location(new,'ArCacheEmit'):C.location(new,'ArCacheEmit')+size]==code
  B.save(O/'cache-final-link-proof.json',json.dumps(dict(candidate_sha256=sha(O/'candidate.nes'),fingerprint=fingerprint.hex(),signature=(bytes([167,32,0,1])+fingerprint).hex(),canonical_bytes=len(payload),emitter_bytes=size,sequential_cache_bytes=len(expected),commands=logs),indent=2)+'\n')
  print(sha(O/'candidate.nes'));return
 if '--rebuild'in sys.argv:
  for name in['cache-wrapper.s','cache-runtime.s','cache-loader.s']:B.save(A/name,(R/'tools/audit'/('arthur_'+name.replace('-','_'))).read_text())
 else:prepare()
 entry=(O/'entrypoint.s').read_text()
 if '.export Mirror_PPUMASK,NmiDisable'not in entry:B.save(O/'entrypoint.s',entry+'\n.export Mirror_PPUMASK,NmiDisable\n')
 B.O=O;B.A=A;B.D=D;B.T=T
 global baseconfig;baseconfig=B.physical_config;B.physical_config=config;B.build()
if __name__=='__main__':main()
