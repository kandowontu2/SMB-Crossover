"""Private source successor: exact disjoint body/prefix swap fast path."""
from pathlib import Path
import difflib,json,shutil,sys
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import arthur_integrate_host_v1 as B
import arthur_host_cache_build_v1 as W
P=R/'build/arthur-body-fair-v3';O=R/'build/arthur-body-fair-fast-v4'
FAST=''' ; Physical body/prefix sets are disjoint when R>=B and R+B<=256.
 ; Swap each full record directly. This is the exact original permutation,
 ; with one transient stack byte instead of snapshotting the whole body.
 lda ArLayoutPtr
 cmp ArDrawPage
 bcc GeneralBodyOrder
 clc
 adc ArDrawPage
 bcc DisjointBodyOrder
 bne GeneralBodyOrder         ; carry+zero means exactly256, still disjoint
DisjointBodyOrder:
 lda ArDrawPage
 lsr
 lsr
 sta ArDrawCount
 ldx ArLayoutPtr
 ldy #0
SwapBodyRecord:
 .repeat 4,I
 lda $0200+I,x
 pha
 lda $0200+I,y
 sta $0200+I,x
 pla
 sta $0200+I,y
 .endrepeat
 txa
 clc
 adc #4
 tax
 tya
 clc
 adc #4
 tay
 dec ArDrawCount
 bne SwapBodyRecord
 jmp PriorityReturn
GeneralBodyOrder:
'''
def main():
 assert B.sha(P/'candidate.nes')=='09237b6f1b88b50d9c3ba054092af36591daa435d43eb83bf21ed08ca856d671'
 assert not O.exists();O.mkdir()
 for folder in ['frozen-inputs','src','dense','arthur']:shutil.copytree(P/folder,O/folder)
 for p in P.iterdir():
  if p.is_file()and(p.suffix in ['.s','.inc','.cfg','.chr','.nam','.rle','.o','.d']or p.name in ['parent-commands.json','parent-reproduction.json','dense-parent-reproduction.json']):shutil.copy2(p,O/p.name)
 for p in O.rglob('*'):
  if p.is_file()and p.suffix in ['.s','.inc','.cfg','.d','.json']:
   s=p.read_text()
   for old,new in [(str(P),str(O)),(P.as_posix(),O.as_posix()),(str(P).replace('\\','\\\\'),str(O).replace('\\','\\\\'))]:s=s.replace(old,new)
   p.write_text(s,newline='\n')
 p=O/'arthur/cache-runtime.s';s=p.read_text();anchor=' lda ArLayoutPtr\n and #3\n jne PriorityReturn\n'
 assert s.count(anchor)==1;s=s.replace(anchor,anchor+FAST);p.write_text(s,newline='\n')
 for p in O.rglob('*'):assert p.resolve().is_relative_to(O.resolve())
 B.O=O;B.A=O/'arthur';B.D=O/'dense';B.T=O/'frozen-inputs';B.physical_config=lambda:None;B.build()
 W.O=O;W.A=O/'arthur';W.D=O/'dense';W.T=O/'frozen-inputs';saved=sys.argv;sys.argv=[__file__,'--finalize']
 try:W.main()
 finally:sys.argv=saved
 changes=[]
 for n in ['arthur/cache-runtime.s','arthur/cache-signature.inc']:
  changes+=difflib.unified_diff((P/n).read_text().splitlines(True),(O/n).read_text().splitlines(True),fromfile='09237/'+n,tofile='fair-fast-v4/'+n)
 (O/'source.patch').write_text(''.join(changes),newline='\n')
 proof=json.loads((O/'cache-final-link-proof.json').read_text())
 (O/'build-parent.json').write_text(json.dumps(dict(parent=B.sha(P/'candidate.nes'),source_only=True,new_leases=False,fast_path='Exactdisjoint record swaps; overlap/wrap retains originalsnapshot algorithm. All64permutation/first8/tailfairness/CPUABI not yet qualified.',C2_runtime=proof['emitter_bytes'],carrier_bytes=2326+proof['emitter_bytes'],bindings={str(Path(__file__).resolve()):B.sha(__file__),str((P/'handoff.json').resolve()):B.sha(P/'handoff.json'),str((P/'native-handoff-v7.json').resolve()):B.sha(P/'native-handoff-v7.json')}),indent=2)+'\n')
 print('PRIVATE_FAIR_FAST_SOURCE_BUILT',B.sha(O/'candidate.nes'),proof['emitter_bytes'])
if __name__=='__main__':main()
