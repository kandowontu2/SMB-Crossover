"""Exact fast/general permutation and complete Main differential against09237."""
from pathlib import Path
import json,traceback
import arthur_body_fair_main_v5 as M
A=M.A;F=M.F;R=M.R;O=R/'build/arthur-body-fair-fast-v4';P=M.O
def main():
 out=O/'CPU-controls-v4.json';assert not out.exists();b=A.scoped_load(O/'candidate.nes');old=A.scoped_load(P/'candidate.nes')
 F.O=O;d=dict(passed=False,native=False,checks={},failures={})
 def strict_snapshot(q,white_scratch=False):
  fields=[i for i in list(range(0x2000))+list(range(0x5c00,0x8000))if not 0x100<=i<0x200]
  return bytes(q.m[i]for i in fields),tuple(q.m.rawtags),bytes(q.m[0x100:0x17b])
 M.snapshot=strict_snapshot
 for name,fn in [('api',M.api),('permutation',F.permutation),('source_body',F.source_body),('fairness',F.fairness),('complete_Main',lambda b:M.own_Main(old,b)),('foreign',lambda b:M.foreign(old,b))]:
  try:d['checks'][name]=fn(b);print('PASS',name,flush=True)
  except Exception as e:d['failures'][name]=dict(error=repr(e),traceback=traceback.format_exc())
 d['passed']=not d['failures'];paths=[Path(__file__),Path(M.__file__),Path(F.__file__),O/'candidate.nes',O/'candidate.dbg',O/'cache-final-link-proof.json',O/'source.patch',P/'candidate.nes',P/'candidate.dbg']
 d['bindings']={str(p.resolve()):A.sha(p)for p in paths};out.write_text(json.dumps(d,indent=2)+'\n')
 print(json.dumps(dict(passed=d['passed'],failures=d['failures'])));assert d['passed']
if __name__=='__main__':main()
