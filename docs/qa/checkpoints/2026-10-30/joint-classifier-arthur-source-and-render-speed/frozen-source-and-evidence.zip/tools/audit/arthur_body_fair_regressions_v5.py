"""Rebind genuine loader, source-pixel and complete Main/NMI controls to fair3."""
from pathlib import Path
import json,traceback,sys
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import arthur_body_fair_main_v5 as F
import arthur_render_fast_commit_v1 as K
V=K.V;A=F.A;H=V.H;O=F.O

def main():
    out=O/'regressions-v5.json';assert not out.exists();b=A.scoped_load(O/'candidate.nes')
    H.O=O;d=dict(passed=False,native=False,checks={},failures={})
    def cold(fn):
        original=A.setup;A.setup=V.G.original_setup
        try:return fn(b)
        finally:A.setup=original
    for name,fn in [('loader',lambda:cold(H.load_controls)),('pixels',lambda:cold(A.render_pixels)),('complete_Main_commit',lambda:K.run(b))]:
        try:d['checks'][name]=fn()
        except Exception as e:d['failures'][name]=dict(error=repr(e),traceback=traceback.format_exc())
    d['passed']=not d['failures']
    paths=[Path(__file__),Path(F.__file__),Path(K.__file__),Path(V.__file__),Path(V.G.__file__),Path(H.__file__),Path(A.__file__),O/'candidate.nes',O/'candidate.dbg',O/'cache-final-link-proof.json']
    d['bindings']={str(p.resolve()):A.sha(p)for p in paths};out.write_text(json.dumps(d,indent=2)+'\n')
    print(json.dumps(dict(passed=d['passed'],checks=list(d['checks']),failures=d['failures'])));assert d['passed']
if __name__=='__main__':main()
