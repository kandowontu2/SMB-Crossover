"""Private source successor: complete Arthur prefix, retained fair tail phase.

No new PRG/RAM/ZP/CHR leases, no shared source, no native emulator launch.
"""
from pathlib import Path
import difflib,json,shutil,sys
R=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import arthur_integrate_host_v1 as B
import arthur_host_cache_build_v1 as W
P=R/'build/arthur-host-render-fast-v1';O=R/'build/arthur-body-fair-v1'

PRIORITY='''
; Verified C2 code, reached after actual DrawAll and before mode2 expansion.
; Save the complete <=11-record body on the genuine CPU stack. Only the
; nonbody records displaced by its protected prefix move into vacated body
; positions. All64 records remain a permutation; global phase is unchanged.
; Render-only aliases: Page=body bytecount, Header=old physical body origin.
; No ZP, RAM allocation, mapper write or cache/code write. Maximum44stackB.
.export ArCacheBodyPriority
ArCacheBodyPriority:
 lda ArDrawPage
 jeq PriorityReturn
 cmp #45
 jcs PriorityReturn
 and #3
 jne PriorityReturn
 lda ArDrawHeader
 and #3
 jne PriorityReturn
 lda ArDrawPage
 lsr
 lsr
 sta ArDrawCount
 ldx ArDrawHeader
PushBody:
 .repeat 4,I
 lda $0200+I,x
 pha
 .endrepeat
 txa
 clc
 adc #4
 tax
 dec ArDrawCount
 bne PushBody
 lda ArDrawPage
 lsr
 lsr
 sta ArDrawCount
 ldx ArDrawHeader
 ldy #0
MoveBodyHole:
 cpx ArDrawPage
 bcc NextBodyHole
FindDisplaced:
 tya
 sec
 sbc ArDrawHeader
 cmp ArDrawPage
 bcs CopyDisplaced
 iny
 iny
 iny
 iny
 bne FindDisplaced
CopyDisplaced:
 .repeat 4,I
 lda $0200+I,y
 sta $0200+I,x
 .endrepeat
 iny
 iny
 iny
 iny
NextBodyHole:
 txa
 clc
 adc #4
 tax
 dec ArDrawCount
 bne MoveBodyHole
 ldx ArDrawPage
PopBody:
 .repeat 4,I
 pla
 dex
 sta $0200,x
 .endrepeat
 txa
 bne PopBody
PriorityReturn:
 rts
'''

def replace(path,old,new):
    s=path.read_text();assert s.count(old)==1,(path,old);path.write_text(s.replace(old,new),newline='\n')

def prepare():
    assert not O.exists()
    assert B.sha(P/'candidate.nes')=='2846e48de17f087e3af5c9b17777c2cd0cdbe2d66f3f79a3a6878ed61b6ee724'
    for n in ['source-proof-v1.json','native-handoff-v1.json']:
        d=json.loads((P/n).read_text())
        for p,h in d['bindings'].items():assert B.sha(p)==h,p
    O.mkdir()
    for folder in ['frozen-inputs','src','dense','arthur']:shutil.copytree(P/folder,O/folder)
    for p in P.iterdir():
        if p.is_file()and(p.suffix in ['.s','.inc','.cfg','.chr','.nam','.rle','.o','.d']or p.name in ['parent-commands.json','parent-reproduction.json','dense-parent-reproduction.json']):shutil.copy2(p,O/p.name)
    for p in O.rglob('*'):
        if p.is_file()and p.suffix in ['.s','.inc','.cfg','.d','.json']:
            s=p.read_text()
            for old,new in [(str(P),str(O)),(P.as_posix(),O.as_posix()),(str(P).replace('\\','\\\\'),str(O).replace('\\','\\\\'))]:s=s.replace(old,new)
            p.write_text(s,newline='\n')
    p=O/'arthur/cache-wrapper.s'
    p.write_text('.import ArDrawPage\n'+p.read_text(),newline='\n')
    replace(p,' jne Return\n lda R0\n',' jne Return\n lda #0\n sta ArDrawPage             ; no stale body metadata if cache is unavailable\n lda R0\n')
    p.write_text(p.read_text()+'''
.segment "ARTHUR_DRAW"
.export ArCacheBodyOrder
.proc ArCacheBodyOrder
 lda CurrentBankC
 pha
 lda #2
 sta CurrentBankC
 sta $5116
 jsr ArCacheBodyPriority
 pla
 sta CurrentBankC
 sta $5116
 rts
.endproc
''',newline='\n')
    p=O/'arthur/cache-runtime.s'
    replace(p,' sta ArDrawCount\n iny\n',''' sta ArDrawCount
 lda ArDrawIndex
 bne BodyOriginReady
 lda CurrentOAMOffset
 sta ArDrawPage             ; temporary logical start, consumed at EmitFinish
 lda GuestOamRotationActive
 beq UnrotatedBodyOrigin
 lda CurrentOAMOffset
 clc
 adc RgOamRotation
 jmp SaveBodyOrigin
UnrotatedBodyOrigin:
 lda CurrentOAMOffset
SaveBodyOrigin:
 sta ArDrawHeader
BodyOriginReady:
 iny
''')
    replace(p,' dec ArDrawCount\n bne FastPart\n rts\n',' dec ArDrawCount\n bne FastPart\n jmp EmitFinish\n')
    replace(p,'EmitDone:rts\n','''EmitFinish:
 lda ArDrawIndex
 bne EmitDone
 lda CurrentOAMOffset
 sec
 sbc ArDrawPage
 sta ArDrawPage             ; exact emitted body bytes, including clipping
EmitDone:rts
''')
    replace(p,'ArCacheExecEnd:\n.assert',PRIORITY+'\nArCacheExecEnd:\n.assert')
    p=O/'arthur/host-adapter.s';p.write_text('.import ArCacheBodyOrder,ArDrawPage\n'+p.read_text(),newline='\n')
    marker=''' lda ArHostOldPage
 cmp #2
 bne Done
 lda CurrentBankC
 pha
 lda #$c6
'''
    replacement=''' lda ArDrawPage
 beq BodyPriorityReady
 jsr ArCacheBodyOrder
BodyPriorityReady:
 lda ArHostOldPage
 cmp #2
 bne Done
 lda CurrentBankC
 pha
 lda #$c6
'''
    replace(p,marker,replacement)
    diffs=[]
    for n in ['arthur/cache-wrapper.s','arthur/cache-runtime.s','arthur/host-adapter.s']:
        diffs += difflib.unified_diff((P/n).read_text().splitlines(True),(O/n).read_text().splitlines(True),fromfile='2846/'+n,tofile='fair-v1/'+n)
    (O/'source.patch').write_text(''.join(diffs),newline='\n')
    (O/'ownership-plan.json').write_text(json.dumps(dict(parent_sha256=B.sha(P/'candidate.nes'),
        expected_A26main=2261,original_main_limit=2262,expected_A26tail=712,original_tail_limit=718,
        C2_max_code=746,source_body_art_unchanged=True,new_RAM_ZP=0,maximum_body_stack_bytes=44,
        phases='Actual body origin/count stored after cookie-verified body emit. Consume after native DrawAll and before original mode2 stable white expansion.',
        semantics='Required source body receives ordered physical prefix; tail records remain a permutation and original global rotation phase is untouched. No record can be written outside0200..<0300.'),indent=2)+'\n')

def main():
    if '--resume'not in sys.argv:prepare()
    # Every generated/import/dependency destination is inside this new packet.
    # Unchanged inherited predecessor dependencies remain read-only.
    for p in O.rglob('*'):
        assert p.resolve().is_relative_to(O.resolve()),p
    for n in ['parent-commands.json','dense-parent-reproduction.json']:
        s=(O/n).read_text();assert str(P).replace('\\','\\\\')not in s and P.as_posix()not in s,n
    B.O=O;B.A=O/'arthur';B.D=O/'dense';B.T=O/'frozen-inputs';B.physical_config=lambda:None
    B.build()
    W.O=O;W.A=O/'arthur';W.D=O/'dense';W.T=O/'frozen-inputs'
    saved=sys.argv;sys.argv=[str(Path(__file__)),'--finalize']
    try:W.main()
    finally:sys.argv=saved
    print('PRIVATE_FAIR_SOURCE_READY',B.sha(O/'candidate.nes'))
if __name__=='__main__':main()
