"""Prove private probe source diff, unchanged workers and existing leases."""
from pathlib import Path
import hashlib,json
import arthur_probe_fast_controls_v1 as C
A=C.A;R=C.R;O=C.O;OLD=C.OLD
def word(raw,i):return raw[i]+256*raw[i+1]
def main():
 out=O/'source-diff-lease-proof-v1.json';assert not out.exists();old=A.scoped_load(OLD/'candidate.nes');new=A.scoped_load(O/'candidate.nes');ra,rb=old['raw'],new['raw']
 assert ra[:16]==rb[:16]and ra[1048592:]==rb[1048592:],'Header/all1MiBCHR must remain exact'
 segments=lambda b:{g['name'].strip('"'):g for g in b['segs'].values()}
 sa,sb=segments(old),segments(new);unchanged=[]
 for n,g in sa.items():
  if not n.startswith('ARTHUR_')or n=='ARTHUR_DRAW'or'ooffs'not in g:continue
  ng=sb[n];assert int(g['size'],0)==int(ng['size'],0)
  a=int(g['ooffs'],0);b=int(ng['ooffs'],0);size=int(g['size'],0);assert ra[a:a+size]==rb[b:b+size],('Original source component segment changed',n)
  unchanged.append(dict(segment=n,bytes=size,sha256=hashlib.sha256(ra[a:a+size]).hexdigest()))
 g=sa['ARTHUR_DRAW'];p=int(g['ooffs'],0);size=int(g['size'],0);assert ra[p:p+size]==rb[p:p+size]
 assert int(sb['ARTHUR_DRAW']['size'],0)-size==39
 assert A.address(new,'ArProbeDispatch')==int(sb['ARTHUR_DRAW']['start'],0)+size
 prefix=A.location(old,'HuCommon')-A.location(old,'HuStart');assert prefix==608
 assert ra[A.location(old,'HuStart'):A.location(old,'HuStart')+prefix]==rb[A.location(new,'HuStart'):A.location(new,'HuStart')+prefix]
 ownranges=[(16+26*8192+0x132a,16+26*8192+0x1c00),(16+79*8192+0x15e0,16+79*8192+0x2000)]
 outside={i for i,(x,y)in enumerate(zip(ra[:1048592],rb[:1048592]))if x!=y and not any(lo<=i<hi for lo,hi in ownranges)}
 relocated=[];covered=set();arg=A.address(old,'SafecallA_SMC')+1;target=A.address(old,'FarcallJmpTarget_SMC')+1;far=A.address(old,'FarCallCommon')
 moved={}
 for n,s in old['syms'].items():
  if '::'in n or n not in new['syms']or'seg'not in s:continue
  try:ao=A.point(old,n);bn=A.point(new,n)
  except(KeyError,ValueError):continue
  if ao!=bn:moved.setdefault((ao,bn),[]).append(n)
 for p in range(16,1048592-18):
  if ra[p]!=141 or word(ra,p+1)!=arg or ra[p+3]!=169 or ra[p+5]!=141 or word(ra,p+6)!=target or ra[p+8]!=169 or ra[p+10]!=141 or word(ra,p+11)!=target+1 or ra[p+13]!=169 or ra[p+15]not in[32,76]or word(ra,p+16)!=far:continue
  if not outside.intersection(range(p,p+18)):continue
  changed=[i for i in range(p,p+18)if ra[i]!=rb[i]];assert set(changed)<=set([p+4,p+9]),('Farcall changed outside actual target operand',p,changed)
  before=(ra[p+14]&127,ra[p+4]+256*ra[p+9]);after=(rb[p+14]&127,rb[p+4]+256*rb[p+9]);names=moved.get((before,after));assert names,('Unbound genuine target relocation',p,before,after)
  relocated.append(dict(file_offset=p,caller_physical_bank=(p-16)//8192,before=before,after=after,genuine_same_source_symbols=names,changed_offsets=changed));covered.update(changed)
 assert covered==outside,('Unclassified PRG change outside owned intervals',sorted(outside-covered)[:30])
 raw_direct=[new['raw'][A.location(new,'HuArthurDirectProbe')+i]for i in range(36)];assert[i for i,x in enumerate(raw_direct)if x]==[10,14,16]
 total=sum(int(g['size'],0)for n,g in sb.items()if n.startswith('ARTHUR_')and'ooffs'in g and int(g['ooffs'],0)<1048592)
 assert int(sb['ARTHUR_BODY']['size'],0)+int(sb['ARTHUR_LEAF']['size'],0)+int(sb['ARTHUR_DRAW']['size'],0)==2233<=2262
 assert int(sb['CHARACTER_HOST_UNION']['size'],0)==1674<=2592
 d=dict(passed=True,native=False,parent_ROM_sha256=A.sha(OLD/'candidate.nes'),candidate_ROM_sha256=A.sha(O/'candidate.nes'),header_and_all_CHR_bytes_exact=True,all_original_Arthur_worker_segments_unchanged=unchanged,old_ArDraw_complete_prefix_exact=size,new_A26_bridge_bytes=39,all36_public16byte_entries_and20Bprefix_exact=True,unchanged_public_prefix_bytes=prefix,existing_granted_ranges=ownranges,all_other_changes_genuine_same_symbol_farcall_relocations=relocated,total_Arthur_PRG_bytes=total,A26_main_used=2233,A26_main_reservation=2262,union_used=1674,union_reservation=2592,fast_rows=[10,14,16],foot_additional_raw32_gate=True,source_calling_contract='Only HuCommon raw32 fast rows and HuArthurFeetGate proven raw32 ingress reach ArProbeDispatch before any private overlay read/write. Actual original probes self-guard raw32, preserve R0/R1, and use no C63 code/data. Input/output ArTemp/Hi and unchanged R1/R0 writes retained. Generic motion/draw/graphics/lifecycle remain unchanged.')
 d['bindings']={str(p.resolve()):A.sha(p)for p in[Path(__file__),O/'candidate.nes',O/'candidate.dbg',OLD/'candidate.nes',OLD/'candidate.dbg',O/'arthur/host-adapter.s',O/'arthur-union.s',O/'probe-source-plan.json']};out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items()if k in['passed','candidate_ROM_sha256','new_A26_bridge_bytes','total_Arthur_PRG_bytes','A26_main_used','union_used']}))
if __name__=='__main__':main()
