"""Freeze source/body fairness/real-vector proof; native remains pending."""
from pathlib import Path
import ast,json,re,zipfile
import arthur_body_fair_main_v5 as F
A=F.A;R=F.R;O=F.O;P=F.P

def main():
    assert not(O/'handoff.json').exists();h=A.sha(O/'candidate.nes')
    assert h=='09237b6f1b88b50d9c3ba054092af36591daa435d43eb83bf21ed08ca856d671'
    names=['controls-v4.json','white-scratch-diagnosis-v5.json','Main-controls-v5.json','ISR-controls-v4.json','regressions-v5.json','source-proof-v5.json']
    docs={n:json.loads((O/n).read_text())for n in names}
    for n,d in docs.items():
        if n=='controls-v4.json':
            assert not d['passed']and set(d['checks'])=={'api','permutation','fairness','source_body','foreign'}and set(d['failures'])=={'Main'}
            assert "7851, 77, 110" in d['failures']['Main']['error']
        else:assert d['passed'],n
        for path,digest in d['bindings'].items():assert A.sha(path)==digest,(n,path,'changed receipt input')
        assert d['bindings'][str((O/'candidate.nes').resolve())]==h
    # Preserve/recheck all actual predecessor source/archive bindings.
    parent=json.loads((P/'source-closure.json').read_text())
    for path,digest in parent['files'].items():assert A.sha(R/path)==digest,('frozen2846predecessor',path)
    files=set();T=O/'frozen-inputs'
    for p in O.glob('*.d'):
        files.add(p.resolve())
        for line in p.read_text().splitlines():
            if '\t'not in line:continue
            for token in re.split(r'(?<!\\)\s+',line.split('\t',1)[1]):
                if token:
                    q=Path(token.replace('\\ ',' '));q=q if q.is_absolute()else T/q
                    assert q.exists(),q;files.add(q.resolve())
    for folder in [O/'arthur',O/'dense',O/'src']:
        files.update(p.resolve()for p in folder.rglob('*')if p.is_file()and p.suffix in ['.s','.inc','.cfg','.chr','.nam','.rle','.bin'])
    files.update(p.resolve()for p in O.iterdir()if p.is_file()and p.suffix in ['.s','.inc','.cfg','.chr','.nam','.rle','.d'])
    recipe=json.loads((O/'cache-final-link-proof.json').read_text())['commands'][-1]['command']
    objects=[Path(v).resolve()for v in recipe if v.endswith('.o')]
    assert all(p.exists()for p in objects);files.update(objects)
    # Verify no actual generated destination escaped this successor.
    for proof in ['arthur-build-proof.json','cache-final-link-proof.json']:
        for z in json.loads((O/proof).read_text())['commands']:
            cmd=z['command']
            for key in ['-o','-Ln','-m']:
                if key in cmd:assert Path(cmd[cmd.index(key)+1]).resolve().is_relative_to(O.resolve()),(proof,key)
    tools=['arthur_body_fair_build_v1.py','arthur_body_fair_build_v2.py','arthur_body_fair_build_v3.py','arthur_body_fair_controls_v4.py','arthur_body_fair_main_v4.py','arthur_body_fair_main_v5.py','arthur_body_fair_isr_v4.py','arthur_body_fair_white_scratch_v5.py','arthur_body_fair_regressions_v5.py','arthur_body_fair_source_proof_v5.py','arthur_body_fair_freeze_v5.py']
    pending=[R/'tools/audit'/n for n in tools];pending.append(R/'build/character-host-union-v5/gm_verify_nmi.py');seen=set()
    while pending:
        p=pending.pop().resolve()
        if p in seen:continue
        seen.add(p);files.add(p)
        for node in ast.walk(ast.parse(p.read_text())):
            modules=[v.name for v in node.names]if isinstance(node,ast.Import)else[node.module]if isinstance(node,ast.ImportFrom)and node.module else[]
            for module in modules:
                rel=Path(*module.split('.')).with_suffix('.py')
                q=next((folder/rel for folder in [p.parent,R/'tools/audit',R/'tools',R]if(folder/rel).is_file()),None)
                if q is not None:pending.append(q)
    files.update((O/n).resolve()for n in names+['source.patch','build-parent.json','arthur-build-proof.json','arthur-build-log.json','cache-final-link-proof.json','candidate.cv3-mirror.json','precheck-negative.py'])
    files.update((P/n).resolve()for n in ['handoff.json','native-handoff-v1.json','source-closure.json','source-proof-v1.json'])
    for version,items in [('arthur-body-fair-v1',['negative-short-branch/preparer.py']),('arthur-body-fair-v2',['Main-controls-v2.json','controls-v3.json','hidden-byte-diagnosis-v3.json','retained-slow-fixture-v2/fixture.py'])]:
        files.update((R/'build'/version/n).resolve()for n in items if (R/'build'/version/n).exists())
    for p in [R/'build/arthur-shadow-ownership-v2/handoff.json',R/'build/arthur-body-priority-plan-v1/audit.json',R/'build/arthur-source-v1/art-source.json',R/'build/arthur-source-v1/arthur-original-sprites.chr']:
        files.add(p.resolve())
    for n in ['arthur-quick-private-allocation','arthur-ice-alias-allocation','arthur-nmi-gateway-allocation','parodius-dense-chr','mmc5-overlay-private-allocation']:
        files.add((R/'docs/qa/checkpoints/2026-10-30'/n/'root-review-and-reservations.json').resolve())
    for d in docs.values():files.update(Path(p).resolve()for p in d['bindings'])
    assert all(p.is_relative_to(R.resolve())and p.exists()for p in files)
    closure=O/'source-closure.json';closure.write_text(json.dumps(dict(candidate_sha256=h,files={p.relative_to(R).as_posix():A.sha(p)for p in sorted(files)},actual_linked_objects=[dict(path=p.relative_to(R).as_posix(),sha256=A.sha(p))for p in objects]),indent=2)+'\n')
    archive=O/'private-source-cpu.zip'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
        for p in sorted(files):z.write(p,p.relative_to(R).as_posix())
        z.write(closure,closure.relative_to(R).as_posix())
    main=docs['Main-controls-v5.json']['checks']['Main'];isr=docs['ISR-controls-v4.json']['checks'];base=docs['controls-v4.json']['checks']
    handoff=dict(status='PRIVATE_SOURCE_CPU_FAIR_BODY_RENDERER_NATIVE_PENDING_SEVERE_LAG_UNRESOLVED',candidate_sha256=h,parent_ROM_sha256=A.sha(P/'candidate.nes'),source_archive_sha256=A.sha(archive),source_closure_sha256=A.sha(closure),source_archive_bytes=archive.stat().st_size,source_archive_members=len(files)+1,receipts={n:A.sha(O/n)for n in names},source_body_hardware8_cases=base['source_body']['cases'],actual64record_permutations=base['permutation']['cases'],actual_native_phase_calls=base['fairness']['actual_native_phase_calls'],stable_tail_cycles=base['fairness']['stable_partition_cycles'],tail_partition_phase_cases=base['fairness']['partition_phase_cases'],each_tail_receives_first_tail_slot_per_stable_cycle=True,foreign_Main=base['foreign'],own_Main=dict(pairs=main['actual_Main_pairs'],body_max_records=main['body_max_records'],natural_priority_entry_SP=main['actual_priority_entry_SP'],source_black_pixels=main['source_black_pixels_visible_first8'],added_CPU=main['added_Main_CPU'],actual_native_consumers=main['actual_native_consumers']),ISR=dict(real_vector_cases=isr['real_vector_cases'],nested_IRQ_in_normal_NMI=isr['nested_actual_IRQ_in_normal_NMI'],minimum_SP=isr['minimum_real_SP'],live_static_page1_Local_eb_and33SMC_preserved=True),resources=dict(A26_main_used=2261,A26_main_reserved=2262,A26_tail_used=714,A26_tail_reserved=718,A79_common_used=1939,C2_code=550,C2_cache=6130,CHR_carrier_used=2876,CHR_carrier_reserved=3072,new_state_bytes=0,new_leases=False),metadata='ArDrawPage is actual emitted body bytes; ArLayoutPtr.low reuses cold-loader-only pointer after initialized cold load. ArDrawHeader remains exact physics witness. Original mode2 final ArTemp last-mask scratch is authenticated separately; no gameplay comparison omitted.',limits=['No native run/visual acceptance/installation/full-campaign or performance claim. Frozen2846 has212lagNMIs/400controlledphysicalframes; new source adds170..2144CPU/Main and can worsen cadence.','Finite scene tests establish actual source/hardware8body protection and stable tail fairness, not visibility of every nonplayer pixel on rows already filled by8body sprites.','Actual8sprite limit and all64records retained. Mode2 original white expansion budget/rules unchanged; later native mask capacity can still cull tail as before.','Current standalone A79 common lease is NOT assumed jointly available against newer fast-v4 union; joint source/layout rebase is pending. No Arthur RAM1 grant/adoption.','Existing controller-earned weapons/upgrades/campaign/Hard/sourceaudio remain open. Prior compile/fixture hidden-byte and genuine mode2 final-mask comparison negatives remain immutable.'])
    handoff['bindings']={str(p.resolve()):A.sha(p)for p in [O/'candidate.nes',O/'candidate.dbg',O/'candidate.lbl',closure,archive]+[O/n for n in names]}
    (O/'handoff.json').write_text(json.dumps(handoff,indent=2)+'\n')
    print(json.dumps(dict(handoff_sha256=A.sha(O/'handoff.json'),ROM=h,members=len(files)+1,archive_bytes=archive.stat().st_size)))
if __name__=='__main__':main()
