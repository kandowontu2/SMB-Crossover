"""Actual complete Main, later player-bank writer, then real normal/lag NMI."""
from pathlib import Path
import argparse,importlib.util,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import arthur_actual_host_controls_v1 as A
from sunny_integrated_controls_v1 import NesMPU

def run(b,negative):
 spec=importlib.util.spec_from_file_location('arthur_commit_nmi',R/'build/character-host-union-v5/gm_verify_nmi.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
 rows=[];bad=[]
 for mode,face in [(m,f)for m in range(3)for f in[1,2]]:
  q=A.setup(b);q.put(AreaType=1 if mode==0 else 3,SmFreezePaletteControl=8 if mode==2 else 4,PlayerFacingDir=face,DisableScreenFlag=0,Mirror_PPUCTRL=160,Mirror_PPUMASK=30)
  captured=[];old=NesMPU.step;pub=A.point(b,'X5SetPhysicalChr')
  def step(c):
   bank=q.m.banks[(c.pc-0x8000)//8192]if c.pc>=0x8000 else -1
   if(bank,c.pc)==pub and c.y==0:captured.append(c.a+256*(c.x&3))
   old(c)
  NesMPU.step=step
  try:
   for age in range(36):
    keys=(1 if face==1 else 2)|(128 if age in[6,16]else 0)|(64 if age in[24,30]else 0)
    q.put(SavedJoypadBits=keys,SavedJoypad1Bits=keys,ArHostPad=keys,ArHostDue=int(age%3==0),NmiDisable=255,VRAM_Buffer1_Offset=0)
    captured.clear();A.call(q,'GameLoop');assert captured,('real body source publisher missing',mode,face,age)
    expected=captured[-1];current=q.get('CurrentCHRBank')+(q.get('X5ChrMode')&3)*256
    if current!=expected:bad.append([mode,face,age,expected,current,q.get('SmChrBank')])
    if negative:break
    assert current==expected and q.get('SmChrBank')==expected&255,('later native player-bank overwrite',mode,face,age,expected,current,q.get('SmChrBank'))
    q.put(NmiDisable=0);q.m.writes=[];z=g.nmi(q);upper=0;hardware={}
    for at,value in q.m.writes:
     if at==0x5130:upper=value&3
     elif 0x5120<=at<=0x512b:hardware[at-0x5120]=value+256*upper
    assert hardware[0]==expected,('real NMI body commit',mode,face,age,expected,hardware)
    assert hardware[6]in[877,879]and hardware[7]in[878,880]
    q.put(NmiDisable=255);q.m.writes=[];g.nmi(q)
    assert not any(0x5120<=at<=0x512b for at,v in q.m.writes),('lag cannot publish incomplete CHR')
    rows.append([mode,face,age,expected,hardware[0],hardware[6],hardware[7]])
  finally:NesMPU.step=old
 if negative:assert len(bad)==6,('expected retained overwrite negative',bad)
 return dict(passed=not negative,expected_negative_proven=negative,complete_Main_normal_lag_commits=len(rows),rows=rows,retained_overwrites=bad,scope='Actual source publisher -> complete native DrawAll player-bank writer -> actual NMI mapper writes. Isolated legal world/input/source-clock boundary; no native visibility claim.')

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--rom',type=Path,required=True);ap.add_argument('--output',type=Path,required=True);ap.add_argument('--expect-negative',action='store_true');a=ap.parse_args();assert not a.output.exists()
 b=A.scoped_load(a.rom);d=run(b,a.expect_negative);d['bindings']={str(p.resolve()):A.sha(p)for p in[Path(__file__),a.rom,a.rom.with_suffix('.dbg')]};a.output.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items()if k not in['rows','bindings']}))
if __name__=='__main__':main()
