"""New source successor: already-protected earlyout and exact reorder APXY."""
from pathlib import Path
import difflib,json,shutil,sys
R=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import arthur_integrate_host_v1 as B
import arthur_host_cache_build_v1 as W
P=R/'build/arthur-body-fair-v1';O=R/'build/arthur-body-fair-v2';BASE=R/'build/arthur-host-render-fast-v1'

def main():
    assert not O.exists();assert B.sha(P/'candidate.nes')=='ead1db551b7a2230437dee28798b041441ddea341d2ff46e94251dc2141d2e7e'
    controls=P/'permutation-controls-v1.json';d=json.loads(controls.read_text());assert d['passed']
    for p,h in d['bindings'].items():assert B.sha(p)==h,p
    O.mkdir()
    for folder in ['frozen-inputs','src','dense','arthur']:shutil.copytree(P/folder,O/folder)
    for p in P.iterdir():
        if p.is_file()and(p.suffix in ['.s','.inc','.cfg','.chr','.nam','.rle','.o','.d']or p.name in ['parent-commands.json','parent-reproduction.json','dense-parent-reproduction.json']):shutil.copy2(p,O/p.name)
    for p in O.rglob('*'):
        if p.is_file()and p.suffix in ['.s','.inc','.cfg','.d','.json']:
            s=p.read_text()
            for old,new in [(str(P),str(O)),(P.as_posix(),O.as_posix()),(str(P).replace('\\','\\\\'),str(O).replace('\\','\\\\'))]:s=s.replace(old,new)
            p.write_text(s,newline='\n')
    p=O/'arthur/cache-runtime.s';s=p.read_text()
    old='ArCacheBodyPriority:\n lda ArDrawPage\n'
    new='''ArCacheBodyPriority:
 php
 pha
 txa
 pha
 tya
 pha
 lda ArDrawHeader
 jeq PriorityReturn          ; exact already-protected prefix, no OAM work
 lda ArDrawPage
'''
    assert s.count(old)==1;s=s.replace(old,new)
    old='PriorityReturn:\n rts\n'
    new='''PriorityReturn:
 pla
 tay
 pla
 tax
 pla
 plp
 rts
'''
    assert s.count(old)==1;s=s.replace(old,new);p.write_text(s,newline='\n')
    for p in O.rglob('*'):assert p.resolve().is_relative_to(O.resolve()),p
    for n in ['parent-commands.json','dense-parent-reproduction.json']:
        s=(O/n).read_text();assert str(P).replace('\\','\\\\')not in s and P.as_posix()not in s,n
    B.O=O;B.A=O/'arthur';B.D=O/'dense';B.T=O/'frozen-inputs';B.physical_config=lambda:None;B.build()
    W.O=O;W.A=O/'arthur';W.D=O/'dense';W.T=O/'frozen-inputs';saved=sys.argv;sys.argv=[__file__,'--finalize']
    try:W.main()
    finally:sys.argv=saved
    changes=[]
    for n in ['arthur/cache-wrapper.s','arthur/cache-runtime.s','arthur/host-adapter.s','arthur/cache-signature.inc']:
        changes+=difflib.unified_diff((BASE/n).read_text().splitlines(True),(O/n).read_text().splitlines(True),fromfile='2846/'+n,tofile='fair-v2/'+n)
    (O/'source.patch').write_text(''.join(changes),newline='\n')
    (O/'build-parent.json').write_text(json.dumps(dict(parent=B.sha(P/'candidate.nes'),baseline=B.sha(BASE/'candidate.nes'),
        v1_positive_controls=B.sha(controls),source_only=True,new_leases=False,
        maximum_body_stack_bytes=44,register_save_stack_bytes=4,maximum_added_stack_bytes=48,
        bindings={str(controls.resolve()):B.sha(controls),str(Path(__file__).resolve()):B.sha(__file__)}),indent=2)+'\n')
    print('PRIVATE_FAIR_V2_SOURCE_READY',B.sha(O/'candidate.nes'))
if __name__=='__main__':main()
