"""Actual shared menu and private Arthur ink with both Shadows settings.

No product edit: the real new-profile outline bypass and Arthur's independent
source emitter already make its source ink unconditional. Retain this proof
instead of adding a redundant renderer trip or modifying the global option.
"""
from pathlib import Path
import collections,importlib.util,itertools,json,traceback
from PIL import Image
import arthur_probe_fast_controls_v1 as C
import arthur_cache_host_controls_v1 as H
import arthur_coalesced_palette_v1 as S
A=C.A;R=C.R;O=R/'build/arthur-shadow-ownership-v2'
PRIVATE=C.O/'candidate.nes';SHARED=R/'build/full-roster-menu-v5/candidate.nes'
PAL=R/'tools/Windows/NEXXT 3.0/defaults/nes.pal'
def rgb(c):return tuple(PAL.read_bytes()[3*(c&63):3*(c&63)+3])
def image(pixels,size,path):
 im=Image.new('RGBA',size)
 for (x,y),value in pixels.items():
  if 0<=x<size[0]and 0<=y<size[1]:im.putpixel((x,y),value+(255,))
 im.save(path)
def raster(q,palette,hardware_limit=False):
 b=q.b;pixels={};occupancy=collections.Counter();discarded=[]
 for slot in range(64):
  y,t,a,x=bytes(q.m[512+slot*4:516+slot*4])
  if y>=240:continue
  window=(t&1)*4+(t>>6);page=q.get('CurrentCHRBank',window)+256*(q.get('X5ChrMode',window)&3)
  at=1048592+page*1024+(t&62)*16;pat=b['raw'][at:at+32]
  for dy in range(16):
   yy=y+1+dy
   if yy>=240:continue
   occupancy[yy]+=1
   if hardware_limit and occupancy[yy]>8:discarded.append([slot,yy]);continue
   sy=15-dy if a&128 else dy
   for dx in range(8):
    xx=x+dx;sx=7-dx if a&64 else dx
    value=(pat[sy//8*16+sy%8]>>(7-sx)&1)|((pat[sy//8*16+sy%8+8]>>(7-sx)&1)<<1)
    if value and xx<256:pixels.setdefault((xx,yy),(rgb(palette[(a&3)*4+value]),a&32))
 return pixels,occupancy,discarded
def menus(b,tag):
 pairs=[];rows=[]
 original=Image.open(R/'build/full-menu-final-art-v1/arthur.png').convert('RGBA');assert original.size==(16,24)
 source_alpha={(x+120,y+168)for y in range(24)for x in range(16)if original.getpixel((x,y))[3]}
 source_black={(x+120,y+168)for y in range(24)for x in range(16)if original.getpixel((x,y))[3]and max(original.getpixel((x,y))[:3])==0}
 for off in[0,1]:
  q=A.C.setup(b,0);q.put(CrossoverMenuIndex=31,CrossoverMenuState=2,PlayerOutlinesOff=off,VRAM_Buffer1_Offset=0)
  c,tr,mn=A.call(q,'FmDrawPreview');assert q.get('PlayerOutlinesOff')==off
  assert A.point(b,'PlayerRemoveOutlines')not in tr
  buf=A.address(b,'VRAM_Buffer1');assert bytes(q.m[buf:buf+3])==bytes([63,17,3]);pal=[15]+list(q.m[buf+3:buf+6])+[0]*12
  pixels,occ,lost=raster(q,pal,True);black={p for p,(col,pr)in pixels.items()if col==(0,0,0)}
  assert set(pixels)==source_alpha,('pending menu alpha differs from authenticated source',tag,off,len(pixels),len(source_alpha))
  assert black==source_black,('pending menu missing opaque source black',tag,off,len(black),len(source_black),sorted(source_black-black)[:10])
  assert not lost and max(occ.values())<=2
  pairs.append((bytes(q.m[512:768]),pixels,pal));rows.append(dict(Shadows_off=off,pixels=len(pixels),opaque_source_black=len(black),max_sprites_per_scanline=max(occ.values()),cycles=c.processorCycles))
 assert pairs[0]==pairs[1],('menu toggle changed pixels/OAM/palette',tag)
 image({(x-120,y-160):v[0]for(x,y),v in pairs[0][1].items()},(16,32),O/(tag+'-menu.png'))
 return dict(rows=rows,both_options_identical=True,all_original_alpha_and_opaque_black_retained=True,source_colors_reduced_to_three_in_existing_menu=True,missing_or_occluded_black_pixels=0)
def lives(b):
 pairs=[];rows=[]
 for off in[0,1]:
  q=C.prepare(b);q.put(PlayerOutlinesOff=off,OperMode=1,GameEngineSubroutine=0,CurrentOAMOffset=0)
  A.call(q,'HuReset');q.m[512:768]=[248,0,0,0]*64;A.call(q,'DrawPlayer_Intermediate');c,tr,mn=A.call(q,'X5PortraitRender')
  assert A.point(b,'ArHostPortrait')in tr and A.point(b,'PlayerRemoveOutlines')not in tr
  assert q.get('PlayerOutlinesOff')==off
  pal=[15,54,24,18,15,26,48,39,15,22,48,39,15,15,54,23]
  pixels,occ,lost=raster(q,pal,True);assert pixels and not lost
  black={p for p,(v,pr)in pixels.items()if v==(0,0,0)};assert black
  pairs.append((bytes(q.m[512:768]),pixels,[q.get('CurrentCHRBank',i)+256*(q.get('X5ChrMode',i)&3)for i in range(8)]))
  rows.append(dict(Shadows_off=off,parts=q.get('CurrentOAMOffset')//4,pixels=len(pixels),opaque_black_pixels=len(black),max_body_sprites_per_scanline=max(occ.values()),cycles=c.processorCycles))
 assert pairs[0]==pairs[1],('lives toggle changed ink/parts/publisher')
 return dict(rows=rows,both_options_identical=True,normal_eight_sprite_limit=True,source_role_palette_for_pixel_count_explicit=True)
def source_pixels(b):
 results=[];original_setup=A.setup
 for off in[0,1]:
  def setup(bundle,ch=32):
   q=original_setup(bundle,ch);q.put(PlayerOutlinesOff=off);return q
  A.setup=setup
  try:result=A.render_pixels(b)
  finally:A.setup=original_setup
  results.append(dict(Shadows_off=off,**result))
 assert results[0]['opaque_original_black_pixels_checked']==results[1]['opaque_original_black_pixels_checked']
 return dict(rows=results,original_RGB_alpha_priority_exact_both_options=True,missing_source_black_pixels=0)
def complete_main(b):
 qa,qb=[C.prepare(b)for _ in range(2)]
 for q,off in[(qa,0),(qb,1)]:q.put(PlayerOutlinesOff=off)
 rows=[];black_frames=0;max_occupancy=0;occluded=0
 for age in range(96):
  pair=[];keys=1|(128 if age in[6,16]else 0)|(64 if 24<=age<78 and age%18<6 else 0)
  for q in[qa,qb]:
   q.put(SavedJoypadBits=keys,SavedJoypad1Bits=keys,ArHostPad=keys,ArHostDue=int(age%3==0),NmiDisable=255,VRAM_Buffer1_Offset=0)
   c,tr,mn,ann,events=A.M.run_linked(q,'GameLoop')
   assert A.point(b,'PlayerRemoveOutlines')not in tr
   assert q.get('PlayerOutlinesOff')==int(q is qb)
   pal=[15,54,24,18,15,26,48,39,15,22,48,39,15,15,54,23]
   pixels,occ,lost=raster(q,pal,True);unlimited,_,_=raster(q,pal,False)
   pair.append((bytes(q.m[512:768]),[q.get('CurrentCHRBank',i)+256*(q.get('X5ChrMode',i)&3)for i in range(12)],pixels,bytes(q.m.ram[2]),q.get('ArUpdates'),c.processorCycles))
  assert pair[0][:5]==pair[1][:5],('full Main OAM/CHR/pixels/source/cache differ by option',age)
  if any(v[0]==(0,0,0)for v in pair[0][2].values()):black_frames+=1
  max_occupancy=max(max_occupancy,max(occ.values(),default=0));occluded+=sum(v[0]==(0,0,0)and p not in pixels for p,v in unlimited.items())
  rows.append([age,pair[0][-1],pair[1][-1],len(pair[0][2]),len(lost)])
 return dict(actual_Main_updates_per_option=96,identical_actual_OAM_CHR_source_state_cache=True,black_visible_frames=black_frames,max_scanline_sprite_occupancy=max_occupancy,opaque_black_pixels_hidden_by_eight_sprite_limit=occluded,rows=rows,scope='Legal isolated source-clock scene; no native capture or route admission. Hardware evaluation modeled as first8 physical OAM records per scanline.')
def main():
 assert not O.exists();O.mkdir();d=dict(passed=False,product_change=False,native=False,checks={})
 try:
  b=A.scoped_load(PRIVATE);shared=A.scoped_load(SHARED)
  for name,bundle in[('shared5b09_pending_menu',shared),('private528_pending_menu',b)]:d['checks'][name]=menus(bundle,name)
  d['checks']['lives']=lives(b);d['checks']['source_pixels']=source_pixels(b);d['checks']['complete_Main']=complete_main(b)
  d['passed']=True
 except Exception as e:d.update(failure=repr(e),traceback=traceback.format_exc())
 d['bindings']={str(p.resolve()):A.sha(p)for p in[Path(__file__),Path(C.__file__),Path(H.__file__),Path(A.__file__),Path(S.__file__),PRIVATE,PRIVATE.with_suffix('.dbg'),SHARED,SHARED.with_suffix('.dbg'),R/'build/full-menu-final-art-v1/arthur.png',R/'build/full-menu-final-art-v1/manifest.json',PAL]}
 (O/'controls.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(passed=d['passed'],failure=d.get('failure'),checks=list(d['checks']))));assert d['passed']
if __name__=='__main__':main()
