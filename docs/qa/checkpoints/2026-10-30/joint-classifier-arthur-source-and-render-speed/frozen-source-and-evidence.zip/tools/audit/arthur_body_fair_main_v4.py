"""Actual complete Main body protection/native actor/state/ABI/cost controls."""
from pathlib import Path
import argparse,collections,importlib.util,itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import arthur_body_fair_controls_v4 as F
from sunny_integrated_controls_v1 import registers,smc_at
from verify_native_relocation import NesMPU
A=F.A;C=F.C;T=F.T;P=F.P;O=R/'build/arthur-body-fair-v3';F.O=O
_real_label=A.M.code_label
_label_cache={}
def _cached_label(bundle,bank,pc,exact=False):
    key=id(bundle),bank,pc,exact
    if key not in _label_cache:_label_cache[key]=_real_label(bundle,bank,pc,exact)
    return _label_cache[key]
A.M.code_label=_cached_label

def snapshot(q):
    omit=set(range(0x100,0x300))|{A.address(q.b,n)for n in ['ArDrawPage','ArLayoutPtr']}
    fields=[i for i in list(range(0x2000))+list(range(0x5c00,0x8000))if i not in omit]
    return bytes(q.m[i]for i in fields),tuple(q.m.rawtags),bytes(q.m[0x100:0x17b])

def own_Main(old,b):
    rows=[];body_cases=0;native_seen=set();samples=[];maximum_body=0;entrySP=[];visible_black=0
    src=json.loads((R/'build/arthur-source-v1/art-source.json').read_text());records={z['pose']:z for z in src['records']}
    chrdata=(R/'build/arthur-source-v1/arthur-original-sprites.chr').read_bytes();pal=src['palette']['hardware_indices'][16:32]
    source_rows={p:8 for p in range(22)}|{p:2 for p in range(32,54)}|{22:2,24:1,26:1}
    for mode,face,crowded in itertools.product(range(3),[1,2],[False,True]):
        qa,qb=[C.prepare(v)for v in [old,b]]
        for q in [qa,qb]:
            q.put(AreaType=1 if mode==0 else 3,SmFreezePaletteControl=8 if mode==2 else 4,PlayerFacingDir=face)
        limit=96 if(mode,face,crowded)==(0,1,False)else 48
        for age in range(limit):
            keys=(1 if face==1 else 2)|(128 if age in [6,16]else 0)|(64 if 24<=age<78 and age%18<6 else 0)
            pair=[];captures=[]
            for q in [qa,qb]:
                q.put(SavedJoypadBits=keys,SavedJoypad1Bits=keys,ArHostPad=keys,ArHostDue=int(age%3==0),
                      PlayerOutlinesOff=int(age>=24),NmiDisable=255,VRAM_Buffer1_Offset=0)
                if crowded:
                    # Explicit legal native actor scene; real enemy/frame/render
                    # consumers run. No expected movement, hit or OAM seeded.
                    for slot,kind in enumerate([6,0,5,6,0,5]):
                        A.C.actor(q,slot,kind,200+slot*8,176)
                raw=bytes(q.m.ram[2]);saved=NesMPU.step;pending=None
                def step(cpu):
                    nonlocal pending,body_cases,maximum_body
                    if q is qb and cpu.pc==A.address(b,'ArCacheBodyPriority')and q.m.rawtags[2]==2:
                        pending=(F.records(q.m),q.get('ArLayoutPtr')//4,q.get('ArDrawPage')//4,(cpu.a,cpu.x,cpu.y,cpu.p),cpu.sp)
                        entrySP.append(cpu.sp)
                    if q is qb and cpu.pc==A.address(b,'PriorityReturn')and q.m.rawtags[2]==2 and pending:
                        original,origin,n,regs,sp=pending
                        assert F.records(q.m)==F.model(original,origin,n),('actual Main phase permutation',mode,face,crowded,age)
                        assert collections.Counter(F.records(q.m))==collections.Counter(original)
                        captures.append((n,regs,sp));maximum_body=max(maximum_body,n);body_cases+=1;pending=None
                    saved(cpu)
                NesMPU.step=step
                try:c,tr,mn,ann,events=A.M.run_linked(q,'GameLoop')
                finally:NesMPU.step=saved
                assert pending is None and bytes(q.m.ram[2])==raw
                pair.append((c,tr,mn,ann,events))
            ca,ta,ma,ana,ea=pair[0];cb,tb,mb,anb,eb=pair[1]
            assert registers(ca)==registers(cb),('Main AXYP/SP',mode,face,crowded,age,registers(ca),registers(cb))
            sa,sb=snapshot(qa),snapshot(qb)
            assert sa==sb,('Main application/staticpage1/maps outside OAM+2declared metadata',mode,face,crowded,age,[(i,x,y)for i,(x,y)in enumerate(zip(sa[0],sb[0]))if x!=y][:12])
            assert qa.get('RgOamUsed')==qb.get('RgOamUsed')and qa.get('RgOamFirst')==qb.get('RgOamFirst')and qa.get('RgOamRotation')==qb.get('RgOamRotation')
            assert [x[-1]for x in ea]==[x[-1]for x in eb]
            if mode<2:assert collections.Counter(z for z in F.records(qa.m)if z[0]<240)==collections.Counter(z for z in F.records(qb.m)if z[0]<240),('full Main exact live OAM multiset',mode,age)
            # Black is source color0F in every palette-role mode. All opaque
            # source black must win actual first8 evaluation in the full frame.
            pose=qb.get('ArR_0522');source=T.S.raster(records[pose],source_rows[pose],chrdata,pal)
            sx=qb.get('ArR_05AF')+256*qb.get('ArR_0583')-qb.get('ArR_0064')-256*qb.get('ArR_0065')
            page=qb.get('ArR_056D');page=page if page<128 else page-256;sy=qb.get('ArR_0599')+240*page+1
            expected={(sx+x,sy+y)for(x,y),(color,pri)in source.items()if color==15 and 0<=sx+x<256 and 0<=sy+y<240}
            palette=[15,54,24,18,15,26,48,39,15,22,48,39,15,15,54,23]
            if mode:palette[1]=15
            limited,occ,lost=T.raster(qb,palette,True)
            missing=[p for p in expected if p not in limited or limited[p][0]!=(0,0,0)]
            assert not missing,('complete Main source black hidden',mode,face,crowded,age,pose,missing[:10])
            visible_black+=len(expected)
            assert max((at for at,v in qb.m.writes if 512<=at<768),default=512)<768
            if crowded:native_seen.update(n for n in ['DrawMetasprite','EnemiesAndLoopsCore','FloateyNumberRender','WorldFirebarDrawAdmission']if A.point(b,n)in tb)
            rows.append([mode,face,int(crowded),age,ca.processorCycles,cb.processorCycles,mb,len(expected),max(occ.values(),default=0),qb.get('ArDrawPage')//4])
    costs=[z[5]-z[4]for z in rows]
    assert 'DrawMetasprite'in native_seen and 'EnemiesAndLoopsCore'in native_seen
    return dict(actual_Main_pairs=len(rows),phase_permutation_cases=body_cases,body_max_records=maximum_body,
                actual_priority_entry_SP=[min(entrySP),max(entrySP)],source_black_pixels_visible_first8=visible_black,
                AXYP_SP_all_nonOAM_application_native_actor_updates_globalphase_staticpage1_rawmaps_exact=True,
                source_code_cache_immutable=True,normal_eight_sprite_limit=True,both_Shadow_options=True,
                actual_native_consumers=sorted(native_seen),added_Main_CPU=dict(min=min(costs),max=max(costs),mean=sum(costs)/len(costs)),
                existing_severe_native_lag_unresolved=True,rows=rows)

def foreign(old,b):
    rows=[]
    for ch,mode,keys in itertools.product([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,23,24,26,28],range(2),[0,129]):
        pair=[]
        for v in [old,b]:
            q=A.C.setup(v,ch)
            if ch==28:A.call(q,'DkConstruct')
            q.put(CrossoverBehaviorVersion=mode,SavedJoypadBits=keys)
            c,tr,mn,ann,events=A.M.run_linked(q,'GameLoop',p=0x71)
            w=[(a,ann.get(i,val))for i,(a,val)in enumerate(q.m.writes)if not 256<=a<512 and not 0x5114<=a<=0x5117 and a not in smc_at(v)and a not in [A.address(v,'CurrentBank'),A.address(v,'CurrentBankC')]]
            pair.append((registers(c),A.C.M.fastapp(q),tuple(q.m.rawtags),bytes(q.m[0x100:0x17b]),w,c.processorCycles))
        assert pair[0]==pair[1],('foreign actual Main changed',ch,mode,keys)
        rows.append([ch,mode,keys,0])
    return dict(cases=len(rows),all_application_ordered_writes_AXYP_SP_staticpage1_maps_and_CPU_exact=True,CPU_delta=0,rows=rows)

def api(b):
    q=C.prepare(b);rows=[]
    flags=[0x30|sum(((v>>i)&1)*bit for i,bit in enumerate([1,2,4,8,64,128]))for v in range(64)]
    for count,origin,p in itertools.product([0,1,4,11],[0,1,10,53,63],flags):
        q.m[512:768]=[(i*37+19)&255 for i in range(256)];q.put(ArDrawPage=count*4,ArLayoutPtr=origin*4)
        def seed(q,c,step):
            if step==0:c.a=83;c.x=155;c.y=23
        c,tr,mn=F.bare(q,p=p,hook=seed)
        assert(c.a,c.x,c.y,c.p,c.sp)==(83,155,23,p,224)
        rows.append([count,origin,p,c.processorCycles,mn])
    return dict(cases=len(rows),all64liveflags_and_AXY_exact=True,already_protected_prefix_earlyout=True,
                cycles=[min(z[3]for z in rows),max(z[3]for z in rows)],rows=rows)

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--only',default='api,permutation,fairness,source_body,Main,foreign');a=p.parse_args();assert not a.output.exists()
    b=A.scoped_load(O/'candidate.nes');old=A.scoped_load(P/'candidate.nes');d=dict(passed=False,native=False,checks={},failures={})
    functions={**F.GROUPS,'api':api,'Main':lambda b:own_Main(old,b),'foreign':lambda b:foreign(old,b)}
    for n in a.only.split(','):
        try:d['checks'][n]=functions[n](b)
        except Exception as e:d['failures'][n]=dict(error=repr(e),traceback=traceback.format_exc())
    d['passed']=not d['failures'];paths=[Path(__file__),Path(F.__file__),Path(C.__file__),Path(T.__file__),O/'candidate.nes',O/'candidate.dbg',O/'cache-final-link-proof.json',P/'candidate.nes',P/'candidate.dbg']
    d['bindings']={str(p.resolve()):A.sha(p)for p in paths};a.output.write_text(json.dumps(d,indent=2)+'\n')
    print(json.dumps(dict(passed=d['passed'],checks=list(d['checks']),failures=d['failures'])));assert d['passed']
if __name__=='__main__':main()
