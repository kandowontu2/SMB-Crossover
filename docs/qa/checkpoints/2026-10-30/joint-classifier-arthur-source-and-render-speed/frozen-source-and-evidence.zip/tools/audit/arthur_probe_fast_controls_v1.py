"""Exact actual old/new probe application writes, flags and complete Main."""
from pathlib import Path
import argparse,itertools,json,traceback
import arthur_cache_host_controls_v1 as H
A=H.A;R=H.R;O=R/'build/arthur-host-probe-fast-v1';OLD=H.O
from sunny_integrated_controls_v1 import registers,smc_at
def seed(b):
 q=A.setup(b)
 for name in['Block_Buffer_1','Block_Buffer_2']:
  for i in range(256):q.m[A.address(b,name)+i]=(i*73+19)&255
 return q
def writes(q):
 skip=set(smc_at(q.b))|{A.address(q.b,n)for n in['CurrentBank','CurrentBankC']}
 return[(a,v)for a,v in q.m.writes if not 256<=a<512 and not 0x5114<=a<=0x5117 and a not in skip]
def state(q):return(A.C.M.fastapp(q),tuple(q.m.rawtags),bytes(q.m[0x1fe:0x200]),bytes(q.m[i]for i in[A.address(q.b,'R0'),A.address(q.b,'R1')]))
def probes(old,b):
 targets=[('HuHead',0),*[( 'HuSide',y)for y in[3,4,5,6]],('HuFullBox',0),('HuArthurFeetGate',0),('HuArthurFeetGate',1)]
 cases=[(n,y,p,96,1,176,0)for n,y in targets for p in range(256)]
 edges=[(x,page,y,c)for x,page,y,c in[(0,0,0,0),(255,0,23,2),(15,1,32,0),(16,2,239,2),(248,255,255,0),(1,1,31,2),(128,2,128,0),(249,1,208,2)]]
 cases +=[(n,y,p,*edge)for n,y in targets for p in[0x30,0x71,0xa4,0xff]for edge in edges]
 rows=[]
 for name,probe,p,x,page,y,crouch in cases:
  pair=[]
  for v in[old,b]:
   q=seed(v);q.put(Player_X_Position=x,Player_PageLoc=page,Player_Y_Position=y,ArR_04F0=128|crouch,R0=55,R1=166)
   cpu,tr,mn=A.call(q,name,a=0x53,x=0x9b,y=probe,p=p);A.exact_maps(q)
   pair.append((q,cpu,tr,mn,writes(q)))
  qa,ca,ta,ma,wa=pair[0];qb,cb,tb,mb,wb=pair[1]
  assert registers(ca)==registers(cb),('probe AXYP/SP',name,probe,p,x,page,y,registers(ca),registers(cb))
  assert state(qa)==state(qb),('probe entire application/raw maps/live stack/R0R1',name,probe,p,x,page,y)
  assert wa==wb,('ordered application writes',name,probe,p,x,page,y,[(i,a,z)for i,(a,z)in enumerate(zip(wa,wb))if a!=z][:8],len(wa),len(wb))
  assert A.point(b,'ArProbeDispatch')in tb and A.point(b,'ArDispatch')not in tb,('actual direct A26 route',name)
  assert not any(at==0x5116 for at,val in qb.m.writes),('probe should not map C',name)
  rows.append([name,probe,p,x,page,y,crouch,ca.processorCycles,cb.processorCycles,min(ma,mb)])
 return dict(cases=len(rows),rows=rows,full256incoming_flags_each_native_probe=True,AXYP_SP_all_application_R0R1_live_page1_raw_maps_ordered_writes_exact=True,old_cycles=[min(r[7]for r in rows),max(r[7]for r in rows)],new_cycles=[min(r[8]for r in rows),max(r[8]for r in rows)],saved_cycles=[min(r[7]-r[8]for r in rows),max(r[7]-r[8]for r in rows)],declared_removed_transport='Only dead stack frames and actual $5116/CurrentBankC save/map/restore. All application store order/value exact, including ArTemp/ArTempHi and unchanged R1/R0 stores.')
def prepare(b):
 q=A.setup(b);q.put(OperMode=1,DisableScreenFlag=1,Mirror_PPUMASK=0,Mirror_PPUCTRL=160,NmiDisable=255);c,_,_=A.owned(q,'ArCacheEnsure');assert c.p&1;return q
def main_differential(old,b):
 rows=[]
 for face,skip in itertools.product([1,2],[0,1]):
  qa,qb=[prepare(v)for v in[old,b]]
  for q in[qa,qb]:q.put(PlayerFacingDir=face,ShouldSkipDrawSprites=skip)
  for age in range(48):
   pair=[];keys=(1 if face==1 else 2)|(128 if age in[6,16]else 0)|(64 if age in[24,36]else 0)
   for q in[qa,qb]:
    q.put(SavedJoypadBits=keys,SavedJoypad1Bits=keys,ArHostPad=keys,ArHostDue=int(age%3==0),NmiDisable=255,VRAM_Buffer1_Offset=0)
    c,tr,mn,ann,events=A.M.run_linked(q,'GameLoop');pair.append((c,tr,mn,ann,events))
   ca,ta,ma,ana,ea=pair[0];cb,tb,mb,anb,eb=pair[1]
   assert registers(ca)==registers(cb)and state(qa)==state(qb),('full Main application/registers/stack/maps',face,skip,age)
   assert writes(qa)==writes(qb),('full Main ordered application writes',face,skip,age)
   rows.append([face,skip,age,ca.processorCycles,cb.processorCycles,min(ma,mb)])
 return dict(updates=len(rows),rows=rows,all_application_ordered_writes_AXYP_SP_live_stack_raw_maps_exact=True,saved_cycles=[min(r[3]-r[4]for r in rows),max(r[3]-r[4]for r in rows)],source_inputs_and_geometry_unchanged=True)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);ap.add_argument('--only',default='probes,Main');a=ap.parse_args();assert not a.output.exists();old=A.scoped_load(OLD/'candidate.nes');b=A.scoped_load(O/'candidate.nes');d=dict(passed=False,native=False,checks={})
 try:
  for name in a.only.split(','):d['checks'][name]=(probes if name=='probes'else main_differential)(old,b)
  d['passed']=True
 except Exception as e:d.update(failure=repr(e),traceback=traceback.format_exc())
 d['bindings']={str(p.resolve()):A.sha(p)for p in[Path(__file__),Path(H.__file__),OLD/'candidate.nes',OLD/'candidate.dbg',O/'candidate.nes',O/'candidate.dbg']};a.output.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(passed=d['passed'],checks=list(d['checks']),failure=d.get('failure'))));assert d['passed']
if __name__=='__main__':main()
