"""Actual verified C2 body permutation and native phase fairness controls."""
from pathlib import Path
import argparse,collections,itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import arthur_probe_fast_controls_v1 as C
import arthur_shadow_ownership_controls_v2 as T
from verify_native_relocation import NesMPU
from check_tmnt_render_oa import address,location
A=C.A;P=R/'build/arthur-host-render-fast-v1';O=R/'build/arthur-body-fair-v3'
sha=A.sha

def records(m):return [tuple(m[512+i*4:516+i*4])for i in range(64)]
def model(items,origin,n):
    out=list(items);pos=[(origin+i)%64 for i in range(n)];body=[items[i]for i in pos]
    source=[i for i in range(n)if i not in pos];holes=[i for i in pos if i>=n]
    assert len(source)==len(holes)
    for s,d in zip(source,holes):out[d]=items[s]
    out[:n]=body
    return out

def bare(q,p=0x30,sp=224,hook=None):
    q.m.raw_page(2,2);q.put(CurrentBankC=2);q.m.writes=[]
    c=NesMPU(memory=q.m,pc=address(q.b,'ArCacheBodyPriority'));c.p=p;c.sp=sp;c.stPushWord(0x5aff)
    low=c.sp;live=bytes(q.m[0x101+sp:0x200]);static=bytes(q.m[0x100:0x17b]);code=bytes(q.m.ram[2]);trace=[]
    for step in range(2000):
        if c.pc==0x5b00:break
        if hook:hook(q,c,step)
        low=min(low,c.sp);trace.append((c.pc,c.sp));assert q.m[c.pc];c.step()
    else:raise AssertionError(('priority timeout',c.pc))
    assert c.sp==sp and bytes(q.m[0x101+sp:0x200])==live
    assert bytes(q.m[0x100:0x17b])==static and bytes(q.m.ram[2])==code
    return c,trace,low

def permutation(b):
    q=C.prepare(b);rows=[];data=[((i*37)&255,i,(i*49)&255,(i*53)&255)for i in range(64)]
    cases=[(n,r,p)for n in range(12)for r in range(64)for p in [0x30,0x71,0xff]]
    flags=[0x30|sum(((v>>i)&1)*bit for i,bit in enumerate([1,2,4,8,64,128]))for v in range(64)]
    cases +=[(11,r,p)for r in range(64)for p in flags]
    for n,r,p in cases:
        q.m[512:768]=[v for z in data for v in z];q.put(ArDrawPage=n*4,ArLayoutPtr=r*4)
        c,tr,low=bare(q,p=p);actual=records(q.m)
        assert actual==model(data,r,n),('actual body permutation',n,r,p)
        assert collections.Counter(actual)==collections.Counter(data)and actual[:n]==[data[(r+i)%64]for i in range(n)]
        allowed={address(b,'ArDrawCount')}|set(range(512,768))|set(range(256,512))
        assert all(at in allowed for at,v in q.m.writes),('unowned writes',[(at,v)for at,v in q.m.writes if at not in allowed])
        assert c.p&12==p&12 and low>=0x7b
        rows.append([n,r,p,c.processorCycles,low])
    for n,r in [(45,0),(255,0),(1,0),(0,1),(44,1)]:
        q.m[512:768]=[v for z in data for v in z];q.put(ArDrawPage=n,ArLayoutPtr=r)
        bare(q);assert records(q.m)==data
    return dict(cases=len(rows),all64physical_origins=True,all0to11body_counts=True,maximum44body_stack_bytes=True,
                exact64record_permutation=True,no0300write=True,static_page1_and_C2_immutable=True,
                cycles=[min(z[3]for z in rows),max(z[3]for z in rows)],minimum_SP=min(z[4]for z in rows),rows=rows)

def fairness(b):
    q=C.prepare(b);rows=[];cases=0
    for used in range(1,64):
        q.put(RgOamUsed=used*4,RgOamFirst=0,SelectedCharacter=32);phases=[]
        for _ in range(used):
            A.call(q,'KbOamPriority');first=q.get('RgOamFirst')//4
            assert q.get('RgOamRotation')==(-first*4)&255
            phases.append(first)
        assert set(phases)==set(range(used)),('actual phase fails full cycle',used,phases)
        data=list(range(used))+[None]*(64-used)
        for n in range(1,min(11,used-1)+1):
            first_tail=[];ranks=collections.defaultdict(list)
            for first in phases:
                rotation=(-first)%64
                physical=[data[(i-rotation)%64]for i in range(64)]
                result=model(physical,rotation,n)
                assert result[:n]==list(range(n))
                first_tail.append(result[n]);cases+=1
                for rank,identity in enumerate(result[n:]):
                    if identity is not None:ranks[identity].append(rank)
            assert set(range(n,used))<=set(first_tail),('tail record starved first-tail priority',used,n,first_tail)
            assert all(min(ranks[i])==0 for i in range(n,used))
            rows.append([used,n,len(phases),len(set(first_tail)&set(range(n,used)))])
    return dict(actual_native_phase_calls=sum(range(1,64)),stable_partition_cycles=len(rows),partition_phase_cases=cases,
                every_live_tail_record_receives_first_tail_slot_in_full_cycle=True,
                global_rotation_and_RgOamFirst_unchanged=True,rows=rows,
                physical_limit='First-tail opportunity is fair among tail records. A body-only row using all8hardware slots leaves no physical tail capacity on that row; no claim can override that NES limit.')

def source_body(b):
    old=A.scoped_load(P/'candidate.nes');qa,qb=[C.prepare(v)for v in [old,b]]
    poses=sorted(int(z)for z in json.loads((R/'build/arthur-palette-leaf-v6/atlas-proof.json').read_text())['posemap']if int(z)<54)
    rows=[]
    for mode,pose in itertools.product(range(3),poses):
        for q in [qa,qb]:
            q.put(ArHostOldPage=mode,OperMode=1,GameEngineSubroutine=8,CurrentOAMOffset=0,
                  GuestOamRotationActive=1,RgOamRotation=0,ArR_0064=0,ArR_0065=1)
            for i in range(4):q.set('ArR_04F0',128 if i==0 else 0,i)
            for n,v in [('ArR_0522',pose),('ArR_05AF',104),('ArR_0583',1),('ArR_0599',200),('ArR_056D',0)]:q.set(n,v)
            q.m[512:768]=[248,0,0,0]*64
        A.owned(qa,'ArHostDraw');expected=records(qa.m)[:qa.get('CurrentOAMOffset')//4]
        palette=[15,54,24,18,15,26,48,39,15,22,48,39,15,15,54,23]
        pixels,occ,_=T.raster(qa,palette,False)
        for phase in range(64):
            qb.put(CurrentOAMOffset=0,RgOamRotation=phase*4)
            qb.m[512:768]=[248,0,0,0]*64
            A.owned(qb,'ArHostDraw');assert qb.get('ArDrawPage')==len(expected)*4
            c,tr,mn=A.call(qb,'ArCacheBodyOrder')
            assert records(qb.m)[:len(expected)]==expected,('complete source body order',mode,pose,phase)
            actual,crowd,lost=T.raster(qb,palette,True)
            assert actual==pixels and max(crowd.values(),default=0)<=8 and not lost,('source RGB alpha priority hardware8',mode,pose,phase)
            rows.append([mode,pose,phase,len(expected),c.processorCycles,mn])
    return dict(cases=len(rows),all47poses_3area_roles_64phases=True,original_body_OAM_and_source_RGB_alpha_priority=True,
                normal8sprite_body_pixels_complete=True,rows=rows)

GROUPS=dict(permutation=permutation,fairness=fairness,source_body=source_body)

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--only',default=','.join(GROUPS));a=p.parse_args()
    assert not a.output.exists();b=A.scoped_load(O/'candidate.nes');d=dict(passed=False,native=False,checks={},failures={})
    for n in a.only.split(','):
        try:d['checks'][n]=GROUPS[n](b)
        except Exception as e:d['failures'][n]=dict(error=repr(e),traceback=traceback.format_exc())
    d['passed']=not d['failures']
    paths=[Path(__file__),Path(C.__file__),Path(T.__file__),O/'candidate.nes',O/'candidate.dbg',O/'cache-final-link-proof.json',P/'candidate.nes',P/'candidate.dbg']
    d['bindings']={str(p.resolve()):sha(p)for p in paths};a.output.write_text(json.dumps(d,indent=2)+'\n')
    print(json.dumps(dict(passed=d['passed'],checks=list(d['checks']),failures=d['failures'])))
    assert d['passed']
if __name__=='__main__':main()
