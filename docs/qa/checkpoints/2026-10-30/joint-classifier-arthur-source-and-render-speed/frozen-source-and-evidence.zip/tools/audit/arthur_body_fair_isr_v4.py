"""All deepest-stack C2 cuts, genuine normal/lag NMI/IRQ and nested IRQ."""
from pathlib import Path
import argparse,copy,itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import arthur_body_fair_controls_v4 as F
import ff_ram3_execution_controls_v2 as E
from verify_native_relocation import NesMPU
from check_tmnt_render_oa import address
A=F.A;C=F.C;O=R/'build/arthur-body-fair-v3'
TEMPLATES={}

def scenario(b,origin=4,lag=255):
    # Capture one genuinely loaded/readback-verified scene, then shallow-clone
    # its CPU model and independent mutable arrays for each interruption cut.
    # The read-only2MB ROM/debug bundle is shared; no loader/preload shortcut
    # replaces the actual initial construction. No native emulator is used.
    if id(b)not in TEMPLATES:TEMPLATES[id(b)]=C.prepare(b)
    template=TEMPLATES[id(b)];q=copy.copy(template);q.m=copy.copy(template.m)
    for name,value in vars(template.m).items():
        if name=='bundle':continue
        if isinstance(value,list):setattr(q.m,name,[bytearray(x)if isinstance(x,bytearray)else x for x in value])
        elif isinstance(value,bytearray):setattr(q.m,name,bytearray(value))
    q.m.writes=[];q.m.ram_writes=[]
    q.put(ArDrawPage=44,ArLayoutPtr=origin,NmiDisable=lag,Sprite0HitDetectFlag=1,
        VRAM_Buffer_AddrCtrl=0,VRAM_Buffer1_Offset=0,VRAM_Buffer2_Offset=0,Local_eb=0x4d)
    q.m[512:768]=[(i*37+19)&255 for i in range(256)]
    q.m.raw_page(1,154);q.put(CurrentBank=154);q.m.raw_page(2,2);q.put(CurrentBankC=2)
    c=NesMPU(memory=q.m,pc=address(b,'ArCacheBodyPriority'));c.sp=224;c.a=83;c.x=155;c.y=23;c.p=0xf9;c.stPushWord(0x5aff)
    return q,c

def advance(q,c,n):
    for _ in range(n):assert q.m[c.pc];c.step()

def finish(q,c,expected,sp=224):
    for _ in range(2000):
        if c.pc==0x5b00:break
        assert q.m[c.pc];c.step()
    else:raise AssertionError('postISR priority return')
    assert (c.a,c.x,c.y,c.p,c.sp)==(83,155,23,0xf9,sp)
    assert F.records(q.m)==expected
    assert q.get('Local_eb')==77

def deepest(b):
    rows=[];nested=[]
    for origin in [4,44,212,252]:
        q,c=scenario(b,origin);steps=[]
        for n in range(2000):
            if c.pc==0x5b00:break
            steps.append((n,c.pc,c.sp));c.step()
        low=min(z[2]for z in steps)
        # Every instruction occurrence at the maximum48-byte added depth,
        # including all moves across full256B OAM and any prefix overlap.
        cuts=[(n,pc)for n,pc,sp in steps if sp==low]
        assert low==174 and cuts
        for n,pc in cuts:
            for kind,lag in [('IRQ',255),('NMI',255),('NMI',0)]:
                z,d=scenario(b,origin,lag);original=F.records(z.m);expected=F.model(original,origin//4,11)
                advance(z,d,n);assert d.pc==pc and d.sp==low
                before=bytes(z.m.ram[2]);meta=[z.get(x)for x in ['ArDrawPage','ArLayoutPtr','ArDrawCount']]
                proof=E.interrupt(z.m,d,kind)
                assert bytes(z.m.ram[2])==before and z.get('Local_eb')==77
                assert [z.get(x)for x in ['ArDrawPage','ArLayoutPtr','ArDrawCount']]==meta
                assert proof['minimum_SP']>=0x7b,('real stack crosses actual static33SMC ceiling',origin,kind,lag,proof['minimum_SP'])
                finish(z,d,expected)
                rows.append(dict(origin=origin,foreground_step=n,PC=pc,foreground_SP=low,lag=lag,**proof))
        # Find the deepest genuinely IRQ-enabled instruction in this actual
        # normal NMI, then prove an actual IRQ there while48buffer bytes live.
        n,pc=cuts[0];z,d=scenario(b,origin,0);advance(z,d,n);eligible=[];saved=NesMPU.step
        def observe(cpu):
            if not cpu.p&4:eligible.append((cpu.pc,z.m.rawtags[(cpu.pc-0x8000)//8192]if cpu.pc>=0x8000 else-1,cpu.sp))
            saved(cpu)
        NesMPU.step=observe
        try:E.interrupt(z.m,d,'NMI')
        finally:NesMPU.step=saved
        assert eligible,'actual normal IRQ31 path must CLI'
        target=min(eligible,key=lambda x:x[2]);z,d=scenario(b,origin,0);expected=F.model(F.records(z.m),origin//4,11);advance(z,d,n);fired=[]
        def inject(cpu):
            key=(cpu.pc,z.m.rawtags[(cpu.pc-0x8000)//8192]if cpu.pc>=0x8000 else-1,cpu.sp)
            if not fired and key==target:
                fired.append(E.interrupt(z.m,cpu,'IRQ'))
            saved(cpu)
        NesMPU.step=inject
        try:proof=E.interrupt(z.m,d,'NMI')
        finally:NesMPU.step=saved
        assert len(fired)==1 and min(proof['minimum_SP'],fired[0]['minimum_SP'])>=0x7b
        finish(z,d,expected)
        nested.append(dict(origin=origin,actual_enabled_IRQ_cut=target,NMI=proof,IRQ=fired[0]))
    return dict(deepest_foreground_SP=174,maximum_body_buffer=44,register_save_bytes=4,
                real_vector_cases=len(rows),nested_actual_IRQ_in_normal_NMI=len(nested),
                minimum_real_SP=min([z['minimum_SP']for z in rows]+[z['IRQ']['minimum_SP']for z in nested]),
                Local_eb_0106_and_all33SMC015A_to017B_and_live_buffer_preserved=True,
                all64OAM_records_exact_permutation_after_ISR=True,rows=rows,nested=nested)

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);a=p.parse_args();assert not a.output.exists()
    b=A.scoped_load(O/'candidate.nes');d=dict(passed=False,native=False)
    try:d['checks']=deepest(b);d['passed']=True
    except Exception as e:d.update(error=repr(e),traceback=traceback.format_exc())
    paths=[Path(__file__),Path(F.__file__),Path(E.__file__),O/'candidate.nes',O/'candidate.dbg',O/'cache-final-link-proof.json']
    d['bindings']={str(p.resolve()):A.sha(p)for p in paths};a.output.write_text(json.dumps(d,indent=2)+'\n')
    print(json.dumps({k:v for k,v in d.items()if k not in ['bindings','checks']}));assert d['passed']
if __name__=='__main__':main()
