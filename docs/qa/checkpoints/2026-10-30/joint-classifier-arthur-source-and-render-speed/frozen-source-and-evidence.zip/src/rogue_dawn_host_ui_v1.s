; PRIVATE native-font menu/status and source-scaled HUD. Existing11 cells,
; caches only under exact raw2/RdVariant1; never legacy inventory/font lease.
.include "ui-imports.inc"
.include "inc/charmap.inc"
.segment "ROGUE_DAWN_HOST_AUX"
.export RdUiStart,RdUiEnd,RdUiName,RdUiStatus,RdUiLateReset,RdUiEarly
RdUiStart:
; A regular NMI consumes the packet; a lag NMI leaves it pending. Before
; ANY new Main producer, retract only our sole complete, cache-matching
; command and retry dirty at the late boundary. X/Y are dead at this one
; real caller (immediate LDX0/LDY7); A/P are retained, foreign ABI exact.
.proc RdUiEarly
 php
 pha
 jsr WxEnabled
 bcc Foreign
 jsr Retract
 pla
 plp
 rts
Foreign:pla
 plp
 WxTail RdLifeUi
Retract:
 lda VRAM_Buffer1_Offset
 cmp #14
 bne Done
 ldx #8
Check:ldy Offsets,x
 lda VRAM_Buffer1,y
 cmp Values,x
 bne Done
 dex
 bpl Check
 lda InvHudName+1
 lsr
 lsr
 lsr
 lsr
 cmp VRAM_Buffer1+4
 bne Done
 lda InvHudName+1
 and #15
 cmp VRAM_Buffer1+5
 bne Done
 lda InvHudName
 lsr
 lsr
 lsr
 lsr
 cmp VRAM_Buffer1+6
 bne Done
 ldx VRAM_Buffer1+9
 cpx #3
 bcs Done
 ldy VRAM_Buffer1+10
 cpy #10
 bcs Done
 lda VRAM_Buffer1+11
 cmp #10
 bcs Done
 clc
 adc Tens,y
 adc Hundreds,x
 bcs Done
 cmp InvHudAmmo
 bne Done
 lda #0
 sta VRAM_Buffer1
 sta VRAM_Buffer1_Offset
 lda #1
 sta InvDirty
Done:rts
Offsets:.byte 0,1,2,3,7,8,12,13,14
Values:.byte $20,$23,11,$0e,$24,$16,$24,$24,0
Tens:.byte 0,10,20,30,40,50,60,70,80,90
Hundreds:.byte 0,100,200
.endproc
.proc RdUiName
 php
 pha
 jsr WxEnabled
 bcc Foreign
 pla
 plp
 ldx VRAM_Buffer1_Offset
 lda #$23
 sta VRAM_Buffer1,x
 lda #<X5MenuNameAddress
 sta VRAM_Buffer1+1,x
 lda #16
 sta VRAM_Buffer1+2,x
 ldy #0
Loop:lda Name,y
 sta VRAM_Buffer1+3,x
 inx
 iny
 cpy #16
 bne Loop
 inx
 inx
 inx
 stx VRAM_Buffer1_Offset
 lda #0
 sta VRAM_Buffer1,x
 rts
Foreign:pla
 plp
 WxTail NrQueueSelectName
Name:.byte "   ROGUE DAWN   "
.endproc
.proc RdUiStatus
 php
 pha
 jsr WxEnabled
 bcc Foreign
 pla
 plp
 cmp #0
 bne Done
 tya
 pha
 ldy #6
Loop:lda Name,y
 sta VRAM_Buffer1+11,y
 dey
 bpl Loop
 pla
 tay
 lda #0
Done:rts
Foreign:pla
 plp
 WxTail NrStatusName
Name:.byte "ROGUE  "
.endproc

; Original ResetPalStar exactly once. This is after native timer/score,
; actors/blocks/misc and ColorRotation. Only later producer is area parser;
; reject its two genuine pending conditions as well as all existing queues.
; Future SMB2/Goku union MUST have one real late dispatcher, not overlay
; their standalone18B target bindings on each other.
.proc RdUiLateReset
 WxFar ResetPalStar
 php
 pha
 txa
 pha
 tya
 pha
 jsr WxEnabled
 bcc Done
 jsr RdUiHud
Done:pla
 tay
 pla
 tax
 pla
 plp
 rts
.endproc

.proc RdUiHud
 lda OperMode
 cmp #1
 jne Done
 lda GameEngineSubroutine
 cmp #8
 jne Done
 lda GamePauseStatus
 and #1
 jne Done
 lda DisableScreenFlag
 ora TimerControl
 ora VRAM_Buffer_AddrCtrl
 ora VRAM_Buffer1_Offset
 ora VRAM_Buffer2_Offset
 ora VRAM_Buffer1
 ora VRAM_Buffer2
 ora ReloadCHRBank
 ora RdColorRequest
 ora SmFreezePalettePending
 ora InvHudActive
 ora StarInvincibleTimer
 ora GuestPowerupActive
 ora PlayerChangeSizeFlag
 ora AreaParserTaskNum
 jne Done
 lda ScrollThirtyTwo
 cmp #32
 jcs Done
 lda InvDirty
 bne Write
 lda RdHealthHi
 cmp InvHudName+1
 bne Write
 lda RdHealthLo
 and #$f0                      ; fractional0.7 heat does not dirty a full unit
 cmp InvHudName
 bne Write
 lda RdMissiles
 cmp InvHudAmmo
 jeq Done
Write:
 ; At this actual late admission there is exactly one14B command and no
 ; later native producer. Cache acknowledgement is AFTER complete packet.
 ldx #0
 lda #$20
 sta VRAM_Buffer1,x
 lda #$23
 sta VRAM_Buffer1+1,x
 lda #11
 sta VRAM_Buffer1+2,x
 lda #$0e                     ; native charmap E
 sta VRAM_Buffer1+3,x
 lda RdHealthHi
 lsr
 lsr
 lsr
 lsr
 sta VRAM_Buffer1+4,x
 lda RdHealthHi
 and #15
 sta VRAM_Buffer1+5,x
 lda RdHealthLo
 lsr
 lsr
 lsr
 lsr
 sta VRAM_Buffer1+6,x
 lda #$24
 sta VRAM_Buffer1+7,x
 sta VRAM_Buffer1+12,x
 sta VRAM_Buffer1+13,x
 lda #$16                     ; native charmap M
 sta VRAM_Buffer1+8,x
 lda RdMissiles
 ldy #0
Hundreds:
 cmp #100
 bcc Tens
 sbc #100
 iny
 bne Hundreds
Tens:
 sty VRAM_Buffer1+9
 ldy #0
Ten:
 cmp #10
 bcc Ones
 sbc #10
 iny
 bne Ten
Ones:
 sty VRAM_Buffer1+10
 sta VRAM_Buffer1+11
 lda #0
 sta VRAM_Buffer1+14
 lda #14
 sta VRAM_Buffer1_Offset
 lda RdHealthHi
 sta InvHudName+1
 lda RdHealthLo
 and #$f0
 sta InvHudName
 lda RdMissiles
 sta InvHudAmmo
 lda #0
 sta InvDirty
Done:rts
.endproc
RdUiEnd:
.assert * <= $be00,error,"Protect source item/drop descriptors"
