; PRIVATE actual outer-NMI composition. Frozen Rogue/S2 leaves stay literal.
; Included after the true SMB2 v8 adapter in the same real source assembly.
; A63 B600..B7FF is ROOT's conditional common lease; actual fit/audit required.
.macro S2CFar Target,ExplicitBank
 sta SafecallA_SMC+1
 lda #<Target
 sta FarcallJmpTarget_SMC+1
 lda #>Target
 sta FarcallJmpTarget_SMC+2
 .ifblank ExplicitBank
 .assert .bank(Target)<128,lderror,"true cold target bank exceeds PRG encoding"
 lda #<(.bank(Target)|$80)
 .else
 lda #(ExplicitBank|$80)
 .endif
 jsr FarCallCommon
.endmacro
S2CommonSmc=RgAudioCpuZp+155
S2CommonCommit=$5fb6
.macro S2CommonSaveSmc
 lda NextBank_SMC+1
 sta S2CommonSmc
 lda SafecallA_SMC+1
 sta S2CommonSmc+1
 lda FarcallJmpTarget_SMC+1
 sta S2CommonSmc+2
 lda FarcallJmpTarget_SMC+2
 sta S2CommonSmc+3
 lda SafereturnA_SMC+1
 sta S2CommonSmc+4
.endmacro
.macro S2CommonRestoreSmc
 lda S2CommonSmc
 sta NextBank_SMC+1
 lda S2CommonSmc+1
 sta SafecallA_SMC+1
 lda S2CommonSmc+2
 sta FarcallJmpTarget_SMC+1
 lda S2CommonSmc+3
 sta FarcallJmpTarget_SMC+2
 lda S2CommonSmc+4
 sta SafereturnA_SMC+1
.endmacro

.pushseg
.segment "SMB2_COMMON_NMI"
.export S2FamilyNmiGate,S2FamilyDmcStatus,S2CommonStart,S2CommonEnd
S2CommonStart:
.assert S2CommonStart=$b600,lderror,"approved common NMI preimage moved"
.proc S2FamilyNmiGate
 ; The genuine resident manual-map prefix has saved oldA on the real stack.
 ; No S2 image/cache/overlay read occurs before raw25 or actual oldowner25.
 lda RgAudioCharacter
 cmp #25
 bne Check
 lda CrossoverMenuState
 cmp #8
 beq Retire
 lda OperMode
 beq Retire
 lda SelectedCharacter
 cmp #25
 beq Check
Retire:
 lda #$bf
 sta CurrentBank
 S2CommonSaveSmc
 S2CFar S2HostRetireNmi
 lda #$ff
 sta GuestAudioCharacter
 S2CommonRestoreSmc
 ; Restore the original software shadow before delegating the still-mapped
 ; A63 cold gate. IRQ preserves this deliberate shadow/hardware gap exactly.
 pla
 sta CurrentBank
 pha
Check:
 lda CrossoverMenuState
 cmp #8
 jeq Foreign
 lda OperMode
 jeq Foreign
 lda SelectedCharacter
 cmp #25
 jne Foreign
 lda #$bf
 sta CurrentBank
 S2CommonSaveSmc
 lda S2CommonCommit
 and #1
 sta S2CommonCommit           ; retire Rogue's count, preserve actual busy.
 lda S2Ready
 cmp #$b2
 jne Cold
 lda GuestAudioCharacter
 cmp #25
 beq Tick
 lda S2CommonCommit
 bne Cold                    ; no stale or half-built S2 audio acquisition.
 S2CFar S2CommonAcquire
 lda RgAudioCharacter
 cmp #25
 bne Cold
 lda #25
 sta GuestAudioCharacter     ; true initialized owner committed LAST.
Tick:
 ; Current NmiDisable was already rearmed by normal NMI. The genuine outer
 ; AudioUpdate JSR return is authoritative: normal E3FA pushes E3FC, lag
 ; E375 pushes E377. The manual prefix saved oldA above those two bytes.
 tsx
 lda $0102,x
 cmp #$fc
 bne LagTick
 lda $0103,x
 cmp #$e3
 bne LagTick
 lda #0
 beq SourceTick
LagTick:
 lda #1
SourceTick:
 S2CFar S2HostNmiTick         ; clock + exact source driver once/outer NMI.
 S2CFar S2CommonFrame
Done:
 S2CommonRestoreSmc
 pla
 sta CurrentBank
 pha
 jmp $f0ce                   ; genuine FixedAudioRestore, immutable contract.
Cold:
 lda #0
 sta $4015                   ; unstable context is explicitly muted, no DAC.
 sta $5015
 jmp Done
Foreign:
 jmp RdsNmiGate              ; no second Rogue tick, original foreign path.
.endproc

; Genuine resident ED0A replacement saves inputA then oldA and maps63.
; Its ED1A return restores oldA/hardware then PLA statusA/RTS. No shared
; farcall SMC is touched by this public status route, including foreign calls.
.proc S2FamilyDmcStatus
 php
 txa
 pha
 lda RgAudioCharacter
 cmp #25
 bne Legacy
 lda S2AudioActiveBank
 beq Off
 lda $4015
 and #$10
 bne Busy
 lda #$ff
 sta $5117
 lda #0
 sta S2AudioActiveBank
 beq Off
Legacy:
 lda BassDmcActive
 beq Off
 lda $4015
 and #$10
 bne Busy
 jsr Cv3DmcEndedGate         ; genuine legacy completion, not a copied stub.
Off:
 tsx
 lda $0104,x
 and #15
 jmp Store
Busy:
 tsx
 lda $0104,x
 ora #$10
Store:
 sta $0104,x
 pla
 tax
 plp
 jmp S2CommonDmcReturn       ; true fixed return emitted inside old29B span.
.endproc
S2CommonEnd:
.assert S2CommonEnd<=$b800,lderror,"common NMI exceeds approved512B"
.popseg

; S2's already-approved A74 append tail, after immutable v8 endBEA1.
; Internal NMI-only helpers may clobber AXY; outer real NMI owns those saves.
.pushseg
.segment "KIRBY_ABILITIES"
.export S2CommonAcquire,S2CommonFrame,S2CommonHelpersStart,S2CommonHelpersEnd
S2CommonHelpersStart:
.assert S2CommonHelpersStart=S2HostAudioEnd,lderror,"S2 owned helper append moved"
.proc S2CommonAcquire
 ; Real old DMC/CV3 owner retirement precedes any 512B image replacement.
 ; Deliberately do not call GuestAudioBegin: it invents a4011 reset for S2.
 S2CFar Cv3DmcResetOwner
 lda #0
 sta BassAudioPreviousMask
 sta BassAudioLastDeath
 sta BassAudioLastGround
 sta GuestMixMask
 sta GuestMixPreviousMask
 sta GuestNativeEnable
 sta GuestCombinedEnable
 sta $5010
 sta $5015
 sta GuestSweepDivider
 sta GuestSweepReload
 sta GuestSweepControl
 sta Square1SoundBuffer
 sta Square2SoundBuffer
 sta NoiseSoundBuffer
 sta PauseSoundBuffer
 ldx #15
Clear:
 sta GuestNativeApu,x
 sta GuestFxApu,x
 sta BassAudioSfxApu,x
 sta GuestNativeDirty,x
 sta GuestFxDirty,x
 dex
 bpl Clear
 lda #$ff
 ldx #15
Invalidate:
 sta GuestApuLast,x
 dex
 bpl Invalidate
 jsr S2HostAcquireNmi
 rts
.endproc

.proc S2CommonFrame
 ; Native world-only SFX remain independent of the authentic three STA cues.
 ; Clock/effect callbacks have already run exactly once at S2HostNmiTick.
 lda Square1SoundQueue
 and #$42
 sta GuestWorldQueues
 lda Square2SoundQueue
 and #$7f
 sta GuestWorldQueues+1
 lda NoiseSoundQueue
 and #1
 sta GuestWorldQueues+2
 lda GamePauseStatus
 and #1
 bne Paused
 S2CFar GuestAudioFinishTick,29
 jmp Ack
Paused:
 ; Source pause41 retains its real music/effect schedule and4015mask0C.
 ; Only shared SMB effects are muted/reset. Never invent a4011 write.
 lda #0
 sta $5015
 sta GuestMixMask
 sta GuestMixPreviousMask
 sta Square1SoundBuffer
 sta Square2SoundBuffer
 sta NoiseSoundBuffer
 lda GuestNativeEnable
 sta GuestCombinedEnable
 sta $4015
 lda #$ff
 ldx #15
Invalidate:
 sta GuestApuLast,x
 dex
 bpl Invalidate
 S2CFar GuestAudioNativeFlush
Ack:
 lda #0
 sta Square1SoundQueue
 sta Square2SoundQueue
 sta NoiseSoundQueue
 sta PauseSoundQueue
 sta AreaMusicQueue
 sta EventMusicQueue
 rts
.endproc
S2CommonHelpersEnd:
.assert S2CommonHelpersEnd<=$c000,lderror,"S2 helpers exceed actual A74 spare tail"
.popseg
