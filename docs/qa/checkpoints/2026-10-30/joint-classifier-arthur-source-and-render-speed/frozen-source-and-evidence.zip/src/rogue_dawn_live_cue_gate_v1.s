; Exact-owner RdHostDispatch gates BEFORE either public target.
.pushseg
.segment "ROGUE_DAWN_HOST"
.import RdaLowHealth
.export RdCueLowHealthGate,RdCueHealthGate,RdCueGateEnd
RdCueLowHealthGate:
 clc
RdCueHealthGate:
 php
 farcall RdaLowHealth
 plp
 rts
RdCueGateEnd:
.assert RdCueGateEnd<=$bf00,lderror,"Live cue gate overlaps death descriptors"
.popseg
