; PRIVATE menu/lives metadata on exact Samus2/Rogue1 only.
.pushseg
.segment "ROGUE_DAWN_HOST"
.export RdUiGateStart,RdUiGateEnd,RdUiToggle,RdUiPortrait
RdUiGateStart:
.proc RdUiToggle
 php
 pha
 lda SelectedCharacter
 cmp #2
 bne Foreign
 lda CrossoverMenuPressed
 and #Select_Button
 beq Foreign
 lda RdVariant
 eor #1
 and #1
 sta RdVariant
 lda #0
 sta InvHudActive
 sta RdSourceAltPalette        ; QueueSelection colors precede portrait
 sta RdMissileMode             ; transient preview selector, no ammo grant
 ldx #3
Loop:
 lda InvDropKind,x
 cmp #$80
 beq Clear
 cmp #$81
 beq Clear
 cmp #$89
 bne Next                     ; only private80/81/89, never legacy/unknown
Clear:
 lda #0
 sta InvDropKind,x
Next:dex
 bpl Loop
 lda #1
 sta InvDirty
 sta ReloadCHRBank
 pla
 plp
 sec
 rts
Foreign:pla
 plp
 farcall NrMenuToggle,jmp
.endproc

; The true raw2 branch is direct SamusPortrait, not NrPortrait. Portrait
; pose is metadata only: no movement tick or health/ammo/gear/newlife seed.
.proc RdUiPortrait
 php
 pha
 jsr RdHostEnabled
 bcc Foreign
 pla
 plp
 lda #8
 sta RdAnimFrame
 lda #0
 sta RdFacing
 sta RdSourceAltPalette
 farcall RdRenderPlayer
 jmp RdBodyPublishChr
Foreign:pla
 plp
 farcall SamusPortrait,jmp
.endproc
RdUiGateEnd:
.assert * <= $bf00,error,"Protect root death descriptors"
.popseg
