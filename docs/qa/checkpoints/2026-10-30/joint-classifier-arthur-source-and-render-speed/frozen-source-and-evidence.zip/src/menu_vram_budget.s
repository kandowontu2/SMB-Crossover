; PRIVATE template: foreground character-selection queue only.
; No new RAM. R0/R1 and complete caller registers/status are restored.
.if ::ENABLE_MMC5_EXPANDED && ::MAPPER_MMC5
.pushseg
.segment "MENU_VRAM_BUDGET"
.proc MenuPreviewBudget
 jsr DrawSelectionPreview
 php
 pha
 txa
 pha
 tya
 pha
 lda R0
 pha
 lda R1
 pha
 lda OperMode
 jne Restore
 lda CrossoverMenuState
 cmp #2
 jne Restore
 lda VRAM_Buffer_AddrCtrl
 jne Restore
 jsr MenuQueueValidate
 jcc Restore
 jsr MenuRemoveHint
 jsr MenuDropShadowPalette
 jsr MenuMergePaletteRuns
Restore:
 pla
 sta R1
 pla
 sta R0
 pla
 tay
 pla
 tax
 pla
 plp
 rts
.endproc

; Exact supported native menu command shapes. Reject unknown palette owners,
; especially0C/1C, rather than filling an unproved palette hole.
.proc MenuQueueValidate
 lda VRAM_Buffer1_Offset
 cmp #84
 jcs Invalid
 ldx #0
Loop:
 cpx VRAM_Buffer1_Offset
 jeq End
 jcs Invalid
 lda VRAM_Buffer1,x
 jeq Invalid
 cmp #$3f
 bne NonPalette
 lda VRAM_Buffer1+1,x
 cmp #$10
 beq Body
 cmp #$11
 beq Three
 cmp #$19
 beq Three
 cmp #$1d
 jne Invalid
Three:
 lda VRAM_Buffer1+2,x
 cmp #3
 jne Invalid
 beq Advance
Body:
 lda VRAM_Buffer1+2,x
 cmp #1
 beq Advance
 cmp #4
 jne Invalid
 beq Advance
NonPalette:
 cmp #$20
 beq Cursor
 cmp #$21
 beq Cursor
 cmp #$23
 jne Invalid
 lda VRAM_Buffer1+1,x
 cmp #$28
 bne Hint
 lda VRAM_Buffer1+2,x
 cmp #16
 jne Invalid
 beq Advance
Hint:
 cmp #$46
 jne Invalid
 lda VRAM_Buffer1+2,x
 cmp #20
 jne Invalid
 beq Advance
Cursor:
 lda VRAM_Buffer1+2,x
 cmp #1
 jne Invalid
Advance:
 tay
 inx
 inx
 inx
Bytes:
 inx
 dey
 bne Bytes
 jmp Loop
End:
 lda VRAM_Buffer1,x
 bne Invalid
 sec
 rts
Invalid:
 clc
 rts
.endproc

; Final native preview3F11/3 overwrites all earlier11..13 writes. Remove
; an earlier full3F11/3 or trim only shadowed colors from3F10/4, keeping10.
.proc MenuDropShadowPalette
 lda VRAM_Buffer1_Offset
 cmp #6
 bcc Done
 sec
 sbc #6
 sta R0
 tax
 lda VRAM_Buffer1,x
 cmp #$3f
 bne Done
 lda VRAM_Buffer1+1,x
 cmp #$11
 bne Done
 lda VRAM_Buffer1+2,x
 cmp #3
 bne Done
 ldx #0
Loop:
 cpx R0
 bcs Done
 lda VRAM_Buffer1,x
 cmp #$3f
 bne Next
 lda VRAM_Buffer1+1,x
 cmp #$11
 bne Partial
 lda VRAM_Buffer1+2,x
 cmp #3
 bne Next
 lda #6
 sta R1
 jmp MenuDeleteBytes
Partial:
 cmp #$10
 bne Next
 lda VRAM_Buffer1+2,x
 cmp #4
 bne Next
 lda #1
 sta VRAM_Buffer1+2,x
 inx
 inx
 inx
 inx
 lda #3
 sta R1
 jmp MenuDeleteBytes
Next:
 lda VRAM_Buffer1+2,x
 tay
 inx
 inx
 inx
Bytes:
 inx
 dey
 bne Bytes
 jmp Loop
Done:rts
.endproc

; Source selection page owns BG0C=$0F and validated menu palette writers never
; touch0C/1C. Fold1D/3 +19/3 to19/7 with that exact already-owned gap. Also
; fold truly adjacent10/1 +11/3 without filling any gap.
.proc MenuMergePaletteRuns
 ldx #0
Loop:
 cpx VRAM_Buffer1_Offset
 jcs Done
 lda VRAM_Buffer1,x
 cmp #$3f
 jne Next
 lda VRAM_Buffer1+1,x
 cmp #$10
 bne Gap
 lda VRAM_Buffer1+2,x
 cmp #1
 jne Next
 lda VRAM_Buffer1+4,x
 cmp #$3f
 jne Next
 lda VRAM_Buffer1+5,x
 cmp #$11
 jne Next
 lda VRAM_Buffer1+6,x
 cmp #3
 jne Next
 lda #4
 sta VRAM_Buffer1+2,x
 lda VRAM_Buffer1+7,x
 sta VRAM_Buffer1+4,x
 lda VRAM_Buffer1+8,x
 sta VRAM_Buffer1+5,x
 lda VRAM_Buffer1+9,x
 sta VRAM_Buffer1+6,x
 txa
 clc
 adc #7
 tax
 lda #3
 sta R1
 jsr MenuDeleteBytes
 ldx #0
 jmp Loop
Gap:
 cmp #$1d
 jne Next
 lda VRAM_Buffer1+2,x
 cmp #3
 jne Next
 lda VRAM_Buffer1+6,x
 cmp #$3f
 jne Next
 lda VRAM_Buffer1+7,x
 cmp #$19
 jne Next
 lda VRAM_Buffer1+8,x
 cmp #3
 jne Next
 lda VRAM_Buffer1+3,x
 pha
 lda VRAM_Buffer1+4,x
 pha
 lda VRAM_Buffer1+5,x
 pha
 lda #$19
 sta VRAM_Buffer1+1,x
 lda #7
 sta VRAM_Buffer1+2,x
 lda VRAM_Buffer1+9,x
 sta VRAM_Buffer1+3,x
 lda VRAM_Buffer1+10,x
 sta VRAM_Buffer1+4,x
 lda VRAM_Buffer1+11,x
 sta VRAM_Buffer1+5,x
 lda #$0f
 sta VRAM_Buffer1+6,x
 pla
 sta VRAM_Buffer1+9,x
 pla
 sta VRAM_Buffer1+8,x
 pla
 sta VRAM_Buffer1+7,x
 txa
 clc
 adc #10
 tax
 lda #2
 sta R1
 jsr MenuDeleteBytes
 ldx #0
 jmp Loop
Next:
 lda VRAM_Buffer1+2,x
 tay
 inx
 inx
 inx
Bytes:
 inx
 dey
 bne Bytes
 jmp Loop
Done:rts
.endproc

; Delete R1bytes at valid queue cursorX, including moving the real terminator.
.proc MenuDeleteBytes
 lda VRAM_Buffer1_Offset
 sec
 sbc R1
 sta VRAM_Buffer1_Offset
 txa
 clc
 adc R1
 tay
Loop:
 lda VRAM_Buffer1,y
 sta VRAM_Buffer1,x
 cpx VRAM_Buffer1_Offset
 beq Done
 inx
 iny
 jmp Loop
Done:rts
.endproc
.proc MenuRemoveHint
 ldx #0
Loop:
 cpx VRAM_Buffer1_Offset
 bcs Done
 lda VRAM_Buffer1,x
 cmp #$23
 bne Next
 lda VRAM_Buffer1+1,x
 cmp #$46
 bne Next
 lda VRAM_Buffer1+2,x
 cmp #20
 bne Next
 lda #23
 sta R1
 jmp MenuDeleteBytes
Next:
 lda VRAM_Buffer1+2,x
 tay
 inx
 inx
 inx
Bytes:
 inx
 dey
 bne Bytes
 jmp Loop
Done:rts
.endproc

; Retain the parent's transient queue/capacity decisions before preview.
; Only its originalshipinitial/direct and liveSelect-only cases skip writing.
.proc MenuHintQueuePolicy
 lda CrossoverMenuState
 cmp #2
 bne Original
 lda SelectedCharacter
 cmp #18
 bne Original
 lda DisableScreenFlag
 beq Live
 lda Mirror_PPUMASK
 and #$18
 bne Original
 lda NmiDisable
 bpl Original
 rts
Live:
 lda CrossoverMenuPressed
 cmp #Select_Button
 beq Done
Original:
 jmp PnMenuVariantHintGate::Original
Done:rts
.endproc

MenuStaticLegend:
 .byte "SELECT ALTERNATES   "
.popseg
.endif
