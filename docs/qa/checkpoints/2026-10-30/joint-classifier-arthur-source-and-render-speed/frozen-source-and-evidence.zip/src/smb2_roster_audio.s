; Authentic SMB2 audio SOURCE UNIT. No scheduler/mixer/Main publication hook.
; Public APIs are raw25 gated before every private-state read. SetQueue/Pause
; are AUDIO-CONSUMER-EXCLUSIVE interfaces, not a Main/NMI publication protocol.
S2AudioState=RgAudioRam
S2AudioZpState=RgAudioRam+52
S2AudioPause=RgAudioRam+64
S2AudioActiveBank=RgAudioRam+65
S2AudioPendingBank=RgAudioRam+66
S2AudioSavedC=RgAudioRam+67
S2AudioEnable=RgAudioRam+68
.pushseg
.segment "KIRBY_ABILITIES"
.res $29,$ff                 ; actual old endB157 -> approvedB180
.include "smb2_roster_audio_native.inc"
.macro S2ASave
 php
 pha
 txa
 pha
 tya
 pha
 lda SelectedCharacter
 cmp #25
 beq :+
 jmp S2AudioReturn
:
.endmacro
.proc S2AudioInit
 S2ASave
 jsr S2AudioInitialize
 jmp S2AudioReturn
.endproc
.proc S2AudioInitialize
 lda RgAudioCharacter
 cmp #25
 bne Clear
 jsr S2AudioCancelInner
Clear:
 lda #0
 ldx #68
Loop:sta S2AudioState,x
 dex
 bpl Loop
 lda #25
 sta RgAudioCharacter          ; initialized owner committed LAST
 rts
.endproc
.proc S2AudioEnsure
 lda RgAudioCharacter
 cmp #25
 bne S2AudioInitialize
 rts
.endproc
.proc S2AudioBorrow
 .repeat 12,I
 lda $bb+I
 sta RgAudioCpuZp+I
 lda S2AudioZpState+I
 sta $bb+I
 .endrepeat
 rts
.endproc
.proc S2AudioRelease
 .repeat 12,I
 lda $bb+I
 sta S2AudioZpState+I
 lda RgAudioCpuZp+I
 sta $bb+I
 .endrepeat
 rts
.endproc
.proc S2AudioTick
 S2ASave
 jsr S2AudioEnsure
 lda CurrentBankC
 sta S2AudioSavedC
 lda #$f5                    ; physical117, complete immutable data lease
 sta CurrentBankC
 sta $5116
 jsr S2AudioBorrow
 jsr S2AudioNativeEntry
 jsr S2AudioRelease
 lda S2AudioSavedC
 sta CurrentBankC
 sta $5116
 jmp S2AudioReturn
.endproc
.proc S2AudioSetQueue
 S2ASave
 jsr S2AudioEnsure
 tsx
 txa
 tay
 lda $0102,y                ; genuine saved inputX, before Ensure clobber
 tax
 cpx #6
 bcs Done
 lda $0103,y                ; genuine saved inputA
 sta S2AudioState+20,x       ; original0600..0605 exact assignment semantics
Done:jmp S2AudioReturn
.endproc
.proc S2AudioSetPause
 S2ASave
 jsr S2AudioEnsure
 tsx
 lda $0103,x
 beq Valid
 cmp #$41                   ; actual source Stack100_Pause discriminator
 bne Done
Valid:sta S2AudioPause
Done:jmp S2AudioReturn
.endproc
.proc S2AudioDmcAddressSTA
 php
 pha
 lda S2AudioSampleBank-1,y
 sta S2AudioPendingBank      ; no E switch before actual source stop
 lda S2AudioSampleStart-1,y
 sta $4012
 pla
 plp
 rts
.endproc
.proc S2AudioStatusSTA
 sta S2AudioEnable
 php
 pha
 and #$10
 bne Start
 pla
 sta $4015                  ; source stop occurs BEFORE E restoration
 pha
 lda S2AudioActiveBank
 beq Done
 lda #$ff
 sta $5117
 lda #0
 sta S2AudioActiveBank
 jmp Done
Start:
 lda S2AudioPendingBank
 ora #$80
 sta $5117                  ; original0F stop already completed
 and #$7f
 sta S2AudioActiveBank
 pla
 sta $4015                  ; exact original1F start AFTER alias selected
 pha
Done:pla
 plp
 rts
.endproc
.proc S2AudioStatusSTX
 php
 pha
 txa
 jsr S2AudioStatusSTA
 pla
 plp
 rts
.endproc
.proc S2AudioPollDmc
 S2ASave
 lda RgAudioCharacter
 cmp #25
 bne Done
 lda S2AudioActiveBank
 beq Done
 lda $4015
 and #$10
 bne Done
 lda #$ff
 sta $5117
 lda #0
 sta S2AudioActiveBank       ; no4011 store; final buffered bit/DAC may drain
Done:jmp S2AudioReturn
.endproc
.proc S2AudioCancelDmc
 S2ASave
 lda RgAudioCharacter
 cmp #25
 bne Done
 jsr S2AudioCancelInner
Done:jmp S2AudioReturn
.endproc
.proc S2AudioCancelInner
 lda S2AudioActiveBank
 beq Done
 lda S2AudioEnable
 and #15
 sta S2AudioEnable
 sta $4015                  ; stop first, preserve native low-channel mask
 lda #$ff
 sta $5117
 lda #0
 sta S2AudioActiveBank
Done:rts
.endproc
.proc S2AudioLeave
 S2ASave
 lda RgAudioCharacter
 cmp #25
 bne Done
 jsr S2AudioCancelInner
 lda #$ff
 sta RgAudioCharacter
Done:jmp S2AudioReturn
.endproc
S2AudioReturn:
 pla
 tay
 pla
 tax
 pla
 plp
 rts
.include "smb2_roster_audio_writers.inc"
S2AudioCodeEnd:
.assert S2AudioNativeEntry=$b180,lderror,"SMB2 approved A74 start changed"
.assert S2AudioCodeEnd<=$c000,lderror,"SMB2 audio exceeds A74 B180..BFFF"
.export S2AudioInit,S2AudioTick,S2AudioSetQueue,S2AudioSetPause,S2AudioPollDmc,S2AudioCancelDmc,S2AudioLeave
.export S2AudioBorrow,S2AudioRelease,S2AudioNativeEntry,S2AudioCodeEnd
.export S2AudioState,S2AudioZpState,S2AudioPause,S2AudioActiveBank,S2AudioPendingBank,S2AudioSavedC,S2AudioEnable
.segment "PARODIUS_ART"
.res $3e,$ff                ; actual old endC9C2 -> approvedCA00
.include "smb2_roster_audio_data.inc"
.assert S2AudioMusicData=$ca00,lderror,"SMB2 approved C117 start changed"
.assert S2AudioDataEnd<=$e000,lderror,"SMB2 audio exceeds C117 CA00..DFFF"
.export S2AudioMusicData,S2AudioNoiseView,S2AudioGrowingView,S2AudioNoiseTables,S2AudioDataEnd
.popseg
