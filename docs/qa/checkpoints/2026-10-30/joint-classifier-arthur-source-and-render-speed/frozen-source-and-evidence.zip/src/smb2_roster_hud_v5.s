; PRIVATE real-resource HUD and source-timer service. No new RAM/CHR.
.pushseg
.segment "PARODIUS_BELLS"
.export S2HudEarly,S2HudInvalidate,S2HudCoreBegin,S2HudCoreEnd
S2HudCoreBegin:
.proc S2HudEarly
 php
 pha
 lda SelectedCharacter
 cmp #25
 beq Own
 pla
 plp
 rts
Own:pla
 plp
 jsr S2MainUi                  ; retain its genuine A0/P and clear semantics.
 php
 pha
 txa
 pha
 tya
 pha
 jsr S2HudRetract
 pla
 tay
 pla
 tax
 pla
 plp
 rts
.endproc
.proc S2HudInvalidate
 ; Replaces only the original STA PaletteAck with this same-size JSR.
 ; Retract a complete still-pending owned packet BEFORE invalidating cache.
 php
 pha
 txa
 pha
 tya
 pha
 jsr S2HudRetract
 lda #$ff
 sta InvHudName
 pla
 tay
 pla
 tax
 pla
 plp
 sta S2PaletteAck
 rts
.endproc
.proc S2HudRetract
 lda SelectedCharacter
 cmp #25
 bne Done
 lda VRAM_Buffer1_Offset
 cmp #14
 bne Done
 ldx #11
Loop:ldy Offsets,x
 lda VRAM_Buffer1,y
 cmp Fixed,x
 bne Done
 dex
 bpl Loop
 lda InvHudName
 beq HP
 cmp #$40
 bcs Done
 lsr
 lsr
 lsr
 lsr
 clc
 adc #1
HP:cmp VRAM_Buffer1+5
 bne Done
 lda InvHudName+1
 cmp #3
 bcs Done
 clc
 adc #2
 cmp VRAM_Buffer1+10
 bne Done
 lda InvHudAmmo
 cmp #10
 bcs Done
 cmp VRAM_Buffer1+13
 bne Done
 lda #0
 sta VRAM_Buffer1
 sta VRAM_Buffer1_Offset
 lda #$ff
 sta InvHudName
Done:rts
Offsets:.byte 0,1,2,3,4,6,7,8,9,11,12,14
Fixed:.byte $20,$23,11,"HP MAX V",0
.endproc
.proc S2HudLate
 ; Actual original timer service runs locally before the HUD save.
 jsr S2MainEndTimers
 php
 pha
 txa
 pha
 tya
 pha
 lda NextBank_SMC+1
 pha
 lda SafecallA_SMC+1
 pha
 lda FarcallJmpTarget_SMC+1
 pha
 lda FarcallJmpTarget_SMC+2
 pha
 lda SafereturnA_SMC+1
 pha
 farcall S2HudPublish
 pla
 sta SafereturnA_SMC+1
 pla
 sta FarcallJmpTarget_SMC+2
 pla
 sta FarcallJmpTarget_SMC+1
 pla
 sta SafecallA_SMC+1
 pla
 sta NextBank_SMC+1
 pla
 tay
 pla
 tax
 pla
 plp
 rts
.endproc
S2HudCoreEnd:
.assert *<=$c000,lderror,"SMB2 HUD core exceeds freed menu tail"

.segment "CHEATS_FOUR"
.export S2HudPublish,S2HudLate
.export S2HudHostBegin,S2HudHostEnd
S2HudHostBegin:
.proc S2HudPublish
 lda SelectedCharacter
 cmp #25
 jne Done
 lda S2Ready
 cmp #$b2
 jne Done
 lda OperMode
 cmp #1
 jne Done
 lda GameEngineSubroutine
 cmp #8
 jne Done
 lda GamePauseStatus
 and #1
 jne Done
 lda DisableScreenFlag
 ora TimerControl
 ora VRAM_Buffer_AddrCtrl
 ora VRAM_Buffer1_Offset
 ora VRAM_Buffer1
 ora VRAM_Buffer2_Offset
 ora VRAM_Buffer2
 ora AreaParserTaskNum
 jne Done
 lda ScrollThirtyTwo
 cmp #32
 bcs Done
 lda S2Health
 cmp InvHudName
 bne Dirty
 lda S2MaxHealth
 cmp InvHudName+1
 bne Dirty
 lda S2Vegetables
 cmp InvHudAmmo
 beq Done
Dirty:
 ldx #13
Copy:lda Template,x
 sta VRAM_Buffer1,x
 dex
 bpl Copy
 lda S2Health
 beq HP
 lsr
 lsr
 lsr
 lsr
 clc
 adc #1
HP:sta VRAM_Buffer1+5
 lda S2MaxHealth
 clc
 adc #2
 sta VRAM_Buffer1+10
 lda S2Vegetables
 sta VRAM_Buffer1+13
 lda #0
 sta VRAM_Buffer1+14
 lda #14
 sta VRAM_Buffer1_Offset
 lda S2Health
 sta InvHudName
 lda S2MaxHealth
 sta InvHudName+1
 lda S2Vegetables
 sta InvHudAmmo                 ; acknowledge only this COMPLETE command.
Done:rts
Template:.byte $20,$23,11,"HP0 MAX0 V0"
.endproc
S2HudHostEnd:
.assert *<=$b800,lderror,"SMB2 host/HUD overlaps palette coalescer"
.popseg
