; PRIVATE authoritative GetPlayerColors invalidation, never a per-frame force.
.pushseg
.segment "CHEATS_FOUR"
.export S2HostForcePalette,S2PaletteLifecycleStart,S2PaletteLifecycleEnd
S2PaletteLifecycleStart:
.assert *=$afdc,lderror,"Use only the owned A63 tail after frozen HUD/gates"
.proc S2HostForcePalette
 php
 pha
 lda SelectedCharacter
 cmp #25
 beq Own
 pla
 plp
 rts
Own:
 pla
 plp
 lda #$ff
 sta S2PaletteAck
 farcall S2MainPalette,jmp     ; genuine A118 publisher; defer retains invalid.
.endproc
S2PaletteLifecycleEnd:
.assert *<=$b800,lderror,"Do not touch the following palette-coalescer owner"
.popseg
