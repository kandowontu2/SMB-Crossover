; PRIVATE successor: actual completed-Main source weapon ordering.
; Include after frozen lifecycle, before root BF00 death descriptors.
.pushseg
.segment "ROGUE_DAWN_HOST"
.export RdWxMovementPipeline,RdWxGateStart,RdWxGateEnd,RdWxBombNative,RdWxSpawn
RdWxGateStart:
; Exact owner was established at RdLifeMovement/RdLifeDeathTick before this
; internal target. Original callbacks/geometry/control and flush stay literal.
.proc RdWxMovementPipeline
 jsr RdTxMovementBegin
 lda CurrentBankC
 pha
 BankPRGC #94
 jsr RdHsImportPosition
 jsr RdHsClockBefore
 farcall RdWxPreStep
 farcall RdControlStep
 jsr RdHsExportPosition
 jsr RdTxMovementFlush
 jsr RdHsClockAfter
 pla
 BankPRGC a
 rts
.endproc

; Actual guarded service20 source spawn continuation. Literal old coordinate
; prefix, then a typed birth publication receipt in the inactive native
; Samus3B metadata alias. No extra stack depth at frozen ControlStepSP192.
; Source newly born records first animate/render in NEXT projectile pass.
.proc RdWxSpawn
 cpy #$d0
 beq Yes
 cpy #$e0
 beq Yes
 cpy #$f0
 bne No
Yes:
 tya
 tax
 lda RdX
 clc
 adc RdWeaponSpawnDX
 sta $5b7e,x
 lda #0
 bit RdWeaponSpawnDX
 bpl :+
 lda #$ff
:
 adc RdRoomHi
 sta $5b7c,x
 lda RdY
 clc
 adc RdWeaponSpawnDY
 sta $5b7d,x
 lda #$40
 cpx #$d0
 beq Slot0
 cpx #$e0
 beq Slot1
 sta SmBombBlocksDone+2
 jmp Published
Slot0:sta SmBombBlocksDone
 jmp Published
Slot1:sta SmBombBlocksDone+1
Published:
 lda $5b7c,x
 and #1
 sec
 rts
No:clc
 rts
.endproc

; Authentic source explosion cross phase, translated to actual SMB point
; block ownership. Existing Samus proxy type10 is a native BombPoint query,
; not an enemy hit/seed. Save the entire reused projectile descriptor before
; entering the genuine brick/question/claim/debris/reward consumer.
.proc RdWxBombNative
 lda RdBombTerrainPhase
 beq Done
 cmp #6
 bcs Done
 tay
 lda MmSlot
 pha
 lda MmBulletType
 pha
 lda MmBulletX
 pha
 lda MmBulletPage
 pha
 lda MmBulletY
 pha
 lda MmBulletDir
 pha
 ldx RdSlot
 lda RdWX,x
 clc
 adc DX,y
 sta MmBulletX
 lda DX,y
 bpl Positive
 lda #$ff
 bne Page
Positive:lda #0
Page:
 adc RdWHi,x
 sta MmBulletPage
 lda RdWY,x
 clc
 adc DY,y
 sta MmBulletY
 lda #1
 sta MmBulletDir
 lda #10
 sta MmBulletType
 lda #0
 sta MmSlot
 tax
 farcall MegaManWeapons::Blocks
 pla
 sta MmBulletDir
 pla
 sta MmBulletY
 pla
 sta MmBulletPage
 pla
 sta MmBulletX
 pla
 sta MmBulletType
 pla
 sta MmSlot
Done:rts
DX:.byte 0,0,0,0,$f0,$10
DY:.byte 0,0,$f0,$10,0,0
.endproc
RdWxGateEnd:
.assert * <= $bf00,error,"Do not consume root death/item descriptor tail"
.popseg
