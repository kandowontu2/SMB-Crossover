; PRIVATE bounded hazard admission. No menu/native or shared installation.
; Appended after frozen b95c A95 endBD0F, before root BF00 death records.
.pushseg
.segment "ROGUE_DAWN_HOST"
.export RdHzGateStart,RdHzGateEnd,RdHzInjury,RdHzFirebar,RdHzGrant
RdHzGateStart:
.proc RdHzInjury
 php
 pha
 jsr RdHostEnabled
 jcc Foreign
 pla
 plp
 ; Genuine ProcHammerObj's JSR return is still on the original stack:
 ; FarCallCommon's five bytes precede it. This is typed call ownership,
 ; never an active-Misc heuristic that can misclassify an enemy contact.
 tsx
 lda $103,x
 cmp #<(.bank(RunHSubs)|$80)
 bne Actor
 lda $106,x
 cmp #<(RunHSubs-1)
 bne Actor
 lda $107,x
 cmp #>(RunHSubs-1)
 bne Actor
 farcall RdHzHammer
 jcc Protected
 jmp Contact
Actor:
 ldx ObjectOffset
 cpx #5
 bcs Original
 lda Enemy_Flag,x
 cmp #1
 bne Original
 lda Enemy_State,x
 and #$20
 bne Protected
 lda Enemy_ID,x
 cmp #$0c                     ; real Podoboo: authored source heat adapter
 beq Heat
 cmp #$15                     ; real Bowser flame
 beq Projectile
 cmp #$2d                     ; real front Bowser only
 beq Projectile
 cmp #$15
 bcs Original
 ; Source F2E8..F310 Screw protection precedes ordinary contact debit,
 ; including explicitly unarmed/armored native classes with no mapped HP.
 farcall RdControlScrew
 bcc Protected
 jmp RdLifeInjury
Projectile:
 farcall RdControlScrew
 bcc Protected                 ; genuine source air-spin/gear admission
 lda Player_X_Position
 sec
 sbc Enemy_X_Position,x
 lda Player_PageLoc
 sbc Enemy_PageLoc,x
 ldy #$20
 bmi Recoil
 ldy #$28
Recoil:tya
Contact:
 ldy GamePauseStatus
 iny
 dey
 bne Protected
 ldy RdHurtClock
 bne Protected
 ldy RdHit
 bmi Protected
 ; pending paid-contact bit20, independent of direction bit08
 pha
 lda RdHit
 and #$20
 bne Pending
 pla
 jmp RdLifeInjury::Hit          ; actual source8.0 BCD debit and native death
Pending:pla
Protected:sec
 rts
Heat:jmp RdHzHeat
Original:jmp RdLifeInjury
Foreign:pla
 plp
 jmp RdLifeInjury
.endproc

; Only the actual FirebarCollision InventoryHas5 call is rebound here.
; Return Cset after the typed heat owner so old Samus5 cannot mask Rogue.
.proc RdHzFirebar
 php
 pha
 jsr RdHostEnabled
 bcc Foreign
 pla
 plp
 jsr RdHzHeat
 sec
 rts
Foreign:pla
 plp
 farcall InventoryHas,jmp
.endproc

; Literal source E28D..E2A1 cadence/protection. Raw BCD07 is0.7 displayed
; energy, not seven whole HP. Suit halves this again at genuine CEAC owner.
; No Screw/hurt-flash immunity or invented room-state byte is applied.
.proc RdHzHeat
 lda GamePauseStatus
 and #1
 bne Done
 lda RdClock
 lsr
 and #3
 bne Done
 lda RdGear
 and #$20
 beq Damage
 bcc Done
Damage:
 lda #7
 ldy #0
 jsr RdHsDamage
 lda RdHealthLo
 and #$f0
 ora RdHealthHi
 bne Done
 jsr RdLifeBeginDeath
Done:sec
 rts
.endproc

; Source contact grants after a real mature-drop overlap. Original5/20energy
; and5missile values; real source arithmetic/caps/requests, no gear grants.
.proc RdHzGrant
 cmp #2
 beq Large
 jmp RdHsDropContact
Large:
 lda #0
 sta Rh6
 lda #2
 sta Rh7
 jsr RdHsAddBCD
 lda #$40
 ora RdSfx+1
 sta RdSfx+1
 sec
 rts
.endproc
RdHzGateEnd:
.assert * <= $bf00,error,"Protect root death descriptor BF00"
.popseg
