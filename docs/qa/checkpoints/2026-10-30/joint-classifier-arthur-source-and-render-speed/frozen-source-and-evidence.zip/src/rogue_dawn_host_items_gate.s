; PRIVATE successor to frozen56ee weapon unit. Native delivery stage is an
; explicit SMB adaptation, not source HP/body size. No automatic grant here.
.pushseg
.segment "ROGUE_DAWN_HOST"
.export RdItPrepare,RdItSyncStatus,RdItSyncLifecycle,RdItGateStart,RdItGateEnd
RdItGateStart:
.proc RdItPrepare
 jsr RdTxPrepareActor             ; genuine native constructor metadata only
 php
 pha
 jsr RdHostEnabled
 bcc Done
 cpx #6
 bcs Done
 lda InvPickupOwner,x
 cmp #2
 bne Done
 lda InvPickup,x
 cmp #$d0
 bcc Done
 cmp #$da
 bcs Done
 lda PowerUpType,x               ; preserve this actual slot's delivered raw
 cmp #2
 bcs Done
 sta InvPickupSaveLo,x
 lda #1                          ; stationary native Flower carrier, typed art
 sta PowerUpType,x               ; original Rogue item objects are stationary
Done:pla
 plp
 rts
.endproc

; All three actual source lifecycle APIs end at the old Dirty publication.
; Preserve that observed return ABI while deriving only the next SMB block's
; raw0/1 delivery status from already earned persistent source resources.
.proc RdItSyncLifecycle
 jsr RdBodyLifecycleDirty
 jmp RdItSyncStatus
.endproc
.proc RdItSyncStatus
 php
 pha
 jsr RdHostEnabled
 bcc Done
 lda RdTanks
 ora RdMaxMissiles
 ora RdGear
 beq Store
 lda #1
Store:sta PlayerStatus
Done:pla
 plp
 rts
.endproc
RdItGateEnd:
.assert * <= $bf00,error,"Protect fixed death descriptors atBF00"
.popseg
