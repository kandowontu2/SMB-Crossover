"""Freeze genuine combined frontend source and complete producer/consumer closure."""
from pathlib import Path
import hashlib,json,re,sys
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(R/'build/full-menu-source-controls-v2/support'))
from link_pit_rygar_sophia_audit_cpu import scoped_load,address,location
O=R/'build/dk-cf-roster-menu-qualified-v1';assert not O.exists();O.mkdir();J=R/'build/dk-cf-roster-menu-v3';A=R/'build/character-host-union-unlock-v3';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();files={Path(__file__)}
parents=[A/'handoff.json',J/'build-proof.json',R/'build/dk-cf-roster-menu-controls-v1/receipt.json',R/'build/dk-cf-roster-grid-lifecycle-v1/receipt.json',R/'build/contra-force-body-art-v6/manifest.json',R/'build/dk-ready-preview-qualified-v1/handoff.json']
for p in parents:
 d=json.loads(p.read_text());assert d.get('passed',True),p
 for f,h in d.get('bindings',{}).items():assert sha(f)==h,f
 files|={p}|set(map(Path,d.get('bindings',{})))
# ca65 escapes spaces in its actual full-dependency rule, not backslashes.
line=(J/'main.dep').read_text().splitlines()[0].split('\t',1)[1];deps=[]
for token in re.findall(r'(?:\\ |[^\s])+',line):
 p=Path(token.replace('\\ ',' '));p=p if p.is_absolute()else R/p;assert p.is_file(),p;deps.append(p.resolve())
files|=set(deps)
old,b=map(scoped_load,[A/'joint/candidate.nes',J/'candidate.nes']);raw=b['raw'];assert sha(J/'candidate.nes')=='ef759e21ea28de51c0ecd9ee93abdcbfe3f625dffd3c91385dcb6970a6318228'
def fields(s):return dict(re.findall(r'(\w+)=("[^"]*"|[^,]+)',s.split('\t',1)[1]))
fs={};lines={};syms={};segments={}
for line in(J/'candidate.dbg').read_text().splitlines():
 if line.startswith('file\t'):f=fields(line);fs[f['id']]=f['name'].strip('"')
 elif line.startswith('line\t'):f=fields(line);lines[f['id']]=f
 elif line.startswith('sym\t'):
  f=fields(line)
  if'ref'in f:syms[f['name'].strip('"')]=f
 elif line.startswith('seg\t'):f=fields(line);segments[f['name'].strip('"')]=f
moved=[]
for e in json.loads((A/'joint/source-closure.json').read_text())['moved_menu_only_global_PCs']:
 name=e['name'];refs=[]
 for idx in syms[name]['ref'].split('+'):
  rec=lines[idx];p=Path(fs[rec['file']]).resolve();assert p in set(deps),('Unrecompiled movedmenu consumer',name,p)
  ln=int(rec['line']);refs.append(dict(file=str(p),line=ln,source=p.read_text().splitlines()[ln-1].strip()))
 moved.append(dict(name=name,old=[(location(old,name)-16)//8192,address(old,name)],new=[(location(b,name)-16)//8192,address(b,name)],actual_recompiled_source_refs=refs))
assert len(moved)==7
ui=int(segments['FULL_ROSTER_MENU']['size'],0);assert ui<=1671
helper=address(b,'FmCfHelperEnd')-address(b,'FmCfHelperStart');assert helper==308 and address(b,'FmCfHelperStart')==0xb49b
assert old['raw'][16+29*8192+0x1fb0:16+29*8192+0x1fbd]==raw[16+29*8192+0x1fb0:16+29*8192+0x1fbd]
for folder in['dk-cf-roster-menu-v1','dk-cf-roster-menu-v2','dk-cf-roster-menu-v3','dk-cf-roster-menu-builder-v2','dk-cf-roster-menu-builder-v3','dk-cf-roster-menu-controls-v1','dk-cf-roster-grid-lifecycle-v1']:
 files|={p for p in(R/'build'/folder).rglob('*')if p.is_file()and'__pycache__'not in p.parts}
files|={R/'tools/audit/prepare_dk_cf_roster_menu_v2.py',R/'tools/audit/prepare_dk_cf_roster_menu_v3.py'}
report=dict(passed=True,native=False,status='FROZEN_COMBINED_AUTHENTIC_DK_CF_FRONTEND_SOURCE_CPU_PASS_NATIVE_PENDING',candidate=str(J/'candidate.nes'),candidate_sha256=sha(J/'candidate.nes'),parent_sha256=sha(A/'joint/candidate.nes'),
 compose=dict(source_root=str(J),entrypoint=str(J/'entrypoint.s'),include_first=str(J/'src'),build_commands=str(J/'build-proof.json'),cfg_and_other_objects='Exact frozen unlock-v3 e706 genuine link inputs; compile main with ownsrc first, retain all other linked objects.'),
 checks=dict(actual_menu_profiles=80,ready=52,pending=28,unchanged_other_profiles=75,CF_original_pixel_previews=4,CF_native_OAM_parts=5,DK_ready_OAM_parts=6,CF_to_all_other_identity_transitions=304,borrow_marker_all256values=True,gray_grid_pixels=384,actual_native_RLE_bytes=1024,cold_warm_title_palette_source_cases=2,
  CF_helper_bytes=helper,approved_helper_max=400,helper_PC=['B49B','B5CF'],fixed_Rush_reset_PC=['BFB0','BFBD'],fixed_Rush13B_exact=True,UI_bytes=ui,UI_lease=1671,UI_remaining=1671-ui,no_added_CHR_pages=True),
 palette=dict(CF_P0=[15,55,18,15],CF_P1=[15,55,22,15],borrow_marker='Existing FmGroups bit7 only; otherbits retained.',retirement='Actual next QueueSelection restores P1 via genuine resident GroundPaletteData+24=[1A,30,27], then native destination colors; fresh/warm title nativepalette selects same groundsource.',opaque_black_source_preserved=True),
 moved_menu_consumers=moved,actual_main_dependencies=len(set(deps)),
 negatives=['Initial helper preimage rejected false13Bprefix assumption; actual13B Rush leaf followsfill. First13FF retained, only308B atB49B used, originalRushleaf untouched.',
 'DK readyv1 pending index lost across mapping; actual80cases caught it, corrected prior to composition.',
 'CFv2 paletteborrow lacked P1 retirement; real Chip/Dale/TMNT consumer audit found it;v3 flag+nativeGroundsource restores304transitions.',
 'OriginalCFcapture timing/latePPUdebug/visible-screenshot phase negatives retained in authenticatedart lineage; no false sameframe claim.'],
 limits=['No native launch or installation of this source candidate. Root owns qualified KamaV1 skin composition and final80menu/Rogue cold verifier.',
  'CF remains visiblypending; authenticmenuart does not grant an unimplemented gameplay engine.',
  'FF/Arthur/Quick independent private gameplay leaves not composed; preserves qualified52ready rollout only.'],
 bindings={str(f.resolve()):sha(f)for f in sorted(files)})
(O/'handoff.json').write_text(json.dumps(report,indent=2)+'\n',newline='\n');print(json.dumps(dict(path=str(O/'handoff.json'),sha256=sha(O/'handoff.json'),bindings=len(files),actual_dependencies=len(set(deps)),UI=ui,ROM=sha(J/'candidate.nes'))))
