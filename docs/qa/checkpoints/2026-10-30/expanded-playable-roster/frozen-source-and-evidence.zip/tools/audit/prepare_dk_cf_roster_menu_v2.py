"""Preserve real Rush leaf after fill; confine helper to approved400B subset."""
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parents[2];A=R/'tools/audit/build_dk_cf_roster_menu_v1.py';s=A.read_text().replace("build/dk-cf-roster-menu-v1'","build/dk-cf-roster-menu-v2'")
s=s.replace("0x149b:16+29*8192+0x1fbd]==bytes([255])*0xb22","0x149b:16+29*8192+0x149b+400]==bytes([255])*400")
s=s.replace('0xb49b<int(fields[\'val\'],0)<0xbfbd','0xb49b<int(fields[\'val\'],0)<0xb62b')
s=s.replace('.assert * = $b49b,lderror,"Existing13B CHAR_SELECT wrapper moved"','.res $0d,$ff ; Retain first13B of old fill before granted helper start.\n.assert * = $b49b,lderror,"Approved menu helper start moved"')
s=s.replace('.res $b22-(FmCfHelperEnd-FmCfHelperStart),$ff','.res $b22-$0d-(FmCfHelperEnd-FmCfHelperStart),$ff').replace('.assert * = $bfbd,lderror,"Fixed Rush reset boundary moved"','.assert * = $bfb0,lderror,"Fixed Rush reset boundary moved"')
s=s.replace('16+29*8192+0x149b<=i<16+29*8192+0x1fbd','16+29*8192+0x149b<=i<16+29*8192+0x149b+400')
p=R/'tools/audit/build_dk_cf_roster_menu_v2_generated.py';assert not p.exists();p.write_text(s,newline='\n');O=R/'build/dk-cf-roster-menu-builder-v2';O.mkdir();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();(O/'derivation.json').write_text(json.dumps(dict(before=str(A),before_sha256=sha(A),after=str(p),after_sha256=sha(p),retained_negative='Full-span preimage rejected: fixed13B Rush leaf is AFTER old2850B filler, not before. New helper confined to approved400B B49B..<B62B; first13FF retained and padding reaches actualRushBFB0, originalleafBFB0..<BFBD unchanged.'),indent=2)+'\n',newline='\n');exec(compile(s,str(p),'exec'),{'__file__':str(p),'__name__':'__main__'})
