"""Restore the preserved explicit index after mapper calls; retain v1 negative."""
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parents[2];A=R/'tools/audit/build_dk_ready_preview_v1.py';s=A.read_text().replace("build/dk-ready-preview-v1'","build/dk-ready-preview-v2'")
needle="new=new.replace(' jsr FmPending\\n pha\\n cmp #17',' cmp #17',1)";assert s.count(needle)==1;s=s.replace(needle,"new=new.replace(' jsr FmPending\\n pha\\n cmp #17',' pla\\n pha\\n cmp #17',1)")
p=R/'tools/audit/build_dk_ready_preview_v2_generated.py';assert not p.exists();p.write_text(s,newline='\n');O=R/'build/dk-ready-preview-builder-v2';O.mkdir();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();(O/'derivation.json').write_text(json.dumps(dict(before=str(A),before_sha256=sha(A),after=str(p),after_sha256=sha(p),retained_negative='Actual80-case menu control caught pendingKarnov changed: newly explicit preview index was saved onstack but mapping loop overwrote A before dispatch. Add PLA/PHA to restore same index; preserve all failedsource/receipt.'),indent=2)+'\n',newline='\n');exec(compile(s,str(p),'exec'),{'__file__':str(p),'__name__':'__main__'})
