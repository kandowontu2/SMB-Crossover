"""Freeze source-ready DK frontend exception; root owns final Rogue composition."""
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parents[2];O=R/'build/dk-ready-preview-qualified-v1';assert not O.exists();O.mkdir();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();files={Path(__file__)}
parents=[R/'build/dk-ready-preview-v2/build-proof.json',R/'build/dk-ready-preview-controls-v3/receipt.json',R/'build/dk-roster-preview-qualified-v1/handoff.json']
for p in parents:
 d=json.loads(p.read_text());assert d['passed'],p
 for f,h in d.get('bindings',{}).items():assert sha(f)==h,f
 files|={p}|set(map(Path,d.get('bindings',{})))
base=R/'build/character-host-union-unlock-v1/handoff.json';d=json.loads(base.read_text())
for f,h in d['bindings'].items():assert sha(f)==h,f
files|={base}|set(map(Path,d['bindings']))
for leaf in['dk-ready-preview-v1','dk-ready-preview-v2','dk-ready-preview-builder-v2','dk-ready-preview-controls-v2','dk-ready-preview-controls-v3','dk-ready-controls-builder-v2']:
 files|={f for f in(R/'build'/leaf).rglob('*')if f.is_file()and'__pycache__'not in f.parts}
files|={R/'tools/audit/prepare_dk_ready_preview_v2.py',R/'tools/audit/prepare_dk_ready_controls_v2.py'}
rom=R/'build/dk-ready-preview-v2/candidate.nes';assert sha(rom)=='3ab44af2edf58cc598b74b9085d970e3aefeb4e56d0efd8654f6b3f4201620b7'
p=dict(passed=True,native=False,status='FROZEN_READY_DK_FRONTEND_SOURCE_CPU_PASS_NATIVE_PENDING',candidate=str(rom),candidate_sha256=sha(rom),
 compose_sources=['build/dk-ready-preview-v2/src/character_select.s','build/dk-ready-preview-v2/src/full_roster_menu.s','build/dk-ready-preview-v2/src/full_roster_menu_art.inc','build/dk-ready-preview-v2/pending-previews.chr'],
 API=dict(ready='Actual SelectedCharacter28 uses FmDrawDkPreview from genuine ready draw seam.',pending='Other pending entries still query real FmPending; same index saved/restored across map loop.',geometry='Six8x16 source parts with Hflip reuse, exact24x19 full idle, source white48/skin54/brown6.',exit='FmNativePrepare restores all borrowed windows/modes before ready foreign art.'),
 checks=dict(actual_menu_profiles=80,ready=52,pending=28,unchanged_other_profiles=79,DK_to_Proto_CHR_retirement=True,only_owned_menu_PRG_and_CHR_changed=True,additional_UI_bytes=50,remaining_UI_bytes=20),
 negatives=['v1 source lost explicit pending index A during mapping; actual KARNOV menu comparison caught it. v2 PLA/PHA restores saved index; all80pass.','Test helper import attempted old output preflight; successor loads immutable definitions without output side effect.'],
 limits=['Parent91b retains known Rogue service19 recursion negative; root composes identical frontend overlay atop qualified7e418 reset19 correction.',
  'Native actual menu picture still owed. This is frontend-only; no DK physics/admission change.',
  'Do not overwrite root separate Rogue preview character_select.s work; compose source patches at distinct readyDK seam.'],
 bindings={str(f.resolve()):sha(f)for f in sorted(files)})
(O/'handoff.json').write_text(json.dumps(p,indent=2)+'\n',newline='\n');print(json.dumps(dict(path=str(O/'handoff.json'),sha256=sha(O/'handoff.json'),bindings=len(files))))
