"""Apply the required genuine CV3 final-link producer, retaining v1 negative."""
from pathlib import Path
import hashlib,json,sys,shutil
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(R/'tools'))
from prepare_cv3_dmc_mirror import prepare
A=R/'build/full-roster-menu-v5';P=R/'build/dk-roster-preview-v1';O=R/'build/dk-roster-preview-v2';assert not O.exists();shutil.copytree(P,O)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
prepare(R,O/'candidate.nes')
a=(A/'candidate.nes').read_bytes();b=(O/'candidate.nes').read_bytes();changed=[i for i,(x,y)in enumerate(zip(a,b))if x!=y]
assert len(a)==len(b)==2097168
assert all(16+76*8192+0x1979<=i<16+77*8192 or 1048592+700*1024<=i<1048592+704*1024 for i in changed)
p=dict(passed=True,native=False,parent_sha256=sha(A/'candidate.nes'),candidate_sha256=sha(O/'candidate.nes'),
 source_producer=str(R/'tools/audit/build_dk_roster_preview_v1.py'),source_root=str(P),finalizer=str(Path(__file__)),
 retained_negative=dict(ROM=str(P/'candidate.nes'),reason='Initial source link omitted required postlink CV3 fixed-E mirror. Candidate rejected; unchanged source passed only after actual canonical mirror producer.'),
 only_menu_owned_PRG_and_preview_CHR_changed=True,other_entries_records_palette_and_opaque_patterns_exact=True,
 grid_CHR_nametable_exact=True,extra_UI_bytes=43,CHR_new_pairs=4,
 bindings={str(f.resolve()):sha(f)for f in[Path(__file__),R/'tools/audit/build_dk_roster_preview_v1.py',R/'tools/prepare_cv3_dmc_mirror.py',A/'source-closure.json',R/'build/roster-body-art-v1/donkey-kong-manifest.json',*[p for p in P.rglob('*')if p.is_file()],O/'candidate.nes',O/'candidate.lbl',O/'candidate.dbg',O/'candidate.cv3-mirror.json']})
(O/'build-proof.json').write_text(json.dumps(p,indent=2)+'\n',newline='\n');print(json.dumps(dict(ROM=sha(O/'candidate.nes'),proof_sha256=sha(O/'build-proof.json'),path=str(O/'build-proof.json'))))
