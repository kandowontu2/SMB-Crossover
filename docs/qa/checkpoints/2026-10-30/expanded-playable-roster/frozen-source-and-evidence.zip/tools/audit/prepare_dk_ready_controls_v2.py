"""Load immutable render helpers without rerunning their output-dir preflight."""
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parents[2];A=R/'tools/audit/dk_ready_preview_controls_v1.py';s=A.read_text();needle='import dk_roster_preview_controls_v1 as Q';assert s.count(needle)==1
s=s.replace(needle,"""import types
Q=types.ModuleType('immutable_dk_helper')
helper=R/'tools/audit/dk_roster_preview_controls_v1.py'
text=helper.read_text();text=text.replace(';assert not O.exists();O.mkdir();sha=T.sha',';sha=T.sha')
Q.__file__=str(helper);Q.__name__='immutable_dk_helper';exec(compile(text,str(helper),'exec'),Q.__dict__)""").replace("build/dk-ready-preview-controls-v1'","build/dk-ready-preview-controls-v2'")
p=R/'tools/audit/dk_ready_preview_controls_v2_generated.py';assert not p.exists();p.write_text(s,newline='\n');O=R/'build/dk-ready-controls-builder-v2';O.mkdir();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();(O/'derivation.json').write_text(json.dumps(dict(base=str(A),base_sha256=sha(A),successor=str(p),successor_sha256=sha(p),negative='v1 helper module import reran its old output directory preflight and rejected existing frozen receipt. Load helper definitions without that side-effect only; all product/assertion methods unchanged.'),indent=2)+'\n',newline='\n');exec(compile(s,str(p),'exec'),{'__file__':str(p),'__name__':'__main__'})
