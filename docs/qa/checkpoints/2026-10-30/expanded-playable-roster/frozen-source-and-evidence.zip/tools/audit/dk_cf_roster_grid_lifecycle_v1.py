"""Actual native RLE/title-ground palette source and exact gray cell proof."""
from pathlib import Path
import hashlib,json,sys,importlib.util
from PIL import Image
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'build/full-menu-source-controls-v2/support')];p=R/'build/full-menu-source-controls-v2/check.py';sp=importlib.util.spec_from_file_location('stable_menu',p);T=importlib.util.module_from_spec(sp);sp.loader.exec_module(T)
O=R/'build/dk-cf-roster-grid-lifecycle-v1';assert not O.exists();O.mkdir();N=R/'build/dk-cf-roster-menu-v3/candidate.nes';T.NEW=N;sha=T.sha;b=T.scoped_load(N)
rle=T.rle_case(b);a=(R/'build/full-roster-menu-v5/menu.nam').read_bytes();nt=(N.parent/'menu.nam').read_bytes();cells=[(16+y)*32+22+x for y in range(3)for x in range(2)];assert all(x==y or i in cells for i,(x,y)in enumerate(zip(a,nt)))
thumb=Image.open(R/'build/contra-force-body-art-v6/contra-force-burns-thumb16x24.png').convert('RGBA');raw=b['raw'];checked=0
for y in range(24):
 for x in range(16):
  t=nt[(16+y//8)*32+22+x//8];at=1048592+4096+t*16+y%8;v=(raw[at]>>(7-x%8)&1)|((raw[at+8]>>(7-x%8)&1)<<1);rr,gg,bb,aa=thumb.getpixel((x,y));wanted=0 if aa<128 else 1 if rr<95 else 2 if rr<200 else 3;assert v==wanted;(checked:=checked+1)
title=[]
for warm in [0,1]:
 a=T.fresh(b,30);a.m.page(1,66);a.m.page(2,64);a.put(CurrentBank=194,CurrentBankC=192,OperMode=0,OperMode_Task=0,SelectedCharacter=0,WorldNumber=7 if warm else 0,AreaNumber=3 if warm else 0)
 a.invoke('InitializeGame');assert a.get('WorldNumber')==0 and a.get('AreaNumber')==0 and a.get('AreaType')==1
 a.invoke('GetAreaPalette');ctrl=a.get('VRAM_Buffer_AddrCtrl');assert ctrl==2
 lo=raw[T.location(b,'VRAM_AddrTable_Low')+ctrl];hi=raw[T.location(b,'VRAM_AddrTable_High')+ctrl];assert lo+hi*256==T.address(b,'GroundPaletteData')
 at=T.location(b,'GroundPaletteData');assert raw[at:at+3]==bytes([63,0,32])and raw[at+24:at+27]==bytes([26,48,39])
 # Genuine forcedblank menu build clears every prior variant/borrow bit.
 a.put(CrossoverMenuState=1,CrossoverMenuIndex=0,Mirror_PPUMASK=0,DisableScreenFlag=1,NmiDisable=255,VRAM_Buffer1_Offset=0);a.m[0x5fe8]=255;a.m[0x5fe5]=255;a.invoke('CrossoverMenuInput');assert a.m[0x5fe8]==0 and a.m[0x5fe5]==0
 title.append(dict(warm=bool(warm),actual_native_world=0,actual_native_area=0,AreaType=1,actual_GetAreaPalette_VRAM_control=ctrl,actual_native_palette_pointer=lo+hi*256,P1=[26,48,39],actual_forcedblank_menu_clears_borrow_marker=True))
report=dict(passed=True,native=False,RLE=rle,gray_cell_pixels_exact=checked,only_CF_six_grid_cells_changed=cells,actual_title_lifecycle=title,
 limits=['Actual CPU title/area/palette-selector chain, not a hardware PPU/NMI delivery or native screenshot assertion. Native parent verifier remains required.'],
 bindings={str(f.resolve()):sha(f)for f in[Path(__file__),p,N,N.with_suffix('.dbg'),N.parent/'build-proof.json',N.parent/'menu.nam',N.parent/'menu.rle',N.parent/'packed.chr',R/'build/contra-force-body-art-v6/manifest.json']})
(O/'receipt.json').write_text(json.dumps(report,indent=2)+'\n',newline='\n');print(json.dumps(dict(passed=True,path=str(O/'receipt.json'),gray_pixels=checked,title_cases=len(title))))
