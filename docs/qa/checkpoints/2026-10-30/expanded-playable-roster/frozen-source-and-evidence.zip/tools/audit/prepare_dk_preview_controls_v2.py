"""Symmetric passive fixture setup; retain v1 caller-map asymmetry negative."""
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parents[2];a=R/'tools/audit/dk_roster_preview_controls_v1.py';s=a.read_text();needle="c,_=ar[1].invoke('FmPending');pending=";assert s.count(needle)==1
s=s.replace(needle,"ar[0].invoke('FmPending');c,_=ar[1].invoke('FmPending');pending=").replace("build/dk-roster-preview-controls-v1'","build/dk-roster-preview-controls-v2'")
p=R/'tools/audit/dk_roster_preview_controls_v2_generated.py';assert not p.exists();p.write_text(s,newline='\n')
o=R/'build/dk-preview-controls-builder-v2';o.mkdir();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();(o/'derivation.json').write_text(json.dumps(dict(before=str(a),before_sha256=sha(a),after=str(p),after_sha256=sha(p),negative='v1 invoked FmPending only in candidate, so test itself mapped A76 on candidate but left parent A66. Invoke same predicate on both before comparing caller maps. No product edit or assertion removed.'),indent=2)+'\n',newline='\n')
exec(compile(s,str(p),'exec'),{'__file__':str(p),'__name__':'__main__'})
