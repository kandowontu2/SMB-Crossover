"""Actual linked menu80-profile/OAM/palette and exact24px source pixel checks."""
from pathlib import Path
import importlib.util,hashlib,itertools,json,sys,traceback
from PIL import Image
R=Path(__file__).resolve().parents[2];P=R/'build/full-menu-source-controls-v2/check.py';spec=importlib.util.spec_from_file_location('menu80',P);T=importlib.util.module_from_spec(spec);spec.loader.exec_module(T)
from build_full_roster_menu_v1 import fit
O=R/'build/dk-roster-preview-controls-v1';assert not O.exists();O.mkdir();sha=T.sha
A=R/'build/full-roster-menu-v5/candidate.nes';N=R/'build/dk-roster-preview-v3/candidate.nes'
def snapshot(a):
 p=T.address(a.b,'Sprite_Data');q=T.address(a.b,'VRAM_Buffer1');n=a.get('VRAM_Buffer1_Offset')
 return dict(OAM=list(a.m[p:p+256]),offset=a.get('CurrentOAMOffset'),queue=list(a.m[q:q+n+1]),CHR=T.chr_state(a),maps=T.maps(a))
def render(b,records):
 raw=b['raw'];pal=[48,54,6];rp=(R/'tools/Windows/NEXXT 3.0/defaults/nes.pal').read_bytes();im=Image.new('RGBA',(256,240))
 for y,t,a,x in reversed([records[i:i+4]for i in range(0,len(records),4)]):
  for yy in range(16):
   sy=15-yy if a&128 else yy
   for xx in range(8):
    sx=7-xx if a&64 else xx;at=1048592+700*1024+(t&254)*16+(sy//8)*16+sy%8
    v=(raw[at]>>(7-sx)&1)|((raw[at+8]>>(7-sx)&1)<<1)
    if v:im.putpixel((x+xx,y+yy+1),tuple(rp[pal[v-1]*3:pal[v-1]*3+3])+(255,))
 return im
def main():
 p=dict(passed=False,native=False,rows=[],limits=['CPU source preview only, native display/review pending.'])
 try:
  bs=[T.scoped_load(f)for f in[A,N]];dk=None
  for slot,count in enumerate(T.COUNTS):
   ar=[T.fresh(b,slot)for b in bs]
   for a in ar:a.invoke('MenuResolveCharacter');a.invoke('QueueSelection')
   for variant in range(count):
    if variant:
     for a in ar:T.button(a,32)
    c,_=ar[1].invoke('FmPending');pending=bool(c.p&1);index=c.a if pending else None
    old,new=map(snapshot,ar)
    assert old['CHR']==new['CHR']and old['maps']==new['maps']
    if index!=17:assert old==new,(slot,variant,index,'foreign preview changed')
    else:
     assert old['offset']==16 and new['offset']==24
     base=T.location(bs[1],'FmDrawPreview::FmDkPreviewOam');records=list(bs[1]['raw'][base:base+24]);assert new['OAM'][:24]==records
     actual=render(bs[1],records).crop((116,160,140,192));expected=fit(Image.open(R/'build/roster-body-art-v1/donkey-kong-preview24.png'),(24,32))
     assert actual.tobytes()==expected.tobytes(),'Original white/skin/brown or mirrored source pixel changed'
     actual.save(O/'actual-linked-DK-preview.png');actual.resize((120,160),Image.Resampling.NEAREST).save(O/'actual-linked-DK-preview-5x.png')
     assert set(records[3::4])=={116,124,132}and set(records[0::4])=={159,175}
     assert all(y in[159,175]for y in records[0::4])
     dk=dict(slot=slot,variant=variant,pending_index=index,OAM=records,source_pixels_exact=True,max_parts_per_scanline=3,palette=[48,54,6])
    p['rows'].append(dict(slot=slot,variant=variant,pending=pending,index=index,old_OAM_bytes=old['offset'],new_OAM_bytes=new['offset']))
  assert len(p['rows'])==80 and dk is not None
  p.update(passed=True,DK=dk,unchanged_other_profiles=79)
 except Exception as e:p.update(error=repr(e),traceback=traceback.format_exc())
 p['bindings']={str(f.resolve()):sha(f)for f in[Path(__file__),P,A,A.with_suffix('.dbg'),N,N.with_suffix('.dbg'),N.parent/'build-proof.json']}
 f=O/('receipt.json'if p['passed']else'negative.json');f.write_text(json.dumps(p,indent=2)+'\n',newline='\n');print(json.dumps(dict(passed=p['passed'],rows=len(p['rows']),path=str(f),error=p.get('error'))));assert p['passed']
if __name__=='__main__':main()
