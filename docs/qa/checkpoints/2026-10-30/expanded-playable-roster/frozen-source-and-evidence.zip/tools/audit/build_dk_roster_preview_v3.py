"""Source successor: explicit original color roles and mandatory final mirror."""
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parents[2];A=R/'tools/audit/build_dk_roster_preview_v1.py';O=R/'build/dk-roster-preview-builder-v3';assert not O.exists();O.mkdir()
s=A.read_text().replace("build/dk-roster-preview-v1'","build/dk-roster-preview-v3'")
needle="(O/'pending-previews.chr').write_bytes(raw)";assert s.count(needle)==1
s=s.replace(needle,needle+'''
# The old16px sample dropped the six native white eye pixels and duplicated
# skin in its palette. Wider source pixels must use original white/skin/brown.
parts=art.split('FmPreviewColors:');lines=parts[1].splitlines();assert lines[18].strip()=='.byte 6,54,54'
lines[18]=' .byte 48,54,6';(O/'src/full_roster_menu_art.inc').write_text(parts[0]+'FmPreviewColors:'+'\\n'.join(lines)+'\\n',newline='\\n')
''')
needle="before=(A/'candidate.nes').read_bytes();after=(O/'candidate.nes').read_bytes()";assert s.count(needle)==1
s=s.replace(needle,"sys.path.insert(0,str(R/'tools'));from prepare_cv3_dmc_mirror import prepare;prepare(R,O/'candidate.nes')\n"+needle)
p=R/'tools/audit/build_dk_roster_preview_v3_generated.py';assert not p.exists();p.write_text(s,newline='\n')
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
(O/'derivation.json').write_text(json.dumps(dict(base=str(A),base_sha256=sha(A),successor=str(p),successor_sha256=sha(p),retained_negatives=['v1 raw source link lacked native CV3 finalizer.','v2 retained old duplicate skin palette row6/54/54; source rolewhite not represented.'],changes=['Only source output destination, explicit selectedDK color row48/54/6, requiredcanonicalCV3 finalizer.']),indent=2)+'\n',newline='\n')
exec(compile(s,str(p),'exec'),{'__file__':str(p),'__name__':'__main__'})
