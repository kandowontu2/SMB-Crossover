"""Actual80menu routes, original CF pixels/two palettes and P1 retirement."""
from pathlib import Path
import types,json,hashlib,sys,traceback
from PIL import Image
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit')]
helper=R/'tools/audit/dk_roster_preview_controls_v1.py';Q=types.ModuleType('immutable_preview_helpers');Q.__file__=str(helper);Q.__name__='immutable_preview_helpers';exec(compile(helper.read_text().replace(';assert not O.exists();O.mkdir();sha=T.sha',';sha=T.sha'),str(helper),'exec'),Q.__dict__)
T=Q.T;O=R/'build/dk-cf-roster-menu-controls-v1';assert not O.exists();O.mkdir();sha=T.sha
A=R/'build/character-host-union-unlock-v3/joint/candidate.nes';N=R/'build/dk-cf-roster-menu-v3/candidate.nes';B=R/'build/contra-force-body-art-v6';entries=json.loads((B/'manifest.json').read_text())['entries']
def apply(q,pal):
 i=0
 while i<len(q)-1 and q[i]:
  n=q[i+2]&63;assert n and not(q[i+2]&192),'Unexpected palette encoding'
  if q[i]==63:
   for j in range(n):pal[(q[i+1]+j)&31]=q[i+3+j]
  i+=3+n
 return pal
def palette():return [15]*20+[15,26,48,39]+[15]*8
def render_cf(b,record,e):
 raw=b['raw'];colors={int(k):tuple(v)for k,v in e['source']['palette_indices'].items()};pals=e['native_palette_rows'];im=Image.new('RGBA',(256,240))
 for y,t,a,x in reversed([record[i:i+4]for i in range(0,len(record),4)]):
  for yy in range(16):
   sy=15-yy if a&128 else yy
   for xx in range(8):
    sx=7-xx if a&64 else xx;at=1048592+700*1024+(t&254)*16+sy//8*16+sy%8;v=(raw[at]>>(7-sx)&1)|((raw[at+8]>>(7-sx)&1)<<1)
    if v:im.putpixel((x+xx,y+yy+1),colors[pals[a&3][v]]+(255,))
 w,h=e['size'];return im.crop(((256-w)//2,192-h,(256-w)//2+w,192))
def main():
 p=dict(passed=False,native=False,rows=[],CF=[],retirement=[],limits=['CPU source fixture only; root owns native menu/fullgame verification.'])
 try:
  bs=[T.scoped_load(f)for f in[A,N]];newb=bs[1];changed=0
  for slot,count in enumerate(T.COUNTS):
   ar=[T.fresh(b,slot)for b in bs]
   for a in ar:a.invoke('MenuResolveCharacter');a.invoke('QueueSelection')
   for variant in range(count):
    if variant:
     for a in ar:T.button(a,32)
    rr=[a.invoke('FmPending')[0]for a in ar];assert bool(rr[0].p&1)==bool(rr[1].p&1)
    old,new=map(Q.snapshot,ar)
    if slot not in[27,30]:assert old==new,(slot,variant,'foreign preview changed')
    elif slot==27:
     changed+=1;assert not(rr[1].p&1)and ar[1].get('SelectedCharacter')==28 and new['offset']==24
     im=Q.render(newb,new['OAM'][:24]).crop((116,160,140,192));assert im.tobytes()==Image.open(R/'build/dk-roster-preview-controls-v2/actual-linked-DK-preview.png').tobytes();im.save(O/'actual-ready-DK.png')
    else:
     changed+=1;assert rr[1].p&1 and rr[1].a==26+variant and ar[1].get('SelectedCharacter')==0
     assert new['offset']==20 and sum(new['OAM'][i]<240 for i in range(0,256,4))==5
     assert new['CHR']['current_chr'][:4]==[188,189,190,191]and new['CHR']['direct_modes'][:4]==[130]*4
     pal=apply(new['queue'],palette());assert pal[17:24]==[55,18,15,15,55,22,15]
     rec=new['OAM'][:20];im=render_cf(newb,rec,entries[variant]);original=Image.open(entries[variant]['path']).convert('RGBA');assert im.tobytes()==original.tobytes(),('CF visible source pixel mismatch',variant)
     im.save(O/(entries[variant]['name']+'-actual-linked.png'))
     assert ar[1].m[0x5fe8]&128 and ar[1].m[0x5fe8]&24==variant*8
     p['CF'].append(dict(variant=variant,index=rr[1].a,OAM=rec,colors=pal[16:24],pixels_exact=True,maximum_parts_on_line=max(sum(y+1<=line<y+17 for y in rec[0::4])for line in range(240))))
    p['rows'].append(dict(slot=slot,variant=variant,pending=bool(rr[1].p&1),SelectedCharacter=ar[1].get('SelectedCharacter'),OAM_bytes=new['offset']))
  assert len(p['rows'])==80 and changed==5
  # Every other identity after EACH CF variant: model actual consumed palettes,
  # then execute genuine destination resolve/queue/Select paths with markerlive.
  for cf in range(4):
   for slot,count in enumerate(T.COUNTS):
    if slot==30:continue
    for variant in range(count):
     a=T.fresh(newb,30);a.invoke('MenuResolveCharacter');a.invoke('QueueSelection')
     for _ in range(cf):T.button(a,32)
     pal=apply(Q.snapshot(a)['queue'],palette());assert pal[21:24]==[55,22,15]
     a.put(CrossoverMenuIndex=slot,VRAM_Buffer1_Offset=0);a.invoke('MenuResolveCharacter');a.invoke('QueueSelection');pal=apply(Q.snapshot(a)['queue'],pal)
     for _ in range(variant):T.button(a,32);pal=apply(Q.snapshot(a)['queue'],pal)
     assert not(a.m[0x5fe8]&128)and pal[21:24]==[26,48,39],(cf,slot,variant,'Native P1 not restored')
     p['retirement'].append(dict(from_cf=cf,to_slot=slot,to_variant=variant,P1=pal[21:24]))
  assert len(p['retirement'])==304
  # Marker is one spare bit of existing menu state; all other bits survive.
  p['flag_preservation']=[]
  for group in range(256):
   a=T.fresh(newb);a.m[0x5fe8]=group;a.invoke('FmCfRestoreP1');assert a.m[0x5fe8]==group&127
   p['flag_preservation'].append([group,a.m[0x5fe8]])
  # Genuine compiled title-ground source bytes, resident under the A29 helper.
  at=T.location(newb,'GroundPaletteData');assert newb['raw'][at+24:at+27]==bytes([26,48,39]);assert(T.location(newb,'GroundPaletteData')-16)//8192==126
  # The old live Rush initializer after filler stays exact, not just its PC.
  lo=16+29*8192+0x1fb0;assert bs[0]['raw'][lo:lo+13]==newb['raw'][lo:lo+13]
  p.update(passed=True,profiles=80,ready=sum(not z['pending']for z in p['rows']),pending=sum(z['pending']for z in p['rows']),unchanged_other_profiles=75,CF_to_other_identities=len(p['retirement']),marker_cases=256,
   actual_helper_bytes=T.address(newb,'FmCfHelperEnd')-T.address(newb,'FmCfHelperStart'))
 except Exception as e:p.update(error=repr(e),traceback=traceback.format_exc())
 p['bindings']={str(f.resolve()):sha(f)for f in[Path(__file__),helper,A,A.with_suffix('.dbg'),N,N.with_suffix('.dbg'),N.parent/'build-proof.json',B/'manifest.json']}
 out=O/('receipt.json'if p['passed']else'negative.json');out.write_text(json.dumps(p,indent=2)+'\n',newline='\n');print(json.dumps(dict(passed=p['passed'],profiles=len(p['rows']),retirement=len(p['retirement']),error=p.get('error'),path=str(out))));assert p['passed']
if __name__=='__main__':main()
