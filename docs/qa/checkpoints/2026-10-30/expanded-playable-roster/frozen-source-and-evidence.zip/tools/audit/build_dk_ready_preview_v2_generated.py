"""Genuine ready-DK menu seam on reviewed91b source; no gameplay hooks."""
from pathlib import Path
import hashlib,json,re,subprocess,sys
R=Path(__file__).resolve().parents[2];A=R/'build/character-host-union-unlock-v1';J=A/'joint';D=R/'build/dk-roster-preview-v3';O=R/'build/dk-ready-preview-v2';assert not O.exists();O.mkdir();(O/'src').mkdir();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(J/'candidate.nes')=='91b28eac0291f7d401a5109146d61f2f5282b819c535b3efc748e28411e01cb6'
h=json.loads((A/'handoff.json').read_text())
for f,v in h['bindings'].items():assert sha(f)==v,f
s=(J/'src/full_roster_menu.s').read_text();old=s[s.index('.proc FmDrawPreview'):s.index('.include "full_roster_menu_art.inc"')]
new=(D/'src/full_roster_menu.s').read_text();new=new[new.index('.proc FmDrawPreview'):new.index('.include "full_roster_menu_art.inc"')]
new=new.replace('.proc FmDrawPreview\n','.proc FmDrawDkPreview\n lda #17\n jmp FmDrawPreviewSelected\n.endproc\n.proc FmDrawPreview\n jsr FmPending\n.endproc\n.proc FmDrawPreviewSelected\n pha\n',1)
assert new.count(' jsr FmPending\n pha\n cmp #17')==1;new=new.replace(' jsr FmPending\n pha\n cmp #17',' pla\n pha\n cmp #17',1)
s=s.replace(old,new);(O/'src/full_roster_menu.s').write_text(s,newline='\n')
art=(J/'src/full_roster_menu_art.inc').read_text();a=art.split('FmPreviewColors:');lines=a[1].splitlines();assert lines[18].strip()=='.byte 6,54,54';lines[18]=' .byte 48,54,6';(O/'src/full_roster_menu_art.inc').write_text(a[0]+'FmPreviewColors:'+'\n'.join(lines)+'\n',newline='\n')
char=(J/'src/character_select.s').read_text();needle='FmNativePreview:\n  farcall MoveAllSpritesOffscreen';assert char.count(needle)==1
char=char.replace(needle,'''FmNativePreview:
  lda SelectedCharacter
  cmp #28
  bne FmNativeOtherPreview
  farcall FmDrawDkPreview,jmp
FmNativeOtherPreview:
  farcall MoveAllSpritesOffscreen''');(O/'src/character_select.s').write_text(char,newline='\n')
(O/'pending-previews.chr').write_bytes((D/'pending-previews.chr').read_bytes())
entry=(J/'entrypoint.s').read_text();old='C:/Users/kando/Documents/ChatGPT/SMB Crossover/build/character-host-union-v13/pending-previews.chr';assert entry.count(old)==1;entry=entry.replace(old,(O/'pending-previews.chr').as_posix());(O/'entrypoint.s').write_text(entry,newline='\n')
cmd=json.loads((J/'main-build.json').read_text())['command'];cmd[1:1]=['-I',str(O/'src')];cmd[cmd.index('--create-full-dep')+1]=str(O/'main.dep');cmd[cmd.index('-o')+1]=str(O/'main.o');cmd[-1]=str(O/'entrypoint.s')
commands=[]
for name,c in [('main-build',cmd),('link-build',json.loads((J/'link-build.json').read_text())['command'])]:
 if name=='link-build':
  for n in['candidate.nes','candidate.lbl','candidate.dbg','candidate.map','main.o']:c=[x.replace(str(J/n),str(O/n))for x in c]
 p=subprocess.run(c,cwd=R,capture_output=True,text=True);(O/(name+'.json')).write_text(json.dumps(dict(command=c,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr),indent=2)+'\n');assert p.returncode==0,p.stderr;commands.append(c)
sys.path.insert(0,str(R/'tools'));from prepare_cv3_dmc_mirror import prepare;prepare(R,O/'candidate.nes')
a=(J/'candidate.nes').read_bytes();b=(O/'candidate.nes').read_bytes();diff=[i for i,(x,y)in enumerate(zip(a,b))if x!=y]
assert all(16+66*8192<=i<16+67*8192 or 16+76*8192+0x1979<=i<16+77*8192 or 1048592+700*1024<=i<1048592+704*1024 for i in diff)
p=dict(passed=True,native=False,admitted=False,parent_sha256=sha(J/'candidate.nes'),candidate_sha256=sha(O/'candidate.nes'),
 source_delta='Only existing frontend readyDK preview seam plus ownUI six-part renderer/rowpalette and existing previewCHR pairs; readiness flags/gameplay/common untouched.',
 Rogue_reset19_negative_inherited='Parent91b source intentionally preserved; root must compose same overlay with qualified7e418 three-byte service19 correction before native gameplay.',
 commands=commands,bindings={str(f.resolve()):sha(f)for f in[Path(__file__),A/'handoff.json',J/'source-closure.json',D/'build-proof.json',*[p for p in O.rglob('*')if p.is_file()]]})
(O/'build-proof.json').write_text(json.dumps(p,indent=2)+'\n',newline='\n');print(json.dumps(dict(ROM=sha(O/'candidate.nes'),path=str(O/'build-proof.json'))))
