"""Retire CF's menu-only P1 through existing FmGroups bit7 and native palette."""
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parents[2];A=R/'tools/audit/build_dk_cf_roster_menu_v2_generated.py';s=A.read_text().replace("build/dk-cf-roster-menu-v2'","build/dk-cf-roster-menu-v3'")
needle='.proc FmDrawCfPreview\n sec';assert s.count(needle)==1;s=s.replace(needle,'.proc FmDrawCfPreview\n pha\n lda FmGroups\n ora #$80\n sta FmGroups\n pla\n sec')
needle='.endproc\nFmCfHelperEnd:';assert s.count(needle)==1;s=s.replace(needle,'''.endproc
; Only bit7 is the temporary menu P1 lease marker. Existing WWF/CF bits0..4
; retain their original meaning. Native title setup uses ground paletteP1;
; obtain its genuine linked resident source bytes, never a guessed RGB row.
.proc FmCfRestoreP1
 lda FmGroups
 bpl Done
 and #$7f
 sta FmGroups
 ldx VRAM_Buffer1_Offset
 lda #$3f
 sta VRAM_Buffer1,x
 lda #$15
 sta VRAM_Buffer1+1,x
 lda #3
 sta VRAM_Buffer1+2,x
 ldy #0
Copy:
 lda GroundPaletteData+24,y
 sta VRAM_Buffer1+3,x
 inx
 iny
 cpy #3
 bcc Copy
 inx
 inx
 inx
 stx VRAM_Buffer1_Offset
 lda #0
 sta VRAM_Buffer1,x
Done:
 rts
.endproc
FmCfHelperEnd:''')
needle="source=source.replace('.res $b22,$ff ; Keep following Rush reset leaf at its original public PC.'";assert s.count(needle)==1
s=s.replace(needle,"source=source.replace('.proc QueueSelection\\n','.proc QueueSelection\\n  farcall FmCfRestoreP1\\n',1)\n"+needle)
p=R/'tools/audit/build_dk_cf_roster_menu_v3_generated.py';assert not p.exists();p.write_text(s,newline='\n');O=R/'build/dk-cf-roster-menu-builder-v3';O.mkdir();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();(O/'derivation.json').write_text(json.dumps(dict(before=str(A),before_sha256=sha(A),after=str(p),after_sha256=sha(p),retained_negative='v2 changed menuP1 but did not restore it before Chip/Dale or TMNT consumers. Existing spare FmGroupsbit7 tracks temporaryborrow; genuine linked GroundPaletteData+24 restores nativeP1 before nextselection, no newRAM/PPUread.'),indent=2)+'\n',newline='\n');exec(compile(s,str(p),'exec'),{'__file__':str(p),'__name__':'__main__'})
