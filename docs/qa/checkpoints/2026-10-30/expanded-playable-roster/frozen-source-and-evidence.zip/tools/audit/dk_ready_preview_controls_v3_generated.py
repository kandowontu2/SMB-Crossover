"""All80 actual menu paths plus readyDK24px and ready-owner CHR retirement."""
from pathlib import Path
import importlib.util,json,hashlib,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit')]
import types
Q=types.ModuleType('immutable_dk_helper')
helper=R/'tools/audit/dk_roster_preview_controls_v1.py'
text=helper.read_text();text=text.replace(';assert not O.exists();O.mkdir();sha=T.sha',';sha=T.sha')
Q.__file__=str(helper);Q.__name__='immutable_dk_helper';exec(compile(text,str(helper),'exec'),Q.__dict__)
T=Q.T;O=R/'build/dk-ready-preview-controls-v3';assert not O.exists();O.mkdir();sha=T.sha
A=R/'build/character-host-union-unlock-v1/joint/candidate.nes';N=R/'build/dk-ready-preview-v2/candidate.nes'
def main():
 p=dict(passed=False,native=False,rows=[],limits=['Source menu paths only; root must compose qualified Rogue-v2 reset19 before native gameplay.'])
 try:
  bs=[T.scoped_load(f)for f in[A,N]];dk=None
  for slot,count in enumerate(T.COUNTS):
   ar=[T.fresh(b,slot)for b in bs]
   for a in ar:a.invoke('MenuResolveCharacter');a.invoke('QueueSelection')
   for variant in range(count):
    if variant:
     for a in ar:T.button(a,32)
    rr=[a.invoke('FmPending')[0]for a in ar];assert bool(rr[0].p&1)==bool(rr[1].p&1)
    old,new=map(Q.snapshot,ar)
    if slot!=27:assert old==new,(slot,variant,'foreign menu preview changed')
    else:
     assert variant==0 and not(rr[1].p&1)and ar[1].get('SelectedCharacter')==28
     assert new['offset']==24 and new['CHR']['current_chr'][:4]==[188,189,190,191]and new['CHR']['direct_modes'][:4]==[130]*4
     b=bs[1];at=T.location(b,'FmDrawPreviewSelected::FmDkPreviewOam');rec=list(b['raw'][at:at+24]);assert new['OAM'][:24]==rec
     expected=(R/'build/dk-roster-preview-controls-v2/actual-linked-DK-preview.png').read_bytes()
     im=Q.render(b,rec).crop((116,160,140,192));target=O/'actual-ready-DK-preview.png';im.save(target);assert target.read_bytes()==expected
     dk=dict(ready=True,SelectedCharacter=28,parts=6,palette=[48,54,6],actual_descriptor=rec)
    p['rows'].append(dict(slot=slot,variant=variant,pending=bool(rr[1].p&1),selected=ar[1].get('SelectedCharacter'),OAM_bytes=new['offset']))
  assert len(p['rows'])==80 and dk
  # A genuine resolve/queue transition must remove borrowed direct windows.
  a=T.fresh(bs[1],27);a.invoke('MenuResolveCharacter');a.invoke('QueueSelection')
  assert a.get('CurrentOAMOffset')==24
  a.put(CrossoverMenuIndex=1,VRAM_Buffer1_Offset=0,ProtoVariant=1);a.invoke('MenuResolveCharacter');a.invoke('QueueSelection')
  assert a.get('SelectedCharacter')==1
  defaults=list(bs[1]['raw'][T.location(bs[1],'CHRBankInitValues'):T.location(bs[1],'CHRBankInitValues')+8])
  state=T.chr_state(a);assert state['current_chr'][1:]==defaults[1:]and state['direct_modes']==[129,0,0,0,0,0,0,0]
  p.update(passed=True,DK=dk,unchanged_other_profiles=79,ready_count=sum(not z['pending']for z in p['rows']),pending_count=sum(z['pending']for z in p['rows']),DK_to_Proto_retirement=state)
 except Exception as e:p.update(error=repr(e),traceback=traceback.format_exc())
 p['bindings']={str(f.resolve()):sha(f)for f in[Path(__file__),Path(Q.__file__),A,A.with_suffix('.dbg'),N,N.with_suffix('.dbg'),N.parent/'build-proof.json']}
 out=O/('receipt.json'if p['passed']else'negative.json');out.write_text(json.dumps(p,indent=2)+'\n',newline='\n');print(json.dumps(dict(passed=p['passed'],rows=len(p['rows']),error=p.get('error'),path=str(out))));assert p['passed']
if __name__=='__main__':main()
