"""Freeze authentic wider DK frontend-only source and all affected CPU checks."""
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parents[2];O=R/'build/dk-roster-preview-qualified-v1';assert not O.exists();O.mkdir();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
files={Path(__file__)}
parents=[R/'build/dk-roster-preview-v3/build-proof.json',R/'build/dk-roster-preview-controls-v2/receipt.json',R/'build/roster-body-art-v1/donkey-kong-manifest.json']
for p in parents:
 d=json.loads(p.read_text());assert d.get('passed',True),p
 for f,h in d.get('bindings',{}).items():assert sha(f)==h,f
 files|={p}|set(map(Path,d.get('bindings',{})))
base=R/'build/full-roster-menu-v5/source-closure.json';d=json.loads(base.read_text())
for f,h in d['actual_ASM_dependencies'].items():assert sha(f)==h,f
files|={base}|set(map(Path,d['actual_ASM_dependencies']))
for folder in['dk-roster-preview-v1','dk-roster-preview-v2','dk-roster-preview-v3','dk-roster-preview-builder-v3','dk-roster-preview-controls-v1','dk-roster-preview-controls-v2','dk-preview-controls-builder-v2']:
 files|={p for p in(R/'build'/folder).rglob('*')if p.is_file()and'__pycache__'not in p.parts}
files|={R/'tools/audit/build_dk_roster_preview_v3.py',R/'tools/audit/prepare_dk_preview_controls_v2.py',R/'tools/audit/finalize_dk_roster_preview_v2.py'}
rom=R/'build/dk-roster-preview-v3/candidate.nes';assert sha(rom)=='ea6955c5ed5c7f5be693b15900b2f16bd698706cf2b9c4f5589ac9c1d2136eaf'
p=dict(passed=True,native=False,admitted=False,status='FROZEN_FRONTEND_DK_WIDER_SOURCE_PREVIEW_CPU_PASS_NATIVE_VISUAL_PENDING',candidate=str(rom),candidate_sha256=sha(rom),
 parent='Stable5b09 source frontend; installedec2f23ed adds separate10B RCR repair, not composed in this review candidate.',
 compose_inputs=['build/dk-roster-preview-v3/src/full_roster_menu.s','build/dk-roster-preview-v3/src/full_roster_menu_art.inc','build/dk-roster-preview-v3/pending-previews.chr'],
 checks=dict(actual_menu_profiles=80,unchanged_other_profiles=79,DK_source_pixel_equivalence=True,DK_original_NES_colors=[48,54,6],DK_OAM_parts=6,max_body_parts_per_scanline=3,
  new_selected_size=[24,19],grid_CHR_and_nametable_exact=True,extra_UI_bytes=43,remaining_existing_UI_bytes=27,additional_CHR_pages=0,new_pattern_pairs=4),
 negatives=['Initial source link lacked required CV3 postlink mirror; fixed by actual canonical producer in successors.',
  'Old16px color quantization dropped nativewhiteeyes and duplicatedskin role; selectedDK row now exact48/54/6.',
  'CPU fixture v1 only called predicate in candidate, mappingA76 vs parentA66; v2 calls same predicate onboth, no weakened assertions.'],
 limits=['Native physical menu capture/visual acceptance still required. CPU decoded visual explicitly not a screenshot.',
  'No gameplay/readiness/other-character change; root composes source into own stable-menu unlock successor.'],
 bindings={str(f.resolve()):sha(f)for f in sorted(files)})
(O/'handoff.json').write_text(json.dumps(p,indent=2)+'\n',newline='\n');print(json.dumps(dict(path=str(O/'handoff.json'),sha256=sha(O/'handoff.json'),bindings=len(files))))
