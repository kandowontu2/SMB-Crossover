"""Compose source-only readyDK and lossless original CF body previews on e706."""
from pathlib import Path
from itertools import groupby
import hashlib,json,re,subprocess,sys
from PIL import Image
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
from build_full_roster_menu_v1 import encode
A=R/'build/character-host-union-unlock-v3';J=A/'joint';D=R/'build/dk-ready-preview-v2';B=R/'build/contra-force-body-art-v6';O=R/'build/dk-cf-roster-menu-v3';assert not O.exists();O.mkdir();(O/'src').mkdir();sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert sha(J/'candidate.nes')=='e706e9f85a8ef0aaba2050d37f71d7e60678f91d9aea109404b4ba4e5b3376fd'
h=json.loads((A/'handoff.json').read_text())
for f,v in h['bindings'].items():assert sha(f)==v,f
assert (J/'candidate.nes').read_bytes()[16+29*8192+0x149b:16+29*8192+0x149b+400]==bytes([255])*400
source=(J/'src/character_select.s').read_text();assert source.count('.res $b22,$ff ; Keep following Rush reset leaf at its original public PC.')==1
# No previous executable label can point into this source-authored fill.
for line in(J/'candidate.dbg').read_text().splitlines():
 if line.startswith('sym\t')and'type=lab'in line and'val='in line and'seg='in line:
  fields=dict(t.split('=',1)for t in line[4:].split(',')if'='in t)
  if fields.get('seg')=='72':assert not 0xb49b<int(fields['val'],0)<0xb62b,fields
full=(J/'src/full_roster_menu.s').read_text();start=full.index('.proc FmDrawPreview');end=full.index('.include "full_roster_menu_art.inc"')
new=(D/'src/full_roster_menu.s').read_text();new=new[new.index('.proc FmDrawDkPreview'):new.index('.include "full_roster_menu_art.inc"')];full=full[:start]+new+full[end:];(O/'src/full_roster_menu.s').write_text(full,newline='\n')
art=(D/'src/full_roster_menu_art.inc').read_text();(O/'src/full_roster_menu_art.inc').write_text(art,newline='\n')
raw=bytearray((D/'pending-previews.chr').read_bytes());entries=json.loads((B/'manifest.json').read_text())['entries'];pairs=[];records=[]
for e in entries:
 v=Path(e['source']['visible_snapshot']).read_bytes();c=v[47:8239];crop=e['source']['crop'];w,hh=e['size'];left=(256-w)//2;top=192-hh;record=[]
 for q in e['source']['source_parts']:
  t=q['tile'];p=c[(t&1)*4096+(t&254)*16:(t&1)*4096+(t&254)*16+32]
  if p not in pairs:pairs.append(p)
  record.extend([top+q['y']-crop[1],(100+pairs.index(p))*2,q['attr'],left+q['x']-crop[0]])
 assert len(record)==20;records.append([20]+record)
assert len(pairs)==16
for i,p in enumerate(pairs):raw[(100+i)*32:(101+i)*32]=p
(O/'pending-previews.chr').write_bytes(raw)
helper='''; Exact original-game CF body patterns/attributes; menu-only P0/P1.
.res $0d,$ff ; Retain first13B of old fill before granted helper start.
.assert * = $b49b,lderror,"Approved menu helper start moved"
FmCfHelperStart:
.proc FmDrawCfPreview
 pha
 lda FmGroups
 ora #$80
 sta FmGroups
 pla
 sec
 sbc #26
 pha
 farcall MoveAllSpritesOffscreen
 farcall X5ClearChrModes
 ldy #0
Map:
 tya
 clc
 adc #$bc
 ldx #2
 farcall X5SetPhysicalChr
 iny
 cpy #4
 bcc Map
 pla
 tax
 lda CfLo,x
 sta R0
 lda CfHi,x
 sta R1
 ldy #0
 lda (R0),y
 sta CurrentOAMOffset
 tax
 iny
Copy:
 lda (R0),y
 sta Sprite_Data-1,y
 iny
 dex
 bne Copy
 ldx VRAM_Buffer1_Offset
 lda #$3f
 sta VRAM_Buffer1,x
 lda #$11
 sta VRAM_Buffer1+1,x
 lda #7
 sta VRAM_Buffer1+2,x
 ldy #0
Pal:
 lda CfPalette,y
 sta VRAM_Buffer1+3,x
 inx
 iny
 cpy #7
 bcc Pal
 inx
 inx
 inx
 stx VRAM_Buffer1_Offset
 lda #0
 sta VRAM_Buffer1,x
 rts
CfPalette:.byte $37,$12,$0f,$0f,$37,$16,$0f
CfLo:.byte <Cf0,<Cf1,<Cf2,<Cf3
CfHi:.byte >Cf0,>Cf1,>Cf2,>Cf3
'''
for i,record in enumerate(records):helper+='Cf'+str(i)+':.byte '+','.join(map(str,record))+'\n'
helper+='''.endproc
; Only bit7 is the temporary menu P1 lease marker. Existing WWF/CF bits0..4
; retain their original meaning. Native title setup uses ground paletteP1;
; obtain its genuine linked resident source bytes, never a guessed RGB row.
.proc FmCfRestoreP1
 lda FmGroups
 bpl Done
 and #$7f
 sta FmGroups
 ldx VRAM_Buffer1_Offset
 lda #$3f
 sta VRAM_Buffer1,x
 lda #$15
 sta VRAM_Buffer1+1,x
 lda #3
 sta VRAM_Buffer1+2,x
 ldy #0
Copy:
 lda GroundPaletteData+24,y
 sta VRAM_Buffer1+3,x
 inx
 iny
 cpy #3
 bcc Copy
 inx
 inx
 inx
 stx VRAM_Buffer1_Offset
 lda #0
 sta VRAM_Buffer1,x
Done:
 rts
.endproc
FmCfHelperEnd:
.assert FmCfHelperEnd-FmCfHelperStart <= 400,lderror,"Menu helper exceeds root400B limit"
.res $b22-$0d-(FmCfHelperEnd-FmCfHelperStart),$ff
.assert * = $bfb0,lderror,"Fixed Rush reset boundary moved"
''';(O/'src/cf_menu_body.inc').write_text(helper,newline='\n')
needle='  farcall FmPending\n  bcc FmNativePreview\n  farcall FmDrawPreview,jmp';assert source.count(needle)==1
source=source.replace(needle,'''  farcall FmPending
  bcc FmNativePreview
  cmp #26
  bcc FmPendingGenericPreview
  cmp #30
  bcs FmPendingGenericPreview
  farcall FmDrawCfPreview,jmp
FmPendingGenericPreview:
  farcall FmDrawPreview,jmp''')
needle='FmNativePreview:\n  farcall MoveAllSpritesOffscreen';assert source.count(needle)==1;source=source.replace(needle,'''FmNativePreview:
  lda SelectedCharacter
  cmp #28
  bne FmNativeOtherPreview
  farcall FmDrawDkPreview,jmp
FmNativeOtherPreview:
  farcall MoveAllSpritesOffscreen''')
source=source.replace('.proc QueueSelection\n','.proc QueueSelection\n  farcall FmCfRestoreP1\n',1)
source=source.replace('.res $b22,$ff ; Keep following Rush reset leaf at its original public PC.','.include "cf_menu_body.inc" ; Same fixed menu-owned filler/end; actualsource helper.')
# Replace only CF's gray grid cell with the genuine full-body thumbnail.
packed=bytearray((R/'build/character-host-union-v13/packed.chr').read_bytes());nt=bytearray((R/'build/full-roster-menu-v5/menu.nam').read_bytes());pic=Image.open(entries[0]['thumbnail']).convert('RGBA')
for ty in range(3):
 for tx in range(2):
  tile=239+ty*2+tx;values=[]
  for y in range(8):
   row=[]
   for x in range(8):
    r,g,b,a=pic.getpixel((tx*8+x,ty*8+y));row.append(0 if a<128 else 1 if r<95 else 2 if r<200 else 3)
   values.append(row)
  assert packed[4096+tile*16:4096+(tile+1)*16]==bytes(16)
  packed[4096+tile*16:4096+(tile+1)*16]=encode(values);nt[(16+ty)*32+22+tx]=tile
(O/'packed.chr').write_bytes(packed);(O/'menu.nam').write_bytes(nt);rle=bytearray()
for value,g in groupby(nt):
 n=len(list(g))
 while n:
  count=min(255,n);rle.extend([count,value]);n-=count
rle.append(0);(O/'menu.rle').write_bytes(rle)
source=source.replace('C:/Users/kando/Documents/ChatGPT/SMB Crossover/build/full-roster-menu-v5/menu.rle',(O/'menu.rle').as_posix());(O/'src/character_select.s').write_text(source,newline='\n')
assert 'PreviewPriority:'in source and 'and #$df'in source.lower(),'Genuine Rogue preview priority source lost'
entry=(J/'entrypoint.s').read_text()
for n in['packed.chr','pending-previews.chr']:entry=entry.replace('C:/Users/kando/Documents/ChatGPT/SMB Crossover/build/character-host-union-v13/'+n,(O/n).as_posix())
(O/'entrypoint.s').write_text(entry,newline='\n');commands=[]
cmd=json.loads((J/'main-build.json').read_text())['command'];cmd[1:1]=['-I',str(O/'src')];cmd[cmd.index('--create-full-dep')+1]=str(O/'main.dep');cmd[cmd.index('-o')+1]=str(O/'main.o');cmd[-1]=str(O/'entrypoint.s')
for name,c in [('main-build',cmd),('link-build',json.loads((J/'link-build.json').read_text())['command'])]:
 if name=='link-build':
  for n in['candidate.nes','candidate.lbl','candidate.dbg','candidate.map','main.o']:c=[x.replace(str(J/n),str(O/n))for x in c]
 q=subprocess.run(c,cwd=R,capture_output=True,text=True);(O/(name+'.json')).write_text(json.dumps(dict(command=c,returncode=q.returncode,stdout=q.stdout,stderr=q.stderr),indent=2)+'\n');assert q.returncode==0,q.stderr;commands.append(c)
from prepare_cv3_dmc_mirror import prepare;prepare(R,O/'candidate.nes')
a=(J/'candidate.nes').read_bytes();b=(O/'candidate.nes').read_bytes();diff=[i for i,(x,y)in enumerate(zip(a,b))if x!=y]
assert all(16+29*8192+0x149b<=i<16+29*8192+0x149b+400 or 16+66*8192<=i<16+67*8192 or 16+76*8192+0x1979<=i<16+77*8192 or 1048592+4*1024<=i<1048592+8*1024 or 1048592+700*1024<=i<1048592+704*1024 for i in diff)
p=dict(passed=True,native=False,admitted=False,parent_sha256=sha(J/'candidate.nes'),candidate_sha256=sha(O/'candidate.nes'),records=records,unique_CF_pairs=16,source_colors_lossless=True,original_black_opaque=True,
 menu_only_palettes=[[15,55,18,15],[15,55,22,15]],old_wrapper_and_Rush_reset_boundary_exact=True,Rogue_v2_reset19_and_v3_portrait_priority_producers_preserved=True,commands=commands,
 bindings={str(f.resolve()):sha(f)for f in[Path(__file__),A/'handoff.json',B/'manifest.json',D/'build-proof.json',*[p for p in O.rglob('*')if p.is_file()]]})
(O/'build-proof.json').write_text(json.dumps(p,indent=2)+'\n',newline='\n');print(json.dumps(dict(ROM=sha(O/'candidate.nes'),path=str(O/'build-proof.json'))))
