"""Export the genuine complete DK idle; retain aspect ratio and source opacity."""
from pathlib import Path
import hashlib,json
from PIL import Image,ImageDraw
R=Path(__file__).resolve().parents[2];O=R/'build/roster-body-art-v1';O.mkdir(exist_ok=True)
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
rom=Path('C:/NES/Donkey Kong (World) (Rev 1).nes');raw=rom.read_bytes()
assert sha(rom)=='226c6f698f60b0a07157bd031004820789469884615fef7bdd862c3157e89d27'
proof=R/'build/dk-source-assets-v1/handoff.json';d=json.loads(proof.read_text());f=next(x for x in d['frames']if x['name']=='idle')
tiles=list(raw[16+0x657+1:16+0x657+25]);assert tiles==f['tiles']
pal=R/'tools/Windows/NEXXT 3.0/defaults/nes.pal';rgb=pal.read_bytes();codes=d['original_palette'];assert codes==[15,48,54,6]
indices=bytearray(48*32);im=Image.new('RGBA',(48,32))
for col in range(6):
 for row in range(4):
  t=tiles[col*4+row];p=raw[16400+4096+t*16:16400+4096+(t+1)*16]
  for y in range(8):
   for x in range(8):
    v=(p[y]>>(7-x)&1)|((p[y+8]>>(7-x)&1)<<1);px=col*8+x;py=row*8+y;indices[py*48+px]=v
    if v:im.putpixel((px,py),tuple(rgb[codes[v]*3:codes[v]*3+3])+(255,))
assert hashlib.sha256(indices).hexdigest()==f['source_pixel_SHA256']
box=im.getbbox();body=im.crop(box);body.save(O/'donkey-kong.png')
preview=body.resize((24,round(body.height*24/body.width)),Image.Resampling.NEAREST);preview.save(O/'donkey-kong-preview24.png')
small=body.resize((16,round(body.height*16/body.width)),Image.Resampling.NEAREST);thumb=Image.new('RGBA',(16,24));thumb.alpha_composite(small,(0,24-small.height))
for y in range(24):
 for x in range(16):
  r,g,b,a=thumb.getpixel((x,y))
  if a:
   l=(299*r+587*g+114*b)//1000;v=72 if l<85 else 160 if l<170 else 248;thumb.putpixel((x,y),(v,v,v,255))
thumb.save(O/'donkey-kong-thumb16x24.png')
sheet=Image.new('RGBA',(300,150),'#18242c');dr=ImageDraw.Draw(sheet)
for x,p,label in[(8,body,'native40x32'),(116,preview,'preview24x19'),(206,thumb,'grid16x24')]:
 dr.text((x,4),label,fill='white');sheet.alpha_composite(p.resize((p.width*2,p.height*2),Image.Resampling.NEAREST),(x,30))
sheet.save(O/'donkey-kong-review.png')
files=[Path(__file__),rom,proof,pal]+[O/n for n in['donkey-kong.png','donkey-kong-preview24.png','donkey-kong-thumb16x24.png','donkey-kong-review.png']]
p=dict(name='donkey-kong',path=str(O/'donkey-kong.png'),thumbnail=str(O/'donkey-kong-thumb16x24.png'),
 preview24=str(O/'donkey-kong-preview24.png'),output_sha256=sha(O/'donkey-kong.png'),thumbnail_sha256=sha(O/'donkey-kong-thumb16x24.png'),
 source=dict(ROM=str(rom),ROM_sha256=sha(rom),PRG_table='C657',frame='original idle',source_canvas=[48,32],alpha_crop=list(box),
  actual_source_pixel_sha256=hashlib.sha256(indices).hexdigest(),NES_palette=codes,geometry_and_opaque_pixels_exact=True),
 presentation=dict(full_body=list(body.size),preview24=list(preview.size),gray_thumbnail=[16,24],
  warning='Fixed16px preview shrinks native silhouette to16x13;24px selected preview retains more detail. No painted/cropped/recolored source pixels.'),
 bindings={str(f.resolve()):sha(f)for f in files})
assert not(O/'donkey-kong-manifest.json').exists();(O/'donkey-kong-manifest.json').write_text(json.dumps(p,indent=2)+'\n',newline='\n')
print(json.dumps(dict(path=str(O/'donkey-kong-manifest.json'),sha256=sha(O/'donkey-kong-manifest.json'))))
