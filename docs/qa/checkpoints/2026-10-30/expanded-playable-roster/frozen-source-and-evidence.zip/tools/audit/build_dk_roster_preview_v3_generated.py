"""Source-build a selected-only six-part authentic DK preview on stable v5."""
from pathlib import Path
import hashlib,json,shutil,subprocess,sys,re
from PIL import Image
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(R/'tools/audit'))
from build_full_roster_menu_v1 import encode,fit
A=R/'build/full-roster-menu-v5';O=R/'build/dk-roster-preview-v3';assert not O.exists();O.mkdir();(O/'src').mkdir()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
closure=json.loads((A/'source-closure.json').read_text())
for f,h in closure['actual_ASM_dependencies'].items():assert sha(f)==h,f
assert sha(A/'candidate.nes')=='5b09a3ed02aa678fb1d6fca57d905224e95c7b8f0f4e12f13901bf3f41f12d1e'
for p in(A/'src').iterdir():
 if p.is_file():shutil.copyfile(p,O/'src'/p.name)
for n in['full-menu.cfg','packed.chr','menu.rle','menu.nam']:shutil.copyfile(A/n,O/n)
im=fit(Image.open(R/'build/roster-body-art-v1/donkey-kong-preview24.png'),(24,32))
rgbdata=(R/'tools/Windows/NEXXT 3.0/defaults/nes.pal').read_bytes();rgb=[tuple(rgbdata[i:i+3])for i in range(0,192,3)];colors=[48,54,6]
v=[[0 if im.getpixel((x,y))[3]<128 else 1+min(range(3),key=lambda i:sum((im.getpixel((x,y))[j]-rgb[colors[i]][j])**2 for j in range(3)))for x in range(24)]for y in range(32)]
art=(A/'src/full_roster_menu_art.inc').read_text();rows=[[int(x)for x in re.findall(r'\d+',line)]for line in art.split('FmPreviewTiles:')[1].split('FmPreviewColors:')[0].splitlines()if'.byte'in line]
assert rows[17]==[112,112,132,134]
used_other={x//2 for i,row in enumerate(rows)if i!=17 for x in row};free=sorted(set(range(128))-used_other);assert free==[66,67,126,127]
raw=bytearray((A/'pending-previews.chr').read_bytes());allocated=[];records=[]
for top,left in[(0,0),(0,8),(0,16),(16,0),(16,8),(16,16)]:
 p=b''.join(encode([r[left:left+8]for r in v[top+h*8:top+h*8+8]])for h in range(2))
 flip=b''.join(encode([list(reversed(r[left:left+8]))for r in v[top+h*8:top+h*8+8]])for h in range(2))
 matches=[(i,a)for i,q in allocated for a,z in[(0,p),(64,flip)]if q==z]
 if matches:i,attr=matches[0]
 else:
  assert free,'Authentic DK exceeds existing CHR pool';i=free.pop(0);raw[i*32:i*32+32]=p;allocated.append((i,p));attr=0
 records.extend([159+top,i*2,attr,116+left])
assert len(allocated)==4 and len(records)==24
for i in used_other:assert raw[i*32:i*32+32]==(A/'pending-previews.chr').read_bytes()[i*32:i*32+32]
(O/'pending-previews.chr').write_bytes(raw)
# The old16px sample dropped the six native white eye pixels and duplicated
# skin in its palette. Wider source pixels must use original white/skin/brown.
parts=art.split('FmPreviewColors:');lines=parts[1].splitlines();assert lines[18].strip()=='.byte 6,54,54'
lines[18]=' .byte 48,54,6';(O/'src/full_roster_menu_art.inc').write_text(parts[0]+'FmPreviewColors:'+'\n'.join(lines)+'\n',newline='\n')

s=(A/'src/full_roster_menu.s').read_text();old=' jsr FmPending\n pha\n asl\n asl\n tay\n ldx #0\nCopy:';new=' jsr FmPending\n pha\n cmp #17\n beq WideDK\n asl\n asl\n tay\n ldx #0\nCopy:'
assert s.count(old)==1;s=s.replace(old,new)
old=' cpx #16\n bcc Copy\n stx CurrentOAMOffset';new=''' cpx #16
 bcc Copy
 bcs PreviewCopied
WideDK:
 ldy #23
WideCopy:
 lda FmDkPreviewOam,y
 sta Sprite_Data,y
 dey
 bpl WideCopy
 ldx #24
PreviewCopied:
 stx CurrentOAMOffset'''
assert s.count(old)==1;s=s.replace(old,new)
s=s.replace('FmPreviewX:.byte','FmDkPreviewOam:.byte '+','.join(map(str,records))+'\nFmPreviewX:.byte',1)
(O/'src/full_roster_menu.s').write_text(s,newline='\n')
entry=(A/'entrypoint.s').read_text().replace(A.as_posix(),O.as_posix());(O/'entrypoint.s').write_text(entry,newline='\n')
commands=[]
for cmd in closure['commands']:
 cmd=[x.replace(str(R/'build/full-roster-menu-independent-v5'),str(O)).replace(str(A),str(O))for x in cmd]
 commands.append(cmd);q=subprocess.run(cmd,cwd=R,capture_output=True,text=True)
 (O/('command-'+str(len(commands))+'.log')).write_text(q.stdout+q.stderr)
 assert q.returncode==0,(cmd,q.stderr)
sys.path.insert(0,str(R/'tools'));from prepare_cv3_dmc_mirror import prepare;prepare(R,O/'candidate.nes')
before=(A/'candidate.nes').read_bytes();after=(O/'candidate.nes').read_bytes();assert len(before)==len(after)
changed=[i for i,(x,y)in enumerate(zip(before,after))if x!=y]
assert all(16+76*8192+0x1979<=i<16+77*8192 or 1048592+700*1024<=i<1048592+704*1024 for i in changed)
p=dict(passed=True,native=False,admitted=False,parent_sha256=sha(A/'candidate.nes'),candidate_sha256=sha(O/'candidate.nes'),
 selected_DK_OAM=records,extra_UI_bytes=43,existing_UI_headroom_before=70,unique_added_CHR_pairs=4,
 changed_pool_pairs=[i for i,q in allocated],other32preview_records_and_palettes_exact=True,
 grid_CHR_nametable_exact=True,all_gameplay_and_foreign_CHR_exact=True,commands=commands,
 bindings={str(f.resolve()):sha(f)for f in[Path(__file__),A/'source-closure.json',R/'build/roster-body-art-v1/donkey-kong-manifest.json',*[f for f in O.rglob('*')if f.is_file()]]})
(O/'build-proof.json').write_text(json.dumps(p,indent=2)+'\n',newline='\n');print(json.dumps(dict(ROM=sha(O/'candidate.nes'),path=str(O/'build-proof.json'),changed=len(changed))))
