"""Real constructor/emergence/contact/progression CPU callers, not native."""
from pathlib import Path
import itertools,json,sys,traceback
R=Path(__file__).resolve().parents[1];sys.path[:0]=[str(R/'tools'),str(R/'tools/audit')]
import rogue_dawn_host_weapons_controls_v1 as w
from check_tmnt_render_oa import address,location
from verify_native_relocation import NesMPU
O=R/'build/rogue-dawn-host-items-v1';get,put,call=w.get,w.put,w.call

def constructor(m,x=128,y=160,slot=5):
 # Legal disclosed CPU scene/producer boundary: used solid block top160,
 # standing player feet160. Actual native constructor delivers the actor;
 # no reward/resource/state/mature/outcome is supplied by this setup.
 w.life.body.pipe.d.old.tile(m,x,y,0xc4)
 put(m,SprDataOffset_Ctrl=0,Block_PageLoc=x>>8,Block_X_Position=x&255,Block_Y_Position=y,ObjectOffset=slot)
 return call(m,'SetupPowerUp',x=slot)

def main():
 b=w.life.d.old.scoped_load(O/'candidate.nes');checks={};minimum=255
 proof=dict(passed=False,source_CPU_only=True,native_run=False,ROM=w.ref.binding(O/'candidate.nes'),checks=checks)
 try:
  rows=[]
  for mode in[0,1]:
   m=w.life.make(b,mode);call(m,'X5ColdInit');m[0x5fee]=1
   put(m,Player_X_Position=128,Player_PageLoc=0,Player_Y_Position=128,Player_State=0,SavedJoypadBits=0)
   # Real source fresh-game resource owner, not direct resource initialization.
   call(m,'NrFreshGameInit');first=True
   for reward in[216,217,*range(208,216),217]:
    before=bytes(m[0x5fb0:0x5fb6]);status=get(m,'PlayerStatus')
    c,l,tr=constructor(m);minimum=min(minimum,l)
    assert get(m,'InvPickup',5)==reward,(mode,reward,get(m,'InvPickup',5),list(before),status)
    assert get(m,'InvPickupSaveLo',5)==int(bool(status)) and get(m,'PowerUpType',5)==1
    assert get(m,'Enemy_State',5)==1 and bytes(m[0x5fb0:0x5fb6])==before
    timeline=[];contacts=[];oldstep=NesMPU.step
    def step(cpu):
     bank=m.banks[(cpu.pc-32768)//8192]if cpu.pc>=32768 else-1
     if bank==121 and cpu.pc==address(b,'RdItPickup'):contacts.append(dict(state=get(m,'Enemy_State',5),SP=cpu.sp))
     oldstep(cpu)
    NesMPU.step=step
    try:
     for age in range(100):
      c,row=w.life.mainstep(m,first=first);first=False;minimum=min(minimum,row['minimum_SP'])
      timeline.append([age,get(m,'Enemy_State',5),get(m,'Enemy_Y_Position',5),get(m,'Enemy_Flag',5),get(m,'Player_Y_Position'),get(m,'InvPickup',5),list(m[0x5fb0:0x5fb6])])
      if not get(m,'Enemy_Flag',5):break
      assert bytes(m[0x5fb0:0x5fb6])==before,('early grant',reward,timeline)
     else:raise AssertionError(('no actual mature contact',mode,reward,timeline,contacts))
    finally:NesMPU.step=oldstep
    assert len(contacts)==1 and contacts[0]['state']==128,('real contact',reward,contacts)
    assert get(m,'InvPickup',5)==get(m,'InvPickupOwner',5)==get(m,'InvRisePhase',5)==0
    assert get(m,'PlayerStatus')==1 and get(m,'PowerUpType',5)==1
    after=bytes(m[0x5fb0:0x5fb6]);assert after!=before
    rows.append(dict(mode=mode,reward=reward,raw_delivery=int(bool(status)),before=list(before),after=list(after),complete_Mains=len(timeline),timeline=timeline,actual_contacts=contacts))
   assert get(m,'RdGear')==255 and get(m,'RdTanks')==1 and get(m,'RdMaxMissiles')==get(m,'RdMissiles')==10
  checks['complete_native_constructor_emergence_physical_contact_next_constructor']=rows
  proof.update(passed=True,minimum_SP=minimum,limits=['Compiled actual CPU caller evidence with explicitly staged scene/constructor boundaries, not natural block bumps or native collected rewards.','No tested source resources, tier, ownership, health, maturity or collection outcomes are seeded.','Palette final colors, typed drop generation, hazards/bosses/audio/native timing remain open.'])
 except BaseException as e:proof.update(error=str(e),traceback=traceback.format_exc());raise
 finally:
  proof['bindings']=[w.ref.binding(p)for p in[Path(__file__),O/'build.json',O/'candidate.nes',O/'candidate.dbg',R/'src/rogue_dawn_host_items.s',R/'src/rogue_dawn_host_items_gate.s']]
  (O/'progression-controls.json').write_text(json.dumps(proof,indent=2)+'\n')
 print(json.dumps(dict(passed=True,cases=len(rows),minimum_SP=minimum)))
if __name__=='__main__':main()
