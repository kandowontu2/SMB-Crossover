"""Executable virtual-bank arrangement in reviewed gaps. This requests no lease."""
from pathlib import Path
import hashlib,importlib.util,json,re,subprocess,sys
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'build/arthur-host-prep-v5';BASE=ROOT/'build/arthur-host-prep-v4'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 OUT.mkdir(exist_ok=True)
 for n in ['host-world.s','host-render.s']:(OUT/n).write_bytes((BASE/n).read_bytes())
 p=OUT/'host-world.s';s=p.read_text()
 s=s.replace(' cmp #$15\n bcs NextEnemy',' cmp #$2d\n beq Eligible\n cmp #$15\n bcs NextEnemy\nEligible:')
 # Native crouch head is6px lower than the standing source head.
 s=s.replace(' lda Player_Y_Position\n clc\n adc YAdd,y',
  ' lda YAdd,y\n sta ArTemp\n cpy #0\n bne ProbeY\n lda ArR_04F0\n and #2\n beq ProbeY\n lda ArTemp\n clc\n adc #6\n sta ArTemp\nProbeY:lda Player_Y_Position\n clc\n adc ArTemp')
 p.write_text(s)
 spec=importlib.util.spec_from_file_location('arthurbuildv4',ROOT/'tools/audit/arthur_build_host_glue_v4.py');mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod);mod.OUT=OUT;mod.main()
 config='''# REQUESTED ARRANGEMENT ONLY. No PRG/RAM/ZP reservation granted.
MEMORY {
 PTR:start=$0003,size=$0002,type=rw,file="";
 ACTIVE:start=$5C00,size=$00B0,type=rw,file="";
 PROFILE:start=$5F90,size=$0008,type=rw,file="";
 A26:start=$A000,size=$2000,type=ro,file=%O,fill=yes,fillval=$FF;
 C63:start=$C000,size=$2000,type=ro,file=%O,fill=yes,fillval=$FF;
 C70:start=$C000,size=$2000,type=ro,file=%O,fill=yes,fillval=$FF;
}
SEGMENTS {
 ARTHUR_PTR:load=PTR,type=zp;
 ARTHUR_SCALARS:load=ACTIVE,type=bss;
 ARTHUR_STATE:load=ACTIVE,type=bss;
 ARTHUR_HOST_STATE:load=ACTIVE,type=bss;
 ARTHUR_PROFILE:load=PROFILE,type=bss;
 ARTHUR_WORLD:load=A26,type=ro,start=$A57A;
 ARTHUR_BODY:load=A26,type=ro,start=$B32A;
 ARTHUR_LEAF:load=A26,type=ro;
 ARTHUR_DRAW:load=A26,type=ro;
 ARTHUR_PROBES:load=A26,type=ro,start=$BD32;
 ARTHUR_COMBAT:load=A26,type=ro;
 ARTHUR_SHOTS:load=C63,type=ro,start=$D001;
 ARTHUR_LIFECYCLE:load=C63,type=ro;
 ARTHUR_COMMON:load=C63,type=ro,start=$DA4C;
 ARTHUR_CLOCK:load=C63,type=ro;
 ARTHUR_PUBLISH:load=C63,type=ro;
 ARTHUR_COMPACT_ART:load=C70,type=ro,start=$D9B8;
}
'''
 (OUT/'fragmented.cfg').write_text(config)
 objects=['native-kernels','component','host-state','host-world','host-render','fixture-imports','compact-art']
 cmd=[str(mod.BIN/'ld65.exe'),'-C',str(OUT/'fragmented.cfg'),'-o',str(OUT/'fragmented.bin'),'-Ln',str(OUT/'fragmented.lbl'),
  '--dbgfile',str(OUT/'fragmented.dbg'),'-m',str(OUT/'fragmented.map')]+[str(OUT/(n+'.o'))for n in objects]
 subprocess.run(cmd,check=True,cwd=ROOT)
 rows=[]
 for line in(OUT/'fragmented.dbg').read_text().splitlines():
  if not line.startswith('seg\t'):continue
  d=dict(v.split('=',1)for v in line[4:].split(',')if'='in v);name=d['name'].strip('"')
  if not name.startswith('ARTHUR_')or d.get('type')!='ro':continue
  start,size,pos=(int(d[k],0)for k in ['start','size','ooffs']);bank=[26,63,70][pos//8192]
  rows.append(dict(segment=name,bank=bank,cpu_start=start,cpu_end=start+size,bytes=size,physical_start=start-(0xa000 if bank==26 else 0xc000),file_offset=pos))
 requests=[(26,0x57a,0x800),(26,0x132a,0x1c00),(26,0x1d32,0x2000),(63,0x1001,0x1400),(63,0x1a4c,0x2000),(70,0x19b8,0x2000)]
 owner=json.loads((ROOT/'build/arthur-host-plan-v2/merged-occupancy.json').read_text())
 # Audit against the frozen merged ledger's explicit occupied records.
 occ=owner['ownership_records'];reservations=owner['explicit_PRG_reservations']
 for r in rows:
  lo,hi=r['physical_start'],r['physical_start']+r['bytes'];bank=r['bank']
  assert any(g['bank']==bank and g['offset_start']<=lo and hi<=g['offset_end_exclusive']for g in owner['remaining_PRG_gaps']),r
  assert not[o for o in occ if o.get('physical_bank')==bank and lo<o['bank_offset']+o['bytes']and o['bank_offset']<hi],r
  assert not[o for o in reservations if o['bank']==bank and lo<o['offset_end_exclusive']and o['offset_start']<hi],r
 proof=dict(status='EXECUTABLE_ABSTRACT_FRAGMENT_REQUEST_NO_PHYSICAL_LEASE',segments=rows,requested_gaps=[dict(bank=b,start=s,end=e,capacity=e-s)for b,s,e in requests],
  total_payload_bytes=sum(r['bytes']for r in rows),all_segments_exclude_frozen_linked_and_future_reservations=True,requests_are_not_grants=True,commands=[cmd],virtual_bank_image_sha256=sha(OUT/'fragmented.bin'),
  excluded_shared_mutations=['No cartridge image emitted','No shared source changed','No allocation/reservation file changed'],
  bindings={str(p.resolve()):sha(p)for p in[Path(__file__),OUT/'build-proof.json',OUT/'fragmented.cfg',OUT/'fragmented.bin',ROOT/'build/arthur-host-plan-v2/merged-occupancy.json']},
  limits='Gap locations follow the frozen v2 conservative ownership map, not fill bytes alone. Shared public importer/router code is not yet attached. Palette-color solution and native controller routes remain pending.')
 for r in rows:assert any(r['bank']==b and s<=r['physical_start']and r['physical_start']+r['bytes']<=e for b,s,e in requests),r
 p=OUT/'fragment-layout.json';p.write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(dict(bytes=proof['total_payload_bytes'],rows=rows,proof_sha256=sha(p))))
if __name__=='__main__':main()
