"""Cost an exact visible-color overlay, preserving all native world palette bytes."""
from pathlib import Path
import hashlib,json,sys
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'build/arthur-host-prep-v4';BASE=ROOT/'build/arthur-source-v1'
sys.path.insert(0,str(ROOT/'tools/audit'))
from check_tmnt_render_oa import load,location
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
PARENT=ROOT/'build/character-host-union-v4/candidate.nes'
def main():
 d=json.loads((BASE/'art-source.json').read_text());c=(BASE/'arthur-original-sprites.chr').read_bytes();pal=d['palette']['hardware_indices'][16:32]
 b=load(PARENT);world={}
 for n in ['WaterPaletteData','GroundPaletteData','UndergroundPaletteData','CastlePaletteData']:
  p=location(b,n);raw=b['raw'][p:p+36];assert raw[:3]==bytes([63,0,32]);world[n]=list(raw[3+24:3+28]);assert world[n]==[15,22,48,39]
 # Authentic source descriptor roles; limb poses copied from actual native
 # handlers. Exotic curse/effect poses remain outside this ordinary-body cost.
 roles={p:8 for p in range(0x16)}|{p:2 for p in range(0x20,0x36)}|{0x16:2,0x18:1,0x1a:1}
 records={r['pose']:r for r in d['records']};cost=[];allpatterns=set();perpose=[]
 def encode(values):
  return bytes(sum(((values[y][x]>>bit)&1)<<(7-x)for x in range(8))for bit in range(2)for y in range(8))+bytes(16)
 def picture(parts):
  out={}
  for p in reversed(parts):
   for yy in range(8):
    for xx in range(8):
     x=7-xx if p['a']&64 else xx;y=7-yy if p['a']&128 else yy
     v=p['values'][y][x]
     if v:out[p['x']+xx,p['y']+yy]=p['palette'][v]
  return out
 for pose,row in sorted(roles.items()):
  r=records[pose];before=[];after=[];patterns=set();parts=[];missing=set()
  for i,p in enumerate(r['parts']):
   if p['tile']==255:continue
   t=c[p['tile']*16:p['tile']*16+16];key=r['attribute_rows'][str(row)]['values'][i];pp=pal[key*4:key*4+4]
   values=[[(t[y]>>(7-x)&1)|((t[y+8]>>(7-x)&1)<<1)for x in range(8)]for y in range(8)]
   original=dict(x=p['x'],y=p['y'],a=p['attribute'],values=values,palette=pp);before.append(original)
   for palette_id,mapping,newpalette in [(0,{15:1,24:2,54:3},[15,15,24,54]),(2,{22:1,32:2},[15,22,48,39])]:
    out=[[mapping.get(pp[v],0)if v else 0 for v in line]for line in values]
    if not any(map(any,out)):continue
    code=encode(out);patterns.add(code);allpatterns.add(code)
    part=original|dict(values=out,palette=newpalette);after.append(part);parts.append(dict(x=p['x'],y=p['y'],attribute=p['attribute']|palette_id,height=16,pattern_sha256=hashlib.sha256(code).hexdigest()))
   missing.update(pp[v]for line in values for v in line if v and pp[v]not in [15,24,54,22,32])
  assert not missing,(pose,missing)
  left=picture(before);right=picture(after);right={xy:(32 if color==48 else color)for xy,color in right.items()};assert left==right,(pose,'color/opacity overlap')
  # Hardware8x16 blank half still consumes a scanline even when transparent.
  for part in parts:
   if part['attribute']&128:part['y']-=8
  peak=max(sum(p['y']<=y<p['y']+16 for p in parts)for y in range(-48,48))
  perpose.append(dict(poses=[pose],patterns=patterns));cost.append(dict(pose=pose,source_row=row,source_parts=len(before),overlay_parts=len(parts),max_body_sprites_per_scanline=peak,distinct_pairs=len(patterns),parts=parts))
 groups=perpose
 while True:
  choices=[(len(groups[i]['patterns']&groups[j]['patterns']),-len(groups[i]['patterns']|groups[j]['patterns']),-i,-j)for i in range(len(groups))for j in range(i)if len(groups[i]['patterns']|groups[j]['patterns'])<=32]
  if not choices:break
  _,_,ni,nj=max(choices);i,j=-ni,-nj;groups[j]=dict(poses=groups[j]['poses']+groups[i]['poses'],patterns=groups[j]['patterns']|groups[i]['patterns']);groups.pop(i)
 result=dict(status='EXACT_VISIBLE_BODY_COLOR_OVERLAY_COST_ONLY_NOT_ADOPTED',world_P2_actual_compiled_rows=world,
  proposed_P0=[15,15,24,54],world_rows_changed=False,white_alias=dict(original=32,world=48,meaning='NES20/30 displayed-white alias; raw index differs, all other visible codes exact.'),
  ordinary_native_body_cases=len(cost),global_distinct_pattern_pairs=len(allpatterns),global_CHR_bytes=len(allpatterns)*32,
  greedy_one_window_body_pages=[dict(poses=sorted(g['poses']),pairs=len(g['patterns']))for g in groups],
  body_pages_required_by_this_exact_greedy_construction=len(groups),body_page_budget=3,normal_sprite_limit=8,
  worst_body_scanline=max(p['max_body_sprites_per_scanline']for p in cost),cases=cost,
  unresolved='Lance/dagger/cross source blue12 is absent from all ordinary world sprite palettes and the three occupied P0color slots. This body-only overlay does not solve full weapon color parity. Never replace black with transparent zero.',
  limits='Cost construction only; extra overlays preserve source pixels but can exceed eight sprites when combined with world actors. Greedy pages are an actual fit, not a proven minimum. Curse/effect poses outside ordinary-body set are uncosted.',
  bindings={str(p.resolve()):sha(p)for p in[Path(__file__),PARENT,PARENT.with_suffix('.dbg'),BASE/'art-source.json',BASE/'arthur-original-sprites.chr']})
 p=OUT/'lossless-palette-cost.json';p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k not in ['cases','bindings']}|dict(receipt_sha256=sha(p))))
if __name__=='__main__':main()
