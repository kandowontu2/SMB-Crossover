"""Assemble real private host workers in a virtual address arena, never a ROM lease."""
from pathlib import Path
import hashlib,json,re,subprocess,sys
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'build/arthur-host-prep-v4';BASE=ROOT/'build/arthur-host-prep-v3'
BIN=ROOT/'tools/Windows/cc65/bin';sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
sys.path.insert(0,str(ROOT/'tools/audit'))
from check_tmnt_render_oa import load,address
PARENT=ROOT/'build/character-host-union-v4/candidate.nes'
NAMES=['SelectedCharacter','CurrentPlayer','NumberofLives','OffScr_NumberofLives','AreaNumber','WorldNumber','AreaAddrsLOffset',
 'CrossoverContinue','OperMode','GameEngineSubroutine','GamePauseStatus','SavedJoypad1Bits','TimerControl',
 'Player_X_Position','Player_PageLoc','Player_Y_Position','Player_Y_HighPos','Player_X_Scroll','Player_X_Speed',
 'Player_XSpeedAbsolute','Player_Y_Speed','Player_State','PlayerFacingDir','PlayerSize','PlayerStatus',
 'Player_CollisionBits','ScreenLeft_X_Pos','ScreenLeft_PageLoc','GetBlockBufferAddr','BlockBufferAddr','Block_Buffer_1',
 'MTileAttribute','CurrentOAMOffset','GuestOamRotationActive','RgOamRotation','Sprite_Y_Position','Sprite_Tilenumber',
 'Sprite_Attributes','Sprite_X_Position','Enemy_Flag','Enemy_ID','Enemy_State','Enemy_X_Position','Enemy_PageLoc',
 'Enemy_Y_Position','Enemy_Y_HighPos','BoundingBox_UL_Corner','BoundingBox_LR_Corner','BoundingBox_UL_Corner',
 'HandleEnemyFBallCol','KillPlayer','CurrentBank','CurrentBankC','X5SetPhysicalChr',
 'Square1SoundQueue','Square2SoundQueue','VRAM_Buffer1','VRAM_Buffer1_Offset','StarInvincibleTimer',
 'GuestPowerupActive','ObjectMetasprite']

def main():
 OUT.mkdir(exist_ok=True)
 for n in ('native-kernels.s','native-context.inc','component.s','host-state.s'):(OUT/n).write_bytes((BASE/n).read_bytes())
 native=(OUT/'native-kernels.s').read_text().replace('ArO_DF3E:', '.export ArNativeAddFall\nArNativeAddFall:\nArO_DF3E:')
 (OUT/'native-kernels.s').write_text(native)
 comp=(OUT/'component.s').read_text().replace('.export ArInit,ArTick,ArStep,ArOnLand,', '.export ArOnSupport,ArOnLedge\n.import ArNativeAddFall\n.export ArInit,ArTick,ArStep,ArOnLand,')
 comp=comp.replace('ArHostAheadTile,ArHostFloorTile,','')
 comp=comp.replace('Falling:lda ArR_0607','Falling:lda ArMode\n cmp #3\n bne CurveFall\n lda #6\n jsr ArNativeAddFall\n jmp AirPose\nCurveFall:lda ArR_0607')
 comp=comp.replace(' jsr ArNativeAlignFloor\n jsr ArNativeClearAir',' jsr ArNativeAlignFloor\n::ArOnSupport:\n jsr ArNativeClearAir')
 comp=comp.replace('.proc ArOnCeiling','; Original E2B0 ledge loop: fixed6px fall, no horizontal movement.\n.proc ArOnLedge\n lda #3\n sta ArMode\n lda #1\n sta ArJumpCount\n lda #0\n sta ArR_065D\n sta ArR_0607\n ldx #0\n jmp ArNativeSetAir\n.endproc\n.proc ArOnCeiling')
 comp=comp.replace('ArHostAheadTile:lda ArAheadTile\n rts\nArHostFloorTile:lda ArFloorTile\n rts\n','')
 (OUT/'component.s').write_text(comp)
 (OUT/'compact-art.s').write_bytes((ROOT/'build/arthur-projected-leaf-v3/compact-art.s').read_bytes())
 b=load(PARENT);fixtures=['; Exact parent ABI, private arena only. No empty service callbacks.']
 for n in dict.fromkeys(NAMES):
  if n not in b['syms']:raise KeyError(n)
  fixtures += [('.exportzp ' if address(b,n)<256 else '.export ')+n,n+'=$'+f'{address(b,n):04x}']
 for i in range(8):fixtures += [f'.exportzp R{i}',f'R{i}=${address(b,"R"+str(i)):02x}']
 fixtures += ['.exportzp ARTHUR_ART_PHASE_BANK,ARTHUR_NATIVE_PHASE_BANK','ARTHUR_ART_PHASE_BANK=$c6','ARTHUR_NATIVE_PHASE_BANK=$bf']
 (OUT/'fixture-imports.s').write_text('\n'.join(fixtures)+'\n')
 positions={'BODY':0xa000,'LEAF':0xa400,'WORLD':0xa740,'PROBES':0xab00,'DRAW':0xac00,'COMBAT':0xb000,
  'PUBLISH':0xcb00,'LIFECYCLE':0xc800,'CLOCK':0xca00,'COMMON':0xc000,'SHOTS':0xc500,'COMPACT_ART':0xd000}
 cfg='''# Virtual contiguous sizing arena only. Physical mapper split follows separately.
MEMORY {
 PTR:start=$0003,size=$0002,type=rw,file="";
 ACTIVE:start=$5C00,size=$00B0,type=rw,file="";
 PROFILE:start=$5F90,size=$0008,type=rw,file="";
 CODE:start=$8000,size=$6000,type=ro,file=%O,fill=yes,fillval=$FF;
}
SEGMENTS {
 ARTHUR_PTR:load=PTR,type=zp;
 ARTHUR_SCALARS:load=ACTIVE,type=bss;
 ARTHUR_STATE:load=ACTIVE,type=bss;
 ARTHUR_HOST_STATE:load=ACTIVE,type=bss;
 ARTHUR_PROFILE:load=PROFILE,type=bss;
'''
 for n,at in sorted(positions.items(),key=lambda v:v[1]):cfg+=f' ARTHUR_{n}:load=CODE,type=ro,start=${at:04X};\n'
 cfg+='}\n';(OUT/'abstract.cfg').write_text(cfg)
 commands=[];objects=['native-kernels','component','host-state','host-world','host-render','fixture-imports','compact-art']
 for n in objects:
  cmd=[str(BIN/'ca65.exe'),'-g','-I',str(OUT),'-o',str(OUT/(n+'.o')),str(OUT/(n+'.s'))];commands.append(cmd);subprocess.run(cmd,check=True,cwd=ROOT)
 cmd=[str(BIN/'ld65.exe'),'-C',str(OUT/'abstract.cfg'),'-o',str(OUT/'abstract.bin'),'-Ln',str(OUT/'abstract.lbl'),
  '--dbgfile',str(OUT/'abstract.dbg'),'-m',str(OUT/'abstract.map')]+[str(OUT/(n+'.o'))for n in objects]
 commands.append(cmd);subprocess.run(cmd,check=True,cwd=ROOT)
 segments={m[1]:int(m[2],0)for l in(OUT/'abstract.dbg').read_text().splitlines()if l.startswith('seg\t')and(m:=re.search(r'name="(ARTHUR_[^"]+)".*size=(0x[0-9A-Fa-f]+)',l))}
 deps=[Path(__file__),PARENT,PARENT.with_suffix('.dbg'),BASE/'build-proof.json',OUT/'abstract.cfg']+[OUT/(n+'.s')for n in objects]+[OUT/'native-context.inc']
 d=dict(status='ABSTRACT_REAL_HOST_GLUE_BUILD_NOT_A_HOST_ROM',segments=segments,code_bytes=sum(v for k,v in segments.items()if k not in ['ARTHUR_PTR','ARTHUR_SCALARS','ARTHUR_STATE','ARTHUR_HOST_STATE','ARTHUR_PROFILE']),
  commands=commands,output_sha256=sha(OUT/'abstract.bin'),bindings={str(p.resolve()):sha(p)for p in deps},
  limits='No physical PRG/RAM/ZP lease or shared mutation. Source palette rows are retained; lossless world-compatible palette routing still requires proof. Abstract art and native phases use virtual bank IDs only; never install this arena as a ROM.')
 p=OUT/'build-proof.json';p.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(segments=segments,code_bytes=d['code_bytes'],proof_sha256=sha(p))))
if __name__=='__main__':main()
