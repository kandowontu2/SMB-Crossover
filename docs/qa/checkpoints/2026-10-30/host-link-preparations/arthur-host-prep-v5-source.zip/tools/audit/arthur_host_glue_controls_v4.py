"""Actual6502 virtual MMC5 arena, authentic fixed-bank world services, no native route claim."""
from pathlib import Path
import hashlib,itertools,json,re,sys
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'build/arthur-host-prep-v4'
sys.path.insert(0,str(ROOT/'tools/audit'))
from check_tmnt_render_oa import Memory as ParentMemory,address,load
from verify_native_relocation import NesMPU
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
PARENT=ROOT/'build/character-host-union-v4/candidate.nes';B=load(PARENT)
S={m[2]:int(m[1],16)for l in(OUT/'abstract.lbl').read_text().splitlines()if(m:=re.match(r'al ([0-9A-Fa-f]+) \.(\w+)',l))}
RAW=(OUT/'abstract.bin').read_bytes()
class Memory(ParentMemory):
 def __init__(self):
  self.virtual={26:RAW[0x2000:0x4000],63:RAW[0x4000:0x6000],70:bytes([255])*4096+RAW[0x5000:0x6000]}
  super().__init__(B);self.page(1,26);self.page(2,63);self[S['CurrentBank']]=154;self[S['CurrentBankC']]=191
  self.pc=None;self.reads=[]
 def page(self,window,bank):
  if hasattr(self,'virtual')and bank in self.virtual:
   self.banks[window]=bank
   list.__setitem__(self,slice(0x8000+window*8192,0xa000+window*8192),self.virtual[bank])
  else:super().page(window,bank)
 def __getitem__(self,key):
  if isinstance(key,int)and hasattr(self,'reads')and(0x5c00<=key<0x5cb0 or 0x5f90<=key<0x5f98):self.reads.append((key,self.pc))
  return super().__getitem__(key)
class CPU:
 def __init__(self):self.m=Memory();self.c=NesMPU(memory=self.m)
 def put(self,**kw):
  for k,v in kw.items():self.m[S[k]]=v&255
 def get(self,k,i=0):return self.m[S[k]+i]
 def call(self,name,a=0,x=0,y=0,p=0x24,remap=True):
  if remap:self.m.page(1,26);self.m.page(2,63);self.put(CurrentBank=154,CurrentBankC=191)
  c=self.c;c.a,c.x,c.y,c.p,c.sp=a,x,y,p,0xfd;c.stPushWord(0x5aff);c.pc=S.get(name,address(B,name)if name in B['syms']else 0)
  self.m.writes=[];self.m.reads=[];seen=[]
  for _ in range(100000):
   if c.pc==0x5b00:assert c.sp==0xfd,(name,c.sp);return seen
   self.m.pc=c.pc;seen.append((c.pc,tuple(self.m.banks)));c.step()
  raise AssertionError((name,hex(c.pc),self.m.banks,'bound'))
 def setup(self):
  self.put(SelectedCharacter=32,CurrentPlayer=0,NumberofLives=2,OffScr_NumberofLives=4,AreaNumber=0,WorldNumber=0,AreaAddrsLOffset=0,
   CrossoverContinue=0,OperMode=1,GameEngineSubroutine=8,GamePauseStatus=0,TimerControl=0,
   Player_X_Position=96,Player_PageLoc=1,Player_Y_Position=176,Player_Y_HighPos=1,Player_CollisionBits=3,
   ScreenLeft_X_Pos=0,ScreenLeft_PageLoc=1,CurrentOAMOffset=0)
  self.call('ArHostSelect',18)

def coordinates():
 c=CPU();c.setup();count=0
 for worldY,x,page in itertools.product(range(768),[0,96,249,255],[0,1,127,255]):
  c.put(Player_X_Position=x,Player_PageLoc=page,Player_Y_Position=worldY&255,Player_Y_HighPos=worldY>>8,ArHostOldX=x,ArHostOldY=worldY&255)
  c.call('ArHostImport');nativeY=c.get('ArR_0599')+240*(c.get('ArR_056D')if c.get('ArR_056D')<128 else c.get('ArR_056D')-256)
  assert nativeY==worldY-232,(worldY,nativeY)
  assert c.get('ArR_05AF')+256*c.get('ArR_0583')==((x+256*page+8)&65535)
  c.call('ArHostExport')
  assert(c.get('Player_X_Position'),c.get('Player_PageLoc'),c.get('Player_Y_Position'),c.get('Player_Y_HighPos'))==(x,page,worldY&255,worldY>>8)
  count+=1
 return dict(cases=count,all_Y0_through767_signed240page_roundtrips=True,horizontal_carry_wrap=True)

def foreign():
 count=0
 for raw,n in itertools.product([x for x in range(256)if x!=32],['ArHostMovement','ArHostAfterTerrain','ArHostHead','ArHostFoot','ArHostSide','ArHostBox','ArHostInjury','ArHostPickup','ArHostShotContacts','ArHostDraw']):
  c=CPU();c.put(SelectedCharacter=raw);c.call(n,a=0x55,x=3,y=2)
  assert not c.m.reads,(raw,n,c.m.reads[:4])
  assert not [(at,v)for at,v in c.m.writes if 0x5c00<=at<0x5cb0 or 0x5f90<=at<0x5f98]
  count+=1
 return dict(cases=count,all_public_foreign_entries_zero_owned_reads_and_writes=True)

def terrain():
 c=CPU();c.setup();a=address(B,'MTileAttribute');solid=next(i for i in range(1,256)if c.m[a+i]&1);count=0
 # Actual fixed GetBlockBufferAddr and MTileAttribute remain in original PRG.
 for page,col,row in itertools.product([0,1,2,15],range(16),[0,1,7,12]):
  xp=page*256+col*16;yp=32+row*16
  c.put(R2=xp&255,R3=xp>>8,R4=yp,R5=0);c.call('ArHostReadPoint')
  target=c.get('R6')+256*c.get('R7')+row*16;c.m[target]=solid
  c.put(R2=xp&255,R3=xp>>8,R4=yp,R5=0);c.call('ArHostReadPoint')
  assert c.c.p&1 and c.c.a==solid,(page,col,row,solid,c.c.a)
  c.m[target]=0
  c.put(R2=xp&255,R3=xp>>8,R4=yp,R5=0);c.call('ArHostReadPoint');assert not c.c.p&1 and c.c.a==0
  count+=2
 for yp,high in [(0,0),(31,0),(240,0),(255,0),(100,1),(100,255)]:
  c.put(R4=yp,R5=high);c.call('ArHostReadPoint');assert not c.c.p&1
 # Native support adapter must preserve a non16px-aligned platform landing.
 c.put(Player_Y_Position=163,Player_Y_HighPos=1,Player_State=0,ArMode=2)
 c.call('ArHostAfterTerrain');assert c.get('ArMode')==0 and c.get('ArR_0599')==187
 c.put(Player_State=2,ArMode=0);c.call('ArHostAfterTerrain');assert c.get('ArMode')==3
 before=c.get('ArR_0599');c.call('ArStep',0);assert c.get('ArR_0599')==before+6
 return dict(actual_parent_fixed_service_calls=count,offscreen_empty_cases=6,arbitrary_platform_support_preserved=True,original_ledge_six_pixel_fall=True)

def movement():
 c=CPU();c.setup();c.put(SavedJoypad1Bits=1);r0,r1=0xa3,0x6e;c.put(R0=r0,R1=r1)
 for i in range(90):
  c.call('ArHostNmiClock');c.call('ArHostMovement');c.call('ArHostAfterTerrain')
  assert(c.get('R0'),c.get('R1'))==(r0,r1)
 assert c.get('ArUpdates')==30 and c.get('Player_X_Position')==186
 # Current first authored restart held for6steps, then exact original6phase jump.
 jumps=[]
 for double in [False,True]:
  c=CPU();c.setup();start=c.get('Player_Y_Position');minimum=start
  for i in range(24):
   pad=128 if i==0 or(double and i==6)else 0
   c.put(ArHostPad=pad,ArHostDue=1)
   c.call('ArHostMovement');minimum=min(minimum,c.get('Player_Y_Position'))
  jumps.append(start-minimum)
 assert jumps==[32,64],jumps
 return dict(video_ticks=90,source_updates=30,walk_pixels=90,borrowed_R0_R1_preserved=True,native_jump_and_authored_restart_apex=jumps,
  scope='No actual native pipe/gap traversal claim; terrain consumer controller route is still required after host hooks exist.')

def render():
 records=json.loads((ROOT/'build/arthur-projected-leaf-v2/windowed-art-proof.json').read_text())['records'];count=0
 for r,offset,rotate in itertools.product(records,[0,228,248,252],[0,1]):
  c=CPU();c.setup();c.put(ArR_0522=r['pose'],ArR_053B=r['attribute_row'],CurrentOAMOffset=offset,
    GuestOamRotationActive=rotate,RgOamRotation=64,R0=0xab,R1=0x7e)
  # Isolate body even for source weapon descriptors to verify all84 legal poses.
  for i in range(1,4):c.m[S['ArR_04F0']+i]=0
  before=[(37*i+9)&255 for i in range(256)];c.m[0x200:0x300]=before
  c.call('ArHostDraw')
  assert(c.get('R0'),c.get('R1'),c.get('CurrentBank'),c.get('CurrentBankC'))==(0xab,0x7e,154,191)
  expected=before[:];at=offset
  for part in r['parts']:
   x=104+part['x'];y=200+part['y']
   if not 0<=x<=255 or not 0<=y<240 or at+4>255:continue
   slot=(at+(64 if rotate else 0))&255
   # Deliberately place all test descriptors in bodywindow0 here.
   expected[slot:slot+4]=[y,part['local_tile'],part['attribute'],x];at+=4
  assert list(c.m[0x200:0x300])==expected,(r['pose'],r['attribute_row'],offset,rotate)
  assert c.get('CurrentOAMOffset')==at
  # Real linked publisher writes only window0/window6 mode entries.
  assert c.m[address(B,'CurrentCHRBank')]==247+r['relative_page']
  assert c.m[address(B,'CurrentCHRBank')+6]==250
  assert c.m[address(B,'X5ChrMode')]==128 and c.m[address(B,'X5ChrMode')+6]==128
  count+=1
 # Simultaneous three different shots must share window6 and retain their tiles.
 c=CPU();c.setup();poses=[0x36,0xa0,0xf8]
 for i,pose in enumerate(poses,1):
  for n,val in [('ArR_04F0',128),('ArR_0522',pose),('ArR_053B',1),('ArR_05AF',104+24*i),('ArR_0583',1),('ArR_0599',180),('ArR_056D',0)]:c.m[S[n]+i]=val
 c.call('ArHostDraw');assert c.m[address(B,'CurrentCHRBank')+6]==250
 return dict(source_descriptor_cases=count,all_84poses_times5source_palettes=True,capacity_and_rotation=True,
  true_source_index_alpha_priority_projection=True,source_palette_rows_retained_not_installed=True,
  both_banks_and_R0_R1_restored=True,simultaneous_three_weapon_window6=True)

def main():
 result=dict(status='PASS_ACTUAL6502_ABSTRACT_HOST_WORKERS_NOT_NATIVE_ADMISSION',coordinates=coordinates(),guards=foreign(),terrain=terrain(),movement=movement(),render=render(),
  bindings={str(p.resolve()):sha(p)for p in[Path(__file__),OUT/'abstract.bin',OUT/'abstract.dbg',OUT/'build-proof.json',PARENT,PARENT.with_suffix('.dbg'),ROOT/'build/arthur-projected-leaf-v2/windowed-art-proof.json']},
  limits='No physical PRG/RAM/ZP lease, no shared source/ROM changes. Palette compatibility, native source audio, NMI interleavings, real controller world route and host hook consumers remain unverified.')
 p=OUT/'host-glue-controls.json';p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(status=result['status'],checks={k:v for k,v in result.items()if k not in ['bindings','limits']},receipt_sha256=sha(p))))
if __name__=='__main__':main()
