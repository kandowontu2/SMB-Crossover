"""Executable phase-alias, lifecycle and NMI-event ownership controls."""
from pathlib import Path
import hashlib,json,random,re,sys
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'build/arthur-host-prep-v4'
sys.path.insert(0,str(ROOT/'tools/audit'))
from verify_native_relocation import NesMPU
from link_pit_rygar_sophia_audit_cpu import Arena,scoped_load
from check_tmnt_render_oa import address
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
S={m[2]:int(m[1],16)for l in(OUT/'abstract.lbl').read_text().splitlines()if(m:=re.match(r'al ([0-9A-Fa-f]+) \.(\w+)',l))}
RAW=(OUT/'abstract.bin').read_bytes()
PRIVATE=lambda at:0x5c00<=at<0x5cb0 or 0x5f90<=at<0x5f98
class Memory(list):
    def __init__(self):super().__init__([0]*65536);self.pc=None;self.reads=[];self.writes=[]
    def __getitem__(self,key):
        if isinstance(key,int)and PRIVATE(key):self.reads.append((key,self.pc))
        return super().__getitem__(key)
    def __setitem__(self,key,value):
        if isinstance(key,int):self.writes.append((key,value,self.pc))
        super().__setitem__(key,value)
def cpu():
    mem=Memory();mem[0x8000:0xe000]=RAW;return NesMPU(memory=mem)
def put(c,n,v,i=0):c.memory[S[n]+i]=v
def get(c,n,i=0):return c.memory[S[n]+i]
def call(c,n,a=0,x=0,y=0,p=0x24,mirror=False):
    c.a,c.x,c.y,c.p,c.sp=a,x,y,p,0xfd;c.stPushWord(0x5afe);c.pc=S[n]-(0x2000 if mirror else 0)
    c.memory.reads=[];c.memory.writes=[];seen=[]
    for _ in range(50000):
        if c.pc==0x5aff:assert c.sp==0xfd;return seen
        c.memory.pc=c.pc;seen.append(c.pc);c.step()
    raise AssertionError((n,hex(c.pc),'bound'))
def setup(c):
    for n,v in dict(SelectedCharacter=32,CurrentPlayer=0,NumberofLives=2,OffScr_NumberofLives=4,
       AreaNumber=0,WorldNumber=0,AreaAddrsLOffset=0,CrossoverContinue=0,OperMode=1,
       GameEngineSubroutine=8,GamePauseStatus=0,SavedJoypad1Bits=0).items():put(c,n,v)
    call(c,'ArHostSelect',18)

def guards():
    names=['ArHostSelect','ArHostFresh','ArHostEnsure','ArHostSave','ArHostDeath','ArHostNativePickup','ArHostNmiClock']
    rng=random.Random(320176);count=0
    for raw in range(256):
        if raw==32:continue
        for name in names:
            c=cpu()
            for a in range(0x5c00,0x5cb0):c.memory[a]=rng.randrange(256)
            for a in range(0x5f90,0x5f98):c.memory[a]=rng.randrange(256)
            before=bytes(c.memory[0x5c00:0x5cb0])+bytes(c.memory[0x5f90:0x5f98])
            put(c,'SelectedCharacter',raw);call(c,name,a=18 if name=='ArHostSelect'else 8)
            assert not c.memory.reads,(raw,name,c.memory.reads[:4])
            assert not[w for w in c.memory.writes if PRIVATE(w[0])],(raw,name)
            assert before==bytes(c.memory[0x5c00:0x5cb0])+bytes(c.memory[0x5f90:0x5f98])
            count+=1
    return dict(public_entries=names,foreign_raw_IDs=255,cases=count,no_overlay_reads_or_writes=True)

def lifecycle():
    c=cpu();setup(c);assert get(c,'ArHostReady')==167 and get(c,'ArR_053A')==64
    call(c,'ArHostNativePickup',6);assert get(c,'ArR_053A')==68
    call(c,'ArTakeHit');assert get(c,'ArR_04F0')&32
    call(c,'ArHostSave');assert get(c,'ArProfileWeapon')==68 and get(c,'ArProfileFlags')==32
    # Actual1UP wrap/gain retains source weapon/armor, modulo losses reset it.
    for old,new,loss in((2,3,False),(255,0,False),(3,2,True),(0,255,True)):
        setup(c);call(c,'ArHostNativePickup',8);call(c,'ArTakeHit');call(c,'ArHostSave')
        put(c,'ArHostLife',old);put(c,'ArProfileLife',old);put(c,'NumberofLives',new)
        call(c,'ArHostEnsure')
        assert get(c,'ArR_053A')==(64 if loss else 66)
        assert bool(get(c,'ArR_04F0')&32)==(not loss)
    setup(c);call(c,'ArHostNativePickup',7);call(c,'ArHostSave')
    for field,value in(('AreaNumber',1),('WorldNumber',2),('AreaAddrsLOffset',7)):
        put(c,'ArR_0607',5);put(c,'ArUpdates',99);put(c,field,value);call(c,'ArHostEnsure')
        assert get(c,'ArR_053A')==54 and get(c,'ArUpdates')==0 and get(c,'ArHostPhase')==1
    call(c,'ArHostDeath');assert get(c,'ArDead')==1 and get(c,'ArR_0522')==26 and get(c,'ArR_053B')==1
    put(c,'NumberofLives',1);call(c,'ArHostEnsure');assert get(c,'ArDead')==0 and get(c,'ArR_053A')==64 and not get(c,'ArR_04F0')&32
    # A same-owner real continue preserves; fresh/newowner always reconstructs.
    setup(c);call(c,'ArHostNativePickup',9);call(c,'ArTakeHit');call(c,'ArHostSave')
    put(c,'CrossoverContinue',1);call(c,'ArHostSelect',32);assert get(c,'ArR_053A')==79 and get(c,'ArR_04F0')&32
    call(c,'ArHostSelect',18);assert get(c,'ArR_053A')==64 and not get(c,'ArR_04F0')&32
    return dict(modulo_life_cases=4,scene_keys=['AreaNumber','WorldNumber','AreaAddrsLOffset'],
        actual_native_armor_weapon_and_death=True,same_owner_continue_and_foreign_owner_reentry=True)

def native_transpose():
    b=scoped_load(ROOT/'build/character-host-union-v4/candidate.nes');q=Arena(b,32);c=cpu();setup(c)
    call(c,'ArHostNativePickup',6);call(c,'ArTakeHit');call(c,'ArHostSave')
    # The actual source crossover menu forces single-player each input poll.
    # Still exercise real native transpose with its optional flag set in this
    # disclosed CPU fixture, proving future alternation cannot cross inventory.
    def transpose():
        for i in range(0x8000):q.m[i]=c.memory[i]
        q.put(NumberOfPlayers=1)
        for n,v in [('OffScr_NumberofLives',4),('OffScr_WorldNumber',1),('OffScr_AreaNumber',3)]:
            if get(c,'CurrentPlayer')==0 and not get(c,'ArProfileTag',1):q.m[address(b,n)]=v
        result,trace=q.invoke('NativeRareTransposePlayersCore')
        assert not result.p&1 and not[w for w in trace if PRIVATE(w['address'])]
        c.memory[:0x8000]=q.m[:0x8000]
        call(c,'ArHostEnsure')
    transpose();assert get(c,'CurrentPlayer')==1 and get(c,'ArR_053A')==64 and not get(c,'ArR_04F0')&32
    call(c,'ArHostNativePickup',8);call(c,'ArHostSave')
    transpose();assert get(c,'CurrentPlayer')==0 and get(c,'ArR_053A')==68 and get(c,'ArR_04F0')&32
    # Genuine player0 death/life decrease before the actual native transpose.
    put(c,'NumberofLives',1);transpose()
    assert get(c,'CurrentPlayer')==1 and get(c,'ArR_053A')==66
    transpose();assert get(c,'CurrentPlayer')==0 and get(c,'ArR_053A')==64 and not get(c,'ArR_04F0')&32
    # Actual global newgame clearing occurs before the final owned constructor.
    for i in range(0x8000):q.m[i]=c.memory[i]
    q.invoke('X5ProfilesNewGame');c.memory[:0x8000]=q.m[:0x8000]
    assert not any(c.memory[0x5c00:0x5cb0])and not any(c.memory[0x5f90:0x5f98])
    call(c,'ArHostSelect',32);assert get(c,'ArR_053A')==64 and get(c,'ArProfileTag')==167
    return dict(actual_parent_ROM_sha256=sha(ROOT/'build/character-host-union-v4/candidate.nes'),
       real_native_transposes=4,independent_player_weapons_armor_and_death_reset=True,
       actual_X5ProfilesNewGame_clear_before_constructor=True,
       installed_menu_policy='CrossoverMenuInput sets NumberOfPlayers0; alternating-player tests deliberately enable the existing native path in CPU fixture only.')

def clock():
    c=cpu();setup(c);put(c,'SavedJoypad1Bits',1);x0=get(c,'ArR_05AF');updates=0
    for _ in range(30):
        call(c,'ArHostNmiClock')
        if get(c,'ArHostDue'):
            put(c,'ArHostDue',0);call(c,'ArStep',get(c,'ArHostPad'));updates+=1
        # An immediate catch-up Main has no new video event.
        assert get(c,'ArHostDue')==0
    assert updates==10 and get(c,'ArR_05AF')==x0+30
    before=(get(c,'ArHostPhase'),get(c,'ArUpdates'));put(c,'GamePauseStatus',1)
    for _ in range(25):call(c,'ArHostNmiClock')
    assert(get(c,'ArHostPhase'),get(c,'ArUpdates'))==before
    put(c,'GamePauseStatus',0)
    for _ in range(30):call(c,'ArHostNmiClock')
    assert get(c,'ArHostDue')==1 # saturating cooperative task, never30 physics steps
    # Only RAM accesses/relative branches occur in clock, so its A mirror in
    # the already-selected common bank is executable without C remapping.
    lo=S['ArHostNmiClock'];size=json.loads((OUT/'build-proof.json').read_text())['segments']['ARTHUR_CLOCK']
    source=c.memory[lo:lo+size];c.memory[lo-0x2000:lo-0x2000+size]=source
    mirror_cases=0
    for raw in(0,18,25,26,28,32,255):
        for ready in(0,167):
            for flags in(0x20,0x21,0x68,0xef):
                a=cpu();z=cpu();setup(a);setup(z)
                for t in(a,z):put(t,'SelectedCharacter',raw);put(t,'ArHostReady',ready)
                z.memory[lo-0x2000:lo-0x2000+size]=source
                call(a,'ArHostNmiClock',a=0x59,x=0xc3,y=0x7a,p=flags)
                call(z,'ArHostNmiClock',a=0x59,x=0xc3,y=0x7a,p=flags,mirror=True)
                for t in(a,z):assert(t.a,t.x,t.y,t.p&0xcf,t.sp)==(0x59,0xc3,0x7a,flags&0xcf,0xfd)
                assert a.memory[0x5c00:0x5cb0]==z.memory[0x5c00:0x5cb0]
                assert not any(0x5114<=at<=0x5130 for at,_,_ in z.memory.writes)
                mirror_cases+=1
    return dict(video_ticks=30,source_updates=10,walk_pixels=30,catchup_Main_cannot_add_physics=True,
       paused_video_ticks_preserve_phase=True,overdue_updates_coalesce=True,actual_A_view_clock_mirror_cases=mirror_cases,
       no_ZP_mapper_SMC_or_profile_access=True)

def main():
    result=dict(status='PASS_EXECUTABLE_RAW32_PHASE_ALIAS_LIFECYCLE_AND_NMI_EVENT_CONTROLS',
        owner_guards=guards(),lifecycle=lifecycle(),native_alternation=native_transpose(),clock=clock(),
        active_range=['5C00','5CB0'],profile_range=['5F90','5F98'],
        global_clear_order='Actual X5ProfilesNewGame/IcGlobalInit may clear aliases. Final raw32 constructor must run after generic newgame initialization.',
        PRG_RAM_ZP_lease_granted=False,
        bindings={str(p.resolve()):sha(p)for p in[Path(__file__),OUT/'build-proof.json',OUT/'host-state.s',OUT/'abstract.bin',OUT/'abstract.lbl',
            ROOT/'build/character-host-union-v4/candidate.nes',ROOT/'build/character-host-union-v4/candidate.dbg',ROOT/'src/character_select.s',ROOT/'src/bill_native_rare.s',ROOT/'src/ice_climbers_core.s']},
        limits='Explicit actual6502 arenas. Existing native transpose/newgame functions execute; position importer is still a disclosed no-op fixture. No complete Main/world/native route, mapper entry wrapper or original audio claim.')
    p=OUT/'lifecycle-controls.json';p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(status=result['status'],guards=result['owner_guards']['cases'],receipt_sha256=sha(p))))
if __name__=='__main__':main()
