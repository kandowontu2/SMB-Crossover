"""Run real6502 worker controls through the requested physical fragmentation virtually."""
from pathlib import Path
import hashlib,importlib.util,json,re
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'build/arthur-host-prep-v5'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 path=ROOT/'tools/audit/arthur_host_glue_controls_v4.py';spec=importlib.util.spec_from_file_location('arthurcontrols',path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
 m.S={v[2]:int(v[1],16)for l in(OUT/'fragmented.lbl').read_text().splitlines()if(v:=re.match(r'al ([0-9A-Fa-f]+) \.(\w+)',l))};raw=(OUT/'fragmented.bin').read_bytes()
 base=m.Memory
 class FragmentMemory(base):
  def __init__(self):
   self.virtual={b:raw[i*8192:(i+1)*8192]for i,b in enumerate([26,63,70])}
   m.ParentMemory.__init__(self,m.B);self.page(1,26);self.page(2,63);self[m.S['CurrentBank']]=154;self[m.S['CurrentBankC']]=191;self.pc=None;self.reads=[]
 m.Memory=FragmentMemory
 checks={name:getattr(m,name)()for name in ['coordinates','foreign','terrain','movement','render']}
 # Exercise actual native source shot/contact followed by the unchanged SMB
 # score/fireproof/Bowser hit consumer, with explicit legal CPU fixture state.
 c=m.CPU();c.setup()
 def enemy(kind,hp=5):
  for n,val in [('Enemy_Flag',1),('Enemy_ID',kind),('Enemy_State',0),('Enemy_X_Position',120),('Enemy_PageLoc',1),('Enemy_Y_Position',176),('Enemy_Y_HighPos',1)]:c.m[m.S[n]]=val
  if'BowserHitPoints'in m.B['syms']:c.m[m.address(m.B,'BowserHitPoints')]=hp
  for n,val in [('ArR_04F0',128),('ArR_0631',0x23),('ArR_05AF',128),('ArR_0583',1),('ArR_0554',128),('ArR_0509',184)]:c.m[m.S[n]+1]=val
  c.call('ArHostShotContacts')
 enemy(6);assert c.get('Enemy_State')&32
 enemy(2);assert not c.get('Enemy_State')&32
 enemy(0x2d);assert c.m[m.address(m.B,'BowserHitPoints')]==4
 checks['actual_source_contact_and_world_weapon_consumer']=dict(Goomba_defeated=True,Buzzy_fireproof=True,Bowser_real_HP_decrement=True)
 d=dict(status='PASS_EXECUTABLE_VIRTUAL_FRAGMENT_ARRANGEMENT_NOT_A_PRG_LEASE',checks=checks,
  bindings={str(p.resolve()):sha(p)for p in[Path(__file__),path,OUT/'fragmented.bin',OUT/'fragmented.dbg',OUT/'fragment-layout.json',OUT/'build-proof.json',m.PARENT,m.PARENT.with_suffix('.dbg')]},
  limits='No shared source or cartridge changed. Public host importers/router not installed, palette-color ownership unresolved, no native controller route/NMI-interleaving/source-audio claim.')
 p=OUT/'fragment-controls.json';p.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(status=d['status'],checks=checks,receipt_sha256=sha(p))))
if __name__=='__main__':main()
