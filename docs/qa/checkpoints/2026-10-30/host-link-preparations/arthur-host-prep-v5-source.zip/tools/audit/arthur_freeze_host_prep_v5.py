"""Freeze reviewable source preparation, without claiming host admission or new leases."""
from pathlib import Path
import hashlib,json
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'build/arthur-host-prep-v5'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 original=(ROOT/'build/arthur-host-prep-v3/native-kernels.s').read_text()
 proposed=(OUT/'native-kernels.s').read_text().replace('.export ArNativeAddFall\nArNativeAddFall:\n','')
 assert original==proposed,'Only native change must be zero-byte additive entry alias.'
 layout=json.loads((OUT/'fragment-layout.json').read_text());controls=json.loads((OUT/'fragment-controls.json').read_text())
 assert layout['total_payload_bytes']==6892 and controls['status'].startswith('PASS_')
 d=dict(status='FROZEN_ARTHUR_SOURCE_HOST_PREPARATION_NOT_PLAYABLE_ADMISSION',
  source_engine='Original Ghosts n Goblins NES authenticated native motion, body/attack poses, five source weapons and native pickup semantics; source instruction body unchanged from qualified v3 except zero-byte AddFall export.',
  explicit_adaptations=['User-requested second native jump restart,32px+32px','20Hz original cooperative task sampled from actual NMI events, saturating one pending update',
   'SMB world coordinate/terrain/platform projection instead of original room RAM','Ordinary SMB weapon-hit consumer supplies world enemy/Bowser progression policy',
   'Mushroom repairs native armor; Flower cycles through the genuine five native weapon IDs','Native ledge fixed6px fall restored; arbitrary SMB platform support skips source16px floor quantization'],
  native_alias_only_source_change_verified=True,
  review_request=dict(PRG=layout['requested_gaps'],PRG_bytes=6892,active_phase_alias='5C00..<5CB0,176bytes;146native/leaf+30host',
   persistent_selected_owner_alias='5F90..<5F98,8bytes; two independent4B player contexts',
   temporary_pointer='R0/R1 actual03/04;2bytes, no44byteZP assumption',
   grant_status='ONLY CHR247..<251 was granted; every PRG/RAM/ZP location here is a request/virtual fixture, not a reservation'),
  phase_call_contract=dict(physics='A26 body/leaf/world and C63 common/shots/lifecycle co-resident; real direct relocatable calls',
   render='A26 decoder switches C63→C70 for all1554B source metadata then restoresC63; real C63 publisher helper temporarily mapsA62 and restoresA26',
   NMI='74B RAM-only clock can execute through its A-view mirror while the shared common A63 NMI gate is already mapped; noZP/SMC/mapper writes',
   caller='Public shared importer/router still to attach. Main wrappers preserve borrowed03/04; constructor/pickup ABI allows native scratch clobber and must be matched to the actual consumer.'),
  lifecycle=dict(public_raw32_guards='Every public host hook checks raw32 before owned reads/writes;1785lifecycle+2550world/render foreign cases',
   scene='ReadyA7 published last after init/import; area/world/scene keys rebuild native task and preserve earned gear',
   life='Real modulo life loss resets armor/lance; gains and FF→00 preserve; death source bone pose plus native world KillPlayer',
   alternating='Four actual native TransposePlayers calls verified independent inventories/armor/life resets; current menu remains singleplayer',
   new_game='Actual X5ProfilesNewGame clears all5C..5F. IcGlobalInit also legitimately clears5F80..97. Owned fresh constructor must run AFTER all generic newgame clearing.',
   Parodius='PnEnsure movement/update raw18 only, cheat caller raw18 only; audio source has noPnEnsure/History references. Final installed outerNMI/audio interference audit remains required.'),
  palette=dict(current='Original source-index atlas/84descriptors retained unchanged. Source rows decoded exactly; no world palette changed and no quantization installed.',
   armored_visible_codes=['0F','16','18','20','36'],naked_visible_codes=['16','18','36'],
   straightforward_overlay='47ordinary body cases:104distinctblank-half pairs,5greedy pages,worst13body sprites/scanline. Rejected under3body pages/eight sprites.',
   possible_extension='Coalesce genuine8x8 source parts into8x16 role layers and borrow already matching world palette colors; not implemented or admitted.',
   campaign_limit='Blue12 weapons plus5armored colors require more thanP0 alone. Normal-area P0/world-donor proposal loses skin donor after actual BowserPaletteData overwritesP1. Boss-safe palette-owner closure remains open.'),
  verified_receipts=dict(CHR_publisher='build/arthur-host-prep-v3/publisher-closure.json',full_lifecycle='build/arthur-host-prep-v4/lifecycle-controls.json',
   virtual_fragmented_workers='build/arthur-host-prep-v5/fragment-controls.json',ownership='build/arthur-host-plan-v2/merged-occupancy.json'),
  open_work=['Joint Arthur+Quick public importer/router sizing and executable union arena','Lossless palette/CHR/OAM solution within approved4pages and normal sprite limits',
   'Exact final shared hook/caller contracts including all head/feet/sides and native terrain contact order','Final raw32 IRQ/NMI/late-audio phase ownership and scene reentry',
   'Original source audio integration','Real controller-only64px pipes/gaps and Easy1-1→25controlled1-2; then Hard/earned upgrades'],
  no_shared_mutation=True,no_native_emulator_launched=True,no_cartridge_image_emitted=True)
 sources=['native-kernels.s','native-context.inc','component.s','host-state.s','host-world.s','host-render.s','compact-art.s','fixture-imports.s','abstract.cfg','fragmented.cfg',
  'build-proof.json','fragment-layout.json','fragment-controls.json','fragmented.bin','fragmented.dbg','fragmented.lbl']
 refs=[ROOT/'build/arthur-source-v1/handoff.json',ROOT/'build/arthur-host-plan-v2/handoff.json',ROOT/'build/arthur-host-plan-v2/merged-occupancy.json',
  ROOT/'build/arthur-projected-leaf-v3/cpu-receipt.json',ROOT/'build/arthur-host-prep-v3/publisher-closure.json',ROOT/'build/arthur-host-prep-v4/lifecycle-controls.json',
  ROOT/'build/arthur-host-prep-v4/lossless-palette-cost.json',ROOT/'build/arthur-projected-leaf-v2/arthur-windowed.chr',
  ROOT/'build/arthur-projected-leaf-v2/windowed-art-proof.json',ROOT/'docs/qa/checkpoints/2026-10-30/final-legacy-chr-reservations/root-review-and-reservations.json']
 tools=[Path(__file__)]+[ROOT/'tools/audit'/n for n in ['arthur_fragment_host_v5.py','arthur_fragment_controls_v5.py','arthur_build_host_glue_v4.py','arthur_host_glue_controls_v4.py','arthur_host_lifecycle_controls_v4.py','arthur_lossless_palette_cost_v1.py']]
 d['bindings']={str(p.resolve()):sha(p)for p in [OUT/n for n in sources]+refs+tools}
 p=OUT/'handoff.json';p.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(path=str(p),sha256=sha(p),bound_files=len(d['bindings']),PRG_bytes=6892)))
if __name__=='__main__':main()
