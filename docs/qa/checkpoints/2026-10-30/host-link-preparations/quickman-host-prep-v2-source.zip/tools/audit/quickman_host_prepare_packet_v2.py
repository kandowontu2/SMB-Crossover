"""Freeze the measured actual-host preparation and its explicit open hooks."""
from pathlib import Path
import hashlib,json,re,shutil,sys
sys.path.insert(0,str(Path(__file__).parent))
import quickman_host_prepare_v2 as p
O=p.O;R=p.R

def main():
    bundle=p.load(p.BASE);layout=json.loads((O/'joint-request.json').read_text())
    def endpoint(name):
        if name not in bundle['syms']:return dict(symbol=name,missing_from_bound_parent=True)
        return p.symbol_table(bundle,[name])[name]
    entries=[]
    def add(feature,seams,implemented,behavior,remaining):
        entries.append(dict(feature=feature,parent_endpoints=[endpoint(s)for s in seams],implemented_in_private_source=implemented,behavior=behavior,remaining=remaining))
    add('selector_and_importer',['HuMovement','HuFresh','HuDraw'],True,'Actual SelectedCharacter9 + FmAlts bit5. Concrete movement/spawn/draw source routes fall back to genuine parent endpoints for foreign owners. Source coordinator A70 uses real shared FarCallCommon; all35CX owners execute in C.','Root-owned caller source replacements and menu pending gate unchanged. No integration/admission grant is inferred.')
    add('movement_contact_with_world',['HuMovement','HuHead','HuBody','HuSide','HuBounce','HuVine'],True,'Source A-edge/physics/wall-cling/fast wall jump/kick/contact resolver retained. Concrete movement hook reverses native NES controller bits, masks Start/Select, runs source Tick, exports live player X/page/Y. World bridge consumes actual block buffers through parent GetBlockBufferAddr and MTileAttribute.','Body origin/bounds/platforms/enemy/firebar/liquid/vine/oneway/destructible/spring adaptation and parent native head/body/side/feet bypasses are not installed. SOLIDbit0 is only the current material mapping. Host native scroll timing and transitions need full caller qualification.')
    add('native_fan_and_enemy_hits',['HuWeapons','HuWeaponTail','HuMature'],False,'Native three-shot boomerang spawn/motion/return/retarget state is executable source; all three source shots render alongside the body in window0. Actor/support aliases retain all32slots.','QuickManProjectileContact is still RTS. No enemy target cache publisher, enemy damage/immunity/filtering, score/drop callback or legacy Bass-projectile suppression is implemented. Source contact jump bridge remains exact; enemy-hit effects must use root policies. No enemy-kill admission claim.')
    add('HP_injury_death',['HuInjury','HuInjuryStatus','HuDeathStart','HuDeath','HuFullPower'],False,'Original maxHP99/currentHP06C0 are retained in the535Bstate, initial40. Source death/yield requests are observed as FixtureStatus1/2.','Damage amount, invulnerability, actual host KillPlayer/death arbitration, continues/lives and death cleanup are not wired. Source container/progression and fortress form-swap remain outside the component. FixtureStatus records a request; it is not a completed host death.')
    add('scene_spawn_and_two_player_lifecycle',['HuFresh','HuReset','HuPrepare','HuRise','HuPrivate','HuPowerup','HuPickup'],False,'Concrete fresh-spawn hook initializes source and imports actual parent player/camera coordinates. CPU suite proves full535B contexts can alternate without saving16directwork or6temporary bytes.','No automatic owner/life/world/area stamps, active-context persistence, save/load storage, death/turn/reset routing or host pickup/container rules. Source currentHP/maxHP/identity/progression cannot be silently kept in an8B snapshot; a complete dormant active context is535B. No extra lifecycle RAM is implemented or assumed. A reset-on-turn policy requires an explicit product decision and source code, not a fit inference.')
    add('graphics_and_OAM',['HuGraphics','HuDraw','HuPortrait','HuFullBox','HuAdder','HuBox','HuVisible'],True,'All30authenticated body poses plus4weapon frames remain source pixel/palette-role/priority exact. Concrete C98 writer emits body and three fan actors; original parent X5SetPhysicalChr publishes only root-granted251..255, window0, upper0. Actual source geometry tests exercise both faces and180cases.','Existing Bass graphics publication must be bypassed for Quick, including portrait/visibility/bounds. OAM start/capacity/rotation/flicker, clipping and all host object overflow need integration policy. No live native PPU CHR or RGB publication proof is claimed.')
    add('palette_HUD_and_pickups',['HuColors','HuWorldPalette','HuUi','HuStatus','HuPickup','HuMenuName'],False,'Frozen component palette proof binds actual CX form-acquisition and NMI instructions. Source role colors are unfaded palette0[0F,0F,28,15],palette1[0F,0F,30,38] conditional on exact stage fixture; decodedE0 becomes0F. Geometry sheet RGB is not live Quick RGB installation.','Host sprite palette ownership/coalescing, body/shot role1 and enemies/HUD harmony; actual Quick acquisition/live colors, health HUD and pickup feedback remain uninstalled. Arthur v5 bytes/art unchanged; any palette successor must request new bytes explicitly.')
    add('audio_and_NMI_ISR_ownership',['GmFamilyNmiGate','GmNmiClock','AudioUpdate'],False,'No source audio/NMI code, nativePPU/APU register store or new ISR state is introduced. Only Main source callbacks and existing shared mapper/publisher are used. Original NMI scratch0000..0002 is never borrowed; source08/09 borrows hostR0/R1=0003/0004 and actual tile service locally savesR6/R7.','QuickManSound and QuickManScrollStrip remain RTS; QuickManEffectSpawn reports allocation failure. Parent still sees Bass raw9, so native Bass music/SFX/palette paths continue until root hooks them. Source music/SFX arbitration and NMI reentry/SMC/shadow timing must be qualified in the actual joined candidate. Main mapper CPU controls do not imply NMI interruption proof.')
    inv=dict(status='PUBLIC_HOOK_INVENTORY_PENDING_ADMISSION',parent_ROM_sha256=p.sha(p.BASE),parent_DBG_sha256=p.sha(p.BASE.with_suffix('.dbg')),menu_pending_unchanged=True,all_host_hook_categories_reviewed=True,entries=entries)
    p.put(O/'public-hook-inventory.json',json.dumps(inv,indent=2)+'\n')
    # Bound source aliases expose every overlapping profile; aliases are not
    # ownership grants or evidence that globally executed consumers are safe.
    aliases=[]
    for name,row in bundle['syms'].items():
        value=int(row['val'],0)
        if 0x5c00<=value<0x5e30:aliases.append(dict(name=name,address=value,kind=row.get('type'),scope=row.get('scope'),global_hole=value==0x5cc3))
    p.put(O/'parent-overlay-aliases.json',json.dumps(dict(status='COMPILED_PARENT_SYMBOL_ALIAS_INVENTORY_NOT_GLOBAL_CONSUMER_CLOSURE',parent_DBG_sha256=p.sha(p.BASE.with_suffix('.dbg')),aliases=sorted(aliases,key=lambda a:(a['address'],a['name'])),explicit_excluded_global='X5Cv3PriorHurt5CC3',remaining='Root owns actual globally live consumer/ISR closure. All these aliases are from actual compiled DBG, not evidence that selected-owner memory is free.'),indent=2)+'\n')
    negative=O/'negatives/abstract-zero-pair-ABI';negative.mkdir(parents=True,exist_ok=True)
    for src in (p.I.parent/'negatives/abstract-zero-pair-ABI').iterdir():
        if src.is_file():shutil.copyfile(src,negative/src.name)
    p.put(O/'README.md',f'''# Quick Man actual-host preparation v2

This is an executable source/link preparation bound to immutable union-v5
`{p.sha(p.BASE)}`. No shared source, menu readiness, original ROM,
Downloads ROM, native emulator, PRG/RAM lease or host ROM output changed.

The previous685B permanent-resident assumption is removed. The actual parent
FarCallCommon maps the758B coordinator into A70 only for a call and restores
the caller A bank from its real CPU stack. All35 original source owners run
in C. The coordinator's C bridge preserves full source A/P and saves the old
actual CurrentBankC mapping on the CPU stack. Nested animation and render
calls restore C before source pointer reads. Each19B importer gate pushes P;
the common bridge consumes it. No custom A mapper or fake bank shadows remain.
The actual parent X5 publisher is called through its genuine shared SMC ABI.

`fragmented.cfg`, `candidate.dbg/lbl/map`, `core.s`, `render.s`, `hooks.s`,
`host-imports.inc` and `joint-request.json` are the concrete candidate source.
The RAM test callsites at7F00 are separate harness code, excluded from every
PRG request. The CPU bus overlays compiled fragments read-only against the
actual parent; no candidate NES file was produced. Placement checks require
the merged source ownership map, preserve Arthur's complete requested gap
budgets, reject all overlaps, and separately verify actual v5 preimages.

Quick requests9031B; Arthur v5 remains6892B byte-for-byte; combined15923B.
No permanent resident bytes are requested. Remaining reviewed-gap headroom
is1093B, not a grant for unspecified future callbacks. Quick selected-state
request is557B:535conservative native aliases,16direct work,6temporary.
Native0008/0009 are the only `(zp),Y` source pair; they borrow actualR0/R1
0003/0004 with public save/restore. World callback locally savesR6/R7
0009/000A. NMI0000..0002 and common5CC3 are excluded. Removed fake A/C
shadows5DCC/5DCD remain holes. No new ZP or persistent lifecycle state is
implemented/assumed. A full dormant active source context needs535B.

Controls:1520original source updates/14semantic assertions;535field equality;
10629actual parent fixed tile service calls;7609actual shared farcalls;
maxTick19997cycles;5110real-selector foreign zero-alias calls;400full-context
alternating updates;180all-pose/body+3fan render cases with actual parent
publisher;768live rolling-buffer read-only queries with fixture publisher
disabled;200host-input/coordinate export updates and12genuine legacy target
entries. These are actual6502 CPU controls, not native60Hz or clear claims.

`public-hook-inventory.json` is the readiness boundary. Enemy-hit/HP/death,
lifecycle/persistence, palette/HUD, pickup, SFX/music/NMI, special materials,
native host physics bypasses and OAM policy remain open. Menu stays pending.
Frozen source palette proof distinguishes palette-role/geometry from live RGB.
Arthur palette work remains independent; v5 requested ranges and bytes are
unchanged. The original00/01ABI negative is retained unchanged in negatives.
''')
    bound=[p.BASE,p.BASE.with_suffix('.dbg'),p.BASE.with_suffix('.lbl'),p.BASE.parent/'handoff.json',p.BASE.parent/'frozen-1a71b8b5.zip',p.MAP,p.AR/'handoff.json',p.AR/'fragment-layout.json',p.AR/'fragmented.cfg',p.AR/'fragmented.bin',p.I.parent/'handoff.json',p.q.ROM,
        R/'build/quickman-component-v2/palette/palette-owner.json',R/'build/quickman-component-v2/palette/native-palette-instructions.txt',R/'build/quickman-host-plan-v1/art/window0-proof.json',R/'build/quickman-host-plan-v1/art/quick-man-window0-5pages.chr',R/'docs/qa/checkpoints/2026-10-30/final-legacy-chr-reservations/root-review-and-reservations.json']
    bound += [Path(__file__),Path(__file__).with_name('quickman_host_prepare_v2.py'),Path(__file__).with_name('quickman_host_prepare_controls_v2.py'),Path(__file__).with_name('quickman_host_prepare_extra_v2.py')]
    # Compile negatives from development are retained and bound, not erased.
    bound += [f for f in O.rglob('*')if f.is_file()and f.name!='handoff.json']
    bindings={str(f.resolve()):p.sha(f)for f in sorted(set(bound))}
    handoff=dict(status='ACTUAL_HOST_SOURCE_PREPARATION_CPU_PASS_PENDING_LEASE_AND_ADMISSION',source_parent_sha256=p.sha(p.BASE),frozen_predecessor_sha256=p.sha(p.I.parent/'handoff.json'),joint_request_sha256=p.sha(O/'joint-request.json'),fragmented_cfg_sha256=p.sha(O/'fragmented.cfg'),genuine_DBG_sha256=p.sha(O/'candidate.dbg'),Quick_PRG=9031,Arthur_PRG=6892,combined_PRG=15923,permanent_resident_PRG=0,selected_ExRAM_bytes=557,new_ZP_bytes=0,CHR_only_grant='251..<256 window0 upper0',source_cpu_controls=json.loads((O/'source-controls.json').read_text())['status'],render_controls=json.loads((O/'render-controls.json').read_text())['status'],live_world_controls=json.loads((O/'live-world-controls.json').read_text())['status'],host_hook_controls=json.loads((O/'hook-controls.json').read_text())['status'],public_inventory_sha256=p.sha(O/'public-hook-inventory.json'),readiness='Pending; frozen old00/01negative retained; no source/menu/shared/native/Downloads install, PRG/RAM lease or host60Hz claim.',bindings=bindings)
    p.put(O/'handoff.json',json.dumps(handoff,indent=2)+'\n')
    print('handoff',p.sha(O/'handoff.json'),'bindings',len(bindings),'files',sum(f.is_file()for f in O.rglob('*')),'bytes',sum(f.stat().st_size for f in O.rglob('*')if f.is_file()))

if __name__=='__main__':main()
