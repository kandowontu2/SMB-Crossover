"""Private actual-parent Quick Man source/link preparation; grants nothing.

The coordinator is phase-resident in A, not permanently resident. Every
relocated CX routine executes in C. The original FarCallCommon supplies the
outer A transaction and the real X5 publisher call; C transactions use the
actual host shadow and a nested CPU-stack lifetime.
"""
from pathlib import Path
from collections import defaultdict
import hashlib,json,re,subprocess,sys,zipfile

R=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(Path(__file__).parent))
import quickman_component_v2 as q
from check_tmnt_render_oa import load,address,location
O=R/'build/quickman-host-prep-v2'
I=R/'build/quickman-host-arena-v1/host-world-arena'
AR=R/'build/arthur-host-prep-v5'
BASE=R/'build/character-host-union-v5/candidate.nes'
MAP=R/'build/arthur-host-plan-v2/merged-occupancy.json'

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,newline='\n')
def symbol_table(bundle,names):
    result={}
    for name in names:
        row=bundle['syms'][name];out=dict(address=int(row['val'],0),source_symbol=name)
        if 'seg'in row:
            seg=bundle['segs'][row['seg']]
            out.update(segment=seg['name'].strip('"'))
            if 'ooffs'in seg:
                pos=location(bundle,name);out.update(file_offset=pos,physical_bank=(pos-16)//8192)
        result[name]=out
    return result

def assemble(srcs,cfg,prefix):
    ca=R/'tools/Windows/cc65/bin/ca65.exe';ld=ca.with_name('ld65.exe');logs=[]
    cmds=[[str(ca),'-g','-I',str(O),str(O/(n+'.s')),'-o',str(O/(n+'.o'))]for n in srcs]
    cmds += [[str(ld),'-C',str(cfg),'--dbgfile',str(O/(prefix+'.dbg')),'-Ln',str(O/(prefix+'.lbl')),'-m',str(O/(prefix+'.map'))]+[str(O/(n+'.o'))for n in srcs]]
    for cmd in cmds:
        p=subprocess.run(cmd,capture_output=True,text=True);logs.append(dict(command=cmd,rc=p.returncode,stdout=p.stdout,stderr=p.stderr))
        if p.returncode:put(O/'compile-negative.json',json.dumps(logs,indent=2));raise AssertionError(p.stderr[:15000])
    return logs

def build():
    O.mkdir(parents=True,exist_ok=True)
    assert sha(BASE)=='1a71b8b5a5752aeec7440c4dc2de91a136d6285c98922c99b52f39f4047f2b25'
    assert sha(I.parent/'handoff.json')=='b37c6843e79711cab5b8a0938fb8893d3b80161235c4ecdea1b71e2eb5d0bed2'
    bundle=load(BASE)
    names=['FarCallCommon','NextBank_SMC','SafecallA_SMC','FarcallJmpTarget_SMC','SafereturnA_SMC','CurrentBank','CurrentBankC','SelectedCharacter','FmAlts','RlVariant','R0','R1','R6','R7','NmiR0','NmiR1','NmiR2','GetBlockBufferAddr','BlockBufferAddr','MTileAttribute','X5SetPhysicalChr','CurrentCHRBank','X5ChrMode','X5WideChrActive','ReloadCHRBank','SavedJoypad1Bits','CurrentOAMOffset','Player_X_Position','Player_PageLoc','Player_Y_Position','Player_Y_HighPos','ScreenLeft_X_Pos','ScreenLeft_PageLoc','CurrentPlayer','GameEngineSubroutine','TimerControl','PauseStatus','HuMovement','HuFresh','HuDraw']
    # Alternate assembly spellings are resolved from the real parent DBG.
    aliases={'Player_X_Position':'Player_X_Position','Player_PageLoc':'Player_PageLoc','Player_Y_Position':'Player_Y_Position','Player_Y_HighPos':'Player_Y_HighPos','CurrentPlayer':'_CurrentPlayer','PauseStatus':'GamePauseStatus'}
    found={}
    for n in names:
        k=n if n in bundle['syms']else aliases.get(n,n)
        if k in bundle['syms']:found[n]=k
        else:raise AssertionError(('missing genuine parent symbol',n))
    symbols={n:symbol_table(bundle,[k])[k]for n,k in found.items()}
    put(O/'parent-symbols.json',json.dumps(dict(parent=str(BASE),sha256=sha(BASE),DBG_sha256=sha(BASE.with_suffix('.dbg')),symbols=symbols),indent=2)+'\n')
    # Numeric values are generated imports from the genuine immutable DBG.
    imports=['; Generated exclusively from immutable union-v5 DBG definitions.']
    for n,v in symbols.items():imports.append(f'Host_{n} = ${v["address"]:04X}')
    imports.append(f'Host_X5SetPhysicalChrBank = ${symbols["X5SetPhysicalChr"]["physical_bank"]|128:02X}')
    for n in ['HuMovement','HuFresh','HuDraw']:imports.append(f'Host_{n}Bank = ${symbols[n]["physical_bank"]|128:02X}')
    put(O/'host-imports.inc','\n'.join(imports)+'\n')
    core=(I/'core.s').read_text()
    core=core.replace('.segment "ARENA_LOW"','.segment "QM_COORD"')
    core=core.replace('.macpack longbranch','.macpack longbranch\n.include "host-imports.inc"')
    # No Boolean fixture owner or private fake mapper shadows survive.
    core=re.sub(r'\.segment "ARENA_EXTERNAL"\nArenaHostActive: \.res 1\n','',core)
    core=core.replace('ArenaCurrentA: .res 1','ArenaCurrentA = Host_CurrentBank').replace('ArenaCurrentC: .res 1','ArenaCurrentC = Host_CurrentBankC')
    core=re.sub(r'ArenaIsActive: lda ArenaHostActive\nbeq ArenaForeign\nsec\nrts\nArenaForeign: clc\nrts',
        'ArenaIsActive:\nlda Host_SelectedCharacter\ncmp #9\nbne ArenaForeign\nlda Host_FmAlts\nand #32\nbeq ArenaForeign\nsec\nrts\nArenaForeign: clc\nrts',core)
    # Eliminate the custom always-mapped A bridge. A is stable for this phase.
    core=re.sub(r'ArenaCallA:[\s\S]*?(?=ArenaCallC:)','',core)
    core=core.replace('jmp ArenaCallA','jmp ArenaCallC')
    core=core.replace('.export ArenaCallA,','.export ArenaCallC,')
    # Move capture of the pushed source P into the one C bridge. Each importer
    # gate becomes19B instead of23B, with the same balanced real stack.
    core=core.replace('ArenaCallC:\nsta ArenaGateBank','ArenaCallC:\nsta ArenaGateBank\npla\nsta ArenaGateP')
    core=core.replace('jsr $95dc','jsr Host_GetBlockBufferAddr').replace('lda $ef36,y','lda Host_MTileAttribute,y')
    core=core.replace('lda $09','lda Host_R6').replace('lda $0a','lda Host_R7').replace('sta $09','sta Host_R6').replace('sta $0a','sta Host_R7').replace('lda ($09),y','lda (Host_R6),y')
    # The real world callback is a C fragment; no data publisher is installed.
    # Split public/core helpers into an A coordinator without a fixed ROM page.
    render=(I/'render.s').read_text()
    render=render.replace('ArenaCallA,','ArenaCallC,')
    render=render.replace('.segment "ARENA_LOW"','.segment "QM_COORD"')
    render=render.replace('.macpack longbranch','.macpack longbranch\n.include "host-imports.inc"')
    render=re.sub(r'\.segment "ARENA_HOST_GLOBALS"[\s\S]*?(?=\.segment "ARENA_ART_LOOKUP")','',render)
    render=render.replace('.export QuickManHostRender,ArenaPublish,CurrentCHRBank,X5ChrMode,X5WideChrActive,ReloadCHRBank','.export QuickManHostRender,ArenaPublish')
    # Publisher is the genuine parent routine, reached by genuine SMC farcall.
    render=re.sub(r'\.segment "ARENA_ART_PUBLISH"[\s\S]*?(?=\.segment "QM_COORD")','''.segment "ARENA_ART_PUBLISH"
ArenaPublish:
ldx #0
ldy #0
sta Host_SafecallA_SMC+1
lda #<Host_X5SetPhysicalChr
sta Host_FarcallJmpTarget_SMC+1
lda #>Host_X5SetPhysicalChr
sta Host_FarcallJmpTarget_SMC+2
lda #Host_X5SetPhysicalChrBank
jmp Host_FarCallCommon
'''.replace('\\.','.'),render)
    render=render.replace('jmp ArenaCallA','jmp ArenaCallC')
    # C98 renderer and art remain co-resident. The A coordinator handles nested
    # GetFrame by mapping C82 and restoring C98 before any pointer dereference.
    render=render.replace('lda ArenaCurrentC\npha\nlda #$E2\nsta ArenaCurrentC\nsta $5116\n','')
    render=render.replace('pla\nsta ArenaCurrentC\nsta $5116\nlda QuickManWork_01\nrts','lda QuickManWork_01\nrts')
    # This duplicate parent publisher copy was a fixture, never requested code.
    render=render.replace('.segment "ARENA_PUBLISHER"','')
    # Export a concrete public hook adapter, separate from native movement.
    hooks='''; Concrete Main-only import/export hooks. Menu readiness remains pending.
.setcpu "6502"
.include "host-imports.inc"
.import QuickManInit,QuickManTick,QuickManHostRender,ArenaIsActive,ArenaCallC,ArenaGateA,ArenaGateP,ArenaGatePtr
.import QmField_001F,QmField_0020,QmField_0440,QmField_0460,QmField_0480,QmField_04A0,QmField_04C0,QmField_06C0,QuickManWork_00
.export QuickManHostMovement,QuickManHostSpawn,QuickManHostDraw
.segment "QM_HOOKS"
; Movement source is C; A coordinator owns the native aliases and borrowed pair.
; Host NES bits are A80 B40 Select20 Start10 Up08 Down04 Left02 Right01.
QuickManMovementCore:
lda Host_ScreenLeft_X_Pos
sta QmField_001F
lda Host_ScreenLeft_PageLoc
sta QmField_0020
lda Host_SavedJoypad1Bits
ldx #8
ldy #0
QmReverseBits:
lsr
pha
tya
rol
tay
pla
dex
bne QmReverseBits
tya
and #$F3                  ; Start/Select remain host-owned.
jsr QuickManTick
lda QmField_0460
sta Host_Player_X_Position
lda QmField_0440
sta Host_Player_PageLoc
lda QmField_04A0
sta Host_Player_Y_Position
lda #1
sta Host_Player_Y_HighPos
rts
QuickManSpawnCore:
jsr QuickManInit
lda Host_Player_X_Position
sta QmField_0460
lda Host_Player_PageLoc
sta QmField_0440
lda Host_Player_Y_Position
sta QmField_04A0
lda #0
sta QmField_0480
sta QmField_04C0
lda Host_ScreenLeft_X_Pos
sta QmField_001F
lda Host_ScreenLeft_PageLoc
sta QmField_0020
rts
.segment "QM_COORD"
QuickManHostDraw:
php
pha
jsr ArenaIsActive
bcc QuickManHostDraw_Foreign
pla
plp
lda Host_CurrentOAMOffset
jsr QuickManHostRender
sta Host_CurrentOAMOffset
rts
'''
    # Ownership gate before all owned state. Spawn/Movement C workers run under
    # the same A coordinator. Outer callers use the shared farcall macro.
    for public,target,legacy in [('QuickManHostMovement','QuickManMovementCore','HuMovement'),('QuickManHostSpawn','QuickManSpawnCore','HuFresh')]:
        hooks+=f'''{public}:
php
pha
jsr ArenaIsActive
bcc {public}_Foreign
pla
plp
sta ArenaGateA
php
pla
sta ArenaGateP
lda #<{target}
sta ArenaGatePtr
lda #>{target}
sta ArenaGatePtr+1
lda #QM_HOOKS_BANK
jmp ArenaCallC
{public}_Foreign: pla
plp
'''
        hooks+=f'''sta Host_SafecallA_SMC+1
lda #<Host_{legacy}
sta Host_FarcallJmpTarget_SMC+1
lda #>Host_{legacy}
sta Host_FarcallJmpTarget_SMC+2
lda #Host_{legacy}Bank
jmp Host_FarCallCommon
'''
    hooks+='''QuickManHostDraw_Foreign:
pla
plp
sta Host_SafecallA_SMC+1
lda #<Host_HuDraw
sta Host_FarcallJmpTarget_SMC+1
lda #>Host_HuDraw
sta Host_FarcallJmpTarget_SMC+2
lda #Host_HuDrawBank
jmp Host_FarCallCommon
'''
    # Genuine symbol exports for separate adapter translation units.
    core+='\n.export QmField_0020,QmField_0440,QmField_0480,QmField_04C0,QmField_06C0\n'
    for name in ['core','render','hooks']:
        value=locals()[name]
        value=value.replace('sta ArenaGateA\nphp\npla\nsta ArenaGateP\nlda #<','sta ArenaGateA\nphp\nlda #<')
        if name=='core':core=value
        elif name=='render':render=value
        else:hooks=value
    # Mark ranges through actual assembling, before choosing physical gaps.
    put(O/'core.s',core);put(O/'render.s',render);put(O/'hooks.s',hooks)
    ca=R/'tools/Windows/cc65/bin/ca65.exe';od=ca.with_name('od65.exe')
    # Temporary genuine constant is overwritten by the final selected linker
    # bank before building executable objects; no post-link patch is used.
    put(O/'placement.inc','QM_HOOKS_BANK=$80\n')
    for n in['core','render','hooks']:
        p=O/(n+'.s');s=p.read_text();s=s.replace('.include "host-imports.inc"','.include "host-imports.inc"\n.include "placement.inc"');put(p,s)
        p1=subprocess.run([str(ca),'-g','-I',str(O),str(p),'-o',str(O/(n+'.o'))],capture_output=True,text=True);assert not p1.returncode,p1.stderr
    sizes=defaultdict(int)
    for n in['core','render','hooks']:
        p=subprocess.run([str(od),'--dump-segments',str(O/(n+'.o'))],capture_output=True,text=True);assert not p.returncode,p.stderr
        for k,v in re.findall(r'Name:\s+"([^"]+)"[\s\S]*?Size:\s+(\d+)',p.stdout):sizes[k]+=int(v)
    put(O/'segment-sizes.json',json.dumps(sizes,indent=2)+'\n')
    # Preserve Arthur's entire requested gap budgets, not only live bytes.
    arthur=json.loads((AR/'fragment-layout.json').read_text());occ=json.loads(MAP.read_text())
    gaps=[dict(bank=g['bank'],start=g['offset_start'],end=g['offset_end_exclusive'])for g in occ['remaining_PRG_gaps']]
    for a in arthur['requested_gaps']:
        g=next(g for g in gaps if(g['bank'],g['start'],g['end'])==(a['bank'],a['start'],a['end']));gaps.remove(g)
    places=[]
    def place(name,window='C',bank=None,start=None):
        size=sizes[name]
        candidates=[g for g in gaps if g['end']-g['start']>=size and(bank is None or g['bank']==bank)and(start is None or g['start']<=start and start+size<=g['end'])]
        assert candidates,('no actual joint candidate gap',name,size)
        g=min(candidates,key=lambda g:(g['end']-g['start']-size,g['bank'],g['start']));gaps.remove(g);at=g['start']if start is None else start
        if g['start']<at:gaps.append(dict(bank=g['bank'],start=g['start'],end=at))
        if at+size<g['end']:gaps.append(dict(bank=g['bank'],start=at+size,end=g['end']))
        row=dict(segment=name,bank=g['bank'],offset=at,bytes=size,window=window,CPU_start=(0xa000 if window=='A'else 0xc000)+at);places.append(row);return row
    coord=place('QM_COORD','A',70,0x860)
    place('ARENA_ART_META','C',98,0xc91)
    cursor=0x1e0b
    for n in ['ARENA_ART_LOOKUP','ARENA_ART_PUBLISH','ARENA_RENDER']:p=place(n,'C',98,cursor);cursor+=p['bytes']
    # Keep original direct-JMP clusters in the same physical C mapping.
    place('R1','C',84,0x1529);cursor=0x1e00
    for n in ['R2','R3','R4','R10','R33']:p=place(n,'C',84,cursor);cursor+=p['bytes']
    place('ARENA_HOST_WORLD','C',87,0x1020)
    place('QM_HOOKS','C',87,0x1020+sizes['ARENA_HOST_WORLD'])
    for n in sorted((n for n in sizes if re.fullmatch(r'R\d+',n)and n not in {p['segment']for p in places}),key=lambda n:-sizes[n]):place(n)
    byname={p['segment']:p for p in places}
    # Regenerate only actual importer bank operands. Source immediates remain
    # untouched. Target addresses are all genuine ca65 linked expressions.
    oldlayout=json.loads((I.parent/'joint-arena/joint-layout.json').read_text())
    target_segment={};oldsegs={};oldsyms=[]
    for line in (I/'arena.dbg').read_text().splitlines():
        if not line.startswith(('sym\t','seg\t')):continue
        z=dict(x.split('=',1)for x in line[4:].split(',')if'='in x)
        if line.startswith('seg\t'):oldsegs[z['id']]=z['name'].strip('"')
        elif 'val'in z and 'seg'in z:oldsyms.append(z)
    for z in oldsyms:
        n=z['name'].strip('"')
        if n.startswith(('CX_','ArenaGetFrameBody')):target_segment[n]=oldsegs[z['seg']]
    target_segment.update(ArenaGetFrameBody='R25',QuickManHostWorldCore='ARENA_HOST_WORLD',ArenaRenderCore='ARENA_RENDER')
    pattern=r'(G_[^\n]+|QuickManWorldProbe|GateRender):\nsta ArenaGateA\nphp\nlda #<([^\n]+)\nsta ArenaGatePtr\nlda #>[^\n]+\nsta ArenaGatePtr\+1\nlda #\$([0-9A-F]{2})\njmp ArenaCallC'
    gate_count=0
    def rebase(m):
        nonlocal gate_count
        gate_count+=1;seg=target_segment[m[2]]
        return m[0].replace('lda #$'+m[3]+'\njmp ArenaCallC',f'lda #${byname[seg]["bank"]|128:02X}\njmp ArenaCallC')
    for n in ['core','render']:
        p=O/(n+'.s');put(p,re.sub(pattern,rebase,p.read_text()))
    put(O/'placement.inc',f'QM_HOOKS_BANK=${byname["QM_HOOKS"]["bank"]|128:02X}\n')
    # Reuse the conservative segmented source RAM, dropping only fake A/C
    # shadows. The two released bytes remain holes, not another owner's lease.
    oldcfg=(I/'link.cfg').read_text();regions=[]
    for line in oldcfg.splitlines():
        if re.match(r'N\d+:',line):regions.append(line)
    cfg=['MEMORY { Z:start=$0003,size=$2,type=rw;']+regions
    cfg += ['CH:start=0,size=$1400,file="'+str(O/'chr.bin').replace('\\','/')+'";']
    for i,p in enumerate(places):cfg.append(f'J{i}:start=${p["CPU_start"]:04X},size=${p["bytes"]:X},file="'+str(O/f'fragment-{i:02d}.bin').replace('\\','/')+'",type=ro;')
    cfg+=['}','SEGMENTS { ARENA_ZP:load=Z,type=zp; ARENA_CHR:load=CH,type=ro;']
    cfg += [line for line in oldcfg.splitlines()if line.startswith('QM_')]
    cfg += [f'{p["segment"]}:load=J{i},type=ro;'for i,p in enumerate(places)]+['}']
    put(O/'fragmented.cfg','\n'.join(cfg)+'\n')
    logs=assemble(['core','render','hooks'],O/'fragmented.cfg','candidate')
    # Parent ROM bytes are never modified. The executable CPU bus overlays the
    # linked source fragments read-only at the proposed physical positions.
    arbytes=(AR/'fragmented.bin').read_bytes();images={};masks={};arthur_proof=[]
    def write(bank,off,raw,owner):
        images.setdefault(bank,bytearray([255])*8192);masks.setdefault(bank,bytearray(8192))
        assert not any(masks[bank][off:off+len(raw)]),('joint overlap',owner,bank,off)
        images[bank][off:off+len(raw)]=raw;masks[bank][off:off+len(raw)]=bytes([1])*len(raw)
    for r in arthur['segments']:
        raw=arbytes[r['file_offset']:r['file_offset']+r['bytes']];write(r['bank'],r['physical_start'],raw,'Arthur/'+r['segment']);arthur_proof.append(dict(segment=r['segment'],bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest()))
    parent=BASE.read_bytes();preimages=[]
    for i,p in enumerate(places):
        raw=(O/f'fragment-{i:02d}.bin').read_bytes();assert len(raw)==p['bytes'],(p,len(raw));write(p['bank'],p['offset'],raw,p['segment'])
        pre=parent[16+p['bank']*8192+p['offset']:16+p['bank']*8192+p['offset']+len(raw)]
        p.update(linked_sha256=hashlib.sha256(raw).hexdigest(),parent_preimage_sha256=hashlib.sha256(pre).hexdigest(),parent_preimage_values=sorted(set(pre)))
        # Ownership, not fill, controls placement; this extra check detects a
        # stale map against the newly bound actual parent.
        assert len(set(pre))==1 and pre[0]in (0,255),('actual parent differs from gap',p)
    for bank,data in images.items():
        putpath=O/f'bank-{bank:02d}.bin';putpath.write_bytes(data);(O/f'mask-{bank:02d}.bin').write_bytes(masks[bank])
    report=dict(status='ACTUAL_HOST_LINK_PREPARATION_NOT_GRANTED_NOT_INSTALLED',parent_ROM=str(BASE),parent_ROM_sha256=sha(BASE),parent_handoff_sha256=sha(BASE.parent/'handoff.json'),frozen_predecessor_sha256=sha(I.parent/'handoff.json'),Arthur_handoff_sha256=sha(AR/'handoff.json'),Arthur_full_requested_gap_budgets_unchanged=True,Arthur_payload_unchanged=arthur_proof,Quick_placements=places,Quick_PRG_bytes=sum(p['bytes']for p in places),Arthur_PRG_bytes=sum(r['bytes']for r in arthur['segments']),combined_PRG_bytes=sum(p['bytes']for p in places)+sum(r['bytes']for r in arthur['segments']),permanent_resident_bytes=0,coordinator_A_bank=coord['bank'],coordinator_bytes=coord['bytes'],source_execution_window='C',all_original_source_routines_retained=35,actual_shared_outer_mapper='FarCallCommon genuine union-v5 SMC bytes; not copied/replaced',inner_C_mapper='Actual CurrentBankC + $5116 with old mapping on CPU stack; full source A/P',gates_rebased=gate_count,remaining_gap_bytes=sum(g['end']-g['start']for g in gaps),remaining_intervals=gaps,root_merged_map_sha256=sha(MAP),RAM_request=dict(native_source=535,direct_work=16,temporary=6,total=557,window='segmented5C00..<5E30;5CC3excluded;5DCC/5DCDreleasedshadowholes',ZP_new_bytes=0,borrowed_source_indirect_pair=['R0=0003','R1=0004'],world_local_pair=['R6=0009','R7=000A'],full_player_context_resume_bytes=535,player_persistence='Host two-player snapshot/reset policy is not implemented; no hidden535Bsecondcontext is assumed'),CHR_grant=dict(physical_pages=list(range(251,256)),window=0,upper=0),no_host_ROM_output=True,no_native_run=True,commands=logs,genuine_DBG_sha256=sha(O/'candidate.dbg'))
    put(O/'joint-request.json',json.dumps(report,indent=2)+'\n')
    print('Quick',report['Quick_PRG_bytes'],'Arthur',report['Arthur_PRG_bytes'],'coord',coord['bytes'],'resident0','headroom',report['remaining_gap_bytes'])
    return report

if __name__=='__main__':build()
