"""Execute the private source payload with the immutable real parent mapper.

Only the CPU test world publisher supplies fixture terrain. The linked source
callback itself reads the live SMB rolling block buffers through the genuine
parent service. Test callsites are explicit RAM harnesses, never fit claims.
"""
from pathlib import Path
import builtins,inspect,json,re,sys,subprocess,hashlib
sys.path.insert(0,str(Path(__file__).parent))
import quickman_host_prepare_v2 as p
import quickman_component_bench_v2 as b
from py65.devices.mpu6502 import MPU
O=p.O;R=p.R
ORACLE=R/'build/quickman-host-arena-v1'

def labels():return {n:int(v,16)for v,n in re.findall(r'al ([0-9A-Fa-f]+) \.(\w+)',(O/'candidate.lbl').read_text())}

class HostBus:
    instances=[]
    publish_test_world=True
    def __init__(self,n=65536):
        self.ram=builtins.bytearray(n);self.events=[];self.writes=[];self.A=88;self.C=87;self.fixed_service_calls=0;self.outer_calls=0;self.publisher_calls=0
        self.lab=labels();self.plan=json.loads((O/'joint-request.json').read_text());self.host=json.loads((O/'parent-symbols.json').read_text())['symbols']
        raw=p.BASE.read_bytes();self.banks={i:builtins.bytearray(raw[16+i*8192:16+(i+1)*8192])for i in range(128)}
        for mask in O.glob('mask-*.bin'):
            bank=int(mask.stem.split('-')[1]);m=mask.read_bytes();v=mask.with_name('bank-'+mask.name[5:]).read_bytes()
            for a,bit in enumerate(m):
                if bit:self.banks[bank][a]=v[a]
        self.ram[0x8000:0xa000]=self.banks[126];self.ram[0xe000:0x10000]=self.banks[127]
        bundle=p.load(p.BASE)
        for row in bundle['segs'].values():
            if row['name']=='"SMCCODE"':
                a,n,o=(int(row[k],0)for k in ['start','size','ooffs']);self.ram[a:a+n]=raw[o:o+n]
        self.ram[self.host['CurrentBank']['address']]=self.A|128;self.ram[self.host['CurrentBankC']['address']]=self.C|128
        self.ram[self.host['SelectedCharacter']['address']]=9;self.ram[self.host['FmAlts']['address']]=32
        self.ram[0:3]=bytes([0x5d,0xd5,0xe7]);self.ram[3:5]=bytes([0xa5,0x5a]);self.ram[9:11]=bytes([0x3c,0xc3]);self.ram[0x5cc3]=0xd7
        self.grid=p.q.make_world()[0];at=self.host['MTileAttribute']['address'];attrs=self.ram[at:at+256];self.solid=next(i for i,x in enumerate(attrs)if x&1);self.empty=next(i for i,x in enumerate(attrs)if not(x&1))
        self.ram[0x7f00:0x7f00+(O/'callsites.bin').stat().st_size]=(O/'callsites.bin').read_bytes()
        HostBus.instances.append(self)
    def __getitem__(self,a):
        if isinstance(a,slice):return builtins.bytearray(self[i]for i in range(a.start or 0,a.stop,a.step or 1))
        if self.A==self.plan['coordinator_A_bank']and a==self.lab['QuickManWorldProbe']and self.publish_test_world:
            page=self.ram[4];parity=page&1;tab=self.host['BlockBufferAddr']['address'];base=self.ram[tab+parity]+256*self.ram[tab+2+parity]
            for y in range(13):
                for x in range(16):self.ram[base+y*16+x]=self.solid if self.grid[y+2][(page&3)*16+x]else self.empty
        if a==self.host['GetBlockBufferAddr']['address']:self.fixed_service_calls+=1
        if a==self.host['FarCallCommon']['address']:self.outer_calls+=1
        if self.A==self.host['X5SetPhysicalChr']['physical_bank']and a==self.host['X5SetPhysicalChr']['address']:self.publisher_calls+=1
        if 0xa000<=a<0xe000:return self.banks[self.A if a<0xc000 else self.C][a&8191]
        return self.ram[a]
    def __setitem__(self,a,v):
        if isinstance(a,slice):
            # The predecessor source oracle loads a flat ROM fixture at8000.
            # Our callable source is in the mapped parent arena; ignore only
            # that explicit empty image, never a runtime source store.
            assert not(a.start==0x8000 and len(v)),('unexpected flat fixture',a,len(v))
            self.ram[a]=v;return
        v&=255;assert a<0x8000,('ROM write',hex(a),v);assert a!=0x5cc3,('global5CC3 write',v)
        self.ram[a]=v;self.writes.append([a,v])
        if a==0x5115:self.A=v&127;self.events.append([a,v])
        elif a==0x5116:self.C=v&127;self.events.append([a,v])

def make_callsites(lab):
    public=['QuickManInit','QuickManTick','QuickManAnimate','QuickManGetFrame','QuickManHostRender','QuickManHostMovement','QuickManHostSpawn','QuickManHostDraw']
    # This genuine callsite code is a test RAM harness, not resident ROM.
    src=['.setcpu "6502"','.include "host-imports.inc"','.segment "CALL_TEST"']
    for n in public:
        src += [f'Call_{n}:','sta Host_SafecallA_SMC+1',f'lda #<${lab[n]:04X}','sta Host_FarcallJmpTarget_SMC+1',f'lda #>${lab[n]:04X}','sta Host_FarcallJmpTarget_SMC+2','lda #$C6','jmp Host_FarCallCommon']
    p.put(O/'callsites.s','\n'.join(src)+'\n');p.put(O/'callsites.cfg','MEMORY { T:start=$7F00,size=$100,file="'+str(O/'callsites.bin').replace('\\','/')+'",type=ro; }\nSEGMENTS { CALL_TEST:load=T,type=ro; }\n')
    ca=R/'tools/Windows/cc65/bin/ca65.exe';ld=ca.with_name('ld65.exe')
    for cmd in [[str(ca),'-g','-I',str(O),str(O/'callsites.s'),'-o',str(O/'callsites.o')],[str(ld),'-C',str(O/'callsites.cfg'),'--dbgfile',str(O/'callsites.dbg'),'-Ln',str(O/'callsites.lbl'),str(O/'callsites.o')]]:
        r=subprocess.run(cmd,capture_output=True,text=True);assert not r.returncode,r.stderr
    return {n.removeprefix('Call_'):int(v,16)for v,n in re.findall(r'al ([0-9A-Fa-f]+) \.(\w+)',(O/'callsites.lbl').read_text())}

def main():
    lab=labels();calls=make_callsites(lab);native_invoke=b.invoke
    def invoke(memory,pc,A=0,hook=None,X=0,registers=None):
        if isinstance(memory,HostBus):
            public=next((n for n in calls if lab[n]==pc),None)
            if public:pc=calls[public]
        return native_invoke(memory,pc,A,hook,X,registers)
    info=json.loads((ORACLE/'two-zp-projection/component/source-map.json').read_text());mapping={int(k,16):v for k,v in info['native_to_private_state'].items()};fields={int(k,16):v for k,v in info['native_to_absolute_state'].items()};work=info['work_absolute']
    out=O/'bench';out.mkdir(exist_ok=True);(out/'component-fixture.bin').write_bytes(b'')
    text=inspect.getsource(b.differential).replace("z=labels['QuickManScratch']","z=0")
    for old,new in [('component[z+8]','component[3]'),('component[z+9]','component[4]'),('component[z+0xa]',f'component[{work["0A"]}]'),('component[z+0xb]',f'component[{work["0B"]}]'),('component[z]',f'component[{work["00"]}]')]:text=text.replace(old,new)
    p.put(out/'segmented-oracle.py',text);namespace=dict(b.__dict__);namespace.update(O=O,bytearray=HostBus,invoke=invoke);exec(compile(text,str(out/'segmented-oracle.py'),'exec'),namespace)
    proof=namespace['differential'](info,mapping,lab,(ORACLE/'projection/bench/native-stage-fixture.bin').read_bytes())
    source_buses=list(HostBus.instances)
    for m in source_buses:
        assert(m.A,m.C)==(88,87)
        assert m.ram[m.host['CurrentBank']['address']]==216 and m.ram[m.host['CurrentBankC']['address']]==215
        assert m.ram[0:3]==bytes([0x5d,0xd5,0xe7])and m.ram[3:5]==bytes([0xa5,0x5a])and m.ram[9:11]==bytes([0x3c,0xc3])and m.ram[0x5cc3]==0xd7
    report=dict(status='REAL_PARENT_FARCALL_AND_ALL_C_SOURCE_DIFFERENTIAL_PASS',ticks=sum(x['ticks']for x in proof['cases']),semantic_assertions=len(proof['semantic_assertions']),state_bytes_compared=535,source_cases=proof['cases'],actual_parent_fixed_tile_calls=sum(m.fixed_service_calls for m in source_buses),actual_shared_FarCallCommon_calls=sum(m.outer_calls for m in source_buses),mapper_transactions=sum(len(m.events)for m in source_buses),maximum_tick_cycles=max(x['component_cycles_max']for x in proof['cases']),all_return_A_C_hardware_and_actual_shadows_restored=True,R0_R1_R6_R7_and_NMI_0000_0002_and_5CC3_unchanged=True,terrain_scope='Only CPU fixture publishes DATA. Linked candidate world callback never publishes terrain and consumes live native block buffers.',test_callsites='Actual assembled 7F00 RAM harness calling original parent SMC; no resident lease or host ROM output.',parent_sha256=p.sha(p.BASE),DBG_sha256=p.sha(O/'candidate.dbg'))
    p.put(O/'source-controls.json',json.dumps(report,indent=2)+'\n')
    # Ownership uses all real raw selectors, including Bass/Roll alternatives.
    m=HostBus();m.A=70;m.ram[m.host['CurrentBank']['address']]=198
    owned=sorted(set(fields.values())|set(work.values())|set(range(0x5dc6,0x5dcc)))
    for a in owned:m.ram[a]=(37*a+19)&255
    foreign_cases=0
    for raw in range(256):
        for alts in [0,31,32,255]:
            if raw==9 and alts&32:continue
            m.ram[m.host['SelectedCharacter']['address']]=raw;m.ram[m.host['FmAlts']['address']]=alts
            before=bytes(m.ram[0x5c00:0x5f00])+bytes(m.ram[3:5]);ev=len(m.events)
            for name in ['QuickManInit','QuickManTick','QuickManAnimate','QuickManGetFrame','QuickManHostRender']:
                regs={};native_invoke(m,lab[name],A=0x56,X=3,registers=regs)
                assert bytes(m.ram[0x5c00:0x5f00])+bytes(m.ram[3:5])==before and len(m.events)==ev,(raw,alts,name)
                assert regs['A']==0x56 and regs['X']==3,(raw,alts,name,regs)
                foreign_cases+=1
    p.put(O/'selector-controls.json',json.dumps(dict(status='REAL_RAW_SELECTOR_FOREIGN_ZERO_ALIAS_PASS',foreign_public_calls=foreign_cases,selector='SelectedCharacter==9 && (FmAlts&32)!=0',owned_ExRAM_R0_R1_and_mapper_untouched=True,compiled_owner_guard=True,parent_sha256=p.sha(p.BASE)),indent=2)+'\n')
    # Full native contexts alternate without swapping temporary/direct work.
    contexts=[HostBus(),HostBus()];shared=HostBus();addresses=sorted(fields.values());saved=[]
    for i,mem in enumerate(contexts):
        invoke(mem,lab['QuickManInit']);x=80 if i==0 else 300;mem.ram[fields[0x460]]=x&255;mem.ram[fields[0x440]]=x>>8;saved.append(bytes(mem.ram[a]for a in addresses))
    invoke(shared,lab['QuickManInit']);sequence=[]
    for frame in range(200):
        for player in [0,1]:
            mask=(128 if player==0 else 64)|(1 if any(lo<=frame<hi for lo,hi in[(5,25),(50,70),(95,115),(140,160)])else 0)|(2 if 20<=frame<180 else 0)
            def tick(mem):
                invoke(mem,lab['QuickManTick'],A=mask)
                for slot in [0,2,3,4]:invoke(mem,lab['QuickManGetFrame'],X=slot)
                assert(mem.A,mem.C)==(88,87)and mem.ram[3:5]==bytes([0xa5,0x5a])
                return bytes(mem.ram[a]for a in addresses)
            expected=tick(contexts[player])
            for a,v in zip(addresses,saved[player]):shared.ram[a]=v
            actual=tick(shared);assert actual==expected,(frame,player);saved[player]=actual;sequence.append(hashlib.sha256(actual).hexdigest())
    p.put(O/'context-controls.json',json.dumps(dict(status='FULL535B_TWO_PLAYER_SOURCE_CONTEXT_PASS',updates=400,native_context_bytes=535,direct_work_not_swapped=16,temporary_not_swapped=6,sequence_sha256=hashlib.sha256(''.join(sequence).encode()).hexdigest(),scope='Conservative full context test; host death/turn snapshot routing and storage lease remain unimplemented.'),indent=2)+'\n')
    print(report['status'],report['ticks'],'ticks',report['actual_shared_FarCallCommon_calls'],'actual farcalls','foreign',foreign_cases,'contexts400')
    return invoke,native_invoke,calls

if __name__=='__main__':main()
