"""Real-parent OAM/publisher, live-buffer and actual adapter controls."""
from pathlib import Path
import json,re,sys,hashlib
sys.path.insert(0,str(Path(__file__).parent))
import quickman_host_prepare_v2 as p
import quickman_host_prepare_controls_v2 as c
import quickman_component_bench_v2 as b
from py65.devices.mpu6502 import MPU
O=p.O;R=p.R

def main():
    lab=c.labels();calls=c.make_callsites(lab);info=json.loads((c.ORACLE/'two-zp-projection/component/source-map.json').read_text());f={int(k,16):v for k,v in info['native_to_absolute_state'].items()};w=info['work_absolute'];art=json.loads((R/'build/quickman-host-plan-v1/art/window0-proof.json').read_text());byframe={v['frame']:v for v in art['frames']};poses=json.loads((R/'build/quickman-source-v1/poses/pose-manifest.json').read_text())['frames']
    def invoke(m,name,A=0,X=0,regs=None):return b.invoke(m,calls[name],A=A,X=X,registers=regs)
    m=c.HostBus();invoke(m,'QuickManInit');cases=[]
    for pose in poses:
        for facing in [0x80,0xc0]:
            for x,y in [(32,32),(128,128),(224,208)]:
                for slot in [0,2,3,4]:m.ram[f[0x420+slot]]=0
                for a,v in [(0x400,int(pose['from_type'],16)),(0x6a0,pose['index']),(0x420,facing),(0x460,x),(0x4a0,y),(0x1f,0)]:m.ram[f[a]]=v
                for slot in [2,3,4]:
                    for a,v in [(0x400,14),(0x6a0,slot-2),(0x420,facing),(0x460,x+(slot-3)*12),(0x4a0,y)]:m.ram[f[a+slot]]=v&255
                h=m.host
                for i in range(1,8):m.ram[h['CurrentCHRBank']['address']+i]=0x60+i;m.ram[h['X5ChrMode']['address']+i]=i
                regs={};cycles=invoke(m,'QuickManHostRender',regs=regs);expected=[]
                for frame,px,py in [(pose['frame'],x,y),(0x5c,x-12,y),(0x5d,x,y),(0x5e,x+12,y)]:
                    for cell in byframe[frame]['cells']:
                        dx=cell['x']if facing&64 else -(cell['x']+8);attr=cell['attr']^(0 if facing&64 else 64);expected += [(py+cell['y'])&255,cell['pair']*2,attr,(px+dx)&255]
                assert regs['A']==len(expected)and m.ram[0x200:0x200+len(expected)]==bytes(expected),(pose['frame'],facing,x,y)
                page=251+byframe[pose['frame']]['logical_page'];assert m.ram[h['CurrentCHRBank']['address']]==page and m.ram[h['X5ChrMode']['address']]==128
                assert all(m.ram[h['CurrentCHRBank']['address']+i]==0x60+i and m.ram[h['X5ChrMode']['address']+i]==i for i in range(1,8))
                assert(m.A,m.C)==(88,87)and m.ram[3:5]==bytes([0xa5,0x5a])and m.ram[0:3]==bytes([0x5d,0xd5,0xe7])
                cases.append(dict(frame=pose['frame'],facing=facing,position=[x,y],physical_page=page,cells=len(expected)//4,cycles=cycles))
    p.put(O/'render-controls.json',json.dumps(dict(status='ACTUAL_PARENT_PUBLISHER_ALL_SOURCE_POSES_AND_FAN_PASS',cases=len(cases),body_poses=30,actual_parent_X5_publisher_calls=m.publisher_calls,actual_parent_FarCallCommon_calls=m.outer_calls,max_render_cycles=max(v['cycles']for v in cases),all_OAM_bytes_geometry_palette_role_priority_exact=True,body_and_all_three_shots_window0=True,explicit_CHR_upper0=True,windows1_7_preserved=True,A_C_hardware_and_shadows_R0_R1_NMI_0_2_restored=True,rows=cases,limits='No native PPU/NMI publication, actual live RGB installation, or host OAM capacity/overflow claim.'),indent=2)+'\n')
    # No fixture-publisher reads are permitted in this live-buffer test.
    live=c.HostBus();live.publish_test_world=False;live.A=70;live.ram[live.host['CurrentBank']['address']]=198
    tab=live.host['BlockBufferAddr']['address'];buffers=[live.ram[tab+i]+256*live.ram[tab+2+i]for i in range(2)]
    originals={}
    for parity,base in enumerate(buffers):
        for row in range(13):
            for col in range(16):
                value=live.solid if (row*3+col+parity)%4==0 else live.empty
                live.ram[base+row*16+col]=value;originals[base+row*16+col]=value
    queries=[]
    for page in range(4):
        for x in range(0,256,16):
            for y in [0,16,31,32,47,64,127,208,224,239,240,255]:
                live.ram[3]=x;live.ram[4]=page;live.ram[w['0A']]=y;live.ram[w['0B']]=0
                b.invoke(live,lab['QuickManWorldProbe'])
                expected=int(32<=y<240 and (((y>>4)-2)*3+(x>>4)+(page&1))%4==0)
                assert live.ram[w['00']]==expected,(page,x,y,expected,live.ram[w['00']])
                assert all(live.ram[a]==v for a,v in originals.items()),'world callback wrote live buffer'
                assert live.ram[9:11]==bytes([0x3c,0xc3])and live.C==87
                queries.append([page,x,y,expected])
    p.put(O/'live-world-controls.json',json.dumps(dict(status='LIVE_PARENT_ROLLING_BUFFER_READ_ONLY_MATRIX_PASS',queries=len(queries),fixture_publisher_disabled=True,actual_GetBlockBufferAddr_calls=live.fixed_service_calls,all_live_buffer_bytes_preserved=True,R6_R7_and_C_hardware_shadow_restored=True,query_sha256=hashlib.sha256(json.dumps(queries).encode()).hexdigest(),material_policy='Native MTileAttribute SOLID bit0 -> ordinary source material1, others0; special materials pending.'),indent=2)+'\n')
    # Concrete host hooks versus the corresponding original source public call.
    host=c.HostBus();reference=c.HostBus();h=host.host
    for mem in [host,reference]:
        for name,value in [('Player_X_Position',80),('Player_PageLoc',0),('Player_Y_Position',181),('ScreenLeft_X_Pos',0),('ScreenLeft_PageLoc',0)]:mem.ram[h[name]['address']]=value
    invoke(host,'QuickManHostSpawn');invoke(reference,'QuickManInit')
    assert all(host.ram[a]==reference.ram[a]for a in f.values()),'spawn import'
    masks=[]
    for tick in range(200):
        original_mask=1|(128 if any(lo<=tick<hi for lo,hi in[(5,25),(50,70),(95,115),(140,160)])else 0)|(64 if 20<=tick<180 else 0)|(16|32)
        native_mask=int(f'{original_mask:08b}'[::-1],2)&0xf3
        host.ram[h['SavedJoypad1Bits']['address']]=original_mask
        invoke(host,'QuickManHostMovement');invoke(reference,'QuickManTick',A=native_mask)
        assert all(host.ram[a]==reference.ram[a]for a in f.values()),('native controller/state',tick)
        assert host.ram[h['Player_X_Position']['address']]==host.ram[f[0x460]]and host.ram[h['Player_PageLoc']['address']]==host.ram[f[0x440]]and host.ram[h['Player_Y_Position']['address']]==host.ram[f[0x4a0]]
        for name in ['ScreenLeft_X_Pos','ScreenLeft_PageLoc']:
            source=0x1f if name=='ScreenLeft_X_Pos'else 0x20
            reference.ram[f[source]]=host.ram[h[name]['address']]
        masks.append([original_mask,native_mask])
    # Stop only at the real immutable legacy entry, recording the actual mapper
    # route/return stack. This is routing evidence, not legacy gameplay replay.
    routes=[]
    for public,legacy in [('QuickManHostMovement','HuMovement'),('QuickManHostSpawn','HuFresh'),('QuickManHostDraw','HuDraw')]:
        for raw,alts in [(0,0),(9,0),(9,1),(32,32)]:
            mem=c.HostBus();mem.ram[h['SelectedCharacter']['address']]=raw;mem.ram[h['FmAlts']['address']]=alts
            mem.ram[0x1fe]=0xfe;mem.ram[0x1ff]=0x7f;cpu=MPU(memory=mem,pc=calls[public]);cpu.sp=0xfd;cpu.a=0x51;cpu.x=3;cpu.y=7
            for _ in range(2000):
                if mem.A==h[legacy]['physical_bank']and cpu.pc==h[legacy]['address']:break
                cpu.step()
            else:raise AssertionError(('legacy route not reached',public,raw,alts,hex(cpu.pc),mem.A))
            assert cpu.a==0x51 and cpu.x==3 and cpu.y==7,(public,raw,alts,'AXY entry')
            routes.append(dict(public=public,legacy=legacy,raw=raw,alts=alts,actual_target_bank=mem.A,actual_target_PC=cpu.pc,SP=cpu.sp))
    p.put(O/'hook-controls.json',json.dumps(dict(status='SOURCE_CONTROLLER_SPAWN_MOVEMENT_EXPORT_AND_REAL_LEGACY_ROUTES_PASS',controller_updates=200,all535_native_state_fields_equal=True,Start_Select_masked_host_owned=True,actual_coordinate_exports=True,legacy_target_entry_AXY_pass=routes,remaining='World/area lifecycle, enemy/HP/injury/death/persistence/audio/NMI callbacks remain open in public-hook-inventory.json. Menu pending gate remains unchanged.'),indent=2)+'\n')
    print('render180, live world',len(queries),'host movement200, genuine legacy routes',len(routes),'PASS')

if __name__=='__main__':main()
