"""Original -> actual compiled SMB2 audio/image/DMC/lease differential.

CPU/mapper only. No analog APU, DMC steals, PPU/native scheduler or mixer proof.
"""
from pathlib import Path
import collections,hashlib,json,statistics,sys
import prepare_smb2_roster_native_v1 as S
sys.path.insert(0,str(S.ROOT/'tools/audit'))
from link_pit_rygar_sophia_audit_cpu import scoped_load
from check_tmnt_render_oa import Memory,address,location
from verify_native_relocation import NesMPU

ROOT=S.ROOT;OUT=ROOT/'build/smb2-roster-audio-v1';ROM=OUT/'candidate.nes'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest();bind=S.binding

class Original:
    def __init__(self):self.ram=S.original(2);self.events=[];self.fetches=[];self.writes=[];self.cpu=None;self.details=[]
    def __getitem__(self,p):return self.ram[p]
    def __setitem__(self,p,v):
        v&=255;self.ram[p]=v;self.writes.append((p,v))
        if 0x4000<=p<=0x4017:
            self.events.append((p,v))
            if self.cpu:self.details.append(dict(register=f'{p:04X}',value=v,PC=self.cpu.pc,X=self.cpu.x,Y=self.cpu.y))
        if p==0x4015 and v&16:
            start=0xc000+self.ram[0x4012]*64;n=self.ram[0x4013]*16+1
            self.fetches.append((self.ram[0x4010],n,hashlib.sha256(self.ram[start:start+n]).hexdigest()))

class Port(Memory):
    def __init__(self,b):
        self.cpu=None;self.events=[];self.fetches=[];self.reads=[];self.execs=[]
        super().__init__(b);self.image=address(b,'GuestNativeApu');self.dirty=address(b,'GuestNativeDirty')
    def __getitem__(self,p):
        if isinstance(p,int):self.reads.append(p)
        return super().__getitem__(p)
    def __setitem__(self,p,v):
        if isinstance(p,int):
            if getattr(self,'image',-100)<=p<getattr(self,'image',-100)+16:self.events.append((0x4000+p-self.image,v))
            elif p in[0x4010,0x4012,0x4013,0x4015,0x4017]:self.events.append((p,v))
            if p==0x5117:
                # The register itself is unrelated to4015; inspect true modeled
                # status. Source must stop BEFORE selecting a different E view.
                assert not self[0x4015]&16,'E changed while hardware DMC busy'
        super().__setitem__(p,v)
        if isinstance(p,int)and p==0x4015 and v&16:
            start=0xc000+self[0x4012]*64;n=self[0x4013]*16+1
            blob=bytes(self[start:start+n]);self.fetches.append((self[0x4010],n,hashlib.sha256(blob).hexdigest()))

def call(m,pc,a=0,x=0,y=0,p=0x30,sp=0xfd,inject=None):
    c=NesMPU(memory=m,pc=pc);c.a,c.x,c.y,c.p,c.sp=a,x,y,p,sp
    m.cpu=c
    c.stPushWord(0x5aff);m.writes=[];m.events=[];m.fetches=[]
    if isinstance(m,Original):m.details=[]
    if isinstance(m,Port):m.cpu=c;m.execs=[];m.native_return=None
    low=c.sp;fired=False
    for _ in range(30000):
        if c.pc==0x5b00:
            assert c.sp==sp and(inject is None or fired)
            c.minimum_SP=low
            return c
        bank=m.banks[(c.pc-0x8000)//8192]if isinstance(m,Port)and c.pc>=0x8000 else-1
        if isinstance(m,Port):m.execs.append((c.pc,bank))
        if isinstance(m,Port)and c.pc==getattr(m,'native_return_pc',None):m.native_return=(c.a,c.x,c.y,c.p&0xcf,c.sp)
        if inject and not fired and(c.pc,bank)==inject:
            snap=(c.pc,c.a,c.x,c.y,c.p&0xcf,c.sp,m.banks.copy())
            smc=bytes(m[0x15a:0x17b]);zp=bytes(m[0xbb:0xc7]);c.irq();assert c.pc!=snap[0]
            for _ in range(2000):
                c.step()
                if c.pc==snap[0]and c.sp==snap[5]:break
            else:raise AssertionError('actual IRQ return')
            assert(c.pc,c.a,c.x,c.y,c.p&0xcf,c.sp,m.banks)==snap,'actual IRQ CPU/banks'
            assert bytes(m[0x15a:0x17b])==smc and bytes(m[0xbb:0xc7])==zp,'actual IRQ borrowed ZP/SMC'
            fired=True
        assert m[c.pc]!=0,('BRK',hex(c.pc));c.step();low=min(low,c.sp)
    raise AssertionError(('bounded call return',hex(pc),hex(c.pc)))

class Campaign:
    def __init__(self,b):
        self.b=b;self.l=S.labels();self.old=Original();self.new=Port(b);self.cost=[];self.trace_hash=hashlib.sha256();self.sites=set()
        self.state=address(b,'S2AudioState');self.zps=address(b,'S2AudioZpState')
        self.new.page(1,74);self.new.page(2,117)
        self.new[address(b,'CurrentBank')]=202;self.new[address(b,'CurrentBankC')]=245
        self.new[address(b,'SelectedCharacter')]=25;self.new[0x5204]=128
        start=location(b,'S2AudioTick');size=int(b['syms']['S2AudioTick']['size'],0)
        needle=bytes([0x20,address(b,'S2AudioNativeEntry')&255,address(b,'S2AudioNativeEntry')>>8])
        blob=b['raw'][start:start+size];assert blob.count(needle)==1,'actual unique native JSR return'
        self.new.native_return_pc=address(b,'S2AudioTick')+blob.index(needle)+3
        call(self.new,address(b,'S2AudioInit'))
        for p in list(range(0xbb,0xc7))+list(range(0x5ec,0x620)):self.old.ram[p]=0
        self.old.ram[0x100]=0;self.old.ram[0x4011]=0x49;self.new[0x4011]=0x49
    def queue(self,index,value):
        self.old.ram[0x600+index]=value
        call(self.new,address(self.b,'S2AudioSetQueue'),a=value,x=index)
    def pause(self,value):
        self.old.ram[0x100]=value;call(self.new,address(self.b,'S2AudioSetPause'),a=value)
    def tick(self,flags=0x30,sp=0xfd):
        # Different authentic foreground input bytes must be restored; audio
        # sees only its persistent native BB..C6 projection.
        for i in range(12):self.new[0xbb+i]=(i*73+len(self.cost)*17+29)&255
        foreground=bytes(self.new[0xbb:0xc7]);smc=bytes(self.new[0x15a:0x17b])
        old=call(self.old,self.l['StartProcessingSoundQueue'],a=0x55,x=3,y=7,p=flags,sp=sp)
        new=call(self.new,address(self.b,'S2AudioTick'),a=0x55,x=3,y=7,p=flags,sp=sp)
        assert(new.a,new.x,new.y,new.p&0xcf)==(0x55,3,7,flags&0xcf),'public endpoint AXYP'
        assert self.new.native_return==(old.a,old.x,old.y,old.p&0xcf,old.sp-6),('original native return AXYP/SP',self.new.native_return,(old.a,old.x,old.y,old.p&0xcf,old.sp-6))
        assert bytes(self.new[0xbb:0xc7])==foreground and bytes(self.new[0x15a:0x17b])==smc
        assert self.new.banks[1:3]==[74,117]and self.new[address(self.b,'CurrentBankC')]==245
        assert self.old.ram[0x4011]==self.new[0x4011]==0x49,'authentic held DAC'
        a,b=self.old.events,self.new.events
        assert len(a)==len(b),('APU event count',a,b)
        for i,((p,v),(q,w))in enumerate(zip(a,b)):
            assert p==q and(p==0x4012 or v==w),('ordered source image/hardware',i,a,b)
        assert self.old.fetches==self.new.fetches,('actual complete hardware fetch bytes',self.old.fetches,self.new.fetches)
        assert self.old.ram[0x5ec:0x620]==bytes(self.new[self.state:self.state+52]),'all52 native state bytes'
        want=bytearray(self.old.ram[0xbb:0xc7]);ptr=want[0]+256*want[1]
        if 0x9000<=ptr<=0xa3ee:
            ptr+=0x3a00;want[0]=ptr&255;want[1]=ptr>>8
        assert want==bytes(self.new[self.zps:self.zps+12]),('all12 nativeZP/pointer',want.hex(),bytes(self.new[self.zps:self.zps+12]).hex())
        allowed=set(range(self.state,self.state+69))|set(range(self.zps,self.zps+12))|set(range(address(self.b,'RgAudioCpuZp'),address(self.b,'RgAudioCpuZp')+12))
        allowed|=set(range(self.new.image,self.new.image+16))|set(range(self.new.dirty,self.new.dirty+16))|set(range(0xbb,0xc7))
        allowed|={address(self.b,'CurrentBankC'),0x5116,0x5117,0x4010,0x4012,0x4013,0x4015,0x4017}
        for p,v in self.new.writes:
            assert p in allowed or 0x17b<=p<=0x100+sp,('undeclared write/stack',hex(p),v)
        self.cost.append((old.processorCycles,new.processorCycles,new.minimum_SP));self.sites.update(self.new.execs)
        self.trace_hash.update(json.dumps(a,separators=(',',':')).encode())
        return old,new
    def result(self,name):
        return dict(name=name,calls=len(self.cost),original_min=min(c[0]for c in self.cost),
            original_max=max(c[0]for c in self.cost),port_min=min(c[1]for c in self.cost),port_max=max(c[1]for c in self.cost),
            added_min=min(c[1]-c[0]for c in self.cost),added_max=max(c[1]-c[0]for c in self.cost),
            minimum_SP=min(c[2]for c in self.cost),ordered_original_sha256=self.trace_hash.hexdigest())

def main():
    build=json.loads((OUT/'build-proof.json').read_text());assert sha(ROM)==build['candidate']['sha256']
    b=scoped_load(ROM);rows=[];all_sites=set();calls=0
    for family,bits,count in[('song',range(8),512),('event',range(8),256),('effect1',range(8),128),
            ('effect2',range(6),128),('effect3',range(3),160),('DPCM',range(8),176)]:
        for bit in bits:
            c=Campaign(b);index=dict(song=0,event=3,effect1=2,effect2=4,effect3=5,DPCM=1)[family]
            c.queue(index,1<<bit)
            for tick in range(count):c.tick(flags=[0x30,0x39,0x70,0xff][tick%4],sp=0xc0 if tick%7==0 else 0xfd)
            rows.append(c.result(f'{family}-{bit}'));all_sites.update(c.sites);calls+=len(c.cost)
    # All source queue byte values and their exact native priority, one actual
    # fresh original/port callback each. No invented enum range truncation.
    for index in range(6):
        for value in range(256):
            c=Campaign(b);c.queue(index,value);c.tick();calls+=1;all_sites.update(c.sites)
        rows.append(dict(name=f'all-byte-queue{index}',calls=256))
    c=Campaign(b);c.queue(0,1)
    for _ in range(20):c.tick()
    c.pause(0x41);c.queue(3,8);c.queue(1,1)
    for _ in range(180):c.tick()
    c.pause(0)
    for _ in range(20):c.tick()
    rows.append(c.result('actual-pause-death-resume'));calls+=len(c.cost)
    proof=dict(passed=True,source_CPU_only=True,native_run=False,actual_ROM=bind(ROM),original=bind(S.ROM),
        build=bind(OUT/'build-proof.json'),calls=calls,campaigns=rows,actual_port_sites=sorted(all_sites),tool=bind(__file__),
        controls='Original ordered4000..0F -> GuestNativeApu image;4010/12/13/15/17 actual hardware order.4012 normalized ONLY by exact full samplefetch bytes/rate/length.52sourceRAM+12sourceZP/pointer exact,foreground12ZP+5SMC+AXYP/SP+C restored.',
        limits='No analog/length-counter APU model,DMC steals/fetch timing,PPU/native scheduling,world mixer or Main cue publication qualification.')
    (OUT/'differential-controls.json').write_text(json.dumps(proof,indent=2)+'\n')
    print(json.dumps(dict(passed=True,calls=calls,campaigns=len(rows),proof=bind(OUT/'differential-controls.json')),indent=2))

if __name__=='__main__':main()
