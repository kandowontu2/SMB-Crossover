"""Explicit new output args after guarded default-argument preflight rejection."""
from pathlib import Path
import hashlib,json
import prepare_current_character_upper_v2 as C
B=C.B;R=C.R;P=C.P;OLD=C.OLD;O=C.O;N=C.N
def main():
 for name,value in json.loads((OLD/'source-stage-handoff-v1.json').read_text())['bindings'].items():assert B.sha(name)==value,name
 (O/'retained-output-guard-negative.json').write_text(json.dumps(dict(native=False,compiler_launched=False,reason='Imported ca(folder=N) retained old Python default object; destination assertion rejected before compiler. Frozen677 predecessor bindings all reverified; successor explicitly supplies N for every compile.'),indent=2)+'\n')
 B.O=O;B.N=N;B.ca('ff-render',N)
 cmd=[x.replace(str(P),str(N)).replace(P.as_posix(),N.as_posix())for x in json.loads((OLD/'final-link.json').read_text())['command']]
 B.run(cmd,'first-link')
 ram=(N/'ram3.bin').read_bytes();assert hashlib.sha256(ram).hexdigest()=='c036ccf3ec72cd4d79abb2f0a5765e47db7c6754ff2b9c5dde25d82fd4ef1970'
 cookie=bytes([167,22,0,6])+hashlib.sha256(ram).digest()[:12];(N/'ff-cookie.bin').write_bytes(cookie);(N/'ff-stream.bin').write_bytes(ram)
 B.ca('loader',N);B.ca('stream',N);B.run(cmd,'final-link')
 from prepare_cv3_dmc_mirror import prepare
 prepare(R,N/'candidate.nes')
 assert(N/'code.bin').read_bytes()==(P/'code.bin').read_bytes()and(N/'data.bin').read_bytes()==(P/'data.bin').read_bytes()
 files=[p for p in O.rglob('*')if p.is_file()]+[Path(__file__),Path(C.__file__),OLD/'source-stage-handoff-v1.json',R/'build/ff-upper-fx-windows-qualified-1030-v1/handoff.json']
 h=dict(status='FROZEN_SOURCE_UPPER_WINDOWS_COMPONENT_STAGE_CPU_PENDING',candidate=B.sha(N/'candidate.nes'),parent=B.sha(P/'candidate.nes'),FF_RAM3=B.sha(N/'ram3.bin'),cookie=list(cookie),native=False,installed=False,no_new_lease=True,bindings={str(p.resolve()):B.sha(p)for p in files})
 (O/'source-stage-handoff-v2.json').write_text(json.dumps(h,indent=2)+'\n');print(json.dumps(dict(candidate=h['candidate'],handoff=B.sha(O/'source-stage-handoff-v2.json'),bindings=len(h['bindings']),FF_RAM3=h['FF_RAM3'])))
if __name__=='__main__':main()
