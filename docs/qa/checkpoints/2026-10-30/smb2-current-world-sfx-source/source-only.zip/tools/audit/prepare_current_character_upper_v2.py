"""Source successor: adopt only frozen FF upper-window decoder/cookie6."""
from pathlib import Path
import hashlib,json,shutil
import build_current_character_composition_v1 as B
R=B.R;P=B.N;OLD=B.O;U=R/'build/ff-upper-fx-windows-1030-v1/joint';O=R/'build/current-character-composition-v2';N=O/'joint'
def main():
 assert not O.exists()
 for path in[OLD/'source-stage-handoff-v1.json',R/'build/ff-upper-fx-windows-qualified-1030-v1/handoff.json']:
  for name,value in json.loads(path.read_text())['bindings'].items():assert B.sha(name)==value,name
 O.mkdir();shutil.copytree(P,N)
 for p in N.rglob('*'):
  if p.is_file()and p.suffix in['.s','.inc','.cfg']:
   s=p.read_text();z=s.replace(str(P),str(N)).replace(P.as_posix(),N.as_posix())
   if s!=z:p.write_text(z,newline='\n')
 s=(U/'ff-render.s').read_text().replace(str(U),str(N)).replace(U.as_posix(),N.as_posix());(N/'ff-render.s').write_text(s,newline='\n')
 B.O=O;B.N=N;B.ca('ff-render')
 cmd=[x.replace(str(P),str(N)).replace(P.as_posix(),N.as_posix())for x in json.loads((OLD/'final-link.json').read_text())['command']]
 B.run(cmd,'first-link')
 ram=(N/'ram3.bin').read_bytes();assert hashlib.sha256(ram).hexdigest()=='c036ccf3ec72cd4d79abb2f0a5765e47db7c6754ff2b9c5dde25d82fd4ef1970'
 cookie=bytes([167,22,0,6])+hashlib.sha256(ram).digest()[:12]
 (N/'ff-cookie.bin').write_bytes(cookie);(N/'ff-stream.bin').write_bytes(ram)
 B.ca('loader');B.ca('stream');B.run(cmd,'final-link')
 from prepare_cv3_dmc_mirror import prepare
 prepare(R,N/'candidate.nes')
 assert(N/'code.bin').read_bytes()==(P/'code.bin').read_bytes()and(N/'data.bin').read_bytes()==(P/'data.bin').read_bytes()
 h=dict(status='FROZEN_SOURCE_UPPER_WINDOWS_COMPONENT_STAGE_CPU_PENDING',candidate=B.sha(N/'candidate.nes'),parent=B.sha(P/'candidate.nes'),FF_RAM3=B.sha(N/'ram3.bin'),cookie=list(cookie),native=False,installed=False,no_new_lease=True,bindings={str(p.resolve()):B.sha(p)for p in list(N.rglob('*'))+[Path(__file__),OLD/'source-stage-handoff-v1.json',R/'build/ff-upper-fx-windows-qualified-1030-v1/handoff.json']if p.is_file()})
 (O/'source-stage-handoff-v2.json').write_text(json.dumps(h,indent=2)+'\n');print(json.dumps(dict(candidate=h['candidate'],handoff=B.sha(O/'source-stage-handoff-v2.json'),bindings=len(h['bindings']),FF_RAM3=h['FF_RAM3'])))
if __name__=='__main__':main()
