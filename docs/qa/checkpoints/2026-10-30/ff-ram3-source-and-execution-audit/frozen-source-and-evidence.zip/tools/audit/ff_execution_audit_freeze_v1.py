"""Freeze only the new read-only FF resource/CPU audit and its limitations."""
from pathlib import Path
import difflib,hashlib,json,re,zipfile

R=Path(__file__).resolve().parents[2]
O=R/'build/final-fantasy-execution-audit-v1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()


def write(p,value):p.write_text(json.dumps(value,indent=2)+'\n',newline='\n')


def main():
    assert not (O/'handoff.json').exists()
    cpu=json.loads((O/'cpu-controls-v2.json').read_text());assert cpu['passed']
    resource=json.loads((O/'resource-closure.json').read_text())
    kernel=R/'build/final-fantasy-ram3-kernel-v1/build-proof.json'
    original=json.loads(kernel.read_text())
    checked={}
    for proof in [cpu,resource,original]:
        for name,expected in proof['bindings'].items():
            p=Path(name);assert sha(p)==expected,('postflight immutable input changed',p)
            checked[str(p.resolve())]=expected
    # Carry forward the complete requested-character future ledger. The old
    # PN832..<1024 owner is explicitly superseded only by the dense receipt.
    old=R/'build/arthur-host-plan-v2/merged-occupancy.json'
    owners=json.loads(old.read_text())['full_CHR_owner_reservations']
    dense=R/'docs/qa/checkpoints/2026-10-30/parodius-dense-chr/root-review-and-reservations.json'
    overlay=R/'docs/qa/checkpoints/2026-10-30/mmc5-overlay-private-allocation/root-review-and-reservations.json'
    legacy=R/'docs/qa/checkpoints/2026-10-30/final-legacy-chr-reservations/root-review-and-reservations.json'
    assert sha(dense)=='c8b7476a6272d383008ec4f47703403be0d0f632fe22db45963c1634acabace7'
    assert sha(overlay)=='71e6d9bb97b6dea45da10c614589b3d0a22c5b0f87a294384edf8037c7076b96'
    assert sha(legacy)=='57151594919f18d0e0d3d64791d6a21aa8d5fb43ae5667dd9dd7d49c5417b13c'
    future=dict(status='READ_ONLY_MERGED_RESERVATION_INTERPRETATION_NO_GRANT',
        retained_prior_requested_character_CHR=[x for x in owners if x['owner']!='fullParodius'],
        superseded_only_if_exact_dense_producer_and_tables_composed=[x for x in owners if x['owner']=='fullParodius'],
        amendments=[dict(owner='denseParodius',first=832,end_exclusive=868),
                    dict(owner='Arthur lossless art/cache',first=868,end_exclusive=884),
                    dict(owner='Quick code/data carrier',first=884,end_exclusive=893),
                    dict(owner='Arthur old atlas retained',first=247,end_exclusive=251),
                    dict(owner='Quick body/weapon atlas',first=251,end_exclusive=256)],
        proposed_FF_carrier=dict(first=893,end_exclusive=901,granted=False),
        PRG_RAM=dict(bank0='Global game state unchanged; live writes remain enabled',
                     bank1='Quick code selected owner',bank2='Quick data/Arthur cache temporal ownership',
                     bank3='Explicitly unallocated in receipt. This CPU fixture preloads bank3 without adopting it.'),
        bindings={str(p.resolve()):sha(p)for p in[old,dense,overlay,legacy]})
    write(O/'future-reservation-closure.json',future)
    # Include actual compiled direct hardware-write sites, including source
    # stream loaders that do not call the generic X5 setter.
    direct={};source_bindings={}
    for row in resource['rows']:
        dbg=Path(row['path']).with_suffix('.dbg');files={};active={}
        for line in dbg.read_text().splitlines():
            typ,_,tail=line.partition('\t')
            if typ not in ['file','line']:continue
            d=dict(x.split('=',1)for x in tail.split(',')if'='in x)
            if typ=='file':files[d['id']]=Path(d['name'].strip('"'))
            elif 'span'in d:active.setdefault(d['file'],set()).add(int(d['line']))
        rows=[]
        for key,linenos in active.items():
            p=files[key]
            if not p.is_file()or p.suffix.lower()not in['.s','.inc']:continue
            text=p.read_text().splitlines()
            for n in sorted(linenos):
                if n>len(text):continue
                s=text[n-1]
                if re.search(r'\b(?:sta|stx|sty)\s+\$(?:512[0-9a-b]|5130)\b',s,re.I):
                    rows.append(dict(path=str(p),line=n,context=text[max(0,n-5):n+3]))
                    source_bindings[str(p.resolve())]=sha(p)
        direct[row['name']]=rows
    write(O/'compiled-direct-CHR-writers.json',dict(rows=direct,bindings=source_bindings,
        scope='Actual DBG source line records with emitted spans; includes generic hardware publisher and forcedblank source stream readers. Symbolic BankCHR macro sites are also in the compiled source/reference closure.'))
    before=R/'tools/audit/ff_ram3_execution_controls_v1.py';after=R/'tools/audit/ff_ram3_execution_controls_v2.py'
    diff=''.join(difflib.unified_diff(before.read_text().splitlines(True),after.read_text().splitlines(True),fromfile=str(before),tofile=str(after)))
    (O/'fixture-v2.diff').write_text(diff,newline='\n')
    negative=json.loads((O/'cpu-controls-negative-v1.json').read_text())
    assert not negative['passed'] and negative['checks']['same_PC_source_pairs']['source_movement_updates']==2304
    correction=dict(status='RETAINED_NORMAL_NMI_FIXTURE_OWNERSHIP_NEGATIVE',
        error=negative['error'],cause='V1 classified live ZP from NmiDisable AFTER normal NMI set itFF. V2 captures the entry ownership bit before interrupt; normal NMI owns NmiR0/NmiR1 and audio scratch.',
        unchanged='Exact ROM/kernel/assertions for AXYP, rawmaps, all33SMC, live caller page1, actual R0/R1 and R6/R7, payload banks; no product or assertion weakening.',
        bindings={str(p.resolve()):sha(p)for p in[before,after,O/'fixture-v2.diff',O/'cpu-controls-negative-v1.json']})
    write(O/'fixture-correction-proof.json',correction)
    # Immutable input recheck after both CPU and inventory passes.
    for p,digest in future['bindings'].items():checked[p]=digest
    for p,digest in source_bindings.items():checked[p]=digest
    for p,digest in checked.items():assert sha(p)==digest,p
    write(O/'postflight-bindings.json',dict(passed=True,input_files_checked=len(checked),
        exact_unchanged_inputs=checked,cartridge_RAM3_CHR_commonhook_mutation=False,
        scope='Read-only input hash verification; explicit isolated CPU RAM3 preload is declared in CPU receipt.'))
    state=json.loads((O/'source-state-ISR-controls.json').read_text())
    assert state['passed'] and state['real_vector_cases']==804
    files=[Path(__file__),before,after,R/'tools/audit/ff_execution_resource_audit_v1.py',
           R/'tools/audit/ff_ram3_state_isr_controls_v1.py']
    files += [p for p in O.iterdir() if p.is_file()]
    bindings={str(p.resolve()):sha(p)for p in files}
    handoff=dict(status='FROZEN_OFFLINE_CONDITIONAL_FF_RESOURCE_AND_RAW3_SOURCE_CPU_AUDIT_NO_GRANT',
        native=False,shared_install=False,allocation=False,source_kernel_sha256=original['image_sha256'],
        current_FF_ROM_sha256=original['current_host_ROM_sha256'],
        code=dict(CORE=3211,publisher=20,image=8192,unused=4961,unused_after_future16B_cookie=4945,
                  virtual_CORE='AA00..<B68B',virtual_publisher='A275..<A289'),
        proposed_carrier='893..<901 eight1KB pages, conditional on exact densePN source; NOT allocated',
        retained_ROM='OwnedA62:AA00..<B6903216B for real source loader/router/ROM-only preview; ART93:D000..<DD523410B and graphics756..<788 unchanged',
        CPU=dict(source_pairs=192,source_movement_updates=2304,render_pairs=160,
                 publication_pairs=128,real_NMI_IRQ_cases=804,FF_source_bytes_preserved_per_ISR=143),
        smallest_architecture=[
            'Keep genuine CORE atAA00..<B68B in rawRAM3, plus exact native20B publisher atsameA275. This preserves every existing CORE instruction/operand and source call order.',
            'Eight physical carrier pages form one full8KB RAM3 image.4961B remain before future cookie/adapters,4945B after a proposed16B cookie. No adapter fit/readiness claim until genuinely linked.',
            'Keep genuine ART3410B in existingC93:D000..<DD52 and original32graphics pages756..<788. Render maps this source ROM bank; it needs no additional C2 ownership.',
            'Source ROM62 selected router/loader must run while rawRAM3 is being built. Enter readyRAM3 through genuineFarCallCommon using raw03 rather than ROM83. Use actual imports and borrowed-pair ABI.',
            'Stack/restore caller rawC around selected source workers while retaining AXYP/result and intentional R0/R1 outputs. No new resident/SMC gateway is required or allocated.',
            'Construct only in actual forcedblank with NmiDisable negative, verify buffered2007 full8KB copy, preserve PPU latch/scroll/12CHR/upper/protection/borrowed pairs/maps; invalidate validity first and publish last.',
            'Retain a genuine ROM-only preview until verified code is ready. No preview or NMI caller may enter unbuiltRAM3; selectedraw22/life/scene/newgame/alternate-player state gates remain actual host integration work.'
        ],
        source_closure=dict(resource='resource-closure.json',compiled_references='compiled-publisher-references.json',
            direct_hardware_writers='compiled-direct-CHR-writers.json',future_ownership='future-reservation-closure.json',
            CPU='cpu-controls-v2.json',postflight='postflight-bindings.json'),
        limits=['No loader, native Main, admission, header adoption, lease or commonhook change.',
            'V13 actual originalPN publishes896..900 inside the proposal; retain this negative and genuine dense-source dependency.',
            'FarCallCommon restores rawA, notC. Source RenderChunk leavesrawDD ROM93 and intentional R0/R1 outputs; actual host adapter must restoreC without erasing outputs.',
            'No global5102/5103 locking: RAM0 remains writable. Bank3 loader/cookie, raw22/lifecycle/two-player readiness and semantic host integration remain to implement/qualify.'],
        bindings=bindings)
    write(O/'handoff.json',handoff)
    files.append(O/'handoff.json')
    archive=O/'source-and-evidence.zip'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
        for p in files:z.write(p,p.resolve().relative_to(R).as_posix())
    print(json.dumps(dict(handoff_sha256=sha(O/'handoff.json'),archive_sha256=sha(archive),
        archive_bytes=archive.stat().st_size,members=len(files),inputs_checked=len(checked),
        direct_compiled_writer_sites=sum(len(v)for v in direct.values()))))


if __name__=='__main__':main()
