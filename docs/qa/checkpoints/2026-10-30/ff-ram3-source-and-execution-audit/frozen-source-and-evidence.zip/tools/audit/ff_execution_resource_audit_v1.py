"""Read-only FF carrier/ABI inventory. No lease, allocation, or ROM mutation."""
from pathlib import Path
import hashlib, json, re, sys

R=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
from prepare_ff_current_component_v2 import qualified
from check_tmnt_render_oa import address,location
from link_pit_rygar_sophia_audit_cpu import Arena
from arthur_publisher_closure_v3 import physical

O=R/'build/final-fantasy-execution-audit-v1'
ROOTS={
 'current753':('build/required-rcr-ink-v2/candidate/candidate.nes','753b6bd1e51bb6c427206f841e63790bfd79fe2a3cca964e04254408f87ead53'),
 'quickdf2b':('build/quickman-wram-render-cpu-v7/candidate.nes','df2b18c499a42660c12e81d86732afb92714952d281e0924859a3ffa14b48e1d'),
 'arthur2846':('build/arthur-host-render-fast-v1/candidate.nes','2846e48de17f087e3af5c9b17777c2cd0cdbe2d66f3f79a3a6878ed61b6ee724'),
 'rogueca26':('build/rogue-audio-page-relocation-v5/relocated/candidate.nes','ca26b6dd231908dfc98e49f4fb16b8e24d0c44c7a4d40d0228ece44f30a90ded'),
 'v13':('build/character-host-union-v13/candidate.nes','3f24a0e1bc73d8655811b333aa52285ace1af5e469fcc7b6158b06afce54f72c'),
 'resource3925':('build/character-host-union-resources-v1/ice/candidate.nes','3925aa18859df68958ff782e5acc6558f877f1c0e81f22bd1e1ae54db9746ddb'),
 'FFaadbbb89':('build/final-fantasy-current-component-v2/linked/candidate.nes','aadbbb89ea680cdfa1e1837f56cd75b1e828c8778d85afc7e6688d4a9dbc0d28')}
NAMES=['X5SetPhysicalChr','X5SetSpecialChr','CurrentCHRBank','X5ChrMode',
 'X5SpecialChrUpper','X5HudChrUpper','PnPoolBodyLo','PnPoolBodyHi',
 'PnPoolSpecialLo','PnPoolSpecialHi','PnPoolPickupLo','PnPoolPickupHi']
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
dig=lambda p:hashlib.sha256(bytes(p)).hexdigest()


def compiled_refs(path):
    files={};lines={};symbols=[]
    for line in path.read_text().splitlines():
        typ,_,text=line.partition('\t')
        if typ not in ['file','line','sym']:continue
        d=dict(x.split('=',1) for x in text.split(',') if '=' in x)
        if typ=='file':files[d['id']]=d['name'].strip('"')
        elif typ=='line':lines[d['id']]=d
        elif d.get('name','').strip('"')in NAMES:symbols.append(d)
    rows=[];seen=set();sources={}
    for d in symbols:
        name=d['name'].strip('"')
        for ref in d.get('ref','').split('+'):
            q=lines.get(ref)
            if not q:continue
            p=Path(files[q['file']]);n=int(q['line']);key=(name,str(p),n)
            if key in seen:continue
            seen.add(key)
            if not p.exists():
                rows.append(dict(symbol=name,path=str(p),line=n,source_missing=True));continue
            text=p.read_text().splitlines();sources[str(p.resolve())]=sha(p)
            rows.append(dict(symbol=name,path=str(p),line=n,
                context=text[max(0,n-8):min(len(text),n+3)]))
    return rows,sources


def ledger():
    # Full semantic scan, not a numeric search through hash/path arrays.
    pat=re.compile(r'(?<![0-9a-f])(?:893|901)(?![0-9a-f])|ram.?3|\bbank.?3\b|unallocated',re.I)
    def walk(x,key=''):
        if any(z in key.lower()for z in ['members','bindings','preimages','runtime_references']):return
        if isinstance(x,dict):
            for k,v in x.items():yield from walk(v,key+'.'+k)
        elif isinstance(x,list):
            for i,v in enumerate(x):yield from walk(v,key+f'[{i}]')
        elif pat.search(str(x)):yield dict(key=key,value=x)
    rows=[];bindings={}
    for p in sorted((R/'docs/qa/checkpoints').rglob('*reservations*.json')):
        bindings[str(p.resolve())]=sha(p)
        hits=list(walk(json.loads(p.read_text())))
        if hits:rows.append(dict(path=str(p),hits=hits))
    return rows,bindings


def main():
    assert not (O/'resource-closure.json').exists();O.mkdir(exist_ok=True)
    bindings={str(Path(__file__).resolve()):sha(__file__)};rows=[];all_refs={}
    for name,(file,expected) in ROOTS.items():
        path=R/file;assert sha(path)==expected
        b=qualified(path);raw=b['raw'];carrier=raw[16+1048576+893*1024:16+1048576+901*1024]
        overlaps=[]
        for g in b['segs'].values():
            if 'ooffs'not in g or int(g['size'],0)==0:continue
            start=int(g['ooffs'],0);end=start+int(g['size'],0)
            if max(start,16+1048576+893*1024)<min(end,16+1048576+901*1024):
                overlaps.append(dict(name=g['name'].strip('"'),file_start=start,bytes=end-start))
        tables={};pn_pages=set()
        for family in ['Body','Special','Pickup']:
            lo=location(b,'PnPool'+family+'Lo');hi=location(b,'PnPool'+family+'Hi')
            values=[raw[lo+i]+256*raw[hi+i]for i in range(18)]
            tables[family]=values;pn_pages.update(values)
            if family=='Body':pn_pages.update(v+1 for v in values)
        deaths=[]
        # Actual compiled PnDeathGraphics::BodyLo is a private scoped table.
        candidates=[n for n in b['syms']if n.endswith('::BodyLo')and 'PnDeath'in n]
        assert len(candidates)==1,candidates
        at=location(b,candidates[0]);deaths=[768+x for x in raw[at:at+3]]
        pn_pages.update(deaths)
        at=location(b,'ChrPhysicalMap');legacy=raw[at:at+256]
        pub_at=location(b,'X5SetPhysicalChr');pub=raw[pub_at:pub_at+20]
        assert address(b,'X5SetPhysicalChr')==0xa275
        assert pub.hex()=='9947018a2903098099e073a9018dee738d460160'
        # Genuine compiled central publisher: exhaust all256 logical requests,
        # both mode gates and current special/HUD table domains.
        q=Arena(b,0);q.put(SsChrActive=0,InvHudActive=0,X5SpecialChrUpper=0,X5HudChrUpper=0)
        calls=0;reachable=set()
        for wide in [0,1]:
            for logical in range(256):
                q.array('CurrentCHRBank',[logical]*12);q.array('X5ChrMode',[0]*12)
                q.put(X5WideChrActive=wide,SsChrActive=0,InvHudActive=0)
                _,trace=q.invoke('X5PublishChr');pages,upper=physical(trace)
                assert list(pages.values())==[legacy[logical]]*12 and upper==0
                assert not set(pages.values())&set(range(893,901))
                reachable.update(pages.values());calls+=1
        physical_tables={}
        for table,count in [('SsPhysicalBanks',17),('SmWeaponPhysicalBanks',2),
                            ('AvPhysicalBanks',17),('InvHudPhysicalBanks',8)]:
            at=location(b,table);values=list(raw[at:at+count]);physical_tables[table]=values
            domain=set(values)|({v|1 for v in values}if table!='InvHudPhysicalBanks'else set())
            for page in domain:
                q.array('CurrentCHRBank',[20]*12);q.array('X5ChrMode',[0]*12)
                q.put(X5WideChrActive=1,SsChrActive=1,SsChrPhysical=page,
                      InvHudActive=1,InvHudPhysical=page,X5SpecialChrUpper=0,X5HudChrUpper=0)
                _,trace=q.invoke('X5PublishChr');pages,upper=physical(trace)
                assert pages[4]==page and pages[8]==page and upper==0
                reachable.update(pages.values());calls+=1
        refs,sources=compiled_refs(path.with_suffix('.dbg'));bindings.update(sources);all_refs[name]=refs
        rows.append(dict(name=name,path=str(path),ROM_sha256=expected,
            proposed_carrier_first=893,proposed_carrier_end_exclusive=901,
            preimage_sha256=dig(carrier),preimage_nonzero_bytes=sum(x!=0 for x in carrier),
            actual_linked_segment_overlaps=overlaps,compiled_PN_tables=tables,
            compiled_PN_death_pages=deaths,PN_physical_pages=sorted(pn_pages),
            PN_requested_range_collision=sorted(pn_pages&set(range(893,901))),
            compiled_legacy_table_sha256=dig(legacy),legacy_max=max(legacy),
            physical_special_HUD_tables=physical_tables,actual_publisher_calls=calls,
            legacy_special_HUD_reachable_pages=sorted(reachable),
            X5SetPhysicalChr=dict(PC=0xa275,bytes=20,cycles=32,hex=pub.hex()),
            R0=address(b,'R0'),R1=address(b,'R1'),CurrentBank=address(b,'CurrentBank'),
            CurrentBankC=address(b,'CurrentBankC'),compiled_reference_sites=len(refs)))
        for p in [path,path.with_suffix('.dbg'),path.with_suffix('.lbl')]:bindings[str(p.resolve())]=sha(p)
    semantic_reservations,reservation_bindings=ledger();bindings.update(reservation_bindings)
    refs_path=O/'compiled-publisher-references.json'
    refs_path.write_text(json.dumps(all_refs,indent=2)+'\n',newline='\n')
    bindings[str(refs_path.resolve())]=sha(refs_path)
    result=dict(status='READ_ONLY_SOURCE_AND_COMPILED_CONDITIONAL_RESOURCE_AUDIT_NO_GRANT',
       rows=rows,semantic_matching_reservations=semantic_reservations,
       requested_carrier=dict(first=893,end_exclusive=901,bytes=8192,
           condition='Only after genuine densePN table/death/36K producer composition; original V13 is a live negative.',
           existing_neighbours='Arthur868..<884; Quick code/data884..<893. Existing FF art756..<788 unchanged.',
           permission=False),
       PRG_RAM3='Explicitly unallocated in existing32KB private header receipt; not staged/leased by this audit.',
       bounds='Compiled reference inventory and genuine central publisher controls complement the full prior requested-character reservation map. Generic physical setters intentionally accept arbitrary0..1023: their existence alone is not an owner claim.',
       limitations=['No physical carrier write, PRG/RAM reservation, header, commonhook, loader or native test.',
          'All prior192-page PN producers must be replaced, not merely the renderer tables.',
          'CPU publication tests do not prove a full FF Main/OAM/palette/combat/world integration.'],
       bindings=bindings)
    target=O/'resource-closure.json';target.write_text(json.dumps(result,indent=2)+'\n',newline='\n')
    print(json.dumps(dict(status=result['status'],roots=len(rows),publisher_calls=sum(r['actual_publisher_calls']for r in rows),
        compiled_references=sum(len(x)for x in all_refs.values()),closure_sha256=sha(target))))


if __name__=='__main__':main()
