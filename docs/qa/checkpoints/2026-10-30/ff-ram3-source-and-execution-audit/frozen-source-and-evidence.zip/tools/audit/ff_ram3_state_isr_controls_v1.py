"""Add FF phase-state noninterference to the unchanged real-vector fixture."""
from pathlib import Path
import hashlib,json,sys
R=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import ff_ram3_execution_controls_v2 as C

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

if __name__=='__main__':
    out=C.O/'source-state-ISR-controls.json';assert not out.exists()
    b=C.qualified(C.P/'candidate.nes')
    # Full declared source phase region, persistent clock/gear/life records and
    # selected class; excludes no field used by the genuine FF component.
    fields=list(range(0x5c00,0x5c80))+list(range(0x5fc1,0x5fcf))+[0x5fef]
    real=C.interrupt;observed=[]
    def checked(m,c,kind):
        before=bytes(m[a]for a in fields)
        protected=bytes(m[0x6000:0x8000]);writes=len(m.writes)
        result=real(m,c,kind)
        assert bytes(m[a]for a in fields)==before,('ISR changed actual FF source field',kind,hex(c.pc))
        # Global RAM may legitimately hold the host audio program. Record its
        # genuine native write footprint, without declaring it disposable.
        global_writes=[(a,v)for a,v in m.writes[writes:]if 0x6000<=a<0x8000]
        observed.append(dict(kind=kind,PC=c.pc,source_bytes=len(fields),
                             global_RAM0_write_addresses=sorted({a for a,v in global_writes})))
        return result
    C.interrupt=checked
    result=C.interrupt_controls(b)
    assert len(observed)==result['real_interrupt_cases']==804
    proof=dict(passed=True,native=False,explicit_fixture_preload=True,
        real_vector_cases=804,FF_phase_persistent_variant_bytes_unchanged_per_ISR=len(fields),
        global_RAM0_not_reallocated_or_copied=True,
        native_global_RAM0_write_addresses=sorted({a for z in observed for a in z['global_RAM0_write_addresses']}),
        global_RAM0_rule='Actual native audio writes remain legal; selected code does not map or write RAM0. All source fields are compared separately. Global5102/5103 stays writable.',
        observations=observed,
        bindings={str(p.resolve()):sha(p)for p in[Path(__file__),Path(C.__file__),C.O/'cpu-controls-v2.json',C.P/'candidate.nes',C.P/'candidate.dbg',C.K/'ram3.bin']})
    out.write_text(json.dumps(proof,indent=2)+'\n',newline='\n')
    print(json.dumps(dict(passed=True,cases=804,source_bytes=len(fields),sha256=sha(out))))
