"""Reserve real24B shatter+score queue and preserve published native uploads."""
from pathlib import Path
import json,sys
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import link_dk_groundpound_v1 as L
P=R/'build/dk-groundpound-v4';O=R/'build/dk-groundpound-v5';J=O/'joint'
def main():
 assert not O.exists();J.mkdir(parents=True)
 for f in(P/'joint').rglob('*'):
  if f.is_file()and f.suffix in['.s','.inc','.cfg','.bin']:
   q=J/f.relative_to(P/'joint');q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(f.read_bytes())
 p=J/'src/donkey_kong_host.s';s=p.read_text()
 a=' lda VRAM_Buffer1_Offset\n cmp #64\n bcs Query';z=' lda VRAM_Buffer_AddrCtrl\n bne Query\n lda VRAM_Buffer1_Offset\n cmp #60\n bcs Query'
 assert s.count(a)==1;s=s.replace(a,z);L.write(p,s)
 p=J/'dk-imports.inc';L.write(p,p.read_text()+'\n.import VRAM_Buffer_AddrCtrl\n')
 L.O=O;L.J=J
 cmd=json.loads((P/'compile.json').read_text())['command'];cmd=[v.replace(str(P),str(O))for v in cmd];L.run(cmd,'compile')
 cfg=(P/'joint/private.cfg').read_text().replace(str(P/'joint'),str(J)).replace((P/'joint').as_posix(),J.as_posix());L.write(J/'private.cfg',cfg)
 cmd=json.loads((P/'final-link.json').read_text())['command']
 for i,v in enumerate(cmd):
  if v in[str(P/'joint'/n)for n in['private.cfg','dk-component.o','candidate.nes','candidate.lbl','candidate.map']]:cmd[i]=str(J/Path(v).name)
  elif v.startswith('--dbgfile,'):cmd[i]='--dbgfile,'+str(J/'candidate.dbg')
 L.run(cmd,'final-link')
 L.write(O/'retained-v4-native-queue-negative.json',json.dumps(dict(candidate=L.sha(P/'joint/candidate.nes'),
  receipt=str(P/'controls-v1.json'),receipt_sha256=L.sha(P/'controls-v1.json'),
  native_shatter_appends_24B_not_10=True,old_limit64_can_cross_buffer2_offset=True,
  correction='Require offset<60 (final<=83); reject any already published native VRAM address-controller packet.'),indent=2))
 print(L.sha(J/'candidate.nes'))
if __name__=='__main__':main()
