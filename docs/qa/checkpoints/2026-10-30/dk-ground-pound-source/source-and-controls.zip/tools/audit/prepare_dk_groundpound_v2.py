"""Fit the complete DK prototype by moving only DK-owned routine boundaries."""
from pathlib import Path
import hashlib,json,re,subprocess,sys
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
from private_build_outputs_v1 import validate
P=R/'build/functional-roster-ready54-v1';V=R/'build/dk-groundpound-v1/joint'
O=R/'build/dk-groundpound-v3';J=O/'joint'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf-8',newline='\n')
def main():
 assert not O.exists();J.mkdir(parents=True)
 for f in V.rglob('*'):
  if f.is_file()and f.suffix in['.s','.inc']:q=J/f.relative_to(V);q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(f.read_bytes())
 write(O/'retained-sizing-v1-negative.json',json.dumps(dict(source_only_no_cart=True,
  predecessor_sha=sha(V/'dk-component.o'),CORE=1553,HOST=1027,ART=1178,commit=75,
  failure='Over capacity; HOST used near JSR to an A36 helper while A65 was mapped. Never linked or executed.'),indent=2))
 p=J/'src/donkey_kong_core.s';s=p.read_text();assert len(re.findall(r'^ DkGate$',s,re.M))==9
 s=re.sub(r'^ DkGate$',' jsr DkCoreGate',s,flags=re.M)
 # A local-only helper preserves the old complete gate ABI. Foreign entry
 # removes ONLY its own JSR frame while restoring original X/A/P in order.
 s+='''
.pushseg
.segment "DONKEY_KONG_CORE"
.proc DkCoreGate
 php
 pha
 phx
 lda SelectedCharacter
 cmp #CHARACTER_DONKEY_KONG
 beq Own
 tsx
 lda $0103,x
 sta $0105,x
 lda $0102,x
 sta $0104,x
 lda $0101,x
 sta $0103,x
 inx
 inx
 txs
Own:
 plx
 pla
 plp
 rts
.endproc
.popseg
''';write(p,s)
 p=J/'src/donkey_kong_host.s';s=p.read_text()
 start=s.index('.proc DkHostBox\n');end=s.index('; The existing shell/block defeat routine',start)
 box=s[start:end];s=s[:start]+s[end:]
 profile=re.search(r'\.proc DkHostBoxProfile\n.*?\.endproc\n',box,re.S).group();box=box.replace(profile,'')
 adder=re.search(r'\.proc DkHostAdder\n.*?\.endproc\n',s,re.S).group();s=s.replace(adder,'')
 s=s.replace('.segment "DONKEY_KONG_CORE"\n.export DkPoundRead,DkPoundCommit','.segment "DONKEY_KONG_HOST"\n.export DkPoundRead,DkPoundCommit')
 s=s.replace(' farcall DkTerrainRead\n',' jsr DkTerrainRead\n').replace('Query:farcall DkTerrainRead,jmp','Query:jmp DkTerrainRead')
 s+='\n.pushseg\n.segment "DONKEY_KONG_CORE"\n'+box+'\n.popseg\n'
 write(p,s)
 p=J/'pound-commit.s';s=p.read_text()+'\n.pushseg\n.segment "DK_POUND_COMMIT"\n'+adder+profile+'\n.popseg\n';write(p,s)
 cmd=[str(R/'tools/Windows/cc65/bin/ca65.exe'),'--cpu','6502x','-g','-I',str(J/'src'),'-I',str(J),'-I',str(R),
      '--create-full-dep',str(J/'dk-component.dep'),'-l',str(J/'dk-component.lst'),'-o',str(J/'dk-component.o'),str(J/'dk-component.s')]
 guard=validate(cmd,O,cwd=R);p=subprocess.run(cmd,cwd=R,capture_output=True,text=True)
 write(O/'compile.json',json.dumps(dict(command=cmd,guard=guard,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr),indent=2));assert p.returncode==0,p.stderr
 print(O)
if __name__=='__main__':main()
