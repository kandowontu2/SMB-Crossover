"""Correct a handoff summary count from actual rows; preserve original receipt."""
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parents[2];O=R/'build/dk-groundpound-v7'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 src=O/'handoff-source-v1.json';out=O/'handoff-source-v2.json';assert not out.exists()
 d=json.loads(src.read_text());f=json.loads((O/'controls-v4.json').read_text())
 actual=f['checks']['ordinary_bricks_only_signed_foot_cells_native_effects']['cases'];assert actual==168
 correction=O/'coverage-count-correction-v2.json';c=dict(passed=True,source_or_control_changed=False,
  original_handoff_sha256=sha(src),field='actual_source_controls.foot_tuples',old_summary=336,actual_executed_rows=actual,
  cause='Manual summary doubled14metatiles×6positions×2feet; original executed control rows and assertions are168 and remain unchanged.',
  README_source_MD_erratum='The same336 prose count in README-source.md is168; no native/admission claim changes.',
  authoritative_control=str(O/'controls-v4.json'),authoritative_control_sha256=sha(O/'controls-v4.json'))
 correction.write_text(json.dumps(c,indent=2)+'\n',encoding='utf-8',newline='\n')
 d['actual_source_controls']['foot_tuples']=actual;d['coverage_summary_correction']=str(correction)
 d['bindings'][str(src.resolve())]=sha(src);d['bindings'][str(correction.resolve())]=sha(correction);d['bindings'][str(Path(__file__).resolve())]=sha(__file__)
 out.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8',newline='\n')
 print(json.dumps(dict(path=str(out),sha256=sha(out),candidate=d['candidate'],bindings=len(d['bindings']))))
if __name__=='__main__':main()
