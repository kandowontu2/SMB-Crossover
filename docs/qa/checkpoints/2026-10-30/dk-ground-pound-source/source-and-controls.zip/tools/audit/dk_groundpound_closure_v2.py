"""Retain first ISR negative and expose precise differing contract fields."""
from pathlib import Path
P=Path(__file__).with_name('dk_groundpound_closure_v1.py');s=P.read_text()
s=s.replace('source-isr-closure-v1.json','source-isr-closure-v2.json')
s=s.replace("assert snap()==before,('genuine ISR preservation',context,kind,here)","""after=snap()
     changes=[]
     for ix,(a,z)in enumerate(zip(before,after)):
      if a!=z:
       if isinstance(a,bytes):changes.append([ix,[[i,u,v]for i,(u,v)in enumerate(zip(a,z))if u!=v][:30]])
       else:changes.append([ix,a,z])
     assert not changes,('genuine ISR preservation',context,kind,here,changes)""")
exec(compile(s,str(P),'exec'),dict(__name__='__main__',__file__=str(Path(__file__).resolve())))
