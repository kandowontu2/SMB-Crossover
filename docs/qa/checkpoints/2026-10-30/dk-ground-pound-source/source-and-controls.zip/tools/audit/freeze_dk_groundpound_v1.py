"""Freeze private authored DK air-pound source, without a native route claim."""
from pathlib import Path
import difflib,json,sys
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import prepare_ff_joint_source_v1 as B
O=R/'build/dk-groundpound-v7';J=O/'joint';P=R/'build/functional-roster-ready54-v1'
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
def main():
 out=O/'handoff-source-v1.json';assert not out.exists()
 files=B.validate(P/'handoff.json','8c5ecf42e67f53a046a64de8e93a893956d713e427d84149b6f472d409621876')
 assert B.sha(J/'candidate.nes')=='8aac268de14cb809fa372d44eecd9e4143e29da4151fb8119d64140a212416bb'
 for name in ['source-isr-closure-v3.json','main-ppu-controls-v2.json','controls-v4.json']:
  p=O/name;v=json.loads(p.read_text());assert v['passed'];files.add(p)
  for f,h in v.get('bindings',{}).items():assert B.sha(f)==h,f;files.add(Path(f))
 for ver in range(1,8):
  stage=R/f'build/dk-groundpound-v{ver}'
  for f in stage.rglob('*'):
   if f.is_file()and f.suffix in['.json','.s','.inc','.dep','.cfg','.o','.lst']:files.add(f)
 for n in ['prepare_dk_groundpound_v1.py','prepare_dk_groundpound_v2.py','prepare_dk_groundpound_v4.py','prepare_dk_groundpound_v5.py','prepare_dk_groundpound_v6.py','prepare_dk_groundpound_v7.py','link_dk_groundpound_v1.py','dk_groundpound_controls_v1.py','dk_groundpound_controls_v2.py','dk_groundpound_controls_v3.py','dk_groundpound_controls_v4.py','dk_groundpound_main_ppu_v1.py','dk_groundpound_main_ppu_v2.py','dk_groundpound_closure_v1.py','dk_groundpound_closure_v2.py','dk_groundpound_closure_v3.py']:
  files.add(R/'tools/audit'/n)
 files.add(Path(__file__));files|={f for f in J.iterdir()if f.is_file()}
 link=json.loads((O/'final-link.json').read_text())['command']
 for name in link:
  if name.endswith('.o'):assert Path(name).is_file();files.add(Path(name))
 inv=dict(candidate=B.sha(J/'candidate.nes'),source_parent=B.sha(P/'joint/candidate.nes'),
  own_sources=[str(J/n)for n in['dk-component.s','dk-imports.inc','dk-p0-art.inc','pound-commit.s','src/donkey_kong_core.s','src/donkey_kong_host.s','src/donkey_kong_render.s','src/donkey_kong_state.inc']],
  genuine_main_export_only_source=str(J/'entrypoint.s'),mandatory_current_local_shadow=str(J/'screen_render.s'),
  main_change='Only zero-byte actual native exports for BrickShatter/DestroyBlockMetatile/GuestClaimBlockSlot and real block state fields. Retain current source local InitScreen chain exactly.',
  actual_recipes=[str(O/n)for n in['compile-main.json','compile.json','final-link.json']],
  recipes_are_evidence_not_replay_safe=True,output_guard='tools/audit/private_build_outputs_v1.py::validate before every compiler/link invocation and every CFG MEMORY output.',
  cfg_addition='OWN physical12 DFAD..<E00083B is run through A-window BFAD..<C000 bank12 alias, DK_POUND_COMMIT82B; retain all current other segments. No new physical allocation or RAM.',
  recompile_consumers='Recompile/relink genuine current main, union, and any component importing moved DK targets.38 compiled bytes outside owned spans are genuine table/farcall relocation operands, never blind binary patches.',
  required_finalizer='tools/audit/prepare_cv3_dmc_mirror.py prepare AFTER final link; physical125 mirror equals current parent.',
  allocation=dict(CORE=[1460,1475],HOST=[1024,1024],ART_original=[1178,1261],ART_tail=[82,83]),
  intended_controls='Fresh airborne Down+B any tier starts Attack3. Ground tier2 Down+B retains original vertical barrel; ground other tier attacks unchanged. Fall speed4 until true solid landing.',
  safety='Only actual ordinary metatiles51/52; water22/cloud88/items55..5E/questionsC0/C1/ground54/pipes unbreakable. Real GuestClaimBlockSlot/DestroyBlockMetatile/BrickShatter score/debris/SFX. One break/Main, native published queues reject, offset<60 guarantees24B append<=83.',
  no_Ram_growth=True,world_geometry='42px body signed foot sample offsets-13,+3,+19,+29 across pages; no native PlayerHeadCollision or substituted player origins.',
  native_status='NO native run. OriginalC2 room is CPU/parser-staged; center112 negative, rightedge160 source route reaches genuine native sidepipe/ChangeArea. No controller-only cold pipe route prepared.')
 save(O/'source-merge-inventory.json',inv);files.add(O/'source-merge-inventory.json')
 negatives=[dict(path=str(R/'build/dk-groundpound-v1'),cause='Over-capacity and cross-A near JSR prototype; never linked/executed.'),
  dict(path=str(R/'build/dk-groundpound-v3/final-link.json'),cause='Config segment mistakenly appended to SYMBOLS; linker rejected before output.'),
  dict(path=str(R/'build/dk-groundpound-v4/controls-v1.json'),cause='Native shatter plus score appends24B, not10; offset64 could cross buffer2. Corrected threshold60 and published queue rejection.'),
  dict(path=str(R/'build/dk-groundpound-v5/controls-v2.json'),cause='Fixture passed no CPU into NMI helper; retained harness error.'),
  dict(path=str(R/'build/dk-groundpound-v5/controls-v3.json'),cause='Direct-foot NMI was lag due inheritedFF; old normal label is incorrect. v7 explicitly sets0 and checks actual2007/4014.'),
  dict(path=str(R/'build/dk-groundpound-v6'),cause='Earlier raw links omitted mandatory final125 mirror; v6 restored mirror but export-only main relocation dropped local screen_render shadow, reverting QwSceneInit operand. No native use; v7 restores exactly3bytes.'),
  dict(path=str(O/'source-isr-closure-v2.json'),cause='Observer incorrectly required old hardware C during genuine shadow-ahead pending5116 interval; actual NMI publishes intended mapping early. v3 binds native opcodes/noCreads and actual foreground convergence; all other live fields strict.')]
 (O/'README-source.md').write_text('''Private DK authored ground pound source; native route still pending.

Air Down+B at any tier engages the new downward attack, while grounded tier2
Down+B keeps the vertical barrel. No RAM grows. All real ordinary51/52 bricks
can shatter through genuine block-slot admission, native VRAM effects, score,
debris and sound. Questions/items/ground/pipes/water/cloud remain intact.
The complete42px feet sample signed pages, one break per Main; published VRAM
uploads and insufficient24B queue capacity reject without damaging packets.

Source controls pass6336 foreign gate/fullflag pairs, all tier/state inputs,
336 ordinary/nonbrick foot tuples,16 alignment footprints,20actual normal
NMI PPU/debris/coin consumers,64 queue/item canaries,18fullMain pound/land
scenes,32foreign wholeMain,1964real IRQ/lagNMI instruction cuts. The original
C2 parser room proves rightedge160 floor break then genuine side-pipe exit;
center112 remains a negative because intact adjacent bricks block escape.
Both are explicit staged CPU scenes, not controller-only native routes.

Only owned CORE/HOST/ARTtail bytes and38genuine DK relocation operands differ
from ready54. Header/CHR/original art records/final125/current scene chain are
exact. Existing pending C shadow publication is documented and qualified;
no observer or product writes normalize mapping. Prior regression/fill/queue/
fixture negatives remain immutable. MinimumSP in the ISR receipt is foreground
observation; live caller stack restoration is tested separately at every cut.

No native/admission/install/download claim. Merge own producers into the
current coherent source; do not copy this older full main/config or obsolete
54frontend over later62 fixes. All build output paths must be guarded anew.
''',encoding='utf-8',newline='\n');files.add(O/'README-source.md')
 # Bind the actual negative carts used for byte/source comparison, but do
 # not manufacture a broad native result from any source CPU control.
 files.add(R/'build/dk-groundpound-v6/joint/candidate.nes')
 files.add(R/'build/dk-groundpound-v5/joint/candidate.nes')
 d=dict(passed=True,status='PRIVATE_DK_AIR_POUND_SOURCE_CPU_QUALIFIED_NATIVE_PENDING',native=False,admitted=False,installed=False,
  candidate=B.sha(J/'candidate.nes'),parent=B.sha(P/'joint/candidate.nes'),own_source_merge_inventory=str(O/'source-merge-inventory.json'),
  actual_source_controls=dict(foreign_gate_pairs=6336,foot_tuples=336,normal_NMI_PPU=20,queue_item_canaries=64,full_Main_landing_scenes=18,foreign_Main=32,IRQ_lag_NMI_cuts=1964),
  controller_only_cold_bonus_route_prepared=False,retained_negatives=negatives,
  bindings={str(f.resolve()):B.sha(f)for f in sorted(files)if f.is_file()})
 save(out,d);print(json.dumps(dict(path=str(out),sha256=B.sha(out),candidate=d['candidate'],bindings=len(d['bindings']))),flush=True)
if __name__=='__main__':main()
