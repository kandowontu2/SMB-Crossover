"""Qualify the native shadow-ahead mapper seam, preserving strict live contracts."""
from pathlib import Path
P=Path(__file__).with_name('dk_groundpound_closure_v2.py');s=P.read_text()
# Use the v2 executable body, then retain its precise failure diagnostics.
Q=Path(__file__).with_name('dk_groundpound_closure_v1.py');body=Q.read_text()
body=body.replace('source-isr-closure-v1.json','source-isr-closure-v3.json')
body=body.replace("['air-trigger','foot-shatter','foreign-gate']", "['air-trigger','foot-shatter','foreign-gate','air-pending-store','foot-pending-store']")
body=body.replace("context=='air-trigger'", "context.startswith('air-')").replace("context=='foot-shatter'", "context.startswith('foot-')")
body=body.replace("original=D.NesMPU.step;hits=set();spmin=255", "original=D.NesMPU.step;hits=set();spmin=255;pending=[];converge=[]")
body=body.replace("if owns(*here)and here not in hits:", """store=bytes(q.m[c.pc:c.pc+3])==bytes([0x8d,0x16,0x51])
    divergent=q.m.banks[2]!=(q.get('CurrentBankC')&127)
    if owns(*here)and here not in hits and('pending-store'not in context or(store and divergent)):""")
body=body.replace("assert snap()==before,('genuine ISR preservation',context,kind,here)","""after=snap();want=list(before)
     if after[6]!=before[6]:
      # Bind the real source macro: STA CurrentBankC; LDA #raw; STA5116.
      # Native NMI saves/restores CurrentBankC, so at this known window its
      # restore can publish the imminent C mapping early. No C fetch/read
      # exists before the foreground's actual5116 store completes.
      cc=D.address(b,'CurrentBankC');shadow=before[8];suffix=bytes([0xa9,shadow,0x8d,0x16,0x51])
      if bytes(q.m[c.pc:c.pc+5])==suffix:
       assert bytes(q.m[c.pc-3:c.pc])==bytes([0x8d,cc&255,cc>>8]);end=c.pc+5
      else:
       assert store and bytes(q.m[c.pc-5:c.pc])==bytes([0x8d,cc&255,cc>>8,0xa9,shadow]);end=c.pc+3
      maps=list(before[6]);maps[2]=shadow&127;want[6]=tuple(maps)
      pending.append(dict(point=here,raw_shadow=shadow,beforeC=before[6][2],afterC=after[6][2],convergencePC=end))
      converge.append(end)
     changes=[]
     for ix,(u,v)in enumerate(zip(want,after)):
      if u!=v:
       changes.append([ix,[[i,a,z]for i,(a,z)in enumerate(zip(u,v))if a!=z][:30]]if isinstance(u,bytes)else[ix,u,v])
     assert not changes,('genuine ISR preservation',context,kind,here,changes)""")
body=body.replace("    original(c)\n   D.NesMPU.step=step", """    original(c)
    if c.pc in converge:
     assert q.m.banks[2]==(q.get('CurrentBankC')&127),'Actual foreground5116 mapping convergence'
     converge.remove(c.pc)
   D.NesMPU.step=step""")
body=body.replace("   assert hits\n   if context", "   assert hits and not converge\n   if context")
body=body.replace("if context.startswith('foot-'):assert any(k==12", "if context=='foot-shatter':assert any(k==12")
body=body.replace("minimum_SP=spmin))", "minimum_SP=spmin,source_bound_pending_publication=pending))")
exec(compile(body,str(Q),'exec'),dict(__name__='__main__',__file__=str(Path(__file__).resolve())))
