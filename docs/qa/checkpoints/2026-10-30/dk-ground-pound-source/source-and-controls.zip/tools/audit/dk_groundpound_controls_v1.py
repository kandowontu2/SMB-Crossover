"""Actual linked DK ground-pound instructions, native shatter/effect consumers."""
from pathlib import Path
import itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools'),str(R/'tools/reference')]
import donkey_kong_host_controls_v1 as D
O=R/'build/dk-groundpound-v4';ROM=O/'joint/candidate.nes';P=R/'build/functional-roster-ready54-v1/joint/candidate.nes'
def scene(b,x=96,tile=0x52):
 q=D.setup(b);q.put(AreaType=2,Player_X_Position=x&255,Player_PageLoc=x>>8,Player_Y_Position=176,
  Player_Y_HighPos=1,Player_State=2,Player_Y_Speed=4,DkAttack=3,DkSpawn=0,VRAM_Buffer1_Offset=0)
 for n in['Block_Buffer_1','Block_Buffer_2']:q.m[D.address(b,n):D.address(b,n)+208]=bytes(208)
 for page in range(2):
  for col in range(16):q.m[D.address(b,'Block_Buffer_1')+page*208+0xb0+col]=tile
 return q
def cell(b,world,row=0xb0):return D.address(b,'Block_Buffer_1')+((world>>8)&1)*208+row+((world&255)>>4)
def main():
 target=O/'controls-v1.json';assert not target.exists();b=D.scoped_load(ROM);old=D.scoped_load(P)
 checks={};proof=dict(passed=False,source_CPU_only=True,native_executed=False,ROM_sha256=D.sha(ROM),checks=checks)
 try:
  rows=[]
  gates=['DkConstruct','DkEnterScene','DkEnsure','DkGrant','DkFullPower','DkMovement','DkBounds','DkSpawnBarrel','DkBarrelStep']
  for raw,f,n in itertools.product([0,1,2,8,9,22,26,27,29,32,255],[v for v in range(256)if v&0x30==0x30],gates):
   pair=[]
   for bundle in[old,b]:
    q=D.setup(bundle);q.set('SelectedCharacter',raw);before=bytes(q.m[0x5c00:0x5c80]);c,w,_=D.run(q,n,a=0xa7,x=0x53,y=0x91,p=f)
    assert bytes(q.m[0x5c00:0x5c80])==before,(raw,f,n,'foreign overlay write')
    pair.append((D.registers(c),D.app(q),tuple(q.m.banks),bytes(q.m[0x1fe:0x200])))
   assert pair[0]==pair[1],('factored exact foreign gate',raw,f,n,pair[0][0],pair[1][0]);rows.append([raw,f,n])
  checks['foreign_9_gates_fullflags_live_stack']=dict(cases=len(rows),AXYP_SP_application_maps_livecaller_exact=True)
  rows=[]
  for tier,state in itertools.product(range(3),range(4)):
   q=D.setup(b);q.put(DkTier=tier,Player_State=state,SavedJoypadBits=0x44,DkPrevious=0)
   D.run(q,'DkClock');want=3 if state in[1,2] else 2 if tier==2 and state==0 else 1
   assert q.get('DkAttack')==want,('input',tier,state,q.get('DkAttack'))
   if want==3:
    for _ in range(80):D.run(q,'DkClock');D.run(q,'DkSpawnBarrel')
    assert q.get('DkAttack')==3 and q.get('Player_Y_Speed')==4 and not any(q.m[D.address(b,'DkShots'):D.address(b,'DkShots')+36])
   rows.append([tier,state,want])
  checks['alltiers_air_DownB_ground_tier2_vertical_retained']=dict(rows=rows,continuous_80updates_no_throw_spawn=True)
  rows=[]
  for tile,x,foot in itertools.product([0x51,0x52,0x22,0x88,0x54,0x61,0x55,0x58,0x5a,0xc0,0xc1,0x10,0x11,0],
    [1,96,254,255,256,511],range(2)):
   q=scene(b,x,tile);start=(x+[-13,19][foot])&65535;at=cell(b,start);before=bytes(q.m[D.address(b,'Block_Buffer_1'):D.address(b,'Block_Buffer_1')+416])
   q.put(R0=0x97,R1=0x35,M0=0x81,M1=0x77)
   c,tr,mn=D.M.C.M.runtrace(q,'DkHostFeet',y=foot,p=0x71)
   own=tile in[0x51,0x52]
   assert tr.count(D.point(b,'BrickShatter'))==int(own),('only ordinary',tile,x,foot)
   assert tr.count(D.point(b,'DestroyBlockMetatile'))==int(own)
   assert D.point(b,'PlayerHeadCollision')not in tr
   assert[q.get(n)for n in['R0','R1','M0','M1']]==[0x97,0x35,0x81,0x77]
   if own:
    assert q.m[at]==0 and q.get('VRAM_Buffer1_Offset')==10 and q.get('DkSpawn')==1
    slot=q.get('SprDataOffset_Ctrl');assert q.get('Block_State',slot)==0x12 and q.get('Block_Metatile',slot)==0
    assert q.get('Block_X_Position',slot)==(start&0xf0) and q.get('Block_PageLoc',slot)==(start>>8)&255
    assert q.get('Block_Y_Position',slot)==208 and q.get('Block_Y_HighPos',slot)==1
    assert q.get('NoiseSoundQueue')!=0 and q.get('Player_Y_Speed')==4
    assert q.get('Player_X_Position')==(x&255) and q.get('Player_PageLoc')==x>>8 and q.get('Player_Y_Position')==176
    D.M.T.nmi(q,c)
   else:assert bytes(q.m[D.address(b,'Block_Buffer_1'):D.address(b,'Block_Buffer_1')+416])==before and not q.get('VRAM_Buffer1_Offset')
   rows.append([tile,x,foot,int(own),c.processorCycles,mn])
  checks['ordinary_bricks_only_signed_foot_cells_native_effects']=dict(cases=len(rows),rows=rows,real_normal_NMI_after_shatter=True,no_head_collision_or_player_origin_substitution=True)
  rows=[]
  for off,busy in itertools.product([0,53,63,64,73,83,255],range(3)):
   q=scene(b);q.put(VRAM_Buffer1_Offset=off)
   if busy:
    for slot in range(2):q.set('Block_State',0x11 if busy==1 else 0,slot);q.set('Block_RepFlag',0 if busy==1 else 1,slot)
   before=bytes(q.m[D.address(b,'Block_Buffer_1'):D.address(b,'Block_Buffer_1')+416]);c,tr,mn=D.M.C.M.runtrace(q,'DkHostFeet',y=0)
   accept=off<64 and busy==0
   assert tr.count(D.point(b,'BrickShatter'))==int(accept)
   assert(q.get('VRAM_Buffer1_Offset')==off+10)if accept else(q.get('VRAM_Buffer1_Offset')==off)
   if not accept:assert bytes(q.m[D.address(b,'Block_Buffer_1'):D.address(b,'Block_Buffer_1')+416])==before and q.get('DkAttack')==3
   rows.append([off,busy,int(accept)])
  checks['queue_atomic_and_item_block_slots_retained']=dict(rows=rows)
  rows=[]
  for low in range(16):
   x=256+low;q=scene(b,x,0x52);removed=[]
   for age in range(5):
    D.run(q,'DkClock');before=bytes(q.m[D.address(b,'Block_Buffer_1'):D.address(b,'Block_Buffer_1')+416]);q.put(VRAM_Buffer1_Offset=0)
    for foot in range(2):D.run(q,'DkHostFeet',y=foot)
    after=bytes(q.m[D.address(b,'Block_Buffer_1'):D.address(b,'Block_Buffer_1')+416]);removed.append(sum(a!=z for a,z in zip(before,after)))
    assert removed[-1]<=1
   expected={cell(b,x+dx)for dx in[-13,3,19,29]}
   assert all(q.m[a]==0 for a in expected),('full42px columns',low,removed,expected)
   rows.append([low,len(expected),removed])
  checks['full42px_all16alignments_one_break_per_Main']=dict(rows=rows)
  proof['passed']=True
 except Exception as e:proof.update(failure=repr(e),traceback=traceback.format_exc())
 finally:
  paths={Path(__file__),ROM,ROM.with_suffix('.dbg'),ROM.with_suffix('.lbl'),P,P.with_suffix('.dbg')}
  for module in list(sys.modules.values()):
   p=getattr(module,'__file__',None)
   if p and Path(p).resolve().is_relative_to(R/'tools'):paths.add(Path(p).resolve())
  for p in(O/'joint').rglob('*'):
   if p.is_file()and p.suffix in['.s','.inc','.cfg','.o','.dep']:paths.add(p)
  proof['bindings']={str(p):D.sha(p)for p in sorted(paths)if p.is_file()};target.write_text(json.dumps(proof,indent=2)+'\n')
 print(json.dumps(dict(passed=proof['passed'],failure=proof.get('failure'),checks=list(checks),receipt=str(target))))
 assert proof['passed']
if __name__=='__main__':main()
