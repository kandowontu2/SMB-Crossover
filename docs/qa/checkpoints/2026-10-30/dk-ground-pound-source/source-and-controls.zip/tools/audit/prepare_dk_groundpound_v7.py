"""Preserve the actual current InitScreen shadow source during zero-export build."""
from pathlib import Path
import json,subprocess,sys
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
from private_build_outputs_v1 import validate
from prepare_cv3_dmc_mirror import prepare
import prepare_ff_joint_source_v1 as B
P=R/'build/dk-groundpound-v6';O=R/'build/dk-groundpound-v7';J=O/'joint';A=R/'build/functional-roster-ready54-v1'
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
def run(c,n):
 guard=validate(c,O,cwd=R);q=subprocess.run(c,cwd=R,capture_output=True,text=True)
 save(O/(n+'.json'),dict(command=c,guard=guard,returncode=q.returncode,stdout=q.stdout,stderr=q.stderr));assert q.returncode==0,q.stderr
def main():
 assert not O.exists();J.mkdir(parents=True)
 for f in(P/'joint').rglob('*'):
  if f.is_file()and f.suffix in['.s','.inc','.cfg','.bin']:
   z=J/f.relative_to(P/'joint');z.parent.mkdir(parents=True,exist_ok=True);z.write_bytes(f.read_bytes())
 (J/'entrypoint.s').write_bytes((R/'build/dk-groundpound-v4/joint/entrypoint.s').read_bytes())
 (J/'screen_render.s').write_bytes((A/'joint/screen_render.s').read_bytes())
 cfg=(J/'private.cfg').read_text().replace(str(P/'joint'),str(J)).replace((P/'joint').as_posix(),J.as_posix());(J/'private.cfg').write_text(cfg,encoding='utf-8',newline='\n')
 c=json.loads((R/'build/dk-groundpound-v4/compile-main.json').read_text())['command']
 old=R/'build/dk-groundpound-v4/joint'
 c=[str(J/Path(x).name)if x in[str(old/n)for n in['entrypoint.s','main.o','main.dep']]else x for x in c];run(c,'compile-main')
 c=json.loads((P/'compile.json').read_text())['command'];c=[x.replace(str(P),str(O))for x in c];run(c,'compile')
 c=json.loads((P/'final-link.json').read_text())['command']
 for i,x in enumerate(c):
  if x==str(old/'main.o'):c[i]=str(J/'main.o')
  elif x in[str(P/'joint'/n)for n in['dk-component.o','private.cfg','candidate.nes','candidate.lbl','candidate.map']]:c[i]=str(J/Path(x).name)
  elif x.startswith('--dbgfile,'):c[i]='--dbgfile,'+str(J/'candidate.dbg')
 run(c,'final-link');prepare(R,J/'candidate.nes')
 a=(A/'joint/candidate.nes').read_bytes();v=(P/'joint/candidate.nes').read_bytes();b=(J/'candidate.nes').read_bytes();diff=[i for i,(x,y)in enumerate(zip(v,b))if x!=y]
 assert diff==[0x725e,0x7263,0x7268],diff
 assert all(b[i]==a[i]for i in diff)
 assert b[:16]==a[:16]and b[1048592:]==a[1048592:]
 save(O/'retained-v6-source-regression.json',dict(passed=True,candidate=B.sha(J/'candidate.nes'),negative_candidate=B.sha(P/'joint/candidate.nes'),
  negative='Relocating entrypoint removed its original local screen_render.s include shadow, reverting the real QwSceneInit operand to MoveAllSpritesOffscreen. Caught before any native/admission.',
  exact_three_byte_correction=[dict(ROM=i,old=v[i],new=b[i],parent=a[i])for i in diff],
  source=str(J/'screen_render.s'),source_sha256=B.sha(J/'screen_render.s'),source_exact_current_parent=True,
  no_payload_CHR_header_other_DK_change=True))
 print(json.dumps(dict(candidate=B.sha(J/'candidate.nes'),output=str(O))),flush=True)
if __name__=='__main__':main()
