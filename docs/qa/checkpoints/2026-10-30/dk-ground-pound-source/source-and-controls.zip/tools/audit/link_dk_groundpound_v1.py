"""Link new DK object using genuine current objects and export-only native source."""
from pathlib import Path
import hashlib,json,re,subprocess,sys
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
from private_build_outputs_v1 import validate
from check_tmnt_render_oa import address,location
from link_pit_rygar_sophia_audit_cpu import scoped_load
P=R/'build/functional-roster-ready54-v1';O=R/'build/dk-groundpound-v3';J=O/'joint'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,s):p.write_text(s,encoding='utf-8',newline='\n')
def run(cmd,name):
 guard=validate(cmd,O,cwd=R);p=subprocess.run(cmd,cwd=R,capture_output=True,text=True)
 write(O/(name+'.json'),json.dumps(dict(command=cmd,guard=guard,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr),indent=2));assert p.returncode==0,p.stderr
def main():
 assert not(J/'candidate.nes').exists()
 b=scoped_load(P/'joint/candidate.nes');data=(P/'joint/candidate.nes').read_bytes()
 start=16+12*8192+0x1fad
 assert data[start:start+83]==b'\xff'*83
 # Actual read-only import closure; no aliased addresses are invented.
 s=(P/'joint/entrypoint.s').read_text();exports=set()
 for line in re.findall(r'^\.export(?:zp)? (.+)$',s,re.M):exports|={n.strip()for n in line.split(',')}
 names=['BrickShatter','DestroyBlockMetatile','GuestClaimBlockSlot','Player_Y_Speed','M0','M1','Block_State',
 'Block_X_Position','Block_Y_Position','Block_PageLoc','Block_Y_HighPos','Block_Orig_YPos','Block_BBuf_Low','Block_PageLoc2','Block_Metatile']
 for n in names:
  if n not in exports:s+='\n.export'+('zp'if address(b,n)<256 else'')+' '+n+'\n'
 write(J/'entrypoint.s',s)
 cmd=json.loads((P/'compile-main.json').read_text())['command']
 inp=[v for v in cmd if v.lower().endswith('.s')];assert inp==[str(P/'joint/entrypoint.s')],inp
 cmd=[str(J/'entrypoint.s')if v==str(P/'joint/entrypoint.s')else v for v in cmd]
 for flag,name in [('-o','main.o'),('--create-full-dep','main.dep')]:cmd[cmd.index(flag)+1]=str(J/name)
 run(cmd,'compile-main')
 cfg=(P/'joint/private.cfg').read_text().replace((P/'joint').as_posix(),J.as_posix()).replace(str(P/'joint'),str(J))
 a,z=cfg.split('SEGMENTS {',1);a=a.rsplit('}',1)[0]+'\nDK_POUND_A12_RUN:start=$bfad,size=$53,type=ro,file="",bank=12;\n}\n'
 z=z.rsplit('}',1)[0]+'\nDK_POUND_COMMIT:load=PRGC_00,run=DK_POUND_A12_RUN,type=ro,start=$bfad;\n}\n'
 write(J/'private.cfg',a+'SEGMENTS {'+z)
 cmd=json.loads((P/'final-link.json').read_text())['command']
 cmd=[str(J/Path(v).name)if v in[str(P/'joint'/n)for n in['main.o','dk-component.o']]else v for v in cmd]
 for i,v in enumerate(cmd):
  if v==str(P/'joint/private.cfg'):cmd[i]=str(J/'private.cfg')
  elif v in[str(P/'joint'/n)for n in['candidate.nes','candidate.lbl','candidate.map']]:cmd[i]=str(J/Path(v).name)
  elif v.startswith('--dbgfile,'):cmd[i]='--dbgfile,'+str(J/'candidate.dbg')
 run(cmd,'final-link')
 z=scoped_load(J/'candidate.nes');changes=[i for i,(x,y)in enumerate(zip(data,(J/'candidate.nes').read_bytes()))if x!=y]
 write(O/'linked-sizing.json',json.dumps(dict(candidate=sha(J/'candidate.nes'),parent=sha(P/'joint/candidate.nes'),
  allocation=dict(CORE=[1460,1475],HOST=[1022,1024],ART=[1178,1261],tail=[82,83]),
  ART_tail_preimage_FF=True,tail_run_BFAD_load_DFAD=True,header_exact=data[:16]==(J/'candidate.nes').read_bytes()[:16],
  changed_ROM_bytes=len(changes),changed_banks=sorted(set((i-16)//8192 for i in changes)),
  native_export_only=True,unchanged_own_ART_prefix=data[location(b,'DkGraphics'):start]==(J/'candidate.nes').read_bytes()[location(z,'DkGraphics'):start]),indent=2))
 print(sha(J/'candidate.nes'))
if __name__=='__main__':main()
