"""Actual DK source relocation/lease closure and real in-flight ISR contracts."""
from pathlib import Path
import itertools,json,re,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools'),str(R/'tools/reference')]
import donkey_kong_host_controls_v1 as D
import dk_groundpound_controls_v1 as V
from arthur_cache_host_controls_v1 import OverlayMemory
import link_pit_rygar_sophia_audit_cpu as A
A.Memory=OverlayMemory
O=R/'build/dk-groundpound-v7';J=O/'joint';P=R/'build/functional-roster-ready54-v1/joint'
def owns(bank,pc):return(bank==36 and 0xb9fd<=pc<0xbfc0)or(bank==65 and 0xbc00<=pc<=0xffff and pc<0xc000)or(bank==12 and(0xdb13<=pc<0xe000 or 0xbfad<=pc<0xc000))
def main():
 out=O/'source-isr-closure-v1.json';assert not out.exists();p=dict(passed=False,native=False,installed=False,admitted=False,checks={});ck=p['checks']
 try:
  b=D.scoped_load(J/'candidate.nes');old=D.scoped_load(P/'candidate.nes');a,z=old['raw'],b['raw']
  assert a[:16]==z[:16]and a[1048592:]==z[1048592:]
  assert a[16+125*8192:16+126*8192]==z[16+125*8192:16+126*8192]
  spans=[(16+36*8192+0x19fd,16+36*8192+0x1fc0),(16+65*8192+0x1c00,16+66*8192),(16+12*8192+0x1b13,16+13*8192)]
  diff={i for i,(x,y)in enumerate(zip(a,z))if x!=y};outside={i for i in diff if not any(lo<=i<hi for lo,hi in spans)};claimed=set();rows=[]
  text=(P/'union.s').read_text();names=re.search(r'^HuLo:\s*\n\s*\.byte (.+)$',text,re.M).group(1).split(',');names=[n.strip()[1:]for n in names]
  assert len(names)==144
  for tab,kind in [('HuLo','lo'),('HuHi','hi'),('HuBank','bank')]:
   base=D.location(old,tab);assert base==D.location(b,tab)
   for i,name in enumerate(names):
    vals=[]
    for bundle in[old,b]:
     ptr=D.address(bundle,name);bank=(D.location(bundle,name)-16)//8192|128
     vals.append(ptr&255 if kind=='lo'else ptr>>8 if kind=='hi'else bank)
    assert a[base+i]==vals[0]and z[base+i]==vals[1],(tab,i,name,vals)
    if vals[0]!=vals[1]:
     assert name.startswith('Dk');claimed.add(base+i);rows.append(dict(ROM=base+i,consumer=tab,index=i,target=name,old=vals[0],new=vals[1]))
  # Actual imported-source farcall immediate triples, including C63's own
  # continuation instead of a fabricated direct call to FarCallCommon.
  lo=D.address(old,'FarcallJmpTarget_SMC')+1;hi=lo+1
  for name in old['syms']:
   if not name.startswith('Dk')or name not in b['syms']:continue
   try:
    u,v=D.address(old,name),D.address(b,name);ub=(D.location(old,name)-16)//8192|128;vb=(D.location(b,name)-16)//8192|128
   except (AssertionError,KeyError):continue
   pattern=bytes([0xa9,u&255,0x8d,lo&255,lo>>8,0xa9,u>>8,0x8d,hi&255,hi>>8,0xa9,ub])
   replacement=bytes([0xa9,v&255,0x8d,lo&255,lo>>8,0xa9,v>>8,0x8d,hi&255,hi>>8,0xa9,vb])
   start=0
   while True:
    at=a.find(pattern,start)
    if at<0:break
    start=at+1
    if not any(at<=i<at+12 for i in outside):continue
    assert z[at:at+12]==replacement,(name,hex(at))
    for k in[1,6,11]:
     if a[at+k]!=z[at+k]:claimed.add(at+k);rows.append(dict(ROM=at+k,consumer='genuine source farcall immediate',target=name,old=a[at+k],new=z[at+k]))
  assert claimed==outside,('unexplained foreign bytes',sorted(outside-claimed),sorted(claimed-outside))
  start=16+12*8192+0x1fad;assert a[start:start+83]==b'\xff'*83
  assert z[start+82]==255
  artlo=D.location(old,'DkArtStart');arthi=D.location(old,'DkArtEnd');assert z[artlo:arthi]==a[artlo:arthi]
  state=J/'src/donkey_kong_state.inc';assert state.read_bytes()==(P/'src/donkey_kong_state.inc').read_bytes()
  ck['exact_lease_and_genuine_source_consumers']=dict(changed_bytes=len(diff),outside_owned_bytes=len(outside),relocations=rows,
   own_physical_spans=spans,allocation=dict(CORE=[1460,1475],HOST=[1024,1024],ART=[1178,1261],tail=[82,83]),
   actual_ART_tail_preimage83FF=True,ART_records_exact=True,header_CHR_final125_exact=True,no_new_RAM=True,
   native_InitScreen_QwSceneInit_operand_exact_parent=True)
  v6=(R/'build/dk-groundpound-v6/joint/candidate.nes').read_bytes();same=[i for i,(u,v)in enumerate(zip(v6,z))if u!=v]
  assert same==[0x725e,0x7263,0x7268]
  ck['v6_code_controls_transfer_scope']=dict(exact_three_restored_native_InitScreen_operands=same,
   every_DK_instruction_and_every_effect_consumer_byte_exact_v6=True,normal_PPU_Main_controls=str(R/'build/dk-groundpound-v6/main-ppu-controls-v1.json'),
   old_v5_lag_NMI_label_erratum='v5 controls-v3 direct foot NMI inherited NmiDisableFF and was LAG. v6 main-ppu controls independently setNmiDisable0 and observed actual2007+4014 writes.',
   no_native_route_or_campaign_claim=True)
  smc=json.loads((R/'build/dk-union13-facing-v3/dk/config.json').read_text())['smc_fields'];assert len(smc)==33
  events=[]
  for context,kind in itertools.product(['air-trigger','foot-shatter','foreign-gate'],['NMI','IRQ']):
   q=V.scene(b);q.put(NmiDisable=255,SavedJoypadBits=0x44 if context=='air-trigger'else 0)
   if context=='air-trigger':q.put(Player_Y_Position=160,Player_State=1,DkAttack=0)
   if context=='foreign-gate':q.put(SelectedCharacter=0)
   original=D.NesMPU.step;hits=set();spmin=255
   def step(c):
    nonlocal spmin
    spmin=min(spmin,c.sp);bank=q.m.banks[(c.pc-0x8000)//8192]if c.pc>=0x8000 else -1;here=(bank,c.pc)
    if owns(*here)and here not in hits:
     hits.add(here)
     def snap():return(c.pc,c.a,c.x,c.y,c.p,c.sp,tuple(q.m.banks),q.get('CurrentBank'),q.get('CurrentBankC'),bytes(q.m[a]for a in smc),bytes(q.m[:8]),bytes(q.m[0x101+c.sp:0x200]),bytes(q.m[0x5c00:0x6000]))
     before=snap()
     if kind=='IRQ':q.m[0x5204]=128;c.irq()
     else:c.nmi()
     for _ in range(60000):
      original(c)
      if c.pc==before[0]and c.sp==before[5]:break
     else:raise AssertionError(('ISR timeout',context,kind,here))
     assert snap()==before,('genuine ISR preservation',context,kind,here)
    original(c)
   D.NesMPU.step=step
   try:
    if context=='foreign-gate':D.M.C.M.runtrace(q,'DkMovement',p=0x30)
    else:D.M.C.M.runtrace(q,'GameLoop',p=0x30)
   finally:D.NesMPU.step=original
   assert hits
   if context=='foot-shatter':assert any(k==12 and 0xbfad<=pc<0xc000 for k,pc in hits)
   events.append(dict(context=context,kind=kind,cuts=len(hits),actual_points=sorted(hits),minimum_SP=spmin))
  ck['actual_inflight_IRQ_lag_NMI_all_own_instruction_points']=dict(rows=events,total_cuts=sum(x['cuts']for x in events),
   all_AXYP_SP_livepage1_R0R7_ExRAM_maps_shadow_33SMC_exact=True,normal_NMI_at_completed_Main_only=True)
  p['passed']=True
 except Exception as e:p.update(error=repr(e),traceback=traceback.format_exc())
 files={Path(__file__),J/'candidate.nes',J/'candidate.dbg',J/'candidate.lbl',P/'candidate.nes',P/'candidate.dbg',P/'union.s',state}
 for module in list(sys.modules.values()):
  f=getattr(module,'__file__',None)
  if f and Path(f).resolve().is_relative_to(R/'tools'):files.add(Path(f).resolve())
 p['bindings']={str(f.resolve()):D.sha(f)for f in files if f.exists()};out.write_text(json.dumps(p,indent=2)+'\n',encoding='utf-8',newline='\n')
 print(json.dumps(dict(passed=p['passed'],error=p.get('error'),checks=list(ck),path=str(out))),flush=True);assert p['passed']
if __name__=='__main__':main()
