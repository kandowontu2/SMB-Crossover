"""Source-only DK ground-pound sizing/link prototype in existing own spans."""
from pathlib import Path
import difflib,hashlib,json,re,subprocess,sys
R=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
from private_build_outputs_v1 import validate
P=R/'build/functional-roster-ready54-v1';S=R/'build/current-character-composition-v1/joint'
O=R/'build/dk-groundpound-v1';J=O/'joint'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf-8',newline='\n')
def main():
 assert not O.exists();J.mkdir(parents=True)
 assert sha(P/'joint/candidate.nes')=='08f1a75fb13f1974270bf9c6732d050f778f7f5b8b8a3361683416c242a176f3'
 for n in ['dk-component.s','dk-imports.inc','dk-p0-art.inc']:
  (J/n).write_bytes((S/n).read_bytes())
 for n in ['donkey_kong_core.s','donkey_kong_state.inc','donkey_kong_render.s','donkey_kong_host.s']:
  write(J/'src'/n,(S/'src'/n).read_text())
 p=J/'src/donkey_kong_core.s';s=p.read_text()
 s=s.replace(' lda DkAttack\n beq Start\n inc DkAge',' lda DkAttack\n cmp #3\n beq Pound\n beq Start\n inc DkAge') if False else s
 s=s.replace(' lda DkAttack\n beq Start\n inc DkAge',' lda DkAttack\n beq Start\n cmp #3\n beq Pound\n inc DkAge')
 s=s.replace('Start:\n lda DkFresh','Pound:\n lda #0\n sta DkSpawn\n lda #2\n sta Player_State\n lda #4\n sta Player_Y_Speed\n rts\nStart:\n lda DkFresh')
 s=s.replace(' lda #1\n sta DkAttack\n lda DkTier',' lda #1\n sta DkAttack\n lda SavedJoypadBits\n and #4\n beq Begin\n lda Player_State\n beq Ground\n cmp #3\n bcs Begin\n lda #3\n sta DkAttack\n bne Pound\nGround:\n lda DkTier')
 s=s.replace(' lda DkSpawn\n jeq No',' lda DkAttack\n cmp #3\n jeq No\n lda DkSpawn\n jeq No')
 write(p,s)
 p=J/'src/donkey_kong_host.s';s=p.read_text()
 old=''' lda #$f3
 cpy #1
 beq :+
 lda #29
:sta DkProbeDX
 jsr DkTerrainRead
 bne Done
 lda #8
 sta DkProbeDX
 jsr DkTerrainRead
Done:rts
.endproc
.proc DkHostSide'''
 new=''' lda #$f3
 cpy #1
 beq :+
 lda #19
:sta DkProbeDX
 jsr DkPoundRead
 bne Done
 lda #3
 cpy #1
 beq :+
 lda #29
:sta DkProbeDX
 jsr DkPoundRead
Done:rts
.endproc
.proc DkHostSide'''
 assert s.count(old)==1;s=s.replace(old,new)
 # Keep the native full foot ABI in the same physical A65, but use the
 # retained A36 capacity for source policy and a true A12 SFC worker.
 s+='''
.pushseg
.segment "DONKEY_KONG_CORE"
.export DkPoundRead,DkPoundCommit
.proc DkPoundRead
 farcall DkTerrainRead
 pha
 lda DkAttack
 cmp #3
 bne Return
 lda R4
 cmp #5
 bcs Return
 pla
 cmp #$51
 beq Brick
 cmp #$52
 beq Brick
 tay
 lda MTileAttribute,y
 and #MTILE_SOLID
 beq Query
 lda #0
 sta DkAttack
Query:farcall DkTerrainRead,jmp
Brick:
 lda DkSpawn
 bne Query
 lda VRAM_Buffer1_Offset
 cmp #64
 bcs Query
 lda R0
 pha
 lda R1
 pha
 lda M0
 pha
 lda M1
 pha
 farcall GuestClaimBlockSlot
 bcc Restore
 farcall DkPoundCommit
Restore:
 pla
 sta M1
 pla
 sta M0
 pla
 sta R1
 pla
 sta R0
 jmp Query
Return:pla
 rts
.endproc
.popseg
'''
 write(p,s)
 # This tail's physical bytes are already owned by DK ART. The linker run
 # view is A-window BFAD; all original C-window art/code PCs stay exact.
 write(J/'pound-commit.s','''
.pushseg
.segment "DK_POUND_COMMIT"
.proc DkPoundCommit
 lda #$12
 sta Block_State,x
 lda R2
 sta Block_Orig_YPos,x
 clc
 adc #32
 sta Block_Y_Position,x
 lda R6
 sta Block_BBuf_Low,x
 lda R5
 and #$f0
 sta Block_X_Position,x
 lda DkProbePage
 sta Block_PageLoc,x
 sta Block_PageLoc2,x
 lda #1
 sta Block_Y_HighPos,x
 sta DkSpawn
 lda #0
 sta Block_Metatile,x
 ldy R2
 sta (R6),y
 farcall DestroyBlockMetatile
 jsr BrickShatter
 lda #4
 sta Player_Y_Speed
 rts
.endproc
.popseg
''')
 p=J/'dk-component.s';s=p.read_text()+ '\n.include "pound-commit.s"\n';write(p,s)
 p=J/'dk-imports.inc';s=p.read_text()+'''
.import BrickShatter,DestroyBlockMetatile,GuestClaimBlockSlot
.importzp Player_Y_Speed,M0,M1,Block_State,Block_X_Position,Block_Y_Position,Block_PageLoc,Block_Y_HighPos
.import Block_Orig_YPos,Block_BBuf_Low,Block_PageLoc2,Block_Metatile
''';write(p,s)
 ca=R/'tools/Windows/cc65/bin/ca65.exe'
 cmd=[str(ca),'--cpu','6502x','-g','-I',str(J/'src'),'-I',str(J),'-I',str(R),
      '--create-full-dep',str(J/'dk-component.dep'),'-l',str(J/'dk-component.lst'),'-o',str(J/'dk-component.o'),str(J/'dk-component.s')]
 guard=validate(cmd,O,cwd=R);p=subprocess.run(cmd,cwd=R,capture_output=True,text=True)
 write(O/'compile.json',json.dumps(dict(command=cmd,guard=guard,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr),indent=2))
 assert p.returncode==0,p.stderr
 print('DK source compiled',O)
if __name__=='__main__':main()
