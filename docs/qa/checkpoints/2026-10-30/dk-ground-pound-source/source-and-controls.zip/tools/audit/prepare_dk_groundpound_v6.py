"""Include mandatory genuine final125 CV3 mirror after final source link."""
from pathlib import Path
P=Path(__file__).with_name('prepare_dk_groundpound_v5.py');s=P.read_text()
s=s.replace("O=R/'build/dk-groundpound-v5'","O=R/'build/dk-groundpound-v6'")
s=s.replace("print(L.sha(J/'candidate.nes'))","from prepare_cv3_dmc_mirror import prepare\n prepare(R,J/'candidate.nes')\n print(L.sha(J/'candidate.nes'))")
exec(compile(s,str(P),'exec'),dict(__name__='__main__',__file__=str(Path(__file__).resolve())))
