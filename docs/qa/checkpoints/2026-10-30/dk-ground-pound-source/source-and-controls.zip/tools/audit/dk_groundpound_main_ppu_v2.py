"""Repeat actual complete Main/PPU controls on corrected native scene source."""
from pathlib import Path
P=Path(__file__).with_name('dk_groundpound_main_ppu_v1.py');s=P.read_text()
s=s.replace('build/dk-groundpound-v6','build/dk-groundpound-v7').replace('main-ppu-controls-v1.json','main-ppu-controls-v2.json')
exec(compile(s,str(P),'exec'),dict(__name__='__main__',__file__=str(Path(__file__).resolve())))
