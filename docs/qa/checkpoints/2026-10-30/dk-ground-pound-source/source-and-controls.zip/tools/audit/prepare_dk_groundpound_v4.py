"""Correct callback flags/foot table and link in a fresh private root."""
from pathlib import Path
import hashlib,json,subprocess,sys
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
from private_build_outputs_v1 import validate
import link_dk_groundpound_v1 as L
P=R/'build/dk-groundpound-v3';O=R/'build/dk-groundpound-v4';J=O/'joint'
def main():
 assert not O.exists();J.mkdir(parents=True)
 for f in(P/'joint').rglob('*'):
  if f.is_file()and f.suffix in['.s','.inc']:
   q=J/f.relative_to(P/'joint');q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(f.read_bytes())
 p=J/'src/donkey_kong_host.s';s=p.read_text()
 old=''' lda #$f3
 cpy #1
 beq :+
 lda #19
:sta DkProbeDX''';assert s.count(old)==1;s=s.replace(old,' lda FootOffsets-1,y\n sta DkProbeDX')
 old=''' lda #3
 cpy #1
 beq :+
 lda #29
:sta DkProbeDX''';assert s.count(old)==1;s=s.replace(old,' lda FootOffsets+1,y\n sta DkProbeDX')
 s=s.replace('Done:rts\n.endproc\n.proc DkHostSide','Done:rts\nFootOffsets:.byte $f3,19,3,29\n.endproc\n.proc DkHostSide')
 s=s.replace('.proc DkPoundRead\n jsr DkTerrainRead\n pha','.proc DkPoundRead\n jsr DkTerrainRead\n php\n pha')
 s=s.replace(' pla\n cmp #$51',' pla\n plp\n cmp #$51').replace('Return:pla\n rts','Return:pla\n plp\n rts')
 L.write(p,s)
 L.O=O;L.J=J
 cmd=json.loads((P/'compile.json').read_text())['command'];cmd=[v.replace(str(P),str(O))for v in cmd]
 L.run(cmd,'compile')
 # The previous link failed before output because its segment was appended
 # to SYMBOLS. Preserve that exact log, and insert in genuine SEGMENTS.
 L.write(O/'retained-link-v3-negative.json',json.dumps(dict(log=str(P/'final-link.json'),sha256=L.sha(P/'final-link.json'),
  failure='Segment line appended into SYMBOLS; ld65 rejected config before linking.'),indent=2))
 original=L.write
 def cfgwrite(p,s):
  if p.name=='private.cfg':
   line='DK_POUND_COMMIT:load=PRGC_00,run=DK_POUND_A12_RUN,type=ro,start=$bfad;\n'
   assert s.count(line)==1;s=s.replace(line,'')
   a,z=s.split('SEGMENTS {',1);before,after=z.split('}',1);s=a+'SEGMENTS {'+before+line+'}'+after
  original(p,s)
 L.write=cfgwrite;L.main()
if __name__=='__main__':main()
