"""Real Main, original bonus-room cells and explicit normal-NMI PPU consumers."""
from pathlib import Path
import itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools'),str(R/'tools/reference')]
import donkey_kong_host_controls_v1 as D
import dk_groundpound_controls_v1 as V
from arthur_cache_host_controls_v1 import OverlayMemory
import link_pit_rygar_sophia_audit_cpu as ArenaModule
ArenaModule.Memory=OverlayMemory
O=R/'build/dk-groundpound-v6';P=R/'build/functional-roster-ready54-v1/joint/candidate.nes'
def bonus(b,x):
 q=D.setup(b);q.put(AreaPointer=0xc2);D.run(q,'GetAreaDataAddrs')
 for j in range(3):q.set('AreaObjectLength',255,j)
 columns=[]
 for col in range(32):
  D.run(q,'AreaParserCore');column=[q.get('MetatileBuffer',y)for y in range(13)];columns.append(column)
  for y,t in enumerate(column):q.m[D.address(b,'Block_Buffer_1')+(col//16)*208+y*16+col%16]=t
  D.run(q,'IncrementColumnPos')
 q.put(Player_X_Position=x,Player_PageLoc=0,Player_Y_Position=112,Player_State=1,Player_X_Speed=0,Player_Y_Speed=0,
  DkAttack=0,PlayerFacingDir=1,Player_MovingDir=1)
 D.run(q,'DkEnsure');return q,columns
def main():
 out=O/'main-ppu-controls-v1.json';assert not out.exists();b=D.scoped_load(O/'joint/candidate.nes');old=D.scoped_load(P)
 ck={};proof=dict(passed=False,native=False,admitted=False,installed=False,source_CPU_fixture=True,checks=ck)
 try:
  rows=[]
  for x,tile,coin in itertools.product([1,96,255,256,511],[0x51,0x52],[0,0xc2]):
   q=V.scene(b,x,tile);q.m[V.cell(b,x-13,row=0xa0)]=coin
   c,tr,mn=D.M.C.M.runtrace(q,'DkHostFeet',y=0)
   assert tr.count(D.point(b,'BrickShatter'))==1 and q.get('VRAM_Buffer1_Offset')==24
   base=D.address(b,'VRAM_Buffer1');packet=bytes(q.m[base:base+25]);addr=packet[0]*256+packet[1]
   q.put(NmiDisable=0);before=len(q.m.ppu_log);cycles=D.M.T.nmi(q,c);new=q.m.ppu_log[before:]
   writes=[(a,v)for a,v in new if a==0x2007]
   assert writes and any(a==0x4014 for a,v in q.m.writes)
   if not coin:assert[q.m.vram[i]for i in[addr,addr+1,addr+32,addr+33]]==[36]*4,('native blank tile consumption',x,addr,new)
   else:
    # Original RemoveCoin_Axe publishes its native buffer2 first. The
    # complete real buffer1 shatter/score packet remains for next NMI.
    q.put(NmiDisable=0);D.M.T.nmi(q,c)
    assert[q.m.vram[i]for i in[addr,addr+1,addr+32,addr+33]]==[36]*4
   assert q.get('NmiDisable')==255
   rows.append([x,tile,coin,addr,len(writes),cycles,mn])
  ck['explicit_normal_NMI_real_PPU_DMA_blank_and_coin']=dict(cases=len(rows),rows=rows,uncoin_flush_one_NMI_coin_two_NMIs=True)
  rows=[]
  for ctrl,off,busy in itertools.product([0,1,6,255],[0,59,60,83],range(2)):
   q=V.scene(b);q.put(VRAM_Buffer_AddrCtrl=ctrl,VRAM_Buffer1_Offset=off)
   if busy:
    for slot in range(2):q.set('Block_State',0x11,slot)
   base=D.address(b,'VRAM_Buffer1');q.m[base:base+85]=bytes((i*13+7)&255 for i in range(85));before=bytes(q.m[base:base+85])
   c,tr,mn=D.M.C.M.runtrace(q,'DkHostFeet',y=0);ok=ctrl==0 and off<60 and not busy
   assert tr.count(D.point(b,'BrickShatter'))==int(ok)
   if ok:assert q.get('VRAM_Buffer1_Offset')==off+24 and q.m[base+84]==before[84]
   else:assert bytes(q.m[base:base+85])==before and q.get('DkAttack')==3
   rows.append([ctrl,off,busy,int(ok)])
  ck['published_upload_fullqueue_item_slot_canary']=dict(cases=len(rows),rows=rows,byte84_Buffer2_offset_untouched=True)
  rows=[]
  for tier,mode,low in itertools.product(range(3),range(2),[0,7,15]):
   q=V.scene(b,96+low);q.put(Player_Y_Position=160,Player_State=1,DkAttack=0,DkTier=tier,PlayerStatus=tier,CrossoverBehaviorVersion=mode)
   for page in range(2):
    for col in range(16):q.m[D.address(b,'Block_Buffer_1')+page*208+0xc0+col]=0x54
   events=[]
   for age in range(24):
    q.put(SavedJoypadBits=0x44 if age==0 else 0,NmiDisable=255)
    c,tr,mn=D.M.C.M.runtrace(q,'GameLoop');count=tr.count(D.point(b,'BrickShatter'));assert count<=1
    assert D.point(b,'PlayerHeadCollision')not in tr
    ni=D.M.T.nmi(q,c);events.append([age,q.get('Player_Y_Position'),q.get('Player_State'),q.get('DkAttack'),count,c.processorCycles,ni,mn])
   assert q.get('Player_Y_Position')==192 and q.get('DkAttack')==0 and q.get('Player_State')==0
   assert q.get('NumberofLives')==2 and q.get('GameEngineSubroutine')==8
   assert sum(r[4]for r in events)>=3
   rows.append(dict(tier=tier,mode=mode,alignment=low,updates=events))
  ck['actual_Main_alltiers_rules_pound_then_unbreakable_land']=dict(cases=len(rows),rows=rows)
  # Source-owned original room, not a native cold route. Retain the central
  # chute limitation; the right-edge route reaches the genuine exit pipe.
  routes=[]
  for x in[112,160]:
   q,cols=bonus(b,x);events=[];side=False;retired=False;first=None
   assert cols[4][8:11]==[82]*3 and cols[15][9:11]==[30,33]
   for age in range(220):
    keys=(0x45 if age==0 else 1)if x==160 else(0x44 if age==0 else 1 if age>=36 else 0)
    q.put(SavedJoypadBits=keys,NmiDisable=255)
    c,tr,mn=D.M.C.M.runtrace(q,'GameLoop');ni=D.M.T.nmi(q,c)
    state=[q.get(n)for n in['OperMode_Task','GameEngineSubroutine','AreaType','AreaPointer','Player_X_Position','Player_Y_Position']]
    if state[1]==2:side=True;first=age if first is None else first
    if side and state[0]==0:retired=True
    assert q.get('NumberofLives')==2 and not q.get('MmDeathFlag')
    events.append([age,keys,*state,tr.count(D.point(b,'BrickShatter')),c.processorCycles,ni,mn])
    if retired:break
   if x==160:assert side and retired,('original-room real exit transition',events[-8:])
   else:assert not side and q.get('Player_X_Position')<128
   routes.append(dict(initial_x=x,actual_original32columns=cols,updates=events,entered_native_side_pipe=side,
    native_ChangeArea_reached=retired,scope='Explicit legal source room/position fixture; no native cold/earned route claim.'))
  ck['original1_1bonus_parser_rightedge_exit_and_center_negative']=dict(routes=routes)
  rows=[]
  for raw,keys in itertools.product([0,1,2,4,8,9,12,13,15,19,20,21,23,24,26,27],[0,129]):
   pair=[]
   for bundle in[old,b]:
    q=D.M.C.setup(bundle,raw);q.put(SavedJoypadBits=keys,NmiDisable=255)
    c,tr,mn=D.M.C.M.runtrace(q,'GameLoop',p=0x71)
    pair.append((D.registers(c),D.M.C.M.fastapp(q),tuple(q.m.banks),c.processorCycles))
   assert pair[0][:3]==pair[1][:3],('foreign complete Main',raw,keys,pair[0][0],pair[1][0])
   rows.append([raw,keys,pair[1][3]-pair[0][3]])
  ck['foreign_complete_Main']=dict(cases=len(rows),rows=rows,AXYP_SP_application_OAM_CHR_banks_exact=True)
  proof['passed']=True
 except Exception as e:proof.update(error=repr(e),traceback=traceback.format_exc())
 paths={Path(__file__),O/'joint/candidate.nes',O/'joint/candidate.dbg',P,P.with_suffix('.dbg')}
 for module in list(sys.modules.values()):
  f=getattr(module,'__file__',None)
  if f and Path(f).resolve().is_relative_to(R/'tools'):paths.add(Path(f).resolve())
 proof['bindings']={str(p.resolve()):D.sha(p)for p in paths if p.exists()};out.write_text(json.dumps(proof,indent=2)+'\n',encoding='utf-8',newline='\n')
 print(json.dumps(dict(passed=proof['passed'],error=proof.get('error'),checks=list(ck),receipt=str(out))));assert proof['passed']
if __name__=='__main__':main()
