"""Use the actual just-returned CPU for normal NMI; preserve prior fixture negative."""
from pathlib import Path
P=Path(__file__).with_name('dk_groundpound_controls_v1.py');s=P.read_text()
s=s.replace("build/dk-groundpound-v4","build/dk-groundpound-v5").replace("controls-v1.json","controls-v3.json")
s=s.replace("q.get('VRAM_Buffer1_Offset')==10","q.get('VRAM_Buffer1_Offset')==24")
s=s.replace("[0,53,63,64,73,83,255]","[0,53,59,60,63,64,73,83,255]")
s=s.replace("accept=off<64 and busy==0","accept=off<60 and busy==0")
s=s.replace("q.get('VRAM_Buffer1_Offset')==off+10","q.get('VRAM_Buffer1_Offset')==off+24")
s=s.replace("for foot in range(2):D.run(q,'DkHostFeet',y=foot)","for foot in range(2):c,_,_=D.run(q,'DkHostFeet',y=foot)")
s=s.replace("assert removed[-1]<=1","assert removed[-1]<=1\n    D.M.T.nmi(q,c)")
exec(compile(s,str(P),'exec'),dict(__name__='__main__',__file__=str(Path(__file__).resolve())))
