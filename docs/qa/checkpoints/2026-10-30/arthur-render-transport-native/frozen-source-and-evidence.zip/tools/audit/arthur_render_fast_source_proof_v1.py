"""Classify every source-linked byte change and retained private resource."""
from pathlib import Path
import hashlib,json
import arthur_render_fast_controls_v1 as F
from arthur_probe_source_proof_v1 import word
A=F.A;R=F.R;O=F.O;OLD=F.OLD
def main():
 out=O/'source-proof-v1.json';assert not out.exists();old=A.scoped_load(OLD/'candidate.nes');b=A.scoped_load(O/'candidate.nes');ra,rb=old['raw'],b['raw'];assert ra[:16]==rb[:16]
 segments=lambda z:{g['name'].strip('"'):g for g in z['segs'].values()};sa,sb=segments(old),segments(b);exact=[]
 for n,g in sa.items():
  if not n.startswith('ARTHUR_')or'ooffs'not in g or n in['ARTHUR_DRAW','ARTHUR_ART_TAIL','ARTHUR_CACHE_EXEC']:continue
  h=sb[n];assert int(g['size'],0)==int(h['size'],0);p,z,size=int(g['ooffs'],0),int(h['ooffs'],0),int(g['size'],0);assert ra[p:p+size]==rb[z:z+size],('unplanned original Arthur segment change',n);exact.append([n,size])
 for name in['host-adapter.s','host-state.s','host-world.s','component.s','native-kernels.s','art.s','palette.s','cache-loader.s','cache-input.bin','chr.s']:
  assert(OLD/'arthur'/name).read_bytes()==(O/'arthur'/name).read_bytes(),('Unplanned retained source edit',name)
 prefix=608;assert ra[A.location(old,'HuStart'):A.location(old,'HuStart')+prefix]==rb[A.location(b,'HuStart'):A.location(b,'HuStart')+prefix]
 bodies=[]
 for name,original,count in[('Visible','ArHostVisible',1),('Body','ArHostBodyPolicy',11),('Adder','ArHostAdder',3),('Box','ArHostBoxProfile',2),('Ui','ArHostUi',8),('Noop','ArHostNoop',1)]:
  orig=A.location(old,original);copy=A.location(b,'HuLocal'+name)+13;assert ra[orig:orig+count]==rb[copy:copy+count]and ra[orig+count]==96 and rb[copy+count]==76;assert word(rb,copy+count+1)==A.address(b,'HuPolicyReturn');bodies.append(dict(original=original,local='HuLocal'+name,exact_body_bytes=count))
 orig=A.location(old,'X5SetPhysicalChr');size=A.location(old,'X5SetSpecialChr')-orig;fast=A.location(b,'ArCachePublishFast');assert ra[orig+size-1]==96
 assert rb[fast:fast+3]==bytes([72,162,3]);assert rb[fast+3:fast+3+size-1]==ra[orig:orig+size-1]and rb[fast+3+size-1:fast+3+size+1]==bytes([104,96])
 changedchr=sorted({(i-1048592)//1024 for i in range(1048592,len(ra))if ra[i]!=rb[i]});assert changedchr==[883]
 allowed=[(16+26*8192+0x132a,16+26*8192+0x1c00),(16+70*8192+0x19b8,16+70*8192+0x2000),(16+79*8192+0x15e0,16+79*8192+0x2000)]
 outside={i for i in range(16,1048592)if ra[i]!=rb[i]and not any(lo<=i<hi for lo,hi in allowed)};covered=set();relocations=[];arg=A.address(old,'SafecallA_SMC')+1;target=A.address(old,'FarcallJmpTarget_SMC')+1;far=A.address(old,'FarCallCommon');moved={}
 for n,s in old['syms'].items():
  if '::'in n or n not in b['syms']or'seg'not in s:continue
  try:x,y=A.point(old,n),A.point(b,n)
  except(KeyError,ValueError):continue
  if x!=y:moved.setdefault((x,y),[]).append(n)
 for p in range(16,1048592-18):
  if ra[p]!=141 or word(ra,p+1)!=arg or ra[p+3]!=169 or ra[p+5]!=141 or word(ra,p+6)!=target or ra[p+8]!=169 or ra[p+10]!=141 or word(ra,p+11)!=target+1 or ra[p+13]!=169 or ra[p+15]not in[32,76]or word(ra,p+16)!=far:continue
  if not outside.intersection(range(p,p+18)):continue
  changed=[i for i in range(p,p+18)if ra[i]!=rb[i]];assert set(changed)<=set([p+4,p+9]);before=(ra[p+14]&127,ra[p+4]+256*ra[p+9]);after=(rb[p+14]&127,rb[p+4]+256*rb[p+9]);names=moved.get((before,after));assert names,('Unbound external relocation',p,before,after);covered.update(changed);relocations.append(dict(file_offset=p,genuine_same_symbols=names,before=before,after=after))
 assert outside==covered,('Unclassified outside owned leases',sorted(outside-covered)[:20])
 mainused=sum(int(sb[n]['size'],0)for n in['ARTHUR_BODY','ARTHUR_LEAF','ARTHUR_DRAW']);union=int(sb['CHARACTER_HOST_UNION']['size'],0);runtime=A.address(b,'ArCacheExecEnd')-A.address(b,'ArCacheEmit');storage=2326+runtime
 assert mainused==2233<=2262 and union==1939<=2592 and runtime==313 and storage==2639<=3072
 d=dict(passed=True,native=False,parent_ROM_sha256=A.sha(OLD/'candidate.nes'),candidate_ROM_sha256=A.sha(O/'candidate.nes'),header_exact=True,unchanged_original_segments=exact,all36_public_entries_and_prefix_exact=prefix,policy_bodies_exact=bodies,publisher_exact_native_instruction_body_bytes=size-1,only_changed_CHR_pages=changedchr,all_original_body_projectile_art_868_880_and_canonical_cache_exact=True,owned_PRG_file_intervals=allowed,outside_owned_intervals_only_same_source_farcall_relocations=relocations,A26_main_used=mainused,A26_main_reserved=2262,A79_union_used=union,A79_union_reserved=2592,C2_runtime_bytes=runtime,own_CHR_storage_bytes=storage,own_CHR_storage_reserved=3072,total_Arthur_PRG_bytes=sum(int(g['size'],0)for n,g in sb.items()if n.startswith('ARTHUR_')and'ooffs'in g and int(g['ooffs'],0)<1048592),no_new_PRG_RAM_ZP_CHR_header_lease=True,owner_contract='Local policy ingress is only HuCommon raw32 after its selected-owner guard. New C2 publisher ingress is only the existing full16B-cookie-verified raw32 ArHostDraw / ArCacheEmit chain. No new public shared hook, no shadow/rotation/source motion/actor update/palette/art change.')
 d['bindings']={str(p.resolve()):A.sha(p)for p in[Path(__file__),Path(F.__file__),O/'candidate.nes',O/'candidate.dbg',OLD/'candidate.nes',OLD/'candidate.dbg',O/'arthur-union.s',O/'arthur/cache-wrapper.s',O/'arthur/cache-runtime.s',O/'render-fast-plan.json',O/'arthur-build-proof.json',O/'cache-final-link-proof.json']};out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items()if k in['passed','candidate_ROM_sha256','A26_main_used','A79_union_used','C2_runtime_bytes','own_CHR_storage_bytes','total_Arthur_PRG_bytes']}))
if __name__=='__main__':main()
