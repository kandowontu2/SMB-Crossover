"""Real source loader/render/ISR/foreign contracts for the transport successor."""
from pathlib import Path
import argparse,importlib.util,json,traceback
import arthur_render_fast_controls_v1 as F
import arthur_cache_regression_controls_v1 as G
import arthur_host_commit_controls_v2 as K
A=F.A;H=F.H;R=F.R;O=F.O;OLD=F.OLD
def seams(b):
 spec=importlib.util.spec_from_file_location('render_fast_real_vectors',R/'build/character-host-union-v5/gm_verify_nmi.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g);rows=[]
 cuts=[('HuLocalUi',0,79),('HuLocalVisible',0,79),('HuPolicyReturn',0,79),('HuPolicyReturn',12,79),('HuPolicyReturn',42,79),('ArCachePublishFast',0,2),('ArCachePublishFast',3,2),('ArCachePublishFast',7,2),('ArCachePublishFast',13,2),('ArCachePublishFast',21,2)]
 for name,offset,bank in cuts:
  for kind in['NMI','IRQ']:
   q=G.setup(b);q.put(DisableScreenFlag=1,ArHostDue=1,ArHostPad=129,NmiDisable=255,VRAM_Buffer1_Offset=0,VRAM_Buffer_AddrCtrl=0)
   before=bytes(q.m.ram[2]);_,z=g.scheduler.invoke(q.m,'GameLoop',sp=240,cut=(A.address(b,name)+offset,bank,kind))
   assert bytes(q.m.ram[2])==before and q.m.rawtags[1]==q.get('CurrentBank')and q.m.rawtags[2]==q.get('CurrentBankC')
   rows.append(dict(entry=name,offset=offset,kind=kind,**g.scheduler.summary(z),ISR=g.scheduler.summary(z['interrupt'])))
 return dict(actual_vector_cuts=len(rows),rows=rows,all33SMC_live_stack_AXYP_SP_raw_tags_and_native_ZP_restored=True,cache_code_immutable=True)
def foreign(b):
 original=A.scoped_load;old=original(OLD/'candidate.nes');pinned=R/'build/ice-pose-aliases-v2/candidate.nes';A.scoped_load=lambda p:old if Path(p)==pinned else original(p)
 try:return A.foreign(b)
 finally:A.scoped_load=original
def main():
 p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--only',default='load,render,pixels,cookie,seams,foreign,interrupts,pickups,powerup_chooser,lifecycle,portrait,presentation,commit');args=p.parse_args();assert not args.output.exists();b=A.scoped_load(O/'candidate.nes');d=dict(passed=False,native=False,checks={});H.O=O
 functions=dict(load=H.load_controls,render=H.render_controls,pixels=A.render_pixels,cookie=G.cookie_execution_negative,seams=seams,foreign=foreign,commit=lambda b:K.run(b,False))
 try:
  for name in args.only.split(','):d['checks'][name]=functions.get(name,getattr(A,name,None))(b)
  d['passed']=True
 except Exception as e:d.update(failure=repr(e),traceback=traceback.format_exc())
 d['bindings']={str(p.resolve()):A.sha(p)for p in[Path(__file__),Path(F.__file__),Path(H.__file__),Path(G.__file__),Path(A.__file__),O/'candidate.nes',O/'candidate.dbg',O/'cache-final-link-proof.json',OLD/'candidate.nes',OLD/'candidate.dbg']};args.output.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(passed=d['passed'],checks=list(d['checks']),failure=d.get('failure'))));assert d['passed']
if __name__=='__main__':main()
