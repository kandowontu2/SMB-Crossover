"""Private successor: local policy bodies and source-equivalent C2 publisher."""
from pathlib import Path
import json,shutil,sys
import arthur_integrate_host_v1 as B
import arthur_host_cache_build_v1 as W
R=Path(__file__).resolve().parents[2];OLD=R/'build/arthur-host-probe-fast-v1';O=R/'build/arthur-host-render-fast-v1'
POLICIES={9:('Visible','sec'),11:('Body','lda #1\n sta GuestBodyNoStomp\n lda #0\n sta GuestBodyStompAllowed\n clc'),12:('Adder','ldy #0\n sec'),13:('Box','ldy #0'),29:('Ui','lda #0\n sta InvHudActive\n sta InvDirty')}
for row in[18,21,22,23,27,28,31,33,34,35]:POLICIES[row]=('Noop','clc')
def prepare():
 assert B.sha(OLD/'candidate.nes')=='52841a18a697a06d95bbbc028d510ec536d154a441391e9a928395b66fb3f4ef';assert not O.exists();O.mkdir()
 for name in['frozen-inputs','src','dense','arthur']:shutil.copytree(OLD/name,O/name)
 for p in OLD.iterdir():
  if p.is_file()and(p.suffix in['.s','.inc','.cfg','.chr','.nam','.rle','.o','.d']or p.name in['parent-commands.json','parent-reproduction.json','dense-parent-reproduction.json','arthur-build-proof.json']):shutil.copy2(p,O/p.name)
 for p in O.rglob('*'):
  if p.is_file()and p.suffix in['.s','.inc','.cfg','.d','.json']:
   s=p.read_text()
   for old,new in[(str(OLD),str(O)),(OLD.as_posix(),O.as_posix()),(str(OLD).replace('\\','\\\\'),str(O).replace('\\','\\\\'))]:s=s.replace(old,new)
   p.write_text(s,newline='\n')
 p=O/'entrypoint.s';p.write_text(p.read_text()+'\n.export SafereturnA_SMC\n',newline='\n')
 p=O/'arthur-union.s';s=p.read_text();s='.import ArTemp,ArTempHi,GuestBodyNoStomp,GuestBodyStompAllowed,InvHudActive,InvDirty,SafereturnA_SMC\n.importzp R0,R1\n'+s
 anchor=' sta ArDrawPtr+1\n lda HuArthurDirectProbe,y';assert s.count(anchor)==1
 s=s.replace(anchor,''' sta ArDrawPtr+1
 lda HuArthurLocalHi,y
 beq NotLocal
 sta FarcallJmpTarget_SMC+2
 lda HuArthurLocalLo,y
 sta FarcallJmpTarget_SMC+1
 pla
 tay
 plp
 lda SafecallA_SMC+1
 jmp (FarcallJmpTarget_SMC+1)
NotLocal:
 lda HuArthurDirectProbe,y''',1)
 table='HuArthurLocalLo:\n .byte '+','.join('<HuLocal'+POLICIES[i][0]if i in POLICIES else'0'for i in range(36))+'\nHuArthurLocalHi:\n .byte '+','.join('>HuLocal'+POLICIES[i][0]if i in POLICIES else'0'for i in range(36))+'\n'
 s=s.replace('HuArthurDirectProbe:',table+'HuArthurDirectProbe:',1)
 wrappers='''
; Reached only after HuCommon proved raw32. Preserve original worker pointer,
; ordered owned stores and the genuine FarCallCommon final A-derived N/Z ABI.
.macro HuPolicyInput
 php
 sta ArTemp
 pla
 sta ArTempHi
 pha
 lda ArTemp
 plp
.endmacro
'''
 for name,body in dict(POLICIES.values()).items():
  wrappers+='HuLocal'+name+':\n HuPolicyInput\n '+body+'\n jmp HuPolicyReturn\n'
 wrappers+='''HuPolicyReturn:
 sta ArTemp
 php
 pla
 sta ArTempHi
 lda R1
 sta R1
 lda R0
 sta R0
 ; Preserve all final transport SMC values, including standalone public calls.
 lda #<ArDispatch
 sta FarcallJmpTarget_SMC+1
 lda #>ArDispatch
 sta FarcallJmpTarget_SMC+2
 lda #.lobyte(.bank(ArDispatch)|$80)
 sta NextBank_SMC+1
 lda ArTemp
 sta SafereturnA_SMC+1
 lda ArTempHi
 pha
 lda ArTemp
 plp
 ora #0
 rts
'''
 s=s.replace('\nHuEnd:\n','\n'+wrappers+'\nHuEnd:\n',1);p.write_text(s,newline='\n')
 p=O/'arthur/cache-wrapper.s';s=p.read_text();assert s.count('jsr ArCachePublish')==2;s=s.replace('jsr ArCachePublish','jsr ArCachePublishFast');s=s.replace('.import CurrentOAMOffset,GuestOamRotationActive,RgOamRotation','.import CurrentOAMOffset,GuestOamRotationActive,RgOamRotation\n.import CurrentCHRBank,X5ChrMode,X5WideChrActive,ReloadCHRBank');p.write_text(s,newline='\n')
 p=O/'arthur/cache-runtime.s';s=p.read_text();assert s.count(' jsr ArCacheBodyPublish')==1;s=s.replace(' jsr ArCacheBodyPublish',' sta SmChrBank\n ldy #0\n jsr ArCachePublishFast',1)
 anchor='ArCacheExecEnd:\n.assert ArCacheExecEnd-ArCacheEmit<=$11d,error,"Granted C2 emitter interval exceeded"';assert anchor in s
 publisher='''; Exact native X5SetPhysicalChr instructions execute in already verified C2.
; Preserve original ArCachePublish A/X/Y/P result, with no foreground bank trip.
.export ArCachePublishFast
ArCachePublishFast:
 pha
 ldx #3
 sta CurrentCHRBank,y
 txa
 and #3
 ora #$80
 sta X5ChrMode,y
 lda #1
 sta X5WideChrActive
 sta ReloadCHRBank
 pla
 rts
ArCacheExecEnd:
.assert ArCacheExecEnd-ArCacheEmit<=$2ea,error,"Own remaining3CHRpages runtime storage exceeded"'''
 s=s.replace(anchor,publisher,1);p.write_text(s,newline='\n')
 (O/'render-fast-plan.json').write_text(json.dumps(dict(parent_ROM_sha256=B.sha(OLD/'candidate.nes'),policy_rows={str(k):v[0]for k,v in POLICIES.items()},copy_true_worker_bodies=True,original_pointer_owned_store_order_and_final33SMC_preserved=True,all_actors_original_cache_data_and_priorities_retained=True,no_rotation_or_Shadow_option_change=True,publisher='Exact genuine X5SetPhysicalChr instruction body copied into selected C2 runtime with original ArCachePublish output contract.',owned_existing_allocation_only=True),indent=2)+'\n')
def main():
 if '--union-only'in sys.argv:
  proof=json.loads((O/'arthur-build-proof.json').read_text());commands=proof['commands'];logs=[]
  for cmd in[next(x['command']for x in commands if str(O/'arthur-union.s')in x['command']),commands[-1]['command']]:
   cp=B.subprocess.run(cmd,cwd=O/'frozen-inputs',capture_output=True,text=True);logs.append(dict(command=cmd,rc=cp.returncode,stdout=cp.stdout,stderr=cp.stderr));assert cp.returncode==0,cp.stderr
  sys.path.insert(0,str(R/'tools'));from prepare_cv3_dmc_mirror import prepare
  prepare(R,O/'candidate.nes');proof['commands']=[next((new for new in logs if new['command']==row['command']),row)for row in commands];proof['candidate_sha256']=B.sha(O/'candidate.nes');(O/'arthur-build-proof.json').write_text(json.dumps(proof,indent=2)+'\n');(O/'union-relink-log.json').write_text(json.dumps(logs,indent=2)+'\n');print(proof['candidate_sha256']);return
 if '--finalize'in sys.argv:
  W.O=O;W.A=O/'arthur';W.D=O/'dense';W.T=O/'frozen-inputs';W.main();return
 if '--resume'not in sys.argv:prepare()
 B.O=O;B.A=O/'arthur';B.D=O/'dense';B.T=O/'frozen-inputs';B.physical_config=lambda:None;B.build()
if __name__=='__main__':main()
