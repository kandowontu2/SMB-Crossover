"""ONE exact root-granted2846 smoke, with frozen pre/post source bindings."""
import hashlib,json,os,sys,zipfile
import arthur_render_fast_controls_v1 as F
A=F.A;O=F.O;R=F.R;N=O/'native/cold-render-smoke-v1'
assert not N.exists(),'Retain prior output; no automatic retry.'
prepared=O/'native-prepared-v1.json';p=json.loads(prepared.read_text())
assert A.sha(prepared)=='c720996118ddaf027130ffc6c010a63730d56e9b63b933024f21548f6d79bd58'
assert p['ROM_sha256']==A.sha(O/'candidate.nes')=='2846e48de17f087e3af5c9b17777c2cd0cdbe2d66f3f79a3a6878ed61b6ee724'
handoff=json.loads((O/'handoff.json').read_text());closure=json.loads((O/'source-closure.json').read_text())
def verify():
 for path,digest in p['bindings'].items():assert A.sha(path)==digest,(path,'prepared input changed')
 assert A.sha(O/'private-source-cpu.zip')==handoff['source_archive_sha256']and A.sha(O/'source-closure.json')==handoff['source_closure_sha256']
 with zipfile.ZipFile(O/'private-source-cpu.zip')as z:
  for path,digest in closure['files'].items():
   assert hashlib.sha256(z.read(path)).hexdigest()==digest,(path,'frozen source member changed')
   assert A.sha(R/path)==digest,(path,'source input changed since freeze')
verify();N.parent.mkdir(exist_ok=True)
meta=dict(passed=True,ROM_sha256=p['ROM_sha256'],prepared_sha256=A.sha(prepared),source_handoff_sha256=A.sha(O/'handoff.json'),source_archive_sha256=handoff['source_archive_sha256'],source_closure_sha256=handoff['source_closure_sha256'],source_members_verified=len(closure['files']),runner_sha256=A.sha(__file__),options=['--doNotSaveSettings','--nes.removeSpriteLimit=false','--nes.ramPowerOnState=AllZeros','--nes.randomizeCpuPpuAlignment=false','--nes.randomizeMapperPowerOnState=false'])
(O/'native-preflight-v1.json').write_text(json.dumps(meta,indent=2)+'\n')
os.environ['SMB_RUN_OUTPUT']=str(N.resolve());sys.path.insert(0,str(R/'tools'));from run_mesen import run
rc=run(O/'native-driver-v1.lua',O/'candidate.nes',timeout=40,emulator_options=meta['options'])
verify();(O/'native-postflight-v1.json').write_text(json.dumps(dict(**meta,exit_code=rc,all_prepared_and_frozen_source_bindings_unchanged=True),indent=2)+'\n')
print(json.dumps(dict(native_terminal=True,exit_code=rc,ROM_sha256=p['ROM_sha256'],output=str(N.resolve()),pre_post_bindings_pass=True)),flush=True)
raise SystemExit(rc)
