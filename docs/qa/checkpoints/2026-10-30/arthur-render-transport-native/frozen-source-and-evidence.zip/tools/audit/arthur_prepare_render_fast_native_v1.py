"""Bind the unchanged finite400gameframe controller smoke; never launch."""
from pathlib import Path
import json
import arthur_render_fast_controls_v1 as F
A=F.A;R=F.R;O=F.O
def main():
 out=O/'native-prepared-v1.json';assert not out.exists();h=A.sha(O/'candidate.nes');handoff=json.loads((O/'handoff.json').read_text());assert h==handoff['candidate_sha256']=='2846e48de17f087e3af5c9b17777c2cd0cdbe2d66f3f79a3a6878ed61b6ee724'
 b=A.scoped_load(O/'candidate.nes');size=int(b['syms']['GameLoop']['size'],0);stop=A.address(b,'GameLoop')+size-1;assert b['raw'][A.location(b,'GameLoop')+size-6:A.location(b,'GameLoop')+size]==bytes([169,0,141,A.address(b,'NmiDisable')&255,A.address(b,'NmiDisable')>>8,96])
 source=R/'build/arthur-host-cache-v1/cache-native-source-v2.lua';assert A.sha(source)=='4b732b7dba0c120481d2946d3f5f165491a8e35592ff5d588dfc8994344c7975';sig=json.loads((O/'cache-final-link-proof.json').read_text());driver=O/'native-driver-v1.lua'
 driver.write_text(f'ARTHUR_HOST_MAIN_EXIT={stop}\nARTHUR_HOST_ROM_SHA256="{h}"\nARTHUR_CACHE_CODE_SIZE={sig["emitter_bytes"]}\nARTHUR_CACHE_SIGNATURE={{{",".join(map(str,bytes.fromhex(sig["signature"])))}}}\ndofile([=[{source.as_posix()}]=])\n',newline='\n')
 p=dict(status='PREPARED_NOT_RUN_AWAITING_ROOT_REVIEW_AND_EXPLICIT_NATIVE_GRANT',ROM_sha256=h,base_Lua_and_all_controller_semantic_cache_visual_assertions_unchanged=True,physical_frame_bound=1200,controlled_game_frames=400,screenshot_bound=6,normal_eight_sprite_limit=True,script_RAM_writes=False,AllZeros=True,doNotSaveSettings=True,proposed_output=str((O/'native/cold-render-smoke-v1').resolve()),baseline=str((F.OLD/'native/cold-probe-smoke-v1').resolve()),actual_baseline_lag=216,actual_baseline_foreground_mean=23771.948,actual_baseline_foreground_max=33968,comparison_limit='Measure new native result; sourceCPU saving does not predict native cadence. OAMcrowding remains a declared unchanged negative.')
 p['bindings']={str(q.resolve()):A.sha(q)for q in[Path(__file__),source,driver,O/'candidate.nes',O/'candidate.dbg',O/'cache-final-link-proof.json',O/'handoff.json',O/'private-source-cpu.zip',R/'tools/run_mesen.py']};out.write_text(json.dumps(p,indent=2)+'\n');print(json.dumps(dict(status=p['status'],ROM_sha256=h,prepared_sha256=A.sha(out))))
if __name__=='__main__':main()
