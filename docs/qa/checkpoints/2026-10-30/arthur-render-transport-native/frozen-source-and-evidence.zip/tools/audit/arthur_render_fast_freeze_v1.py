"""Freeze source/CPU closure for the private measured render transport leaf."""
from pathlib import Path
import ast,json,re,zipfile
import arthur_render_fast_controls_v1 as F
A=F.A;R=F.R;O=F.O;OLD=F.OLD;T=O/'frozen-inputs'
def main():
 assert not(O/'handoff.json').exists();h=A.sha(O/'candidate.nes');names=['controls-v2.json','render-loader-controls-v2.json','host-regressions-v2.json','complete-commit-controls-v3.json','source-proof-v1.json'];checks={}
 for n in names:
  p=O/n;d=json.loads(p.read_text())
  if n=='host-regressions-v2.json':
   assert d['passed']is False and d['failure']=="AssertionError(('real body source publisher missing', 0, 1, 0))"and set(d['checks'])=={'seams','foreign','interrupts','pickups','powerup_chooser','lifecycle','portrait','presentation'}
  else:assert d['passed'],n
  for path,digest in d['bindings'].items():assert A.sha(path)==digest,(n,path,'stale source')
  assert d['bindings'][str((O/'candidate.nes').resolve())]==h;checks[n]=A.sha(p)
 files=set()
 for p in O.glob('*.d'):
  files.add(p.resolve())
  for line in p.read_text().splitlines():
   if '\t'not in line:continue
   for token in re.split(r'(?<!\\)\s+',line.split('\t',1)[1]):
    if token:
     q=Path(token.replace('\\ ',' '));q=q if q.is_absolute()else T/q;assert q.exists(),q;files.add(q.resolve())
 for folder in[O/'arthur',O/'dense',O/'src']:
  files.update(p.resolve()for p in folder.rglob('*')if p.is_file()and p.suffix in['.s','.inc','.cfg','.chr','.nam','.rle','.bin'])
 files.update(p.resolve()for p in O.iterdir()if p.is_file()and p.suffix in['.s','.inc','.cfg','.chr','.nam','.rle'])
 recipe=json.loads((O/'arthur-build-proof.json').read_text())['commands'];produced={Path(z['command'][z['command'].index('-o')+1]).resolve()for z in recipe[:-1]};inherited=[]
 for token in recipe[-1]['command']:
  p=Path(token)
  if p.suffix=='.o'and p.resolve()not in produced:files.add(p.resolve());inherited.append(dict(path=str(p.resolve()),sha256=A.sha(p)))
 tools=['arthur_host_render_fast_v1.py','arthur_render_fast_controls_v1.py','arthur_render_fast_regressions_v1.py','arthur_render_fast_regressions_v2.py','arthur_render_fast_commit_v1.py','arthur_render_fast_source_proof_v1.py','arthur_render_fast_freeze_v1.py'];pending=[R/'tools/audit'/n for n in tools];pending.append(R/'build/character-host-union-v5/gm_verify_nmi.py');seen=set()
 while pending:
  p=pending.pop().resolve()
  if p in seen:continue
  seen.add(p);files.add(p)
  for node in ast.walk(ast.parse(p.read_text())):
   modules=[v.name for v in node.names]if isinstance(node,ast.Import)else[node.module]if isinstance(node,ast.ImportFrom)and node.module else[]
   for module in modules:
    rel=Path(*module.split('.')).with_suffix('.py');q=next((folder/rel for folder in[p.parent,R/'tools/audit',R/'tools',R]if(folder/rel).is_file()),None)
    if q is not None:pending.append(q)
 for n in names+['controls-v1.json','render-loader-controls-v1.json','host-regressions-v1.json','negative-policy-entry-NZ.zip','negative-unexported-real-SMC-build.json','arthur-build-proof.json','arthur-build-log.json','union-relink-log.json','cache-final-link-proof.json','dense-parent-reproduction.json','parent-reproduction.json','parent-commands.json','render-fast-plan.json','candidate.cv3-mirror.json']:files.add((O/n).resolve())
 for p in[OLD/'handoff.json',OLD/'native-handoff-v1.json',R/'build/arthur-shadow-ownership-v2/handoff.json',R/'build/arthur-body-priority-plan-v1/audit.json',R/'build/arthur-dispatch-cost-v1/audit.json']:files.add(p.resolve())
 for n in['arthur-quick-private-allocation','arthur-ice-alias-allocation','arthur-nmi-gateway-allocation','parodius-dense-chr','mmc5-overlay-private-allocation']:files.add((R/'docs/qa/checkpoints/2026-10-30'/n/'root-review-and-reservations.json').resolve())
 closure=O/'source-closure.json';closure.write_text(json.dumps(dict(candidate_sha256=h,files={p.relative_to(R).as_posix():A.sha(p)for p in sorted(files)},inherited_objects=inherited),indent=2)+'\n');archive=O/'private-source-cpu.zip'
 with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
  for p in sorted(files):z.write(p,p.relative_to(R).as_posix())
  z.write(closure,closure.relative_to(R).as_posix())
 base=json.loads((O/'controls-v2.json').read_text());proof=json.loads((O/'source-proof-v1.json').read_text());host=json.loads((O/'host-regressions-v2.json').read_text());render=json.loads((O/'render-loader-controls-v2.json').read_text());commit=json.loads((O/'complete-commit-controls-v3.json').read_text())
 handoff=dict(status='PRIVATE_SOURCE_CPU_QUALIFIED_RENDER_TRANSPORT_NATIVE_PENDING',candidate_sha256=h,parent_ROM_sha256=A.sha(OLD/'candidate.nes'),source_archive_sha256=A.sha(archive),source_closure_sha256=A.sha(closure),source_archive_bytes=archive.stat().st_size,source_archive_members=len(files)+1,receipts=checks,policy_cases=base['checks']['policies']['cases'],policy_saved_cycles=base['checks']['policies']['saved_cycles'],publisher_cases=base['checks']['publisher']['cases'],publisher_cycles=dict(old=144,new=41),complete_Main_updates=192,complete_Main_saved_cycles=base['checks']['Main']['saved_cycles'],actual_original_RGB_alpha_priority_cases=render['checks']['pixels']['actual_cartridge_pose_area_cases'],actual_full_draw_OAM_cases=render['checks']['render']['cases']if'cases'in render['checks']['render']else render['checks']['render'],real_vector_cuts=host['checks']['seams']['actual_vector_cuts'],full_Main_then_actual_normal_lag_CHR_commits=commit['checks']['complete_Main_normal_lag_commits'],A26_main_used=proof['A26_main_used'],A26_main_reserved=2262,A79_union_used=proof['A79_union_used'],A79_union_reserved=2592,C2_runtime_bytes=313,own_CHR_storage_bytes=2639,own_CHR_storage_reserved=3072,foreign=host['checks']['foreign'],header_original_art_cache_data_and_original_source_workers_exact=True,actual_shadow_and_OAM_priority_behavior_unchanged=True,observer_supersession='Old complete-commit observer pinned ROM X5SetPhysicalChr entry and correctly failed once the true publisher moved. Separate successor pins genuine linked rawC2 STA CurrentCHRBank,Y and preserves all216 later player-bank/normal-NMI/lag-NMI checks. Prior negative retained.',limits=['No native run, cadence improvement or installation/admission claim for2846. Frozen528 remains actual216lag/400 baseline.','Actual completeMain source saving455..757cycles is bounded and below the earlierthousands target; further transport/render work remains.','Body/weapon/world OAM ordering unchanged: source ink ignores Shadows, but known17sprites/line crowding can hide body ink. Rotation0 remains held for fairness.','No newlease, shared source/Downloads modification, campaign/Hard/earned-upgrade/audio claim.','Compile missing real export, entry-N/Z semantic negative, cold-fixture setup contamination, invalid instruction-boundary seam and stale publisher observer negatives all retained.'])
 (O/'handoff.json').write_text(json.dumps(handoff,indent=2)+'\n');print(json.dumps({k:v for k,v in handoff.items()if k not in['receipts','foreign','limits','actual_full_draw_OAM_cases']}))
if __name__=='__main__':main()
