"""Add genuine producer revalidation beside the immutable coverage erratum."""
from pathlib import Path
import collections,hashlib,json,sys,zipfile
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import prepare_ff_joint_source_v1 as B
D=R/'docs/qa/checkpoints/2026-10-30/ff-epoch-coverage-revalidation'
N=R/'build/ff-fx-epoch-pre0-v1'


def save(p,d):
    p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8',newline='\n')


def main():
    assert not D.exists();D.mkdir(parents=True)
    correction=R/'docs/qa/checkpoints/2026-10-30/ff-epoch-coverage-correction/correction.json'
    assert B.sha(correction)=='0daf5bf9f687540f6c5bb85cb851b242c07650f3f05f4de504a49ab23aaa7d28'
    matrix=N/'epoch-controls-v5.json';p=json.loads(matrix.read_text());assert p['passed']
    rows=p['checks']['actual_DrawAll_pairs']['rows'];assert len(rows)==3072
    assert all(r['pose']==r['actual_pose'] for r in rows)
    sword=[r for r in rows if r['variant']in[0,3]and r['pose']>=6]
    assert sword and all(4 in r['present']for r in sword)
    assert set(r['chosen']for r in rows)==set(range(6))
    witness=R/'build/ff-fx-epoch-action-witness-v1/controls.json'
    w=json.loads(witness.read_text());assert w['passed']
    assert len(w['actual_action_rows'])==20
    files={Path(__file__),correction,matrix,witness,
        R/'tools/audit/ff_fx_epoch_action_witness_v1.py',R/'tools/audit/ff_fx_epoch_cart_controls_v5.py',
        R/'src/final_fantasy_render.s',R/'src/final_fantasy_weapons.s'}
    for receipt in[matrix,witness]:
        q=json.loads(receipt.read_text())
        for f,h in q['bindings'].items():assert B.sha(f)==h,f
    scenarios=sorted({(r['variant'],r['pose'],r['actual_pose'],r['source_action'],r['source_age'],
        tuple(tuple(e)for e in r['entries']))for r in rows})
    out=dict(status='ADDITIVE_REAL_PRODUCER_REVALIDATION',native=False,admitted=False,performance_HOLD=True,
        original_coverage_correction=dict(path=str(correction.relative_to(R)),sha256=B.sha(correction)),
        actual_cart=dict(path=str((N/'joint/candidate.nes').relative_to(R)),sha256=B.sha(N/'joint/candidate.nes')),
        finite_matrix=dict(path=str(matrix.relative_to(R)),sha256=B.sha(matrix),cases=len(rows),
            actual_pose_verified_after_genuine_FwHostGraphics=True,
            every_active_requested_entry_asserted_against_genuine_FwProjectileEntry=True,
            requested_and_actual_scenarios=scenarios,actual_sword_rows=len(sword),
            family_admission_counts=dict(sorted(collections.Counter(r['chosen']for r in rows).items())),
            all_Fighter_Thief_attack_rows_require_actual_family4_presence=True,
            dimensions='4 areas x both facings x both Shadows options x4 world fixtures x8 source scenarios x6 starting cursors',
            comparison='Completed original/native OAM against independent family/group filter; admitted source patterns, exact source palette vectors, body0/P0, worldP2/P3/backdrop, CHR, source state, AXYP/SP/R0..7 and native C output.'),
        independent_actual_action_witness=dict(path=str(witness.relative_to(R)),sha256=B.sha(witness),cases=20,
            actual_poses=[6,7,8,9,10],actual_ages=[0,6,12,18,24],both_melee_classes_and_Shadow_options=True),
        scope='Finite real-producer renderer CPU setups only. Actual matrix body poses are1/6; the separate20-action witness covers6..10. No claim of every animation, earned controller action, native frame deadline or campaign.',
        preserved_prior_evidence='The480/model and older3072 Draw receipts/archives remain unchanged under their explicit narrower observed scope. The pose-only negative remains retained; this supplement does not silently relabel them.',
        performance=dict(extra_DrawAll_CPU=[min(r['CPU_delta']for r in rows),max(r['CPU_delta']for r in rows)],
            largest_tested_DrawAll_CPU=max(r['new_CPU']for r in rows),qualification='HOLD'),
        bindings={str(f.resolve()):B.sha(f)for f in sorted(files)})
    save(D/'supplement.json',out)
    (D/'README.md').write_text('''This additive supplement revalidates the finite FF epoch renderer matrix.

The immutable earlier correction withdrew requested-sword coverage from the
480/model and older3072 Draw fixtures. Those files and archives stay unchanged.

The new3072-case CPU matrix supplies genuine action/age inputs, verifies actual
pose after FwHostGraphics, and verifies each requested projectile entry through
real FwProjectileEntry. Fighter/Thief attack cases require family4 presence.
All six families are actually admitted. The matrix covers actual body poses1/6;
the separate20-action witness proves both melee classes at poses6..10 and both
Shadows settings. This is finite renderer setup evidence, not earned actions or
an all-animation/campaign claim.

Completed OAM filtering, exact admitted source patterns/palettes, body0/world
state and normal-NMI commits pass. Performance remains HOLD: added DrawAll cost
4548..15465CPU, reaching50419CPU in the largest tested callback. No native run,
readiness, admission, installation or Git-index changes are made here.
''',encoding='utf-8',newline='\n')
    files|={D/'supplement.json',D/'README.md'}
    zpath=D/'source-evidence.zip'
    with zipfile.ZipFile(zpath,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
        for f in sorted(files):z.write(f,f.relative_to(R).as_posix())
    with zipfile.ZipFile(zpath)as z:
        for f in files:assert hashlib.sha256(z.read(f.relative_to(R).as_posix())).hexdigest()==B.sha(f)
    save(D/'archive-proof.json',dict(passed=True,source_only=True,members=len(files),
        archive_sha256=B.sha(zpath),bytes=zpath.stat().st_size,supplement_sha256=B.sha(D/'supplement.json'),
        no_NES_CHR_object_debug_or_executable=True))
    print(json.dumps(dict(path=str(D/'supplement.json'),sha256=B.sha(D/'supplement.json'),members=len(files),archive_bytes=zpath.stat().st_size)),flush=True)


if __name__=='__main__':main()
