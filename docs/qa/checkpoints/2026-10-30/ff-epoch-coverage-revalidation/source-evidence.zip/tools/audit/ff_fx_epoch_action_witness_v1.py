"""Retain pose-only fixture gap; use genuine action/age for actual sword OAM."""
from pathlib import Path
import itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import ff_fx_epoch_cart_controls_v4 as E
from check_tmnt_render_oa import address
H,L=E.H,E.L;N=E.N;H.O=N/'joint';O=R/'build/ff-fx-epoch-action-witness-v1'

def main():
    O.mkdir(exist_ok=False);p=dict(passed=False,native=False,admitted=False,checks={})
    try:
        b=H.C.qualified(N/'joint/candidate.nes');base=E.fresh(b,1);rows=[]
        for variant,off,age in itertools.product([0,3],[0,1],[0,6,12,18,24]):
            requested=6+age//6
            m=E.T.copy(base);H.put(m,FfAction=1,FfAge=age,FfHurt=0,Player_State=0)
            m,c,lo=E.frame(m,variant,requested,off,1,'empty',[],4)
            actual=H.get(m,'FfPose');assert actual==requested,(variant,off,age,actual,requested)
            family=H.get(m,'SmFreezeLastBlue')&7
            rows.append(dict(variant=variant,outlines_off=off,source_action=1,source_age=age,
                actual_pose=actual,chosen_family=family,sword_family_admitted=family==4,CPU=c.processorCycles))
        # Original pose-only setup is a real retained negative coverage witness.
        m,c,lo=E.frame(base,0,6,0,1,'empty',[],4)
        assert H.get(m,'FfAction')==0 and H.get(m,'FfPose')==1 and H.get(m,'SmFreezeLastBlue')&7!=4
        p.update(passed=True,actual_action_rows=rows,pose_only_fixture_gap=dict(requested_pose=6,
            actual_pose=H.get(m,'FfPose'),source_action=H.get(m,'FfAction'),actual_family=H.get(m,'SmFreezeLastBlue')&7),
            qualification_correction='Prior480/model and3072 Draw rows labeledrequested Sword pose did not test actualSword because graphics recomputespose. Preserve their narrowerbody/spell/world positives; withdraw actualSword coverage until realaction rows pass.',
            original_source_iterator576_sword_role_cases_unchanged=True)
    except Exception as e:p.update(error=repr(e),traceback=traceback.format_exc())
    files=[Path(__file__),Path(E.__file__),N/'source-closure.json',N/'joint/candidate.nes',N/'joint/candidate.dbg',R/'src/final_fantasy_render.s',
        R/'build/ff-fx-epoch-model-qualified-v1/handoff.json',R/'build/ff-fx-epoch-cart-v4/handoff-performance-hold-v1.json']
    p['bindings']={str(f.resolve()):L.sha(f)for f in files}
    out=O/('controls.json'if p['passed']else'negative.json');out.write_text(json.dumps(p,indent=2)+'\n',newline='\n')
    print(json.dumps(dict(passed=p['passed'],path=str(out),error=p.get('error'),rows=p.get('actual_action_rows'))),flush=True);assert p['passed']

if __name__=='__main__':main()
