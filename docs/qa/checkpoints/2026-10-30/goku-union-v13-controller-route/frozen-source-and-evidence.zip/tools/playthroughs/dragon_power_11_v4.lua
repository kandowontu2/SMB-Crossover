-- Controller-only native-elevator successor; v3 and its pipe stop stay frozen.
local root=assert(ROSTER_CONFIG.out:match('^(.*)/build/'))
local route=assert(dofile(root..'/tools/playthroughs/dragon_power_11_v3.lua'))
local departed=false
local hold=0
return function(c)
 local b=route(c)
 if c.world==0 and c.level==0 and not departed and c.x>=850 and c.x<945 then
  b={right=c.x<887}
  local tag=c.r('HpActorSlot')
  local slot=tag-1
  local supported=tag>=1 and tag<=6
  if supported then
   supported=c.r('HpActorOwner',slot)==0x83
    and c.r('Enemy_Flag',slot)==1 and c.r('Enemy_ID',slot)==0x25
    and c.r('Enemy_State',slot)==0x40
    and c.r('PlatformCollisionFlag',slot)<0x80
  end
  -- Wait for real native carry, then use an ordinary released-to-pressed A.
  if supported and c.r('DpAction')==1 and c.grounded and c.y<=144 and not c.lastA then
   b={right=true,a=true}
   hold=7
   departed=true
  end
 elseif departed and hold>0 then
  b={right=true,a=true}
  hold=hold-1
 end
 return b
end
