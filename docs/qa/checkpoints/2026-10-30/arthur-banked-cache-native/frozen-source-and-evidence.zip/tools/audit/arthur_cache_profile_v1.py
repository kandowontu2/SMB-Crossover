"""Matched legal Main CPU attribution; cache warm through actual loader."""
from pathlib import Path
import argparse,collections,json
import arthur_cache_host_controls_v1 as H
from verify_native_relocation import NesMPU
A=H.A;O=H.O
def run(b,cache):
 q=H.ready(b)[0]if cache else A.setup(b);ranges=[]
 for g in b['segs'].values():
  if 'ooffs'not in g or not int(g['size'],0):continue
  ranges.append(((int(g['ooffs'],0)-16)//8192,int(g['start'],0),int(g['start'],0)+int(g['size'],0),g['name'].strip('"')))
 names=['ArDispatch','ArHostMovement','ArHostGraphics','ArHostDraw','ArHostEnsure','ArCacheEnsure','ArCachePublish','ArHostAfterTerrain','ArHostShotContacts','ArStep','ArHostPoint','SamusFreezeDrawAll','DrawAllMetasprites','HuCommon','PlayerBGCollision','AudioUpdate']
 watch={A.point(b,n):n for n in names if n in b['syms']}
 if cache:watch[(2,A.address(b,'ArCacheEmit'))]='ArCacheEmit'
 orig=NesMPU.step;segments=collections.Counter();costs=collections.defaultdict(list);active=[];updates=[]
 def step(c):
  for e in active[:]:
   if c.sp==((e['SP']+2)&255)and c.pc==e['return']:costs[e['name']].append(c.processorCycles-e['CPU']);active.remove(e)
  pc=c.pc;bank=q.m.banks[(pc-0x8000)//8192]if pc>=0x8000 else -1;n=watch.get((bank,pc))
  if n:
   ret=q.m[256+((c.sp+1)&255)]|q.m[256+((c.sp+2)&255)]<<8;active.append(dict(name=n,SP=c.sp,CPU=c.processorCycles,**{'return':(ret+1)&65535}))
  owner='ARTHUR_CACHE_EXEC'if cache and 0xd800<=pc<0xd91c and q.m.rawtags[2]==2 else next((n for bk,lo,hi,n in ranges if bk==bank and lo<=pc<hi),'SMC/RAM'if pc<32768 else'UNATTRIBUTED')
  before=c.processorCycles;orig(c);segments[owner]+=c.processorCycles-before
 NesMPU.step=step
 try:
  for age in range(48):
   keys=1|(128 if age in[6,16]else 0)|(64 if age in[24,36]else 0);q.put(SavedJoypadBits=keys,SavedJoypad1Bits=keys,ArHostPad=keys,ArHostDue=int(age%3==0),NmiDisable=255,VRAM_Buffer1_Offset=0)
   c,_,_=A.call(q,'GameLoop');updates.append(c.processorCycles)
 finally:NesMPU.step=orig
 assert sum(segments.values())==sum(updates)
 return dict(updates=48,Main_cycles=dict(min=min(updates),max=max(updates),mean=sum(updates)/48),exclusive_segment_CPU=dict(segments.most_common()),inclusive_actual_return_costs={n:dict(calls=len(v),total=sum(v),min=min(v),max=max(v),mean=sum(v)/len(v))for n,v in sorted(costs.items(),key=lambda z:-sum(z[1]))})
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();assert not a.output.exists();b=A.scoped_load(O/'candidate.nes');old=A.scoped_load(H.OLD/'candidate.nes')
 d=dict(passed=True,native=False,old=run(old,False),cache=run(b,True),scope='Matched legal isolated input/world/source-clock phase. Exclusive segments sum exactly; named routines are inclusive and overlap. No emulated video cadence claim.')
 d['bindings']={str(p.resolve()):A.sha(p)for p in[Path(__file__),Path(H.__file__),O/'candidate.nes',O/'candidate.dbg',H.OLD/'candidate.nes',H.OLD/'candidate.dbg']};a.output.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(old=d['old']['Main_cycles'],cache=d['cache']['Main_cycles'])))
if __name__=='__main__':main()
