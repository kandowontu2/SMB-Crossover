; Actual linked C2 executable emitter. No code/cache writes during gameplay.
.export ArCacheEmit,ArCacheExecEnd,ArCacheShotPoses
.segment "ARTHUR_CACHE_EXEC"
ArCacheEmit:
 ldx ArHostOldPage
 lda ArCacheTablesLow,x
 sta R0
 lda ArCacheTablesHigh,x
 sta R0+1
 lda ArDrawRecord
 asl
 tay
 lda (R0),y
 pha
 iny
 lda (R0),y
 sta R0+1
 pla
 sta R0
 lda R0+1
 jeq EmitDone
 ldy #0
 lda (R0),y
 sta ArDrawCount
 iny
 lda (R0),y
 cmp #255
 beq NoBodyPublish
 jsr ArCacheBodyPublish
NoBodyPublish:
 ; All authenticated201views have relativeX -20..12, Y -34..7 and
 ; at most11parts. These conservative bounds prove no per-cell clipping
 ; or capacity branch is needed. Every edge/crowded case uses fallback.
 lda ArTempHi
 bne Clipped
 lda ArDrawX
 cmp #20
 bcc Clipped
 cmp #244
 bcs Clipped
 lda ArDrawY
 cmp #34
 bcc Clipped
 cmp #233
 bcs Clipped
 ldx CurrentOAMOffset
 cpx #209
 bcs Clipped
 lda GuestOamRotationActive
 beq FastBaseReady
 txa
 clc
 adc RgOamRotation
 tax
FastBaseReady:
 lda ArDrawCount
 asl
 asl
 adc CurrentOAMOffset
 sta CurrentOAMOffset
 ldy #2
FastPart:
 lda (R0),y
 clc
 adc ArDrawY
 sta $0200,x
 iny
 lda (R0),y
 sta $0201,x
 iny
 lda (R0),y
 sta $0202,x
 iny
 lda (R0),y
 clc
 adc ArDrawX
 sta $0203,x
 iny
 inx
 inx
 inx
 inx
 dec ArDrawCount
 bne FastPart
 rts
Clipped:
 ldy #2
EmitPart:
 lda (R0),y
 clc
 adc ArDrawY
 sta R4
 iny
 lda (R0),y
 sta ArDrawTile
 iny
 lda (R0),y
 sta ArDrawAttr
 iny
 lda (R0),y
 ldx #0
 cmp #128
 bcc PositiveX
 dex
PositiveX:
 stx R3
 clc
 adc ArDrawX
 sta R2
 lda R3
 adc ArTempHi
 bne NextPart
 lda R4
 cmp #240
 bcs NextPart
 ldx CurrentOAMOffset
 txa
 clc
 adc #4
 bcs NextPart
 sta CurrentOAMOffset
 lda GuestOamRotationActive
 beq Write
 txa
 clc
 adc RgOamRotation
 tax
Write:
 lda R4
 sta $0200,x
 lda ArDrawTile
 sta $0201,x
 lda ArDrawAttr
 sta $0202,x
 lda R2
 sta $0203,x
NextPart:
 iny
 dec ArDrawCount
 bne EmitPart
EmitDone:rts
ArCacheTablesLow:.byte <$c000,<$c094,<$c128
ArCacheTablesHigh:.byte >$c000,>$c094,>$c128
ArCacheShotPoses:
 .byte 54,55,56,57,64,65,66,67,68,69,79,86,102,160,161,162,169,170,248,249
ArCacheExecEnd:
.assert ArCacheExecEnd-ArCacheEmit<=$11d,error,"Granted C2 emitter interval exceeded"
