"""Prepare one passive exact-hash cache smoke; does not launch an emulator."""
from pathlib import Path
import hashlib,json,sys
R=Path(__file__).resolve().parents[2];O=R/'build/arthur-host-cache-v1'
sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
from check_tmnt_render_oa import address,location
from link_pit_rygar_sophia_audit_cpu import scoped_load
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
b=scoped_load(O/'candidate.nes');sz=int(b['syms']['GameLoop']['size'],0);exit=address(b,'GameLoop')+sz-1;assert b['raw'][location(b,'GameLoop')+sz-1]==96
base=R/'tools/audit/arthur_actual_host_smoke_v2.lua';text=base.read_text()
instrument=r'''
-- Passive actual loader/cache checks. No CPU/PPU/RAM writes from Lua.
local cacheRawA,cacheRawC=0,0
local cacheLoading=false
local cacheLoads,cacheEmits,cacheWrites=0,0,0
local cacheBeginCycle=0
local cacheLoadCPU=0
emu.addMemoryCallback(function(_,v)cacheRawA=v end,emu.callbackType.write,0x5115)
emu.addMemoryCallback(function(_,v)cacheRawC=v end,emu.callbackType.write,0x5116)
emu.addMemoryCallback(function()
 if cacheRawC~=0xc6 then return end
 assert(not cacheLoading,'No recursive cache load')
 assert(r('SelectedCharacter')==32 and r('DisableScreenFlag')~=0 and r('NmiDisable')&128~=0 and mask&24==0,'Actual cache construction is forced blank under Main owner')
 cacheLoading=true;cacheBeginCycle=cycles()
end,emu.callbackType.exec,L.ArCacheLoad)
emu.addMemoryCallback(function()
 if cacheRawC~=0xc6 then return end
 assert(cacheLoading and cacheRawA==2 and r('ArHostReady')==0 and mask&24==0,'Actual source stream maps rawA2 and hides partial source state')
end,emu.callbackType.exec,L.ArCacheStreamBegin)
emu.addMemoryCallback(function()
 if cacheRawC~=0xc6 then return end
 assert(cacheLoading and cacheRawA==2 and r('ArHostReady')==0 and mask&24==0,'Loader finish owns selected bank2 under blank')
 for i,v in ipairs(ARTHUR_CACHE_SIGNATURE)do assert(emu.read(0xbfe0+i-1,emu.memType.nesDebug)==v,'Actual verified full cache cookie '..i)end
 local function dump(name,start,count)
  local f=assert(io.open(OUTPUT..name,'wb'));for i=0,count-1 do f:write(string.char(emu.read(start+i,emu.memType.nesDebug)))end;f:close()
 end
 dump('actual-cache.bin',0xa000,6130);dump('actual-cache-code.bin',0xb800,ARTHUR_CACHE_CODE_SIZE);dump('actual-cache-cookie.bin',0xbfe0,16)
 cacheLoads=cacheLoads+1;cacheLoadCPU=cacheLoadCPU+cycles()-cacheBeginCycle;cacheLoading=false
end,emu.callbackType.exec,L.ArCacheStreamDone)
emu.addMemoryCallback(function()
 if cacheRawC~=2 then return end
 assert(not cacheLoading and cacheLoads==1,'Only a completed verified actual loader enables executable RAM')
 for i,v in ipairs(ARTHUR_CACHE_SIGNATURE)do assert(emu.read(0xdfe0+i-1,emu.memType.nesDebug)==v,'Runtime full cache fingerprint retained')end
 cacheEmits=cacheEmits+1
end,emu.callbackType.exec,L.ArCacheEmit)
local function selectedWrite(at,value,raw)
 if raw~=2 then return end
 cacheWrites=cacheWrites+1
 assert(cacheLoading or ((at&8191)==0x1fe0 and value==0),'No live cache/code write outside loading/own retirement')
end
emu.addMemoryCallback(function(at,v)selectedWrite(at,v,cacheRawA)end,emu.callbackType.write,0xa000,0xbfff)
emu.addMemoryCallback(function(at,v)selectedWrite(at,v,cacheRawC)end,emu.callbackType.write,0xc000,0xdfff)
local function cacheReceipt()
 assert(cacheLoads==1 and cacheEmits>50,'One cold loader and actual cached gameplay emitters observed')
 local f=assert(io.open(OUTPUT..'cache-native.json','w'))
 f:write(string.format('{"passed":true,"ROM_sha256":"%s","loader_calls":%d,"emitter_calls":%d,"selected_RAM_writes":%d,"inclusive_loader_cycles":%d,"script_RAM_writes":false,"scope":"One controller cold smoke; no owner alternation/campaign admission."}\n',ARTHUR_HOST_ROM_SHA256,cacheLoads,cacheEmits,cacheWrites,cacheLoadCPU));f:close()
end
'''
anchor="emu.addMemoryCallback(function(_,v)bankA=v&127 end,emu.callbackType.write,0x5115)";assert anchor in text;text=text.replace(anchor,instrument+'\n'+anchor,1)
anchor="   timingFile('timing.json')";assert anchor in text;text=text.replace(anchor,"   cacheReceipt()\n"+anchor,1)
source=O/'cache-native-source.lua';source.write_text(text,newline='\n')
proof=json.loads((O/'cache-final-link-proof.json').read_text());signature=bytes.fromhex(proof['signature'])
driver=O/'cache-native-driver.lua';driver.write_text(f'ARTHUR_HOST_MAIN_EXIT={exit}\nARTHUR_HOST_ROM_SHA256="{sha(O/"candidate.nes")}"\nARTHUR_CACHE_CODE_SIZE={proof["emitter_bytes"]}\nARTHUR_CACHE_SIGNATURE={{{",".join(map(str,signature))}}}\ndofile([=[{source.as_posix()}]=])\n',newline='\n')
(O/'cache-native-binding.json').write_text(json.dumps(dict(ROM_sha256=sha(O/'candidate.nes'),Main_exit=exit,driver=str(driver.resolve()),bindings={str(p.resolve()):sha(p)for p in[Path(__file__),base,source,driver,O/'candidate.dbg',O/'cache-final-link-proof.json']}),indent=2)+'\n')
print(json.dumps(dict(ROM_sha256=sha(O/'candidate.nes'),driver=str(driver))))
