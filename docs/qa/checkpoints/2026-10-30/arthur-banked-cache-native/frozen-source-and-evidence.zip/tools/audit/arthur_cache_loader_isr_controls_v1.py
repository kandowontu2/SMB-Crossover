"""Real source loader interrupted at raw-bank, PPU and validity seams."""
from pathlib import Path
import argparse,importlib.util,json,traceback
import arthur_cache_host_controls_v1 as H
A=H.A;R=H.R;O=H.O
from verify_native_relocation import NesMPU

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();assert not a.output.exists()
 b=A.scoped_load(O/'candidate.nes');d=dict(passed=False,native=False,checks={})
 spec=importlib.util.spec_from_file_location('cache_loader_nmi',R/'build/character-host-union-v5/gm_verify_nmi.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g)
 try:
  rows=[]
  # These are genuine source PCs, including stores with shadow/hardware
  # temporarily different. Lag NMI is the legal vector during forced blank.
  labels=['ArCacheCheckpoint','ArCacheStreamBegin','ArCacheLoad::CopyPart','ArCacheLoad::CopyCode','ArCacheLoad::Cookie','ArCacheStreamDone']
  for n in labels+['pending raw A2','pending restored raw A']:
   q=A.setup(b);q.put(DisableScreenFlag=1,Mirror_PPUMASK=0,Mirror_PPUCTRL=160,NmiDisable=255,VRAM_Buffer1_Offset=0,VRAM_Buffer_AddrCtrl=0)
   bank,pc=A.point(b,'ArCacheEnsure');q.m.page(1,bank);q.set('CurrentBank',bank|128)
   c=NesMPU(memory=q.m,pc=pc);c.sp=240;c.p=0x71;c.stPushWord(0x5aff);fired=False;row=None
   for _ in range(300000):
    if c.pc==0x5b00:break
    physical=q.m.banks[(c.pc-0x8000)//8192]if c.pc>=0x8000 else -1
    hit=(c.pc==A.address(b,n)and physical==70)if n in labels else bytes(q.m[c.pc:c.pc+3])==bytes.fromhex('8d1551')and q.m.rawtags[1]!=q.get('CurrentBank')and(q.get('CurrentBank')==2 if n=='pending raw A2'else q.m.rawtags[1]==2)
    if hit and not fired:
     before=(list(q.m.rawtags),list(q.m.chr_latches),q.m.upper,q.m.ppu_addr,q.m.toggle,q.m.buffer,bytes(q.m.ram[2]),q.get('ArHostReady'))
     z=g.checked_interrupt(q.m,c);assert all(q.m.rawtags[i]==(q.get('CurrentBank')if i==1 else q.get('CurrentBankC')if i==2 else before[0][i])for i in range(4))
     assert (list(q.m.chr_latches),q.m.upper,q.m.ppu_addr,q.m.toggle,q.m.buffer,bytes(q.m.ram[2]),q.get('ArHostReady'))==before[1:]
     row=dict(entry=n,raw_mapping_before=before[0],raw_mapping_after=list(q.m.rawtags),I_masked=bool(c.p&4),**g.scheduler.summary(z));fired=True
    assert q.m[c.pc]!=0,('BRK',n,hex(c.pc),physical);c.step()
   else:raise AssertionError(('loader timeout',n,hex(c.pc)))
   assert fired and c.p&1 and c.sp==240
   assert q.m.ram[2][0x1fe0]==167 and q.get('ArHostReady')==167
   assert q.m.rawtags[1]==bank|128 and q.m.rawtags[2]==q.get('CurrentBankC')
   rows.append(row)
  d['checks']['actual_loader_lag_NMI_seams']=rows
  d.update(passed=True,limits=['CPU model of real vector and MMC5/PPU buffered reads; native forced-blank visibility/cadence still pending.','IRQ is intentionally masked by loader PHP/SEI/PLP; no impossible IRQ is injected while I is set.','No actual Quick loader is present in this independent Arthur source parent; cross-family poisoning/retirement protocol is covered separately.'])
 except Exception as e:d.update(failure=repr(e),traceback=traceback.format_exc())
 d['bindings']={str(p.resolve()):A.sha(p)for p in[Path(__file__),Path(H.__file__),O/'candidate.nes',O/'candidate.dbg']};a.output.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(passed=d['passed'],failure=d.get('failure'))));assert d['passed']
if __name__=='__main__':main()
