"""Both real private loaders share selected physical RAM, separate source ROMs.

This proves the agreed cache ownership protocol; it is not a composed ROM or
native alternating-player qualification. No executable payload is preloaded.
"""
import argparse,json,traceback
from pathlib import Path
import arthur_cache_host_controls_v1 as H
import quickman_wram_host_controls_v4 as Q
A=H.A;R=H.R;O=H.O
# Quick's imported fixtures may install their own memory factory. Keep this
# Arthur constructor bound explicitly; each real loader retains its own bus.
H.ArenaModule.Memory=H.OverlayMemory

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();assert not a.output.exists()
 b=A.scoped_load(O/'candidate.nes');qh=Q.sha(Q.O/'candidate.nes');assert qh=='eed0ac40e6cffbf8877f504dfde2cc5c04c85f10038192a7d16d5c3bb24dfeaa'
 d=dict(passed=False,native=False,source_scope=__doc__,rows=[])
 try:
  shared=[bytearray([165])*8192 for _ in range(4)]
  for turn in range(6):
   quick=Q.Bus();quick.wram=shared;quick.set('SelectedCharacter',9);quick.set('FmAlts',32)
   global0=bytes(quick.ram[0x6000:0x8000]);result=Q.invoke(quick,'QwLoad');assert result['registers']['P']&1;Q.exact_cache(quick)
   assert bytes(quick.ram[0x6000:0x8000])==global0
   qsig=bytes(shared[2][0x1fe0:0x1ff0]);assert qsig[:4]==bytes([167,9,32,4])
   quick.set('SelectedCharacter',32);Q.invoke(quick,'QwRetire');assert shared[2][0x1fe0]==0
   q=A.setup(b);q.m.ram=shared;q.put(DisableScreenFlag=1,Mirror_PPUMASK=0,Mirror_PPUCTRL=160,NmiDisable=255)
   bank1=bytes(shared[1]);global0=bytes(q.m[0x6000:0x8000]);c,_,_=A.owned(q,'ArCacheEnsure');assert c.p&1
   assert bytes(shared[1])==bank1 and bytes(q.m[0x6000:0x8000])==global0
   asig=bytes(shared[2][0x1fe0:0x1ff0]);assert asig[:4]==bytes([167,32,0,1])
   expected=bytes.fromhex(json.loads((O/'cache-final-link-proof.json').read_text())['signature']);assert asig==expected
   # A stale Quick retirement callback is harmless after Arthur publishes.
   Q.invoke(quick,'QwRetire');assert bytes(shared[2][0x1fe0:0x1ff0])==asig
   reads=q.m.ppu_reads;warm,_,_=A.owned(q,'ArCacheEnsure');assert warm.p&1 and q.m.ppu_reads==reads
   A.owned(q,'ArCacheRetire');assert shared[2][0x1fe0]==0
   d['rows'].append(dict(turn=turn,Quick_loader_CPU=result['CPU'],Arthur_loader_CPU=c.processorCycles,Quick_cookie=qsig.hex(),Arthur_cookie=asig.hex(),global_RAM0_and_Quick_bank1_unchanged_by_Arthur=True))
  d.update(passed=True,actual_full_owner_loads=12,actual_retire_calls=18,no_payload_preload=True,limits=['Each loader executes its own exact source-linked private ROM with shared physical RAM1/2 arrays.','Unified loader routing, shared header adoption and native cold/warm owner changes remain pending.'])
 except Exception as e:d.update(failure=repr(e),traceback=traceback.format_exc())
 d['bindings']={str(p.resolve()):A.sha(p)for p in[Path(__file__),Path(H.__file__),Path(Q.__file__),O/'candidate.nes',O/'candidate.dbg',Q.O/'candidate.nes',Q.O/'candidate.dbg',Q.O/'code.bin',Q.O/'data.bin']}
 a.output.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(passed=d['passed'],failure=d.get('failure'),actual_full_owner_loads=d.get('actual_full_owner_loads'))));assert d['passed']
if __name__=='__main__':main()
