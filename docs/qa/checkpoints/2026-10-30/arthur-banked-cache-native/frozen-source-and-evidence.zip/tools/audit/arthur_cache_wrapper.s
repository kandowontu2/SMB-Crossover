; Actual selected-owner Arthur wrapper. Private32KB WRAM successor only.
.macpack longbranch
.include "native-context.inc"
.include "cache-signature.inc"
.import ArHostEnsure,ArHostPoint,X5SetPhysicalChr
.import SelectedCharacter,OperMode,CurrentBank,CurrentBankC,SmChrBank
.import DisableScreenFlag,Mirror_PPUMASK,NmiDisable
.import ArHostOldPage,ArHostReady,ArDrawIndex,ArDrawRecord,ArDrawX,ArDrawY,ArTempHi
.import ArDrawCount,ArDrawPart,ArDrawHeader,ArDrawTile,ArDrawAttr,ArDrawPtr,ArLayoutPtr,ArTemp
.import Mirror_PPUCTRL,X5PublishChr
.import CurrentOAMOffset,GuestOamRotationActive,RgOamRotation
.importzp GameEngineSubroutine,R0,R1,R2,R3,R4,R5
.export ArHostDraw,ArCacheEnsure,ArCacheRetire,ArCacheBodyPublish,ArHostPublish
AR_CACHE_VALID=$dfe0
AR_CACHE_FAMILY=$dfe1
AR_CACHE_VERSION=$dfe3
.segment "ARTHUR_DRAW"
.proc ArHostDraw
 lda SelectedCharacter
 cmp #32
 jne Return
 lda R0
 pha
 lda R1
 pha
 jsr ArHostEnsure
 lda CurrentBankC
 pha
 jsr ArCacheEnsure           ; all16 identity/fingerprint bytes before execution
 jcc Finished
 lda #2                      ; rawRAM tag, notROM $82
 sta CurrentBankC
 sta $5116
 lda OperMode
 beq BodyOnly
 lda GameEngineSubroutine
 cmp #8
 bcc BodyOnly
 lda ArHostOldPage
 beq WB6
 lda #111
 bne Common6
WB6:lda #109
Common6:
 ldy #6
 jsr ArCachePublish
 lda ArHostOldPage
 beq WB7
 lda #112
 bne Common7
WB7:lda #110
Common7:
 ldy #7
 jsr ArCachePublish
BodyOnly:
 lda #0
 sta ArDrawIndex
Slot:
 ldx ArDrawIndex
 lda ArR_04F0,x
 jpl Next
 jsr ArHostPoint
 lda R2
 sec
 sbc ArR_0064
 sta ArDrawX
 lda R3
 sbc ArR_0065
 sta ArTempHi
 lda R4
 sta ArDrawY
 lda R5
 bne Next
 lda ArR_0522,x
 cmp #54
 bcc Pose
 ldy #19
FindShot:
 cmp ArCacheShotPoses,y
 beq ShotFound
 dey
 bpl FindShot
 jmp Next
ShotFound:
 tya
 clc
 adc #54
Pose:
 sta ArDrawRecord
 jsr ArCacheEmit              ; genuine linked C2D800 execution address
Next:
 inc ArDrawIndex
 lda OperMode
 beq Finished
 lda GameEngineSubroutine
 cmp #8
 bcc Finished
 lda ArDrawIndex
 cmp #4
 jcc Slot
Finished:
 pla
 sta CurrentBankC
 sta $5116
 pla
 sta R1
 pla
 sta R0
Return:rts
.endproc
.proc ArCacheBodyPublish
 sta SmChrBank                ; complete native PlayerBankReady ABI
 ldy #0
 ; fall through
.endproc
.proc ArCachePublish
 pha
 lda CurrentBankC
 pha
 lda #.lobyte(.bank(ArHostPublish)|$80)
 sta CurrentBankC
 sta $5116
 tsx
 lda $0102,x
 ldx #3
 jsr ArHostPublish
 pla
 sta CurrentBankC
 sta $5116
 pla
 rts
.endproc

; Full cookie compared before activation. An active frame can only execute
; a cookie already verified in a legal forced-blank construction phase.
.proc ArCacheEnsure
 lda SelectedCharacter
 cmp #32
 jne Unavailable
 lda CurrentBankC
 pha
 lda #2
 sta CurrentBankC
 sta $5116
 .repeat 16,I
 lda AR_CACHE_VALID+I
 cmp #.ident(.concat("AR_CACHE_SIG",.string(I)))
 jne Invalid
 .endrepeat
 sec
 bcs Restore
Invalid:
 lda OperMode
 cmp #1
 bne NotBlank
 lda DisableScreenFlag
 beq NotBlank
 lda Mirror_PPUMASK
 and #$18
 bne NotBlank
 lda NmiDisable
 bpl NotBlank
 lda #.lobyte(.bank(ArCacheLoad)|$80)
 sta CurrentBankC
 sta $5116
 jsr ArCacheLoad
 jmp Restore
NotBlank:clc
Restore:
 pla
 sta CurrentBankC
 sta $5116
 rts
Unavailable:clc
 rts
.endproc

.segment "ARTHUR_PUBLISH"
.proc ArHostPublish
 pha
 lda CurrentBank
 pha
 lda #$be
 sta CurrentBank
 sta $5115
 tsx
 lda $0102,x
 ldx #3
 jsr X5SetPhysicalChr
 pla
 sta CurrentBank
 sta $5115
 pla
 rts
.endproc

.segment "ARTHUR_DRAW"
.proc ArCacheRetire
 lda SelectedCharacter
 cmp #32
 bne Done
 lda CurrentBankC
 pha
 lda #2
 sta CurrentBankC
 sta $5116
 lda AR_CACHE_VALID
 cmp #$a7
 bne Restore
 lda AR_CACHE_FAMILY
 cmp #32
 bne Restore
 lda #0
 sta AR_CACHE_VALID           ; never clear an already-Quick-owned cookie
Restore:
 pla
 sta CurrentBankC
 sta $5116
Done:rts
.endproc
