"""Freeze exact clean cache smoke and unchanged first400frame payloads."""
import hashlib,json,zipfile
from pathlib import Path
R=Path(__file__).resolve().parents[2];O=R/'build/arthur-host-cache-v1';P=O/'native/cold-cache-smoke-v1';N=O/'native/cold-cache-smoke-v2'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 assert not(O/'arthur-cache-handoff-v1.json').exists()
 cap=json.loads((N/'capture-budget.json').read_text());assert cap['returncode']==0 and not cap['violations']
 result=json.loads((N/'result.json').read_text());timing=json.loads((N/'timing.json').read_text());cache=json.loads((N/'cache-native.json').read_text());h=sha(O/'candidate.nes')
 assert result['passed']and cache['passed']and result['controlled_game_frames']==400 and timing['ROM_sha256']==cache['ROM_sha256']==h
 parity={}
 for p in P.iterdir():
  if not p.is_file()or p.suffix=='.log'or p.name=='capture-budget.json':continue
  q=N/p.name;assert q.exists()
  binary=p.read_bytes()==q.read_bytes()
  if not binary:assert p.suffix=='.json'and json.loads(p.read_text())==json.loads(q.read_text()),('actual first400frame output parity',p.name)
  parity[p.name]=dict(sha256=sha(q),comparison='byte_exact'if binary else'JSON_all_values_exact_key_serialization_order_only')
 proof=O/'cache-native-clean-parity-v1.json';proof.write_text(json.dumps(dict(passed=True,ROM_sha256=h,first_process_exit=1,corrected_process_exit=0,actual_output_pairs=len(parity),exact_outputs=parity,correction='Single return after emu.stop. All400frame payloads/screens/cache exact bytes; timing JSON unordered pairs serialize keys differently but every metric value exact.'),indent=2)+'\n')
 files=list(P.iterdir())+list(N.iterdir())+[proof,O/'cache-native-source.lua',O/'cache-native-source-v2.lua',O/'cache-native-driver.lua',O/'cache-native-driver-v2.lua',O/'cache-native-binding.json',O/'cache-native-binding-v2.json',O/'cache-native-preflight-v1.json',O/'cache-native-preflight-v2.json',O/'cache-native-negative-review-v1.json',O/'cache-matched-profile-v1.json']
 tools=['arthur_review_cache_native_v1.py','arthur_run_cache_native_v1.py','arthur_run_cache_native_v2.py','arthur_cache_native_closure_v1.py','arthur_cache_profile_v1.py']
 files +=[R/'tools/audit'/n for n in tools]
 archive=O/'cache-native-supplement-v1.zip';assert not archive.exists()
 with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
  for p in files:
   if p.is_file():z.write(p,p.relative_to(R).as_posix())
 ready=json.loads((O/'cache-source-ready-v1.json').read_text())
 handoff=dict(status='PRIVATE_CACHE_HOST_SMOKE_ONLY_PERFORMANCE_UNADMITTED',candidate_sha256=h,source_ready_sha256=sha(O/'cache-source-ready-v1.json'),source_archive_sha256=ready['source_archive_sha256'],native_supplement_sha256=sha(archive),native_process_exit=0,normal_8sprite_limit=True,doNotSaveSettings=True,controller_only=True,script_RAM_writes=False,physical_frames=result['frames'],controlled_game_frames=400,cache_payload_exact_bytes=6130,cache_executable_exact_bytes=284,cookie_exact_bytes=16,actual_source_double_jump_pixels=result['jump_pixels'],actual_source_lance_calls=result['source_lance_calls'],active_PPU_writes=result['active_ppu_writes'],lag_NMIs=timing['lag_NMIs'],foreground=timing['timing']['foreground'],normal_NMI=timing['timing']['normal_nmi'],lag_NMI=timing['timing']['lag_nmi'],actual_output_pairs_exact=len(parity),retained_negative='native/cold-cache-smoke-v1 exit1 cleanup fallthrough; all30first400frame output pairs exact after fixture-only return.',visual='Root and child reviewed visible genuine Arthur/world/HUD/lance. Source201RGB/opaque/priority cases exact.',limits=['217lagNMIs/400physical frames remains severe. No install/admission.','Original20Hzsource tick and authored64pxdoublejump unchanged.','Controller-earned upgrades/fiveweapons/campaign/Hard/sourceaudio still pending.','Native actual-source hotspot observer is the next work; no observer run claimed.'])
 (O/'arthur-cache-handoff-v1.json').write_text(json.dumps(handoff,indent=2)+'\n');print(json.dumps(handoff))
if __name__=='__main__':main()
