"""Bind actual cache source, resource bounds and CPU evidence for review."""
from pathlib import Path
import ast,hashlib,json,re,sys,zipfile
R=Path(__file__).resolve().parents[2];O=R/'build/arthur-host-cache-v1';T=O/'frozen-inputs'
sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
from link_pit_rygar_sophia_audit_cpu import scoped_load
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 h=sha(O/'candidate.nes');b=scoped_load(O/'candidate.nes');old=(R/'build/arthur-host-integration-v2/candidate.nes').read_bytes();assert b['raw'][10]==9 and old[10]==7
 receipt_names=['cache-controls-final-v1.json','cache-regressions-final-v1.json','cache-source-pixel-controls-final-v1.json','cache-loader-isr-v1.json','cache-ppu-restore-v1.json','joint-cache-alternation-v1.json']
 receipts={}
 for n in receipt_names:
  p=O/n;d=json.loads(p.read_text());assert d['passed'],n
  assert d['bindings'][str((O/'candidate.nes').resolve())]==h
  for path,digest in d['bindings'].items():assert sha(path)==digest,(n,'stale source dependency',path)
  receipts[n]=sha(p)
 segments=[]
 for g in b['segs'].values():
  if not g['name'].startswith('"ARTHUR_'):continue
  row=dict(name=g['name'].strip('"'),start=int(g['start'],0),bytes=int(g['size'],0))
  if 'ooffs'in g:row['file_offset']=int(g['ooffs'],0)
  segments.append(row)
 prg=sum(g['bytes']for g in segments if 'file_offset'in g and g['file_offset']<1048592);assert prg<=8500
 # Genuine exact source-linked input and runtime storage only in own pages.
 assert b['raw'][1048592+868*1024:1048592+881*1024]==old[1048592+868*1024:1048592+881*1024]
 changed_chr=sorted({i//1024 for i,(x,y)in enumerate(zip(old[1048592:],b['raw'][1048592:]))if x!=y});assert set(changed_chr)<=set(range(881,884))
 assert [i for i in range(16)if old[i]!=b['raw'][i]]==[10]
 controls=json.loads((O/'cache-controls-final-v1.json').read_text());rows=controls['checks']['render']['rows'];nominal=rows[:201]
 mean=lambda vals:sum(vals)/len(vals)
 perf=dict(actual_complete_Draw_nominal_cases=201,old_complete_Draw_mean=mean([r[7]for r in nominal]),new_complete_Draw_mean=mean([r[8]for r in nominal]),mean_saved_CPU=mean([r[7]-r[8]for r in nominal]),native_cadence_pending=True)
 files=set()
 for p in O.glob('*.d'):
  files.add(p.resolve())
  for line in p.read_text().splitlines():
   if '\t'not in line:continue
   for token in re.split(r'(?<!\\)\s+',line.split('\t',1)[1]):
    if token:
     q=Path(token.replace('\\ ',' '));q=q if q.is_absolute()else T/q;assert q.exists(),q;files.add(q.resolve())
 for folder in[O/'arthur',O/'dense',O/'src']:
  files.update(p.resolve()for p in folder.rglob('*')if p.is_file()and p.suffix in['.s','.inc','.cfg','.chr','.nam','.rle','.bin'])
 files.update(p.resolve()for p in O.iterdir()if p.is_file()and p.suffix in['.s','.inc','.cfg','.chr','.nam','.rle'])
 recipe=json.loads((O/'arthur-build-proof.json').read_text())['commands'];produced=set()
 for row in recipe[:-1]:
  cmd=row['command'];produced.add(Path(cmd[cmd.index('-o')+1]).resolve())
 inherited=[]
 for token in recipe[-1]['command']:
  p=Path(token)
  if p.suffix=='.o'and p.resolve()not in produced:files.add(p.resolve());inherited.append(dict(path=str(p.resolve()),sha256=sha(p)))
 tools=['arthur_host_cache_build_v1.py','arthur_cache_wrapper.s','arthur_cache_loader.s','arthur_cache_runtime.s','arthur_cache_host_controls_v1.py','arthur_cache_regression_controls_v1.py','arthur_cache_loader_isr_controls_v1.py','arthur_cache_ppu_restore_v1.py','arthur_quick_cache_alternation_v1.py','arthur_prepare_cache_native_v1.py','arthur_cache_source_ready_v1.py']
 files.update((R/'tools/audit'/n).resolve()for n in tools)
 pending=[R/'tools/audit'/n for n in tools if n.endswith('.py')];pending += [R/'build/character-host-union-v5/gm_verify_nmi.py',R/'tools/prepare_cv3_dmc_mirror.py']
 seen=set()
 while pending:
  p=pending.pop().resolve()
  if p in seen:continue
  seen.add(p);files.add(p)
  for node in ast.walk(ast.parse(p.read_text())):
   names=[v.name for v in node.names]if isinstance(node,ast.Import)else[node.module]if isinstance(node,ast.ImportFrom)and node.module else[]
   for name in names:
    rel=Path(*name.split('.')).with_suffix('.py');q=next((folder/rel for folder in[p.parent,R/'tools/audit',R/'tools',R]if(folder/rel).is_file()),None)
    if q is not None:pending.append(q)
 for n in receipt_names+['arthur-build-proof.json','arthur-build-log.json','cache-final-link-proof.json','dense-parent-reproduction.json','parent-reproduction.json','parent-commands.json','candidate.cv3-mirror.json','cache-native-source.lua','cache-native-driver.lua','cache-native-binding.json']:
  files.add((O/n).resolve())
 allocations=['arthur-quick-private-allocation','arthur-nmi-gateway-allocation','arthur-ice-alias-allocation','parodius-dense-chr','mmc5-overlay-private-allocation']
 files.update((R/'docs/qa/checkpoints/2026-10-30'/n/'root-review-and-reservations.json').resolve()for n in allocations)
 # Preserve both actual incomplete-cookie negative artifacts. Earlier visible
 # smoke/performance negatives are bound through their immutable parent packet.
 files.update((O/n).resolve()for n in['negative-incomplete-draw-cookie.nes','negative-incomplete-draw-cookie.dbg'])
 files.add((R/'build/arthur-host-integration-v2/arthur-handoff.json').resolve())
 manifest={str(p.relative_to(R)).replace('\\','/'):sha(p)for p in sorted(files)}
 closure=O/'cache-source-closure.json';closure.write_text(json.dumps(dict(status='PRIVATE_SOURCE_REVIEW_ONLY_NATIVE_PENDING',candidate_sha256=h,files=manifest,inherited_parent_objects=inherited),indent=2)+'\n')
 archive=O/'cache-private-source.zip'
 if archive.exists():assert False,'Do not overwrite a source snapshot; use a successor output.'
 with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
  for p in sorted(files):z.write(p,p.relative_to(R).as_posix())
  z.write(closure,closure.relative_to(R).as_posix())
 ready=dict(status='PRIVATE_SOURCE_READY_NATIVE_CACHE_AND_CADENCE_PENDING',candidate_sha256=h,source_archive_sha256=sha(archive),source_archive_bytes=archive.stat().st_size,source_archive_members=len(files)+1,source_closure_sha256=sha(closure),source_CPU_receipts=receipts,actual_PRG_bytes=prg,retained_PRG_reservation=8500,segments=segments,active_RAM=[0x5c00,0x5cb0],persistent_RAM=[0x5f90,0x5f98],temporal_selected_RAM2_cache=[0xc000,0xd7f2],temporal_selected_RAM2_code=[0xd800,0xd91c],shared_cookie=[0xdfe0,0xdff0],CHR_pages=[868,884],new_storage_pages=changed_chr,header_change=dict(byte=10,before=7,after=9,scope='Private32KB WRAM only; no shared header adoption.'),performance=perf,limits=['Native cache-loader/PPU visibility/cadence pending.','No campaign/earned upgrades/Hard/source audio admission.','Joint loader protocol uses both real ROMs against shared selected physical RAM; no unified ROM proof.','Ordinary source20Hz clock and authored second jump unchanged.','Earlier4fb11 visual smoke retains233lag/400frames as performance negative.'])
 (O/'cache-source-ready-v1.json').write_text(json.dumps(ready,indent=2)+'\n');print(json.dumps({k:v for k,v in ready.items()if k in['status','candidate_sha256','actual_PRG_bytes','source_archive_sha256','performance']}))
if __name__=='__main__':main()
