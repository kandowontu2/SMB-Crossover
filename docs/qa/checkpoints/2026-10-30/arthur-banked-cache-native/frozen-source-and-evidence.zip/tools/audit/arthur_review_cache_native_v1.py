"""Retain native semantic evidence and exact cleanup failure; prepare driver only."""
from pathlib import Path
import hashlib,json,sys
R=Path(__file__).resolve().parents[2];O=R/'build/arthur-host-cache-v1';N=O/'native/cold-cache-smoke-v1'
sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import arthur_cache_host_controls_v1 as H
A=H.A;sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 b=A.scoped_load(O/'candidate.nes');h=sha(O/'candidate.nes');result=json.loads((N/'result.json').read_text());timing=json.loads((N/'timing.json').read_text());cache=json.loads((N/'cache-native.json').read_text());cap=json.loads((N/'capture-budget.json').read_text())
 assert cap['returncode']==1 and not cap['violations']
 assert result['passed']and result['controlled_game_frames']==400 and timing['ROM_sha256']==h==cache['ROM_sha256']
 expected=H.D.expected_cache(A.scoped_load(H.OLD/'candidate.nes'))
 code=b['raw'][A.location(b,'ArCacheEmit'):A.location(b,'ArCacheExecEnd')];signature=bytes.fromhex(json.loads((O/'cache-final-link-proof.json').read_text())['signature'])
 assert (N/'actual-cache.bin').read_bytes()==expected and(N/'actual-cache-code.bin').read_bytes()==code and(N/'actual-cache-cookie.bin').read_bytes()==signature
 assert cache['loader_calls']==1 and cache['emitter_calls']>50 and result['active_ppu_writes']==0
 text=(O/'cache-native-source.lua').read_text();oldline=";emu.stop(0)";assert text.count(oldline)==1
 log=(N/'candidate-cache-native-driver.log').read_text();assert 'attempt to use a closed file'in log
 source=O/'cache-native-source-v2.lua';assert not source.exists(),'Preserve prepared retry fixture.'
 corrected=text.replace(oldline,oldline+';return',1);source.write_text(corrected,newline='\n')
 driver=O/'cache-native-driver-v2.lua';old=(O/'cache-native-driver.lua').read_text();driver.write_text(old.replace((O/'cache-native-source.lua').as_posix(),source.as_posix(),1),newline='\n')
 binding=dict(ROM_sha256=h,driver=str(driver.resolve()),product_bytes_unchanged=True,correction=dict(before='emu.stop(0)',after='emu.stop(0);return',meaning='Stop requests process termination but Lua can continue the current callback. Frame948 is divisible by6, so the logging tail ran after log:close. Explicit callback return preserves all400frame assertions and prevents the closed-file write.'),bindings={str(p.resolve()):sha(p)for p in[Path(__file__),O/'cache-native-source.lua',O/'cache-native-driver.lua',source,driver,O/'candidate.dbg',O/'cache-final-link-proof.json']})
 (O/'cache-native-binding-v2.json').write_text(json.dumps(binding,indent=2)+'\n')
 oldtiming=json.loads((H.OLD/'native/cold-smoke-v1/timing.json').read_text())
 review=dict(status='NATIVE_CACHE_AND_SEMANTICS_OBSERVED_FIXTURE_EXIT_FAILURE_CADENCE_FAILURE',overall_native_pass=False,ROM_sha256=h,process_exit=1,retained_first_failure='Closed frames.csv fallthrough at completed frame948; exact immutable Lua source line227.',actual_payload=dict(cache_bytes=len(expected),code_bytes=len(code),cookie_bytes=len(signature),all_bytes_exact=True,loader_calls=1,inclusive_loader_cycles=cache['inclusive_loader_cycles'],actual_RAM_emit_calls=cache['emitter_calls'],script_RAM_writes=False),semantic_result=result,timing=timing,comparison=dict(controlled_physical_frames=400,old_ROM_sha256=oldtiming['ROM_sha256'],lag_before=oldtiming['lag_NMIs'],lag_after=timing['lag_NMIs'],active_Main_before=oldtiming['timing']['foreground']['count'],active_Main_after=timing['timing']['foreground']['count'],exclusive_foreground_mean_before=oldtiming['timing']['foreground']['mean'],exclusive_foreground_mean_after=timing['timing']['foreground']['mean']),visual_review='Viewed actual game-controlled, double-jump and source-lance PNGs: coherent source Arthur/weapon, ARTHUR HUD, world and blue backdrop. All earlier visual/source palette controls retained.',retry_driver_prepared=str(driver.resolve()),retry_binding_sha256=sha(O/'cache-native-binding-v2.json'),limits=['No exit0 qualification; no automatic rerun.','217lag NMIs/400physical frames remains a severe performance blocker.','No campaign clear or controller-earned upgrades; no shared installation.'])
 review['bindings']={str(p.resolve()):sha(p)for p in[N/'result.json',N/'cache-native.json',N/'timing.json',N/'capture-budget.json',N/'candidate-cache-native-driver.log',N/'actual-cache.bin',N/'actual-cache-code.bin',N/'actual-cache-cookie.bin',O/'candidate.nes',O/'candidate.dbg',O/'cache-source-ready-v1.json',O/'cache-native-binding.json']+list(N.glob('*.png'))}
 (O/'cache-native-negative-review-v1.json').write_text(json.dumps(review,indent=2)+'\n');print(json.dumps({k:v for k,v in review.items()if k in['status','ROM_sha256','actual_payload','comparison','retry_binding_sha256']}))
if __name__=='__main__':main()
