"""Actual immutable publisher checkpoint vs final cache-loader PPU state."""
import argparse,json,traceback
from pathlib import Path
import arthur_cache_host_controls_v1 as H
A=H.A;O=H.O
from verify_native_relocation import NesMPU
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();assert not a.output.exists()
 b=A.scoped_load(O/'candidate.nes');d=dict(passed=False,native=False,rows=[])
 try:
  for wide,ctrl in[(w,c)for w in[0,1]for c in[128,132,160,164]]:
   q=A.setup(b);q.put(DisableScreenFlag=1,Mirror_PPUMASK=0,Mirror_PPUCTRL=ctrl,NmiDisable=255,X5WideChrActive=wide)
   for i in range(12):q.set('CurrentCHRBank',(11+37*i)&255,i);q.set('X5ChrMode',[0,128,129,130,131][i%5],i)
   before=[q.get('CurrentCHRBank',i)for i in range(12)]+[q.get('X5ChrMode',i)for i in range(12)]
   q.m.chr_latches=[913+i for i in range(12)];incoming=list(q.m.chr_latches);checkpoint=[];realstep=NesMPU.step
   def step(c):
    if c.pc==A.address(b,'ArCacheCheckpoint')and q.m.rawtags[2]==198:checkpoint.append((list(q.m.chr_latches),q.m.upper,q.m.lastset))
    realstep(c)
   NesMPU.step=step
   try:c,_,_=A.owned(q,'ArCacheEnsure')
   finally:NesMPU.step=realstep
   assert c.p&1 and len(checkpoint)==1
   assert (list(q.m.chr_latches),q.m.upper,q.m.lastset)==checkpoint[0],('all12actual physical latches/upper/lastset',wide,ctrl,checkpoint,q.m.chr_latches)
   after=[q.get('CurrentCHRBank',i)for i in range(12)]+[q.get('X5ChrMode',i)for i in range(12)]
   assert before==after and q.m.toggle==0 and q.m.ppuctrl==ctrl and q.m.ppu_log[-2:]==[(8197,0),(8197,0)]
   d['rows'].append(dict(wide=wide,original_PPUCTRL=ctrl,incoming_pending_hardware=incoming,completed_native_publisher_checkpoint=checkpoint[0],all12_physical_latches_and_upper_lastset_restored=True,software_CHR_cache_unchanged=True,source_2005_zero_pair_restored=True))
  d.update(passed=True,scope='Actual completed X5PublishChr checkpoint is the restoration contract. Arbitrary pending incoming hardware is normalized by this genuine native publisher before streaming; no false raw-entry equality claim. Native timing pending.')
 except Exception as e:d.update(failure=repr(e),traceback=traceback.format_exc())
 d['bindings']={str(p.resolve()):A.sha(p)for p in[Path(__file__),Path(H.__file__),O/'candidate.nes',O/'candidate.dbg']};a.output.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(passed=d['passed'],failure=d.get('failure'))));assert d['passed']
if __name__=='__main__':main()
