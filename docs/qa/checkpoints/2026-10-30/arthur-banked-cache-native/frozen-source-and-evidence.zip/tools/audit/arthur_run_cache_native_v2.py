"""One approved cleanup-only fixture retry on immutable3daf product."""
import hashlib,json,os,sys
from pathlib import Path
R=Path(__file__).resolve().parents[2];O=R/'build/arthur-host-cache-v1';N=O/'native/cold-cache-smoke-v2'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert not N.exists(),'Retain prior run; no automatic retries.'
ready=json.loads((O/'cache-source-ready-v1.json').read_text());h=sha(O/'candidate.nes');assert h==ready['candidate_sha256']=='3daf811f57ce62a2e9c44707c5359d9f54af038bdd80c652dab3ffca22eee644'
assert sha(O/'cache-private-source.zip')==ready['source_archive_sha256']
assert sha(O/'cache-source-closure.json')==ready['source_closure_sha256']
binding=json.loads((O/'cache-native-binding-v2.json').read_text());assert binding['ROM_sha256']==h
for p,digest in binding['bindings'].items():assert sha(p)==digest,(p,'fixture changed')
before=(O/'cache-native-source.lua').read_text();after=(O/'cache-native-source-v2.lua').read_text();assert before.replace(';emu.stop(0)',';emu.stop(0);return',1)==after
(O/'cache-native-preflight-v2.json').write_text(json.dumps(dict(passed=True,ROM_sha256=h,source_ready_sha256=sha(O/'cache-source-ready-v1.json'),native_binding_sha256=sha(O/'cache-native-binding-v2.json'),only_fixture_change='Return after terminal emu.stop; all semantic/controller checks unchanged.'),indent=2)+'\n')
os.environ['SMB_RUN_OUTPUT']=str(N.resolve());sys.path.insert(0,str(R/'tools'));from run_mesen import run
raise SystemExit(run(O/'cache-native-driver-v2.lua',O/'candidate.nes',timeout=40,emulator_options=['--doNotSaveSettings','--nes.removeSpriteLimit=false','--nes.ramPowerOnState=AllZeros','--nes.randomizeCpuPpuAlignment=false','--nes.randomizeMapperPowerOnState=false']))
