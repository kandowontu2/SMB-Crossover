"""Verify frozen private inputs, then run exactly one granted native smoke."""
import hashlib,json,os,sys,zipfile
from pathlib import Path
R=Path(__file__).resolve().parents[2];O=R/'build/arthur-host-cache-v1';N=O/'native/cold-cache-smoke-v1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert not N.exists(),'Retain previous native output; no automatic retry.'
ready=json.loads((O/'cache-source-ready-v1.json').read_text());h=sha(O/'candidate.nes');assert h==ready['candidate_sha256']=='3daf811f57ce62a2e9c44707c5359d9f54af038bdd80c652dab3ffca22eee644'
assert sha(O/'cache-private-source.zip')==ready['source_archive_sha256']
assert sha(O/'cache-source-closure.json')==ready['source_closure_sha256']
with zipfile.ZipFile(O/'cache-private-source.zip')as z:
 for path,digest in json.loads((O/'cache-source-closure.json').read_text())['files'].items():
  assert hashlib.sha256(z.read(path)).hexdigest()==digest,(path,'archived member changed')
binding=json.loads((O/'cache-native-binding.json').read_text());assert binding['ROM_sha256']==h
for p,digest in binding['bindings'].items():assert sha(p)==digest,(p,'native source changed')
N.parent.mkdir(exist_ok=True);(O/'cache-native-preflight-v1.json').write_text(json.dumps(dict(passed=True,ROM_sha256=h,verified_source_archive=ready['source_archive_sha256'],native_binding_sha256=sha(O/'cache-native-binding.json'),source_members=ready['source_archive_members']),indent=2)+'\n')
os.environ['SMB_RUN_OUTPUT']=str(N.resolve());sys.path.insert(0,str(R/'tools'));from run_mesen import run
raise SystemExit(run(O/'cache-native-driver.lua',O/'candidate.nes',timeout=40,emulator_options=['--doNotSaveSettings','--nes.removeSpriteLimit=false','--nes.ramPowerOnState=AllZeros','--nes.randomizeCpuPpuAlignment=false','--nes.randomizeMapperPowerOnState=false']))
