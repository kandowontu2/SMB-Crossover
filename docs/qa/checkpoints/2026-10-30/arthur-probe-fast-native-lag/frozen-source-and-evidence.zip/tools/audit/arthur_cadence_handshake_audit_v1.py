"""Read-only native trace histogram and exact frame-publication source audit."""
from pathlib import Path
import collections,csv,json,re
import arthur_probe_fast_controls_v1 as C
A=C.A;R=C.R;O=R/'build/arthur-cadence-handshake-v1';AR=C.O
def histogram(rows,column):
 previous=int(rows[0][column]);counts=collections.Counter();cross=collections.Counter();total=0
 for row in rows[1:]:
  now=int(row[column]);delta=now-previous;assert 0<=delta<=3;counts[delta]+=1;total+=delta;previous=now
 return dict(video_intervals=len(rows)-1,completion_histogram=dict(sorted(counts.items())),observed_completions=total)
def main():
 O.mkdir(exist_ok=True);out=O/'audit.json';assert not out.exists();b=A.scoped_load(AR/'candidate.nes');p=R/'build/full-roster-menu-v5/candidate.nes';bill=A.scoped_load(p)
 functions={}
 for n in['IdleLoop','GameLoop']:
  size=int(b['syms'][n]['size'],0);bs=int(bill['syms'][n]['size'],0);x=b['raw'][A.location(b,n):A.location(b,n)+size];y=bill['raw'][A.location(bill,n):A.location(bill,n)+bs]
  functions[n]=dict(Arthur_address=A.address(b,n),Bill_address=A.address(bill,n),Arthur_bytes=size,Bill_bytes=bs,byte_exact=x==y,Arthur_sha256=__import__('hashlib').sha256(x).hexdigest(),Bill_sha256=__import__('hashlib').sha256(y).hexdigest())
  assert x==y,('Handshake source differs from normal Bill parent',n)
 end=A.location(b,'GameLoop')+int(b['syms']['GameLoop']['size'],0);suffix=b['raw'][end-6:end];assert suffix==bytes([169,0,141,A.address(b,'NmiDisable')&255,A.address(b,'NmiDisable')>>8,96])
 trace=R/'build/arthur-cache-native-profile-v2/native/profile-frames.csv';rows=list(csv.DictReader(trace.open()));assert len(rows)==301
 ar_hist=histogram(rows,'Main');lag=sum((int(z['NmiSkipped'])-int(x['NmiSkipped']))&255 for x,z in zip(rows,rows[1:]));draws=int(rows[-1]['Draw'])-int(rows[0]['Draw']);steps=int(rows[-1]['ArStep'])-int(rows[0]['ArStep'])
 joint=collections.Counter()
 for x,z in zip(rows,rows[1:]):joint[(int(z['Main'])-int(x['Main']),int(z['Draw'])-int(x['Draw']),(int(z['NmiSkipped'])-int(x['NmiSkipped']))&255)]+=1
 ar_hist.update(ROM_sha256='3daf811f57ce62a2e9c44707c5359d9f54af038bdd80c652dab3ffca22eee644',physical_frame_endpoints=[600,900],draw_completions=draws,source_steps=steps,lag_counter_increment=lag,joint_Main_Draw_Lag_histogram=[dict(Main=k[0],Draw=k[1],Lag=k[2],frames=n)for k,n in sorted(joint.items())],scope='Existing actual301row profile covers300physical intervals, not all400frames of5284. Two selected-window Main spans finish after frame900; do not invent missing observations.')
 bp=R/'build/rogue-current-menu-v6/native/bill-parent-v1';br=list(csv.DictReader((bp/'trace.csv').open()));br=[q for q in br if q['phase']=='game'and int(q['age'])>0];assert len(br)==300
 prev=0;bh=collections.Counter()
 for row in br:now=int(row['main_updates']);bh[now-prev]+=1;prev=now
 bresult=json.loads((bp/'result.json').read_text());assert prev==bresult['main_updates']
 private_writers=[]
 for path in(AR/'arthur').glob('*.s'):
  for i,line in enumerate(path.read_text().splitlines(),1):
   if re.search(r'\b(?:sta|stx|sty|stz|inc|dec)\s+(?:NmiDisable|ShouldSkipDrawSprites|FramesSinceLastSpriteDraw)\b',line,re.I):private_writers.append([str(path),i,line])
 assert private_writers==[]
 d=dict(status='SOURCE_AND_EXISTING_NATIVE_CADENCE_AUDIT_NO_NEW_NATIVE',ROM_sha256=A.sha(AR/'candidate.nes'),shared_IdleLoop_GameLoop_exact_to_Bill_parent=functions,actual_GameLoop_always_finishes_LDA0_STA_NmiDisable_RTS=True,Arthur_private_writes_to_native_pacing_flags=private_writers,Arthur_existing_native_histogram=ar_hist,Bill_parent_control=dict(ROM_sha256=bresult['ROM_sha256'],physical_game_frames=300,Main_completions=prev,completion_histogram=dict(sorted(bh.items())),lag_NMIs=bresult['timing']['lag_nmi'],scope='Different Bill input/physics scenario used as normal handshake control; not a matched Arthur performance comparison.'),source_contract=[
 'Normal NMI seesNmiDisable0 thenDEC→FF; lagNMI seesbit7set, incrementsNmiSkipped, retains previous OAM/CHR and ticks audio/source clock.',
 'GameLoop beginsFF and every normal/paused completion stores0 atPauseSkip before its actual finalRTS. Native completion hook is after that store.',
 'IdleLoop detects changedNmiSkipped across one Main, callsTerrainCatchupPending; except pending secondary VRAM packet6, it setsShouldSkipDrawSprites1 and performs ONE immediate catch-up Main.',
 'Catch-up Main intentionally skips DrawAllMetasprites unless13updates since lastdraw. GameCore clearsShouldSkipDrawSprites after the draw decision; IdleLoop clears it again aftercatchup. Therefore endFrame skip0 does not mean no skipped Main.',
 'The immediate catch-up setsNmiDisableFF again before NMI can publish the normal completed frame; publication waits until catch-up completes. This is the shared native pacing policy, byte-exact to Bill control.',
 'Arthur20Hz clock sets onlyArHostDue/Phase/Pad; ArHostDraw is not gated byArHostDue. Source134ticks/400frames differs from184draws and cannot explain the half-rate rendering as intentional20Hz art.',
 'Observed3daf mostly0-or2Main completions, with about one draw perpair, supports genuine overrun plus shared draw-skipping catchup. No private missingcompletion store is present. Exact400frame5284 event histogram still requires a passive granted capture.'
 ])
 d['bindings']={str(q.resolve()):A.sha(q)for q in[Path(__file__),AR/'candidate.nes',AR/'candidate.dbg',p,p.with_suffix('.dbg'),C.OLD/'src/arthur_game.s',C.OLD/'src/reset.s',C.OLD/'frozen-inputs/src/terrain_catchup.s',AR/'arthur/host-state.s',AR/'arthur/cache-wrapper.s',trace,bp/'trace.csv',bp/'result.json',bp/'binding.json']};out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items()if k in['status','shared_IdleLoop_GameLoop_exact_to_Bill_parent','Arthur_existing_native_histogram','Bill_parent_control']}))
if __name__=='__main__':main()
