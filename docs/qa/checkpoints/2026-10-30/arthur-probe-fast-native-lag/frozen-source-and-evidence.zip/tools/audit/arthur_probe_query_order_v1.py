"""Compare actual source metatile loads and all33 final SMC bytes."""
from pathlib import Path
import json
import arthur_probe_fast_controls_v1 as C
from verify_native_relocation import NesMPU
import arthur_cache_regression_controls_v1 as G
A=C.A;R=C.R;O=C.O;OLD=C.OLD
def main():
 out=O/'query-order-controls-v1.json';assert not out.exists();old=A.scoped_load(OLD/'candidate.nes');new=A.scoped_load(O/'candidate.nes');qs=[C.prepare(v)for v in[old,new]];rows=[]
 for age in range(72):
  pair=[]
  for b,q in zip([old,new],qs):
   loads=[];real=NesMPU.step;lo=A.address(b,'BodyProbe');hi=lo+int(b['syms']['BodyProbe']['size'],0)
   def step(c):
    if lo<=c.pc<hi and q.m.rawtags[1]==154 and q.m[c.pc]==177 and q.m[c.pc+1]==A.address(b,'R6'):
     ptr=q.get('R6')+256*q.get('R7');at=(ptr+c.y)&65535;loads.append([at,q.m[at],c.y,q.get('R5'),q.get('R2')])
    real(c)
   NesMPU.step=step
   try:
    keys=(1 if age<36 else 2)|(128 if age in[6,16,42,52]else 0)|(64 if age in[24,60]else 0)
    q.put(SavedJoypadBits=keys,SavedJoypad1Bits=keys,ArHostPad=keys,ArHostDue=int(age%3==0),NmiDisable=255,VRAM_Buffer1_Offset=0);c,tr,mn=A.call(q,'GameLoop')
   finally:NesMPU.step=real
   pair.append((loads,bytes(q.m[0x15a:0x17b]),q.m.rawtags[:],c.processorCycles))
  assert pair[0][:3]==pair[1][:3],('native metatile query order/all33 finalSMC/rawbanks',age,pair)
  assert len(pair[0][0])>=4
  rows.append(dict(age=age,metatile_queries=pair[0][0],all33_final_SMC_exact=True,old_CPU=pair[0][3],new_CPU=pair[1][3]))
 d=dict(passed=True,native=False,actual_complete_Main_updates=72,actual_metatile_queries=sum(len(r['metatile_queries'])for r in rows),rows=rows,all_source_query_addresses_values_order_and_final33SMC_exact=True,bindings={str(p.resolve()):A.sha(p)for p in[Path(__file__),Path(C.__file__),OLD/'candidate.nes',OLD/'candidate.dbg',O/'candidate.nes',O/'candidate.dbg']});out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items()if k not in['rows','bindings']}))
if __name__=='__main__':main()
