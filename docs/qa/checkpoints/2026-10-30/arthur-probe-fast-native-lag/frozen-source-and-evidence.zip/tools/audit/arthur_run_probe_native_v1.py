"""One root-granted exact source-bound focused probe native smoke."""
import json,os,sys,zipfile,hashlib
import arthur_probe_fast_controls_v1 as C
A=C.A;O=C.O;R=C.R;N=O/'native/cold-probe-smoke-v1'
assert not N.exists(),'Retain prior runs; no automatic retry.'
p=json.loads((O/'native-prepared-v1.json').read_text());assert p['ROM_sha256']==A.sha(O/'candidate.nes')=='52841a18a697a06d95bbbc028d510ec536d154a441391e9a928395b66fb3f4ef'
for path,digest in p['bindings'].items():assert A.sha(path)==digest,(path,'prepared input changed')
handoff=json.loads((O/'handoff.json').read_text());assert A.sha(O/'private-source-cpu.zip')==handoff['source_archive_sha256']and A.sha(O/'source-closure.json')==handoff['source_closure_sha256']
with zipfile.ZipFile(O/'private-source-cpu.zip')as z:
 for path,digest in json.loads((O/'source-closure.json').read_text())['files'].items():assert hashlib.sha256(z.read(path)).hexdigest()==digest,(path,'source member changed')
N.parent.mkdir(exist_ok=True);(O/'native-preflight-v1.json').write_text(json.dumps(dict(passed=True,ROM_sha256=p['ROM_sha256'],prepared_binding_sha256=A.sha(O/'native-prepared-v1.json'),source_handoff_sha256=A.sha(O/'handoff.json'),source_archive_sha256=handoff['source_archive_sha256']),indent=2)+'\n')
os.environ['SMB_RUN_OUTPUT']=str(N.resolve());sys.path.insert(0,str(R/'tools'));from run_mesen import run
raise SystemExit(run(O/'native-driver-v1.lua',O/'candidate.nes',timeout=40,emulator_options=['--doNotSaveSettings','--nes.removeSpriteLimit=false','--nes.ramPowerOnState=AllZeros','--nes.randomizeCpuPpuAlignment=false','--nes.randomizeMapperPowerOnState=false']))
