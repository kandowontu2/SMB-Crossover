"""Prepare unchanged400gameplay assertions for focused probe successor."""
from pathlib import Path
import json
import arthur_probe_fast_controls_v1 as C
A=C.A;R=C.R;O=C.O;OLD=C.OLD
def main():
 assert not(O/'native-prepared-v1.json').exists();handoff=json.loads((O/'handoff.json').read_text());h=A.sha(O/'candidate.nes');assert h==handoff['candidate_sha256']
 b=A.scoped_load(O/'candidate.nes');size=int(b['syms']['GameLoop']['size'],0);exit=A.address(b,'GameLoop')+size-1;assert b['raw'][A.location(b,'GameLoop')+size-1]==96
 source=OLD/'cache-native-source-v2.lua';sig=json.loads((O/'cache-final-link-proof.json').read_text());driver=O/'native-driver-v1.lua'
 driver.write_text(f'ARTHUR_HOST_MAIN_EXIT={exit}\nARTHUR_HOST_ROM_SHA256="{h}"\nARTHUR_CACHE_CODE_SIZE={sig["emitter_bytes"]}\nARTHUR_CACHE_SIGNATURE={{{",".join(map(str,bytes.fromhex(sig["signature"])))}}}\ndofile([=[{source.as_posix()}]=])\n',newline='\n')
 proof=dict(status='PREPARED_NOT_RUN_AWAITING_ROOT_REVIEW_AND_NATIVE_GRANT',ROM_sha256=h,base_Lua_source_unchanged=True,controller_inputs_and_all400frame_cache_visual_assertions_unchanged=True,physical_frame_bound=1200,controlled_game_frames=400,screenshot_bound=6,normal_8sprite_limit=True,script_RAM_writes=False,doNotSaveSettings=True,driver=str(driver.resolve()),proposed_output=str((O/'native/cold-probe-smoke-v1').resolve()),bindings={str(p.resolve()):A.sha(p)for p in[Path(__file__),source,driver,O/'candidate.nes',O/'candidate.dbg',O/'cache-final-link-proof.json',O/'handoff.json',O/'private-source-cpu.zip']})
 (O/'native-prepared-v1.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(dict(status=proof['status'],ROM_sha256=h,driver=str(driver))))
if __name__=='__main__':main()
