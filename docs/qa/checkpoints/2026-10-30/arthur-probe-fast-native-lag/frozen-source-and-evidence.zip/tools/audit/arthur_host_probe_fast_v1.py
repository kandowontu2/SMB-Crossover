"""New private leaf: direct selected-owner source probes, no physics rewrite."""
from pathlib import Path
import json,shutil,sys
import arthur_host_cache_build_v1 as W
import arthur_integrate_host_v1 as B
R=Path(__file__).resolve().parents[2];OLD=R/'build/arthur-host-cache-v1';O=R/'build/arthur-host-probe-fast-v1'
BRIDGE='''
; Private target: ingress ONLY from HuCommon's proven raw32 probe row or
; HuArthurFeetGate's raw32 branch. Original source probes preserve R0/R1 and
; do not access C63. Retain identical owned scratch writes/output flags.
.segment "ARTHUR_DRAW"
.export ArProbeDispatch
.proc ArProbeDispatch
 php
 sta ArTemp
 pla
 sta ArTempHi
 jsr Invoke
 sta ArTemp
 php
 pla
 sta ArTempHi
 lda R1
 sta R1
 lda R0
 sta R0
 lda ArTempHi
 pha
 lda ArTemp
 plp
 rts
Invoke:jmp (ArDrawPtr)
.endproc
'''
def prepare():
 assert B.sha(OLD/'candidate.nes')=='3daf811f57ce62a2e9c44707c5359d9f54af038bdd80c652dab3ffca22eee644';assert not O.exists();O.mkdir()
 for name in['frozen-inputs','src','dense','arthur']:shutil.copytree(OLD/name,O/name)
 for p in OLD.iterdir():
  if p.is_file()and(p.suffix in['.s','.inc','.cfg','.chr','.nam','.rle','.o','.d']or p.name in['parent-commands.json','parent-reproduction.json','dense-parent-reproduction.json','arthur-build-proof.json']):shutil.copy2(p,O/p.name)
 for p in O.rglob('*'):
  if p.is_file()and p.suffix in['.s','.inc','.cfg','.d','.json']:
   s=p.read_text()
   for old,new in[(str(OLD),str(O)),(OLD.as_posix(),O.as_posix()),(str(OLD).replace('\\','\\\\'),str(O).replace('\\','\\\\'))]:s=s.replace(old,new)
   p.write_text(s,newline='\n')
 (O/'arthur/host-adapter.s').write_text((O/'arthur/host-adapter.s').read_text()+BRIDGE,newline='\n')
 p=O/'arthur-union.s';s=p.read_text();s='.import ArProbeDispatch\n'+s
 anchor=' sta ArDrawPtr+1\n lda #<ArDispatch\n sta FarcallJmpTarget_SMC+1\n lda #>ArDispatch\n sta FarcallJmpTarget_SMC+2\n lda #.lobyte(.bank(ArDispatch)|$80)'
 assert s.count(anchor)==1
 replacement=''' sta ArDrawPtr+1
 lda HuArthurDirectProbe,y
 beq Generic
 lda ArDrawPtr
 sta FarcallJmpTarget_SMC+1
 lda ArDrawPtr+1
 sta FarcallJmpTarget_SMC+2
 lda #<ArProbeDispatch
 sta FarcallJmpTarget_SMC+1
 lda #>ArProbeDispatch
 sta FarcallJmpTarget_SMC+2
 lda #.lobyte(.bank(ArProbeDispatch)|$80)
 sta NextBank_SMC+1
 jmp RestoreCaller
Generic:
 lda #<ArDispatch
 sta FarcallJmpTarget_SMC+1
 lda #>ArDispatch
 sta FarcallJmpTarget_SMC+2
 lda #.lobyte(.bank(ArDispatch)|$80)'''
 # ArDrawPtr remains the genuine source worker; the ordinary mapper gate
 # enters the small same-A26 output-preserving adapter directly.
 replacement=replacement.replace(' lda ArDrawPtr\n sta FarcallJmpTarget_SMC+1\n lda ArDrawPtr+1\n sta FarcallJmpTarget_SMC+2\n','',1)
 s=s.replace(anchor,replacement,1)
 rows=[1 if i in[10,14,16]else 0 for i in range(36)]
 s=s.replace('HuArthurLo:','HuArthurDirectProbe:\n .byte '+','.join(map(str,rows))+'\nHuArthurLo:',1)
 start=s.index('.proc HuArthurFeetGate');end=s.index('.endproc',start)
 part=s[start:end];assert part.count('farcall ArDispatch,jmp')==1;s=s[:start]+part.replace('farcall ArDispatch,jmp','farcall ArProbeDispatch,jmp',1)+s[end:]
 p.write_text(s,newline='\n')
 (O/'probe-source-plan.json').write_text(json.dumps(dict(parent_ROM_sha256=B.sha(OLD/'candidate.nes'),fast_rows=dict(HuHead=10,HuSide=14,HuFullBox=16),additional_fast_entry='HuArthurFeetGate raw32 branch',actual_source_probes_unchanged=['ArHostHead','ArHostSide','ArHostFoot','ArHostBox','BodyProbe'],scratch_order_preserved=['ArTemp inputA','ArTempHi inputPHP','source probe ordered writes','ArTemp outputA','ArTempHi outputPHP','R1 unchanged store','R0 unchanged store'],generic_motion_draw_graphics_lifecycle_retained=True),indent=2)+'\n')
def main():
 if '--finalize'in sys.argv:
  W.O=O;W.A=O/'arthur';W.D=O/'dense';W.T=O/'frozen-inputs';W.main();return
 prepare();W.O=O;W.A=O/'arthur';W.D=O/'dense';W.T=O/'frozen-inputs';sys.argv.append('--rebuild');W.main()
if __name__=='__main__':main()
