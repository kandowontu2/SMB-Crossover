"""Actual ISR/live-context, contacts and foreign-route closure for probes."""
from pathlib import Path
import argparse,importlib.util,json,traceback
import arthur_cache_host_controls_v1 as H
import arthur_cache_regression_controls_v1 as G
import arthur_host_commit_controls_v2 as K
A=H.A;R=H.R;O=R/'build/arthur-host-probe-fast-v1';OLD=H.O
def seams(b):
 spec=importlib.util.spec_from_file_location('probe_fast_real_vectors',R/'build/character-host-union-v5/gm_verify_nmi.py');g=importlib.util.module_from_spec(spec);spec.loader.exec_module(g);rows=[]
 start=A.address(b,'ArProbeDispatch')
 for offset in[0,4,8,11,19,27,34,36]:
  for kind in['NMI','IRQ']:
   q=G.setup(b);q.put(DisableScreenFlag=1,ArHostDue=1,ArHostPad=129,NmiDisable=255,VRAM_Buffer1_Offset=0,VRAM_Buffer_AddrCtrl=0)
   cache=bytes(q.m.ram[2]);_,z=g.scheduler.invoke(q.m,'GameLoop',sp=240,cut=(start+offset,26,kind))
   assert bytes(q.m.ram[2])==cache and q.m.rawtags[1]==q.get('CurrentBank')and q.m.rawtags[2]==q.get('CurrentBankC')
   assert q.get('ArHostReady')==167
   rows.append(dict(entry_offset=offset,kind=kind,**g.scheduler.summary(z),ISR=g.scheduler.summary(z['interrupt'])))
 return dict(actual_genuine_vector_cuts=len(rows),rows=rows,all33_SMC_live_stack_AXYP_SP_raw_maps_live_native_ZP_R0R1_restored=True,cache_immutable=True)
def foreign(b):
 original=A.scoped_load;old=original(OLD/'candidate.nes');pinned=R/'build/ice-pose-aliases-v2/candidate.nes'
 A.scoped_load=lambda p:old if Path(p)==pinned else original(p)
 try:return A.foreign(b)
 finally:A.scoped_load=original
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);ap.add_argument('--only',default='seams,foreign,selectors,pickups,powerup_chooser,lifecycle,interrupts,commit');a=ap.parse_args();assert not a.output.exists();b=A.scoped_load(O/'candidate.nes');d=dict(passed=False,native=False,checks={})
 functions=dict(seams=seams,foreign=foreign,commit=lambda b:K.run(b,False))
 try:
  for name in a.only.split(','):d['checks'][name]=functions.get(name,getattr(A,name,None))(b)
  d['passed']=True
 except Exception as e:d.update(failure=repr(e),traceback=traceback.format_exc())
 d['bindings']={str(p.resolve()):A.sha(p)for p in[Path(__file__),Path(H.__file__),Path(G.__file__),Path(A.__file__),O/'candidate.nes',O/'candidate.dbg',OLD/'candidate.nes',OLD/'candidate.dbg']};a.output.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(passed=d['passed'],checks=list(d['checks']),failure=d.get('failure'))));assert d['passed']
if __name__=='__main__':main()
