"""Freeze focused private source/CPU direct-probe successor for root review."""
from pathlib import Path
import ast,hashlib,json,re,zipfile
import arthur_probe_fast_controls_v1 as C
A=C.A;R=C.R;O=C.O;OLD=C.OLD;T=O/'frozen-inputs'
def main():
 assert not(O/'handoff.json').exists();h=A.sha(O/'candidate.nes');receipts=['controls-v1.json','extra-controls-v1.json','query-order-controls-v1.json','source-diff-lease-proof-v1.json'];checks={}
 for n in receipts:
  p=O/n;d=json.loads(p.read_text());assert d['passed']
  bindings=d['bindings'];key=str((O/'candidate.nes').resolve());assert bindings.get(key,d.get('candidate_ROM_sha256'))==h
  for path,digest in bindings.items():assert A.sha(path)==digest,(n,path,'stale source')
  checks[n]=A.sha(p)
 files=set()
 for p in O.glob('*.d'):
  files.add(p.resolve())
  for line in p.read_text().splitlines():
   if '\t'not in line:continue
   for token in re.split(r'(?<!\\)\s+',line.split('\t',1)[1]):
    if token:
     q=Path(token.replace('\\ ',' '));q=q if q.is_absolute()else T/q;assert q.exists(),q;files.add(q.resolve())
 for folder in[O/'arthur',O/'dense',O/'src']:
  files.update(p.resolve()for p in folder.rglob('*')if p.is_file()and p.suffix in['.s','.inc','.cfg','.chr','.nam','.rle','.bin'])
 files.update(p.resolve()for p in O.iterdir()if p.is_file()and p.suffix in['.s','.inc','.cfg','.chr','.nam','.rle'])
 recipe=json.loads((O/'arthur-build-proof.json').read_text())['commands'];produced={Path(z['command'][z['command'].index('-o')+1]).resolve()for z in recipe[:-1]};inherited=[]
 for token in recipe[-1]['command']:
  p=Path(token)
  if p.suffix=='.o'and p.resolve()not in produced:files.add(p.resolve());inherited.append(dict(path=str(p.resolve()),sha256=A.sha(p)))
 tools=['arthur_host_probe_fast_v1.py','arthur_probe_fast_controls_v1.py','arthur_probe_fast_extra_controls_v1.py','arthur_probe_query_order_v1.py','arthur_probe_source_proof_v1.py','arthur_probe_freeze_cpu_v1.py']
 files.update((R/'tools/audit'/n).resolve()for n in tools);pending=[R/'tools/audit'/n for n in tools];pending.append(R/'build/character-host-union-v5/gm_verify_nmi.py');seen=set()
 while pending:
  p=pending.pop().resolve()
  if p in seen:continue
  seen.add(p);files.add(p)
  for node in ast.walk(ast.parse(p.read_text())):
   names=[v.name for v in node.names]if isinstance(node,ast.Import)else[node.module]if isinstance(node,ast.ImportFrom)and node.module else[]
   for name in names:
    rel=Path(*name.split('.')).with_suffix('.py');q=next((folder/rel for folder in[p.parent,R/'tools/audit',R/'tools',R]if(folder/rel).is_file()),None)
    if q is not None:pending.append(q)
 for n in receipts+['arthur-build-proof.json','arthur-build-log.json','cache-final-link-proof.json','dense-parent-reproduction.json','parent-reproduction.json','parent-commands.json','probe-source-plan.json','candidate.cv3-mirror.json']:files.add((O/n).resolve())
 # Current cache smoke/performance is a retained immutable negative baseline.
 files.add((OLD/'arthur-cache-handoff-v1.json').resolve());files.add((R/'build/arthur-cache-native-profile-v2/review.json').resolve())
 grants=['arthur-quick-private-allocation','arthur-ice-alias-allocation','arthur-nmi-gateway-allocation','parodius-dense-chr','mmc5-overlay-private-allocation'];files.update((R/'docs/qa/checkpoints/2026-10-30'/n/'root-review-and-reservations.json').resolve()for n in grants)
 closure=O/'source-closure.json';manifest={p.relative_to(R).as_posix():A.sha(p)for p in sorted(files)};closure.write_text(json.dumps(dict(candidate_sha256=h,files=manifest,inherited_objects=inherited),indent=2)+'\n');archive=O/'private-source-cpu.zip'
 with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
  for p in sorted(files):z.write(p,p.relative_to(R).as_posix())
  z.write(closure,closure.relative_to(R).as_posix())
 basic=json.loads((O/'controls-v1.json').read_text());extra=json.loads((O/'extra-controls-v1.json').read_text());proof=json.loads((O/'source-diff-lease-proof-v1.json').read_text())
 probe=basic['checks']['probes'];main=basic['checks']['Main'];rows=main['rows'];saved=[r[3]-r[4]for r in rows]
 handoff=dict(status='PRIVATE_SOURCE_CPU_QUALIFIED_NATIVE_PENDING',candidate_sha256=h,parent_ROM_sha256=A.sha(OLD/'candidate.nes'),source_archive_sha256=A.sha(archive),source_closure_sha256=A.sha(closure),source_archive_bytes=archive.stat().st_size,source_archive_members=len(files)+1,receipts=checks,probe_cases=probe['cases'],actual_probe_saved_cycles=probe['saved_cycles'],differential_complete_Main_updates=main['updates'],complete_Main_saved_cycles=dict(min=min(saved),max=max(saved),mean=sum(saved)/len(saved)),actual_metatile_queries=504,real_probe_ISR_cuts=16,foreign=extra['checks']['foreign'],old_worker_header_CHR_cache_bytes_exact=True,all_original_Arthur_PRG_segments_exact_except_appended39B_Draw_adapter=True,A26_main_used=proof['A26_main_used'],A26_main_reserved=2262,union_used=proof['union_used'],union_reserved=2592,total_Arthur_PRG=proof['total_Arthur_PRG_bytes'],own_lease_only=True,limits=['No native run or cadence claim for5284.','Actual saving68cycles/probe preserves all ordered application writes; earlier148estimate was an upper bound before scratch/state contract sizing.','3daf native baseline217lag/400remains retained; further optimization/rebase/routes still required.','Source-owned motion/world/weapon/geometry/20Hzclock/doublejump unchanged; generic lifecycle/draw/graphics dispatch retained.'])
 (O/'handoff.json').write_text(json.dumps(handoff,indent=2)+'\n');print(json.dumps({k:v for k,v in handoff.items()if k not in['foreign','receipts','limits']}))
if __name__=='__main__':main()
