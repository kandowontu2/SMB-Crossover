"""Freeze focused native smoke with honest remaining cadence blocker."""
from pathlib import Path
import json,zipfile
import arthur_probe_fast_controls_v1 as C
A=C.A;R=C.R;O=C.O;OLD=C.OLD;N=O/'native/cold-probe-smoke-v1'
def main():
 assert not(O/'native-handoff-v1.json').exists();b=A.scoped_load(O/'candidate.nes');h=A.sha(O/'candidate.nes');result=json.loads((N/'result.json').read_text());timing=json.loads((N/'timing.json').read_text());cache=json.loads((N/'cache-native.json').read_text());cap=json.loads((N/'capture-budget.json').read_text())
 assert cap['returncode']==0 and not cap['violations']and result['passed']and cache['passed']and timing['ROM_sha256']==h==cache['ROM_sha256']
 baseline=OLD/'native/cold-cache-smoke-v2'
 for name in['actual-cache.bin','actual-cache-code.bin','actual-cache-cookie.bin']:assert(N/name).read_bytes()==(baseline/name).read_bytes(),('Exact unchanged verified cache payload',name)
 source=json.loads((O/'handoff.json').read_text());assert source['candidate_sha256']==h
 oldtiming=json.loads((baseline/'timing.json').read_text());files=list(N.iterdir())+[O/'native-driver-v1.lua',O/'native-prepared-v1.json',O/'native-preflight-v1.json',R/'tools/audit/arthur_prepare_probe_native_v1.py',R/'tools/audit/arthur_run_probe_native_v1.py',R/'tools/audit/arthur_probe_native_freeze_v1.py',OLD/'cache-native-source-v2.lua']
 archive=O/'native-supplement-v1.zip';assert not archive.exists()
 with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
  for p in files:
   if p.is_file():z.write(p,p.relative_to(R).as_posix())
 d=dict(status='PRIVATE_PROBE_HOST_SMOKE_ONLY_PERFORMANCE_UNADMITTED',candidate_sha256=h,source_handoff_sha256=A.sha(O/'handoff.json'),source_archive_sha256=source['source_archive_sha256'],native_archive_sha256=A.sha(archive),process_exit=0,all_original_controller_cache_PPU_source_assertions_retained=True,normal_8sprites=True,script_RAM_writes=False,cache_all6130_code284_cookie16_bytes_exact_to_3daf=True,semantic_result=result,timing=timing,comparison=dict(physical_game_frames=400,parent_ROM_sha256=oldtiming['ROM_sha256'],lag_before=oldtiming['lag_NMIs'],lag_after=timing['lag_NMIs'],active_Main_before=oldtiming['timing']['foreground']['count'],active_Main_after=timing['timing']['foreground']['count'],foreground_mean_before=oldtiming['timing']['foreground']['mean'],foreground_mean_after=timing['timing']['foreground']['mean'],foreground_max_before=oldtiming['timing']['foreground']['max'],foreground_max_after=timing['timing']['foreground']['max']),visual='Viewed actual controlled-game/source-lance PNGs; genuine Arthur/world/HUD/lance coherent. Original header/CHR/source workers byte-exact and earlier201source pixel controls retained by exact data/instruction provenance.',limits=['216lagNMIs/400frames is still severe; no shared install/admission.','This optimization changes instruction timing, so controller video-phase distributions can differ; source per-update proof is separate.','Controller-earned upgrades/fiveweapons/campaign/Hard/sourceaudio still pending.','Later V13 rebase must preserve current63+18gates and compose actual aliases/Quick owner retirement; no rebase implemented.'])
 d['bindings']={str(p.resolve()):A.sha(p)for p in files+[O/'candidate.nes',O/'candidate.dbg',O/'handoff.json',O/'source-diff-lease-proof-v1.json',OLD/'arthur-cache-handoff-v1.json']if p.is_file()};(O/'native-handoff-v1.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items()if k in['status','candidate_sha256','native_archive_sha256','comparison']}))
if __name__=='__main__':main()
