"""Freeze supplemental native CPU consumers without changing the source packet."""
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parents[2];P=R/'build/final-fantasy-joint-typed-v1';O=R/'build/final-fantasy-joint-consumers-v1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
assert not O.exists();files={Path(__file__),P/'handoff.json'}
for p in[P/'staged-native-consumer-fixtures-v2.json',P/'staged-main-fixture-correction-v3.json',P/'staged-nativebg-v2.json',P/'staged-main-v3.json']:
    d=json.loads(p.read_text())
    if 'passed'in d:assert d['passed'],p
    for f,h in d.get('bindings',{}).items():assert sha(f)==h,f
    files|={p}|set(map(Path,d.get('bindings',{})))
for p in[P/'staged-main-negative-v1.json',P/'staged-main-negative-v2.json',P/'staged-nativebg-v1.json']:files.add(p)
assert sha(P/'handoff.json')=='b44dd7368466afb584a6dc9117978718241cb1a2ef0e6f4fa90958d737d7c8a3'
h=json.loads((P/'handoff.json').read_text())
for p,s in h['bindings'].items():assert sha(p)==s,p
O.mkdir();m=json.loads((P/'staged-main-v3.json').read_text())
frames=[f for row in m['rows']for f in row['frames']];assert len(frames)==128
report=dict(passed=True,native=False,admitted=False,actual_cart_hooks=False,RAM3_preload=False,
 status='FROZEN_SOURCE_NATIVE_CPU_CONSUMERS_WITH_EXPLICIT_UNINSTALLED_SELECTORS',
 candidate_sha256='eefce872bd91cd75a549272a67a652b3f79061814b8c4aa0a2e90c90378545c9',
 actual_Main_updates=len(frames),actual_native_BG_ceiling_cases=24,
 every_Main_has_one_original_FF_movement_and_one_native_BG=True,
 selectors='Genuine physicalROM bank+PC staged through real FarCallCommon to source-linked ROM62 gates; no fabricated callback/contact results',
 original_Main_contract='Fixed126 direct nativeJSR; A-bank/SP/livepage1 restored, intentional graphics C hardware==shadow retained and recorded',
 observed_partial_Main_CPU=[min(f['observed_CPU']for f in frames),max(f['observed_CPU']for f in frames)],
 limits=['NOT installed common/Main routing. Six BG selectors and further Main callbacks remain explicitly staged CPU fixture routes.',
 'Source body/effects renderer,palette,audio,postBG,flash,NewEnemy and lifecycle composition still pending. Current body presentation is only firstchunk.',
 'No native emulator, hardware cadence/crowding, campaign or admission claim.'],
 retained_negatives=[str(P/'staged-main-negative-v1.json'),str(P/'staged-main-negative-v2.json')],
 bindings={str(p.resolve()):sha(p)for p in sorted(files)})
(O/'handoff.json').write_text(json.dumps(report,indent=2)+'\n',newline='\n')
print(json.dumps(dict(path=str(O/'handoff.json'),sha256=sha(O/'handoff.json'),bindings=len(files),updates=128)),flush=True)
