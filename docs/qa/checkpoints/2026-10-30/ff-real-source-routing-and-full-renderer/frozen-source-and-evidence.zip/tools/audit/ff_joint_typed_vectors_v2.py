"""Preserve full adapter flags at entry; separately prove genuine SFC's NZ ABI."""
from pathlib import Path
import itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import ff_joint_typed_vectors_v1 as P
from verify_native_relocation import NesMPU
T=P.T;H=T.H;O=T.O;sha=T.sha

def fullflags(b):
    seed=T.base(b);rows=[];guards=[]
    for f in range(64):
        p=(f&15)|((f&48)<<2)|32
        for name,native in[('FwSvcStomp','X5StompDispatch'),('FwSvcSpring','X5SpringDispatch')]:
            pair=[]
            for wrapped in[False,True]:
                m=T.copy(seed);H.put(m,FfJump=0,FfGPhase=2,MmUnderwater=0,Player_State=2,Player_Y_Speed=2)
                m.writes.clear();m.ram_writes.clear()
                if wrapped:c,_=H.invoke(m,name,a=91,x=4,y=133,p=p)
                else:
                    c,_=H.invoke(m,native,a=91,x=4,y=133,p=p)
                    c,_=H.invoke(m,'FwHostImpulseAccepted',a=c.a,x=c.x,y=c.y,p=c.p)
                pair.append(T.sig(m,c));H.exact(m)
                assert H.get(m,'FfJump')==1 and H.get(m,'FfGPhase')==0
            assert pair[0]==pair[1],(name,p)
            rows.append([name,p])
        for changed in[{},dict(SelectedCharacter=0),dict(GameEngineSubroutine=4),dict(GameEngineSubroutine=5),dict(GamePauseStatus=1),dict(TimerControl=1),dict(MmDeathFlag=1)]:
            # Direct real ROM62 entry establishes full APXY adapter contract.
            m=T.copy(seed);H.put(m,**changed);H.put(m,CurrentBank=0xbe);m.raw_page(1,0xbe)
            c=NesMPU(memory=m,pc=H.address(b,'FwSvcActive'));c.a=91;c.x=4;c.y=133;c.p=p;c.sp=224;c.stPushWord(0x5aff)
            live=bytes(m[225:256]);H.finish(m,c)
            assert(c.a,c.x,c.y,c.p&0xce,c.sp)==(91,4,133,p&0xce,224)
            assert bool(c.p&1)==(not changed) and bytes(m[225:256])==live
            # Actual shared SFC loads return A; that intentionally defines NZ.
            m=T.copy(seed);H.put(m,**changed);c,_=H.invoke(m,'FwSvcActive',a=91,x=4,y=133,p=p)
            assert(c.a,c.x,c.y,c.p&0x4c,c.sp)==(91,4,133,p&0x4c,224)
            assert c.p&0x82==0 and bool(c.p&1)==(not changed)
            guards.append([p,changed])
    return dict(actual_native_impulse_pairs=len(rows),rows=rows,
        full_flags_direct_adapter_cases=len(guards),genuine_SFC_return_A_NZ_cases=len(guards),guards=guards,
        original_negative='v1 incorrectly asserted pre-SFC NZ through genuine SFC final LDA returnA')

def main():
    out=O/'typed-vectors-v2.json';assert not out.exists();p=dict(passed=False,native=False,admitted=False,checks={})
    try:
        closure=json.loads((O/'source-closure.json').read_text())
        for f,h in closure['bindings'].items():assert sha(f)==h,f
        b=H.C.qualified(H.O/'candidate.nes')
        for n,fn in[('full_flags_impulses',fullflags),('real_native_vectors',P.vectors)]:
            p['checks'][n]=fn(b);print(n,'PASS',flush=True)
        p['passed']=True
    except Exception as e:p.update(error=repr(e),traceback=traceback.format_exc())
    p['bindings']={str(f.resolve()):sha(f)for f in[Path(__file__),Path(P.__file__),Path(T.__file__),Path(H.__file__),Path(P.V.__file__),O/'source-closure.json',O/'typed-controls-v2.json',O/'typed-vectors-negative-v1.json',H.O/'candidate.nes',H.O/'candidate.dbg']}
    t=out if p['passed']else O/'typed-vectors-negative-v2.json';assert not t.exists();t.write_text(json.dumps(p,indent=2)+'\n',newline='\n')
    print(json.dumps(dict(passed=p['passed'],path=str(t),error=p.get('error'))),flush=True);assert p['passed']

if __name__=='__main__':main()
