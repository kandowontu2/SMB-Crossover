"""Reuse exact FF-v13 semantic assertions against genuine fast-v6 composition."""
from pathlib import Path
import hashlib,json,sys,traceback
R=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import ff_wram_host_controls_v7 as H
import ff_selected_reset_controls_v3 as L

O=R/'build/final-fantasy-joint-source-v1'
H.O=O/'joint';L.O=H.O
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
    out=O/'semantic-controls.json';assert not out.exists()
    proof=dict(passed=False,native=False,admitted=False,common_routes_installed=False,checks={})
    try:
        closure=json.loads((O/'source-closure.json').read_text())
        for p,h in closure['bindings'].items():assert sha(p)==h,p
        b=H.C.qualified(H.O/'candidate.nes')
        for n,fn in [('loader',H.loader),('routes',H.routes),('lifecycle',H.lifecycle),
                     ('cold_portraits',H.cold_portraits),('host_routes',H.host_routes),
                     ('host_graphics',H.host_graphics),('selected_reset',L.cases),('staged_reset_caller',L.actual_caller)]:
            proof['checks'][n]=fn(b);print(n,'PASS',flush=True)
        proof['passed']=True
    except Exception as e:proof.update(error=repr(e),traceback=traceback.format_exc())
    proof['bindings']={str(p.resolve()):sha(p)for p in[Path(__file__),Path(H.__file__),Path(L.__file__),O/'source-closure.json',H.O/'candidate.nes',H.O/'candidate.dbg',H.O/'ram3.bin',H.O/'ff-cookie.bin']}
    target=out if proof['passed']else O/'semantic-controls-negative.json'
    assert not target.exists();target.write_text(json.dumps(proof,indent=2)+'\n',newline='\n')
    print(json.dumps(dict(passed=proof['passed'],path=str(target),error=proof.get('error'))),flush=True)
    assert proof['passed']

if __name__=='__main__':main()
