"""Derive stricter real-bank selector fixtures and the actual native Main ABI."""
from pathlib import Path
import hashlib,json,subprocess,sys
R=Path(__file__).resolve().parents[2];D=R/'tools/audit';O=R/'build/final-fantasy-joint-typed-v1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
new=[]
for stem in['ff_joint_staged_nativebg','ff_joint_staged_main']:
    p=D/(stem+'_v1.py');q=D/(stem+'_v2.py');assert not q.exists();s=p.read_text()
    s=s.replace('import ff_joint_typed_controls_v1 as T','from check_tmnt_render_oa import location\nimport ff_joint_typed_controls_v1 as T')
    s=s.replace("targets={H.address(b,n):(n,v)for n,v in ROUTES.items()}","targets={(H.address(b,n),((location(b,n)-16)//8192)|128):(n,v)for n,v in ROUTES.items()}")
    s=s.replace("targets={H.address(b,n):(n,t)for n,t in ROUTES.items()}","targets={(H.address(b,n),((location(b,n)-16)//8192)|128):(n,t)for n,t in ROUTES.items()}")
    s=s.replace('if c.pc not in targets:return','tag=mem.rawtags[(c.pc-0x8000)//8192]if c.pc>=0x8000 else -1\n'+('                    'if stem.endswith('main')else'        ')+'if(c.pc,tag)not in targets:return')
    s=s.replace('targets[c.pc]','targets[(c.pc,tag)]')
    s=s.replace('staged-nativebg-v1.json','staged-nativebg-v2.json').replace('staged-nativebg-negative-v1.json','staged-nativebg-negative-v2.json')
    s=s.replace('staged-main-v1.json','staged-main-v2.json').replace('staged-main-negative-v1.json','staged-main-negative-v2.json')
    if stem.endswith('main'):
        s=s.replace("import ff_joint_staged_nativebg_v1 as BG","import ff_joint_staged_nativebg_v2 as BG\nfrom verify_native_relocation import NesMPU")
        helper='''
def invoke_main(m,hook):
    # Native IdleLoop JSRs this fixed126 routine directly. Generic SFC restores
    # only A; Main's genuine graphics C publication intentionally persists.
    before=m.rawtags[:];c=NesMPU(memory=m,pc=H.address(m.bundle,'GameLoop'))
    c.a=0x55;c.x=7;c.y=91;c.p=0x71;c.sp=224;c.stPushWord(0x5aff)
    live=bytes(m[0x1e1:0x200]);c,low=H.finish(m,c,hook)
    assert c.sp==224 and bytes(m[0x1e1:0x200])==live
    assert m.rawtags[1]==before[1] and H.get(m,'CurrentBank')==before[1]
    assert m.rawtags[2]==H.get(m,'CurrentBankC')
    return c,low

'''
        s=s.replace('def main():',helper+'def main():')
        s=s.replace("H.invoke(m,'GameLoop',hook=stage)","invoke_main(m,stage)")
        s=s.replace("observed_CPU=c.processorCycles,minimum_SP=low,X=", "observed_CPU=c.processorCycles,minimum_SP=low,actual_final_rawC=m.rawtags[2],X=")
    s=s.replace("O/'handoff.json',H.O/'candidate.nes'", "O/'handoff.json',O/'staged-main-negative-v1.json',DUMMY_PLACEHOLDER,H.O/'candidate.nes'")if False else s
    q.write_text(s,newline='\n');new += [p,q]
proof=dict(native=False,ROM_unchanged=True,corrections=['Bind selector to genuine physicalROM bank+PC, never only aliasedvirtualPC',
 'Invoke genuine fixed126 GameLoop directly as nativeIdleLoop does; assert its real A/SP/livepage1/Cshadow contract; record intentional publishedC'],
 retained_negative=str(O/'staged-main-negative-v1.json'),bindings={str(p):sha(p)for p in[Path(__file__),*new,O/'handoff.json',O/'staged-main-negative-v1.json']})
(O/'staged-native-consumer-fixtures-v2.json').write_text(json.dumps(proof,indent=2)+'\n',newline='\n')
for stem in['ff_joint_staged_nativebg','ff_joint_staged_main']:
    code=subprocess.call([sys.executable,str(D/(stem+'_v2.py'))],cwd=R)
    if code:raise SystemExit(code)
