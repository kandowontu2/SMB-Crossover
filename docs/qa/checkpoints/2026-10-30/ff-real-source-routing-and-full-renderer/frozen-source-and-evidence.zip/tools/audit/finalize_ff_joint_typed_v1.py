"""Freeze the qualified source-only FF joint loader and typed callback stage."""
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parents[2]
A=R/'build/final-fantasy-joint-source-v1';O=R/'build/final-fantasy-joint-typed-v1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
files={Path(__file__)}
for p in[A/'source-closure.json',O/'source-closure.json',A/'semantic-controls.json',
          A/'isr-fixture-derivation.json',A/'joint/loader-isr-controls-v8.json',
          O/'typed-controls-v2.json',O/'typed-vectors-v2.json']:
    d=json.loads(p.read_text())
    if 'passed'in d:assert d['passed'],p
    for f,h in d.get('bindings',{}).items():assert sha(f)==h,f
    files|=set(map(Path,d.get('bindings',{})))|{p}
for p in[A,O]:files|={f for f in p.rglob('*')if f.is_file()}
assert not(O/'handoff.json').exists()
rom=O/'joint/candidate.nes';assert sha(rom)=='eefce872bd91cd75a549272a67a652b3f79061814b8c4aa0a2e90c90378545c9'
assert (O/'joint/ram3.bin').read_bytes()==(R/'build/final-fantasy-wram-host-v13/ram3.bin').read_bytes()
checks={
 'genuine_fast_v6_reproduction':'2ed6d9f8c05d08eac3a2df080df3f4d02fc301a9eaab0724e6d8a4581b753629',
 'actual_source_merge':'9e66753786b8404643d52d757259857fe0dd3f98a699d40352d2ed1472131f9e',
 'source_RAM3_exact':'2ef76f0b00d94f5ecf10ed0bdc5745b0ac9e90394ddc1f0a0dc2abd5a26ec0ed',
 'ROM62_typed_adapter_bytes':381,'ROM62_typed_adapter_interval':['B46E','B5EB'],
 'ROM62_remaining_tail':165,'ROM62_remaining_existing_alignment':228,
 'active_native_query_fallback_pairs':336,'source_motion_native_climb_pairs':32,
 'side_effect_free_maturity_cases':360,'native_X5_impulse_pairs_all64flags':128,
 'direct_full_APXY_guard_cases':448,'actual_SFC_return_A_NZ_cases':448,
 'real_typed_NMI_IRQ_cases':1512,'real_cold_loader_ISR_cases':142,
 'masked_IRQ_loader_requests':134,'real_hot_loader_ISR_cases':1388,
 'all_previous_publicPCs_exact':True,'common_A79_exact':True,
 'only_native_hook':'Existing InitScreen farcall3immediate operands, originalMove first',
 'no_native_no_admission_no_frontend_change':True,
}
report=dict(status='FROZEN_PRIVATE_FF_FASTV6_SOURCE_LOADER_TYPED_CALLBACK_CPU_PASS_MAIN_ROUTING_PENDING',
 passed=True,native=False,admitted=False,candidate=str(rom),candidate_sha256=sha(rom),checks=checks,
 API=dict(veneer='FwServiceVeneers B400 rawBE',reject_slot36='B46C CLC RTS',
  service23='FwSvcMature admission only, no effects',service24='FwHostCollect actual native actor consumption',
  movement='FwSvcMovement active22/8/cookie; Cclear source handoff runs genuine MegaManClimbing',
  terrain='FwSvcHead/Side/HeadWithin/Body/Adder/BoxProfile/FullBox active8 own source; inactive/4/5 genuine old native callbacks',
  impulses='FwSvcStomp/Spring real native X5 then source ImpulseAccepted; disclosed host adaptation',
  reset='FwSelectedReset genuineSpecialRosterClear + Ensure/AreaReset; scene retains earned class/tier/charges; actuallife loss resets sourcegear',
  loader='Private forcedblank893..<901 buffered2007 copy+fullverify toC3;16Bcookie validfirst-clear/last-publish; no5102/5103/5113writes'),
 retained_negatives=[str(O/'typed-controls-negative.json'),str(O/'typed-vectors-negative-v1.json')],
 limits=['No commonA79/classifier mutation in this packet; actual joint55B transport remains next source composition.',
  'FF remains frontend-pending. These direct typed callback tests do not prove actual fullMain/BG installed routing.',
  'Full body/effect renderer, palette and audio still root-owned pending components. Current graphics/portrait retain authentic first-chunk API only.',
  'Feet/wall/postBG outside36service hooks, native actor Fresh and once-per-update native flash aging/owner still need genuine integration.',
  'No native emulator, playable/campaign/admission or performance claim.'],
 bindings={str(f.resolve()):sha(f)for f in sorted(files)})
(O/'handoff.json').write_text(json.dumps(report,indent=2)+'\n',newline='\n')
print(json.dumps(dict(path=str(O/'handoff.json'),sha256=sha(O/'handoff.json'),bindings=len(files),candidate_sha256=sha(rom))),flush=True)
