"""Execute separate FF dispatcher source fragments against genuine cart ABI.

The common fragment is a separate linker output mapped ONLY by this CPU
fixture. Cartridge A79 is unchanged. Pending services reject explicitly;
their routing checks are not gameplay qualification.
"""
from pathlib import Path
import copy,hashlib,itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import ff_wram_host_controls_v7 as H
import ff_host_pickups_vectors_v2 as V
from ff_wram_host_isr_v4 import clone
C=H.C;O=R/'build/final-fantasy-wram-host-v13'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()


class ModelMemory(type(H.make(C.qualified(H.O/'candidate.nes')))):
    def __getitem__(self,key):
        if isinstance(key,slice):return [self[i]for i in range(*key.indices(65536))]
        if 0xb000<=key<0xb200 and self.rawtags[1]==0xcf:
            return self.fragment[key-0xb000]
        return super().__getitem__(key)


def model(base):
    m=list.__new__(ModelMemory);list.extend(m,list.__iter__(base))
    for k,v in base.__dict__.items():setattr(m,k,v if k=='bundle'else copy.deepcopy(v))
    m.fragment=(O/'dispatch-model.bin').read_bytes()
    m.raw_page(1,0xcf);H.put(m,CurrentBank=0xcf)
    return m


def start(m,entry,index,a=0x55,x=7,y=91,p=0x71,sp=224):
    m[H.address(m.bundle,'SafecallA_SMC')+1]=a
    c=H.NesMPU(memory=m,pc=H.address(m.bundle,entry))
    c.a=a;c.x=x;c.y=index;c.p=p;c.sp=sp
    c.stPushWord(0x5aff);c.stPush(p);c.stPush(y)
    return c


def application(m):
    ex=set(range(0x100,0x200))|set(range(0x15a,0x17b))|set(range(0x5114,0x5118))
    return bytes(m[i]for i in range(0x8000)if i not in ex)


def stores(m):
    ex=set(range(0x100,0x200))|set(range(0x15a,0x17b))|set(range(0x5114,0x5118))
    ex.update([H.address(m.bundle,'CurrentBank'),H.address(m.bundle,'CurrentBankC')])
    return [(a,v)for a,v in m.writes if a not in ex]


def finish(m,c,index,hook=None):
    oldc=m.rawtags[2];live=bytes(m[0x1e1:0x200]);seen=[]
    veneer=H.address(m.bundle,'FwServiceVeneers')+3*index if index<36 else H.address(m.bundle,'FwServiceUnavailable')
    def observe(mem,cpu,i):
        if cpu.pc==veneer:
            assert mem.rawtags[1]==0xbe and H.get(mem,'CurrentBank')==0xbe
            seen.append([cpu.pc,mem.rawtags[1],cpu.a,cpu.x,cpu.y,cpu.p])
        if hook:hook(mem,cpu,i)
    H.finish(m,c,observe)
    assert seen and c.sp==224 and bytes(m[0x1e1:0x200])==live
    assert m.rawtags[1]==0xcf and H.get(m,'CurrentBank')==0xcf
    assert m.rawtags[2]==oldc and H.get(m,'CurrentBankC')==oldc
    return seen


def ready(b):
    m=H.make(b);H.invoke(m,'FwLoad');H.invoke(m,'FwEnsure')
    H.put(m,TimerControl=0,MmDeathFlag=0,GamePauseStatus=0,ObjectOffset=4,
          FfPower=2,FfEarned=2,Player_State=0,Player_Y_Speed=0,
          SavedJoypadBits=0,ScreenLeft_X_Pos=0,ScreenLeft_PageLoc=0,
          RgCrouch=0,FfTerrainPreviousY=160,FfTerrainFlags=0)
    for n in ['Enemy_Flag','Enemy_ID','Enemy_State','Enemy_X_Position','Enemy_PageLoc',
              'Enemy_Y_Position','Enemy_Y_HighPos','Enemy_BoundBoxCtrl',
              'MmEnemyHealthLo','MmEnemyHealthHi','MmEnemyFlash']:
        for i in range(6):m[H.address(b,n)+i]=0
    for i in range(H.address(b,'Block_Buffer_1'),H.address(b,'Block_Buffer_2')+208):m[i]=0
    return m


def paired(b):
    base=ready(b);rows=[];costs=[]
    flags=[0x30|sum(((n>>i)&1)*bit for i,bit in enumerate([1,2,4,8,64,128]))for n in range(64)]
    for index,p in itertools.product(range(36),flags):
        pair=[];cycles=[]
        for entry in ['FwTableModel','FwSelectModel']:
            m=model(base);m.writes.clear();m.ram_writes.clear()
            c=start(m,entry,index,p=p,x=index%6,y=0 if index!=14 else 3)
            seen=finish(m,c,index);H.exact(m)
            pair.append((application(m),stores(m),(c.a,c.x,c.y,c.p,c.sp),m.rawtags[:],bytes(m[0x15a:0x17b]),m.ram[3][:],seen))
            cycles.append(c.processorCycles)
        assert pair[0]==pair[1],('real table/arithmetic dispatch differs',index,p)
        costs.append(cycles[1]-cycles[0]);rows.append([index,p,*cycles])
    rejected=[]
    for index in range(36,256):
        m=model(base);before=application(m);m.writes.clear();m.ram_writes.clear()
        c=start(m,'FwSelectModel',index);finish(m,c,index)
        assert not c.p&1 and application(m)==before and not stores(m) and not m.ram_writes
        rejected.append(index)
    return dict(actual_table_arithmetic_pairs=len(rows),all64_flags=True,rows=rows,
        invalid_indices_rejected=rejected,AXYP_SP_live_page1_R0_R1_all33SMC_maps_source_state_ordered_application_stores_exact=True,
        arithmetic_minus_table_CPU_cycles=[min(costs),max(costs)],
        pending_rows='Explicit Cclear unavailable endpoints verify transport only, not missing gameplay semantics.')


def vectors(b):
    base=ready(b);rows=[];masked=0
    for index in [0,1,3,4,10,11,14,16,19,23,33,35,36]:
        m=model(base);H.put(m,NmiDisable=0)
        c=start(m,'FwSelectModel',index,p=0x30,x=0,y=3 if index==14 else 0)
        snapshots=[]
        def take(mem,cpu,i):
            op=bytes(mem[cpu.pc:cpu.pc+3])
            if i<45 or op in [b'\x8d\x15\x51',b'\x8d\x16\x51'] or (mem.rawtags[1]==3 and cpu.pc==H.address(b,'FfGraphicsBank')+5):
                snapshots.append((i,cpu.pc,clone(mem,cpu)))
        finish(m,c,index,take);expected=(c.a,c.x,c.y,c.p,c.sp)
        for step,pc,(state,cpu) in snapshots:
            for lag,kind in itertools.product([0,255],['NMI','IRQ']):
                q,d=clone(state,cpu);H.put(q,NmiDisable=lag)
                if kind=='IRQ'and d.p&d.INTERRUPT:
                    before=C.cpu_state(d);d.irq();assert C.cpu_state(d)==before;masked+=1;continue
                ff=bytes(q[0x5c00:0x5c80])+bytes(q[0x5fc1:0x5fcf])+bytes([q[0x5fef]])
                result=V.interrupt(q,d,kind)
                assert ff==bytes(q[0x5c00:0x5c80])+bytes(q[0x5fc1:0x5fcf])+bytes([q[0x5fef]])
                # Continue this already-entered transfer; no synthetic new call.
                H.finish(q,d);H.exact(q)
                assert(d.a,d.x,d.y,d.p,d.sp)==expected and q.rawtags==m.rawtags
                rows.append(dict(service=index,step=step,PC=pc,lag=lag,**result))
    return dict(real_normal_lag_NMI_IRQ_cases=len(rows),masked_IRQ_requests=masked,rows=rows,
        all33SMC_borrowed_pairs_stack_raw_shadow_pending_seams_preserved=True)


def main():
    out=O/'dispatch-controls-v4.json';assert not out.exists()
    proof=dict(passed=False,native=False,common_cartridge_mutated=False,fixture_common_fragment=True,checks={})
    try:
        build=json.loads((O/'build-proof.json').read_text())
        for p,h in build['bindings'].items():assert sha(p)==h,p
        b=C.qualified(O/'candidate.nes');m=H.make(b)
        sfc=H.address(b,'FarCallCommon');code=bytes(m[sfc:sfc+33])
        assert sfc==0x15a and code[:3]==bytes([0x8d,(H.address(b,'NextBank_SMC')+1)&255,(H.address(b,'NextBank_SMC')+1)>>8])
        assert bytes((O/'candidate.nes').read_bytes()[16+79*8192:16+80*8192])==bytes((H.O/'candidate.nes').read_bytes()[16+79*8192:16+80*8192])
        proof['SFC_interior']=dict(source=str(R/'src/mmc5.s'),address=sfc,bytes=code.hex(),
            skipped_only='STA NextBank_SMC+1; arithmetic and reference model both explicitly set this exact operand before entry.',
            valid_entry='FarCallCommon+3 is existing genuine HuCommon entry ABI, not a new public call convention.')
        proof['checks']['paired']=paired(b);print('FF real dispatch allflags/bounds PASS',flush=True)
        proof['checks']['vectors']=vectors(b);print('FF dispatch real vector cuts PASS',flush=True)
        proof['passed']=True
    except Exception as e:proof.update(error=repr(e),traceback=traceback.format_exc())
    proof['bindings']={str(p.resolve()):sha(p)for p in [Path(__file__),Path(H.__file__),Path(V.__file__),O/'build-proof.json',O/'candidate.nes',O/'candidate.dbg',O/'dispatch-model.bin',O/'dispatch-model.s',O/'service-matrix.json',R/'src/mmc5.s',R/'build/character-host-union-v13/union.s']}
    target=out if proof['passed']else O/'dispatch-negative-v4.json';assert not target.exists()
    target.write_text(json.dumps(proof,indent=2)+'\n',newline='\n')
    print(json.dumps(dict(passed=proof['passed'],error=proof.get('error'),path=str(target))))
    assert proof['passed']


if __name__=='__main__':main()
