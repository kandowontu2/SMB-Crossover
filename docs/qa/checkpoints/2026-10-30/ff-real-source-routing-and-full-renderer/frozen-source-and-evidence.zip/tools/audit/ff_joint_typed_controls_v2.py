"""Correct only a fixture symbol typo; preserve v1's completed fallback pass."""
from pathlib import Path
import hashlib,itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import ff_joint_typed_controls_v1 as T
H=T.H;O=T.O;sha=T.sha

def movement(b):
    seed=T.base(b);rows=[]
    for state,joy,flags in itertools.product([0,1,2,3],[0,1,2,0x80],[0x30,0x71]):
        out=[]
        for wrapped in[False,True]:
            m=T.copy(seed);H.put(m,Player_State=state,SavedJoypadBits=joy,FfPrevious=0,Player_Y_Speed=0,
                 ClimbSideTimer=0,Player_CollisionBits=0xff)
            m.writes.clear();m.ram_writes.clear()
            c,_=H.invoke(m,'FwSvcMovement'if wrapped else'FwHostMovement',a=22,x=0,y=0,p=flags)
            if not wrapped and state==3:c,_=H.invoke(m,'MegaManClimbing',a=c.a,x=c.x,y=c.y,p=c.p)
            out.append(T.sig(m,c));H.exact(m)
        assert out[0]==out[1],('movement/climb',state,joy,flags)
        rows.append([state,joy,flags])
    return dict(actual_source_plus_genuine_native_climb_pairs=len(rows),rows=rows)

def main():
    out=O/'typed-controls-v2.json';assert not out.exists()
    p=dict(passed=False,native=False,admitted=False,checks={},retained_negative=str(O/'typed-controls-negative.json'),
           correction='Fixture symbol PlayerCollisionBits corrected to genuine Player_CollisionBits. ROM/assertions unchanged.')
    try:
        d=json.loads((O/'source-closure.json').read_text())
        for f,h in d['bindings'].items():assert sha(f)==h,f
        b=H.C.qualified(H.O/'candidate.nes')
        for n,fn in[('native_query_fallbacks',T.pairs),('movement_and_climb',movement),('maturity_order',T.maturity)]:
            p['checks'][n]=fn(b);print(n,'PASS',flush=True)
        p['passed']=True
    except Exception as e:p.update(error=repr(e),traceback=traceback.format_exc())
    p['bindings']={str(f.resolve()):sha(f)for f in[Path(__file__),Path(T.__file__),Path(H.__file__),O/'source-closure.json',O/'typed-controls-negative.json',H.O/'candidate.nes',H.O/'candidate.dbg']}
    t=out if p['passed']else O/'typed-controls-negative-v2.json';assert not t.exists();t.write_text(json.dumps(p,indent=2)+'\n',newline='\n')
    print(json.dumps(dict(passed=p['passed'],path=str(t),error=p.get('error'))),flush=True);assert p['passed']

if __name__=='__main__':main()
