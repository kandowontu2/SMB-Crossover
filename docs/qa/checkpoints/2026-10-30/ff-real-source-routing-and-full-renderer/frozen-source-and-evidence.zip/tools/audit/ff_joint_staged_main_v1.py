"""Actual Main call inventory with explicit uninstalled typed source selectors.

The full native Main executes. This is partial FF integration evidence only:
full presentation, postBG/flash/NewEnemy and installed common routing are owed.
"""
from pathlib import Path
import itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import ff_joint_typed_controls_v1 as T
import ff_joint_staged_nativebg_v1 as BG
import dragon_power_gameplay_controls_v1 as C
O=T.O;H=T.H;sha=T.sha
ROUTES={**BG.ROUTES,'NrMovement':'FwSvcMovement','NrGraphics':'FwHostGraphics',
 'NrVisible':'FwVisible','NrBody':'FwSvcBody','NrBox':'FwSvcBoxProfile',
 'GmFullBoxGate':'FwSvcFullBox','NrWeapons':'FwHostWeapons'}

def setup(b):
    q=C.setup(b,22);m=H.make(b)
    # Reuse the legal source-Main scene fixture. No code/cache preload.
    for a in list(range(0x800))+list(range(0x5c00,0x6000)):list.__setitem__(m,a,q.m[a])
    m.ram[0][:]=bytes(q.m[a]for a in range(0x6000,0x8000))
    H.put(m,CurrentBank=215,CurrentBankC=216,OperMode=1,DisableScreenFlag=1,
          Mirror_PPUMASK=0,Mirror_PPUCTRL=0xa0,NmiDisable=255,FfVariant=0,FfReady=0)
    H.invoke(m,'FwLoad');H.invoke(m,'FwEnsure')
    H.put(m,DisableScreenFlag=0,Mirror_PPUMASK=30)
    return m

def main():
    out=O/'staged-main-v1.json';assert not out.exists()
    p=dict(passed=False,native=False,admitted=False,actual_cart_hooks=False,RAM3_preload=False,
      source_scene_setup_only=True,artificial_contact_or_result_writes=False,routes=ROUTES,rows=[],
      limits=['Uninstalled selector staging only; does not establish cart/common readiness.',
       'Graphics is authentic chunk0 only; full renderer/palette,postBG/flash/NewEnemy remain pending.',
       'CPU observations are not native cadence, campaign, gameplay admission, or performance proof.'])
    try:
        b=H.C.qualified(H.O/'candidate.nes');targets={H.address(b,n):(n,t)for n,t in ROUTES.items()}
        for variant,face,skip in itertools.product(range(4),[1,2],[0,1]):
            m=setup(b);H.put(m,FfVariant=variant,PlayerFacingDir=face,ShouldSkipDrawSprites=skip);frames=[]
            for age in range(8):
                joy=(1 if face==1 else 2)|(128 if 2<=age<5 else 0)
                H.put(m,SavedJoypadBits=joy,A_B_Buttons=joy&192,Left_Right_Buttons=joy&3,
                      NmiDisable=255,VRAM_Buffer1_Offset=0)
                calls=[];body=0;bg=0
                def stage(mem,c,i):
                    nonlocal body,bg
                    if c.pc==H.address(b,'FfHostMovement')and mem.rawtags[1]==3:body+=1
                    if c.pc==H.address(b,'PlayerBGCollision'):bg+=1
                    if c.pc not in targets:return
                    source,target=targets[c.pc];calls.append([source,target,c.a,c.x,c.y])
                    at=H.address(b,target);mem[H.address(b,'SafecallA_SMC')+1]=c.a
                    mem[H.address(b,'FarcallJmpTarget_SMC')+1]=at&255
                    mem[H.address(b,'FarcallJmpTarget_SMC')+2]=at>>8
                    c.a=0xbe;c.pc=H.address(b,'FarCallCommon')
                c,low=H.invoke(m,'GameLoop',hook=stage)
                assert body==1 and bg==1,('actual Main source/BG cadence',variant,face,skip,age,body,bg,calls)
                assert H.get(m,'NmiDisable')==0 and H.get(m,'GameEngineSubroutine')==8
                H.exact(m)
                frames.append(dict(age=age,input=joy,source_movement_calls=body,native_BG_calls=bg,
                  observed_CPU=c.processorCycles,minimum_SP=low,X=H.get(m,'Player_X_Position'),
                  Y=H.get(m,'Player_Y_Position'),calls=calls))
            p['rows'].append(dict(variant=variant,face=face,skip=skip,frames=frames))
        p['passed']=True
    except Exception as e:p.update(error=repr(e),traceback=traceback.format_exc())
    p['bindings']={str(f.resolve()):sha(f)for f in[Path(__file__),Path(T.__file__),Path(H.__file__),Path(C.__file__),O/'handoff.json',H.O/'candidate.nes',H.O/'candidate.dbg']}
    t=out if p['passed']else O/'staged-main-negative-v1.json';assert not t.exists();t.write_text(json.dumps(p,indent=2)+'\n',newline='\n')
    print(json.dumps(dict(passed=p['passed'],rows=len(p['rows']),error=p.get('error'),path=str(t))),flush=True);assert p['passed']

if __name__=='__main__':main()
