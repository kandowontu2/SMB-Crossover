"""New private FF typed callback row on exact source-only joint merge."""
from pathlib import Path
import hashlib,json,re,sys
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import prepare_ff_joint_source_v1 as B
from prepare_ff_current_component_v2 import qualified
from finalize_ff_current_component_v3 import dependencies
from check_tmnt_render_oa import location,address
from prepare_cv3_dmc_mirror import prepare

P=B.O;O=R/'build/final-fantasy-joint-typed-v1';sha=B.sha

def main():
    assert not O.exists();proof=json.loads((P/'source-closure.json').read_text())
    for p,h in proof['bindings'].items():assert sha(p)==h,p
    assert json.loads((P/'semantic-controls.json').read_text())['passed']
    O.mkdir();d=O/'joint';d.mkdir()
    for p in(P/'joint').rglob('*'):
        if p.is_file()and(p.suffix in['.s','.inc','.cfg']or p.name in['ff-stream.bin','ff-cookie.bin']):
            q=d/p.relative_to(P/'joint');q.parent.mkdir(exist_ok=True,parents=True);q.write_bytes(p.read_bytes())
    cfg=(d/'private.cfg').read_text().replace(str(P/'joint').replace('\\','/'),str(d).replace('\\','/'))
    cfg=cfg.replace('FF_SERVICE_VENEERS:load=X5_NEW_3E,type=ro,start=$b400;',
                    'FF_SERVICE_VENEERS:load=X5_NEW_3E,type=ro,start=$b400;\nFF_SERVICE_ADAPTERS:load=X5_NEW_3E,type=ro,start=$b46e;')
    B.write(d/'private.cfg',cfg)
    src=R/'tools/audit/ff_joint_typed_services_v1.s';B.write(d/'typed-services.s',src.read_text())
    row=json.loads((B.F/'service-matrix.json').read_text())
    changes={0:'FwSvcMovement',10:'FwSvcHead',11:'FwSvcBody',12:'FwSvcAdder',13:'FwSvcBoxProfile',14:'FwSvcSide',16:'FwSvcFullBox',23:'FwSvcMature',24:'FwHostCollect',27:'FwSvcStomp',28:'FwSvcHeadWithin',31:'FwSvcStomp'}
    v=(d/'veneers.s').read_text()
    for i,t in changes.items():
        old=row['rows'][i]['target'];needle='; '+str(i)+' '+row['rows'][i]['name']
        start=v.index(needle);end=v.index('\n',v.index(' jmp ',start))
        s=v[start:end];assert ' jmp '+old in s
        v=v[:start]+s.replace(' jmp '+old,' jmp '+t)+v[end:]
        row['rows'][i].update(target=t,status='typed_actual_native_contract')
    v=''.join('.import '+n+'\n'for n in sorted(set(changes.values())-{'FwHostCollect'}))+v
    B.write(d/'veneers.s',v);row.update(native=False,admitted=False,common_mutated=False)
    row['limits']=['FF remains pending; common routing and full rendering/palette not yet installed.',
                   'Service23 maturity is side-effect-free; service24 calls native actor collection.',
                   'Feet/postBG/wall/full Main body hook outside36 remain explicit integration work.']
    B.save(O/'service-matrix.json',row)
    entry=(d/'entrypoint.s').read_text()
    for match in re.finditer(r'^\.import(zp)? (.+)$',src.read_text(),re.M):
        for n in match[2].split(','):
            n=n.strip()
            if not n.startswith(('Fw','Ff')):entry+='\n.export'+('zp'if match[1]else'')+' '+n
    B.write(d/'entrypoint.s',entry+'\n')
    before=str(B.P/'joint');after=str(d)
    for phase in['main','rogue-component','union','bbox-local','gm-nmi','dk-component','reader']:
        cmd=json.loads((B.P/'joint'/(phase+'-build.json')).read_text())['command']
        B.run(d,[x.replace(before,after)for x in cmd],phase+'-build')
    objects=[]
    for n in['ff-component','publisher','loader','preview','stream','combat','terrain','pickups','veneers','typed-services']:
        cmd=[str(R/'tools/Windows/cc65/bin/ca65.exe'),'-g','--cpu','6502x','-I',str(d),'-I',str(R/'src'),
             '--bin-include-dir',str(d),'--bin-include-dir',str(R),'--create-full-dep',str(d/(n+'.dep')),'-o',str(d/(n+'.o')),str(d/(n+'.s'))]
        B.run(d,cmd,n+'-build');objects.append(str(d/(n+'.o')))
    cmd=json.loads((B.P/'joint/link-build.json').read_text())['command']
    cmd=[x.replace(before,after)for x in cmd]+objects
    B.run(d,cmd,'link-build');prepare(R,d/'candidate.nes')
    b=qualified(d/'candidate.nes');old=qualified(P/'joint/candidate.nes');raw=b['raw'];base=old['raw']
    lo=16+62*8192+0xa00;hi=16+62*8192+0x1690
    diff=[i for i,(a,z)in enumerate(zip(raw,base))if a!=z]
    assert all(lo<=i<hi for i in diff),'Typed services changed foreign bytes'
    assert(d/'ram3.bin').read_bytes()==(P/'joint/ram3.bin').read_bytes()
    size=address(b,'FwSvcEnd')-address(b,'FwSvcBegin');assert address(b,'FwSvcEnd')<=0xb690
    moved={n:[s['val'],b['syms'].get(n,{}).get('val')]for n,s in old['syms'].items()if b['syms'].get(n,{}).get('val')!=s['val']}
    assert not moved,moved
    files=set(map(Path,proof['bindings']))|{P/'source-closure.json',P/'semantic-controls.json',Path(__file__),src}
    for p in d.glob('*.dep'):files.update(dependencies(p))
    files.update(Path(x)for x in cmd if x.endswith('.o'));files.update(p for p in O.rglob('*')if p.is_file())
    B.save(O/'source-closure.json',dict(passed=True,native=False,admitted=False,common_mutated=False,
       candidate_sha256=sha(d/'candidate.nes'),parent_sha256=sha(P/'joint/candidate.nes'),
       adapter_bytes=size,adapter_start=hex(address(b,'FwSvcBegin')),adapter_end=hex(address(b,'FwSvcEnd')),
       changed_bytes=len(diff),only_ownROM62=True,all_previous_publicPCs_exact=True,RAM3_CHR_header_nativehook_exact=True,
       bindings={str(p.resolve()):sha(p)for p in sorted(files)}))
    print('TYPED SOURCE',sha(d/'candidate.nes'),'adapter',size,flush=True)

if __name__=='__main__':main()
