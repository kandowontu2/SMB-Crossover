"""Private genuine fast-v6 + FF-v13 producer composition. No native/admission."""
from pathlib import Path
import hashlib,json,re,subprocess,sys

R=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
from prepare_ff_current_component_v2 import qualified
from finalize_ff_current_component_v3 import dependencies
from prepare_cv3_dmc_mirror import prepare
from check_tmnt_render_oa import address,location

P=R/'build/character-host-union-rogue-fast-v6'
F=R/'build/final-fantasy-wram-host-v13'
O=R/'build/final-fantasy-joint-source-v1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def save(p,d):p.write_text(json.dumps(d,indent=2)+'\n',newline='\n')
def write(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,newline='\n')
def validate(p,expected):
    assert sha(p)==expected,(str(p),'handoff changed')
    h=json.loads(p.read_text());bindings=h.get('bindings',{})
    assert bindings,p
    for path,digest in bindings.items():assert sha(path)==digest,path
    return set(map(Path,bindings))|{p}

def run(d,cmd,phase):
    result=subprocess.run(cmd,cwd=R,capture_output=True,text=True)
    save(d/(phase+'.json'),dict(command=cmd,returncode=result.returncode,stdout=result.stdout,stderr=result.stderr))
    print(phase,result.returncode,flush=True)
    assert result.returncode==0,result.stderr[-18000:]

def copy_sources(d):
    for p in (P/'joint').rglob('*'):
        if p.is_file()and p.suffix in ['.s','.inc','.cfg']:
            q=d/p.relative_to(P/'joint');q.parent.mkdir(exist_ok=True,parents=True);q.write_bytes(p.read_bytes())

def compile(d,ff=False):
    before=str(P/'joint');after=str(d)
    for phase in ['main','rogue-component','union','bbox-local','gm-nmi','dk-component','reader']:
        cmd=json.loads((P/'joint'/(phase+'-build.json')).read_text())['command']
        cmd=[x.replace(before,after)for x in cmd]
        run(d,cmd,phase+'-build')
    extra=[]
    if ff:
        for n in ['ff-component','publisher','loader','preview','stream','combat','terrain','pickups','veneers']:
            cmd=[str(R/'tools/Windows/cc65/bin/ca65.exe'),'-g','--cpu','6502x','-I',str(d),'-I',str(R/'src'),
                 '--bin-include-dir',str(d),'--bin-include-dir',str(R),'--create-full-dep',str(d/(n+'.dep')),
                 '-o',str(d/(n+'.o')),str(d/(n+'.s'))]
            run(d,cmd,n+'-build');extra.append(str(d/(n+'.o')))
    cmd=json.loads((P/'joint/link-build.json').read_text())['command']
    cmd=[x.replace(before,after)for x in cmd]+extra
    run(d,cmd,'link-build');prepare(R,d/'candidate.nes')
    return cmd

def add_ff(d):
    for n in ['ff-component.s','publisher.s','loader.s','preview.s','combat.s','terrain.s','pickups.s','ff-host-health.inc','veneers.s','stream.s','ff-cookie.bin','ff-stream.bin']:
        (d/n).write_bytes((F/n).read_bytes())
    # Keep the actual joint screen producer; replacing the already-existing
    # native farcall's three immediate operands does not move any instruction.
    candidates=[]
    for p in dependencies(P/'joint/main.dep'):
        if p.name=='screen_render.s':candidates.append(p)
    assert len(candidates)==1,candidates
    s=candidates[0].read_text();needle='farcall MoveAllSpritesOffscreen ;initialize all sprites including sprite #0'
    assert s.count(needle)==1
    write(d/'screen_render.s','.import FwSceneInit\n'+s.replace(needle,'farcall FwSceneInit ; private FF loader, genuine Move remains first'))
    entry=(d/'entrypoint.s').read_text();assert entry.count('nes2wram $2000')==1
    entry=entry.replace('nes2wram $2000','nes2wram $8000')
    # Source-defined genuine imports, never old DBG absolute aliases.
    names={}
    for n in ['ff-component','loader','preview','combat','terrain','pickups']:
        for match in re.finditer(r'^\.import(zp)? (.+)$',(d/(n+'.s')).read_text(),re.M):
            for name in match[2].split(','):
                name=name.strip()
                if not name.startswith(('Ff','Fw')):names[name]=bool(match[1])or names.get(name,False)
    entry+='\n; Genuine exports for private FF separate objects.\n'+''.join('.export'+('zp'if zp else'')+' '+n+'\n'for n,zp in sorted(names.items()))
    write(d/'entrypoint.s',entry)
    cfg=(d/'private.cfg').read_text();mem,segs=cfg.split('SEGMENTS {',1)
    needle='X5_NEW_5D_AFTER_BBOX:start=$afe7,size=$1019,type=ro,file=%O,fill=yes,fillval=$ff,bank=$5d;'
    assert mem.count(needle)==1
    mem=mem.replace(needle,'X5_NEW_5D_AFTER_BBOX:start=$afe7,size=$19,type=ro,file=%O,fill=yes,fillval=$ff,bank=$5d;\n'
                    'FF_ART_MEM:start=$d000,size=$1000,type=ro,file=%O,fill=yes,fillval=$ff,bank=$5d;')
    needle='RECLAIMED_PARODIUS_CHR_MEM: start=$d9000,size=$27000,type=ro,fill=yes,file=%O,fillval=$00;'
    assert mem.count(needle)==1
    mem=mem.replace(needle,'PRIOR_PRIVATE_CHR_MEM:start=$d9000,size=$6400,type=ro,fill=yes,file=%O,fillval=$00;\n'
        'FF_STREAM_MEM:start=$df400,size=$2000,type=ro,fill=yes,file=%O,fillval=$00;\n'
        'UNALLOCATED_CHR_MEM:start=$e1400,size=$1ec00,type=ro,fill=yes,file=%O,fillval=$00;')
    mem=mem.rsplit('}',1)[0]+'FF_RAM3_MEM:start=$a000,size=$2000,bank=3,type=ro,file="'+(d/'ram3.bin').as_posix()+'",fill=yes,fillval=$ff;\n}\n'
    needle='    KAMIKAZE_CORE: load=X5_NEW_3E,type=ro,start=$b690,optional=yes;'
    assert segs.count(needle)==1
    segs=segs.replace(needle,'FF_RAM_PUBLISHER:load=FF_RAM3_MEM,type=ro,start=$a275;\n'
        'FINAL_FANTASY_CORE:load=FF_RAM3_MEM,type=ro,start=$aa00;\n'
        'FF_HOST_COMBAT:load=FF_RAM3_MEM,type=ro,start=$b700;\n'
        'FF_HOST_TERRAIN:load=FF_RAM3_MEM,type=ro,start=$b900;\n'
        'FF_HOST_PICKUPS:load=FF_RAM3_MEM,type=ro,start=$bb60;\n'
        'FF_ROM_HOST:load=X5_NEW_3E,type=ro,start=$aa00;\n'
        'FF_SERVICE_VENEERS:load=X5_NEW_3E,type=ro,start=$b400;\n'
        'FINAL_FANTASY_ART:load=FF_ART_MEM,type=ro;\n'
        'FINAL_FANTASY_CHR:load=TMNT_CHR_TAIL,type=ro,start=$bd000;\n'
        'FF_STREAM:load=FF_STREAM_MEM,type=ro;\n'+needle)
    write(d/'private.cfg',mem+'SEGMENTS {'+segs)

def main():
    assert not O.exists()
    files=validate(P/'handoff.json','e086635f6d798a36c50dff3cf0dbdfef5011021100bd2c5e1dd0a9f9edd6f275')
    files|=validate(F/'handoff.json','b02d60745a884d10955c03c29b1a4b50ba324b15c9547c7f7c70f8239670b2df')
    O.mkdir();rp=O/'reproduce';rp.mkdir();copy_sources(rp);compile(rp)
    assert (rp/'candidate.nes').read_bytes()==(P/'joint/candidate.nes').read_bytes(),'genuine fast-v6 reproduction differs'
    save(O/'reproduction.json',dict(passed=True,sha256=sha(rp/'candidate.nes'),source_linked=True))
    d=O/'joint';d.mkdir();copy_sources(d);add_ff(d);link=compile(d,True)
    b=qualified(d/'candidate.nes');old=qualified(P/'joint/candidate.nes')
    raw=b['raw'];base=old['raw'];ff=(F/'candidate.nes').read_bytes();cs=16+1048576
    assert (d/'ram3.bin').read_bytes()==(F/'ram3.bin').read_bytes(),'RAM3 source-linked payload changed'
    assert raw[10]==9 and base[10]==7
    ranges=[(10,11,'private32KBheader'),(16+62*8192+0xa00,16+62*8192+0x1690,'ownROM62'),
        (16+93*8192+0x1000,16+94*8192,'ownART93'),(cs+756*1024,cs+788*1024,'ownCHR756'),
        (cs+893*1024,cs+901*1024,'owncarrier893')]
    # The source hook preserves the full original instruction span/PCs.
    hook=location(old,'InitScreen');hook_end=hook+80
    changes=[i for i,(x,y)in enumerate(zip(base,raw))if x!=y]
    outside=[i for i in changes if not any(a<=i<z for a,z,n in ranges)]
    assert len(outside)==3 and all(hook<=i<hook_end for i in outside),outside
    assert raw[cs+893*1024:cs+901*1024]==(d/'ram3.bin').read_bytes()
    for a,z,n in ranges:
        if n in ['ownART93','ownCHR756']:assert raw[a:z]==ff[a:z],n
    moved={n:[s['val'],b['syms'].get(n,{}).get('val')]for n,s in old['syms'].items()if b['syms'].get(n,{}).get('val')!=s['val']}
    assert all('seg'not in old['syms'][n]and 'seg'not in b['syms'].get(n,{})for n in moved),moved
    assert set(moved)=={'_nes2_wramsize','LOCAL-MACRO_SYMBOL-002A'},moved
    for dep in [*rp.glob('*.dep'),*d.glob('*.dep')]:files.update(dependencies(dep))
    files.update(Path(x)for x in link if x.endswith('.o'))
    files.update(p for p in O.rglob('*')if p.is_file())
    files.add(Path(__file__))
    save(O/'source-closure.json',dict(status='PRIVATE_SOURCE_MERGE_NO_COMMON_ROUTE_CPU_PENDING',passed=True,native=False,admitted=False,
        candidate_sha256=sha(d/'candidate.nes'),parent_sha256=sha(P/'joint/candidate.nes'),FF_source_sha256=sha(F/'candidate.nes'),
        RAM3_sha256=sha(d/'ram3.bin'),changes=len(changes),native_hook_operands=outside,old_public_PCs_moved=0,
        allowed_ranges=[dict(start=a,end=z,name=n)for a,z,n in ranges],A79_exact=True,CHR_other_exact=True,
        limits=['Actual common FF/Arthur selection remains unmodified.','FF frontend remains pending.','Full rendering/palette and actual Main/BG typed natural routes pending.'],
        bindings={str(p.resolve()):sha(p)for p in sorted(files)}))
    print('SOURCE MERGE',sha(d/'candidate.nes'),flush=True)

if __name__=='__main__':main()
