; Genuine selected-FF native callback contracts. No new state. ROM62 only.
; Original v13 row23/24 were leaf plans: native23 is admission,24 collection.
.setcpu "6502"
.macpack longbranch
.import SelectedCharacter,GamePauseStatus,TimerControl,MmDeathFlag
.importzp GameEngineSubroutine,Enemy_Flag,Enemy_ID,Enemy_State,PowerUpType,PowerUpObject
.import FarCallCommon,SafecallA_SMC,FarcallJmpTarget_SMC
.import FwCheck,FwHostMovement,FwHostHead,FwHostSide,FwHostHeadWithin
.import FwHostBody,FwHostAdder,FwBox,FwHostBox,FwHostImpulseAccepted
.import BlockBufferColli_Head,BlockBufferColli_Side,Z2HeadWithinTerrain
.import JnBodyDispatch,RlAdderDispatch,RlBoxDispatch,LmBoundingBoxGate
.import MegaManClimbing,X5StompDispatch,X5SpringDispatch
.export FwSvcActive,FwSvcMovement,FwSvcHead,FwSvcSide,FwSvcHeadWithin
.export FwSvcBody,FwSvcAdder,FwSvcBoxProfile,FwSvcFullBox,FwSvcMature
.export FwSvcStomp,FwSvcSpring,FwSvcBegin,FwSvcEnd

.macro FWS_FAR target,tail
 sta SafecallA_SMC+1
 lda #<target
 sta FarcallJmpTarget_SMC+1
 lda #>target
 sta FarcallJmpTarget_SMC+2
 lda #.lobyte(.bank(target)|$80)
 .if .xmatch({tail},{jmp})
 jmp FarCallCommon
 .else
 jsr FarCallCommon
 .endif
.endmacro

.segment "FF_SERVICE_ADAPTERS"
FwSvcBegin:
; APXY preserved except resultC. No cookie lookup/execution on nonactive paths.
.proc FwSvcActive
 php
 pha
 lda SelectedCharacter
 cmp #22
 bne No
 lda GameEngineSubroutine
 cmp #8
 bne No
 lda GamePauseStatus
 and #1
 bne No
 lda TimerControl
 bne No
 lda MmDeathFlag
 bne No
 pla
 plp
 jmp FwCheck
No:pla
 plp
 clc
 rts
.endproc

; Actual PlayerMovementSubs already retains native engines4/5 before NrMovement.
; FF Cclear means source-climb handoff, so run genuine native climbing now.
.proc FwSvcMovement
 php
 jsr FwSvcActive
 bcc No
 plp
 jsr FwHostMovement
 bcs Done
 FWS_FAR MegaManClimbing
Done:rts
No:plp
 clc
 rts
.endproc

; Automatic4/5 and all inactive calls retain their old genuine native query.
.macro FWS_TYPED name,own,native
.proc name
 php
 jsr FwSvcActive
 bcc Legacy
 plp
 jmp own
Legacy:plp
 FWS_FAR native,jmp
.endproc
.endmacro
FWS_TYPED FwSvcHead,FwHostHead,BlockBufferColli_Head
FWS_TYPED FwSvcSide,FwHostSide,BlockBufferColli_Side
FWS_TYPED FwSvcHeadWithin,FwHostHeadWithin,Z2HeadWithinTerrain
FWS_TYPED FwSvcBody,FwHostBody,JnBodyDispatch
FWS_TYPED FwSvcAdder,FwHostAdder,RlAdderDispatch
FWS_TYPED FwSvcBoxProfile,FwBox,RlBoxDispatch
FWS_TYPED FwSvcFullBox,FwHostBox,LmBoundingBoxGate

; Native collision admission only: do not erase, score, freeze, or grant gear.
; Actual collection service24 independently invokes qualified FwHostCollect.
.proc FwSvcMature
 php
 pha
 jsr FwSvcActive
 bcc No
 cpx #6
 bcs No
 lda Enemy_Flag,x
 beq No
 bmi No
 lda Enemy_ID,x
 cmp #PowerUpObject
 bne No
 lda Enemy_State,x
 bpl No
 lda PowerUpType,x
 cmp #4
 bcs No
 pla
 plp
 sec
 rts
No:pla
 plp
 clc
 rts
.endproc

; The existing X5 profile genuinely includes raw22. These are disclosed native
; platform impulses; after acceptance FF keeps its own jump pose/gravity phase.
.proc FwSvcStomp
 php
 jsr FwSvcActive
 bcc No
 plp
 FWS_FAR X5StompDispatch
 jmp FwHostImpulseAccepted
No:plp
 clc
 rts
.endproc
.proc FwSvcSpring
 php
 jsr FwSvcActive
 bcc No
 plp
 FWS_FAR X5SpringDispatch
 jmp FwHostImpulseAccepted
No:plp
 clc
 rts
.endproc
FwSvcEnd:
