"""Bounded real linked DK host callers; no native or gameplay-seeding claim."""
from pathlib import Path
import argparse,itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(R/'tools/audit'),str(R/'tools'),str(R/'tools/reference')]
import supermaaa_host_controls_v1 as M
from sunny_integrated_controls_v1 import *
O=R/'build/donkey-kong-host-v1';P=R/'build/pit-retold-host-v3'

def setup(b,char=28):
 q=M.C.setup(b,char)
 if char==28:run(q,'DkConstruct')
 return q
def point(b,n):return((location(b,n)-16)//8192,address(b,n))
def feature_controls(b,old,ck):
 import donkey_kong_component_controls_v1 as A
 import dragon_power_gameplay_render_v3 as D
 import hashlib
 # Palette packet boundaries: only P0 changes, never native enemy/item P1..3.
 for offset in range(84):
  q=setup(b);base=address(b,'VRAM_Buffer1');q.m[base:base+85]=bytes((i*13+3)&255 for i in range(85));before=bytes(q.m[base:base+85])
  q.put(VRAM_Buffer1_Offset=offset,DkPaletteAck=255);run(q,'DkQueuePalette');after=bytes(q.m[base:base+85])
  if offset<78:
   assert after[:offset]==before[:offset] and after[offset:offset+7]==bytes.fromhex('3f110330270600') and after[offset+7:]==before[offset+7:]
   assert q.get('VRAM_Buffer1_Offset')==offset+6 and q.get('DkPaletteAck')==0
  else:assert before==after and q.get('VRAM_Buffer1_Offset')==offset and q.get('DkPaletteAck')==255
 ck['P0_only_atomic_palette']=dict(cases=84,world_P1_P2_P3_untouched=True,explicit_source_quantization={'36':'27','02':'06'})
 source=(R/'build/dk-playable-assets-v3/dk.chr').read_bytes();patterns=(O/'dk-p0.chr').read_bytes();bodyrows=[]
 for pose,face,outline in itertools.product(range(9),[1,2],range(2)):
  q=setup(b);q.put(PlayerFacingDir=face,PlayerOutlinesOff=outline,Player_Y_Position=100,Player_Rel_YPos=100,CurrentOAMOffset=0,Player_SprAttrib=32)
  run(q,'DkSetPose',x=pose);at=address(b,'DkRenderBuffer');rec=bytes(q.m[at:at+q.m[at]+1]);page=q.get('DkRenderPage')-(820&255)
  assert A.raster(rec,patterns[page*1024:(page+1)*1024])==A.raster(rec,source[page*1024:(page+1)*1024])
  c,events,mn,tr=D.draw(q);owned=[e for e in events if e['ptr']==at];assert len(owned)==1 and owned[0]['accepted']
  e=owned[0];actual=bytearray(48*32);o=bytes.fromhex(e['OAM_after'])
  for i in range(e['header']-4,-1,-4):
   off=(e['before']+i+e['rotation'])&255;sy,t,attr,sx=[o[(off+k)&255]for k in range(4)]
   assert t<64 and attr&32 and not attr&3
   for yy in range(16):
    py=15-yy if attr&128 else yy;tile=(t&254)+py//8;lo=page*1024+tile*16+py%8
    for xx in range(8):
     px=7-xx if attr&64 else xx;v=(patterns[lo]>>(7-px)&1)|((patterns[lo+8]>>(7-px)&1)<<1)
     if v:
      dx=sx-96+16+xx;dy=sy+1-100+yy;assert 0<=dx<48 and 0<=dy<32
      actual[dy*48+dx]=v
  assert actual==A.raster(rec,patterns[page*1024:(page+1)*1024]),('actual full DrawAll source pixels',pose,face,outline)
  bodyrows.append([pose,face,outline,e['header'],c.processorCycles,mn])
 ck['all_original_body_poses_actual_DrawAll']=dict(cases=len(bodyrows),rows=bodyrows,original_opacity_geometry_HV_palette_classes_exact=True,source36_to27_palette_adaptation_only=True,real_priority_bit_preserved=True)
 # Native contact owner, true armor/Bowser paths. The only created projectile
 # is the genuine typed B attack and its source age16 spawn event.
 rows=[]
 for kind,face,slot in itertools.product([0,2,6,8,12,13,18,21,45],[1,2],range(6)):
  q=setup(b);q.put(PlayerFacingDir=face,SavedJoypadBits=64)
  run(q,'DkClock')
  for age in range(16):run(q,'DkClock')
  run(q,'DkSpawnBarrel');assert q.get('DkShots')
  x=q.get('DkShots',4)+256*q.get('DkShots',5);y=q.get('DkShots',6)
  M.C.actor(q,slot,kind,x,y);q.put(ObjectOffset=(slot+1)%6,BowserHitPoints=5)
  c,tr,mn=M.C.M.runtrace(q,'DkBarrelActors',x=0)
  admitted=kind<21 or kind==45
  assert (point(b,'HandleEnemyFBallCol')in tr)==admitted,('native actor owner admission',kind,slot)
  if admitted:
   assert q.get('DkShots')==0
   if kind==45:assert q.get('BowserHitPoints')==4
   elif kind in[2,8,12]:assert not q.get('Enemy_State',slot)&32
   else:assert q.get('Enemy_State',slot)&32 and q.get('FloateyNum_Control',slot)>0
  else:assert q.get('DkShots')
  rows.append([kind,face,slot,c.processorCycles,mn])
 ck['actual_B_age16_native_barrel_contact_owners']=dict(cases=len(rows),native_fireproof_and_hazard_exclusions=True,Bowser_actual_HP_owner=True,real_score_drop_defeat_owner=True,rows=rows)
 # Real retained image, then the original no-draw Main Vine path. Check all
 # physical rotation alignments and the three genuine variable body sizes.
 rows=[]
 for pose,pivot in itertools.product([0,3,8],range(0,256,4)):
  q=setup(b);q.put(Player_Y_Position=100,Player_Rel_YPos=100,RgOamFirst=pivot,RgOamUsed=252,FrameCounter=0)
  run(q,'DkSetPose',x=pose);c,events,mn,tr=D.draw(q);e=[e for e in events if e['ptr']==address(b,'DkRenderBuffer')][0];assert e['accepted']
  slots=[(e['before']+i+e['rotation'])&255 for i in range(e['header'])];before=bytes(q.m[512:768]);M.C.actor(q,5,47,128,80)
  q.put(Vine_FlagOffset=1,Vine_Height=96,ShouldSkipDrawSprites=1,FramesSinceLastSpriteDraw=0,ObjectOffset=5);q.set('Vine_ObjOffset',5,0)
  c,tr,mn=M.C.M.runtrace(q,'GameLoop');assert point(b,'VineObjectHandler')in tr and point(b,'DrawAllMetasprites')not in tr
  assert all(q.m[512+i]==before[i]for i in slots),('retained body overwritten',pose,pivot,e)
  rows.append([pose,pivot,e['header'],c.processorCycles,mn])
 ck['actual_no_draw_Main_Vine_retained_variable_body']=dict(cases=len(rows),rows=rows,all_64_rotations=True,native_Vine_priority_palette_and_tiles_retained=True)
 rows=[]
 for cursor,pivot in itertools.product(range(0,256,4),range(0,256,4)):
  q=setup(b);q.put(GuestOamRotationActive=1,RgOamRotation=pivot,RgOamPlayerStart=0,DkPublishedSize=48,CurrentOAMOffset=cursor,Enemy_Rel_XPos=128,Enemy_Rel_YPos=80,Vine_Start_Y_Position=80)
  q.m[512:768]=bytes((i*17)&255 for i in range(256));before=bytes(q.m[512:768]);c,tr,mn=M.C.M.runtrace(q,'DkHostVine',y=0)
  logical=max(48,cursor);allowed=logical<232;writes=[a-512 for a,v in q.m.writes if 512<=a<768];want={(logical+pivot+i)&255 for i in range(24)}if allowed else set()
  assert set(writes)==want and not want&{(pivot+i)&255 for i in range(48)},('Vine capacity ownership',cursor,pivot)
  assert q.get('CurrentOAMOffset')==(logical+24 if allowed else cursor)
  assert not any(768<=a<1024 for a,v in q.m.writes)
  rows.append([cursor,pivot,int(allowed),c.processorCycles,mn])
 ck['Vine_capacity_all_physical_alignments']=dict(cases=len(rows),accepted=sum(r[2]for r in rows),no_300spill_or_body_overlap=True,CPU=[min(r[3]for r in rows),max(r[3]for r in rows)])

def terrain_lifecycle_controls(b,ck):
 rows=[]
 for mode,tile in itertools.product(range(2),[0x51,0x55,0xc0]):
  q=setup(b);q.put(CrossoverBehaviorVersion=mode);cell=address(b,'Block_Buffer_1')+0x70+6;q.m[cell]=tile;found=False
  for age in range(48):
   q.put(SavedJoypadBits=128 if 1<=age<20 else 0,NmiDisable=255,VRAM_Buffer1_Offset=0)
   c,tr,mn=M.C.M.runtrace(q,'GameLoop')
   if point(b,'PlayerHeadCollision')in tr:
    assert point(b,'DkHostHead')in tr and q.get('PlayerSize')==0
    rows.append([mode,tile,age,c.processorCycles,mn,q.m[cell]]);found=True;break
  assert found,('real wide DK jump/block',mode,tile)
 ck['actual_full_Main_jump_head_native_block']=dict(cases=len(rows),rows=rows,real_native_block_coin_score_owners=True)
 # All probe cells are read from real two-column buffers, with native result
 # tuple, and without editing player position or the caller's R0/R1/Local_eb.
 rows=[]
 for x,y,which in itertools.product([1,96,254,256,511],[32,100,176],['DkHostHead','DkHostFeet','DkHostSide']):
  q=setup(b);q.put(Player_X_Position=x&255,Player_PageLoc=x>>8,Player_Y_Position=y,Local_eb=0);q.set('R0',173);q.set('R1',94)
  for base in ['Block_Buffer_1','Block_Buffer_2']:
   for row in range(13):
    for col in range(16):q.m[address(b,base)+16*row+col]=0x61
  before=[q.get(n)for n in['Player_X_Position','Player_PageLoc','Player_Y_Position','R0','R1','Local_eb']]
  for yy in ([0]if which=='DkHostHead'else[0,1]if which=='DkHostFeet'else[3,4,5,6]):
   c,tr,mn=M.C.M.runtrace(q,which,y=yy)
   assert [q.get(n)for n in['Player_X_Position','Player_PageLoc','Player_Y_Position','R0','R1','Local_eb']]==before
   assert c.a==0x61 and q.get('R3')==0x61 and c.x==0
   rows.append([which,x,y,yy,c.y,q.get('R2'),q.get('R4'),c.processorCycles])
 ck['signed_world_head_feet_side_native_query_tuple']=dict(cases=len(rows),rows=rows,source_bounds_left=-13,right=29,bottom=32,no_temporary_player_or_live_scratch_rewrite=True)
 q=setup(b)
 for kind in[0,0]:
  q.set('PowerUpType',kind,5);q.set('Enemy_State',128,5);q.set('Enemy_Flag',1,5);run(q,'NrPickup',x=5)
  for age in range(60):run(q,'PlayerChangeSize')
 assert q.get('DkTier')==2
 q.put(AreaPointer=0xc2);run(q,'DkEnsure');assert q.get('DkTier')==2
 q.put(AreaAddrsLOffset=6);run(q,'DkEnsure');assert q.get('DkTier')==2
 q.put(AreaType=2);run(q,'DkEnsure');assert q.get('DkTier')==2 and q.get('DkArea')==0x46
 # Real 1-Up credit before Ensure, never a seeded increment in this case.
 before=q.get('NumberofLives');M.C.actor(q,5,46,96,176);q.set('PowerUpType',3,5);q.set('Enemy_State',128,5);run(q,'NrPickup',x=5)
 for age in range(8):
  q.put(SavedJoypadBits=0,NmiDisable=255,VRAM_Buffer1_Offset=0);c,tr,mn=M.C.M.runtrace(q,'GameLoop');M.T.nmi(q,c)
 assert q.get('NumberofLives')==before+1,('actual delayed life credit',before,q.get('NumberofLives'),q.get('FloateyNum_Control',5),q.get('FloateyNum_Timer',5))
 run(q,'DkEnsure');assert q.get('DkTier')==2
 q.put(GuestPowerupActive=0,GameEngineSubroutine=8,InjuryTimer=0);run(q,'InjurePlayer');assert q.get('DkTier')==1 and q.get('InjuryTimer')==90
 q.put(InjuryTimer=0);run(q,'InjurePlayer');assert q.get('DkTier')==0
 q.put(InjuryTimer=0);run(q,'InjurePlayer');assert q.get('GameEngineSubroutine')==11 and q.get('MmDeathFlag')==1
 run(q,'NrFreshGameInit');assert q.get('DkTier')==0 and q.get('DkReady')==0x44
 ck['earned_upgrades_real_1Up_scene_damage_death_fresh']=dict(actual_earned_two_Mushrooms=True,true_1Up_writer=True,stable_loaded_scene_key=True,tier_preserved_same_life_scene_and_1Up=True,native_tier_shield_then_death=True)

def router_isr_controls(b,old,ck):
 import re
 from donkey_kong_host_routes_v1 import TARGETS
 source=next(Path(p)for p in __import__('json').loads((P/'closure.json').read_text())['actual_dependencies']if Path(p).name=='new_roster_dispatch.s')
 rows=re.findall(r'^NrGate (\w+),(\w+),(\w+),(\w+),(\w+)$',source.read_text(),re.M);assert len(rows)==11
 def reach(q,entry,target,flags):
  bk,pc=point(q.b,entry);q.m.page(1,bk);q.set('CurrentBank',bk|128);q.m.writes=[]
  c=NesMPU(memory=q.m,pc=pc);c.a,c.x,c.y,c.p,c.sp=91,7,55,flags,253;c.stPushWord(0x5aff);want=point(q.b,target)
  for _ in range(2000):
   here=(q.m.banks[(c.pc-0x8000)//8192],c.pc)
   if here==want:return c
   assert q.m[c.pc]!=0,('router BRK',entry,target,here);c.step()
  raise AssertionError(('router target not reached',entry,target,hex(c.pc)))
 count=0;costs=[];stacks=[]
 pairs={(raw,f)for raw in range(256)for f in[0x30,0x31,0x70,0xf3]}|{(raw,f)for raw in[0,20,21,23,28,255]for f in range(256)if f&0x30==0x30}
 for index,row in enumerate(rows):
  entry=row[0];assert point(old,entry)==point(b,entry),('public97B slot moved',entry)
  for raw,flags in sorted(pairs):
   target=TARGETS[index]if raw==28 else row[{20:1,21:2,23:3}.get(raw,4)]
   q=M.C.setup(b,raw);c=reach(q,entry,target,flags);assert(c.a,c.x,c.y)==(91,7,55);stacks.append(c.sp)
   if raw!=28:
    z=M.C.setup(old,raw);d=reach(z,entry,target,flags)
    assert registers(c)==registers(d)and M.C.M.fastapp(q)==M.C.M.fastapp(z)and q.m.banks==z.m.banks,('full target entry ABI',entry,raw,flags,registers(c),registers(d))
    wa=[(i,v)for i,v in z.m.writes if i in smc_at(old)];wb=[(i,v)for i,v in q.m.writes if i in smc_at(b)]
    assert wa==wb,('ordered5SMC preparation',entry,raw,flags,wa,wb)
    costs.append(c.processorCycles-d.processorCycles)
   count+=1
 ck['genuine_router_target_entry_all_raw_flags']=dict(cases=count,all256raw_orthogonal_all64flags=True,raw24_25_26_27_remain_exact_legacy=True,owned_target_AXY_preserved=True,foreign_AXYP_SP_allapplication_banks_ordered5SMC_exact=True,all11public97B_entries_exact=True,entry_CPU_delta=[min(costs),max(costs)],target_entry_minimum_SP=min(stacks))
 # Actual reached complete Main boundaries, including every target SMC store
 # and body/terrain/native contact callbacks, under real IRQ and lag NMI.
 q=setup(b);q.put(SavedJoypadBits=129);c,tr,mn=M.C.M.runtrace(q,'GameLoop');common=address(b,'DkNrCommon')
 points=sorted(set(z for z in tr if(z[0]==124 and common<=z[1]<common+64)))
 for name in['DkHostDraw','DkHostGraphics','DkHostHead','DkHostFeet','DkHostSide','DkHostBox','DkMovement']:
  if point(b,name)in tr:points.append(point(b,name))
 events=[]
 for kind,cut in itertools.product(['IRQ','NMI'],points):
  q=setup(b);q.put(SavedJoypadBits=129,NmiDisable=255)
  c,_,mn,_,hit=M.ISR.interrupt_actual(q,'GameLoop',flags=0x30,inject=cut,kind=kind,a=0);assert hit;events.append([kind,*cut,mn])
 ck['real_Main_IRQ_lag_NMI_partial_SMC']=dict(cases=len(events),events=events,physical_IRQ_context_exact=True,only_proven_literal_pending_C_STA_NMI_normalization=M.ISR.SHADOW_WINDOWS,AXYP_SP_active_stack_application5C_5F_banks_and5SMC_exact=True)
 rows=[]
 for mode in range(2):
  q=setup(b);q.put(CrossoverBehaviorVersion=mode,DisableScreenFlag=0,Mirror_PPUCTRL=168,Mirror_PPUMASK=30)
  costs=[]
  for age in range(96):
   q.put(SavedJoypadBits=128 if 5<=age<15 else 64 if age in[28,62]else 0)
   c,tr,mn=M.C.M.runtrace(q,'GameLoop');assert q.get('NmiDisable')==0
   q.m.writes=[];ni=M.T.nmi(q,c);costs.append(ni)
   assert any(a==0x4014 for a,v in q.m.writes)and q.get('NmiDisable')==255
   assert q.m.banks[2]==12 and q.get('CurrentBankC')==140
   assert q.get('ReloadCHRBank')==0 and q.get('DkPaletteAck')==0
  rows.append([mode,min(costs),max(costs),mn])
 ck['consecutive_real_Main_normal_NMI_CHR_DMA']=dict(updates=192,rows=rows,genuine_source_instructions_only=True,normal_DMA_and_C12_owner=True,no_PPU_alignment_or_native_deadline_claim=True)

def menu_pointer_controls(b,old,ck):
 rows=[]
 for mode,face,keys in itertools.product(range(2),[1,2],[0,1,129]):
  pair=[]
  for v in[old,b]:
   q=M.C.setup(v,1);q.put(ProtoVariant=1,PlayerFacingDir=face,CrossoverBehaviorVersion=mode,SavedJoypadBits=keys)
   c,tr,mn=M.C.M.runtrace(q,'GameLoop',p=0x71)
   assert point(v,'ProtoPoseSelector')in tr
   pair.append((registers(c),M.C.M.fastapp(q),tuple(q.m.banks),c.processorCycles))
  assert pair[0][:3]==pair[1][:3],('actual whole Main Proto C65 consumer',mode,face,keys)
  rows.append(pair[1][-1]-pair[0][-1])
 assert old['raw'][16+65*8192:16+65*8192+0x1c00]==b['raw'][16+65*8192:16+65*8192+0x1c00]
 table=[]
 for k in range(address(old,'ProtoPoseRightHi')-address(old,'ProtoPoseRightLo')):
  for face in['Right','Left']:
   lo=location(old,'ProtoPose'+face+'Lo')+k;hi=location(old,'ProtoPose'+face+'Hi')+k
   ptr=old['raw'][lo]+256*old['raw'][hi];assert 0xc000<=ptr<0xdc00
   header=old['raw'][16+65*8192+ptr-0xc000];assert ptr+header+1<=address(old,'ProtoArtEnd')
   table.append([face,k,ptr,header])
 ck['C65_head_old_Proto_full_record_pointer_lease']=dict(actual_complete_Main_consumers=len(rows),all_live_AXYP_SP_application_OAM_CHR_banks_exact=True,Main_CPU_delta=[min(rows),max(rows)],pointer_records=len(table),record_end_max=max(r[2]+r[3]+1 for r in table),all_old_C65_before_DC00_literal_exact=True,new_A65_BC00_has_true_A_labels_not_C_aliases=True)
 rows=[]
 for caller in['DrawSelectionPreview','DrawPlayer_Intermediate','X5PortraitRender']:
  q=setup(b);q.put(CrossoverMenuIndex=27,OperMode=0 if caller=='DrawSelectionPreview'else 1,Player_X_Position=120,Player_Rel_XPos=120,Player_Y_Position=112,Player_Rel_YPos=112,CurrentOAMOffset=0)
  if caller=='X5PortraitRender':run(q,'DrawPlayer_Intermediate')
  c,tr,mn=M.C.M.runtrace(q,caller)
  assert q.m.banks[2]==12 and q.get('SmPosePtr')==address(b,'DkRenderBuffer')&255
  assert q.get('DkPose')==9
  if caller!='DrawPlayer_Intermediate':assert any(a==0x5120 or a==address(b,'X5ChrMode')for a,v in q.m.writes)or q.get('X5ChrMode')==0x83
  rows.append([caller,c.processorCycles,mn,q.get('CurrentOAMOffset')])
 q=setup(b);q.put(VRAM_Buffer1_Offset=0);q.m[address(b,'VRAM_Buffer1'):address(b,'VRAM_Buffer1')+84]=bytes([204])*84
 run(q,'QueueSelectName',a=91,x=7,y=55,p=0x71);start=address(b,'VRAM_Buffer1');assert bytes(q.m[start+3:start+19])==b['raw'][location(b,'DkMenuName::Name'):location(b,'DkMenuName::Name')+16]
 q=setup(b);start=address(b,'VRAM_Buffer1');q.m[start+11:start+19]=bytes([204])*8;c,tr,mn=M.C.M.runtrace(q,'CrossoverPatchStatusName',a=0,x=7,y=55,p=0x71)
 assert c.x==7 and c.y==55 and q.m[start+18]==204 and bytes(q.m[start+11:start+18])==b['raw'][location(b,'DkHostName::Name'):location(b,'DkHostName::Name')+7]
 ck['actual_menu_lives_portrait_name_status']=dict(rows=rows,C12_genuine_high_CHR_publisher=True,true_compact_source_portrait=True,menu_16cell_and_status7cell_canaries=True,status_XY_preserved=True)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--section',choices=['smoke','full','features','terrain','router','menu'],default='full');a=ap.parse_args()
 b=scoped_load(O/'candidate.nes');old=scoped_load(P/'candidate.nes')
 started={str(p.resolve()):sha(p)for p in[Path(__file__),O/'candidate.nes',O/'candidate.dbg',O/'candidate.lbl']}
 proof=dict(passed=False,source_CPU_only=True,native_run=False,candidate=sha(O/'candidate.nes'),checks={});ck=proof['checks']
 try:
  # Actual cold resolver, including a foreign overlay with the same ready
  # canary. No field is read on the assumption that a canary proves owner.
  q=M.C.setup(b,23);q.m[0x5c00:0x5c80]=bytes([0x44])*128
  q.put(CrossoverMenuIndex=27,MarioVariant=0,CrossoverContinue=0)
  c,tr,mn=M.C.M.runtrace(q,'MenuResolveCharacter')
  assert q.get('SelectedCharacter')==28 and q.get('DkTier')==0 and q.get('DkReady')==0x44
  assert point(b,'DkConstruct')in tr
  q.set('DkTier',2);q.put(PlayerStatus=2,CrossoverContinue=1)
  M.C.M.runtrace(q,'MenuResolveCharacter');assert q.get('DkTier')==2
  ck['actual_menu_constructor']=dict(cold_raw28=True,foreign_false_ready_rejected=True,same_owner_continue_preserves_tier=True,minimum_SP=mn)
  # Complete actual Main, with genuine controller clocks and actual native
  # floor; source arenas initialize scenes, not native-route resources.
  rows=[]
  for mode,face in itertools.product(range(2),[1,2]):
   q=setup(b);q.put(CrossoverBehaviorVersion=mode,PlayerFacingDir=face)
   costs=[];births=[]
   for age in range(100):
    keys=(1 if face==1 else 2)if age<4 else 0
    if 5<=age<15:keys|=128
    if age in[26,61]:keys|=64
    q.put(SavedJoypadBits=keys,NmiDisable=255,VRAM_Buffer1_Offset=0)
    c,tr,mn=M.C.M.runtrace(q,'GameLoop');costs.append(c.processorCycles)
    if point(b,'DkSpawnBarrel')in tr and q.get('DkShots'):
     births.append([age,q.get('DkShots+3')if'DkShots+3'in b['syms']else q.m[address(b,'DkShots')+3]])
    assert q.get('PlayerSize')==0 and q.get('Player_BoundBoxCtrl')==0
    assert q.get('CurrentBank')&127==q.m.banks[1] and q.get('CurrentBankC')&127==q.m.banks[2]
   assert births,('no genuine B release',mode,face)
   rows.append([mode,face,min(costs),max(costs),mn,births[:3]])
  ck['actual_complete_Main']=dict(updates=400,rows=rows,controller_B_clock_and_native_floor=True)
  # Mature physical pickup, exact real actor slot, true erase and score.
  rows=[]
  for slot,mode,kind,mature in itertools.product(range(6),range(2),range(2),[0,128]):
   q=setup(b);q.put(CrossoverBehaviorVersion=mode,ObjectOffset=(slot+1)%6)
   M.C.actor(q,slot,0x2e,96,176);q.set('PowerUpType',kind,slot);q.set('Enemy_State',mature,slot)
   c,tr,mn=M.C.M.runtrace(q,'NrPickup',x=slot)
   if mature:
    assert q.get('Enemy_Flag',slot)==0 and q.get('DkTier')==kind+1
    assert q.get('FloateyNum_Control',slot)==6 and q.get('Square2SoundQueue')==32
    assert point(b,'EraseEnemyObject')in tr and point(b,'SetupFloateyNumber')in tr
    for _ in range(60):M.C.M.runtrace(q,'PlayerChangeSize')
    assert q.get('PlayerSize')==0 and q.get('PlayerStatus')==q.get('DkTier') and q.get('GuestPowerupActive')==0
   else:assert q.get('Enemy_Flag',slot)==1 and q.get('DkTier')==0
   rows.append([slot,mode,kind,mature,c.processorCycles,mn])
  ck['actual_mature_pickup_and_complete_freeze']=dict(cases=len(rows),rows=rows)
  if a.section in ['full','features']:feature_controls(b,old,ck)
  if a.section in ['full','terrain']:terrain_lifecycle_controls(b,ck)
  if a.section in ['full','router']:router_isr_controls(b,old,ck)
  if a.section in ['full','menu']:menu_pointer_controls(b,old,ck)
  if a.section=='full':
   rows=[]
   variants=[(0,'MarioVariant',1),(0,'MarioVariant',3),(0,'MarioVariant',4),(1,'ProtoVariant',1),(3,'BillVariant',1),(4,'Z2Variant',1),(5,'Cv3Variant',1),(5,'Cv3Variant',2),(5,'Cv3Variant',3),(6,'PitVariant',1),(9,'RlVariant',1),(12,'DarkwingVariant',1),(13,'KbVariant',1),(14,'CdVariant',1),(15,'MacVariant',1),(15,'MacVariant',2),(17,'M3Variant',1),(18,'VvVariant',1),(18,'VvVariant',2),(18,'VvVariant',3),(19,'TnVariant',1),(19,'TnVariant',2),(19,'TnVariant',3),(20,'IcVariant',1),(21,'RcVariant',1)]
   matrix=[(ch,None,0,mode,keys)for ch,mode,keys in itertools.product(list(range(22))+[23],range(2),[0,1,129])]+[(ch,key,var,mode,129)for ch,key,var in variants for mode in range(2)]
   for char,key,var,mode,keys in matrix:
    pair=[]
    for bundle in[old,b]:
     q=setup(bundle,char);q.put(CrossoverBehaviorVersion=mode,SavedJoypadBits=keys)
     if key=='PitVariant':q.m[0x5fe0]=var
     elif key:q.set(key,var)
     c,tr,mn,annotations,events=M.run_linked(q,'GameLoop',p=0x71)
     state=(registers(c),M.C.M.fastapp(q),tuple(q.m.banks))
     writes=[(i,v)for i,v in q.m.writes if not 0x100<=i<0x200 and not 0x5114<=i<=0x5117 and i not in smc_at(bundle)]
     pair.append((q,c,tr,mn,state,writes))
    qa,ca,ta,ma,sa,wa=pair[0];qb,cb,tb,mb,sb,wb=pair[1]
    assert sa==sb,('foreign complete Main state',char,mode,keys,sa[0],sb[0])
    assert wa==wb,('foreign complete Main writes',char,mode,keys)
    M.smc_contract(qa,qb,ta,tb)
    rows.append([char,key,var,mode,keys,cb.processorCycles-ca.processorCycles,mb])
   ck['foreign_complete_Main']=dict(cases=len(rows),rows=rows,full_AXYP_SP_application_OAM_CHR_banks_exact=True,ordered_nonstack_nonmapper_nonSMC_writes_exact=True,inactive_stack_bytes_reported_as_architecturally_dead_not_live=True)
  assert all(sha(p)==h for p,h in started.items()),'Input changed during controls'
  proof['passed']=True
 except Exception as e:proof.update(failure=repr(e),traceback=traceback.format_exc())
 proof['bindings']={str(p.resolve()):sha(p)for p in[Path(__file__),O/'candidate.nes',O/'candidate.dbg',O/'candidate.lbl',P/'candidate.nes',Path(M.__file__),R/'tools/reference/donkey_kong_host_v1.s']}
 (O/('controls-'+a.section+'.json')).write_text(json.dumps(proof,indent=2)+'\n')
 if not proof['passed']:
  with(O/'negative-ledger.jsonl').open('a')as f:f.write(json.dumps(dict(candidate=proof['candidate'],failure=proof['failure'],completed=list(ck)))+'\n')
 print(json.dumps(dict(passed=proof['passed'],failure=proof.get('failure'),completed=list(ck))))
 assert proof['passed']
if __name__=='__main__':main()
