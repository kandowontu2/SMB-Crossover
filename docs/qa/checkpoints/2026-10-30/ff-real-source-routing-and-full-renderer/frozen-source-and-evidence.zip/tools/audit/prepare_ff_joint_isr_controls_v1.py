"""Derive unchanged real-vector assertions with explicit new-source bindings."""
from pathlib import Path
import hashlib,json,subprocess,sys
R=Path(__file__).resolve().parents[2]
p=R/'tools/audit/ff_wram_host_isr_v8.py'
q=R/'tools/audit/ff_joint_source_isr_v1.py'
assert not q.exists()
s=p.read_text().replace('C=H.C;O=H.O','C=H.C;O=R/\'build/final-fantasy-joint-source-v1/joint\';H.O=O')
s=s.replace("O/'build-proof.json'","O.parent/'source-closure.json'")
s=s.replace("O/'loader-controls-v7.json'","O.parent/'semantic-controls.json'")
q.write_text(s,newline='\n')
O=R/'build/final-fantasy-joint-source-v1'
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
(O/'isr-fixture-derivation.json').write_text(json.dumps(dict(assertions_and_loop_bounds_unchanged=True,
  changes=['Bind actual joint source directory','Bind actual source-closure and semantic-control receipt paths'],
  bindings={str(f):sha(f)for f in[p,q,Path(__file__)]}),indent=2)+'\n',newline='\n')
raise SystemExit(subprocess.call([sys.executable,str(q)],cwd=R))
