"""Full flags and actual native-vector cuts for new typed ROM62 callbacks."""
from pathlib import Path
import hashlib,itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import ff_joint_typed_controls_v1 as T
import ff_host_pickups_vectors_v2 as V
from ff_wram_host_isr_v8 import clone
H=T.H;O=T.O;sha=T.sha

def flags_and_impulses(b):
    seed=T.base(b);rows=[];guards=[]
    for f in range(64):
        p=(f&15)|((f&48)<<2)|32
        for name,native in[('FwSvcStomp','X5StompDispatch'),('FwSvcSpring','X5SpringDispatch')]:
            pair=[]
            for wrapped in[False,True]:
                m=T.copy(seed);H.put(m,FfJump=0,FfGPhase=2,MmUnderwater=0,Player_State=2,Player_Y_Speed=2)
                m.writes.clear();m.ram_writes.clear()
                if wrapped:c,_=H.invoke(m,name,a=91,x=4,y=133,p=p)
                else:
                    c,_=H.invoke(m,native,a=91,x=4,y=133,p=p)
                    c,_=H.invoke(m,'FwHostImpulseAccepted',a=c.a,x=c.x,y=c.y,p=c.p)
                pair.append(T.sig(m,c));H.exact(m)
                assert H.get(m,'FfJump')==1 and H.get(m,'FfGPhase')==0
            assert pair[0]==pair[1],(name,p)
            rows.append([name,p])
        for changed in[{},dict(SelectedCharacter=0),dict(GameEngineSubroutine=4),dict(GameEngineSubroutine=5),dict(GamePauseStatus=1),dict(TimerControl=1),dict(MmDeathFlag=1)]:
            m=T.copy(seed);H.put(m,**changed);c,_=H.invoke(m,'FwSvcActive',a=91,x=4,y=133,p=p)
            assert(c.a,c.x,c.y,c.p&0xce,c.sp)==(91,4,133,p&0xce,224)
            assert bool(c.p&1)==(not changed)
            guards.append([p,changed])
    return dict(actual_native_impulse_pairs=len(rows),rows=rows,full_flags_active_guard_cases=len(guards),guards=guards)

def vectors(b):
    seed=T.base(b);snap=[];seen=set();names=['FwSvcActive','FwSvcMovement','FwSvcHead','FwSvcSide','FwSvcHeadWithin',
      'FwSvcBody','FwSvcAdder','FwSvcBoxProfile','FwSvcFullBox','FwSvcMature','FwSvcStomp','FwSvcSpring']
    start=H.address(b,'FwSvcBegin');end=H.address(b,'FwSvcEnd')
    for name in names:
        m=T.copy(seed);H.put(m,NmiDisable=0);c=H.start(m,name,a=22,x=0,y=0,p=0x30)
        for i in range(10000):
            if c.pc==0x5b00:break
            # Every new adapter instruction plus every actual map transition.
            if start<=c.pc<end or bytes(m[c.pc:c.pc+3])in[b'\x8d\x15\x51',b'\x8d\x16\x51']:
                key=(name,c.pc,m.rawtags[1],m.rawtags[2])
                if key not in seen:seen.add(key);snap.append((name,i,c.pc,clone(m,c)))
            c.step()
        else:raise AssertionError(('bounded typed discovery',name,hex(c.pc)))
    rows=[]
    for name,step,pc,(m,c)in snap:
        for lag,kind in itertools.product([0,255],['NMI','IRQ']):
            q,d=clone(m,c);H.put(q,NmiDisable=lag)
            if kind=='IRQ'and d.p&d.INTERRUPT:continue
            proof=V.interrupt(q,d,kind);H.finish(q,d);H.exact(q)
            assert q.rawtags[1:3]==[215,216]
            rows.append(dict(entry=name,step=step,PC=pc,lag=lag,**proof))
    return dict(real_normal_lag_NMI_IRQ_cases=len(rows),instruction_snapshots=len(snap),rows=rows,
         all33SMC_AXYP_SP_livepage1_native_R0R1_R6R7_rawmaps_and_RAM0_3_exact=True)

def main():
    out=O/'typed-vectors-v1.json';assert not out.exists();p=dict(passed=False,native=False,admitted=False,checks={})
    try:
        closure=json.loads((O/'source-closure.json').read_text())
        for f,h in closure['bindings'].items():assert sha(f)==h,f
        b=H.C.qualified(H.O/'candidate.nes')
        for n,fn in[('full_flags_impulses',flags_and_impulses),('real_native_vectors',vectors)]:
            p['checks'][n]=fn(b);print(n,'PASS',flush=True)
        p['passed']=True
    except Exception as e:p.update(error=repr(e),traceback=traceback.format_exc())
    p['bindings']={str(f.resolve()):sha(f)for f in[Path(__file__),Path(T.__file__),Path(H.__file__),Path(V.__file__),O/'source-closure.json',O/'typed-controls-v2.json',H.O/'candidate.nes',H.O/'candidate.dbg']}
    t=out if p['passed']else O/'typed-vectors-negative-v1.json';assert not t.exists();t.write_text(json.dumps(p,indent=2)+'\n',newline='\n')
    print(json.dumps(dict(passed=p['passed'],path=str(t),error=p.get('error'))),flush=True);assert p['passed']

if __name__=='__main__':main()
