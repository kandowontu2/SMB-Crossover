"""Build a genuine private FF ROM loader + RAM3 source image. No native run."""
from pathlib import Path
import hashlib,json,re,subprocess,sys
R=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
from prepare_ff_current_component_v2 import qualified
from finalize_ff_current_component_v3 import dependencies
from check_tmnt_render_oa import address,location
from prepare_cv3_dmc_mirror import prepare

P=R/'build/final-fantasy-current-component-v2/linked'
K=R/'build/final-fantasy-ram3-kernel-v1'
O=R/'build/final-fantasy-wram-host-v13'
LEASE=R/'docs/qa/checkpoints/2026-10-30/ff-ram3-private-allocation/root-review-and-reservations.json'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,s):p.parent.mkdir(exist_ok=True,parents=True);p.write_text(s,newline='\n')
def save(p,d):write(p,json.dumps(d,indent=2)+'\n')


def run(command,phase):
    result=subprocess.run(command,cwd=R,capture_output=True,text=True)
    path=O/'commands.json';logs=json.loads(path.read_text())if path.exists()else[]
    logs.append(dict(phase=phase,command=command,returncode=result.returncode,stdout=result.stdout,stderr=result.stderr))
    save(path,logs);assert result.returncode==0,result.stderr[-14000:]


def stage(d,entry,cfg,component,extra=()):
    d.mkdir(exist_ok=True,parents=True);write(d/'entrypoint.s',entry);write(d/'private.cfg',cfg)
    write(d/'ff-component.s',component)
    recipe=json.loads((P/'compile-log.json').read_text())
    ca=R/'tools/Windows/cc65/bin/ca65.exe'
    main=recipe[0]['command'][:]
    for option,path in [('-o',d/'main.o'),('--create-full-dep',d/'main.d')]:main[main.index(option)+1]=str(path)
    main[-1]=str(d/'entrypoint.s');main[1:1]=['-I',str(d),'-I',str(P),'-I',str(R/'build/required-rcr-ink-v2/candidate')]
    run(main,'main_source_'+d.name)
    objects=[]
    for name,source in [('ff-component',d/'ff-component.s')]+list(extra):
        run([str(ca),'-g','--cpu','6502x','-I',str(d),'-I',str(R/'src'),
             '--bin-include-dir',str(d),'--bin-include-dir',str(R),'--create-full-dep',str(d/(name+'.d')),
             '-o',str(d/(name+'.o')),str(source)],'component_'+name)
        objects.append(str(d/(name+'.o')))
    link=recipe[-1]['command'][:]
    for option,path in [('-C',d/'private.cfg'),('-o',d/'candidate.nes'),('-Ln',d/'candidate.lbl'),('-m',d/'candidate.map')]:link[link.index(option)+1]=str(path)
    link[link.index('--ld-args')+1]='--dbgfile,'+str(d/'candidate.dbg')
    link=[str(d/'main.o')if v.endswith('/main.o')or v.endswith('\\main.o')else v for v in link]
    link=[v for v in link if v!=str(P/'ff-component.o')];link+=objects
    run(link,'source_link_'+d.name);prepare(R,d/'candidate.nes')
    return main,link


def main():
    assert not O.exists();assert sha(LEASE)=='6bdc187e7cea9ac719d9c186159c7d695e8bfa68c8fe860bc06ad761574c1820'
    assert sha(P/'candidate.nes')=='aadbbb89ea680cdfa1e1837f56cd75b1e828c8778d85afc7e6688d4a9dbc0d28'
    proof=json.loads((K/'build-proof.json').read_text())
    for path,digest in proof['bindings'].items():assert sha(path)==digest,path
    host_handoffs=[R/'build/final-fantasy-host-combat-qualified-v3/handoff.json',R/'build/final-fantasy-host-terrain-qualified-v1/handoff.json',R/'build/final-fantasy-host-pickups-qualified-v1/handoff.json']
    for hp,digest in zip(host_handoffs,['6773102feabdb2983d06b4b61fce4c6a62b1cba3865c21092c18b2f77bb1c2b6','6f2ca05db6f2b5fa4b7e846e57aebf1c0169827cf51cc49909911d9e0dc62044','db2e2d4fb28a7082836cc2611eb851107f2b8f36aa6a5c58728df55e7a99386d']):
        assert sha(hp)==digest
        for p,h in json.loads(hp.read_text())['bindings'].items():assert sha(p)==h,p
    O.mkdir();entry=(P/'entrypoint.s').read_text();cfg=(P/'private.cfg').read_text();component=(P/'ff-component.s').read_text()
    reproduced=R/'build/final-fantasy-wram-host-v2/reproduce/candidate.nes'
    assert sha(reproduced)==sha(P/'candidate.nes')
    save(O/'exact-parent.json',dict(passed=True,ROM_sha256=sha(P/'candidate.nes'),genuine_reassembly=True))
    # Reassemble the original source with genuine host imports, not fixture
    # absolute addresses. Same virtual CORE and publisher keep its bytes exact.
    component=component.replace('.import X5SetPhysicalChr\n','.import FfRamPhysicalChr\n.define X5SetPhysicalChr FfRamPhysicalChr\n')
    own_exports=['FfEntryRecord','FfRecordLo','FfRecordHi','FfRectX','FfRectY','FfPaletteRed','FfPaletteBlue']
    component+='\n.export '+','.join(own_exports)+'\n'
    write(O/'publisher.s',(K/'publisher.s').read_text())
    write(O/'loader.s',(R/'tools/audit/ff_wram_loader_v3.s').read_text())
    for name,source in [('combat',R/'build/final-fantasy-host-combat-v2/combat.s'),('terrain',R/'build/final-fantasy-host-terrain-v3/terrain.s'),('pickups',R/'build/final-fantasy-host-pickups-v3/pickups.s')]:
        write(O/(name+'.s'),source.read_text())
    (O/'ff-host-health.inc').write_bytes((R/'build/final-fantasy-host-combat-v2/ff-host-health.inc').read_bytes())
    loader=(O/'loader.s').read_text()
    host_targets=['Movement','HeadWithin','Head','Feet','Side','Wall','AfterTerrain','Box','Adder','Target','Damage','Contact','Weapons','NewEnemy','Fresh','Collect','PowerupTick','Graphics','Body','ImpulseAccepted']
    loader+='\n'+''.join('FW_GATE FwHost'+n+',FfHost'+n+'\n'for n in host_targets)
    loader+='\nFW_GATE FwVisible,FfVisible\n'
    write(O/'loader.s',loader)
    service_names=['Movement','Graphics','Draw','Portrait','Weapons','Injury','InjuryStatus','DeathStart','Death','Visible','Head','BodyPolicy','Adder','Box','Side','Fresh','FullBox','MenuPortrait','MenuName','Reset','Prepare','Rise','Private','MatureCollision','Pickup','FullPower','Colors','BounceOnly','HeadWithinOnly','UI','Status','Bounce','WorldPalette','Powerup','WeaponTail','Vine']
    targets=['FwHostMovement','FwHostGraphics',None,'FwPortrait','FwHostWeapons','FwInjuryStart','FwInjuryStatus','FwDeathStart','FwDeathUpdate','FwVisible','FwHostHead','FwHostBody','FwHostAdder','FwBox','FwHostSide','FwHostFresh','FwHostBox','FwPortrait',None,'FwSelectedReset',None,None,None,'FwHostCollect','FwPickup','FwFullPower','FwPalettePointer',None,'FwHostHeadWithin',None,None,None,None,'FwHostPowerupTick',None,None]
    services=[dict(index=i,name=n,target=t or 'FwServiceUnavailable',implemented=t is not None,status='typed_source_gate_only'if t else'explicit_unimplemented_reject',bank='ROMBE',limitations='Native service sequencing/active guard and whole body/palette/Main remain parent integration work.')for i,(n,t)in enumerate(zip(service_names,targets))]
    save(O/'service-matrix.json',dict(native=False,admitted=False,common_mutated=False,rows=services,limits=['Draw and presentation/item/freeze/name services still pending actual source module.','Graphics/portrait are source chunk APIs, not complete aggregate body/effect rendering.','Source FwPickup accepts normalized0/1; native mature-item erase/score/freeze wrapper still required.']))
    veneers='.segment "FF_SERVICE_VENEERS"\n.export FwServiceVeneers,FwServiceVeneersEnd,FwServiceUnavailable\n'
    veneers+=''.join('.import '+t+'\n'for t in sorted(set(t for t in targets if t)))
    veneers+='FwServiceVeneers:\n'
    for row in services:veneers+='; '+str(row['index'])+' '+row['name']+' '+row['status']+'\n jmp '+row['target']+'\n'
    veneers+='FwServiceVeneersEnd:\nFwServiceUnavailable:\n clc\n rts\n'
    write(O/'veneers.s',veneers)
    write(O/'dispatch-model.s',(R/'tools/audit/ff_dispatch_proposal_v2.s').read_text())
    # Clone only authentic ROM preview leaves; no FfEnsure/cache dependency.
    source=(R/'src/final_fantasy_render.s').read_text()
    clones=[]
    for old,new in [('FfGraphicsBank','FwPreviewGraphicsBank'),('FfRenderChunk','FwPreviewChunk'),
                    ('FfPublishChunk','FwPreviewPublish'),('FfPalettePointer','FwPreviewColors')]:
        a=source.index('.proc '+old);z=source.index('.endproc',a)+len('.endproc')
        s=source[a:z].replace('.proc '+old,'.proc '+new).replace('jsr FfGraphicsBank','jsr FwPreviewGraphicsBank')
        clones.append(s)
    text='\n'.join(clones)
    # Every host/state/art name remains a real imported source symbol.
    names=sorted(set(re.findall(r'\bFf\w+\b',text)))
    old_imports='\n'.join(s for s in (P/'ff-component.s').read_text().splitlines()if s.startswith('.import'))
    pre=(P/'ff-component.s').read_text();pre=pre[pre.index('.macpack'):pre.index('.pushseg')]
    preview=old_imports+'\n'+''.join('.import '+n+'\n'for n in names)+'\n'+pre+'\n.segment "FF_ROM_HOST"\n'
    preview+='.export FwPreviewGraphicsBank,FwPreviewChunk,FwPreviewPublish,FwPreviewColors\n'+text+'\n'
    preview+='''
.import FfPower,FfPose
.export FwPreviewPortrait
.proc FwPreviewPortrait
 lda #0
 sta Player_SprAttrib
 lda #1
 sta FfPose
 lda PlayerFacingDir
 sta FfSlot
 ldx FfVariant
 cpx #4
 bcs Hide
 lda Offset,x
 ldx FfPower
 cpx #2
 bcc Base
 clc
 adc #18
Base:
 ldx #0
 ldy #0
 jsr FwPreviewChunk
 bcc Hide
 lda #<FfRenderBuffer
 sta SmPosePtr
 lda #>FfRenderBuffer
 sta SmPosePtr+1
 lda #METASPRITE_SAMUS_BODY
 sta ObjectMetasprite
 sec
 rts
Hide:
 lda #0
 sta ObjectMetasprite
 clc
 rts
Offset:.byte 0,36,72,108
.endproc
'''
    write(O/'preview.s',preview)
    # Preserve exact native PCs: replace only an existing farcall operand site.
    screen=(R/'src/screen_render.s').read_text();needle='farcall MoveAllSpritesOffscreen ;initialize all sprites including sprite #0'
    assert screen.count(needle)==1
    write(O/'screen_render.s','.import FwSceneInit\n'+screen.replace(needle,'farcall FwSceneInit ; source-owned FF forcedblank loader; original Move still first'))
    assert entry.count('nes2wram $2000')==1;entry=entry.replace('nes2wram $2000','nes2wram $8000')
    host_names=set(re.findall(r'^\.import(?:zp)? (\w+)',(O/'loader.s').read_text(),re.M))
    # Comma-separated imports need explicit exports as well.
    for s in (O/'loader.s').read_text().splitlines():
        if s.startswith('.import '):host_names.update(s.removeprefix('.import ').split(','))
    for n in sorted(host_names):
        if n.startswith(('Fw','Ff')):continue
        entry+='\n.export '+n
    for src in ['combat','terrain','pickups']:
        for line in (O/(src+'.s')).read_text().splitlines():
            match=re.fullmatch(r'\.import(zp)? (.+)',line)
            if not match:continue
            for n in match[2].split(','):
                n=n.strip()
                if n.startswith('Ff'):continue
                entry+='\n.export'+('zp'if match[1]else'')+' '+n
    entry+='\n'
    # Physical order is unchanged outside the explicitly granted carrier.
    mem,segs=cfg.split('SEGMENTS {',1)
    needle='RECLAIMED_PARODIUS_CHR_MEM: start=$d9000,size=$27000,type=ro,fill=yes,file=%O,fillval=$00;'
    assert mem.count(needle)==1
    mem=mem.replace(needle,'PRIOR_PRIVATE_CHR_MEM:start=$d9000,size=$6400,type=ro,fill=yes,file=%O,fillval=$00;\n'
        'FF_STREAM_MEM:start=$df400,size=$2000,type=ro,fill=yes,file=%O,fillval=$00;\n'
        'UNALLOCATED_CHR_MEM:start=$e1400,size=$1ec00,type=ro,fill=yes,file=%O,fillval=$00;')
    mem=mem.rsplit('}',1)[0]+'FF_RAM3_MEM:start=$a000,size=$2000,bank=3,type=ro,file="'+(O/'ram3.bin').as_posix()+'",fill=yes,fillval=$ff;\nFF_DISPATCH_MODEL_MEM:start=$b000,size=$200,bank=79,type=ro,file="'+(O/'dispatch-model.bin').as_posix()+'",fill=yes,fillval=$ff;\n}\n'
    needle='FINAL_FANTASY_CORE:load=X5_NEW_3E,type=ro,start=$aa00;';assert segs.count(needle)==1
    segs=segs.replace(needle,'FF_RAM_PUBLISHER:load=FF_RAM3_MEM,type=ro,start=$a275;\n'
        'FINAL_FANTASY_CORE:load=FF_RAM3_MEM,type=ro,start=$aa00;\n'
        'FF_HOST_COMBAT:load=FF_RAM3_MEM,type=ro,start=$b700;\nFF_HOST_TERRAIN:load=FF_RAM3_MEM,type=ro,start=$b900;\nFF_HOST_PICKUPS:load=FF_RAM3_MEM,type=ro,start=$bb60;\n'
        'FF_ROM_HOST:load=X5_NEW_3E,type=ro,start=$aa00;\nFF_SERVICE_VENEERS:load=X5_NEW_3E,type=ro,start=$b400;\nFF_STREAM:load=FF_STREAM_MEM,type=ro;')
    segs=segs.replace('}\nSYMBOLS {','FF_DISPATCH_MODEL:load=FF_DISPATCH_MODEL_MEM,type=ro;\n}\nSYMBOLS {')
    cfg=mem+'SEGMENTS {'+segs
    image=(R/'build/final-fantasy-host-pickups-v3/ram3.bin').read_bytes();assert hashlib.sha256(image).hexdigest()=='2ef76f0b00d94f5ecf10ed0bdc5745b0ac9e90394ddc1f0a0dc2abd5a26ec0ed'
    cookie=bytes([0xa7,22,0,3])+hashlib.sha256(image).digest()[:12]
    (O/'ff-cookie.bin').write_bytes(cookie);(O/'ff-stream.bin').write_bytes(image)
    write(O/'stream.s','.segment "FF_STREAM"\n.incbin "ff-stream.bin"\n')
    maincmd,link=stage(O,entry,cfg,component,[(n,O/(n+'.s'))for n in['publisher','loader','preview','stream','combat','terrain','pickups','veneers','dispatch-model']])
    assert (O/'ram3.bin').read_bytes()==image,'Source-linked RAM3 image changed from qualified kernel'
    b=qualified(O/'candidate.nes');raw=b['raw'];base=(P/'candidate.nes').read_bytes();cs=16+1048576
    assert raw[10]==9 and base[10]==7
    assert raw[cs+893*1024:cs+901*1024]==image
    assert raw[cs:cs+893*1024]==base[cs:cs+893*1024] and raw[cs+901*1024:]==base[cs+901*1024:]
    assert raw[16+93*8192+4096:16+94*8192]==base[16+93*8192+4096:16+94*8192]
    coreseg=next(g for g in b['segs'].values()if g['name']=='"FF_ROM_HOST"')
    used=int(coreseg['size'],0);payload_used=used+110;used=0xb46e-0xaa00;assert used<=3216,(used,'FF ROM lease overflow')
    old=qualified(P/'candidate.nes')
    moved={n:(s['val'],b['syms'].get(n,{}).get('val'))for n,s in old['syms'].items()
           if not n.startswith('Ff') and b['syms'].get(n,{}).get('val')!=s['val']}
    assert moved=={'_nes2_wramsize':('0x7','0x9'),'LOCAL-MACRO_SYMBOL-002A':('0x7','0x9')},moved
    assert all('seg'not in old['syms'][n]and 'seg'not in b['syms'][n]for n in moved)
    files=set()
    for p in [*O.glob('*.d'),*(O/'reproduce').glob('*.d')]:files.update(dependencies(p))
    inherited=[Path(x)for x in link if x.endswith('.o')and not Path(x).is_relative_to(O)]
    files.update(inherited);files.update(p for p in O.iterdir()if p.is_file())
    files.update(host_handoffs)
    files.update([reproduced,reproduced.parent.parent/'exact-parent.json',Path(__file__),R/'tools/audit/ff_wram_loader_v3.s',R/'tools/audit/ff_dispatch_proposal_v2.s',LEASE,K/'build-proof.json',P/'candidate.nes',P/'candidate.dbg'])
    report=dict(passed=True,ROM_payload=payload_used,source_model_only_common_file='dispatch-model.bin; never cartridge-emitted',status='PRIVATE_SOURCE_LINKED_FF_RAM3_LOADER_CPU_PENDING',native=False,admitted=False,
        parent_sha256=sha(P/'candidate.nes'),candidate_sha256=sha(O/'candidate.nes'),
        exact_current_reproduction=True,source_RAM3_sha256=sha(O/'ram3.bin'),stream_pages=[893,901],
        RAM3_cookie=list(cookie),ROM_used=used,ROM_budget=3216,ART_CHR_exact=True,old_host_symbols_moved=0,
        actual_dependencies=len(files),bindings={str(p.resolve()):sha(p)for p in files},
        limits=['FF remains pending; only actual InitScreen loader operand is hooked. Qualified combat/terrain now genuinely linked in RAM3 and callable through own ROM gates; no gameplay route admission/full render/audio integration.',
          'Code is source-linked; CPU loader/ISR/lifecycle/model checks still required. No native or shared install.'])
    save(O/'build-proof.json',report)
    print(json.dumps({k:report[k]for k in['status','candidate_sha256','ROM_used','source_RAM3_sha256']}))


if __name__=='__main__':main()
