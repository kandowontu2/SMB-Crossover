; Isolated source model only: linked to a separate file, never emitted into
; the cartridge/common bank. Root must review/compose the actual common hook.
.setcpu "6502"
.import SelectedCharacter,FarCallCommon,FarcallJmpTarget_SMC,NextBank_SMC
.import FwServiceVeneers,FwServiceVeneersEnd,FwServiceUnavailable
.export FwSelectModel,FwTableModel,FwModelRestore,FwModelEnd
.segment "FF_DISPATCH_MODEL"
.assert .lobyte(FwServiceVeneers)=0,lderror,"3-byte FF veneers must be page aligned"
.assert FwServiceVeneersEnd-FwServiceVeneers=36*3,lderror,"Exactly36 FF service veneers"
.assert .bank(FwServiceVeneers)=62,lderror,"Veneer bank must be genuine ROM62, never RAM3"

; The genuine HuCommon precondition: original A is already SafecallA_SMC,
; original Y then P are on stack; live Y is service0..35, X remains untouched.
; Parent caller already selected raw22. Invalid index rejects through ROM.
FwSelectModel:
 cpy #36
 bcs FwModelInvalid
 tya
 asl
 sta FarcallJmpTarget_SMC+1
 tya
 clc
 adc FarcallJmpTarget_SMC+1
 sta FarcallJmpTarget_SMC+1
 lda #>FwServiceVeneers
 sta FarcallJmpTarget_SMC+2
 lda #.lobyte(.bank(FwServiceVeneers)|$80)
 sta NextBank_SMC+1
 jmp FwModelRestore
FwModelInvalid:
 lda #<FwServiceUnavailable
 sta FarcallJmpTarget_SMC+1
 lda #>FwServiceUnavailable
 sta FarcallJmpTarget_SMC+2
 lda #.lobyte(.bank(FwServiceUnavailable)|$80)
 sta NextBank_SMC+1
FwModelRestore:
 pla
 tay
 plp
 ; This skips only STA NextBank_SMC+1. Both paths wrote that exact operand.
 jmp FarCallCommon+3

; Genuine lookup alternative for CPU comparison; same targets/return ABI.
FwTableModel:
 cpy #36
 bcs FwModelInvalid
 lda FwModelLo,y
 sta FarcallJmpTarget_SMC+1
 lda FwModelHi,y
 sta FarcallJmpTarget_SMC+2
 lda FwModelBank,y
 sta NextBank_SMC+1
 jmp FwModelRestore
FwModelLo:
.repeat 36,I
 .byte <(FwServiceVeneers+3*I)
.endrepeat
FwModelHi:
.repeat 36,I
 .byte >(FwServiceVeneers+3*I)
.endrepeat
FwModelBank:
.repeat 36,I
 .byte .lobyte(.bank(FwServiceVeneers)|$80)
.endrepeat
FwModelEnd:
