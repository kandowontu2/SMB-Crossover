"""Actual linked FF callback guards/native query fallbacks and item ordering."""
from pathlib import Path
import hashlib,itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import ff_wram_host_controls_v7 as H
from ff_wram_host_isr_v4 import clone
import ff_host_combat_controls_v1 as K
O=R/'build/final-fantasy-joint-typed-v1';H.O=O/'joint'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def base(b):
    m=H.make(b);H.invoke(m,'FwLoad');H.invoke(m,'FwEnsure')
    H.put(m,TimerControl=0,GamePauseStatus=0,MmDeathFlag=0,GameEngineSubroutine=8,
          ScreenLeft_X_Pos=0,ScreenLeft_PageLoc=0,Player_State=0,PlayerFacingDir=1,
          R0=1,R1=0xa6,R2=0,R3=0,R4=0,R5=0,R6=0,R7=5,Local_eb=0,
          BoundingBox_UL_Corner=120,BoundingBox_LR_Corner=135,Up_Down_Buttons=0,
          Left_Right_Buttons=0,JumpspringAnimCtrl=0)
    for a in range(H.address(b,'Block_Buffer_1'),H.address(b,'Block_Buffer_2')+208):m[a]=0
    return m

def copy(m):return clone(m,H.start(m,'FwCheck'))[0]
def sig(m,c):
    exclude=set(range(0x100,0x200))|set(range(0x5114,0x5118))
    sh={H.address(m.bundle,n)for n in['CurrentBank','CurrentBankC']};exclude|=sh
    return (bytes(m[i]for i in range(0x8000)if i not in exclude),
            [(a,v)for a,v in m.writes if a not in exclude],(c.a,c.x,c.y,c.p,c.sp),m.rawtags[:],m.ram[3][:])

def pairs(b):
    seed=base(b);rows=[]
    routes=[('Head','FwHostHead','BlockBufferColli_Head'),('Side','FwHostSide','BlockBufferColli_Side'),
            ('HeadWithin','FwHostHeadWithin','Z2HeadWithinTerrain'),('Body','FwHostBody','JnBodyDispatch'),
            ('Adder','FwHostAdder','RlAdderDispatch'),('BoxProfile','FwBox','RlBoxDispatch'),
            ('FullBox','FwHostBox','LmBoundingBoxGate')]
    for (svc,own,native),engine,paused,timer,dead,flags in itertools.product(routes,[4,5,8],[0,1],[0,1],[0,1],[0x30,0x71]):
        active=engine==8 and not(paused or timer or dead);out=[]
        for wrapped in[False,True]:
            m=copy(seed);H.put(m,GameEngineSubroutine=engine,GamePauseStatus=paused,TimerControl=timer,MmDeathFlag=dead)
            m.writes.clear();m.ram_writes.clear()
            c,_=H.invoke(m,'FwSvc'+svc if wrapped else own if active else native,a=22,x=0,y=0,p=flags)
            out.append(sig(m,c));H.exact(m)
        assert out[0]==out[1],('native callback pair',svc,engine,paused,timer,dead,flags)
        rows.append([svc,engine,paused,timer,dead,flags,active])
    return dict(actual_linked_pairs=len(rows),rows=rows,automatic4_5_native_query_outputs_exact=True,
       all_native_state_ordered_application_writes_AXYP_SP_livepage1_rawmaps_exact=True)

def movement(b):
    seed=base(b);rows=[]
    for state,joy,flags in itertools.product([0,1,2,3],[0,1,2,0x80],[0x30,0x71]):
        out=[]
        for wrapped in[False,True]:
            m=copy(seed);H.put(m,Player_State=state,SavedJoypadBits=joy,FfPrevious=0,Player_Y_Speed=0,
                 ClimbSideTimer=0,PlayerCollisionBits=0xff if 'PlayerCollisionBits'in b['syms']else 0)
            m.writes.clear();m.ram_writes.clear()
            c,_=H.invoke(m,'FwSvcMovement'if wrapped else'FwHostMovement',a=22,x=0,y=0,p=flags)
            if not wrapped and state==3:c,_=H.invoke(m,'MegaManClimbing',a=c.a,x=c.x,y=c.y,p=c.p)
            out.append(sig(m,c));H.exact(m)
        assert out[0]==out[1],('movement/climb',state,joy,flags)
        rows.append([state,joy,flags])
    return dict(actual_source_plus_genuine_native_climb_pairs=len(rows),rows=rows)

def maturity(b):
    seed=base(b);rows=[]
    for x,flag,state,kind,engine in itertools.product([0,4,5,6],[0,1,128],[0,128],[0,1,2,3,4],[4,5,8]):
        m=copy(seed);H.put(m,GameEngineSubroutine=engine,ObjectOffset=4)
        if x<6:
            K.actor(m,x=x,kind=H.address(b,'PowerUpObject'),px=144,y=160,state=state)
            m[H.address(b,'Enemy_Flag')+x]=flag;m[H.address(b,'PowerUpType')+x]=kind
        before=bytes(m[i]for i in range(0x8000)if not 0x100<=i<0x200)
        m.writes.clear();c,_=H.invoke(m,'FwSvcMature',a=0x55,x=x,y=91,p=0x71)
        expected=x<6 and flag==1 and state==128 and kind<4 and engine==8
        assert bool(c.p&1)==expected,(x,flag,state,kind,engine)
        assert(c.a,c.x,c.y,c.p&0xce,c.sp)==(0x55,x,91,0x71&0xce,224)
        allowed=set(range(0x100,0x200))|set(range(0x5114,0x5118))|{H.address(b,'CurrentBank'),H.address(b,'CurrentBankC')}
        assert not[(a,v)for a,v in m.writes if a not in allowed],('admission had application side effects',x,flag,state,kind,engine)
        rows.append([x,flag,state,kind,engine,expected])
    return dict(side_effect_free_admission_cases=len(rows),rows=rows,
       no_erase_score_freeze_or_source_grant_in_service23=True,service24_target='qualified FwHostCollect')

def main():
    out=O/'typed-controls.json';assert not out.exists();p=dict(passed=False,native=False,admitted=False,checks={})
    try:
        d=json.loads((O/'source-closure.json').read_text())
        for f,h in d['bindings'].items():assert sha(f)==h,f
        b=H.C.qualified(H.O/'candidate.nes')
        for n,fn in[('native_query_fallbacks',pairs),('movement_and_climb',movement),('maturity_order',maturity)]:
            p['checks'][n]=fn(b);print(n,'PASS',flush=True)
        p['passed']=True
    except Exception as e:p.update(error=repr(e),traceback=traceback.format_exc())
    p['bindings']={str(f.resolve()):sha(f)for f in[Path(__file__),Path(H.__file__),O/'source-closure.json',H.O/'candidate.nes',H.O/'candidate.dbg']}
    t=out if p['passed']else O/'typed-controls-negative.json';assert not t.exists();t.write_text(json.dumps(p,indent=2)+'\n',newline='\n')
    print(json.dumps(dict(passed=p['passed'],path=str(t),error=p.get('error'))),flush=True);assert p['passed']

if __name__=='__main__':main()
