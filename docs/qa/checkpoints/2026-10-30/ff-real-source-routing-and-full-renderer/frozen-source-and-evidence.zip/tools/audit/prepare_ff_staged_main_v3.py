"""Correct the scene adapter's native6000 RAM fixture copy, not ROM semantics."""
from pathlib import Path
import hashlib,json,subprocess,sys
R=Path(__file__).resolve().parents[2];D=R/'tools/audit';O=R/'build/final-fantasy-joint-typed-v1'
p=D/'ff_joint_staged_main_v2.py';q=D/'ff_joint_staged_main_v3.py';assert not q.exists()
s=p.read_text();needle='    m.ram[0][:]=bytes(q.m[a]for a in range(0x6000,0x8000))'
assert s.count(needle)==1
s=s.replace(needle,needle+'\n    for a in range(0x6000,0x8000):list.__setitem__(m,a,q.m[a])')
s=s.replace('staged-main-v2.json','staged-main-v3.json').replace('staged-main-negative-v2.json','staged-main-negative-v3.json')
q.write_text(s,newline='\n')
sha=lambda f:hashlib.sha256(f.read_bytes()).hexdigest()
proof=dict(native=False,ROM_unchanged=True,correction='OverlayMemory exposes6000..7FFF native hostRAM through inherited list; copying only raw-window RAM0 cache array left H.make poison GuestHurtTicks128/MmDeathFlag98. Copy actual6000 plane too from same legal source scene; retain all typed/Main assertions.',
 bindings={str(f):sha(f)for f in[Path(__file__),p,q,O/'handoff.json',O/'staged-main-negative-v1.json',O/'staged-main-negative-v2.json']})
(O/'staged-main-fixture-correction-v3.json').write_text(json.dumps(proof,indent=2)+'\n',newline='\n')
raise SystemExit(subprocess.call([sys.executable,str(q)],cwd=R))
