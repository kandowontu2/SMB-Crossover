"""Real linked FF gates + actual native BG, with explicit uninstalled selectors.

No callback result/contact is injected. The six declared selector entries are
staged to genuine ROM62 gates via real SFC; feet/wall/postBG remain uninstalled.
This fixture does not establish actual cartridge/common hooks or admission.
"""
from pathlib import Path
import hashlib,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
from check_tmnt_render_oa import location
import ff_joint_typed_controls_v1 as T
from ff_host_terrain_controls_v1 import cell
O=T.O;H=T.H;sha=T.sha
ROUTES={'MegaManCollisionAdder':'FwSvcAdder','HuBillBGHeadFast':'FwSvcHead',
        'GmFootResident':'FwHostFeet','CrossoverSourceSideProbe':'FwSvcSide',
        'CrossoverHeadWithinTerrain':'FwSvcHeadWithin','SamusStopAtWall':'FwHostWall'}

def drive(b,wx,duck):
    m=T.base(b);top=17 if duck else 6;old=160-top;current=old-3
    at,_,_=cell(b,(wx+8)&65535,current+top);m[at]=0xc1
    H.put(m,Player_X_Position=wx&255,Player_PageLoc=wx>>8,Player_Y_Position=current,
      Player_Y_HighPos=1,Player_Y_Speed=253,Player_State=1,PlayerStatus=0,
      PlayerSize=0,CrouchingFlag=duck,RgCrouch=duck,FfTerrainPreviousY=old,
      FfTerrainFlags=0,Local_eb=0,DisableCollisionDet=0,SwimmingFlag=0,
      JumpspringAnimCtrl=0,BlockBounceTimer=0,GuestHurtTicks=0,SprDataOffset_Ctrl=0,
      Player_MovingDir=1,GameEngineSubroutine=8)
    targets={(H.address(b,n),((location(b,n)-16)//8192)|128):(n,v)for n,v in ROUTES.items()};calls=[]
    def stage(mem,c,step):
        tag=mem.rawtags[(c.pc-0x8000)//8192]if c.pc>=0x8000 else -1
        if(c.pc,tag)not in targets:return
        source,target=targets[(c.pc,tag)];calls.append([source,target,c.a,c.x,c.y])
        pc=H.address(b,target)
        mem[H.address(b,'SafecallA_SMC')+1]=c.a
        mem[H.address(b,'FarcallJmpTarget_SMC')+1]=pc&255
        mem[H.address(b,'FarcallJmpTarget_SMC')+2]=pc>>8
        c.a=0xbe;c.pc=H.address(b,'FarCallCommon')
    c,low=H.invoke(m,'PlayerBGCollision',hook=stage)
    H.invoke(m,'FwHostAfterTerrain')
    actualx=H.get(m,'Player_X_Position')+256*H.get(m,'Player_PageLoc')
    block=[H.get(m,n)for n in['Block_X_Position','Block_PageLoc','Block_Y_Position']]
    assert actualx==wx,('native BG displaced X',wx,duck,actualx,calls,block)
    assert H.get(m,'Player_Y_Position')==old,('native ceiling response',old,H.get(m,'Player_Y_Position'))
    assert block==[((wx+8)&65535)&240,((wx+8)&65535)>>8,144]
    H.exact(m)
    return dict(worldX=wx,duck=duck,resultX=actualx,block=block,calls=calls,minimum_SP=low)

def main():
    out=O/'staged-nativebg-v2.json';assert not out.exists()
    p=dict(passed=False,native=False,admitted=False,actual_cart_hooks=False,artificial_contact_or_result_writes=False,
      scope='Actual native BG and block/item writers with six explicitly staged source selector entries; real buffered loader initializes RAM3, no preload.',
      routes=ROUTES,uninstalled=['Feet','Wall','AfterBG','Common22/32'],cases=[])
    try:
        h=json.loads((O/'handoff.json').read_text())
        for f,s in h['bindings'].items():assert sha(f)==s,f
        b=H.C.qualified(H.O/'candidate.nes')
        for wx in[112,113,119,120,121,127,128,247,250,255,256,511]:
            for duck in[0,1]:p['cases'].append(drive(b,wx,duck))
        p['passed']=True
    except Exception as e:p.update(error=repr(e),traceback=traceback.format_exc())
    p['bindings']={str(f.resolve()):sha(f)for f in[Path(__file__),Path(T.__file__),Path(H.__file__),O/'handoff.json',H.O/'candidate.nes',H.O/'candidate.dbg']}
    t=out if p['passed']else O/'staged-nativebg-negative-v2.json';assert not t.exists();t.write_text(json.dumps(p,indent=2)+'\n',newline='\n')
    print(json.dumps(dict(passed=p['passed'],cases=len(p['cases']),error=p.get('error'),path=str(t))),flush=True);assert p['passed']

if __name__=='__main__':main()
