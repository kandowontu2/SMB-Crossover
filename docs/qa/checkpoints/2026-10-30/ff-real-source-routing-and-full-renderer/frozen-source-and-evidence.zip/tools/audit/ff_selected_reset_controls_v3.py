"""Actual scene/life FF reset and verified-load construction; no common hook."""
from pathlib import Path
import hashlib,itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import ff_wram_host_controls_v7 as H
from ff_wram_host_isr_v4 import clone
C=H.C;O=R/'build/final-fantasy-wram-host-v13'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
PERSIST=['FfVariant','FfReady','FfLife','FfArea','FfWorld','FfPower','FfEarned','FfHealCharges']


def duplicate(m):return clone(m,H.start(m,'FwCheck'))[0]


def original_move(b):
    m=H.make(b);c,_=H.invoke(m,'MoveAllSpritesOffscreen')
    return c.a,c.x,c.y,c.p,c.sp


def cases(b):
    cold=H.make(b);warm=H.make(b);H.invoke(warm,'FwLoad')
    for m in [cold,warm]:m.writes.clear();m.ram_writes.clear()
    rows=[];want_move=original_move(b)
    for loaded,variant,tier,life,area in itertools.product([0,1],range(4),range(3),[2,1],[0,1]):
        m=duplicate(warm if loaded else cold)
        H.put(m,FfVariant=variant,FfReady=0xf7,FfLife=2,FfArea=32,FfWorld=0,
              FfPower=tier,FfEarned=tier,FfHealCharges=3,FfAction=2,FfAge=14,
              NumberofLives=life,AreaAddrsLOffset=area,SavedJoypadBits=0x81,
              MmDeathFlag=0,TimerControl=0,GamePauseStatus=0)
        before={n:H.get(m,n)for n in PERSIST};trace=[];initial_reads=m.ppu_reads
        def observe(mem,cpu,i):
            if 0xa000<=cpu.pc<0xc000 and mem.rawtags[1]==3:
                assert bytes(mem.ram[3][0x1fe0:0x1ff0])==(O/'ff-cookie.bin').read_bytes()
                trace.append(cpu.pc)
        H.invoke(m,'FwSelectedReset',hook=observe)
        if not loaded:
            assert not trace and {n:H.get(m,n)for n in PERSIST}==before
        c,_=H.invoke(m,'FwSceneInit',hook=observe)
        assert(c.a,c.x,c.y,c.p,c.sp)==want_move,'Original native Move AXYP/SP changed'
        H.exact(m)
        assert H.get(m,'FfVariant')==variant and H.get(m,'FfReady')==0xf7
        assert H.get(m,'FfLife')==life and H.get(m,'FfArea')==32|area
        expected=tier if life==2 else 0
        assert H.get(m,'FfPower')==expected and H.get(m,'FfEarned')==expected
        assert H.get(m,'FfHealCharges')==(3 if life==2 else 0)
        assert H.get(m,'FfAction')==0 and H.get(m,'FfAge')==0
        assert m.ppu_reads-initial_reads==(0 if loaded else 16400)
        # Lives portrait immediately after successful scene load sees constructed
        # source state, never stale pre-newgame tier or unready source code.
        H.invoke(m,'FwPortrait',hook=observe);assert H.get(m,'ObjectMetasprite')!=0
        assert H.get(m,'FfPower')==expected and H.get(m,'FfVariant')==variant
        rows.append([loaded,variant,tier,life,area,expected,len(trace)])
    return dict(cold_warm_class_tier_life_scene_cases=len(rows),rows=rows,
        source_earned_tier_charges_class_preserved_on_scene=True,
        source_actual_life_loss_resets_earned_gear=True,
        no_Ready0_on_selected_area_reset=True,full_cookie_precedes_all_RAM3_execution=True,
        original_Move_AXYP_SP_exact=True,source_constructor_before_lives_portrait=True)


def actual_caller(b):
    rows=[]
    for loaded,variant,tier in itertools.product([0,1],range(4),range(3)):
        m=H.make(b)
        if loaded:H.invoke(m,'FwLoad')
        H.put(m,FfVariant=variant,FfReady=0xf7,FfLife=2,FfArea=32,FfWorld=0,
              FfPower=tier,FfEarned=tier,FfHealCharges=3,FfAction=2,
              MmDeathFlag=0,TimerControl=0,GamePauseStatus=0)
        at=H.address(b,'GmResetGate');target=H.address(b,'FwSelectedReset');calls=[]
        def stage(mem,cpu,i):
            if cpu.pc!=at:return
            assert mem.rawtags[1]==0xfc,'Actual native NrReset bank ABI changed'
            calls.append([i,cpu.a,cpu.x,cpu.y,cpu.p,cpu.sp])
            mem[H.address(b,'SafecallA_SMC')+1]=cpu.a
            mem[H.address(b,'FarcallJmpTarget_SMC')+1]=target&255
            mem[H.address(b,'FarcallJmpTarget_SMC')+2]=target>>8
            cpu.a=0xbe;cpu.pc=H.address(b,'FarCallCommon')
        c=H.start(m,'RosterClearState',a=0,x=0,y=0,p=0x30)
        H.finish(m,c,stage);assert len(calls)==1 and c.sp==224
        assert H.get(m,'FfVariant')==variant and H.get(m,'FfPower')==tier
        assert H.get(m,'FfEarned')==tier and H.get(m,'FfHealCharges')==3
        if loaded:assert H.get(m,'FfAction')==0
        else:assert H.get(m,'FfAction')==2
        H.invoke(m,'InitScreen');H.exact(m)
        assert H.get(m,'FfAction')==0 and H.get(m,'FfPower')==tier and H.get(m,'FfVariant')==variant
        rows.append([loaded,variant,tier,c.processorCycles])
    return dict(actual_native_RosterClearState_cases=len(rows),rows=rows,
        true_native_clear_and_Reset_gate_execute=True,
        explicit_staged_single_selector=True,
        limit='Only the GmResetGate entry is explicitly redirected by this CPU fixture through real FarCallCommon. Actual common source cart hook/Main remains uninstalled.')


def main():
    out=O/'selected-reset-controls-v3.json';assert not out.exists()
    report=dict(passed=False,native=False,common_hook=False,checks={})
    try:
        d=json.loads((O/'build-proof.json').read_text())
        for p,h in d['bindings'].items():assert sha(p)==h,p
        b=C.qualified(O/'candidate.nes')
        report['checks']['cases']=cases(b);print('FF selected scene/life construction PASS',flush=True)
        report['checks']['actual_caller']=actual_caller(b);print('FF genuine staged native reset caller PASS',flush=True)
        report['passed']=True
    except Exception as e:report.update(error=repr(e),traceback=traceback.format_exc())
    report['bindings']={str(p.resolve()):sha(p)for p in [Path(__file__),Path(H.__file__),O/'candidate.nes',O/'candidate.dbg',O/'build-proof.json',O/'ram3.bin',O/'ff-cookie.bin',R/'tools/audit/ff_wram_loader_v3.s',R/'build/final-fantasy-reset-caller-audit-v1/controls.json']}
    p=out if report['passed']else O/'selected-reset-negative-v3.json';assert not p.exists()
    p.write_text(json.dumps(report,indent=2)+'\n',newline='\n')
    print(json.dumps(dict(passed=report['passed'],error=report.get('error'),path=str(p))))
    assert report['passed']


if __name__=='__main__':main()
