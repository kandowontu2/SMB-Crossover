; PRIVATE typed acquisition owner, not yet linked/admitted. Definitions are
; imported from the new genuine object builder; no function-address aliases.
.include "item-imports.inc"
; Included after the weapon object, which owns the longbranch macro pack.
.segment "ROGUE_DAWN_HOST_AUX"
.export RdItStart,RdItEnd,RdItPickup,RdItCollision,RdItPrivate
RdItStart:
.proc ItEnabled
 lda SelectedCharacter
 cmp #2
 bne No
 lda RdVariant
 cmp #1
 bne No
 sec
 rts
No:clc
 rts
.endproc

; Actual actor classification, never source resource/outcome seeding.
.proc ItTyped
 cpx #6
 bcs No
 lda Enemy_Flag,x
 cmp #1
 bne No
 lda Enemy_ID,x
 cmp #$2e
 bne No
 lda InvPickupOwner,x
 cmp #2
 bne No
 lda InvPickup,x
 cmp #$d0
 bcc No
 cmp #$da
 bcs No
 sec
 rts
No:clc
 rts
.endproc

; Complete native pickup contact calls here, before any original erase.
; A typed reward must be fully emerged. Foreign callers keep genuine NrPickup;
; native Star/1Up go to their actual untouched normal consumer once.
.proc RdItPickup
 php
 pha
 jsr ItEnabled
 bcc Foreign
 pla
 plp
 jsr ItTyped
 bcc Ordinary
 lda Enemy_State,x
 bpl Done
 WxFar RdHsCollectActor
 bcc Done
 WxFar RdItSyncStatus
 jsr EraseEnemyObject
 lda #0
 sta InvPickup,x
 sta InvPickupOwner,x
 sta InvRisePhase,x
 lda #6
 jsr SetupFloateyNumber
 lda #<Sfx_PowerUpGrab
 sta Square2SoundQueue
Done:rts
Ordinary:
 lda PowerUpType,x
 cmp #2
 bcc Done                       ; unknown raw0/1 must never become old Samus
 WxTail MarioSourcePowerupCollision
Foreign:pla
 plp
 WxTail NrPickup
.endproc

; The actual PowerUpObjHandler calls this after geometry and before contact.
; Entirely rising typed objects stay visible but cannot be collected early.
.proc RdItCollision
 php
 pha
 jsr ItEnabled
 bcc Foreign
 pla
 plp
 jsr ItTyped
 bcc Native
 lda Enemy_State,x
 bpl No
Native:sec
 rts
No:clc
 rts
Foreign:pla
 plp
 WxTail NrPickupCollision
.endproc

; Suppress native Flower appearance for typedD0..D9 only. The distinct source
; art needs the actual safe item-window lease before this target is installed.
.proc RdItPrivate
 php
 pha
 jsr ItEnabled
 bcc Foreign
 pla
 plp
 jmp ItTyped
Foreign:pla
 plp
 WxTail LmPrivateGate
.endproc
RdItEnd:
.assert * <= $be00,error,"Protect512B authenticated item descriptors"
