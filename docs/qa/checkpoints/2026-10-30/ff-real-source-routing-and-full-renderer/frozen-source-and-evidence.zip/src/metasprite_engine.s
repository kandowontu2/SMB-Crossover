
.segment "METASPRITE"

METASPRITES_COUNT .set 0

PATTERN_TABLE_0 = $00
PATTERN_TABLE_1 = $01
.if MAPPER_MMC5
SPRITE_BANK_0 = $00 | PATTERN_TABLE_0
SPRITE_BANK_1 = $40 | PATTERN_TABLE_0
SPRITE_BANK_2 = $80 | PATTERN_TABLE_0
SPRITE_BANK_3 = $c0 | PATTERN_TABLE_0
SPRITE_BANK_4 = $00 | PATTERN_TABLE_1
SPRITE_BANK_5 = $40 | PATTERN_TABLE_1
SPRITE_BANK_6 = $80 | PATTERN_TABLE_1
SPRITE_BANK_7 = $c0 | PATTERN_TABLE_1
.else
SPRITE_BANK_0 = $00 | PATTERN_TABLE_1
SPRITE_BANK_1 = $40 | PATTERN_TABLE_1
SPRITE_BANK_2 = $80 | PATTERN_TABLE_1
SPRITE_BANK_3 = $c0 | PATTERN_TABLE_1
SPRITE_BANK_4 = $c0 | PATTERN_TABLE_0
SPRITE_BANK_5 = $80 | PATTERN_TABLE_0
.endif


MSPR_VERTICAL_FLIP = %10000000
MSPR_OFFSET_MASK = %00111111
.define MetaspriteOffset(b) 0+((b) & MSPR_OFFSET_MASK)

; Custom values to signify that this sprite should be flipped in the metasprite
SPR_FLIP_H = %01000000 << 8
SPR_FLIP_V = %10000000 << 8
; Can be used to force a sprite palette. If NO_PALETTE is set, then the palette value
; from the object in the game will not be applied, and this value will be forced instead
SPR_NO_PALETTE = %00100000 << 8
SPR_PALETTE_0  = SPR_NO_PALETTE | %00000000 << 8
SPR_PALETTE_1  = SPR_NO_PALETTE | %00000001 << 8
SPR_PALETTE_2  = SPR_NO_PALETTE | %00000010 << 8
SPR_PALETTE_3  = SPR_NO_PALETTE | %00000011 << 8


.define MetaspriteVramOffset(b, vram) (((b) & %00111111) | vram)

.macro MetaspriteBoxBody Object, Animation, Direction, VramOffset, Palette, XOffset, YOffset, Spr1, Spr2, Spr3, Spr4
.local X1, X2, Y1, Y2, Size
.local Tile1, Tile2, Tile3, Tile4
.local Attr1, Attr2, Attr3, Attr4
.local DrawSprite1, DrawSprite2, DrawSprite3, DrawSprite4

X1 = 0+XOffset
X2 = 8+XOffset
Y1 = 8+YOffset
Y2 = 24+YOffset
Size .set 1

DrawSprite2 .set 0
DrawSprite3 .set 0
DrawSprite4 .set 0

DrawSprite1 .set 1
Tile1 .set MetaspriteVramOffset(<Spr1, VramOffset)

.ifnblank Spr2
DrawSprite2 .set 1
Size .set 2
Tile2 .set MetaspriteVramOffset(<Spr2, VramOffset)
.endif
.ifnblank Spr3
DrawSprite3 .set 1
Size .set 3
Tile3 .set MetaspriteVramOffset(<Spr3, VramOffset)
.endif
.ifnblank Spr4
DrawSprite4 .set 1
Size .set 4
Tile4 .set MetaspriteVramOffset(<Spr4, VramOffset)
.endif

Attr1 .set (Palette | ((>Spr1) >> 8))
.ifnblank Spr2
Attr2 .set (Palette | ((>Spr2) >> 8))
.endif
.ifnblank Spr3
Attr3 .set (Palette | ((>Spr3) >> 8))
.endif
.ifnblank Spr4
Attr4 .set (Palette | ((>Spr4) >> 8))
.endif

.if .xmatch(Direction, "LEFT")
; .out .sprintf("Switching tile and attr %s %s %s", Object, Animation, Direction)
.ifnblank Spr2
  Tmp .set Tile1
  Tile1 .set Tile2
  Tile2 .set Tmp
  Tmp .set Attr1
  Attr1 .set Attr2
  Attr2 .set Tmp
  Attr1 .set Attr1 ^ $40
  Attr2 .set Attr2 ^ $40
.endif
.if .blank(Spr4) .and(.not .blank(Spr3))
  DrawSprite4 .set 1
  DrawSprite3 .set 0
  Attr4 .set Attr3 ^ $40
  Tile4 .set Tile3
.endif
.ifnblank Spr4
  Tmp .set Tile3
  Tile3 .set Tile4
  Tile4 .set Tmp
  Tmp .set Attr3
  Attr3 .set Attr4
  Attr4 .set Tmp
  Attr3 .set Attr3 ^ $40
  Attr4 .set Attr4 ^ $40
.endif
.endif

.ident( .sprintf("MetaspriteData_%s_%s_%s", Object, Animation, Direction) ):
  .byte   (Size * 4)
.if DrawSprite1 <> 0
  .byte   Tile1, Attr1, Y1, X1
.endif
.if DrawSprite2 <> 0
  .byte   Tile2, Attr2, Y1, X2
.endif
.if DrawSprite3 <> 0
  .byte   Tile3, Attr3, Y2, X1
.endif
.if DrawSprite4 <> 0
  .byte   Tile4, Attr4, Y2, X2
.endif
.endmacro

.macro MetaspriteBox Object, Animation, Spr1, Spr2, Spr3, Spr4
.local VramOffset, Bank, Palette, XOffset, YOffset, Mirror

.if .defined(.ident( .sprintf("%s_%s_VRAM_OFFSET", Object, Animation) ))
  VramOffset = .ident( .sprintf("%s_%s_VRAM_OFFSET", Object, Animation) )
.elseif .defined(.ident( .sprintf("%s_VRAM_OFFSET", Object) ))
  VramOffset = .ident( .sprintf("%s_VRAM_OFFSET", Object) )
.else
  VramOffset = 0
.endif
.if .defined(.ident( .sprintf("%s_%s_BANK", Object, Animation) ))
  Bank = .ident( .sprintf("%s_%s_BANK", Object, Animation) )
.elseif .defined(.ident( .sprintf("%s_BANK", Object) ))
  Bank = .ident( .sprintf("%s_BANK", Object) )
.else
  Bank = $ff
.endif
.if .defined(.ident( .sprintf("%s_%s_PALETTE", Object, Animation) ))
  Palette = .ident( .sprintf("%s_%s_PALETTE", Object, Animation) )
.elseif .defined(.ident( .sprintf("%s_PALETTE", Object) ))
  Palette = .ident( .sprintf("%s_PALETTE", Object) )
.else
  .error .sprintf("Could not define Metasprite without the palette. Please define either %s_PALETTE or %s_%s_PALETTE", Object, Object, Animation)
.endif

.if .defined(.ident( .sprintf("%s_%s_Y_OFFSET", Object, Animation) ))
  YOffset = <.ident( .sprintf("%s_%s_Y_OFFSET", Object, Animation) )
.elseif .defined(.ident( .sprintf("%s_Y_OFFSET", Object) ))
  YOffset = <.ident( .sprintf("%s_Y_OFFSET", Object) )
.else
  YOffset = 0
.endif

.if .defined(.ident( .sprintf("%s_%s_X_OFFSET", Object, Animation) ))
  XOffset = <.ident( .sprintf("%s_%s_X_OFFSET", Object, Animation) )
.elseif .defined(.ident( .sprintf("%s_X_OFFSET", Object) ))
  XOffset = <.ident( .sprintf("%s_X_OFFSET", Object) )
.else
  XOffset = 0
.endif

.if .defined(.ident( .sprintf("%s_%s_NO_MIRROR", Object, Animation) ))
  Mirror = 0
.elseif .defined(.ident( .sprintf("%s_NO_MIRROR", Object) ))
  Mirror = 0
.else
  Mirror = 1
.endif

.ident( .sprintf("METASPRITE_%d_BANK",  METASPRITES_COUNT) ) = Bank

.ifdef METASPRITE_BODY

.if Mirror = 1
MetaspriteBoxBody Object, Animation, "LEFT", VramOffset, Palette, XOffset, YOffset, Spr1, Spr2, Spr3, Spr4
.endif
MetaspriteBoxBody Object, Animation, "RIGHT", VramOffset, Palette, XOffset, YOffset, Spr1, Spr2, Spr3, Spr4

.if PRINT_METASPRITE_IDS
.out .sprintf("#define METASPRITE_%s_%s 0x%02x", Object, Animation, METASPRITES_COUNT)
.endif
.if Mirror = 1
.ident( .sprintf("METASPRITE_LEFT_%d_LO",  METASPRITES_COUNT) ) = .lobyte(.ident( .sprintf("MetaspriteData_%s_%s_LEFT", Object, Animation) ))
.ident( .sprintf("METASPRITE_LEFT_%d_HI",  METASPRITES_COUNT) ) = .hibyte(.ident( .sprintf("MetaspriteData_%s_%s_LEFT", Object, Animation) ))
.else
.ident( .sprintf("METASPRITE_LEFT_%d_LO",  METASPRITES_COUNT) ) = .lobyte(.ident( .sprintf("MetaspriteData_%s_%s_RIGHT", Object, Animation) ))
.ident( .sprintf("METASPRITE_LEFT_%d_HI",  METASPRITES_COUNT) ) = .hibyte(.ident( .sprintf("MetaspriteData_%s_%s_RIGHT", Object, Animation) ))
.endif

.ident( .sprintf("METASPRITE_RIGHT_%d_LO",  METASPRITES_COUNT) ) = .lobyte(.ident( .sprintf("MetaspriteData_%s_%s_RIGHT", Object, Animation) ))
.ident( .sprintf("METASPRITE_RIGHT_%d_HI",  METASPRITES_COUNT) ) = .hibyte(.ident( .sprintf("MetaspriteData_%s_%s_RIGHT", Object, Animation) ))


.endif

MetaspriteReserve .sprintf("%s_%s",Object, Animation)
.endmacro

.macro MetaspriteDuplicate Name, Mspr
.Local LL, LH, RL, RH, Id, Bank
Id = .ident( .concat("METASPRITE_", Mspr) )
Bank = .ident( .sprintf("METASPRITE_%d_BANK", Id) )
.ident( .sprintf("METASPRITE_%d_BANK",  METASPRITES_COUNT) ) = Bank

.ifdef METASPRITE_BODY
.if PRINT_METASPRITE_IDS
.out .sprintf("#define METASPRITE_%s 0x%02x // (duplicate of %s)", Name, METASPRITES_COUNT, Mspr)
.endif

LL = .ident(.sprintf("METASPRITE_LEFT_%d_LO", Id))
LH = .ident(.sprintf("METASPRITE_LEFT_%d_HI", Id))
RL = .ident(.sprintf("METASPRITE_RIGHT_%d_LO", Id))
RH = .ident(.sprintf("METASPRITE_RIGHT_%d_HI", Id))

.ident( .sprintf("METASPRITE_LEFT_%d_LO",  METASPRITES_COUNT) ) = LL
.ident( .sprintf("METASPRITE_LEFT_%d_HI",  METASPRITES_COUNT) ) = LH
.ident( .sprintf("METASPRITE_RIGHT_%d_LO",  METASPRITES_COUNT) ) = RL
.ident( .sprintf("METASPRITE_RIGHT_%d_HI",  METASPRITES_COUNT) ) = RH

.endif

MetaspriteReserve Name
.endmacro


;;;;
; Reserves a spot in the metasprite table for this named constant.
; This is used internally when making a new metasprite, but can also
; be used to make your own metasprite. Just reserve a slot with the name
; of the metasprite and 
.macro MetaspriteReserve Name
.ident( .sprintf("METASPRITE_%s", Name) ) = METASPRITES_COUNT
METASPRITES_COUNT .set METASPRITES_COUNT + 1
.endmacro

.macro MetaspriteData Name, Left, Right
.Local Id

; Check to see if the name is already reserved. If not, add a new slot for it.
.if .not(.defined( .ident( .sprintf("METASPRITE_%s", Name) ) ))
  MetaspriteReserve Name
.endif
Id = .ident( .sprintf("METASPRITE_%s", Name) )

.ident( .sprintf("METASPRITE_LEFT_%d_LO",  Id) ) = .lobyte(Left)
.ident( .sprintf("METASPRITE_LEFT_%d_HI",  Id) ) = .hibyte(Left)
.ifnblank Right
.ident( .sprintf("METASPRITE_RIGHT_%d_LO", Id) ) = .lobyte(Right)
.ident( .sprintf("METASPRITE_RIGHT_%d_HI", Id) ) = .hibyte(Right)
.else
.ident( .sprintf("METASPRITE_RIGHT_%d_LO", Id) ) = .lobyte(Left)
.ident( .sprintf("METASPRITE_RIGHT_%d_HI", Id) ) = .hibyte(Left)
.endif

.endmacro


.pushseg
.segment "FIXED"
.proc PlayerOAMReservation
  lda #4 * 4
.if ::ENABLE_CROSSOVER
  ldx SelectedCharacter
  beq Ready
    lda #MEGAMAN_MAX_SPRITES * 4
    cpx #CHARACTER_SAMUS
    bne :+
      lda #SAMUS_MAX_SPRITES * 4
    :
    cpx #CHARACTER_BILL
    bcc :+
      lda #16 * 4
    :
    ldx MmDeathFlag
    beq Ready
      lda #24 * 4
Ready:
.endif
.if ::MOUSE_DISPLAY_CURSOR
  clc
  adc #2 * 4
.endif
  rts
.endproc
.popseg

.proc DrawAllMetasprites

LoopCount = M0
.if ::ENABLE_CROSSOVER && ::MAPPER_MMC3
  lda #0
  sta GuestHudMixed
  lda #28
  sta GuestHudNextDelay
.endif

  ; Poses use different sprite counts. Hide the whole player reservation
  ; before drawing anything, including the death burst into that reservation.
.if ::ENABLE_CROSSOVER
  jsr HpGraphicsBankCopy
.endif
 .if ::ENABLE_CROSSOVER
.if ::ENABLE_MMC5_EXPANDED
  lda SelectedCharacter
  cmp #CHARACTER_BILL
  bcs RotateGuestOAM
  lsr
  bcc MmReserveNonMega
  jmp MmReserveBegin
MmReserveNonMega:
  lsr
  sta GuestOamRotationActive
  jmp ClearReservedPlayer
.else
  lda SelectedCharacter
  cmp #CHARACTER_MEGAMAN
  beq RotateGuestOAM
  cmp #CHARACTER_BILL
  bcs RotateGuestOAM
  lda #0
  sta GuestOamRotationActive
  jmp ClearReservedPlayer
.endif
RotateGuestOAM:
  lda #1
  sta GuestOamRotationActive
  ; Move the hardware's first-sprite priority through the entire OAM list.
  ; Keep allocation offsets logical, so body/weapon budgets are unchanged.
.if ::ENABLE_MMC5_EXPANDED
  ; Keep the full bank4 draw gate bounded; the expanded selector retains the
  ; same rotation and skips only pivots that split Meta's native layers.
  farcall KbOamPriority
.else
  lda RgOamUsed
  beq FirstRosterDraw
  lsr
  lsr
  tax
  lda RosterRotationStep,x
  clc
  adc RgOamFirst
  bcs WrapRosterPriority
  cmp RgOamUsed
  bcc RosterPriorityReady
WrapRosterPriority:
  sec
  sbc RgOamUsed
  jmp RosterPriorityReady
FirstRosterDraw:
  lda #0
RosterPriorityReady:
  sta RgOamFirst
  eor #$ff
  clc
  adc #1
  sta RgOamRotation
.endif
.if ::ENABLE_MMC5_EXPANDED
  ldx #0
::MmReserveClear:
.endif
  ; Give weapons the first OAM slots. Transparent portions of layered bodies
  ; still consume the PPU's eight sprites per line and must not hide shots.
  lda #$f8
  ; The entire rotated OAM ring must be hidden, even on sparse frames. Direct
  ; stores save 767 CPU cycles compared with 64 indexed stores/increments.
 .repeat 64, I
  sta Sprite_Y_Position+I*4
 .endrepeat
.if !::ENABLE_MMC5_EXPANDED
  ldx #0
.endif
  stx CurrentOAMOffset
.if ::ENABLE_MMC5_EXPANDED
  farcall RlSpecialDrawDispatch
.else
  farcall SpecialDrawShots
.endif
  lda SelectedCharacter
  cmp #CHARACTER_MEGAMAN
  bne RosterShots
  jsr MegaManDrawShots
.if ::ENABLE_MMC5_EXPANDED
  jsr MmReserveFinish
  jmp InitObjectLoop
  .res 13,$ea
.else
  lda CurrentOAMOffset
  sta RgOamPlayerStart
::MegaManProjectileOamReady:
  jsr PlayerOAMReservation
  clc
  adc CurrentOAMOffset
  sta CurrentOAMOffset
  jmp InitObjectLoop
.endif
RosterShots:
.if ::ENABLE_MMC5_EXPANDED
  jsr KbDrawDispatch
.else
  jsr RosterDrawShots
.endif
  lda CurrentOAMOffset
  sta RgOamPlayerStart
::RosterProjectileOamReady:
  lda SmPosePtr
  sta R0
  lda SmPosePtr+1
  sta R1
  ldy #0
  lda (R0),y
  clc
  adc CurrentOAMOffset
  sta CurrentOAMOffset
  jmp InitObjectLoop
ClearReservedPlayer:
.endif
  jsr PlayerOAMReservation
  tax
  lda #$f8
ClearPlayerOAM:
  dex
  dex
  dex
  dex
  sta Sprite_Y_Position,x
.if !::ENABLE_MMC5_EXPANDED
  cpx #0
.endif
  bne ClearPlayerOAM
.if ::ENABLE_MMC5_EXPANDED
  sec
.endif

InitObjectLoop:
  lda #24 - 1 ; size of the different object update list
  sta LoopCount
  lda SpriteShuffleOffset
  clc
  adc #19
  cmp #24
  bcc :+
    ; implicit carry set
    sbc #24
:
  sta SpriteShuffleOffset
  lda FrameCounter
  lsr
  lda SpriteShuffleOffset
  bcc ObjectLoopNegative

ObjectLoopPositive:
    clc
    adc #13
    cmp #24
    bcc :+
      ; implicit carry set
      sbc #24
    :
    ; Index zero is the reserved world-firebar turn. Share the shuffled OAM
    ; budget with ordinary objects instead of always drawing firebars last.
.if ::ENABLE_CROSSOVER
    beq PositiveFirebars
.else
    beq NextLoop
.endif
      ; TODO check offscreenbits to make sure they are onscreen still
      tay
      ldx ObjectMetasprite,y
      beq NextLoop
      cpx #METASPRITES_COUNT ; todo remove this after fixing all bugs
      bcs NextLoop
        sta SpriteShuffleOffset
        jsr DrawMetasprite
        lda SpriteShuffleOffset
  NextLoop:
    dec LoopCount
    bpl ObjectLoopPositive
  jmp HandleFloateyNumbers
.if ::ENABLE_CROSSOVER
PositiveFirebars:
  jsr WorldFirebarDrawAdmission
  lda #0
  beq NextLoop
.endif

ObjectLoopNegative:
    sec
    sbc #13
    bcs :+
      ; implicit carry clear
      adc #24
    :
.if ::ENABLE_CROSSOVER
    beq NegativeFirebars
.else
    beq NextLoop2
.endif
      ; TODO check offscreenbits to make sure they are onscreen still
      tay
      ldx ObjectMetasprite,y
      beq NextLoop2
      cpx #METASPRITES_COUNT ; todo remove this after fixing all bugs
      bcs NextLoop2
        sta SpriteShuffleOffset
        jsr DrawMetasprite
        lda SpriteShuffleOffset
  NextLoop2:
    dec LoopCount
    bpl ObjectLoopNegative
.if ::ENABLE_CROSSOVER
  jmp HandleFloateyNumbers
NegativeFirebars:
  jsr WorldFirebarDrawAdmission
  lda #0
  beq NextLoop2
.endif

HandleFloateyNumbers:
  sta SpriteShuffleOffset
.if ::ENABLE_CROSSOVER
  jsr DrawBrickDebris
  farcall SamusDrawShots
  jsr MegaManFullShotBank
.endif

  ldx #7-1
FloateyNumberLoop:
    lda FloateyNum_Control,x     ;load control for floatey number
    beq Skip                     ;if zero, branch to leave
      phx
        jsr FloateyNumberRender
      plx
  Skip:
    dex
    bpl FloateyNumberLoop
  
  lda CurrentOAMOffset
  pha

    ; put the player in slot 0 always
    lda #0
.if ::ENABLE_CROSSOVER
    ldx GuestOamRotationActive
    beq :+
      lda RgOamPlayerStart
    :
.endif
    sta CurrentOAMOffset

.if ::MOUSE_DISPLAY_CURSOR
    lda mouse
    bmi connected
      ; not connected so draw the alternate sprite at the middle of the screen
      lda #256 / 2 - 8
      sta mouse + kMouseX
      lda #240 / 2 - 8
      sta mouse + kMouseY

      lda FrameCounter
      and #%00100000
      beq useothersprite ; switch between connected and not connected
        ldy #1
        bne loadmetasprite ;unconditional
      useothersprite:
        ldy #0
        beq loadmetasprite
connected:
    ldy MouseState
loadmetasprite:
    ldx MouseStateMetasprite,y
    lda MetaspriteTableLeftLo,x
    sta R0 ; Ptr
    lda MetaspriteTableLeftHi,x
    sta R1 ; Ptr
    lda #0
    sta R3 ; Atr
    lda mouse + kMouseX
    sta R4 ; Xlo
    lda #0
    sta R5 ; Xhi
    lda mouse + kMouseY
    sta R6 ; Ylo
    lda #1
    sta R7 ; Yhi
    jsr MetaspriteRenderLoop
.endif

    ldy #0
    ldx ObjectMetasprite,y
    ; unless the player is currently flickering due to damage taken
    beq DoneDrawingPlayer
      ; Load the bank for the player if it changed
.if ::ENABLE_CROSSOVER
      lda ObjectMetasprite
      cmp #METASPRITE_SAMUS_BODY
      bne :+
        lda SmChrBank
        jmp PlayerBankReady
      :
      cpx #METASPRITE_MEGAMAN_STANDING
      bcc :+
        lda MegaManSpriteBanks-METASPRITE_MEGAMAN_STANDING,x
        jmp PlayerBankReady
      :
.endif
      lda PlayerBankTable,x
PlayerBankReady:
      cmp PlayerChrBank
      beq :+
        sta PlayerChrBank
        inc ReloadCHRBank
      :
      jsr DrawMetasprite
  DoneDrawingPlayer:
.if ::ENABLE_CROSSOVER && ::MAPPER_MMC3
    jsr GuestHudOamOrder
.endif
 .if ::ENABLE_CROSSOVER
    lda GuestOamRotationActive
.if ::ENABLE_MMC5_EXPANDED
    bmi MmReserveExitBranch
.endif
    beq LegacyTailClear
      ; The full ring was hidden at entry; no linear tail clear is needed.
::MmReserveRosterTail:
      pla
      sta RgOamUsed
      lda RgOamFirst
      cmp RgOamUsed
      bcc RosterPriorityInRange
        lda #0
        sta RgOamFirst
RosterPriorityInRange:
::RosterOamReady:
      rts
LegacyTailClear:
 .endif
    
  ; Clear sprites up to the offset
  ; Calculate CurrentOAMOffset / 4 * 3 and add that to the OAM clear to jump
  ; the middle of the clear routine based on how many we need to clear
  pla ; CurrentOAMOffset
  lsr 
  sta M0
  lsr 
  ; clc - always cleared
  adc M0
  ; clc - always cleared
  adc #<OAMClear
  sta M0
  lda #>OAMClear
  adc #0
  sta M1
  lda #$f8
  jmp (M0)

.if ::MOUSE_DISPLAY_CURSOR
MouseStateMetasprite:
  .byte METASPRITE_MOUSE_POINTER
  .byte METASPRITE_MOUSE_DISCONNECTED
  .byte METASPRITE_MOUSE_PINCH
.endif
.endproc

.if ::ENABLE_CROSSOVER
.proc WorldFirebarDrawAdmission
.if ::ENABLE_MMC5_EXPANDED
::WorldFirebarAdmission:
 farcall Z2LateWorldAdmission
 jmp WorldFirebarAdmissionDone
::MmReserveExitBranch:
 jmp MmReserveExit
 .res 12,$ea
::WorldFirebarAdmissionDone:
 rts
 .assert *-WorldFirebarDrawAdmission=37,lderror,"Body-reservation resident span"
.else
::WorldFirebarAdmission:
  ; No matching ID can produce a firebar. Keep the existing live-owner checks.
  ldx #5
CheckFirebarID:
  lda Enemy_ID,x
  cmp #$1b
  bcc NextFirebarID
  cmp #$23
  bcc DrawFirebars
NextFirebarID:
  dex
  bpl CheckFirebarID
  stx FirebarSlot
  bmi FirebarsReady
DrawFirebars:
  farcall DrawWorldFirebars
FirebarsReady:
::WorldFirebarAdmissionDone:
  rts
.endif
.endproc
.endif

.if ::ENABLE_CROSSOVER
; Step through the allocated list rather than all 64 slots. Coprime steps
; prevent an unlucky body/projectile count from starving particular parts.
.if .not ::ENABLE_MMC5_EXPANDED
RosterRotationStep:
  .byte 0
.repeat 63, I
 .scope
  N = I+1
  .if N=1
    .byte 0
  .elseif (N .mod 7)=0
    .if (N .mod 5)=0
      .byte (3 .mod N)*4
    .else
      .byte (5 .mod N)*4
    .endif
  .else
    .byte (7 .mod N)*4
  .endif
 .endscope
.endrepeat
.endif
.pushseg
.segment "SRAM"
DebrisSlot: .res 1
DebrisPart: .res 1
.popseg
.proc DrawBrickDebris
  ; Native physics runs before DrawAllMetasprites. Draw its four chunks here
  ; so clearing/reserving OAM cannot erase them, including on the OAM ring.
  lda #1
  sta DebrisSlot
Slot:
  ldx DebrisSlot
  lda Block_State,x
  cmp #2
  jne NextSlot
  lda #0
  sta DebrisPart
Part:
  farcall SamusFreezeDebrisPosition
  jmp PositionReady
::SamusFreezeDrawAll:
  lda SmFreezeRenderState
  beq NativeDraw
  jsr DrawAllMetasprites
  farcall SamusFreezeRenderFinish, jmp
NativeDraw:
  jmp DrawAllMetasprites
::SamusFreezeFlashOwner:
  cmp #CHARACTER_RYU
  beq NativeFlash
  cmp #CHARACTER_SAMUS
  bne FreezeDone
  lda SmFreezeRenderState
  beq FreezeDone
  farcall SamusFreezeColorActor
FreezeDone:
  jmp SmFreezeNativeFlashDone
NativeFlash:
  jmp SmFreezeNativeFlashEnemy
  .res 90-(*-DrawBrickDebris::Part), $ea
PositionReady:
  lda #<Chunk
  sta R0
  lda #>Chunk
  sta R1
  lda FrameCounter
  asl
  asl
  asl
  asl
  and #$c0
  ora #3
  sta R3
  jsr MetaspriteRenderLoop
  inc DebrisPart
  lda DebrisPart
  cmp #4
  jcc Part
NextSlot:
  dec DebrisSlot
  jpl Slot
  rts
Chunk:
  .byte 4, BRICK_CHUNK_TILE, 0, 0, 0
.endproc
.endif

MoveAllSpritesOffscreen:
  ldy #0
  sty CurrentOAMOffset
  lda #$f8
OAMClear:
.repeat 64, I
    sta Sprite_Y_Position + I*4 ; write 248 into OAM data's Y coordinate
.endrepeat
  rts


LsrFlashPalettes: .byte 2,1,2,3 ; source rows0,1,2,3; see effect audit.
.proc DrawMetasprite
Ptr = R0
; OrigOffset = R2
Atr = R3
Xlo = R4
Xhi = R5
Ylo = R6
Yhi = R7
LoopCount = M0
VFlip = M1
  
  lda PlayerFacingDir,y
  lsr
  bne FacingLeft
    lda MetaspriteTableRightLo,x
    sta Ptr
    lda MetaspriteTableRightHi,x
    sta Ptr+1
    bne DrawSprite ; unconditional
  FacingLeft:
    lda MetaspriteTableLeftLo,x
    sta Ptr
    lda MetaspriteTableLeftHi,x
    sta Ptr+1
DrawSprite:

.if ::ENABLE_CROSSOVER
  ; The once-per-DrawAll preparation validates each indirect slot. A zero
  ; high byte keeps its original immutable native metasprite pointer.
::HpNativePointerBegin:
  cpy #7
  bcs :+
  lda HpNativeDrawHi,y
  beq :+
    sta Ptr+1
    lda HpNativeDrawLo,y
    sta Ptr
 .if ::ENABLE_MMC5_EXPANDED
    jmp MmDynamicPlayerPrgOwner
    .res 2,$ea
 .else
    .res 5,$ea
 .endif
  :
::HpNativePointerEnd:
  .assert HpNativePointerEnd-HpNativePointerBegin=21,error,"Original pointer span"
.endif
  ; sty OrigOffset

  lda SprObject_X_Position,y
  sec
  sbc ScreenLeft_X_Pos
  sta Xlo
  lda SprObject_PageLoc,y
  sbc ScreenLeft_PageLoc
  sta Xhi
  lda SprObject_Y_HighPos,y
  sta Yhi
  
  lda #0
  sta VFlip
  cpy #7
  bcs SkipVerticalFlipCheck
    lda ObjectVerticalFlip,y
    bpl NoVFlip
      ; Object has a vertical flip attribute set
      sta VFlip
  NoVFlip:
      ; Object has an added Y offset
      ; The negative flag is bit 5 in our number, so sign extend the value
      and #%00111111
      cmp #%00100000
      bcc PositiveYOffset
        ; subtracting a small negative offset here
        ora #%11000000
        clc
        adc SprObject_Y_Position,y
        ; adding a negative number means if carry is clear, then "wrapped"
        bcs SetYOffset
          dec Yhi
          bcc SetYOffset ; unconditional
    PositiveYOffset:
      adc SprObject_Y_Position,y
      bcc SetYOffset
        ; If the carry is set, then we need to inc Yhi ... TODO
        ; this probably doesn't handle underflow properly?
        inc Yhi
        bcs SetYOffset ; unconditional
SkipVerticalFlipCheck:
    lda SprObject_Y_Position,y
SetYOffset:
  sta Ylo

  lda VFlip
  beq DontSetFlipBit
    lda #OAM_FLIP_V
    .byte $2c ; masks the next lda #0
DontSetFlipBit:
    lda #0
  ora SprObject_SprAttrib,y
  sta Atr

.if ::ENABLE_CROSSOVER
  ; FLASH changes only this enemy's OAM palette. The four source phases use
  ; existing green/red/brown sprite palettes; no player/powerup palette writes.
  ; Bit3 in Atr is a software-only palette override, removed before OAM.
  cpy #1
  bcc LsrFlashDone
  cpy #7
  bcs LsrFlashDone
  lda SelectedCharacter
  cmp #CHARACTER_LINK
  beq LsrFlashEnemy
  jmp SamusFreezeFlashOwner
  nop
LsrFlashEnemy:
::SmFreezeNativeFlashEnemy:
  tya
  pha
  ; Bowser's rear is a native duplicate of one source object. Follow only
  ; a validated live Bowser primary; unrelated composite actors keep theirs.
  lda Enemy_ID-1,y
  cmp #Bowser
  bne LsrFlashSlotReady
  lda Enemy_Flag-1,y
  bpl LsrFlashSlotReady
  and #$7f
  cmp #6
  bcs LsrFlashNoColor
  tay
  lda Enemy_ID,y
  cmp #Bowser
  bne LsrFlashNoColor
  lda Enemy_Flag,y
  beq LsrFlashNoColor
  bmi LsrFlashNoColor
  iny
LsrFlashSlotReady:
  lda MmEnemyFlash-1,y
  beq LsrFlashNoColor
  lda #24
  sec
  sbc MmEnemyFlash-1,y
  lsr
  clc
  adc #1
  and #3
  tay
  lda Atr
  and #$fc
  ora LsrFlashPalettes,y
  ora #8
  sta Atr
LsrFlashNoColor:
  pla
  tay
LsrFlashDone:
::SmFreezeNativeFlashDone:
  cpy #0
  bne :+
    lda PlayerOutlinesOff
    beq :+
      ldx SelectedCharacter
 .if ::ENABLE_MMC5_EXPANDED
      jsr X5PlayerOutlineFlag
 .else
      lda PlayerOutlineCharacters,x
 .endif
      beq :+                    ; Skip characters with no added mask records.
      farcall PlayerRemoveOutlines
  :
.endif
.if ::ENABLE_CROSSOVER && ::MAPPER_MMC5
 .if ::ENABLE_MMC5_EXPANDED
  jsr RlNativeRenderDispatch
 .else
  jsr NativeGoombaRender
 .endif
.else
  jsr MetaspriteRenderLoop
.endif
  jcc DontShiftPositions        ; Rejected draws must not flip earlier sprites.

.if ::ENABLE_CROSSOVER
  ; Apply FLASH only to this completed actor span. Common draws keep the
  ; original per-tile cost; an active flash reuses R2 (unused before flips).
  lda Atr
  and #8
  beq LsrFlashDrawDone
  phx
  ldy #0
  lda (Ptr),y
  sta R2
  txa
  sec
  sbc R2
  tax
  ldy R2
LsrFlashDrawLoop:
  lda Sprite_Attributes,x
  eor Atr
  and #$fc
  eor Atr
  and #$f3
  sta Sprite_Attributes,x
  inx
  inx
  inx
  inx
  dey
  dey
  dey
  dey
  bne LsrFlashDrawLoop
  plx
LsrFlashDrawDone:
::LsrFlashDrawComplete:
.endif
  lda VFlip
  jeq DontShiftPositions
    ldy #0
    lda (Ptr),y
    cmp #8 + 1
    jcc DontShiftPositions
    cmp #12
    beq Flip3
      ; otherwise flip all 4 sprites
      ; Index within the OAM page explicitly: a rotated draw may straddle
      ; the end of the page, including vertically flipped enemies.
      txa
      sec
      sbc #4
      tay
      lda Sprite_Tilenumber,y     ;with first or second row tiles
      pha                         ;and save tiles to the stack
        tya
        sec
        sbc #4
        tay
        lda Sprite_Tilenumber,y
        pha
          tya
          sec
          sbc #4
          tay
          lda Sprite_Tilenumber,y
          pha
          tya
          sec
          sbc #4
          tay
          lda Sprite_Tilenumber,y
          sta R2
          pla
          sta R3
          pla
          sta Sprite_Tilenumber,y
          tya
          clc
          adc #4
          tay
          pla
          sta Sprite_Tilenumber,y
          tya
          clc
          adc #4
          tay
          lda R2
          sta Sprite_Tilenumber,y
          tya
          clc
          adc #4
          tay
          lda R3
          sta Sprite_Tilenumber,y
      rts
  Flip3:
    ; Custom flip code for bowser's front since he is weird.
    txa
    sec
    sbc #4
    tay
    lda Sprite_Y_Position,y
    pha
      tya
      sec
      sbc #8
      tay
      lda Sprite_Y_Position,y
      sta R2
      tya
      clc
      adc #4
      tay
      lda R2
      sta Sprite_Y_Position,y
      tya
      clc
      adc #4
      tay
      lda R2
      sta Sprite_Y_Position,y
    pla
    sta R2
    tya
    sec
    sbc #8
    tay
    lda R2
    sta Sprite_Y_Position,y
DontShiftPositions:
  rts

.endproc

.proc MetaspriteRenderLoop
Ptr = R0
Atr = R3
Xlo = R4
Xhi = R5
Ylo = R6
Yhi = R7

  ldx CurrentOAMOffset
  ldy #0
  lda (Ptr),y
.if ::ENABLE_CROSSOVER
  bne :+
    ; An absent pose must consume neither OAM nor bytes after its length.
::EmptyMetaspriteReturn:
    clc
    rts
  :
::MetaspriteHeaderCheck:
    tay                         ; Keep the length through validation/rotation.
    and #3
    beq :+
      ; The loop consumes four bytes per sprite. An invalid header must
      ; never wrap forever without reaching zero.
HeaderRejected:
      tya
      ldy #0
      ora #0                    ; Match the old PLA's A/N/Z on rejection.
      clc
      rts
    :
::MetaspriteHeaderValid:
  tya
  clc
  adc CurrentOAMOffset
  bcs HeaderRejected
  ldx CurrentOAMOffset
  lda GuestOamRotationActive
  beq :+
    txa
    clc
    adc RgOamRotation
    tax
  :
  tya
.else
  tay
.endif
  bpl RenderLoop

; Offscreen sprites end up here

Skip4:   ; X Offscreen
    dey
Skip3:   ; Y Offscreen
    dey
Skip2:
    dey
    ; Move this sprite offscreen
    lda #$f8
    sta Sprite_Y_Position,x
    inx
    inx
    inx
    inx
    dey
    jeq LoopEnded
RenderLoop:
    ; load the x position and make sure its on screen
    clc
    lda (Ptr),y
    bpl PositiveX
      adc Xlo
      sta Sprite_X_Position,x
      lda Xhi
      adc #$ff
      beq ContinueAfterX
      bne Skip4
  PositiveX:
    adc Xlo
    sta Sprite_X_Position,x
    lda Xhi
    adc #0
    bne Skip4
  ContinueAfterX:
    dey

    ; load the y position and also make sure its on screen
    clc
    lda (Ptr),y
    bpl PositiveY
      ; NegativeY
      adc Ylo
      sta Sprite_Y_Position,x
      lda Yhi
      adc #$ff
      cmp #1      ; page 1 is the "main" y position
      beq ContinueAfterY
      bne Skip3
  PositiveY:
    adc Ylo
    sta Sprite_Y_Position,x
    lda Yhi
    adc #0
    cmp #1      ; page 1 is the "main" y position
    bne Skip3
  ContinueAfterY:
    dey

    ; Mix attributes but if the NO_PALETTE bit is set, prevent
    ; the palette from changing.
    lda (Ptr),y
    bit NoPaletteBitMask
    beq AllowPaletteChange
      ; No palette change bit set, so pull the byte and
      ; mask off the palette from the attribute byte
      lda Atr
      and #%11111100
      ora (Ptr),y
      bne WritePalette ; unconditional
AllowPaletteChange:
    ora Atr
WritePalette:
.if ::ENABLE_CROSSOVER
    and #$f3                    ; Bits2/3 tag software-only outline/FLASH.
.endif
    sta Sprite_Attributes,x
    dey

    ; set the tile number and move to the next sprite
    lda (Ptr),y
    sta Sprite_Tilenumber,x
.if ::ENABLE_CROSSOVER && ::MAPPER_MMC3
    ; Mixed 8x16 pattern tables can clock MMC3 more than once per HUD row.
    and #1
    bne :+
      lda Sprite_Y_Position,x
      cmp #32
      bcc MarkMixedHud
      cmp #224
      bcc :+
      cmp #240
      bcs :+
MarkMixedHud:
        inc GuestHudMixed
    :
.endif
    inx
    inx
    inx
    inx
    dey
    jne RenderLoop
LoopEnded:
.if ::ENABLE_CROSSOVER
  txa
  ldy GuestOamRotationActive
  beq :+
    sec
    sbc RgOamRotation
  :
  sta CurrentOAMOffset
.else
  stx CurrentOAMOffset
.endif
  ldy #0
  sec
  rts

NoPaletteBitMask:
  .byte (SPR_NO_PALETTE >> 8)
.endproc

.if ::ENABLE_CROSSOVER && ::MAPPER_MMC3
.pushseg
.segment "SRAM"
GuestHudMixed: .res 1
GuestHudRows: .res 33            ; HUD fetch rows 0..31 and the final visible row.
GuestHudNextDelay: .res 1
GuestHudIrqDelay: .res 1
.segment "METASPRITE"
.proc GuestHudOamOrder
  lda GuestHudMixed
  jeq Done
  lda Sprite0HitDetectFlag
  jeq Done
  lda #0
  ldx #32
Clear:
  sta GuestHudRows,x
  dex
  bpl Clear
  sta R1                         ; Next hardware slot for low-table HUD parts.
  ldx #0
Part:
  lda Sprite_Y_Position,x
  cmp #32
  bcc TopPart
  cmp #224
  jcc Next
  cmp #240
  jcs Next
  lda Sprite_Tilenumber,x
  and #1
  jne Next
  lda GuestHudRows+32
  cmp #7
  jcs Hide
  inc GuestHudRows+32
  jmp Move
TopPart:
  sta R3
  lda Sprite_Tilenumber,x
  and #1
  jne Next
  lda R3
  clc
  adc #16
  cmp #32
  bcc :+
    lda #32
  :
  sta R2
  ldy R3
Check:
  lda GuestHudRows,y
  cmp #7
  bcs Hide                       ; Keep an A12-high sprite/dummy fetch per row.
  iny
  cpy R2
  bcc Check
  ldy R3
Count:
  lda GuestHudRows,y
  clc
  adc #1
  sta GuestHudRows,y
  iny
  cpy R2
  bcc Count
Move:
  ldy R1
  ; All A12-low HUD parts precede high parts, giving one qualified rising
  ; edge per scanline. Include sprites selected on row 239: secondary OAM
  ; survives vblank and is fetched again on the pre-render line, where a
  ; high/low/high sequence would advance the next frame's counter twice.
  ; Preserve tile/attribute/position as a complete sprite.
 .repeat 4,I
  lda Sprite_Data+I,x
  pha
  lda Sprite_Data+I,y
  sta Sprite_Data+I,x
  pla
  sta Sprite_Data+I,y
 .endrepeat
  lda R1
  clc
  adc #4
  sta R1
  jmp Next
Hide:
  lda #$f8
  sta Sprite_Y_Position,x
Next:
  inx
  inx
  inx
  inx
  jne Part
  ; The $1f counter reaches zero on scanline30. Sprite fetches on that
  ; line raise IRQ; the handler finishes the scroll split on scanline31.
  ; OAM Y=15 covers fetch rows15..30, so the row31 count can differ.
  ldx GuestHudRows+30
  lda Delays,x
  sta GuestHudNextDelay
Done:
  rts
; Low-table sprites in the IRQ-trigger row postpone the one A12 rise by
; eight PPU dots each.
; Compensate by floor(8*N/3) CPU cycles. The IRQ's redundant AND was removed
; to offset the absolute delay load's two extra cycles.
Delays: .byte 28,26,23,20,18,15,12,10
.endproc
.popseg
.endif

; ;-------------------------------------------------------------------------------------
.proc FloateyNumberRender
Ptr = R0
; OrigOffset = R2
Atr = R3
Xlo = R4
Xhi = R5
Ylo = R6
Yhi = R7

  lda FloateyNum_Y_Pos,x       ;get vertical coordinate for
  cmp #$18                     ;floatey number, if coordinate in the
  bcc SetupNumSpr              ;status bar, branch
    sbc #$01
    sta FloateyNum_Y_Pos,x       ;otherwise subtract one and store as new
SetupNumSpr:
  sta Ylo
  lda #1
  sta Yhi
  lda #0
  sta Atr
  sta Xhi
  lda FloateyNum_X_Pos,x
  sta Xlo
  ldy FloateyNum_Control,x
  ldx FloateyNumMetasprites-1,y
  lda MetaspriteTableRightLo,x
  sta Ptr
  lda MetaspriteTableRightHi,x
  sta Ptr+1
  jmp MetaspriteRenderLoop
  ; implicit rts

FloateyNumMetasprites:
  .byte METASPRITE_NUMBER_100
  .byte METASPRITE_NUMBER_200
  .byte METASPRITE_NUMBER_400
  .byte METASPRITE_NUMBER_500
  .byte METASPRITE_NUMBER_800
  .byte METASPRITE_NUMBER_1000
  .byte METASPRITE_NUMBER_2000
  .byte METASPRITE_NUMBER_4000
  .byte METASPRITE_NUMBER_5000
  .byte METASPRITE_NUMBER_8000
  .byte METASPRITE_NUMBER_1UP

.endproc
