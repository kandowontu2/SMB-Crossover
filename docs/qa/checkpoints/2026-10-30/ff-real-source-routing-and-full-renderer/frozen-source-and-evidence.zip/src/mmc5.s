

.pushseg

; .segment "ZEROPAGE"
; safecall_ptr: .res 2

.segment "SHORTRAM"
safecall_a: .res 1
; safecall_x: .res 1
; safecall_y: .res 1
CurrentBank: .res 1
ReloadCHRBank: .res 1
CurrentCHRBank: .res 12
AreaChrBank := CurrentCHRBank + 8
PlayerChrBank := CurrentCHRBank + 0
EnemyChrBank := CurrentCHRBank + 2

.popseg


IRQ_STATUS = $5204

.macro MAPPER_IRQ_ACK
  bit IRQ_STATUS
.endmacro

MMC5_PRG_ROM = %10000000

MMC5_PRG_BANK_BASE = $5113
MMC5_PRG_BANK_6 = MMC5_PRG_BANK_BASE + 0
MMC5_PRG_BANK_8 = MMC5_PRG_BANK_BASE + 1
MMC5_PRG_BANK_A = MMC5_PRG_BANK_BASE + 2
MMC5_PRG_BANK_C = MMC5_PRG_BANK_BASE + 3
MMC5_PRG_BANK_E = MMC5_PRG_BANK_BASE + 4

MMC5_CHR_BANK_BASE = $5120
MMC5_CHR_SPR_BANK_00 = MMC5_CHR_BANK_BASE + 0
MMC5_CHR_SPR_BANK_04 = MMC5_CHR_BANK_BASE + 1
MMC5_CHR_SPR_BANK_08 = MMC5_CHR_BANK_BASE + 2
MMC5_CHR_SPR_BANK_0C = MMC5_CHR_BANK_BASE + 3
MMC5_CHR_SPR_BANK_10 = MMC5_CHR_BANK_BASE + 4
MMC5_CHR_SPR_BANK_14 = MMC5_CHR_BANK_BASE + 5
MMC5_CHR_SPR_BANK_18 = MMC5_CHR_BANK_BASE + 6
MMC5_CHR_SPR_BANK_1C = MMC5_CHR_BANK_BASE + 7
MMC5_CHR_BG_BANK_00 = MMC5_CHR_BANK_BASE + 8
MMC5_CHR_BG_BANK_04 = MMC5_CHR_BANK_BASE + 9
MMC5_CHR_BG_BANK_08 = MMC5_CHR_BANK_BASE + 10
MMC5_CHR_BG_BANK_0C = MMC5_CHR_BANK_BASE + 11


.macro BankSprCHR00 bank
  _BANK_INNER bank, MMC5_CHR_SPR_BANK_00
.endmacro

.macro BankSprCHR04 bank
  _BANK_INNER bank, MMC5_CHR_SPR_BANK_04
.endmacro

.macro BankSprCHR08 bank
  _BANK_INNER bank, MMC5_CHR_SPR_BANK_08
.endmacro

.macro BankSprCHR0C bank
  _BANK_INNER bank, MMC5_CHR_SPR_BANK_0C
.endmacro

.macro BankSprCHR10 bank
  _BANK_INNER bank, MMC5_CHR_SPR_BANK_10
.endmacro

.macro BankSprCHR14 bank
  _BANK_INNER bank, MMC5_CHR_SPR_BANK_14
.endmacro

.macro BankSprCHR18 bank
  _BANK_INNER bank, MMC5_CHR_SPR_BANK_18
.endmacro

.macro BankSprCHR1C bank
  _BANK_INNER bank, MMC5_CHR_SPR_BANK_1C
.endmacro

.macro BankBgCHR00 bank
  _BANK_INNER bank, MMC5_CHR_BG_BANK_00
.endmacro

.macro BankBgCHR04 bank
  _BANK_INNER bank, MMC5_CHR_BG_BANK_04
.endmacro

.macro BankBgCHR08 bank
  _BANK_INNER bank, MMC5_CHR_BG_BANK_08
.endmacro

.macro BankBgCHR0C bank
  _BANK_INNER bank, MMC5_CHR_BG_BANK_0C
.endmacro

.macro BankPRG6 bank
  _BANK_INNER bank, MMC5_PRG_BANK_6
.endmacro

.macro BankPRG8 bank
  _BANK_INNER bank, MMC5_PRG_BANK_8
.endmacro

.macro BankPRGA bank
  _BANK_INNER bank, MMC5_PRG_BANK_A
.endmacro

.macro BankPRGC bank
.if ::ENABLE_CROSSOVER
  .if .match(bank, a)
    sta CurrentBankC
  .elseif .match(bank, x)
    stx CurrentBankC
  .elseif .match(bank, y)
    sty CurrentBankC
  .else
    .if (.match (.left (1, {bank}), #))
      lda #.right (.tcount ({bank})-1, {bank}) | MMC5_PRG_ROM
    .else
      lda bank
    .endif
    sta CurrentBankC
  .endif
.endif
  _BANK_INNER bank, MMC5_PRG_BANK_C
.endmacro

.macro BankPRGE bank
  _BANK_INNER bank, MMC5_PRG_BANK_E
.endmacro


.macro _BANK_INNER bank, ADDRESS
.scope
  .if .match(bank, a)
    sta ADDRESS
  .elseif .match(bank, x)
    stx ADDRESS
  .elseif .match(bank, y)
    sty ADDRESS
  .else
    .if (.match (.left (1, {bank}), #))
      lda #.right (.tcount ({bank})-1, {bank}) | MMC5_PRG_ROM ; todo handle ram banking
    .else
      lda bank
    .endif
    sta ADDRESS
  .endif
.endscope
.endmacro

.macro SetScanlineIRQ val
.if (.match (.left (1, {val}), #))
  lda #.right (.tcount ({val})-1, {val})
.else
  lda val
.endif
  sta $5203
  lda #$80
  sta $5204
.endmacro

.macro SwitchAreaCHR
.if ::ENABLE_MMC5_EXPANDED
 .local StartPublication,EndPublication
StartPublication:
  ; This NMI-only bridge does not touch shared farcall SMC or CurrentBank.
  lda CurrentBank
  pha
  lda #$be                       ; physical62 in the expanded cartridge
  sta MMC5_PRG_BANK_A
  jsr X5PublishChr
  tax
  pla
  sta MMC5_PRG_BANK_A
  txa
  jmp EndPublication
::DwResidentGraphicsSelector:
  ; Called by NMI audio as well as the main renderer. Never use shared
  ; farcall SMC here: it can interrupt a partially prepared main call.
  lda SelectedCharacter
  sec
  sbc #CHARACTER_PIT
  tax
  cpx #CHARACTER_SCROOGE-CHARACTER_PIT
  bne NativeGraphics
  lda DarkwingVariant
  beq NativeGraphics
  lda #68 | MMC5_PRG_ROM
  bne StoreGraphics
NativeGraphics:
  lda DwResidentGraphicsBanks,x ; rows already carry the ROM-select bit
StoreGraphics:
  sta CurrentBankC
  sta MMC5_PRG_BANK_C
  rts
::DwResidentGraphicsBanks:
  .byte (.bank(XgPIT0_STANDRight))|MMC5_PRG_ROM,(.bank(XgRYGAR0_STANDRight))|MMC5_PRG_ROM,(.bank(XgLUIGI0_STANDRight))|MMC5_PRG_ROM,(.bank(XgBASS0_STANDRight))|MMC5_PRG_ROM,(.bank(XgRYU0_STANDRight))|MMC5_PRG_ROM,(.bank(XgSOPHIA0_STANDRight))|MMC5_PRG_ROM,(.bank(XgSCROOGE_STANDRight))|MMC5_PRG_ROM,(.bank(KbArtStart))|MMC5_PRG_ROM,(.bank(CdArtBegin))|MMC5_PRG_ROM,(94)|MMC5_PRG_ROM,(97)|MMC5_PRG_ROM,(91)|MMC5_PRG_ROM,(76)|MMC5_PRG_ROM,(.bank(TnArtStart))|MMC5_PRG_ROM,(.bank(IcArtStart))|MMC5_PRG_ROM,(.bank(RcArtStart))|MMC5_PRG_ROM,$ff,(94)|MMC5_PRG_ROM
::Cv3ResidentRosterBank:
 ; Sole RosterGraphicsBank caller has X=SelectedCharacter-CHARACTER_BILL.
 cpx #CHARACTER_SIMON-CHARACTER_BILL
 bne Cv3BankLegacy
 lda Cv3Variant
 beq Cv3BankLegacy
 cmp #4
 bcs Cv3BankLegacy
 cmp #3
 lda #83
 bcc Cv3BankReturn
 lda #85
Cv3BankReturn:rts
Cv3BankLegacy:
 lda Cv3LegacyBanks,x
 rts
::Cv3ResidentAdder:
 cmp #CHARACTER_SIMON
 bne Cv3AdderLegacy
 lda Cv3Variant
 beq Cv3AdderLegacy
 cmp #4
 bcs Cv3AdderLegacy
 ldy Cv3CachedAdder
 sec
 rts
Cv3AdderLegacy:
 lda SelectedCharacter
 cmp #CHARACTER_BILL
 bne Cv3AdderOther
 jmp Cv3LegacyAdderBill
Cv3AdderOther:jmp Cv3LegacyAdderOther
::CheatsInjuryMask:
  lda CheatInvincible
  and #1
  ora InjuryTimer
  rts
  .res 136-(*-StartPublication),$ea ; old unrolled publication footprint
EndPublication:

.else
  .local SpecialChrDone
  .local HudChrDone
  .repeat 12, I
    lda CurrentCHRBank + I
.if ::ENABLE_CROSSOVER
    tay
    lda ChrPhysicalMap,y
.if I = 8
    ldy InvHudActive
    beq HudChrDone
      lda InvHudPhysical
HudChrDone:
.endif
.if I = 4
    ldy SsChrActive
    beq SpecialChrDone
      lda SsChrPhysical
SpecialChrDone:
.endif
.endif
    sta MMC5_CHR_BANK_BASE + I
  .endrepeat

.endif
.endmacro

.macro LoadAreaTypeCHR
  lda AreaTypeBankMap,y
  cmp AreaChrBank
  beq :+
    tax
  .repeat 4,I
    stx AreaChrBank+I
  .if I <> 3
    inx
  .endif
  .endrepeat
    ldx #CHR_MISC
  .repeat 7,I
    stx CurrentCHRBank + I + 1
  .if I <> 6
    inx
  .endif
  .endrepeat
    inc ReloadCHRBank
  :
  lda AreaType
  rts

AreaTypeBankMap:
  .byte CHR_BG_WATER, CHR_BG_GROUND, CHR_BG_UNDERGROUND, CHR_BG_CASTLE
.endmacro

.segment "FIXED"

MapperInit:
  ; Set PRG mode to 4 8kb banks
  lda #3
  sta $5100
  ; set CHR mode to 4 1kb banks
  sta $5101
  ; allow writing PRG RAM
  lda #2
  sta $5102
  lda #1
  sta $5103
  ; setup vertical mirroring
  lda #$44
  sta $5105

  ; Nestopia requires SRAM to be explicitly inited
  lda #0
  sta MMC5_PRG_BANK_6
  sta $5010                      ; Disable PCM read mode and its IRQ.
  sta $5015                      ; Expansion length counters survive reset.

  ; Setup default banks
  lda #$80
  sta CurrentBank
  BankPRGA #.bank(PLAYER)
  BankPRGC #.bank(DPCM_BANK0)
  BankPRG8 #.bank(LOWCODE)
  BankPRGE #.bank(FIXED)

.import __SMCCODE_SIZE__, __SMCCODE_LOAD__, __SMCCODE_RUN__ 
  ; Copy the Self Modifying Code for super fast farcall bank switches
  ldx #__SMCCODE_SIZE__ - 1
  :
    lda __SMCCODE_LOAD__,x
    sta __SMCCODE_RUN__,x
    dex
    bpl :-


  ; now setup the CHR banks
  ; To prevent graphics glitches, they must always be written in this order
.if ::ENABLE_MMC5_EXPANDED
  ; Preserve the original20-byte boot publication span and all following PCs.
X5BootPublication:
  lda #$be
  sta MMC5_PRG_BANK_A
  jsr X5ColdInit
  pha
  lda #.bank(PLAYER) | MMC5_PRG_ROM
  sta MMC5_PRG_BANK_A
  pla
  cpx #12                       ; restore original boot-loop flags exactly
  .res 20-(*-X5BootPublication),$ea
.else
  ldx #0
  :
    lda CHRBankInitValues,x
    sta CurrentCHRBank,x
.if ::ENABLE_CROSSOVER
    tay
    lda ChrPhysicalMap,y
.endif
    sta MMC5_CHR_BANK_BASE,x
    inx
    cpx #12
    bcc :-
.endif
  rts
CHRBankInitValues:
; SPR bank init values
  .byte CHR_SMALLMARIO, CHR_MISC, CHR_SPRITES, CHR_SPRITES+1
  .byte CHR_SPRITES+2, CHR_SPRITES+3, CHR_SPRITES+4, CHR_SPRITES+5

; BG bank init values
  .byte CHR_BG_GROUND, CHR_BG_GROUND+1, CHR_BG_GROUND+2, CHR_BG_GROUND+3


.segment "FIXED"
_FARCALL_COUNT .set 0

.macro farcall loc, usejmp
.scope
.assert .bank(loc) <> .bank(*), error, "Attempting to farcall to the same bank!"
.assert .bank(loc) <> .bank(LOWCODE), error, "Attempting to farcall to the low bank!"
.assert .bank(loc) <> .bank(FIXED), error, "Attempting to farcall to the fixed bank!"

  SMC_StoreValue SafecallA, a
  lda #.lobyte(loc)
  SMC_StoreLowByte FarcallJmpTarget, a
  lda #.hibyte(loc)
  SMC_StoreHighByte FarcallJmpTarget, a
  lda #.bank(loc) | MMC5_PRG_ROM
.ifblank usejmp
  jsr FarCallCommon
.else
  jmp FarCallCommon
.endif

::_FARCALL_COUNT .set ::_FARCALL_COUNT + 1

.endscope
.endmacro

; Private rare resident ABI: restore original MMC3 register selector.
.macro BillRareCall loc
.scope
.assert .bank(loc) <> .bank(*), error, "Attempting to farcall to the same bank!"
.assert .bank(loc) <> .bank(LOWCODE), error, "Attempting to farcall to the low bank!"
.assert .bank(loc) <> .bank(FIXED), error, "Attempting to farcall to the fixed bank!"

  SMC_StoreValue SafecallA, a
  lda #.lobyte(loc)
  SMC_StoreLowByte FarcallJmpTarget, a
  lda #.hibyte(loc)
  SMC_StoreHighByte FarcallJmpTarget, a
  lda #.bank(loc) | MMC5_PRG_ROM
  jmp BillRareCallCommon

::_FARCALL_COUNT .set ::_FARCALL_COUNT + 1

.endscope
.endmacro

;; TODO - redo this macro too
.macro far loc
.scope
.assert .bank(*) = .bank(FIXED) || .bank(*) = .bank(LOWCODE), error, "Cannot use far to read data when not in the fixed bank"
.assert .bank(loc) <> .bank(*), error, "Attempting to farcall to the same bank!"
.assert .bank(loc) <> .bank(LOWCODE), error, "Attempting to farcall to the low bank!"
.assert .bank(loc) <> .bank(FIXED), error, "Attempting to farcall to the fixed bank!"

  sta safecall_a

  lda CurrentBank
  pha
    lda #.bank(loc) | MMC5_PRG_ROM
    sta CurrentBank
    sta MMC5_PRG_BANK_A
    lda safecall_a

.endmacro

.macro endfar
    sta safecall_a
    pla
  sta CurrentBank
  sta MMC5_PRG_BANK_A
  lda safecall_a
.endscope
.endmacro

.segment "SMCCODE"
SMCCODE:

; Put the bank switching routine into RAM for fastest farcalls

.include "smc.inc"

FarCallCommon:
  SMC_StoreValue NextBank, a
  lda CurrentBank
  pha
    SMC NextBank, { lda #SMC_Value }
    sta CurrentBank
    BankPRGA a
    SMC SafecallA, { lda #SMC_Value }
    SMC FarcallJmpTarget, { jsr SMC_AbsAdr }
    SMC_StoreValue SafereturnA, a
  pla
  sta CurrentBank
  BankPRGA a
  SMC SafereturnA, { lda #SMC_Value }
  rts
