; PRIVATE source-informed ordinary drops/boss/hammer consumers.
; No new RAM: four existing native InvDrop slots, typed80/81/89 only.
.include "hazard-imports.inc"
.segment "ROGUE_DAWN_HOST_AUX"
.export RdHzAuxStart,RdHzAuxEnd,RdHzTerminal,RdHzUpdateDrops,RdHzDrawDrops
.export RdHzHammer,RdHzBossDefeat
RdHzAuxStart:

; Called only from the genuine paid source HP terminal branch. Preserve the
; original origin/type before native ShellOrBlockDefeat demotes/moves it.
.proc RdHzTerminal
 lda MmEnemyHealthLo,x
 ora MmEnemyHealthHi,x
 bne No
 jsr RdWxActorEligible
 bcc No
 lda Enemy_ID,x
 cmp #$2d
 jeq RdHzBossDefeat
 pha
 lda Enemy_X_Position,x
 pha
 lda Enemy_PageLoc,x
 pha
 lda Enemy_Y_Position,x
 pha
 jsr ShellOrBlockDefeat
 pla
 sta Rh4
 pla
 sta Rh3
 pla
 sta Rh2
 pla
 sta Rh5
 ; Verified terminal receipt; no drop for scripted bosses or unknown IDs.
 lda Enemy_State,x
 and #$20
 beq Done
 lda PseudoRandomBitReg+1       ; named actual native LFSR byte, not source2E
 cmp #$10
 bcc Done
 and #7
 tay
 lda Table,y                   ; exact default-area2 BFE7 weights
 cmp #$80
 bne Energy
 ldy RdMaxMissiles
 beq Done
Energy:
 cmp #$89
 bne Find
 ldy Rh5
 cpy #6                        ; authored Goomba -> sourceHP2/type4 bit0clear
 beq Done
Find:
 ldy #3
Loop:
 ldx InvDropKind,y
 beq Birth
 dey
 bpl Loop
Done:ldx ObjectOffset
 rts
No:rts
Birth:
 sta InvDropKind,y
 lda Rh2
 clc
 adc #8
 sta InvDropX,y
 lda Rh3
 adc #0
 sta InvDropPage,y
 lda Rh4
 clc
 adc #8
 sta InvDropY,y
 lda #96
 sta InvDropAge,y              ; actual source96 decrement clock, not4000ms
 lda #1
 sta InvDropAgeHi,y            ; birth update cannot collect before draw
 ldx ObjectOffset
 rts
Table:.byte $80,$81,$89,$80,$81,$89,$81,$89
.endproc

; Native front Bowser -> explicit source class8 HP32/miniboss40 adaptation.
; Real terminal normalizes/clears rear and pays native score/fall exactly once.
.proc RdHzBossDefeat
 lda #1
 sta BowserHitPoints
 stx R1
 jsr HandleEnemyFBallCol
 ldx ObjectOffset
 rts
.endproc

; Called only after the genuine hammer collision's physical speed reversal
; and from its verified ProcHammerObj return. No enemy/Misc slot confusion.
.proc RdHzHammer
 ldx ObjectOffset
 cpx #9
 bcs No
 lda Misc_State,x
 bpl No
 lda Misc_Collision_Flag,x
 cmp #1
 bne No
 lda Misc_Y_HighPos,x
 cmp #1
 bne No
 ldy HammerEnemyOffset,x
 cpy #5
 bcs No
 lda Enemy_Flag,y
 cmp #1
 bne No
 lda Enemy_ID,y
 cmp #5
 bne No
 lda Enemy_State,y
 and #$20
 bne No
 WxFar RdControlScrew
 bcc No                        ; native reflection already occurred unchanged
 lda Player_X_Position
 sec
 sbc Misc_X_Position,x
 lda Player_PageLoc
 sbc Misc_PageLoc,x
 ldy #$20
 bmi Ready
 ldy #$28
Ready:tya
 sec
 rts
No:clc
 rts
.endproc

; Source drop action5 runs on an actual next update, remains stationary,
; expires after96 actual Clock&3 decrements. Real full-page source player
; radius overlap; no auto grant, rising actor, fake owned result or health.
.proc RdHzUpdateDrops
 php
 pha
 jsr WxEnabled
 jcc Foreign
 pla
 plp
 lda TimerControl
 jne Done
 lda GameEngineSubroutine
 cmp #8
 jne Done
 lda ObjectOffset
 pha
 ldx #3
Loop:
 stx InvDropSlot
 lda InvDropKind,x
 jeq Next
 cmp #$80
 beq Typed
 cmp #$81
 beq Typed
 cmp #$89
 jne Next
Typed:
 lda InvDropAgeHi,x
 beq Mature
 lda #0
 sta InvDropAgeHi,x
 jeq Next
Mature:
 lda RdClock
 and #3
 bne Contact
 dec InvDropAge,x
 jeq Erase
Contact:
 lda Player_Y_HighPos
 cmp #1
 jne Next
 lda #4                       ; actual DD8B energy radiusY4 / missile8
 ldy InvDropKind,x
 cpy #$80
 bne Radius
 lda #8
Radius:clc
 adc RdRadiusY
 sta Rh4
 lda RdY
 sec
 sbc InvDropY,x
 sta Rh2
 lda #0
 sbc #0
 sta Rh3
 lda Rh2
 clc
 adc Rh4
 sta Rh2
 lda Rh3
 adc #0
 jne Next
 lda Rh4
 asl
 cmp Rh2
 jcc Next
 lda RdX
 clc
 adc RdRadiusX
 sta Rh2
 lda RdRoomHi
 adc #0
 sta Rh3
 lda Rh2
 clc
 adc #4                       ; actual all-three source radiusX4
 sta Rh2
 lda Rh3
 adc #0
 sta Rh3
 lda Rh2
 sec
 sbc InvDropX,x
 sta Rh2
 lda Rh3
 sbc InvDropPage,x
 jne Next
 lda RdRadiusX
 asl
 clc
 adc #8
 cmp Rh2
 jcc Next
 lda InvDropKind,x
 ldy #0                       ; A0 energy5 / A1 missile5 / A2 energy20
 cmp #$81
 beq Grant
 iny
 cmp #$80
 beq Grant
 iny
Grant:tya
 WxFar RdHzGrant
 ldx InvDropSlot
Erase:
 lda #0
 sta InvDropKind,x
Next:
 ldx InvDropSlot
 dex
 jpl Loop
 pla
 sta ObjectOffset
Done:rts
Foreign:pla
 plp
 WxTail Z2UpdateDropsGate
.endproc

; Same existing window6/page694 publication. Source drop records retained
; their authentic behind-background priority; body0 palette adaptation only.
.proc RdHzDrawDrops
 lda CurrentBankC
 pha
 ldx #3
Loop:
 stx InvDropSlot
 lda InvDropKind,x
 ldy #40
 cmp #$80
 beq Draw
 iny
 cmp #$81
 beq Draw
 iny
 cmp #$89
 jne Next
Draw:
 lda #<(.bank(RdWxAuxStart)|$80)
 sta CurrentBankC
 sta $5116
 lda RD_ITEM_LO_C,y
 sta R0
 lda RD_ITEM_HI_C,y
 sta R1
 lda #182
 cmp CurrentCHRBank+6
 bne Publish
 lda X5ChrMode+6
 cmp #$82
 beq Position
Publish:
 lda #182
 sta CurrentCHRBank+6
 lda #$82
 sta X5ChrMode+6
 lda #1
 sta ReloadCHRBank
 sta X5WideChrActive
Position:
 ; Stored source center -> the shared top-left record API subtracts8.
 lda InvDropX,x
 sec
 sbc #8
 sta R4
 lda InvDropPage,x
 sbc #0
 sta R5
 lda R4
 sec
 sbc ScreenLeft_X_Pos
 sta R4
 lda R5
 sbc ScreenLeft_PageLoc
 sta R5
 lda InvDropY,x
 sec
 sbc #8
 sta R6
 lda #1
 sbc #0
 sta R7
 lda #0
 sta R3
 WxFar MetaspriteRenderLoop
Next:
 ldx InvDropSlot
 dex
 jpl Loop
 pla
 sta CurrentBankC
 sta $5116
 rts
.endproc
RdHzAuxEnd:
.assert * <= $be00,error,"Preserve512B item/drop data tail"
