"""Execute the real cartridge loader through buffered PPUDATA. No RAM preload."""
from pathlib import Path
import hashlib,inspect,json,re,sys
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(Path(__file__).parent))
import quickman_host_controls_v3 as C
import quickman_wram_controls_v1 as K
H=K.H
O=R/'build/quickman-wram-host-v4';P=R/'build/quickman-host-cpu-v4'
CODE=(O/'code.bin').read_bytes();DATA=(O/'data.bin').read_bytes()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(n,d):(O/n).write_text(json.dumps(d,indent=2)+'\n',newline='\n')

class Bus(C.HostBus):
    def __init__(self,n=65536):
        path=O/'candidate.nes'
        if isinstance(n,dict):path=O/'dense-parent.nes'if n['raw']==(O/'dense-parent.nes').read_bytes()else O/'candidate.nes';n=65536
        super().__init__(n,path=path)
        self.ROM_banks=self.banks;self.banks=[126,88,87,127]
        self.tags=[0xfe,0xd8,0xd7,0xff]
        self.wram=[bytearray([0xa5])*8192 for _ in range(4)]
        self.chr=[i*7 for i in range(12)];self.upper=0;self.last_chr_BG=True
        self.vram=bytearray(16384);self.ppu_address=0;self.ppu_latch=0;self.buffer=0x6b
        self.ppu_ctrl=0xa0;self.ppu_mask=0;self.scroll=[0,0]
        self.ppu_reads=0;self.PPU_active_reads=0;self.cache_writes=[];self.corrupt=None
        self.executed_RAM=[];self.pc=0
        self.pad_bits=(0,0);self.pad_index=[0,0];self.pad_strobe=0;self.pad_reads=[0,0]
        self.ram[0x5102]=2;self.ram[0x5103]=1;self.ram[0x5113]=0
        for name,v in [('Mirror_PPUCTRL',0xa0),('Mirror_PPUMASK',0),('DisableScreenFlag',1),('NmiDisable',255)]:self.set(name,v)
        self.sync_chr11()
    def sync_chr11(self):
        mode=self.ram[self.lab['X5ChrMode']+11]
        value=self.ram[self.lab['CurrentCHRBank']+11]
        self.chr[11]=((mode&3)*256+value)if mode&128 and self.get('X5WideChrActive')else self.ROM_banks[127][(self.lab['ChrPhysicalMap']&8191)+value]
    def page(self,window,bank):
        self.tags[window]=bank|128;self.banks[window]=bank
        setattr(self,['low','A','C','high'][window],bank)
    def __getitem__(self,a):
        if isinstance(a,slice):return bytearray(self[i]for i in range(a.start or 0,a.stop,a.step or 1))
        if a in [0x4016,0x4017]:
            port=a-0x4016;i=self.pad_index[port];v=((self.pad_bits[port]>>(7-i))&1)if i<8 else 1
            if not self.pad_strobe:self.pad_index[port]+=1
            self.pad_reads[port]+=1;return v
        if a==0x2002:self.ppu_latch=0;return 0x80
        if a==0x2007:
            self.ppu_reads+=1
            if self.ppu_mask&24:self.PPU_active_reads+=1
            address=self.ppu_address&0x3fff;answer=self.buffer
            if address<0x2000:
                slot=8+((address>>10)&3)if self.last_chr_BG and self.ppu_ctrl&32 else(address>>10)&7
                at=16+128*8192+self.chr[slot]*1024+(address&1023)
                self.buffer=self.bundle['raw'][at]
            else:self.buffer=self.vram[address]
            self.ppu_address=(self.ppu_address+(32 if self.ppu_ctrl&4 else 1))&0x7fff
            return answer
        if self.publish_test_world and self.tags[1]==1 and a==self.lab['QuickManWorldProbe']:
            page=self.ram[4];tab=self.lab['BlockBufferAddr'];base=self[tab+(page&1)]+256*self[tab+2+(page&1)]
            for y in range(13):
                for x in range(16):self.ram[base+y*16+x]=self.solid if self.grid[y+2][(page&3)*16+x]else self.empty
        if a>=0x8000:
            tag=self.tags[(a-0x8000)//8192]
            if not tag&128:return self.wram[tag&3][a&8191]
            return self.ROM_banks[tag&127][a&8191]
        return super().__getitem__(a)
    def __setitem__(self,a,v):
        if isinstance(a,slice):self.ram[a]=v;return
        v&=255
        if a>=0x8000:
            tag=self.tags[(a-0x8000)//8192];assert not tag&128,('ROM store',hex(a),tag)
            assert self.ram[0x5102]==2 and self.ram[0x5103]==1,('global WRAM protection blocks state/code writes',hex(a))
            if self.corrupt==(tag,a&8191)and v!=255:v^=1;self.corrupt=None
            self.wram[tag&3][a&8191]=v;self.cache_writes.append((tag,a&8191,v));return
        if 0x5114<=a<=0x5117:self.tags[a-0x5114]=v;self.banks[a-0x5114]=v&127
        if a==0x5113:assert v==0,'Global RAM0 mapping changed'
        if a==0x4016:self.pad_strobe=v&1;self.pad_index=[0,0]
        if a==0x5130:self.upper=v&3
        if 0x5120<=a<=0x512b:self.chr[a-0x5120]=self.upper*256+v;self.last_chr_BG=a>=0x5128
        if a==0x2000:self.ppu_ctrl=v
        if a==0x2001:self.ppu_mask=v
        if a==0x2005:self.scroll[self.ppu_latch]=v;self.ppu_latch^=1
        if a==0x2006:
            self.ppu_address=((v&63)<<8)|(self.ppu_address&255)if self.ppu_latch==0 else(self.ppu_address&0x7f00)|v
            self.ppu_latch^=1
        if a==0x2007:self.vram[self.ppu_address&0x3fff]=v;self.ppu_address=(self.ppu_address+(32 if self.ppu_ctrl&4 else 1))&0x7fff
        super().__setitem__(a,v)

def invoke(m,target,A=0,X=0,Y=0,P=0x30,hook=None,regs=None):
    incoming=m.tags[:];requested=target
    pc=m.lab[target];seg=m.bundle['segs'][m.bundle['syms'][target]['seg']]['name'].strip('"')
    if seg=='QW_CODE':
        m.set('ArenaGatePtr',pc);m.ram[m.lab['ArenaGatePtr']+1]=pc>>8;target='QwRouter'
    m.ram[m.lab['SafecallA_SMC']+1]=A
    m.ram[m.lab['FarcallJmpTarget_SMC']+1]=m.lab[target]&255;m.ram[m.lab['FarcallJmpTarget_SMC']+2]=m.lab[target]>>8
    m.ram[0x1fe]=0xfe;m.ram[0x1ff]=0x7f
    c=H.N.NesMPU(memory=m,pc=m.lab['FarCallCommon']);c.a=m.bank(target)|128;c.x=X;c.y=Y;c.p=P;c.sp=253
    low=253;trace=[]
    for step in range(800000):
        if c.pc==0x7fff:break
        m.pc=c.pc;low=min(low,c.sp)
        if hook:hook(c)
        if c.pc>=0x8000:
            tag=m.tags[(c.pc-0x8000)//8192]
            if not tag&128:m.executed_RAM.append((tag,c.pc))
        trace.append((tuple(m.tags),c.pc))
        assert m[c.pc]!=0,('actual cartridge BRK',hex(c.pc),m.tags,trace[-12:])
        c.step()
    else:raise AssertionError(('actual cartridge timeout',target,hex(c.pc),m.tags,trace[-15:]))
    assert c.sp==255,('actual stack leak',target,c.sp)
    assert m.tags[0]==incoming[0]and m.tags[1]==incoming[1]and m.tags[3]==incoming[3]
    assert m.get('CurrentBank')==m.tags[1]and m.get('CurrentBankC')==m.tags[2]
    if requested!='GameLoop':assert m.tags==incoming,('public mapper restore',requested,m.tags,incoming)
    if regs is not None:regs.update(A=c.a,X=c.x,Y=c.y,P=c.p)
    return dict(CPU=c.processorCycles,minimum_SP=low,trace=trace,registers=dict(A=c.a,X=c.x,Y=c.y,P=c.p))

def exact_cache(m):
    assert m.wram[1]==CODE,('code copy mismatch',[(i,a,b)for i,(a,b)in enumerate(zip(m.wram[1],CODE))if a!=b][:5])
    expected=bytearray(DATA);expected[0x1fe0:0x1ff0]=(O/'quick/cookie.bin').read_bytes()
    assert m.wram[2]==expected,('data copy mismatch',[(i,a,b)for i,(a,b)in enumerate(zip(m.wram[2],expected))if a!=b][:5])

def loader():
    rows=[]
    for mode,wide,ctrl in [(0,0,0xa0),(0x80,1,0xa0),(0x83,1,0xa0),(0x83,0,0x80)]:
        m=Bus();m.ram[0x6000:0x8000]=bytes((i*13+7)&255 for i in range(8192))
        m.set('CurrentBankC',215);m.set('HorizontalScroll',73);m.set('VerticalScroll',32);m.set('X5WideChrActive',wide);m.set('Mirror_PPUCTRL',ctrl);m.ppu_ctrl=ctrl;m.ram[m.lab['X5ChrMode']+11]=mode;m.ram[m.lab['CurrentCHRBank']+11]=91;m.sync_chr11()
        before=m.chr[:];protect=bytes(m.ram[0x5102:0x5104]);state=bytes(m.ram[0x6000:0x8000])
        result=invoke(m,'QwLoad');assert result['registers']['P']&1
        exact_cache(m);assert m.chr==before and m.upper==0 and m.scroll==[73,32]and m.ppu_ctrl==m.get('Mirror_PPUCTRL')
        assert bytes(m.ram[0x6000:0x8000])==state and bytes(m.ram[0x5102:0x5104])==protect
        assert m.ppu_reads==9*1025*2 and not m.PPU_active_reads and not m.executed_RAM
        rows.append(dict(mode=mode,wide=wide,original_PPUCTRL=ctrl,CPU=result['CPU'],minimum_SP=result['minimum_SP'],PPUDATA_reads=m.ppu_reads,all16384_code_data_bytes_exact=True,only_shared_cookie_differs=True))
    # Illegal active display cannot trigger a copy or execute any cache code.
    for flags in [(24,1,255),(0,0,255),(0,1,0)]:
        m=Bus();m.set('Mirror_PPUMASK',flags[0]);m.set('DisableScreenFlag',flags[1]);m.set('NmiDisable',flags[2]);result=invoke(m,'QwLoad')
        assert not result['registers']['P']&1 and not m.cache_writes and m.ppu_reads==0 and not m.executed_RAM
    # Exact copy-verify failure must keep validity clear and avoid RAM execution.
    m=Bus();m.corrupt=(1,0);result=invoke(m,'QwLoad');assert not result['registers']['P']&1 and m.wram[2][0x1fe0]==0 and not m.executed_RAM
    put('loader-controls.json',dict(passed=True,native=False,RAM_preload=False,ROM_sha256=sha(O/'candidate.nes'),rows=rows,active_display_and_invalid_boundary_negatives=3,deliberate_bad_copy_detected=True,global_RAM0_mapping_and_bytes_and_protection_unchanged=True,actual_buffered2007=True,physical_stream_pages=[884,893]))
    print('Real loader exact16KB/PPU/boundary/negative PASS',flush=True)

def preview():
    m=Bus();m.set('Player_X_Position',121);m.set('Player_Y_Position',160);m.set('CurrentOAMOffset',0)
    before=[bytes(x)for x in m.wram];result=invoke(m,'HuMenuPortrait')
    assert bytes(m.wram[1])==before[1]and bytes(m.wram[2])==before[2]and not m.executed_RAM and m.ppu_reads==0
    oam=bytes(m.ram[0x200:0x200+result['registers']['A']]);assert oam and len(oam)==28
    invoke(m,'HuColors');assert m.get('VRAM_Buffer1_Offset')==10
    put('cold-preview-controls.json',dict(passed=True,native=False,RAM_preload=False,ROM_sha256=sha(O/'candidate.nes'),no_RAM_execution_or_cache_changes=True,actual_ROM_OAM=list(oam),palette_packet=list(m.ram[m.lab['VRAM_Buffer1']:m.lab['VRAM_Buffer1']+11]),CPU=result['CPU']))
    print('Cold ROM-only portrait+colors PASS',flush=True)

def lifecycle():
    m=Bus();invoke(m,'NrGlobalInit');assert m.wram[2][0x1fe0]==0 and bytes(m.ram[m.lab['QhPersistent']:m.lab['QhPersistent']+8])==bytes(8)
    invoke(m,'HuFresh');exact_cache(m);assert m.get('QmField_06C0')==40
    reads=m.ppu_reads;rows=[]
    for player in [0,1]*10:
        m.set('_CurrentPlayer',player)
        for n in m.lab:
            if n.startswith(('QmField_','QuickManWork_')):m.set(n,0xa5)
        invoke(m,'HuReset');assert m.get('QmField_06C0')==40 and m.ppu_reads==reads
        rows.append(dict(player=player,HP=m.get('QmField_06C0'),no_reload=True))
    # Foreign retirement discards Quick validity; Arthur's already-owned tag
    # survives and is rejected by Quick before any RAM execution.
    m.set('SelectedCharacter',3);invoke(m,'QwRetire');assert m.wram[2][0x1fe0]==0
    m.wram[2][0x1fe0:0x1fe4]=bytes([0xa7,32,0,1]);invoke(m,'QwRetire');assert m.wram[2][0x1fe0]==0xa7
    m.set('SelectedCharacter',9);before=len(m.executed_RAM);invoke(m,'HuMovement');assert len(m.executed_RAM)==before
    invoke(m,'HuFresh');exact_cache(m);assert m.ppu_reads==reads*2
    m.wram[2][0x1fe4]^=1;invoke(m,'HuFresh');exact_cache(m);assert m.ppu_reads==reads*3
    # Real global boot invalidates warm bytes and both player records.
    invoke(m,'NrGlobalInit');assert m.wram[2][0x1fe0]==0 and bytes(m.ram[m.lab['QhPersistent']:m.lab['QhPersistent']+8])==bytes(8)
    put('lifecycle-controls.json',dict(passed=True,native=False,ROM_sha256=sha(O/'candidate.nes'),RAM_preload=False,alternating_resets=rows,cold_and_warm_actual_global_init=True,Quick_retirement_and_Arthur_owner_negative=True,reacquisition_reloads_both_banks=True))
    print('Cold/warm/player20/retire/Arthur-negative PASS',flush=True)

def call(m,name,**kw):
    if name=='QuickManInit'and m.wram[2][0x1fe0]!=0xa7:invoke(m,'HuFresh')
    if'registers'in kw:kw['regs']=kw.pop('registers')
    return invoke(m,name,**kw)['CPU']

def source():
    info=json.loads((C.ORACLE/'two-zp-projection/component/source-map.json').read_text());mapping={int(k,16):v for k,v in info['native_to_private_state'].items()};work=info['work_absolute']
    out=O/'bench';out.mkdir(exist_ok=True);(out/'component-fixture.bin').write_bytes(b'')
    text=inspect.getsource(C.b.differential).replace("z=labels['QuickManScratch']","z=0").replace("or component[labels['FixtureStatus']]",
        "or(component[labels['FixtureStatus']]&127)")
    for a,b in [('component[z+8]','component[3]'),('component[z+9]','component[4]'),('component[z+0xa]',f'component[{work["0A"]}]'),('component[z+0xb]',f'component[{work["0B"]}]'),('component[z]',f'component[{work["00"]}]')]:text=text.replace(a,b)
    def dispatch(m,pc,A=0,hook=None,X=0,registers=None):
        if not isinstance(m,Bus):return C.b.invoke(m,pc,A,hook,X,registers)
        n=next(n for n in ['QuickManInit','QuickManTick','QuickManGetFrame']if m.lab[n]==pc)
        return call(m,n,A=A,X=X,hook=hook,regs=registers)
    ns=dict(C.b.__dict__);ns.update(O=O,bytearray=Bus,invoke=dispatch);exec(compile(text,'actual-loader-source-oracle','exec'),ns)
    C.HostBus.publish_test_world=True
    try:proof=ns['differential'](info,mapping,Bus().lab,(C.ORACLE/'projection/bench/native-stage-fixture.bin').read_bytes())
    finally:C.HostBus.publish_test_world=False
    result=dict(passed=True,native=False,RAM_preload=False,ROM_sha256=sha(O/'candidate.nes'),ticks=sum(x['ticks']for x in proof['cases']),all535_source_fields_and_ordered_tile_queries_equal=True,semantic_assertions=proof['semantic_assertions'],maximum_tick_cycles=max(x['component_cycles_max']for x in proof['cases']),cases=proof['cases'])
    put('source-controls.json',result);print('Actual loader source1520 PASS',result['maximum_tick_cycles'],flush=True)

def render_public(which):
    function=C.render_controls if which=='render'else C.public_controls
    text=inspect.getsource(function).replace('def '+function.__name__+'():','def run():')
    ns=dict(C.__dict__);ns.update(O=O,HostBus=Bus,call=call);exec(compile(text,'actual-loader-'+which,'exec'),ns);ns['run']()
    n='render-controls-v3.json'if which=='render'else'public-controls-v3.json'
    d=json.loads((O/n).read_text());d.update(RAM_preload=False,actual_source_loader_and_router=True,native=False);put(which+'-controls.json',d)

def seeded():
    B=H.U.scoped_load(O/'candidate.nes');q=H.U.setup(B,9);m=Bus();m.ram[:0x8000]=bytes(q.m[:0x8000])
    m.set('CurrentBank',216);m.set('CurrentBankC',215);m.set('FmAlts',32);m.set('RlVariant',0);m.set('PlayerSize',0);m.set('PlayerStatus',0)
    m.set('NmiDisable',255);m.set('Mirror_PPUMASK',0);m.set('Mirror_PPUCTRL',0xa0);m.ppu_ctrl=0xa0;m.ppu_mask=0;m.sync_chr11()
    m.ram[0x5102]=2;m.ram[0x5103]=1;m.ram[0x5113]=0 # actual MapperInit fixture state
    invoke(m,'NrFreshGameInit');exact_cache(m);return m

def normal_nmi(m,keys):
    m.pad_bits=(keys,0);m.set('NmiDisable',0)
    c=H.N.NesMPU(memory=m,pc=0x7fff);c.sp=255;c.p=0x30;c.nmi()
    for _ in range(100000):
        if c.pc==0x7fff and c.sp==255:break
        assert m[c.pc]!=0,('NMI BRK',hex(c.pc),m.tags);c.step()
    else:raise AssertionError('normal NMI timeout')
    assert m.get('SavedJoypad1Bits')==keys and m.get('SavedJoypad2Bits')==0
    return c.processorCycles

def full_main():
    rows=[]
    for mode in [0,1]:
        m=seeded();m.set('CrossoverBehaviorVersion',mode);m.cache_writes.clear();local=[]
        for age in range(80):
            keys=1|(128 if 5<=age<18 else 0)|(64 if 10<=age<40 else 0)
            nmi=normal_nmi(m,keys);result=invoke(m,'GameLoop')
            count=sum(1 for tags,pc in result['trace']if tags[1]==1 and pc==m.lab['QuickManTick'])
            assert count==1,('native source tick',age,count)
            assert m.get('GameEngineSubroutine')==8
            assert(m.get('QmField_0460')-m.get('Player_X_Position'))&255==8
            assert(m.get('QmField_04A0')-m.get('Player_Y_Position'))&255==20
            assert not m.cache_writes;exact_cache(m)
            row=dict(mode=mode,age=age,keys=keys,X=m.get('Player_X_Position'),page=m.get('Player_PageLoc'),Y=m.get('Player_Y_Position'),screen_left=m.get('ScreenLeft_X_Pos'),source_VY=[m.get('QmField_0640'),m.get('QmField_0660')],source_held=m.get('QmField_0023'),source_edges=m.get('QmField_0027'),active_boomerangs=[i for i in range(2,5)if m.get('QmField_'+format(0x420+i,'04X'))&128],foreground_CPU=result['CPU'],NMI_CPU=nmi,minimum_SP=result['minimum_SP'])
            rows.append(row);local.append(row)
        assert local[5]['source_VY']==[4,223]
        assert min(r['Y']for r in local)<140 and local[-1]['Y']==176
        assert any(r['active_boomerangs']==[2,3,4]for r in local)
        assert any(r['screen_left']for r in local)
    put('full-main-controls.json',dict(passed=True,native=False,RAM_preload=False,ROM_sha256=sha(O/'candidate.nes'),actual_serial_controller_NMI=True,updates=len(rows),maximum_foreground_CPU=max(r['foreground_CPU']for r in rows),maximum_NMI_CPU=max(r['NMI_CPU']for r in rows),no_active_cache_writes=True,scope='CPU Main called through genuine FarCallCommon outer entry; finite scene only, no NTSC cadence claim.',rows=rows))
    print('Actual loader fullMain160 active PASS',max(r['foreground_CPU']for r in rows),flush=True)

def flags():
    template=Bus();invoke(template,'HuFresh');snapshot=[bytes(x)for x in template.wram]
    oldcpu=C.MPU;C.MPU=H.N.NesMPU;rows=[]
    try:
        for p in [v for v in range(256)if v&0x30==0x30]:
            for keys in [0,1,2,64,128,129,131,160]:
                a=C.HostBus(path=P/'candidate.nes');C.call(a,'QuickManInit');old={};C.call(a,'QuickManTick',A=keys,P=p,registers=old)
                m=Bus();m.wram=[bytearray(x)for x in snapshot];invoke(m,'QuickManInit');new={};invoke(m,'QuickManTick',A=keys,P=p,regs=new)
                assert old==new,(p,keys,old,new)
                assert all(a.get(n)==m.get(n)for n in a.lab if n.startswith('QmField_')),(p,keys)
                rows.append([p,keys,*new.values()])
    finally:C.MPU=oldcpu
    put('flags-controls.json',dict(passed=True,native=False,ROM_sha256=sha(O/'candidate.nes'),cases=len(rows),AXYP_and_all535_fields_equal=True,fixture='Each case replays a CPU snapshot produced by genuine2007 loader. No external payload RAM preload or native claim.',rows=rows));print('Actual router/source flags512 PASS',flush=True)

def interrupt_at(m,c,kind,require_blank=False):
    old=K.KERNEL;K.KERNEL=bytes(m.wram[1]);cache2=bytes(m.wram[2]);ppu=(m.ppu_reads,m.ppu_address,m.buffer,m.ppu_latch,m.chr[:],m.upper,m.ppu_ctrl,m.ppu_mask,m.scroll[:])
    try:result=K.context(m,c,kind)
    finally:K.KERNEL=old
    assert bytes(m.wram[2])==cache2,'ISR changed selected-owner bank2 cache'
    if require_blank:assert(m.ppu_reads,m.ppu_address,m.buffer,m.ppu_latch,m.chr[:],m.upper,m.ppu_ctrl,m.ppu_mask,m.scroll[:])==ppu,('lag ISR altered loader PPU transaction',hex(c.pc))
    return result

def interrupts():
    # Execute an actual loader while real lag NMI/IRQ requests occur at the
    # first instance of each mapper/PPU/cookie boundary, each source page.
    m=Bus();cuts=[];seen=set();count=0
    entries={m.lab[n]for n in ['QwLoad','QwLoaderCore','QwMapPage','QwCopy256','QwVerify256','QwPublishCookie','QwLoadRestore','QwDirect11','QwWrite11','QwLoadUnavailable']}
    def observe(c):
        nonlocal count
        pc=c.pc;op=bytes(m[pc:pc+3]);key=(pc,m.get('QuickManWork_00'),m.get('QuickManWork_01'))
        if(pc in entries or op in [b'\x8d\x15\x51',b'\x8d\x16\x51'])and key not in seen:
            seen.add(key);cuts.append((count,pc))
        count+=1
    invoke(m,'QwLoad',hook=observe);exact_cache(m);rows=[]
    for step,pc in cuts:
        m=Bus();injected=[];at=0
        def inject(c):
            nonlocal at
            if at==step:
                assert c.pc==pc
                # IRQ cannot enter the SEI-owned copy. Actual IRQ remains
                # covered before entry/after restoration and in active hooks.
                masked=bool(c.p&c.INTERRUPT)
                if masked:
                    before=(c.pc,c.sp,c.p);c.irq();assert(c.pc,c.sp,c.p)==before
                proof=interrupt_at(m,c,'NMI',require_blank=masked and m.get('ReloadCHRBank')==0)
                injected.append(dict(step=step,PC=pc,IRQ_masked=masked,**proof))
            at+=1
        invoke(m,'QwLoad',hook=inject);exact_cache(m);assert len(injected)==1;rows.extend(injected)
    put('loader-isr-controls.json',dict(passed=True,native=False,ROM_sha256=sha(O/'candidate.nes'),real_lag_NMI_interruptions=len(rows),all_mapper_PPU_page_cookie_entry_boundaries=True,IRQ_masking_retained=True,no_ISR_PPU_or_cache_corruption=True,rows=rows));print('Actual loader ISR',len(rows),'PASS',flush=True)
    # Full public motion/render routes, ordinary and lag NMI plus actual IRQ.
    rows=[]
    template=seeded()
    def ready_snapshot():
        result=Bus();result.ram[:]=template.ram[:];result.wram=[bytearray(x)for x in template.wram]
        result.tags=template.tags[:];result.banks=template.banks[:];result.A,result.C=template.A,template.C
        result.chr=template.chr[:];result.upper=template.upper;result.ppu_ctrl=template.ppu_ctrl;result.ppu_mask=template.ppu_mask
        return result
    for target in ['HuMovement','HuDraw','HuWeapons']:
        m=ready_snapshot();count=0;cuts=[];seen=set()
        def observe(c):
            nonlocal count
            pc=c.pc;op=bytes(m[pc:pc+3]);tag=m.tags[(pc-0x8000)//8192]if pc>=0x8000 else -1
            if((tag,pc)not in seen)and(0x15a<=pc<0x17b or op in [b'\x8d\x15\x51',b'\x8d\x16\x51']or tag==1 and count%96==0):
                seen.add((tag,pc));cuts.append((count,pc))
            count+=1
        invoke(m,target,A=131,hook=observe)
        for step,pc in cuts:
            for lag in [0,255]:
                for kind in ['NMI','IRQ']:
                    m=ready_snapshot();m.set('NmiDisable',lag);at=0;result=[]
                    def inject(c):
                        nonlocal at
                        if at==step:
                            assert c.pc==pc
                            if kind=='IRQ'and c.p&c.INTERRUPT:return
                            result.append(interrupt_at(m,c,kind))
                        at+=1
                    invoke(m,target,A=131,hook=inject);exact_cache(m)
                    if result:rows.append(dict(target=target,step=step,PC=pc,lag=lag,**result[0]))
    put('active-isr-controls.json',dict(passed=True,native=False,ROM_sha256=sha(O/'candidate.nes'),real_vector_interruptions=len(rows),raw_RAM_mapper_SMC_AXYP_stack_borrowed_pairs_restored=True,no_cache_corruption=True,fixture='Each active seam replays a CPU state snapshot produced by actual verified2007 loader; loader itself separately interrupted at40 real boundaries.',rows=rows));print('Actual active route ISR',len(rows),'PASS',flush=True)

def foreign():
    # Compare against the exact densePN composition of the frozen Quick host,
    # using the same real four-bank RAM-capable bus on both sides.
    import link_pit_rygar_sophia_audit_cpu as L
    oldmemory=L.Memory;oldload=H.U.scoped_load;old=oldload(O/'dense-parent.nes')
    def bound(path):return old if Path(path)==R/'build/pit-retold-host-v3/candidate.nes'else oldload(path)
    class ForeignBus(Bus):
        def __init__(self,bundle):
            super().__init__(bundle);self.set('FmAlts',0) # genuine native baseline
    L.Memory=ForeignBus;H.U.scoped_load=bound
    try:result=H.U.foreign(oldload(O/'candidate.nes'))
    finally:L.Memory=oldmemory;H.U.scoped_load=oldload
    result.update(passed=True,native=False,ROM_sha256=sha(O/'candidate.nes'),parent_dense_sha256=sha(O/'dense-parent.nes'),actual_raw_RAM_capable_bus=True)
    put('foreign-controls.json',result);print('Actual foreign Main',result['cases'],'PASS',flush=True)

if __name__=='__main__':
    if '--loader'in sys.argv:loader()
    if '--preview'in sys.argv:preview()
    if '--life'in sys.argv:lifecycle()
    if '--source'in sys.argv:source()
    if '--render'in sys.argv:render_public('render')
    if '--public'in sys.argv:render_public('public')
    if '--main'in sys.argv:full_main()
    if '--flags'in sys.argv:flags()
    if '--isr'in sys.argv:interrupts()
    if '--foreign'in sys.argv:foreign()
