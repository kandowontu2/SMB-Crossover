"""Prepare bounded controller-only Quick loader smoke; never starts Mesen."""
from pathlib import Path
import hashlib,json,sys
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(Path(__file__).parent))
from link_pit_rygar_sophia_audit_cpu import scoped_load
from check_tmnt_render_oa import address
O=R/'build/quickman-wram-host-v4'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
    b=scoped_load(O/'candidate.nes');end=address(b,'GameLoop::PauseSkip')+5
    assert b['raw'][16+126*8192+(end&8191)]==0x60
    text=r'''-- Original controllers only. No emu.write, save state, or debugger-input edits.
local wall,age=0,0
local pad={}
local phase='title'
local lastAction=-99
local previewFrame,confirmFrame,loadedFrame,gameFrame=nil,nil,nil,nil
local loaderCalls,loaderReads,cacheWrites=0,0,0
local loaded=false
local loader=false
local hardwareMask=0
local tickCount,mainCount,nmis,irqs=0,0,0,0
local jump,fan,scrolled=false,false,false
local minY,startX=255,nil
local mainStart=nil
local maximumMainElapsed=0
local shots=0
local trace=assert(io.open(OUTPUT..'frames.csv','w'))
trace:write('frame,phase,age,mode,task,engine,index,alt,x,page,y,sourceState,HP,ticks,mains,nmi,irq,NmiSkipped\n')
local function r(n) return emu.read(assert(L[n],n),emu.memType.nesDebug) end
local function cpu() return emu.getState()['cpu.cycleCount'] end
local function screenshot(tag)
 shots=shots+1;assert(shots<=6,'Bounded screenshot count')
 local f=assert(io.open(OUTPUT..tag..'.png','wb'));f:write(emu.takeScreenshot());f:close()
end
local function readfile(name)
 local f=assert(io.open(TEST_DIR..name,'rb'));local s=f:read('*a');f:close();return s
end
local code,data,cookie=readfile('code.bin'),readfile('data.bin'),readfile('quick/cookie.bin')
assert(#code==8192 and #data==8192 and #cookie==16,'Bound exact payload sizes')
local function verify()
 assert(r('CurrentBank')==1 and r('CurrentBankC')==2,'Actual rawRAM1/2 code entry')
 for i=0,8191 do
  assert(emu.read(0xa000+i,emu.memType.nesDebug)==code:byte(i+1),'Actual loaded code byte '..i)
  local expected=data:byte(i+1)
  if i>=0x1fe0 and i<0x1ff0 then expected=cookie:byte(i-0x1fe0+1) end
  assert(emu.read(0xc000+i,emu.memType.nesDebug)==expected,'Actual loaded data byte '..i)
 end
end
emu.addMemoryCallback(function(_,v) hardwareMask=v end,emu.callbackType.write,0x2001)
emu.addMemoryCallback(function()
 if r('CurrentBankC')~=(B.QwLoaderCore|0x80)then return end
 assert(previewFrame~=nil and confirmFrame~=nil,'Gameplay loading follows real cold preview and confirm')
 assert(hardwareMask&0x18==0 and r('Mirror_PPUMASK')&0x18==0 and r('DisableScreenFlag')~=0 and r('NmiDisable')>=128,'Actual forced blank/lag boundary')
 loader=true;loaderCalls=loaderCalls+1
end,emu.callbackType.exec,L.QwLoaderCore)
emu.addMemoryCallback(function() if loader then loaderReads=loaderReads+1 end end,emu.callbackType.read,0x2007)
emu.addMemoryCallback(function(a)
 local raw=a<0xc000 and r('CurrentBank')or r('CurrentBankC')
 if raw==1 or raw==2 then
  cacheWrites=cacheWrites+1
  assert(loader,'Selected cache has no active-play writes')
 end
end,emu.callbackType.write,0xa000,0xdfff)
emu.addMemoryCallback(function()
 if r('CurrentBank')~=1 or r('CurrentBankC')~=2 then return end
 if not loaded then
  verify();loaded=true;loadedFrame=wall;loader=false
  assert(loaderCalls==1 and loaderReads==18450,'Genuine buffered9-page copy and full verify')
 end
end,emu.callbackType.exec,L.QwIndirect)
emu.addMemoryCallback(function()
 if r('CurrentBank')==1 then tickCount=tickCount+1 end
end,emu.callbackType.exec,L.QuickManTick)
emu.addMemoryCallback(function() mainCount=mainCount+1;mainStart=cpu() end,emu.callbackType.exec,L.GameLoop)
emu.addMemoryCallback(function()
 if mainStart then maximumMainElapsed=math.max(maximumMainElapsed,cpu()-mainStart+6);mainStart=nil end
end,emu.callbackType.exec,@MAIN_END@)
emu.addMemoryCallback(function() nmis=nmis+1 end,emu.callbackType.exec,L.NonMaskableInterrupt)
emu.addMemoryCallback(function() irqs=irqs+1 end,emu.callbackType.exec,L.IrqScrollSplit)
emu.addEventCallback(function() emu.setInput(pad,0) end,emu.eventType.inputPolled)
local function action(button)
 if wall-lastAction<8 then return end
 pad[button]=true;lastAction=wall
end
local function finish()
 assert(loaded and previewFrame and gameFrame,'Real preview/load/gameplay boundaries all reached')
 assert(tickCount>20 and jump and fan and scrolled,'Original movement, A-edge jump, fan and scroll observed')
 screenshot('gameplay-final')
 trace:close()
 local f=assert(io.open(OUTPUT..'result.json','w'))
 f:write(string.format('{"passed":true,"native":true,"debug_RAM_writes":false,"frames":%d,"preview_frame":%d,"loaded_frame":%d,"game_frame":%d,"code8192_data8192_exact":true,"loader_calls":%d,"loader_reads":%d,"cache_writes_during_loader":%d,"source_ticks":%d,"main_updates":%d,"NMI":%d,"IRQ":%d,"jump":%s,"fan":%s,"scroll":%s,"minimumY":%d,"max_Main_elapsed_including_ISR":%d,"cadence_qualification":false}\n',wall,previewFrame,loadedFrame,gameFrame,loaderCalls,loaderReads,cacheWrites,tickCount,mainCount,nmis,irqs,tostring(jump),tostring(fan),tostring(scrolled),minY,maximumMainElapsed));f:close()
 emu.stop(0)
end
emu.addEventCallback(function()
 wall=wall+1;pad={}
 local mode,state,index=r('OperMode'),r('CrossoverMenuState'),r('CrossoverMenuIndex')
 if phase=='title'then
  if mode==0 and state==2 then phase='select' else if wall>=50 then action('start')end end
 elseif phase=='select'then
  assert(not loaded,'Menu before any gameplay RAM execution')
  if state==2 then
   local row,col=math.floor(index/8),index%8
   if row<1 then action('down')elseif row>1 then action('up')elseif col<1 then action('right')elseif col>1 then action('left')
   elseif r('FmAlts')&32==0 then action('select')
   elseif wall-lastAction>=16 then
    assert(r('SelectedCharacter')==9,'Actual Bass Select-cycle reaches Quick')
    screenshot('quick-cold-menu');previewFrame=wall;phase='confirm'
   end
  end
 elseif phase=='confirm'then
  if wall-previewFrame>=12 then pad.a=true;confirmFrame=wall;phase='loading'end
 elseif phase=='loading'then
  if state==2 and wall-confirmFrame<8 then pad.a=true end
  if mode==1 and r('OperMode_Task')==3 and r('GameEngineSubroutine')==8 and loaded then
   gameFrame=wall;startX=r('Player_X_Position');phase='game';screenshot('gameplay-start')
  end
 elseif phase=='game'then
  age=age+1;pad.right=true
  pad.a=age>=12 and age<26
  pad.b=age>=30 and age<95
  minY=math.min(minY,r('Player_Y_Position'))
  jump=jump or r('Player_Y_Position')<145
  fan=fan or(r('QmField_0422')>=128 and r('QmField_0423')>=128 and r('QmField_0424')>=128)
  scrolled=scrolled or r('ScreenLeft_X_Pos')~=0 or r('ScreenLeft_PageLoc')~=0
  if age==40 then screenshot('jump-and-fan')end
  if age>=220 then finish();return end
 end
 trace:write(table.concat({wall,phase,age,mode,r('OperMode_Task'),r('GameEngineSubroutine'),index,r('FmAlts'),r('Player_X_Position'),r('Player_PageLoc'),r('Player_Y_Position'),r('QmField_002C'),r('QmField_06C0'),tickCount,mainCount,nmis,irqs,r('NmiSkipped')},',')..'\n')
 if wall>=1000 then screenshot('timeout');assert(false,'Bounded native first-look timeout phase='..phase)end
end,emu.eventType.endFrame)
'''.replace('@MAIN_END@',str(end))
    assert'emu.write('not in text
    (O/'native-first-look.lua').write_text(text,newline='\n')
    d=dict(prepared=True,native_run=False,ROM_sha256=sha(O/'candidate.nes'),script_sha256=sha(O/'native-first-look.lua'),strict_controllers=True,maximum_frames=1000,maximum_screenshots=6,source_main_RTS=end,bindings={str(p):sha(p)for p in [O/'candidate.nes',O/'candidate.dbg',O/'candidate.lbl',O/'code.bin',O/'data.bin',O/'quick/cookie.bin',Path(__file__)]},requirements='Only tools/run_mesen.py after root native lease. Cold power-on only; no menu-bootstrap or save state. Finite first-look does not qualify cadence/campaign/audio.')
    (O/'native-first-look-prepared.json').write_text(json.dumps(d,indent=2)+'\n')
    print(json.dumps(dict(prepared=True,ROM_sha256=d['ROM_sha256'],script=str(O/'native-first-look.lua'))))
if __name__=='__main__':main()
