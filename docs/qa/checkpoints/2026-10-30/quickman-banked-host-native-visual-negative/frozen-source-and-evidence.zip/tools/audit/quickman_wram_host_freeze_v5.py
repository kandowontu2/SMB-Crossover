"""Freeze actual private source-linked Quick loader/CPU candidate, never install."""
from pathlib import Path
import hashlib,json,re,shutil,sys,zipfile
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(Path(__file__).parent))
from check_tmnt_render_oa import load,address,location
W=R/'build/quickman-wram-host-v4';P=R/'build/quickman-host-cpu-v4';F=R/'build/quickman-wram-whole-cpu-v3'
O=R/'build/quickman-wram-host-cpu-v5'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,d):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(d,indent=2)+'\n',newline='\n')
def verify(p):
    d=json.loads(p.read_text())
    for n,h in d['bindings'].items():assert sha(n)==h,('Earlier frozen binding changed',n)
def main():
    assert not O.exists();verify(P/'handoff.json');verify(F/'handoff.json')
    b=load(W/'candidate.nes');d=load(W/'dense-parent.nes');raw=b['raw'];old=d['raw'];rom=sha(W/'candidate.nes')
    assert rom=='eed0ac40e6cffbf8877f504dfde2cc5c04c85f10038192a7d16d5c3bb24dfeaa'
    checks=['loader-controls.json','cold-preview-controls.json','lifecycle-controls.json','source-controls.json','render-controls.json','public-controls.json','full-main-controls.json','flags-controls.json','loader-isr-controls.json','active-isr-controls.json','foreign-controls.json']
    for n in checks:
        x=json.loads((W/n).read_text());assert x['ROM_sha256']==rom,n;assert x.get('passed',True),n
    # Both earlier frozen packets remain wholly intact, including indirect
    # predecessor source paths touched by the retained failed replay negative.
    lease=json.loads((W/'lease-copy.json').read_text())['Quick_Man']['PRG'];allowed=set()
    for span in lease:
        for off in range(span['start'],span['end']):
            if span['bank']==93 and 0xfa7<=off<0xfe7:continue
            allowed.add(16+span['bank']*8192+off)
    placements=[];owned=set();ram=[]
    for s in b['segs'].values():
        name=s['name'].strip('"')
        if name.startswith('QP_')or name in ['QW_ROUTER','QW_LOADER']:
            at=int(s['ooffs'],0);size=int(s['size'],0);assert set(range(at,at+size))<=allowed,name
            owned.update(range(at,at+size));placements.append(dict(segment=name,bank=(at-16)//8192,offset=(at-16)%8192,start=int(s['start'],0),bytes=size,sha256=hashlib.sha256(raw[at:at+size]).hexdigest()))
        if name.startswith('QM_')and'ooffs'not in s:
            start=int(s['start'],0);end=start+int(s['size'],0)
            assert not any(start<=x<end for x in [0x5cc3,0x5dcc,0x5dcd]);ram.append(dict(segment=name,start=start,end=end))
    assert sum(v['end']-v['start']for v in ram)==557
    assert all(address(b,n)==address(d,n)for n in b['syms']if n.startswith('QmField_'))
    src=(W/'quick/whole.s').read_text();native=re.findall(r'(?m)^(CX_[A-F0-9_]+):',(P/'source/quick/core.s').read_text())
    for n in native:assert n in b['syms']and 0xa000<=address(b,n)<0xb95b,n
    assert len(re.findall(r'(?m)^QmField_[A-F0-9]{4}:',src))==535
    assert all(raw[x:x+64]==old[x:x+64]for x in [16+93*8192+0xfa7])
    # Exact changed byte inventory outside retained Quick leases; fixed code
    # owns only the linked post-terrain operand changes and regenerated clone.
    segs=[(int(s['ooffs'],0),int(s['ooffs'],0)+int(s['size'],0),s['name'].strip('"'))for s in b['segs'].values()if'ooffs'in s and s['name']not in ['"QW_CODE"','"QW_DATA"']]
    changed=[];counts={}
    for at,(before,after)in enumerate(zip(old,raw)):
        if before==after or at in allowed or not 16<=at<16+128*8192:continue
        name=next((n for a,z,n in segs if a<=at<z),'CV3_FIXED_MIRROR')
        assert name in ['CHARACTER_HOST_UNION','NEW_ROSTER_GATE','RENDER','FULL_ROSTER_MENU','PROTO_MENU','PLAYER','FIXED','CV3_FIXED_MIRROR'],(at,name)
        counts[name]=counts.get(name,0)+1;changed.append(dict(bank=(at-16)//8192,offset=(at-16)%8192,before=before,after=after,segment=name))
    fixed=[r for r in changed if r['bank']in [125,127]];assert len(fixed)==2
    for bank in [125,127]:
        rows=[r for r in fixed if r['bank']==bank];assert len(rows)==1
        assert [r['offset']for r in rows]==[0x5d0]
        assert[raw[16+bank*8192+off-1]for off in [0x5d0,0x5d5]]==[0xa9,0xa9]
        assert[raw[16+bank*8192+off]for off in [0x5d0,0x5d5]]==[address(b,'HuAfterTerrainGate')&255,address(b,'HuAfterTerrainGate')>>8]
    for name in ['SMCCODE']:
        sn=next(s for s in b['segs'].values()if s['name']=='"'+name+'"');so=next(s for s in d['segs'].values()if s['name']=='"'+name+'"')
        at,oa,n=int(sn['ooffs'],0),int(so['ooffs'],0),int(sn['size'],0);assert n==33 and raw[at:at+n]==old[oa:oa+n]
    cs=16+128*8192;assert raw[10]==9 and old[10]==7
    assert[at for at,(a,z)in enumerate(zip(raw[:16],old[:16]))if a!=z]==[10]
    assert raw[cs:cs+884*1024]==old[cs:cs+884*1024]and raw[cs+893*1024:]==old[cs+893*1024:]
    code=(W/'code.bin').read_bytes();data=(W/'data.bin').read_bytes();cookie=(W/'quick/cookie.bin').read_bytes()
    assert cookie[:4]==bytes([0xa7,9,32,4])and cookie[4:]==hashlib.sha256(code[:6491]+data[:1921]).digest()[:12]
    assert raw[cs+884*1024:cs+893*1024]==code[:7168]+data[:2048]
    assert raw[cs+868*1024:cs+884*1024]==bytes(16384)
    assert code[6491:]==b'\xff'*(8192-6491)and data[1921:]==b'\xff'*(8192-1921)
    O.mkdir()
    names=['candidate.nes','candidate.dbg','candidate.lbl','candidate.map','candidate.cv3-mirror.json','code.bin','data.bin','wram.cfg','commands.json','exact-parent.json','dense-precondition.json','prepared.json','native-first-look.lua','native-first-look-prepared.json',*checks]
    for n in names:shutil.copy2(W/n,O/n)
    (O/'quick').mkdir();shutil.copy2(W/'quick/cookie.bin',O/'quick/cookie.bin')
    # Preserve negative receipts as evidence. No negative is promoted to PASS.
    for p in W.glob('*negative*.json'):
        dest=O/'negatives'/p.name;dest.parent.mkdir(exist_ok=True);shutil.copy2(p,dest)
    direct=[p for p in W.rglob('*')if p.is_file()and p.suffix in ['.s','.inc','.cfg','.chr','.bin']and not p.is_relative_to(W/'positive-69273552-before-boundary-tightening')]
    # Include each actual selected source/asset dependency; existing generated
    # music assets under the frozen private copy are part of the full closure.
    for p in (W/'frozen-inputs').rglob('*'):
        if p.is_file()and p not in direct and p.suffix not in ['.o','.nes','.dbg','.lbl','.map','.py','.json']:direct.append(p)
    tools=[R/'tools/audit'/n for n in ['quickman_wram_host_v4.py','quickman_wram_loader_v4.s','quickman_wram_host_controls_v4.py','quickman_wram_native_prepare_v4.py','quickman_wram_host_freeze_v5.py']]
    with zipfile.ZipFile(O/'source-closure.zip','w',zipfile.ZIP_DEFLATED)as z:
        for p in sorted(set(direct+tools+[R/'tools/prepare_cv3_dmc_mirror.py'])):z.write(p,p.relative_to(R).as_posix())
    with zipfile.ZipFile(O/'source-closure.zip')as z:assert z.testzip()is None;members=len(z.namelist())
    hooks=json.loads((P/'public-hook-inventory.json').read_text())
    hooks.update(status='ACTUAL_PRIVATE_SOURCE_LINKED_WRAM_CPU_QUALIFIED_NATIVE_OPEN',actual_ROM_sha256=rom,actual_loader='Native InitScreen forced-blank call-site → retainedA70 QwSceneInit/QwConstruct → C82QwLoaderCore, genuine bufferedPPUDATA copies and verify before owner cookie valid-last.',actual_router='ExistingA79 HuCommon rows → retainedA70 QwRouter → actualFarCallCommon rawRAM1 QhDispatch/C2. ROM menu portrait/colors run before construction.',actual_boot='NrGlobalInit followsIcGlobalInit withQwBoot; Sunny outputABI preserved, warmC2cookie and two4B player records invalidated.',actual_owner_retirement='HuResolve callsQwRetire after native resolution; only a retiredQuick09-owned cookie is cleared, an alreadyArthur20-owned cache is preserved.',readiness=False,original_CX_audio='OPEN: source Sound currently generic hostSquare1effect20; no original theme/driver integration or native cadence claim.',native_gameplay=False)
    put(O/'public-hook-inventory.json',hooks)
    put(O/'linked-source-proof.json',dict(passed=True,ROM_sha256=rom,retained_Quick_ROM_used=sum(p['bytes']for p in placements),retained_Quick_lease=10060,unreleased_headroom=10060-sum(p['bytes']for p in placements),placements=placements,loaded_code_bytes=6491,loaded_data_bytes=1921,code_data_RAM_each8192=True,stream_pages=[884,893],preserved_Arthur_pages=[868,884],preserved_Quick_art=[251,256],all535_source_aliases_unchanged=True,all35_native_routines_and_labels_retained=len(native),transient_RAM=ram,transient_bytes=557,persistent=[0x5f88,0x5f90],new_ZP=0,shared33SMC_exact=True,private_header_only_byte10_7_to9=True,nonlease_parent_changed_bytes=changed,nonlease_parent_changed_segment_counts=counts,fixed_operand_edits=fixed,global_protection='No new5102/5103/5113 writes; nativeRAM0 remains writable.',cookie=dict(C2=[0xdfe0,0xdff0],rawA2_alias=[0xbfe0,0xbff0],bytes=list(cookie),fingerprint='first12SHA256 of6491code+1921data',valid_last=True,hot_header_checked=True,constructor_full16_checked=True),PPU_model_primary_source='https://raw.githubusercontent.com/SourMesen/Mesen2/master/Core/NES/Mappers/Nintendo/MMC5.h',PPU_model_scope='Mesen implementation selectsBGset after512B outside rendering with8x16control. Real installed-native copy/PPU cadence remains unqualified.'))
    report='''This is a frozen private source-linked32KB-WRAM Quick Man cartridge CPU candidate. It is not admission, shared installation or native qualification.

The exact frozen774a78 parent reproduced first. The four qualified denseParodius source overrides and split memory config then produced exact832..<868 pixels and verified868..<1024 zero, retainingQuick251..<256. Only afterward did the9-page884..<893 code/data stream enter the source linker. Arthur868..<884 remains zero/reserved. All otherCHR is exact to the dense parent.

Actual source-linked retained ROM provides the realA79 selector, A70raw-RAM importer, C82PPUDATA loader, cold ROM portrait/colors and original InitScreen/NrGlobalInit/HuResolve hooks. No new resident range or sharedSMC growth. Fixed127 has only the two linkedHuAfterTerrainGate immediate-operand edits; actualprepare_cv3_dmc_mirror regenerates125. All changed nonlease PRG bytes are enumerated inlinked-source-proof.json.

Quick code6491B runs inrawRAM1 A000..<B95B; data1921B inrawRAM2 C000..<C781. The loader invalidatesC2DFE0 through correctA2BFE0 before any overwrite, fills both8KBFF, performs18450 genuine buffered2007 reads (copy and readback of9216 stream bytes), publishes the16B owner/version/payload-fingerprint cookie valid-last, restores nativeCHR11/upper0/control/scroll and rawA/C state. It forces8x16+increment1 only duringcopy, retains actuallagNMI/audio withReload0 and DisableScreenFlag set, masksIRQ until restoration. Constructor checks the full16B cookie; hot public dispatch checks its4B owner/version header. No5102/5103/5113 changes; RAM0/protection remain native and writable.

CPU evidence bound to this exact hash: all16384 loadedcode/data bytes exact (16cookiebytes replaceFF), four legacy/direct/stale-wide/8x8 control cases; active-display and boundary rejection; deliberatecopycorruption negative; actualcoldROMportrait/colors with no RAM execution; cold/warm globalconstructor,20 alternating-player lifecycle resets, full poisoned source-field reset/persistentHP/progression/item/injury/death/palette controls;1520 original-source updates with all535fields and ordered terrain queries equal;512 registers/flags cases;300 authentic OAM cases;160 activecompleteMain updates through actualserial controllerNMI, jump/land/fan/scroll and centerY+20 resync;40 real loaderlagNMI interruptions and292 active ordinary/lag NMI/IRQ interruptions;282 genuine foreigncompleteMain cases exact against the dense frozenparent. ActiveISR/flags cases replay CPU snapshots genuinely produced by the separately qualified loader; no external payloadRAM preload supports activation tests.

Maximum sourceTick13251CPU; maximumMain35371CPU through a genuineFarCallCommon testouterentry. Native NTSCcadence remains OPEN. The bounded native-first-look.lua is prepared only: cold controllers navigate Bass Select-cycle toQuick, capture authenticcoloredmenu beforeloading, then confirm and observe220activevideoframes; it watches actual forcedblank/18450reads, verifiesall16KB at realrawRAM1/C2entry, rejectsactivecachewrites and records Main/source/NMI/IRQ cadence. Max1000frames/6screenshots, noemu.write/save-state/bootstrap edits. Run only withroot nativequeue grant via tools/run_mesen.py.

Limits: no native boot/menu/PPU/OAM/RGB/controller/campaign/Hard qualification yet; no unifiedArthur+Quick cartridge claim from separate-source array tests. OriginalCX sound/theme driver, source enemy-contact cadence/dictionaries and broader water/platform/automatic scene ownership remain OPEN. Sound currently queues generic hosteffect20; native100-unit piercing damage remains the explicitSMB adaptation. No60Hz or full ability-admission claim. No canonical source, Downloads, shared readiness, physical leases, user Mesen window or emulator process changed.

Retained negatives include the escapedJSON replay path error (owned working predecessor outputs were restored; both earlier frozen packets71+74bindings all remained exact), the realAFE0/BFE0 cookie alias error caught before native, and a foreign-fixture inheritedFmAlts32 mistake that accidentally selectedQuick rather thanBass. No failed fixture is promoted. Reproduction uses this private source closure, recorded exactcommands and source-linked stream second pass; build outputs/generated paths are asserted inside the new preparation tree. Earlier immutable packets bind source authentication and original physics/pose/palette provenance.
'''
    (O/'README.txt').write_text(report,newline='\n')
    refs=[P/'handoff.json',F/'handoff.json',R/'docs/qa/checkpoints/2026-10-30/mmc5-overlay-private-allocation/root-review-and-reservations.json',R/'docs/qa/checkpoints/2026-10-30/arthur-quick-private-allocation/root-review-and-reservations.json',R/'docs/qa/checkpoints/2026-10-30/union-bbox-reallocation/root-review-and-reservations.json',W/'parent-774a78.nes',W/'dense-parent.nes',W/'dense-parent.dbg',W/'dense-parent.lbl',R/'build/quickman-component-v2/palette/palette-owner.json']
    files=[p for p in O.rglob('*')if p.is_file()]
    put(O/'handoff.json',dict(status='FROZEN_ACTUAL_PRIVATE_WRAM_HOST_CPU_CANDIDATE_NATIVE_OPEN',ROM_sha256=rom,native=False,shared_install=False,header_bytes=32768,code_bytes=6491,data_bytes=1921,stream_CHR_pages=[884,893],existing_art_CHR=[251,256],retained_ROM_used=sum(p['bytes']for p in placements),retained_ROM_lease=10060,new_RAM0=0,transient_bytes=557,persistent_bytes=8,new_ZP=0,files=len(files),source_closure_members=members,bindings={str(p.resolve()):sha(p)for p in files+direct+tools+refs}))
    print(json.dumps(dict(packet=str(O),handoff_sha256=sha(O/'handoff.json'),ROM_sha256=rom,retained_ROM_used=sum(p['bytes']for p in placements),files=len(files),source_members=members,bytes=sum(p.stat().st_size for p in O.rglob('*')if p.is_file())),indent=2))
if __name__=='__main__':main()
