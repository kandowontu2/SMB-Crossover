; Retained ROM workers for private Quick codeRAM1/dataRAM2 activation.
; No new state/ZP/resident allocation. No write-protection register changes.
.setcpu "6502"
.macpack longbranch
.import FarCallCommon,SafecallA_SMC,FarcallJmpTarget_SMC,CurrentBank,CurrentBankC
.import ArenaGateA,ArenaGateP,ArenaGatePtr,QuickManWork_00,QuickManWork_01
.importzp R0,R1
.import QhDispatch,QhConstruct,QhSync,QhPersistent
.import Qp_QhPortrait
.import FmAlts,SelectedCharacter,Mirror_PPUMASK,Mirror_PPUCTRL,NmiDisable,DisableScreenFlag
.import ReloadCHRBank,CurrentCHRBank,X5ChrMode,X5WideChrActive,ChrPhysicalMap,HorizontalScroll,VerticalScroll
.import MoveAllSpritesOffscreen,SunnyGlobalInit
.import VRAM_Buffer_AddrCtrl,VRAM_Buffer1_Offset,VRAM_Buffer1
.export QwRouter,QwConstruct,QwPortrait,QwColors,QwSyncGate,QwRetire,QwBoot,QwSceneInit
.export QwLoad,QwLoaderCore,QwCookie,QwCacheValid

.macro RomCall Target
 sta SafecallA_SMC+1
 lda #<Target
 sta FarcallJmpTarget_SMC+1
 lda #>Target
 sta FarcallJmpTarget_SMC+2
 lda #.lobyte(.bank(Target)|$80)
 jsr FarCallCommon
.endmacro
.macro PushR01
 lda R0
 pha
 lda R1
 pha
.endmacro
.macro PopR01
 pla
 sta R1
 pla
 sta R0
.endmacro

.segment "QW_ROUTER"
QwActive:
 lda SelectedCharacter
 cmp #9
 bne QwForeign
 lda FmAlts
 and #32
 beq QwForeign
 sec
 rts
QwForeign:clc
 rts

; Only mapper C and A/P flags are volatile. No selected-owner aliases touched.
QwCacheFull:
 txa
 pha
 ldx #15
 bne QwCacheStart
QwCacheValid:
 txa
 pha
 ldx #3
QwCacheStart:
 lda CurrentBankC
 pha
 lda #2
 sta CurrentBankC
 sta $5116
 lda $dfe0
 cmp #$a7
 bne QwBadCache
QwCheckCookie:
 lda $dfe0,x
 cmp QwCookie,x
 bne QwBadCache
 dex
 bne QwCheckCookie
 pla
 sta CurrentBankC
 sta $5116
 pla
 tax
 sec
 rts
QwBadCache:
 pla
 sta CurrentBankC
 sta $5116
 pla
 tax
 clc
 rts

; Source HuCommon sets ArenaGatePtr and passes native A/P via genuine SFC.
; Returning while invalid never executes an uninitialized RAM instruction.
QwRouter:
 php
 pha
 jsr QwCacheValid
 bcc QwNotReady
 pla
 plp
 sta SafecallA_SMC+1
 lda #<QhDispatch
 sta FarcallJmpTarget_SMC+1
 lda #>QhDispatch
 sta FarcallJmpTarget_SMC+2
 lda #1                         ; raw RAM tag, never OR80
 jmp FarCallCommon
QwNotReady:
 pla
 plp
 sec
 rts

QwConstruct:
 jsr QwCacheFull
 bcs QwConstructReady
 jsr QwLoad                     ; accepts only the real blank/lag boundary
 bcc QwUnavailable
QwConstructReady:
 lda #<QhConstruct
 sta ArenaGatePtr
 lda #>QhConstruct
 sta ArenaGatePtr+1
 jmp QwRouter
QwUnavailable:rts
QwSyncGate:
 php
 pha
 lda #<QhSync
 sta ArenaGatePtr
 lda #>QhSync
 sta ArenaGatePtr+1
 pla
 plp
 jmp QwRouter

; ScreenRoutines::InitScreen has already proved Mirror_PPUMASK&18==0.
; This replaces its original same-size farcall operand, not resident code.
QwSceneInit:
 jsr QwActive
 bcc QwSceneNative
 jsr QwConstruct
QwSceneNative:
 RomCall MoveAllSpritesOffscreen
 rts

; True global constructor follows IcGlobalInit. Its output registers/flags
; retain the prior SunnyGlobalInit contract while invalidating warm RAM.
QwBoot:
 RomCall SunnyGlobalInit
 php
 pha
 txa
 pha
 tya
 pha
 lda CurrentBankC
 pha
 lda #2
 sta CurrentBankC
 sta $5116
 lda #0
 sta $dfe0
 ldx #7
QwClearPersistent:
 sta QhPersistent,x
 dex
 bpl QwClearPersistent
 pla
 sta CurrentBankC
 sta $5116
 pla
 tay
 pla
 tax
 pla
 plp
 rts

; A resolved foreign profile retires only a previous valid Quick cache.
; An Arthur-owned cookie is untouched. No RAM0/selected state is borrowed.
QwRetire:
 php
 pha
 txa
 pha
 jsr QwActive
 bcs QwRetireDone
 lda CurrentBankC
 pha
 lda #2
 sta CurrentBankC
 sta $5116
 lda $dfe1
 cmp #9
 bne QwRetireRestore
 lda $dfe0
 cmp #$a7
 bne QwRetireRestore
 lda #0
 sta $dfe0
QwRetireRestore:
 pla
 sta CurrentBankC
 sta $5116
QwRetireDone:
 pla
 tax
 pla
 plp
 rts

; ROM-only authentic standing portrait: C98 metadata and renderer remain
; accessible before RAM construction. Borrowed R0/R1 and raw C are restored.
QwPortrait:
 PushR01
 lda CurrentBankC
 pha
 lda #.lobyte(.bank(Qp_QhPortrait)|$80)
 sta CurrentBankC
 sta $5116
 jsr Qp_QhPortrait
 sta ArenaGateA
 pla
 sta CurrentBankC
 sta $5116
 PopR01
 lda ArenaGateA
 rts

; Source palette queue is deliberately independent of RAM execution/state.
QwColors:
 lda VRAM_Buffer_AddrCtrl
 bne QwColorDone
 ldx VRAM_Buffer1_Offset
 cpx #54
 bcs QwColorDone
 lda #$3f
 sta VRAM_Buffer1,x
 lda #$11
 sta VRAM_Buffer1+1,x
 lda #7
 sta VRAM_Buffer1+2,x
 ldy #6
QwColorCopy:
 lda QwSourceColors,y
 sta VRAM_Buffer1+3,x
 inx
 dey
 bpl QwColorCopy
 txa
 clc
 adc #3
 tax
 stx VRAM_Buffer1_Offset
 lda #0
 sta VRAM_Buffer1,x
QwColorDone:rts
QwSourceColors:.byte $38,$30,$0f,$0f,$15,$28,$0f

QwCookie:
.incbin "cookie.bin"
.assert *-QwCookie=16,error,"Shared temporal owner cookie"

; Check before touching either RAM cache. All PPU transfers occur only while
; genuine native forced blank + lag-NMI gate own the scene. SEI masks IRQ;
; actual lag NMI/audio remains enabled and has DisableScreenFlag!=0,Reload=0.
QwLoad:
 lda Mirror_PPUMASK
 and #$18
 bne QwLoadUnavailable
 lda DisableScreenFlag
 beq QwLoadUnavailable
 lda NmiDisable
 bpl QwLoadUnavailable
 php
 sei
 PushR01
 lda ReloadCHRBank
 pha
 lda #0
 sta ReloadCHRBank
 lda CurrentBankC
 pha
 lda #.lobyte(.bank(QwLoaderCore)|$80)
 sta CurrentBankC
 sta $5116
 jsr QwLoaderCore
 php
 pla
 sta ArenaGateP
 pla
 sta CurrentBankC
 sta $5116
 pla
 sta ReloadCHRBank
 PopR01
 plp
 lda ArenaGateP
 lsr
 rts
QwLoadUnavailable:clc
 rts

.segment "QW_LOADER"
; C-ROM worker can map RAM1/2 through A without executing overwritten RAM.
; No new ZP; R0/R1 are saved by the outer ROM worker.
QwLoaderCore:
 lda CurrentBank
 pha
 lda #2
 sta CurrentBank
 sta $5115
 lda #0
 sta $bfe0                      ; C2DFE0 aliases A2BFE0, invalidate FIRST
 lda Mirror_PPUCTRL
 and #$fb                       ; PPUDATA increment1, retain NMI enable
 ora #$20                       ; explicit8x16 selects the last-written BG set
 sta $2000
 lda #0
 sta QuickManWork_00            ; source stream page index0..8
 lda #1
 sta QuickManWork_01            ; current destination RAM bank1/2
QwLoadBank:
 lda QuickManWork_01
 sta CurrentBank
 sta $5115
 lda #0
 sta R0
 lda #$a0
 sta R1
 ldy #0
 lda #$ff
QwFillPage:
 sta (R0),y
 iny
 bne QwFillPage
 inc R1
 ldx R1
 cpx #$c0
 bne QwFillPage
 lda #$a0
 sta R1
QwLoadPage:
 jsr QwMapPage
 ldx #4
QwCopy256:
 lda $2007
 sta (R0),y
 iny
 bne QwCopy256
 inc R1
 dex
 bne QwCopy256
 ; Re-read the same physical source and compare every copied byte.
 lda R1
 sec
 sbc #4
 sta R1
 jsr QwMapPage
 ldx #4
QwVerify256:
 lda $2007
 cmp (R0),y
 jne QwLoadFailed
 iny
 bne QwVerify256
 inc R1
 dex
 bne QwVerify256
 inc QuickManWork_00
 lda QuickManWork_00
 cmp #7
 beq QwSecondBank
 cmp #9
 bne QwLoadPage
 ; Bank2 is mapped through A. Publish the shared cookie, validity LAST.
 ldx #15
QwPublishCookie:
 lda QwLoadCookie,x
 sta $bfe0,x
 dex
 bne QwPublishCookie
 lda #$a7
 sta $bfe0
 sec
 bcs QwLoadRestore
QwSecondBank:
 inc QuickManWork_01
 jmp QwLoadBank
QwLoadFailed:
 lda #2
 sta CurrentBank
 sta $5115
 lda #0
 sta $bfe0
 clc
QwLoadRestore:
 php
 ; Only BG window11 was borrowed. Its native software publication is exact
 ; at this InitScreen boundary; all other eleven hardware latches stay put.
 lda X5WideChrActive
 beq QwLegacy11
 lda X5ChrMode+11
 bmi QwDirect11
QwLegacy11:
 lda #0
 sta $5130
 ldy CurrentCHRBank+11
 lda ChrPhysicalMap,y
 jmp QwWrite11
QwDirect11:
 and #3
 sta $5130
 lda CurrentCHRBank+11
QwWrite11:
 sta $512b
 lda #0                         ; actual native publisher leaves upper latch0
 sta $5130
 bit $2002
 lda Mirror_PPUCTRL
 sta $2000
 lda HorizontalScroll
 sta $2005
 lda VerticalScroll
 sta $2005
 pla
 sta ArenaGateP
 pla
 sta CurrentBank
 sta $5115
 lda ArenaGateP
 pha
 plp
 rts

; CPU PPUDATA uses the background set after the actual512B write. Each
; physical1KB page is addressed at0C00, with a mandatory buffered-read discard.
QwMapPage:
 lda #3
 sta $5130
 lda QuickManWork_00
 clc
 adc #$74                       ; physical884 = upper3,low116
 sta $512b
 bit $2002
 lda #$0c
 sta $2006
 lda #0
 sta $2006
 lda $2007
 ldy #0
 rts
QwLoadCookie:.incbin "cookie.bin"
