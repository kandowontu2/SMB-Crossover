"""Private source-linked Quick WRAM cartridge. Never installs or launches Mesen."""
from pathlib import Path
import hashlib,json,re,shutil,subprocess,sys
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(Path(__file__).parent))
from check_tmnt_render_oa import load,address,location
P=R/'build/quickman-host-cpu-v4';W=R/'build/quickman-host-integrate-v3';F=R/'build/quickman-wram-whole-cpu-v3'
O=R/'build/quickman-wram-host-v4';T=O/'frozen-inputs';Q=O/'quick'
LEASE=R/'docs/qa/checkpoints/2026-10-30/mmc5-overlay-private-allocation/root-review-and-reservations.json'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,s):
    assert p.resolve().is_relative_to(O.resolve()),('Generated destination outside new packet',p)
    p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,newline='\n')
def save(p,d):put(p,json.dumps(d,indent=2)+'\n')
def trans(s):
    for a,b in [(W.as_posix(),O.as_posix()),(str(W).replace('\\','\\\\'),str(O).replace('\\','\\\\')),(str(W),str(O))]:s=s.replace(a,b)
    return s
def run(cmd,phase):
    assert all(str(W)not in str(v)and W.as_posix()not in str(v)for v in cmd),('Retired working path in command',phase)
    for i,v in enumerate(cmd):
        if v in ['-o','-Ln','-m','--create-full-dep','--debug-info']:
            assert Path(cmd[i+1]).resolve().is_relative_to(O.resolve()),('Output outside packet',phase,v,cmd[i+1])
        if str(v).startswith('--dbgfile,'):
            assert Path(v.split(',',1)[1]).resolve().is_relative_to(O.resolve()),('DBG output outside packet',phase,v)
    p=subprocess.run(cmd,cwd=T,capture_output=True,text=True)
    log=json.loads((O/'commands.json').read_text())if(O/'commands.json').exists()else[]
    log.append(dict(phase=phase,command=cmd,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr));save(O/'commands.json',log)
    assert p.returncode==0,p.stderr[-14000:]
def mirror():
    sys.path.insert(0,str(R/'tools'));from prepare_cv3_dmc_mirror import prepare
    prepare(R,O/'candidate.nes')
def prepare():
    assert not O.exists()or'--resume-prepare'in sys.argv;assert sha(P/'candidate.nes')=='774a78ed9b9ca4bee3276019fac40a0233abc71f5d5d26f9dacb2963b7bd329d'
    assert sha(F/'handoff.json')=='dd2486be91b945b6f208590fc56515d0c9d40395528a6437d3a706648bf9c9cf'
    assert sha(LEASE)=='71e6d9bb97b6dea45da10c614589b3d0a22c5b0f87a294384edf8037c7076b96'
    O.mkdir(exist_ok=True);Q.mkdir(exist_ok=True)
    # The source closure is frozen independently; copy actual selected inputs,
    # then replace all CPU-qualified changed sources by the immutable packet.
    shutil.copytree(W/'frozen-inputs',T,dirs_exist_ok=True);shutil.copytree(W/'src',O/'src',dirs_exist_ok=True)
    for p in W.iterdir():
        if p.is_file()and p.suffix in ['.s','.inc','.cfg','.chr','.bin','.json']:shutil.copy2(p,O/p.name)
    shutil.copytree(P/'source/quick',Q,dirs_exist_ok=True)
    for p in (P/'source').rglob('*'):
        if p.is_file()and not p.is_relative_to(P/'source/quick'):
            dest=O/p.relative_to(P/'source');dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest)
    # All original textual references remain inside this private source copy.
    for p in O.rglob('*'):
        if p.is_file()and p.suffix in ['.s','.inc','.cfg','.json']:
            try:put(p,trans(p.read_text()))
            except UnicodeDecodeError:pass
    shutil.copy2(P/'quick.cfg',O/'private.cfg');put(O/'private.cfg',trans((O/'private.cfg').read_text()))
    cmds=json.loads((O/'parent-commands.json').read_text());link=cmds[-1]
    link[link.index('-C')+1]=str(O/'private.cfg')
    ca=R/'tools/Windows/cc65/bin/ca65.exe'
    cc=T/'build/kamikaze-mario-host-v4/c-full.s'
    run([str(ca),'--cpu','6502x','-t','nes','-g','-o',str(cc.with_suffix('.o')),str(cc)],'private_c_source')
    for cmd in cmds[:-1]:run(cmd,'exact_frozen_parent')
    for n in ['core','render','runtime']:
        run([str(ca),'-g','-I',str(Q),'-I',str(T),str(Q/(n+'.s')),'-o',str(Q/(n+'.o'))],'exact_frozen_quick')
        link.append(str(Q/(n+'.o')))
    run(link,'exact_frozen_parent_link');mirror();assert sha(O/'candidate.nes')==sha(P/'candidate.nes')
    save(O/'exact-parent.json',dict(passed=True,ROM_sha256=sha(O/'candidate.nes')))
    shutil.copy2(O/'candidate.nes',O/'parent-774a78.nes')
    # Required source composition precedes any stream publication.
    pn=R/'build/parodius-chr-compact-v1'
    for n in ['vic_viper.s','parodius.s','parodius_art.inc','parodius_death.s']:shutil.copy2(pn/n,O/'src'/n)
    cfg=(O/'private.cfg').read_text();needle='PARODIUS_CHR_MEM: start=$d0000,size=$30000,type=ro,fill=yes,file=%O,fillval=$00;'
    assert cfg.count(needle)==1
    cfg=cfg.replace(needle,'PARODIUS_CHR_MEM: start=$d0000,size=$9000,type=ro,fill=yes,file=%O,fillval=$00;\nRECLAIMED_PARODIUS_CHR_MEM: start=$d9000,size=$27000,type=ro,fill=yes,file=%O,fillval=$00;')
    put(O/'private.cfg',cfg)
    run(cmds[0],'densePN_source_composition');run(link,'densePN_link');mirror()
    raw=(O/'candidate.nes').read_bytes();base=(O/'parent-774a78.nes').read_bytes();cs=16+128*8192
    dense=(pn/'candidate.nes').read_bytes()
    assert raw[cs+832*1024:cs+868*1024]==dense[cs+832*1024:cs+868*1024]
    assert raw[cs+868*1024:]==bytes(156*1024)
    assert raw[cs+251*1024:cs+256*1024]==base[cs+251*1024:cs+256*1024]
    assert sum(a!=b for a,b in zip(base[16:cs],raw[16:cs]))==54
    shutil.copy2(O/'candidate.nes',O/'dense-parent.nes');shutil.copy2(O/'candidate.dbg',O/'dense-parent.dbg');shutil.copy2(O/'candidate.lbl',O/'dense-parent.lbl')
    save(O/'dense-precondition.json',dict(passed=True,parent_exact=True,dense_ROM_sha256=sha(O/'dense-parent.nes'),dense_pages=[832,868],zero_pages=[868,1024],stream_pages_verified_zero=[884,893],Quick_art_pages_unchanged=[251,256],PRG_table_byte_differences=54,source_overrides={str(pn/n):sha(pn/n)for n in ['vic_viper.s','parodius.s','parodius_art.inc','parodius_death.s']}))
    save(O/'parent-link.json',link)

def sources():
    B=load(P/'candidate.nes')
    whole=(F/'whole.s').read_text()
    # Replace all absolute host definitions with real source-link imports.
    extern=re.findall(r'(?m)^\.import(zp)? (\w+)$',whole)
    entry=trans((P/'source/entrypoint.s').read_text()).replace('nes2wram $2000','nes2wram $8000',1)
    for zp,n in extern:
        if n.startswith('HostBank_'):continue
        if n=='Target':whole=whole.replace('.import Target\n','');continue
        if n=='GmPublishEmpty':continue # genuine external object already exports it
        entry+='\n.export'+('zp 'if zp else' ')+n
    for n in ['MoveAllSpritesOffscreen','SunnyGlobalInit','Mirror_PPUMASK','Mirror_PPUCTRL','NmiDisable','DisableScreenFlag','ReloadCHRBank','CurrentCHRBank','ChrPhysicalMap','HorizontalScroll','VerticalScroll']:entry+='\n.export '+n
    for n in re.findall(r'(?m)^\.importzp HostBank_(\w+)$',whole):entry+='\n.exportzp HostBank_'+n+' := .lobyte(.bank('+n+')|$80)'
    # Own labels are genuine RAM segments and are exported for the source router.
    own=set(re.findall(r'(?m)^(\w+)\s*:',whole))
    exports=set(re.findall(r'(?m)^\.export (.*)$',whole))
    all_exp=set(','.join(exports).split(','))
    for n in sorted(own):
        if n.startswith(('Qh','QuickMan','ArenaGate','ArenaCurrent'))and n not in all_exp:whole+='\n.export '+n
    whole=whole.replace((R/'build/quickman-host-plan-v1/art/quick-man-window0-5pages.chr').as_posix(),(Q/'art-source.chr').as_posix())
    whole=whole.replace((P/'source/quick/metasprites3.bin').as_posix(),(Q/'metasprites3.bin').as_posix())
    shutil.copy2(F/'art.chr',Q/'art-source.chr')
    put(Q/'whole.s',whole+'\n');put(O/'entrypoint.s',entry+'\n')
    # Preserve the genuine ROM-only menu portrait; it cannot call RAM code.
    render=(P/'source/quick/render.s').read_text()
    a=render.index('.segment "QM_COORD"\nQuickManHostRender:');z=render.index('.segment "ARENA_RENDER"',a)
    render=render[:a]+render[z:]
    render=re.sub(r'\.segment "ARENA_CHR"\nQuickManHostChr: \.incbin [^\n]*\n','',render)
    render=render.replace('.export QuickManHostRender,ArenaPublish','.export ArenaPublish').replace(',QuickManHostChr','')
    # No stale mapper dispatcher is needed by this static ROM entry.
    render=render.replace('ArenaCallC,','')
    defs=set(re.findall(r'(?m)^(\w+):',render))
    for n in sorted(defs,key=len,reverse=True):render=re.sub(r'\b'+n+r'\b','Qp_'+n,render)
    render=re.sub(r'(?m)^\.segment "(ARENA_[A-Z_]+)"',lambda m:'.segment "QP_'+m[1]+'"',render)
    render=render.replace((W/'quick/metasprites3.bin').as_posix(),(Q/'metasprites3.bin').as_posix())
    put(Q/'portrait.s',render)
    # True source hooks, with fixed stride and foreign rows preserved.
    union=(P/'source/union.s').read_text();union='.import QwRouter,QwConstruct,QwPortrait,QwColors,QwSyncGate,QwRetire\n'+union
    union=union.replace(' lda HuQuickHi,y\n cmp #$c0\n bcs QuickLeaf',' lda HuQuickBank,y\n bpl QuickLeaf\n lda HuQuickHi,y',1)
    union=union.replace('lda #<QhDispatch','lda #<QwRouter').replace('lda #>QhDispatch','lda #>QwRouter').replace('lda #.lobyte(.bank(QhDispatch)|$80)','lda #.lobyte(.bank(QwRouter)|$80)')
    # Tables for RAM-owned entries carry raw01. Menu/construct use retained ROM.
    a=union.index('HuQuickLo:');z=union.index('HuLo:',a);tables=union[a:z]
    for n in ['QhConstruct','QhPortrait','QhColors']:tables=tables.replace(n,{'QhConstruct':'QwConstruct','QhPortrait':'QwPortrait','QhColors':'QwColors'}[n])
    tables=re.sub(r'\.lobyte\(\.bank\((Qh\w+)\)\|\$80\)','1',tables)
    union=union[:a]+tables+union[z:]
    union=union.replace('farcall QhSync,jmp','farcall QwSyncGate,jmp')
    union=union.replace('Done:pla\n plp\n lda SelectedCharacter','Done:farcall QwRetire\n pla\n plp\n lda SelectedCharacter',1)
    put(O/'union.s',union)
    # Forced-blank native scene boundary, same genuine call-site operand span.
    screen=(T/'src/screen_render.s').read_text();needle='farcall MoveAllSpritesOffscreen ;initialize all sprites including sprite #0'
    assert screen.count(needle)==1;screen='.import QwSceneInit\n'+screen.replace(needle,'farcall QwSceneInit ; selected owner load at actual native forced blank')
    put(O/'src/screen_render.s',screen)
    nr=trans((P/'source/src/new_roster_dispatch.s').read_text());needle=' farcall IcGlobalInit\n farcall SunnyGlobalInit,jmp'
    assert nr.count(needle)==1;nr='.import QwBoot\n'+nr.replace(needle,' farcall IcGlobalInit\n farcall QwBoot,jmp',1);put(O/'src/new_roster_dispatch.s',nr)
    # Components use existing A70/C82 ROM gaps, all within retained leases.
    if not(Q/'cookie.bin').exists():(Q/'cookie.bin').write_bytes(bytes([0xa7,9,32,4])+bytes(12))
    glue=(R/'tools/audit/quickman_wram_loader_v4.s').read_text().replace('"cookie.bin"','"'+(Q/'cookie.bin').as_posix()+'"');put(Q/'loader.s',glue)

def config():
    cfg=(O/'private.cfg').read_text();mem,segs=cfg.split('SEGMENTS {',1)
    # Reclaim only original Quick payload allocations, retaining physical fill.
    segs=re.sub(r'(?m)^(?:R\d+(?:_TABLE)?|QM_COORD|QH_[A-Z_]+|ARENA_[A-Z_]+):load=QH_PRG_\d+,type=ro;\n','',segs)
    # There is one canonical art segment in the loaded source object.
    for n in ['QP_ARENA_ART_META','QP_ARENA_ART_LOOKUP','QP_ARENA_ART_PUBLISH','QP_ARENA_RENDER']:
        original=n.removeprefix('QP_');match=re.search(r'(?m)^'+original+r':load=(QH_PRG_\d+),type=ro;', (P/'quick.cfg').read_text());assert match,n
        segs=segs.replace('}',n+':load='+match[1]+',type=ro;\n}',1)
    # A70 original coordinate+near leaves are adjacent but remain separate file
    # slots. Use only the original720-byte slot initially; other own gaps remain.
    segs=segs.replace('}','QW_ROUTER:load=QH_PRG_0,type=ro;\nQW_LOADER:load=QH_PRG_5,type=ro;\n}',1)
    # Actual physical stream memory order, after Arthur's separate reservation.
    needle='RECLAIMED_PARODIUS_CHR_MEM: start=$d9000,size=$27000,type=ro,fill=yes,file=%O,fillval=$00;'
    assert mem.count(needle)==1
    mem=mem.replace(needle,'ARTHUR_RESERVED_CHR_MEM:start=$d9000,size=$4000,type=ro,fill=yes,file=%O,fillval=$00;\nQW_STREAM_MEM:start=$dd000,size=$2400,type=ro,fill=yes,file=%O,fillval=$00;\nUNCLAIMED_PN_CHR_MEM:start=$df400,size=$20c00,type=ro,fill=yes,file=%O,fillval=$00;')
    mem=mem.rsplit('}',1)[0]+f'QW_RAM1:start=$a000,size=$2000,type=ro,fill=yes,fillval=$ff,file="{(O/"code.bin").as_posix()}",bank=1;\nQW_RAM2:start=$c000,size=$2000,type=ro,fill=yes,fillval=$ff,file="{(O/"data.bin").as_posix()}",bank=2;\n}}\n'
    segs=segs.replace('}','QW_CODE:load=QW_RAM1,type=ro;\nQW_DATA:load=QW_RAM2,type=ro;\nQW_STREAM:load=QW_STREAM_MEM,type=ro;\n}',1)
    put(O/'wram.cfg',mem+'SEGMENTS {'+segs)

def build():
    cmds=json.loads((O/'parent-commands.json').read_text());ca=R/'tools/Windows/cc65/bin/ca65.exe'
    link=cmds[-1];link[link.index('-C')+1]=str(O/'wram.cfg')
    # New component replaces all fragmented source objects, not native hosts.
    for n in ['whole','portrait','loader','stream']:
        if n=='stream'and not(Q/'stream.bin').exists():(Q/'stream.bin').write_bytes(bytes(9216))
        if n=='stream':put(Q/'stream.s','.segment "QW_STREAM"\n.incbin "'+(Q/'stream.bin').as_posix()+'"\n')
        run([str(ca),'-g','-I',str(Q),'-I',str(T),'-I',str(O),str(Q/(n+'.s')),'-o',str(Q/(n+'.o'))],'assemble_'+n)
        link.append(str(Q/(n+'.o')))
    if '--glue-only'not in sys.argv:
        for cmd in cmds[:-1]:run(cmd,'actual_host_source_link')
    run(link,'first_whole_RAM_link');mirror()
    stream=(O/'code.bin').read_bytes()[:7168]+(O/'data.bin').read_bytes()[:2048];assert len(stream)==9216
    payload=(O/'code.bin').read_bytes()[:6491]+(O/'data.bin').read_bytes()[:1921]
    (Q/'cookie.bin').write_bytes(bytes([0xa7,9,32,4])+hashlib.sha256(payload).digest()[:12])
    (Q/'stream.bin').write_bytes(stream)
    run([str(ca),'-g','-I',str(Q),'-I',str(T),'-I',str(O),str(Q/'loader.s'),'-o',str(Q/'loader.o')],'actual_payload_cookie')
    run([str(ca),'-g',str(Q/'stream.s'),'-o',str(Q/'stream.o')],'actual_linked_stream_carrier')
    before=[sha(O/n)for n in ['code.bin','data.bin']];run(link,'final_whole_RAM_link');mirror();assert before==[sha(O/n)for n in ['code.bin','data.bin']]
    raw=(O/'candidate.nes').read_bytes();cs=16+128*8192;base=(O/'dense-parent.nes').read_bytes()
    assert raw[10]==9 and raw[cs+884*1024:cs+893*1024]==stream
    assert raw[cs:cs+884*1024]==base[cs:cs+884*1024]
    assert raw[cs+893*1024:]==base[cs+893*1024:]
    save(O/'prepared.json',dict(status='PRIVATE_SOURCE_LINKED_WHOLE_WRAM_LOADER_CPU_CONTROLS_PENDING',ROM_sha256=sha(O/'candidate.nes'),code_sha256=sha(O/'code.bin'),data_sha256=sha(O/'data.bin'),actual_32KB_header=True,native=False,shared_install=False,conditional_stream=[884,893],Arthur_reserved=[868,884],original_Quick_art=[251,256],bindings={str(LEASE):sha(LEASE),str(P/'handoff.json'):sha(P/'handoff.json'),str(F/'handoff.json'):sha(F/'handoff.json')}))
    print('Actual private WRAM host',sha(O/'candidate.nes'))

if __name__=='__main__':
    if '--prepare'in sys.argv:prepare()
    if '--sources'in sys.argv:sources()
    if '--config'in sys.argv:config()
    if '--build'in sys.argv:build()
