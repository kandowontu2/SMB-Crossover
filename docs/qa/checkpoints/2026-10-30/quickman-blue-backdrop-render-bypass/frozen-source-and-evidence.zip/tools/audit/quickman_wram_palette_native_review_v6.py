"""Freeze narrow blue-backdrop evidence and the real source-render bypass."""
from pathlib import Path
import csv,json,hashlib,collections,sys
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(Path(__file__).parent))
import quickman_wram_palette_controls_v6 as C
P=R/'build/quickman-wram-palette-cpu-v6';N=R/'build/quickman-wram-palette-native-v6';O=R/'build/quickman-wram-palette-native-review-v6'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(n,d):(O/n).write_text(json.dumps(d,indent=2)+'\n',newline='\n')
def main():
 assert not O.exists()
 for p,h in json.loads((P/'handoff.json').read_text())['bindings'].items():assert sha(p)==h,p
 assert json.loads((N/'terminal.json').read_text())['exit_code']==1
 assert 'Meaningful actual source profile coverage'in(N/'candidate-native-palette-v6.log').read_text()
 O.mkdir();spans=list(csv.DictReader((N/'gameplay-spans.csv').open()));palette=list(csv.DictReader((N/'gameplay-palette.csv').open()))
 assert len(palette)==219 and all(int(x['3F00'])==int(x['3F10'])==0x22 for x in palette)
 groups={}
 for n in ['GameLoop','QuickManTick','QhMovement','QhUi','QhDraw']:
  a=[x for x in spans if x['name']==n]
  groups[n]=dict(calls=len(a))
  if a:groups[n].update(foreground_min=min(int(x['foreground'])for x in a),foreground_max=max(int(x['foreground'])for x in a),elapsed_max=max(int(x['elapsed'])for x in a),foreground_sum=sum(int(x['foreground'])for x in a),nested_ISR_sum=sum(int(x['interrupt'])for x in a))
 assert all(groups[n]['calls']==126 for n in ['GameLoop','QuickManTick','QhMovement','QhUi'])and groups['QhDraw']['calls']==0
 m=C.seeded()
 class Watched(C.Bus):
  def __setitem__(self,a,v):
   if isinstance(a,int)and 0x200<=a<0x300:self.oam_writes.append((a,v,self.pc,tuple(self.tags)))
   return super().__setitem__(a,v)
 m.__class__=Watched;m.oam_writes=[];rows=[]
 for age in range(31):
  C.normal_nmi(m,129|(64 if age>=12 else 0));m.oam_writes=[];q=C.invoke(m,'GameLoop')
  if age not in [0,12,30]:continue
  counts={}
  for name in ['KbDrawDispatch','Z2DrawGuard','RlLegacyDrawDispatch','RosterDrawShots','HotPlayerGraphics','KbGraphicsDispatch','ExpandedGraphics','NrGraphics','QhGraphics','GmPublishEmpty','NrDraw','HuDraw','QhDraw','QuickManHostRender','ArenaRenderCore','PlayerBankReady']:
   if name not in m.lab:continue
   pc=m.lab[name];tag=1 if name in ['QhGraphics','QhDraw','QuickManHostRender','ArenaRenderCore']else m.bank(name)|128
   counts[name]=sum(pc==p and tags[(p-0x8000)//8192]==tag for tags,p in q['trace'])
  assert counts['KbDrawDispatch']==counts['Z2DrawGuard']==counts['RlLegacyDrawDispatch']==counts['RosterDrawShots']==counts['PlayerBankReady']==1
  assert counts['QhDraw']==counts['QhGraphics']==counts['GmPublishEmpty']==0
  writers=collections.Counter((pc,tags[1])for a,v,pc,tags in m.oam_writes)
  assert all(bank==132 for pc,bank in writers)
  rows.append(dict(age=age,route_counts=counts,ObjectMetasprite=m.get('ObjectMetasprite'),native_CHR=m.get('CurrentCHRBank'),PlayerChrBank=m.get('PlayerChrBank'),SmPosePtr=list(m.ram[m.lab['SmPosePtr']:m.lab['SmPosePtr']+2]),OAM_cursor=m.get('CurrentOAMOffset'),body_writer_sites=[dict(PC=pc,raw_A=bank,writes=count)for(pc,bank),count in writers.most_common(5)],RAM1_OAM_writer_count=0,OAM_first48=list(m.ram[0x200:0x230])))
 put('observations.json',dict(status='NATIVE_BLUE_BACKDROP_SUBSET_PASS_REAL_RENDER_INTEGRATION_FAIL',ROM_sha256=sha(P/'candidate.nes'),native_process_terminal_exit=1,first_failed_assertion='Meaningful actual source profile coverage: QhDraw0 vs required>50',native_steady_hardware_3F00_and3F10_equal22_samples=219,images_viewed=['quick-cold-menu.png','gameplay-start.png','jump-and-fan.png'],image_findings='Both gameplay screenshots preserve blue overworld; visible legacy body/fan-looking art cannot qualify source renderer. Menu cyan band unchanged and remains open.',source_profile=groups,source_profile_scope='Actual raw-bank/stack-return matched spans in game ages10..190; foreground subtracts real nested ISR elapsed, forcedblank loader excluded. Real126Main/Tick/Movement/UI, noQhDraw.',actual_Main_CPU_OAM_writer_and_route_rows=rows,diagnosis='Raw9 falls below KbDrawDispatch Kirby threshold, thenZ2DrawGuard/RlLegacyDrawDispatch/RosterDrawShots. HotPlayerGraphics also reaches legacy ExpandedGraphics, leaving Bass/ObjectMetasprite233/SmPosePtr and legacyCHR. Native MetaspriteRenderLoop physical4 emits the body cells; source QhGraphics/QhDraw/QuickManHostRender never execute.',previous_193_ABI_scope='48Main+1explicitHuDraw gave193source spans; that separate draw ABI check was not a proof that actualMain reachedHuDraw. This real negative is preserved.',native_admission=False,native_60Hz_qualified=False,automatic_retry=False))
 files=[p for p in N.iterdir()if p.is_file()]+[P/'handoff.json',P/'candidate.nes',P/'native-palette-v6.lua',P/'native-profile-v6.lua',P/'observer-ABI-controls.json',O/'observations.json',Path(__file__)]
 put('handoff.json',dict(status='FROZEN_NATIVE_BLUE_SUBSET_AND_RENDER_BYPASS_NEGATIVE',ROM_sha256=sha(P/'candidate.nes'),native_exit=1,admission=False,bindings={str(p.resolve()):sha(p)for p in files}))
 print(json.dumps(dict(packet=str(O),handoff_sha256=sha(O/'handoff.json'),blue_hardware_samples=219,source_renderer_calls=0)))
if __name__=='__main__':main()
