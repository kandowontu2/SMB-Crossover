"""Private source successor for the observed eed black-backdrop failure."""
from pathlib import Path
import hashlib,json,re,shutil,subprocess,sys
R=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(Path(__file__).parent))
from check_tmnt_render_oa import load,address
P=R/'build/quickman-wram-host-v4'
F=R/'build/quickman-wram-host-cpu-v5'
O=R/'build/quickman-wram-palette-v6'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,s):
    assert p.resolve().is_relative_to(O.resolve()),p
    p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,newline='\n')
def save(n,d):put(O/n,json.dumps(d,indent=2)+'\n')
def verify():
    d=json.loads((F/'handoff.json').read_text())
    for p,h in d['bindings'].items():assert sha(p)==h,('Frozen predecessor changed',p)
    return len(d['bindings'])
def trans(s):
    for a,b in [(P.as_posix(),O.as_posix()),(str(P).replace('\\','\\\\'),str(O).replace('\\','\\\\')),(str(P),str(O))]:s=s.replace(a,b)
    return s
def prepare():
    assert not O.exists();count=verify()
    shutil.copytree(P,O,ignore=shutil.ignore_patterns('positive-*','bench','*.o'))
    for p in O.rglob('*'):
        if p.is_file()and p.suffix in ['.s','.inc','.cfg','.json','.d']:
            try:put(p,trans(p.read_text()))
            except UnicodeDecodeError:pass
    # Both independent owners use the existing genuine native area owner.
    # Preflight all14B so it cannot leave a backdrop-only partial append.
    for n,prefix,call in [('quick/loader.s','Qw',' RomCall X5QueueAreaBackdrop'),('quick/whole.s','Qh',' QhFar X5QueueAreaBackdrop')]:
        p=O/n;s=p.read_text();a=s.index(prefix+'Colors:');z=s.index(prefix+'SourceColors:',a)
        part=s[a:z];assert part.count(' cpx #54')==1
        part=part.replace(' cpx #54',' cpx #50',1)
        needle=' bcs '+('QwColorDone'if prefix=='Qw'else'ColorDone')+'\n'
        assert part.count(needle)==1
        part=part.replace(needle,needle+call+'\n ldx VRAM_Buffer1_Offset\n',1)
        s=s[:a]+part+s[z:]
        s='.import X5QueueAreaBackdrop\n'+s
        if prefix=='Qh':s='.importzp HostBank_X5QueueAreaBackdrop\n'+s
        put(p,s)
    p=O/'entrypoint.s'
    put(p,p.read_text()+'\n.export X5QueueAreaBackdrop\n.exportzp HostBank_X5QueueAreaBackdrop := .lobyte(.bank(X5QueueAreaBackdrop)|$80)\n')
    save('predecessor.json',dict(ROM_sha256=sha(P/'candidate.nes'),frozen_handoff_sha256=sha(F/'handoff.json'),all_frozen_bindings_verified=count,native_graphical_result='FAIL: World1-1 backdrop black; immutable build/quickman-wram-native-v2 captures',source_change='QwColors/QhColors preflight14B, call genuine X5QueueAreaBackdrop, then unchanged original source colors; real source exports/imports only.'))
def run(cmd,phase):
    for i,v in enumerate(cmd):
        if v in ['-o','-Ln','-m','--create-full-dep','--debug-info']:
            assert Path(cmd[i+1]).resolve().is_relative_to(O.resolve()),(phase,v,cmd[i+1])
        if str(v).startswith('--dbgfile,'):assert Path(v.split(',',1)[1]).resolve().is_relative_to(O.resolve())
        assert str(P)not in v and P.as_posix()not in v,(phase,v)
    p=subprocess.run(cmd,cwd=O/'frozen-inputs',capture_output=True,text=True)
    n='successor-commands.json';rows=json.loads((O/n).read_text())if(O/n).exists()else[]
    rows.append(dict(phase=phase,command=cmd,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr));save(n,rows)
    assert p.returncode==0,p.stderr[-12000:]
def build():
    cmds=json.loads((O/'parent-commands.json').read_text());ca=str(R/'tools/Windows/cc65/bin/ca65.exe')
    cc=O/'frozen-inputs/build/kamikaze-mario-host-v4/c-full.s'
    run([ca,'--cpu','6502x','-t','nes','-g','-o',str(cc.with_suffix('.o')),str(cc)],'private_c_source')
    for cmd in cmds[:-1]:run(cmd,'actual_host_source')
    link=cmds[-1];link[link.index('-C')+1]=str(O/'wram.cfg')
    def assemble(n):run([ca,'-g','-I',str(O/'quick'),'-I',str(O/'frozen-inputs'),'-I',str(O),str(O/'quick'/(n+'.s')),'-o',str(O/'quick'/(n+'.o'))],'assemble_'+n)
    for n in ['whole','portrait','loader','stream']:assemble(n);link.append(str(O/'quick'/(n+'.o')))
    run(link,'first_successor_link')
    b=load(O/'candidate.nes');code_size=next(int(s['size'],0)for s in b['segs'].values()if s['name']=='"QW_CODE"');data_size=next(int(s['size'],0)for s in b['segs'].values()if s['name']=='"QW_DATA"')
    code=(O/'code.bin').read_bytes();data=(O/'data.bin').read_bytes()
    assert code_size<=7168 and data_size<=2048
    (O/'quick/cookie.bin').write_bytes(bytes([0xa7,9,32,4])+hashlib.sha256(code[:code_size]+data[:data_size]).digest()[:12])
    (O/'quick/stream.bin').write_bytes(code[:7168]+data[:2048])
    for n in ['loader','stream']:assemble(n)
    run(link,'final_source_link')
    sys.path.insert(0,str(R/'tools'));from prepare_cv3_dmc_mirror import prepare as mirror
    mirror(R,O/'candidate.nes');verify()
    b=load(O/'candidate.nes');old=load(P/'candidate.nes');raw=b['raw'];prev=old['raw'];cs=16+128*8192
    assert raw[:16]==prev[:16]and raw[cs:cs+884*1024]==prev[cs:cs+884*1024]and raw[cs+893*1024:]==prev[cs+893*1024:]
    assert all(address(b,n)==address(old,n)for n in old['syms']if n.startswith('QmField_'))
    save('palette-prepared.json',dict(status='PRIVATE_SOURCE_SUCCESSOR_CPU_TESTS_PENDING',native=False,ROM_sha256=sha(O/'candidate.nes'),loaded_code_bytes=code_size,loaded_data_bytes=data_size,changes='Existing area backdrop owner in ROM and loaded colors. No source visible color changes.',retained_art_and_nonstream_CHR_exact=True,all535_aliases_exact=True))
    print(json.dumps(json.loads((O/'palette-prepared.json').read_text()),indent=2))
if __name__=='__main__':
    if '--prepare'in sys.argv:prepare()
    if '--build'in sys.argv:build()
