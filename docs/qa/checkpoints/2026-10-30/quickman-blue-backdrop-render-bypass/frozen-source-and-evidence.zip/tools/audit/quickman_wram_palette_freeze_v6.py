"""Freeze source/CPU successor; native graphical qualification remains open."""
from pathlib import Path
import hashlib,json,shutil,sys,zipfile,difflib,re
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(Path(__file__).parent))
from check_tmnt_render_oa import load,address
W=R/'build/quickman-wram-palette-v6';P=R/'build/quickman-wram-host-v4';F=R/'build/quickman-wram-host-cpu-v5';O=R/'build/quickman-wram-palette-cpu-v6'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(n,d):(O/n).write_text(json.dumps(d,indent=2)+'\n',newline='\n')
def main():
 assert not O.exists()
 old=json.loads((F/'handoff.json').read_text())
 for n,h in old['bindings'].items():assert sha(n)==h,('Frozen predecessor changed',n)
 rom=sha(W/'candidate.nes');assert rom=='710672e7f0451b136752b8b5455686e6df517027ecb4b7272f49785a40a07610'
 checks=['loader-controls.json','cold-preview-controls.json','lifecycle-controls.json','source-controls.json','render-controls.json','public-controls.json','full-main-controls.json','flags-controls.json','loader-isr-controls.json','active-isr-controls.json','foreign-controls.json','palette-scene-controls.json','palette-isr-controls.json','observer-ABI-controls.json']
 for n in checks:
  d=json.loads((W/n).read_text());assert d['ROM_sha256']==rom and d.get('passed',True),n
 b=load(W/'candidate.nes');p=load(P/'candidate.nes');raw=b['raw'];previous=p['raw'];cs=16+128*8192
 assert raw[:16]==previous[:16]and raw[cs:cs+884*1024]==previous[cs:cs+884*1024]and raw[cs+893*1024:]==previous[cs+893*1024:]
 assert all(address(b,n)==address(p,n)for n in p['syms']if n.startswith('QmField_'))
 assert(W/'code.bin').read_bytes()[6512:]==b'\xff'*(8192-6512)
 assert(W/'data.bin').read_bytes()==(P/'data.bin').read_bytes()
 cookie=(W/'quick/cookie.bin').read_bytes();assert cookie[4:]==hashlib.sha256((W/'code.bin').read_bytes()[:6512]+(W/'data.bin').read_bytes()[:1921]).digest()[:12]
 grant=R/'docs/qa/checkpoints/2026-10-30/rogue-quick-audio-private-allocation/root-review-and-reservations.json'
 assert sha(grant)=='4fb5b1bb6e0e0a8bbc8f906f3a69f48725ad1afa695973be65d8b4ebd59dff92'
 segs=[(int(s['ooffs'],0),int(s['ooffs'],0)+int(s['size'],0),s['name'].strip('"'))for s in b['segs'].values()if'ooffs'in s and s['name']not in ['"QW_CODE"','"QW_DATA"']]
 changes=[]
 for at,(a,z)in enumerate(zip(previous[16:cs],raw[16:cs]),16):
  if a!=z:
   n=next((n for begin,end,n in segs if begin<=at<end),'UNMAPPED')
   assert n in ['QW_ROUTER','QW_LOADER','CHARACTER_HOST_UNION'],(at,n)
   changes.append(dict(bank=(at-16)//8192,offset=(at-16)%8192,before=a,after=z,segment=n))
 assert raw[16+125*8192:16+126*8192]==previous[16+125*8192:16+126*8192]
 assert raw[16+127*8192:cs]==previous[16+127*8192:cs]
 O.mkdir();names=['candidate.nes','candidate.dbg','candidate.lbl','candidate.map','candidate.cv3-mirror.json','code.bin','data.bin','wram.cfg','successor-commands.json','palette-prepared.json','predecessor.json','unused-PRG-review.json','prior-native-cadence-negative.json','native-palette-v6.lua','native-profile-v6.lua','native-profile-config-v6.json','native-palette-prepared.json',*checks]
 for n in names:shutil.copy2(W/n,O/n)
 (O/'quick').mkdir();shutil.copy2(W/'quick/cookie.bin',O/'quick/cookie.bin')
 diff=[]
 for n in ['quick/whole.s','quick/loader.s','entrypoint.s']:
  before=(P/n).read_text().replace(P.as_posix(),'<PRIVATE>').replace(str(P),'<PRIVATE>')
  after=(W/n).read_text().replace(W.as_posix(),'<PRIVATE>').replace(str(W),'<PRIVATE>')
  diff.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='eed/'+n,tofile='7106/'+n))
 (O/'palette-source.diff').write_text(''.join(diff),newline='\n')
 direct=[x for x in W.rglob('*')if x.is_file()and x.suffix in ['.s','.inc','.cfg','.chr','.bin']and not x.is_relative_to(W/'bench')]
 for x in (W/'frozen-inputs').rglob('*'):
  if x.is_file()and x not in direct and x.suffix not in ['.o','.nes','.dbg','.lbl','.map','.py','.json']:direct.append(x)
 tools=[R/'tools/audit'/n for n in ['quickman_wram_palette_v6.py','quickman_wram_palette_controls_v6.py','quickman_wram_headroom_v6.py','quickman_wram_palette_native_v6.py','quickman_wram_observer_abi_v6.py','quickman_wram_palette_freeze_v6.py']]
 with zipfile.ZipFile(O/'source-closure.zip','w',zipfile.ZIP_DEFLATED)as z:
  for x in sorted(set(direct+tools)):z.write(x,x.relative_to(R).as_posix())
 with zipfile.ZipFile(O/'source-closure.zip')as z:assert z.testzip()is None;members=len(z.namelist())
 put('source-linked-proof.json',dict(passed=True,ROM_sha256=rom,predecessor_ROM_sha256=sha(P/'candidate.nes'),loaded_code_bytes=6512,code_growth=21,loaded_data_bytes=1921,data_exact=True,retained_ROM_used=1916,ROM_growth=21,new_ZP=0,transient_RAM=557,persistent_RAM=8,all535_source_aliases_exact=True,unchanged_art_pages=[251,256],changed_stream_pages=[884,893],all_other_CHR_exact=True,fixed125_and127_exact=True,actual_prepare_cv3_dmc_mirror_rerun=True,exact_changed_PRG_bytes=changes,source_diff='palette-source.diff',native=False,source_closure_members=members))
 put('joint-partition.json',dict(status='ACKNOWLEDGED_ROOT_PRIVATE_JOINT_PARTITION',grant=str(grant),grant_sha256=sha(grant),historical_standalone_lease=10060,current_joint_Quick_lease=7500,actual_used=1916,remaining_joint_headroom=5584,ten_Rogue_audio_pages='Reserved by root grant; standalone candidate keeps FF but cannot confer future Quick write ownership. Future unified linker must preserve these audio pages and permanent93:0FA7..<0FE7 exclusion.',future_audio_fit='UNMEASURED; original CX audio/state integration remains open.'))
 (O/'README.txt').write_text('Private source-linked palette repair CPU packet, NOT native graphical admission. Exact710672e7 ROM calls the existing native X5QueueAreaBackdrop from QwColors and loaded QhColors via genuine FarCallCommon, after atomic14-byte conservative queue preflight. Original7 source palette bytes are unchanged. Actual GroundPaletteData + UpdateScreen reproduce predecessor eed black3F00; successor80scene/384queue/68palette ISR controls restore native area backdrop, including buffer offset49 prefix and terminator63 before actual next-buffer offset84. All11 previous CPU groups rerun on this hash;1520source ticks/all535fields,300OAM cases,160source-activeMain cases,512flags,40loader+292activeISR,282foreignMain cases pass. Isolated Main actor fixture does not establish visible native render timing;300 public render cases remain separate.48Main+1publicDraw observer ABI controls close193actual stack/bank matched spans. No native RGB or cadence qualification yet.\n\nOriginal native eed/v2 semantic PASS is superseded as a graphical FAIL: blackWorld1-1 remains unchanged in its screenshots. Old220sample gameplay trace contains156tick/153Main entry differences across219sample intervals and131lagNMI; total168ticks includes earlier phases. Old661853 maximum includes loader and cannot support gameplay timing.\n\nPrepared native fixture rebinds actual source boot/retireSTA instructions and new code6512/data1921/cookie, retains strict no-active-cache-write guard and exact16KB readback, asserts actual3F00/3F10=22 after completed fresh gameplayNMI, captures unchanged controller220frame route, and profiles onlygame ages10..190 using actual raw-bank/stack returns and nestedISR subtraction. Max1000frames/6screenshots; only run_mesen after explicit root queue grant. Fixture preparation is not native evidence.\n\nRoot current joint partition leaves Quick7500B=1916used+5584headroom; ten256B pages belong to prospective Rogue audio. No release or final audio-fit claim arises from standalone FF bytes. OriginalCXaudio/theme/contact cadence, broader scene/platform/water/campaign/Hard ownership and real NTSCcadence remain open. No shared source, Downloads, canonical readiness, emulator or user window changed. All606 predecessor bindings verified unchanged.\n',newline='\n')
 refs=[F/'handoff.json',grant,R/'build/quickman-wram-native-v2/result.json',R/'build/quickman-wram-native-v2/terminal.json',R/'build/quickman-wram-native-v2/frames.csv']
 files=[x for x in O.rglob('*')if x.is_file()]
 put('handoff.json',dict(status='FROZEN_PRIVATE_PALETTE_SOURCE_CPU_SUCCESSOR_NATIVE_OPEN',ROM_sha256=rom,native=False,shared_install=False,code_bytes=6512,data_bytes=1921,retained_ROM_used=1916,joint_Quick_lease=7500,joint_headroom=5584,source_members=members,previous_native_graphical_result='FAIL blackWorld1-1 on immutableeed/v2',bindings={str(x.resolve()):sha(x)for x in files+direct+tools+refs}))
 print(json.dumps(dict(packet=str(O),handoff_sha256=sha(O/'handoff.json'),ROM_sha256=rom,bindings=len(json.loads((O/'handoff.json').read_text())['bindings']),source_members=members),indent=2))
if __name__=='__main__':main()
