"""Prepare only: rebind controller/cache/PPU and gameplay timing observers."""
from pathlib import Path
import hashlib,json,sys
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(Path(__file__).parent))
import quickman_wram_native_prepare_v4 as G
from check_tmnt_render_oa import load,address,location
O=R/'build/quickman-wram-palette-v6'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(n,d):(O/n).write_text(json.dumps(d,indent=2)+'\n',newline='\n')
def lua(v):
 if isinstance(v,dict):return'{'+','.join('['+json.dumps(k)+']='+lua(x)for k,x in v.items())+'}'
 if isinstance(v,list):return'{'+','.join(lua(x)for x in v)+'}'
 return json.dumps(v)
def main():
 assert not(O/'native-palette-v6.lua').exists()or'--reprepare'in sys.argv
 G.O=O;G.main();b=load(O/'candidate.nes');sites=[]
 for first,end,kind in [('QwBoot','QwRetire','boot'),('QwRetire','QwPortrait','retire')]:
  at=location(b,first);raw=b['raw'][at:at+address(b,end)-address(b,first)]
  indexes=[i for i in range(len(raw)-2)if raw[i:i+3]==bytes.fromhex('8de0df')];assert len(indexes)==1
  sites.append(dict(kind=kind,PC=address(b,first)+indexes[0],opcode=[0x8d,0xe0,0xdf],bank=(at-16)//8192,address=0xdfe0,value=0))
 oldguard=R/'build/quickman-wram-native-guard-v2/native-first-look-v2.lua'
 assert sha(oldguard)=='69f03ac8c19fa5ea9e3f79fd35f6b021e80203fc4e1e4d7db8b1a24d64bde38b'
 text=(O/'native-first-look.lua').read_text();guard=oldguard.read_text()
 a=guard.index('local cookieArm=nil');z=guard.index("emu.addMemoryCallback(function()\n if r('CurrentBank')~=1",a)
 patch=guard[a:z]
 # Exact source operands, not numeric PCs carried forward without validation.
 for old,new in [(43321,sites[0]['PC']),(43383,sites[1]['PC'])]:patch=patch.replace(str(old),str(new))
 assert sites[0]['bank']==70 and sites[1]['bank']==70
 a=text.index('emu.addMemoryCallback(function(a)\n');z=text.index("emu.addMemoryCallback(function()\n if r('CurrentBank')~=1",a)
 text=text[:a]+patch+text[z:]
 interrupts={}
 for key,n in [('NMI','NonMaskableInterrupt'),('NMIReturn','NonMaskableInterrupt'),('IRQ','IrqScrollSplit'),('IRQReturn','IrqScrollSplit')]:
  offset=int(b['syms'][n]['size'],0)-1 if key.endswith('Return')else 0
  pc=address(b,n)+offset
  if offset:assert b['raw'][location(b,n)+offset]==64,('Actual final RTI',n)
  interrupts[key]=dict(address=pc,raw_bank=(location(b,n)-16)//8192|128)
 functions=[]
 code=(O/'code.bin').read_bytes()
 for n in ['GameLoop','QuickManTick','QhMovement','QhDraw','QhUi']:
  pc=address(b,n)
  if n=='GameLoop':bank=(location(b,n)-16)//8192|128;first=b['raw'][location(b,n):location(b,n)+3]
  else:bank=1;first=code[pc-0xa000:pc-0xa000+3]
  functions.append(dict(name=n,address=pc,raw_bank=bank,bytes=list(first)))
 config=dict(ROM_sha256=sha(O/'candidate.nes'),first_frame=0,last_frame=1000,functions=functions,interrupts=interrupts)
 baseobserver=R/'tools/audit/arthur_cache_native_profile_v1.lua'
 observer=baseobserver.read_text().replace('ARTHUR_PROFILE_CONFIG','QUICK_PROFILE_CONFIG')
 observer=observer.replace("return wall>=P.first_frame and wall<=P.last_frame and r('SelectedCharacter')==32 and r('OperMode')==1 and r('GameEngineSubroutine')==8", "return QUICK_PROFILE_GATE==true and r('SelectedCharacter')==9 and r('FmAlts')&32~=0 and r('OperMode')==1 and r('GameEngineSubroutine')==8")
 observer=observer.replace("r('ArHostDue')","r('QmField_001C')").replace("n('ArCacheEmit')>50","n('QuickManTick')>100")
 observer=observer.replace("n('GameLoop')>100 and n('QuickManTick')>100","n('GameLoop')>100 and n('QuickManTick')>100 and n('QhDraw')>50")
 observer=observer.replace("n('DrawAllMetasprites'),n('PlayerBGCollision'),n('ArDispatch'),n('ArStep'),n('ArCacheEmit')", "n('QuickManTick'),n('QhMovement'),n('QhDraw'),n('QhUi'),n('QuickManTick')")
 observer=observer.replace('wall,Main,Draw,BG,ArDispatch,ArStep,CacheEmit,clockDue,skip,NmiSkipped,x,y','wall,Main,Tick,Movement,Draw,Ui,TickDuplicate,sourceClock,skip,NmiSkipped,x,y')
 observer=observer.replace('The profile window ends48physical frames before the unchanged400frame','The active gate ends30physical frames before the controller220frame')
 observer=observer.replace('Actual raw-bank/stack-return matched source function spans.','Gameplay-only gate ages10..190; actual raw-bank/stack-return matched source function spans.')
 # Per-return rows retain actual Main and source costs separately, with ISR time.
 observer=observer.replace("local serial,closed=0,0", "local serial,closed=0,0\nlocal spans=assert(io.open(OUTPUT..'gameplay-spans.csv','w'))\nspans:write('name,entryFrame,exitFrame,entryCycle,exitCycle,elapsed,interrupt,foreground,entrySP,returnPC,returnBank\\n')")
 needle="  assert(cpu>=0 and cpu>=q.child,'Actual stack-matched profile accounting')"
 observer=observer.replace(needle,needle+"\n  spans:write(table.concat({q.name,q.wall,wall,q.start,s['cpu.cycleCount'],elapsed,q.interrupt,cpu,q.entrySP,q.ret,q.returnBank},',')..'\\n')")
 observer=observer.replace(' trace:close()',' trace:close();spans:close()',1)
 (O/'native-profile-v6.lua').write_text(observer,newline='\n');put('native-profile-config-v6.json',config)
 prefix='QUICK_PROFILE_GATE=false\nQUICK_PROFILE_CONFIG='+lua(config)+'\nlocal QUICK_PROFILE=dofile([=['+(O/'native-profile-v6.lua').as_posix()+']=])\n'
 text=prefix+text
 text=text.replace('local shots=0', "local shots=0\nlocal freshCompleted,gameFresh=0,nil\nlocal nmiFresh=false\nlocal paletteChecks=0\nlocal palette=assert(io.open(OUTPUT..'gameplay-palette.csv','w'))\npalette:write('wall,age,freshNMI,3F00,3F10,3F11,3F12,3F13,3F15,3F16,3F17\\n')")
 text=text.replace("emu.addMemoryCallback(function() nmis=nmis+1 end,emu.callbackType.exec,L.NonMaskableInterrupt)","emu.addMemoryCallback(function() nmis=nmis+1;nmiFresh=r('NmiDisable')<128 end,emu.callbackType.exec,L.NonMaskableInterrupt)\nemu.addMemoryCallback(function()if nmiFresh then freshCompleted=freshCompleted+1 end;nmiFresh=false end,emu.callbackType.exec,"+str(interrupts['NMIReturn']['address'])+")")
 text=text.replace(" screenshot('gameplay-final')", " assert(paletteChecks>100,'Meaningful hardware palette coverage after freshNMI')\n QUICK_PROFILE.finish()\n palette:close();guardEvents:close()\n screenshot('gameplay-final')",1)
 text=text.replace("gameFrame=wall;startX=r('Player_X_Position');phase='game';screenshot('gameplay-start')", "gameFrame=wall;gameFresh=freshCompleted;startX=r('Player_X_Position');phase='game'")
 needle="  age=age+1;pad.right=true"
 assert text.count(needle)==1
 addition=r'''
  if age>=2 and freshCompleted>gameFresh then
   local values={};for _,p in ipairs({0x3f00,0x3f10,0x3f11,0x3f12,0x3f13,0x3f15,0x3f16,0x3f17})do values[#values+1]=emu.read(p,emu.memType.nesPpuDebug)end
   palette:write(table.concat({wall,age,freshCompleted,table.unpack(values)},',')..'\n');palette:flush()
   if values[1]~=0x22 or values[2]~=0x22 then screenshot('wrong-world-palette')end
   assert(values[1]==0x22 and values[2]==0x22,'Actual steady1-1 blue universal backdrop after fresh completedNMI')
   paletteChecks=paletteChecks+1
   if paletteChecks==1 then screenshot('gameplay-start')end
  end
'''
 text=text.replace(needle,needle+addition,1)
 text=text.replace(" wall=wall+1;pad={}"," wall=wall+1;pad={};QUICK_PROFILE_GATE=phase=='game'and age>=10 and age<=190",1)
 assert 'emu.write('not in text
 (O/'native-palette-v6.lua').write_text(text,newline='\n')
 put('native-palette-prepared.json',dict(status='PREPARED_ONLY_NO_NATIVE_LAUNCH',ROM_sha256=sha(O/'candidate.nes'),script_sha256=sha(O/'native-palette-v6.lua'),exact_source_cookie_store_sites=sites,source_code_bytes=6512,source_data_bytes=1921,cookie_sha256=sha(O/'quick/cookie.bin'),controller_sequence='Unchanged v2 cold controller title/menu/Quick Select-cycle/confirm and220video gameplayframes.',maximum_frames=1000,maximum_screenshots=6,hardware_palette_assertion='After fresh completedNMI during1-1 gameplay,3F00 and3F10 must both equal22; >100checks; screenshots require human blue-world review.',profile='Game ages10..190 only; actual source/rawbank/stack-return matched Main+Tick+movement/draw/UI, nested ISR elapsed subtracted. Loader excluded by gate. No60Hz claim.',original_failed_native='build/quickman-wram-native-v2 unchanged; eed black-sky graphicalFAIL retained.',bindings={str(p.resolve()):sha(p)for p in[Path(__file__),oldguard,baseobserver,O/'candidate.nes',O/'candidate.dbg',O/'candidate.lbl',O/'code.bin',O/'data.bin',O/'quick/cookie.bin',O/'native-palette-v6.lua',O/'native-profile-v6.lua',O/'native-profile-config-v6.json']}))
 print('Prepared successor native only',sha(O/'native-palette-v6.lua'))
if __name__=='__main__':main()
