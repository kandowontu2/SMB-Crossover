"""Verify prepared passive profile call/return assumptions with real6502."""
from pathlib import Path
import json,sys,hashlib
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(Path(__file__).parent))
import quickman_wram_palette_controls_v6 as C
O=C.O
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 cfg=json.loads((O/'native-profile-config-v6.json').read_text());lookup={(x['raw_bank'],x['address']):x for x in cfg['functions']}
 m=C.seeded();calls=[];closed=[];serial=0
 def tag(pc):return m.tags[(pc-0x8000)//8192]if pc>=0x8000 else -1
 def observe(c):
  nonlocal serial
  while calls:
   q=calls[-1]
   if(q['ret'],q['returnSP'],q['returnBank'])!=(c.pc,c.sp,tag(c.pc)):break
   assert c.processorCycles>=q['start'];closed.append(calls.pop())
  h=lookup.get((tag(c.pc),c.pc))
  if not h:return
  assert bytes(m[c.pc:c.pc+3])==bytes(h['bytes'])
  sp=c.sp;ret=(m[256+((sp+1)&255)]+256*m[256+((sp+2)&255)]+1)&65535
  if calls and(calls[-1]['address'],calls[-1]['entrySP'],calls[-1]['ret'])==(c.pc,sp,ret):return
  serial+=1;calls.append(dict(name=h['name'],address=c.pc,entrySP=sp,returnSP=(sp+2)&255,ret=ret,returnBank=tag(ret),start=c.processorCycles))
 for age in range(48):
  C.normal_nmi(m,1|(128 if 5<=age<18 else 0)|(64 if 10<=age<40 else 0))
  C.invoke(m,'GameLoop',hook=observe)
  assert not calls,('Observer assumes a nonexistent ordinary RTS boundary',calls)
 # Main's isolated actor fixture does not publish a visible player render;
 # exercise its already-qualified public draw route explicitly for this ABI.
 C.invoke(m,'HuDraw',hook=observe)
 assert not calls,('Draw observer return boundary',calls)
 counts={n:sum(x['name']==n for x in closed)for n in [x['name']for x in cfg['functions']]}
 assert serial==len(closed)and all(v>0 for v in counts.values()),counts
 # The IRQ/NMI return PCs are actual final RTI instructions and the shared
 # Arthur observer handles real nested elapsed ownership. This receipt checks
 # specifically that none of these Quick functions has the special rare-index
 # transfer which invalidated Arthur's initial ordinary-return observer.
 d=dict(passed=True,native=False,ROM_sha256=sha(O/'candidate.nes'),actual_controller_NMI_and_Main_updates=48,additional_explicit_public_draw_calls=1,source_entry_count=serial,source_closed_count=len(closed),counts=counts,actual_bank_and_stack_matched=True,source_instruction_bytes_exact=True,no_open_nonreturning_or_fake_RTS_spans=True,scope='Actual6502 preparation of profile function boundaries. Isolated Main actor fixture omits visible player render; public HuDraw is separately invoked and300 full OAM cases separately qualify it. Native elapsed/ISR timings are not asserted here.',bindings={str(p):sha(p)for p in[Path(__file__),O/'native-profile-config-v6.json',O/'native-profile-v6.lua',O/'native-palette-v6.lua',O/'candidate.nes',O/'candidate.dbg']})
 (O/'observer-ABI-controls.json').write_text(json.dumps(d,indent=2)+'\n',newline='\n');print(json.dumps(counts))
if __name__=='__main__':main()
