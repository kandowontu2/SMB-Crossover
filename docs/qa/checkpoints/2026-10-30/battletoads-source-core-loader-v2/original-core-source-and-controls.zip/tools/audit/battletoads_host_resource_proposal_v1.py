"""Current-source BT resource REQUEST; never allocates or modifies a host."""
from pathlib import Path
import hashlib, json, re

R = Path(__file__).resolve().parents[2]
O = R / 'build/battletoads-host-resource-proposal-v1'
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()
CURRENT = R / 'build/arthur-goku-smb2-palette-v1'
ROM_REQUEST = [(93, 0x0dc0, 0x0fa7), (87, 0x1020, 0x1100), (72, 0x1011, 0x1100)]


def segments(path):
    out = []
    for line in Path(path).read_text().splitlines():
        if not line.startswith('seg\t'):
            continue
        d = dict(re.findall(r'(\w+)=("[^"]*"|[^,]+)', line.split('\t', 1)[1]))
        if 'ooffs' not in d or not d.get('oname', '').endswith('candidate.nes"') or not int(d['size'], 0):
            continue
        at, size = int(d['ooffs']), int(d['size'], 0)
        out.append(dict(name=d['name'].strip('"'), file_start=at, file_end=at+size,
                        CPU=int(d['start'], 0), bytes=size))
    return out


def excerpts(p, first, last):
    s = p.read_text()
    a = s.index(first)
    b = s.index(last, a)
    return dict(path=str(p.resolve()), first=first, end_exclusive=last,
                first_line=s[:a].count('\n')+1,
                source=s[a:b], sha256=sha(p))


def main():
    assert not O.exists(), 'Immutable output already exists'
    O.mkdir()
    hpd = CURRENT / 'handoff.json'
    assert sha(hpd) == '93cf798479a206ea7ee1e08d503c8357fbee211b85d468d1b471313ab5592482'
    cases = []
    dependencies = [Path(__file__), hpd]
    for root in [R/'build/functional-roster-coherent62-v4', R/'build/arthur-goku-select-remap-v3', CURRENT]:
        p = root / 'joint/candidate.nes'
        dbg = root / 'joint/candidate.dbg'
        raw = p.read_bytes()
        segs = segments(dbg)
        record = dict(path=str(p.resolve()), sha256=sha(p), header=raw[:16].hex(), spans=[])
        for bank, start, end in ROM_REQUEST:
            a, b = 16 + bank*8192 + start, 16 + bank*8192 + end
            data = raw[a:b]
            collisions = [s for s in segs if s['file_start'] < b and a < s['file_end']]
            assert not collisions, ('Live segment collision', root, bank, start, collisions)
            assert set(data) == {255}
            record['spans'].append(dict(physical_bank=bank, offset_start=start, offset_end_exclusive=end,
                bytes=len(data), preimage_sha256=hashlib.sha256(data).hexdigest(), preimage_values=[255],
                actual_linked_segment_intersections=collisions,
                ownership='STILL QUICK-OWNED; explicit source reallocation required'))
        a, b = 16 + 0x100000 + 915*1024, 16 + 0x100000 + 927*1024
        data = raw[a:b]
        collisions = [s for s in segs if s['file_start'] < b and a < s['file_end']]
        assert not collisions and set(data) == {0}
        record['CHR'] = dict(first=915, end_exclusive=927, bytes=len(data),
            preimage_sha256=hashlib.sha256(data).hexdigest(), actual_segment_intersections=collisions,
            request_only=True, body_pages=[915,919], cache_carrier_pages=[919,927])
        cases.append(record)
        dependencies += [p, dbg, root/'joint/private.cfg', root/'handoff.json']
    base = R / 'docs/qa/checkpoints/2026-10-30'
    ledger = [base/'arthur-quick-private-allocation/root-review-and-reservations.json',
              base/'rogue-quick-audio-private-allocation/root-review-and-reservations.json',
              base/'parodius-dense-chr/root-review-and-reservations.json',
              base/'mmc5-overlay-private-allocation/root-review-and-reservations.json',
              base/'ff-ram3-private-allocation/root-review-and-reservations.json',
              base/'benj-toad-peach-source-reservations/receipt.json',
              base/'benj-toad-peach-source-reservations/RAM-reservation.json',
              base/'family-main-commit-private-allocation/root-review-and-reservations.json']
    j = CURRENT / 'joint'
    consumers = [excerpts(j/'loader.s', 'FwRetire:', '; Actual area/life service19'),
                 excerpts(j/'quick/loader.s', 'QwMenuRetire:', '; ROM-only authentic standing portrait'),
                 excerpts(j/'generation-shared.s', '.proc ArGenResolve', '.endproc'),
                 excerpts(j/'ff-palette-lifecycle.s', 'FwMuxMenuA:', 'FwMuxSceneA:')]
    dependencies += ledger + [Path(x['path']) for x in consumers]
    (O/'actual-retirement-consumers.json').write_text(json.dumps(consumers,indent=2)+'\n')
    sizes = json.loads((R/'build/battletoads-small-cache-v1/build.json').read_text())['sizes']
    q = dict(status='REQUEST_ONLY_NO_ALLOCATION_NO_HOST_ADMISSION',
        exact_current_ROM=cases[-1]['sha256'], exact_current_handoff=sha(hpd),
        functional_scope=['Original side-view horizontal acceleration, friction, double-tap dash and fractional jump',
            'Original idle/blink/walk/run/jump and two randomized basic-punch scripts with original event payloads',
            'Rash/Zitz share genuine pose geometry, retain distinct original body colors and common secondary role'],
        cache_payload=sizes, current_preimages=cases,
        ROM_request=dict(total_bytes=950, ranges=ROM_REQUEST,
            required_owner_action='Root and Quick/shared source owner explicitly partition these retained Quick ranges; no FF-only inference',
            planned_budget=dict(loader_check_cookie_retirement=487, cold_ROM_preview=239, typed_row_and_transport=224),
            budget_is_not_assembled_adapter_proof=True,
            fallback='If actual resident source exceeds950B, stop and revise measured producer; do not widen ranges'),
        CHR_request=dict(body_first=915, body_end_exclusive=919, cache_first=919, cache_end_exclusive=927,
            preserves=['Benj901..<915','FF893..<901','Quick884..<893','Arthur868..<884','densePN832..<868'],
            authority='Dense-source release plus subsequent explicit allocations; proposed915..<927 still needs root reservation'),
        RAM_request=dict(existing_bank=3, temporal_reassignment=True, new_global_bytes=0,
            source_state='RAM3 BEE0..<BF55', host_state_budget='RAM3 BF60..<BFA0', cookie='RAM3 BFE0..<BFF0',
            cookie_family=33, entry='Only raw33 + verified own16B cookie; validityA7 published LAST',
            construction='Actual forcedblank InitScreen only; full8192B buffered2007 copy/verify; busy5FFF bit0 held',
            retired='Invalidate raw3 cookie family33 before foreign cache construction/menu ownership publication',
            preserve=['RAM0/5113','RAM1 Quick','RAM2 Arthur/Quick','5102/5103','5FFF actual existing protocol'],
            pointer='Borrow nativeR0/R1 only within own foreground frame, restore on return; real interrupt proof still required',
            persistent_player_health_bridge='Unimplemented; no spare global byte assumed'),
        shared_owner_contract=dict(raw=33, slot=23, variants=['Rash','Zitz'],
            proposed_variant_source='Menu owner may review FmGroups bit5; NOT reserved or written here',
            shared_source_not_edited=True, A79_or_common_growth_not_assumed=True,
            foreground_clock='Original FrameCounter is once-per-BT-completed-foreground, no new NMI clock gate',
            hooks_required=['raw33 typed36 table selection/Only ingress', 'menu resolve retirement/variant publication',
                'Fresh sourceInit after genuine global init', 'forcedblank code load and source area acquisition',
                'one source integrator with native side/head/feet/progression handoffs',
                'source punch event→native target damage/defeat', 'own status/health/damage/death/pickup',
                'ROM cold menu/lives renderer then verified-cache gameplay DrawAll retaining native actors']),
        palette_contract=dict(rash=[15,15,10,26], zitz=[15,15,23,39], common=[15,24,40,32],
            original_two_roles_required=True,
            pending='Scoped secondary-role composition/retirement preserving native actor colors needs source integration; no whole-world recolor assumed',
            universal='Queue only visible shades or preserve genuine native universal; original0F header must not clobber sky3F00'),
        explicit_exclusions=['Extended combos/uppercut/big-foot/big-fist/tongue/weapon/carry/ride/rope/depth-stage subsystems',
            'Original Battletoads music/audio driver not ported; eventual bounded core uses native SMB audio fallback unless separately qualified',
            'Native head/feet/combat/health/lifecycle/actualMain not yet implemented or qualified',
            'Native controller/PPU proof and actual unlock remain pending'],
        no_host_mutation=True, no_native=True,
        reference_consumer_caveat='Actual current segment closure and historical owner receipts do not release Quick future headroom; exact release is a parent decision',
        bindings={str(p.resolve()):sha(p) for p in dependencies + [R/'build/battletoads-small-core-assets-v1/controls.json',
              R/'build/battletoads-small-cache-v1/build.json',R/'build/battletoads-small-cache-v1/combat-controls.json',O/'actual-retirement-consumers.json']})
    (O/'proposal.json').write_text(json.dumps(q,indent=2)+'\n')
    print(json.dumps(dict(status=q['status'],current=q['exact_current_ROM'],ROM_request=950,CHR_pages=12,
        new_global_RAM_bytes=0,remaining_cache_adapter_budget=sizes['remaining_contiguous_host_adapter_budget'],
        proposal_sha256=sha(O/'proposal.json'))))


if __name__=='__main__':
    main()
