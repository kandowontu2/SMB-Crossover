"""Freeze the BT source core/assets and reviewed resource REQUEST, no host edits."""
from pathlib import Path
import hashlib, json, zipfile

R=Path(__file__).resolve().parents[2]
O=R/'build/battletoads-source-core-packet-v3'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    assert not O.exists(), 'Immutable packet already exists'
    O.mkdir()
    roots=[R/'build/battletoads-original-source-v1/upstream-manifest.json',
        R/'build/battletoads-source-reproduction-v1/reproduction.json',
        R/'build/battletoads-native-assets-v1/manifest.json',
        R/'build/battletoads-target-art-v2/controls.json',
        R/'build/battletoads-physics-component-v3/controls.json',
        R/'build/battletoads-playable-core-v3/build.json',
        R/'build/battletoads-playable-core-v3/combat-controls.json',
        R/'build/battletoads-small-core-assets-v1/controls.json',
        R/'build/battletoads-small-cache-v1/build.json',
        R/'build/battletoads-small-cache-v1/combat-controls.json',
        R/'build/battletoads-host-resource-proposal-v1/proposal.json']
    bindings={}

    def bind(p):
        p=Path(p).resolve()
        if str(p) in bindings:return
        assert p.is_file(), p
        bindings[str(p)]=sha(p)
        if p.suffix.lower()=='.json' and (p.parent.name.startswith('battletoads-') or 'battletoads-source-reproduction-v1' in p.parts):
            j=json.loads(p.read_text())
            # Only exact conventional binding maps. Upstream metadata can use
            # other structures; do not invent hash normalization.
            b=j.get('bindings',{}) if isinstance(j,dict) else {}
            for name,expected in (b.items() if isinstance(b,dict) else [(v['path'],v['sha256']) for v in b if isinstance(v,dict) and 'path'in v and 'sha256'in v]):
                if not isinstance(expected,str) or len(expected)!=64:continue
                dep=Path(name)
                assert sha(dep)==expected,('Stale bound input',p,dep)
                bind(dep)

    for p in roots+[Path(__file__)]:bind(p)
    source_paths=set()
    for directory in ['battletoads-original-source-v1/reference',
        'battletoads-source-reproduction-v1/source',
        'battletoads-source-reproduction-v1/toolchain',
        'battletoads-native-assets-v1','battletoads-target-art-v1','battletoads-target-art-v2',
        'battletoads-physics-component-v3','battletoads-playable-core-v1',
        'battletoads-playable-core-v2','battletoads-playable-core-v3',
        'battletoads-small-core-assets-v1','battletoads-small-cache-v1',
        'battletoads-host-resource-proposal-v1']:
        for p in (R/'build'/directory).rglob('*'):
            if p.is_file() and p.suffix.lower() not in ['.exe','.o','.nes','.pyc'] and '__pycache__'not in p.parts:
                source_paths.add(p)
    # Exact source reproduction recipe/labels, not downloaded donor ROM/EXE.
    for name in ['prepare.py','reproduction.json','reproduced.lua']:
        source_paths.add(R/'build/battletoads-source-reproduction-v1'/name)
    for p in R.joinpath('tools/audit').glob('*battletoads*'):
        if p.suffix=='.py':source_paths.add(p)
    source_paths.add(R/'tools/audit/private_build_outputs_v1.py')
    source_paths.update(R.glob('build/battletoads-source-core-packet-v*/freezer-negative.json'))
    manifest={str(p.relative_to(R)).replace('\\','/'):sha(p) for p in sorted(source_paths)}
    (O/'source-members.json').write_text(json.dumps(manifest,indent=2)+'\n')
    archive=O/'source-and-controls.zip'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
        for p in sorted(source_paths):z.write(p,str(p.relative_to(R)).replace('\\','/'))
    with zipfile.ZipFile(archive)as z:
        for name,h in manifest.items():assert hashlib.sha256(z.read(name)).hexdigest()==h
    text='''Battletoads Rash/Zitz source core, not admitted

Original mapper7 donor PRG is byte-exactly reproduced from pinned annotated
source. The basic side-view core preserves original acceleration, friction,
dash, jump fractions, source frame selection and two original small-punch
scripts. No generic Mario physics substitution is present.

Evidence: 2048 original6502 isolated physics pairs; 512 original script ticks;
204 original pose/class pairs for the full102-pose archive; 48 original
class/facing/pose pairs for the legal12-pose basic pack. The latter uses4CHR
pages and512B metadata. Relocated synthetic cache also passes512 script ticks.
These are component/CPU checks, not real hostMain, native terrain or gameplay.

Synthetic cache emits3382B before4522B of unimplemented host-adapter budget.
117B source state plus64B host-state budget remain inside proposed RAM3;
no native5C/global bytes are borrowed. NativeR0/R1 borrowing is a pending
interrupt/actualcaller contract. Existing health records through foreign
cache eviction remain unimplemented.

Resource proposal binds current combined37210891/sourcehandoff93cf, prior
40bce/408a, real source retirement consumers and authoritative reservations.
950B in three Quick-owned ROM ranges, temporalRAM3 andCHR915..<927 are
REQUESTS, not grants or proof that the unassembled resident adapters fit.
Native actor palette composition, collisions/progression/damage/pickups,
health/death/lifecycle and sharedraw33 ingress are still pending. Original
music/extended attacks/carry/rope/ride are excluded from this basic milestone.

All102 original art poses and retained wrong9-sprite packing/attack lookahead
negatives are archived for later full-moveset work. No current host source,
ROM, menu readiness, installed download or emulator process changed.
'''
    (O/'HANDOFF.txt').write_text(text)
    bindings.update({str(p.resolve()):sha(p)for p in[archive,O/'source-members.json',O/'HANDOFF.txt']})
    q=dict(status='FROZEN_SOURCE_CORE_AND_RESOURCE_REQUEST_NO_UNLOCK',source=True,native=False,
        host_admitted=False,original_donor_sha256='2cc2a9afae9b9e875f0fd2f36affb615d81ce4301dbf530336fc23add999e63d',
        original_PRG_exact=True,current_host_sha256='37210891ffbf79373bf3390d16ead891b0e8f43408603a07273f12297a36121a',
        original_physics_pairs=2048,original_script_ticks=512,relocated_cache_script_ticks=512,
        original_all_pose_class_pairs=204,small_pose_class_face_pairs=48,
        sizes=dict(source_core=2864,boundary=6,metadata=512,CHR_pages=4,source_state=117,
            emitted_cache_payload=3382,unimplemented_contiguous_adapter_budget=4522),
        archive=dict(path=str(archive.resolve()),sha256=sha(archive),members=len(manifest),bytes=archive.stat().st_size),
        proposal=str((R/'build/battletoads-host-resource-proposal-v1/proposal.json').resolve()),
        source_members_are_exact=True,foreign_handoffs_hash_bound_not_recursively_live=True,bindings=bindings)
    (O/'handoff.json').write_text(json.dumps(q,indent=2)+'\n')
    print(json.dumps(dict(status=q['status'],handoff_sha256=sha(O/'handoff.json'),bindings=len(bindings),
        archive_members=len(manifest),archive_bytes=archive.stat().st_size)))


if __name__=='__main__':main()
