"""Relocated synthetic RAM3-layout original punch, no actual host allocation."""
from pathlib import Path
import hashlib,importlib.util,json,re,sys,traceback
R=Path(__file__).resolve().parents[2];O=R/'build/battletoads-small-cache-v1';sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
s=importlib.util.spec_from_file_location('original_bt',R/'build/battletoads-native-assets-v1/extract.py');N=importlib.util.module_from_spec(s);s.loader.exec_module(N)
from verify_native_relocation import NesMPU
L={m[2]:int(m[1],16)for line in(O/'cache.lbl').read_text().splitlines()if(m:=re.fullmatch(r'al ([0-9A-Fa-f]+) \.([^ ]+)',line))};rawmap=json.loads((R/'build/battletoads-playable-core-v3/state-map.json').read_text());rename=rawmap['rename'];fields=rawmap['source_names'];sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
class Port:
 def __init__(self):self.ram=bytearray(65536);self.ram[0xa000:0xbee0]=(O/'cache.bin').read_bytes();self.ram[0xe000:0xe100]=(O/'synthetic-host.bin').read_bytes()
 def __getitem__(self,a):return self.ram[a]
 def __setitem__(self,a,v):self.ram[a]=v&255
 def set(self,n,v,i=0):self.ram[L[rename.get(n,n)]+i]=v
 def get(self,n,i=0):return self.ram[L[rename.get(n,n)]+i]
def invoke(m,name,A=0,X=0,original=False):
 c=NesMPU(memory=m,pc=N.LABELS[name]if original else L[name]);c.a=A;c.x=X;c.y=0x57;c.p=0x61;c.sp=253;c.stPushWord(0x5aff);events=[]
 for _ in range(20000):
  if c.pc==0x5b00:break
  if original and name=='toads_simple_punch'and c.pc==N.LABELS['loc_0_A6AF']:
   c.pc=(c.stPopWord()+1)&65535;continue
  at=N.LABELS['anim_damage_by_table']if original else L['BtHostHit']
  if c.pc==at:
   read=(lambda n:m.get(n))if original else(lambda n:m.get(n));events.append(dict(A=c.a,X=c.x,Z=read('hit_Z_table_index'),damage=read('Obj_Amindata2_tmp'),next=read('Obj_Amindata3_tmp')))
   c.pc=(c.stPopWord()+1)&65535;continue
  assert m[c.pc]!=0,('BRK',name,c.pc);c.step()
 else:raise AssertionError(('bound',name,c.pc))
 assert c.sp==253
 return dict(registers=[c.a,c.x,c.y,c.p,c.sp],events=events)
rows=[];last=None
try:
 assert not(O/'combat-controls.json').exists()
 for slot in range(2):
  for air in [0,96]:
   for choice in [0,2]:
    n=N.Bus(0);p=Port();invoke(p,'BtInit')
    for name,address in fields.items():
     for i in range(2 if re.search(r'\b'+re.escape(rename.get(name,name))+r'\s*,X',(O/'core.s').read_text(),re.I)else 1):n.put(name,p.get(name,i),i)
    for name,value in dict(Level_ID=1,Objects_Z_floor=air,Objects_TypeID=slot+1,RandomValue_1=choice,InputHold_P1=(1 if choice==0 else 2),Objects_Flags=(64 if choice==0 else 0)).items():
     index=0 if name=='Level_ID'else slot;n.put(name,value,index);p.set(name,value,index)
    a=invoke(n,'toads_simple_punch',X=slot,original=True);b=invoke(p,'BtStartPunch',X=slot);assert a['registers']==b['registers']
    case=dict(slot=slot,height=air,source_attack_ID=2+choice,frames=[]);rows.append(case)
    for frame in range(64):
     n.put('FrameCounter',frame);p.set('FrameCounter',frame);n.put('InputTap_P1',0,slot);p.set('InputTap_P1',0,slot)
     if n.get('Objects_AnimID',slot):a=invoke(n,'start_read_anim',A=1,X=slot,original=True)
     else:a=None
     b=invoke(p,'BtAttackTick',X=slot);last=dict(slot=slot,air=air,choice=choice,frame=frame,original=a,component=b)
     for name,address in fields.items():
      if name in ['tmp_var_19','tmp_var_1A','tmp_var_1B','tmp_var_1C']:continue # genuine relocated ROM pointers, not state differences
      width=2 if re.search(r'\b'+re.escape(rename.get(name,name))+r'\s*,X',(O/'core.s').read_text(),re.I)else 1
      for i in range(width):assert n.get(name,i)==p.get(name,i),('source field',last,name,i,n.get(name,i),p.get(name,i))
     if a:
      assert a['registers']==b['registers'],('source live return',last)
      assert a['events']==b['events'],('source hit event',last)
     case['frames'].append(dict(frame=frame,attack=n.get('Objects_AnimID',slot),ptr=n.get('Objects_Anim_Ptr',slot),pose=n.get('player1_obj_wanted_frame',slot),events=b['events']))
    assert n.get('Objects_AnimID',slot)==0 and any(x['events']for x in case['frames'])
 q=dict(passed=True,synthetic_cache_layout_only=True,source_actor_sequences=8,source_script_tick_pairs=512,native=False,unmodified_original_three_bank_reader=True,genuine_basic_punch_and_event_payloads_exact=True,all_source_state_except_relocated_pointer_words_exact=True,active_source_AXYP_SP_exact=True,rows=rows,limits=['Native actor hit callback is an explicit boundary on both sides; no real SMB damage/defeat/Main/lifecycle claim.','Only original basic punch IDs2/4 are ported. Extended attacks/carry/tongue/power-ups remain pending.'],bindings={str(p.resolve()):sha(p)for p in[Path(__file__),O/'build.json',O/'core.s',O/'cache.bin',O/'cache.lbl',R/'build/battletoads-playable-core-v3/state-map.json',Path(N.__file__),R/'build/battletoads-source-reproduction-v1/reproduction.json']})
 (O/'combat-controls.json').write_text(json.dumps(q,indent=2)+'\n');print(json.dumps(dict(passed=True,actor_sequences=8,ticks=512)))
except Exception as e:
 p=O/'first-combat-negative.json';assert not p.exists();p.write_text(json.dumps(dict(passed=False,error=repr(e),traceback=traceback.format_exc(),last=last),indent=2)+'\n');raise
