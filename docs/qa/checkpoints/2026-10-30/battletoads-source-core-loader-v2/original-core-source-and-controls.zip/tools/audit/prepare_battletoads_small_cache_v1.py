"""Relocate the small BT source component into a synthetic cache layout only."""
from pathlib import Path
import hashlib, json, re, subprocess, sys

R = Path(__file__).resolve().parents[2]
O = R / 'build/battletoads-small-cache-v1'
sys.path[:0] = [str(R / 'tools/audit')]
from private_build_outputs_v1 import validate

sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()


def main():
    assert not O.exists(), 'Immutable output already exists'
    O.mkdir()
    old = R / 'build/battletoads-playable-core-v3'
    art = R / 'build/battletoads-small-core-assets-v1'
    (O / 'core.s').write_bytes((old / 'core.s').read_bytes())
    (O / 'art.s').write_bytes((art / 'art.s').read_bytes())
    # Genuine original object dispatcher publishes this index before object
    # workers. A direct component caller must reproduce it for native slot1.
    (O / 'boundary.s').write_text('''
.import BtPhysicsStep,Object_RamSlotID_tmp
.export BtCoreStep
.segment "BT_BOUNDARY"
BtCoreStep:
 stx Object_RamSlotID_tmp
 jmp BtPhysicsStep
''')
    (O / 'synthetic-host.s').write_text('''
.export BtState,BtHostCamera,BtHostTerrain,BtSoundDeath,BtHostHit
.exportzp BtScriptPtr
.segment "BT_ZP"
BtScriptPtr:.res 2
.segment "BT_STATE"
BtState:.res 117
.segment "BT_SYNTHETIC_HOST"
BtHostCamera:rts
BtHostTerrain:rts
BtSoundDeath:rts
BtHostHit:rts
''')
    # File is a synthetic layout, NOT a claim on host RAM3/ZP or PRG. Host
    # adapters are unimplemented space, with a fixed upper budget so their
    # eventual source link cannot silently eat state/cookie boundaries.
    out = str(O / 'cache.bin').replace('\\', '/')
    stub = str(O / 'synthetic-host.bin').replace('\\', '/')
    (O / 'cache.cfg').write_text('''MEMORY {
 ZP:start=$f0,size=2,type=rw,file="";
 CACHE:start=$a000,size=$1ee0,type=ro,file="''' + out + '''",fill=yes,fillval=$ff;
 STATE:start=$bee0,size=$75,type=rw,file="";
 HOST_STATE:start=$bf60,size=$40,type=rw,file="";
 COOKIE:start=$bfe0,size=$10,type=rw,file="";
 HOST:start=$e000,size=$100,type=ro,file="''' + stub + '''",fill=yes,fillval=$ff;
}
SEGMENTS {
 BT_ZP:load=ZP,type=zp;
 BT_CORE:load=CACHE,type=ro;
 BT_BOUNDARY:load=CACHE,type=ro;
 BT_ART_META:load=CACHE,type=ro;
 BT_STATE:load=STATE,type=bss;
 BT_SYNTHETIC_HOST:load=HOST,type=ro;
}
''')
    commands = []
    cc = R / 'tools/Windows/cc65/bin'
    for name in ['core', 'boundary', 'art', 'synthetic-host']:
        commands.append([str(cc / 'ca65.exe'), '-g', '-o', str(O / (name + '.o')), str(O / (name + '.s'))])
    commands.append([str(cc / 'ld65.exe'), '-C', str(O / 'cache.cfg'), '-o', str(O / 'unused.bin'),
        '-Ln', str(O / 'cache.lbl'), '--dbgfile', str(O / 'cache.dbg'), '-m', str(O / 'cache.map')]
        + [str(O / (n + '.o')) for n in ['core', 'boundary', 'art', 'synthetic-host']])
    logs = []
    for c in commands:
        guarded = validate(c, O, cwd=R)
        z = subprocess.run(c, cwd=R, text=True, capture_output=True)
        logs.append(dict(command=c, guarded=guarded, returncode=z.returncode, stdout=z.stdout, stderr=z.stderr))
        (O / 'commands.json').write_text(json.dumps(logs, indent=2) + '\n')
        assert z.returncode == 0, z.stderr
    lbl = {m[2]:int(m[1],16) for l in (O/'cache.lbl').read_text().splitlines()
           if (m := re.fullmatch(r'al ([0-9A-Fa-f]+) \.([^ ]+)', l))}
    end = lbl['BtOriginalPalettes'] + 12
    sizes = dict(core=2864, source_context_boundary=6, art_metadata_lookup_palette=512,
                 emitted_cache_payload=end - 0xa000, source_state=117, host_state_budget=64, cookie=16,
                 remaining_contiguous_host_adapter_budget=0xbee0 - end)
    assert sizes['emitted_cache_payload'] == 3382
    q = dict(passed=True, synthetic_only=True, no_host_allocation=True, no_native=True,
        sizes=sizes, layout=dict(code='A000..AD35', adapters_reserved_not_implemented='AD36..<BEE0',
            source_state='BEE0..<BF55', host_state_budget='BF60..<BFA0', cookie='BFE0..<BFF0'),
        host_apis=['BtHostCamera', 'BtHostTerrain', 'BtSoundDeath', 'BtHostHit'],
        pointer_contract='Synthetic F0/F1 only; eventual native R0/R1 borrow requires actual Main/NMI preservation proof',
        readiness_blockers=['No ROM loader/router/preview or host lease granted',
            'No native head/side/feet/progression/damage/pickup/death/lifecycle adapters implemented',
            'No persistent alternating-player health bridge through cache eviction yet',
            'No actual shared raw33 typed ingress or menu variant/art/palette producer',
            'No native Main/ISR/PPU/campaign qualification'],
        bindings={str(p.resolve()):sha(p) for p in [Path(__file__), old/'build.json', old/'combat-controls.json',
             art/'controls.json', R/'tools/audit/private_build_outputs_v1.py'] + list(O.glob('*.s')) +
             [O/'cache.cfg', O/'cache.lbl', O/'cache.map', O/'cache.dbg', O/'cache.bin', O/'commands.json']})
    (O / 'build.json').write_text(json.dumps(q, indent=2) + '\n')
    print(json.dumps(dict(passed=True, synthetic_only=True, sizes=sizes)))


if __name__ == '__main__':
    main()
