"""Pack the finite original BT basic-core poses; does not allocate host resources."""
from pathlib import Path
import hashlib, importlib.util, json, sys

R = Path(__file__).resolve().parents[2]
O = R / 'build/battletoads-small-core-assets-v1'
P = R / 'build/battletoads-target-art-v2'
FRAMES = [1, 2, 3, 4, 5, 6, 7, 8, 25, 27, 29, 45]
sha = lambda p: hashlib.sha256(Path(p).read_bytes()).hexdigest()


def decode(pattern, x, y, role, hflip=False):
    out = {}
    for yy in range(16):
        at = (yy // 8) * 16 + yy % 8
        for xx in range(8):
            sx = 7 - xx if hflip else xx
            v = ((pattern[at] >> (7 - sx)) & 1) | (((pattern[at + 8] >> (7 - sx)) & 1) << 1)
            if v:
                out[x + xx, y + yy] = (role, v)
    return out


def main():
    assert not O.exists(), 'Immutable output already exists'
    O.mkdir()
    q = json.loads((P / 'poses.json').read_text())
    source_chr = (P / 'art.chr').read_bytes()
    source_rows = {r['frame']: r for r in q['frames']}
    pages, rows = [], []
    for f in FRAMES:
        old = source_rows[f]
        recs = []
        for i in range(1, len(old['descriptor']), 4):
            tile, attr, y, x = old['descriptor'][i:i + 4]
            at = old['page'] * 1024 + tile * 16
            recs.append((source_chr[at:at + 32], attr, y, x))
        unique = set(r[0] for r in recs)
        options = [(len(unique - set(p)), i) for i, p in enumerate(pages) if len(unique | set(p)) <= 32]
        if options:
            _, page = min(options)
        else:
            page = len(pages)
            pages.append([])
        for pat in sorted(unique):
            if pat not in pages[page]:
                pages[page].append(pat)
        descriptor = [len(recs) * 4]
        for pat, attr, y, x in recs:
            descriptor += [pages[page].index(pat) * 2, attr, y, x]
        rows.append(dict(frame=f, page=page, descriptor=descriptor,
                         parts=old['parts'], max_scanline=old['max_sprites_per_scanline']))
    chr_bytes = b''.join(b''.join(p) + bytes(1024 - len(p) * 32) for p in pages)
    (O / 'art.chr').write_bytes(chr_bytes)
    # Source CPU verifies exact visible roles, pixels and the original mirror
    # center. Target native flip/anchor integration remains a separate contract.
    spec = importlib.util.spec_from_file_location('bt_native', R / 'build/battletoads-native-assets-v1/extract.py')
    n = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(n)
    base = n.Bus

    class Full(base):
        def __init__(self, bank=0):
            super().__init__(bank)
            self.put('tmp_var_15', 2)
            self.invoke('unpack_tiles_bank1', 1)
            self.bank = bank
            self.writes = []

    n.Bus = Full

    def original_pixels(m, oam, slot):
        out = {}
        for i in range(0, len(oam), 4):
            y, t, a, x = oam[i:i + 4]
            assert a & 3 in [slot, 2]
            role = 0 if a & 3 == slot else 1
            for yy in range(8):
                at = t * 16 + (7 - yy if a & 128 else yy)
                for xx in range(8):
                    sx = 7 - xx if a & 64 else xx
                    v = ((m.chr[at] >> (7 - sx)) & 1) | (((m.chr[at + 8] >> (7 - sx)) & 1) << 1)
                    key = (x + xx - 128, y + 1 + yy - 161)
                    if v and key not in out:
                        out[key] = (role, v)
        return out

    checks = []
    for row in rows:
        pixels = {}
        for i in range(1, len(row['descriptor']), 4):
            t, a, y, x = row['descriptor'][i:i + 4]
            x, y = (x - 256 if x > 127 else x), (y - 256 if y > 127 else y)
            at = row['page'] * 1024 + t * 16
            part = decode(chr_bytes[at:at + 32], x, y, a)
            assert not pixels.keys() & part.keys()
            pixels.update(part)
        for slot in [0, 1]:
            for face in [0, 64]:
                m, oam, meta = n.original(row['frame'], slot, face)
                expected = pixels if face == 0 else {(-x, y): v for (x, y), v in pixels.items()}
                assert original_pixels(m, oam, slot) == expected, ('Original face/role pixels', row['frame'], slot, face)
                checks.append(dict(frame=row['frame'], slot=slot, face=face, pixels=len(pixels)))
    (O / 'poses.json').write_text(json.dumps(dict(frames=rows, pages=len(pages),
        original_mirror_x='left_pixel_offset = -right_pixel_offset about original actorX',
        host_flip_anchor_pending=True, no_host_allocation=True), indent=2) + '\n')
    # Relative labels link into whichever component ROM/cache is later granted.
    asm = ['.segment "BT_ART_META"', '.export BtPoseIds,BtPosePages,BtPoseLo,BtPoseHi,BtOriginalPalettes',
           'BtPoseIds:.byte ' + ','.join(map(str, FRAMES)),
           'BtPosePages:.byte ' + ','.join(str(r['page']) for r in rows),
           'BtPoseLo:.byte ' + ','.join('<BtPose' + str(r['frame']) for r in rows),
           'BtPoseHi:.byte ' + ','.join('>BtPose' + str(r['frame']) for r in rows)]
    for row in rows:
        asm.append('BtPose' + str(row['frame']) + ':.byte ' + ','.join('$%02x' % b for b in row['descriptor']))
    asm += ['BtOriginalPalettes:.byte $0f,$0f,$0a,$1a,$0f,$0f,$17,$27,$0f,$18,$28,$20']
    (O / 'art.s').write_text('\n'.join(asm) + '\n')
    result = dict(passed=True, core_pose_contract=dict(level=1, depth_input_disabled=True,
        carry_not_implemented=True, attack_IDs=[0, 2, 4], frames=FRAMES,
        retained_full102_pose_archive=str(P.resolve()),
        proof_scope='Source branches and original script literals; legal host/state ingress still requires integration controls'),
        original_6502_class_face_pose_pairs=len(checks), original_visible_pixels_and_palette_roles_exact=True,
        CHR_pages=len(pages), CHR_bytes=len(chr_bytes), descriptor_bytes=sum(len(r['descriptor']) for r in rows),
        lookup_bytes=4 * len(rows), palette_bytes=12,
        maximum_parts=max(r['parts'] for r in rows), maximum_scanline=max(r['max_scanline'] for r in rows),
        no_host_allocation=True, no_native=True, cases=checks,
        bindings={str(p.resolve()):sha(p) for p in [Path(__file__), O/'art.chr', O/'art.s', O/'poses.json',
             P/'poses.json', P/'art.chr', P/'controls.json', R/'build/battletoads-playable-core-v3/core.s',
             R/'build/battletoads-playable-core-v3/combat-controls.json', Path(n.__file__)]})
    (O / 'controls.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k:v for k,v in result.items() if k not in ['cases','bindings','core_pose_contract']}))


if __name__ == '__main__':
    main()
