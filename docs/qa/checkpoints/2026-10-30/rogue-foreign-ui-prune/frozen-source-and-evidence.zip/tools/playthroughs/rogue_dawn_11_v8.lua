-- Reuse the existing roster's top-stair landing maneuver. Launching from
-- a lower step spends the jump before the far stair. No geometry changes.
local root=assert(ROSTER_CONFIG.out:match('^(.*)/build/'))
local base=assert(dofile(root..'/tools/playthroughs/rogue_dawn_11_v7.lua'))
local stairs={{begin=2080,peak=2192,edge=2208,far=2240,finish=2304},
 {begin=2336,peak=2432,edge=2448,far=2480,finish=2544}}
local phase,which='climb',1
return function(c)
 if c.world~=0 or c.level~=0 then return base(c) end
 local s=stairs[which]
 if s and c.x>=s.finish then which=which+1;phase='climb';s=stairs[which] end
 if s and c.x>=s.begin and c.x<s.finish then
  local t=c.block(s.edge+8,145)
  local nativeTop=c.block(s.peak+8,145)==0x61
   and c.block(s.far+8,145)==0x61 and(t==0 or t==0x23 or t==0x26)
  if nativeTop then
   if phase=='climb' and c.x>=s.peak and c.y<=112 then phase='land' end
   if phase=='land' then
    local b={right=c.x<s.peak+2,left=c.x>s.peak+6}
    if c.grounded and c.y<=114 and c.r('RdVY')==0
     and c.r('RdGravity')==0 and not c.lastA then
     phase='cross';return {right=true,a=true}
    end
    return b
   elseif phase=='cross' then return {right=true,a=true} end
  end
 end
 return base(c)
end
