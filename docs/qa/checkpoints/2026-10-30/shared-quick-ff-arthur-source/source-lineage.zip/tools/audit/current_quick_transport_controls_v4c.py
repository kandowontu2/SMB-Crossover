"""Keep exact known source-SMC rebinding and genuine SFC NZ semantics explicit."""
import inspect
import current_quick_transport_controls_v4 as M
text=inspect.getsource(M.endpoint);old='if seen and not hu<=dest<hu+36*16:'
assert text.count(old)==1
exec(compile(text.replace(old,"if seen and not (m.tags[1]==(m.bank('HuEntryBase')|128)and hu<=dest<hu+36*16):"),__file__,'exec'),M.__dict__)
text=inspect.getsource(M.same)
old="assert ma.ram[0x100:0x100+live]==mb.ram[0x100:0x100+live],('static/livepage1',case)"
new="assert all(ma.ram[j]==mb.ram[j]for j in range(0x100,0x100+live)if j not in metadata),('static/livepage1 except exact two rebound source lookup operand bytes',case)"
assert text.count(old)==1;exec(compile(text.replace(old,new),__file__,'exec'),M.__dict__)
text=inspect.getsource(M.classifiers)
old="assert z['regs'][:4]==[9 if name in['NrAdder','NrBox']else 0x83,0x5a,0xc7,0xf9],('Quick source ABI',bits,index,z)"
new="expectedA=9 if name in['NrAdder','NrBox']else 0x83\n    assert z['regs'][:4]==[expectedA,0x5a,0xc7,(0xf9&~0x82)|(expectedA&0x80)],('Quick source ABI, genuine SFC LDA owns NZ',bits,index,z)"
assert text.count(old)==1;exec(compile(text.replace(old,new),__file__,'exec'),M.__dict__)
M.O=M.O/'controls-v4c';M.O.mkdir(exist_ok=False)
if __name__=='__main__':M.main()
