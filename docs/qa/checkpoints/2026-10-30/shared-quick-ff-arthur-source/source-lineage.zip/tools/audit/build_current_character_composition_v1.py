"""Actual FF/Quick source composition with retained Arthur, no ROM overlay."""
from pathlib import Path
import hashlib,json,re,subprocess,sys
import prepare_current_character_composition_v1 as B
R=B.R;P=B.P;F=B.F;Q=B.Q;O=B.O;N=B.N;sha=B.sha
sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
from link_pit_rygar_sophia_audit_cpu import scoped_load
from check_tmnt_render_oa import address,location
CA=R/'tools/Windows/cc65/bin/ca65.exe'
def save(n,d):(O/n).write_text(json.dumps(d,indent=2)+'\n')
def rewrite_command(cmd):
 old=Path(cmd[cmd.index('-o')+1]).parent
 if old.name in['arthur','quick']:old=old.parent
 return[x.replace(str(old),str(N)).replace(old.as_posix(),N.as_posix())for x in cmd]
def run(cmd,name):
 for flag in['-o','-Ln','-m','--create-full-dep']:
  if flag in cmd:assert Path(cmd[cmd.index(flag)+1]).resolve().is_relative_to(N.resolve()),cmd
 for x in cmd:
  if x.startswith('--dbgfile,'):assert Path(x.split(',',1)[1]).resolve().is_relative_to(N.resolve())
 p=subprocess.run(cmd,cwd=R,capture_output=True,text=True);save(name+'.json',dict(command=cmd,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr));assert p.returncode==0,p.stderr[-15000:]
def ca(name,folder=N):
 run([str(CA),'-g','--cpu','6502x','-I',str(N),'-I',str(N/'src'),'-I',str(N/'component-src'),'-I',str(folder),'-I',str(R),'-I',str(R/'build/character-host-union-v13'),'--bin-include-dir',str(N),'--bin-include-dir',str(R),'--create-full-dep',str(folder/(name+'.dep')),'-o',str(folder/(name+'.o')),str(folder/(name+'.s'))],'compile-'+folder.name+'-'+name)
def resolve():
 p=N/'entrypoint.s';s=p.read_text();s=(''if '.import FwNativeEnemyInit' in s else '.import FwNativeEnemyInit\n.export RgEnemyStun,LsrFrozenPose,AvFrozen,AvFrozenHi,GuestBodyPrev,GuestBodyNow\n.import FwSvcWall\n.export LmWallGate\n')+s+(''if '.export SamusFreezeRenderFinish' in s else '\n.export SamusFreezeRenderFinish\n');p.write_text(s,newline='\n')
 p=N/'src/characters.s';s=(F/'src/characters.s').read_text();assert s.count('lda #<DkHostFeetUnionRouter')==1
 s=s.replace('lda #<DkHostFeetUnionRouter','lda #<ArGenFoot',1).replace('lda #>DkHostFeetUnionRouter','lda #>ArGenFoot',1).replace('.bank(DkHostFeetUnionRouter)','.bank(ArGenFoot)',1);p.write_text(s,newline='\n')
 p=N/'generation-shared.s';s=p.read_text();old=' sta NextBank_SMC+1\n pla\n pla\n jmp NextBank_SMC\n.endmacro'
 assert s.count(old)==1 and s.count(' GenTail ')==8;s=s.replace(old,' jmp ArGenTailFinish\n.endmacro').replace('.proc ArGenFoot\n php','.proc ArGenFoot\n sta SafecallA_SMC+1\n php',1)
 s+='''
.import FwSvcAfterTerrain
ArGenTailFinish:
 sta NextBank_SMC+1
 pla
 pla
 jmp NextBank_SMC
.export FwGenAfterTerrain
.proc FwGenAfterTerrain
 lda #<FwSvcAfterTerrain
 sta FarcallJmpTarget_SMC+1
 lda #>FwSvcAfterTerrain
 sta FarcallJmpTarget_SMC+2
 lda #.lobyte(.bank(FwSvcAfterTerrain)|$80)
 jmp ArGenTailFinish
.endproc
'''
 p.write_text(s,newline='\n')
 p=N/'union.s';s=p.read_text();tail='.proc HuSourceCallbackTail\n sta NextBank_SMC+1\n plp\n pla\n pla\n jmp NextBank_SMC\n.endproc\n'
 assert s.count(tail)==1;s=s.replace(tail,'').replace('.res $20-(*-HuStart),$ff',tail+'.res $20-(*-HuStart),$ff',1);s='.import FwGenAfterTerrain\n'+s
 needle=' cmp #32\n jeq HuLegacyPostBG::ArAfterLo\n cmp #26';assert s.count(needle)==1
 s=s.replace(needle,' cmp #22\n beq ExtendedPostBG\n cmp #32\n bne OtherPostBG\nExtendedPostBG:\n jmp HuLegacyPostBG::ArAfterLo\nOtherPostBG:\n cmp #26',1)
 old='''ArAfterLo:
 pla
 plp
 lda #<ArGenAfterTerrain
 sta FarcallJmpTarget_SMC+1
 jmp HuLegacyPostBG::ArAfterHi
 .res 2,$ea'''
 new='''ArAfterLo:
 cmp #22
 bne ArLow
 lda #<FwGenAfterTerrain
 bne SetLow
ArLow:
 lda #<ArGenAfterTerrain
SetLow:
 sta FarcallJmpTarget_SMC+1
 pla
 plp
 jmp HuLegacyPostBG::ArAfterHi
 .assert .lobyte(FwGenAfterTerrain)<>0,lderror,"Real FF low-byte shared installer"
 .assert .hibyte(FwGenAfterTerrain)=.hibyte(ArGenAfterTerrain),lderror,"Real common postBG page"'''
 assert s.count(old)==1;s=s.replace(old,new,1);p.write_text(s,newline='\n')
def config():
 p=N/'private.cfg';mem,segs=p.read_text().split('SEGMENTS {',1);parent=scoped_load(P/'candidate.nes')
 regions=[(70,'X5_NEW_46_MID',[(0x860,0x315,'QW_ROUTER_MEM',0xa860)]),(82,'X5_NEW_52',[(0x1c64,0x360,'QW_LOADER_MEM',0xdc64)]),(98,'X5_NEW_62',[(0xc91,0x26b,'QP_META_MEM',0xcc91),(0x1e0b,0xa3,'QP_LOOKUP_MEM',0xde0b),(0x1eae,0x16,'QP_PUBLISH_MEM',0xdeae),(0x1ec4,0x129,'QP_RENDER_MEM',0xdec4)]),(34,'XG_BASS_MEM',[(0x1d9d,1,'QW_EMPTY34_MEM',0xdd9d)])]
 rebind=[];raw=(P/'candidate.nes').read_bytes()
 for bank,name,rs in regions:
  pat=r'(?m)^\s*'+name+r':[^\n]*;';line=re.search(pat,mem).group();base=int(re.search(r'start\s*=\s*\$(\w+)',line)[1],16);size=int(re.search(r'size\s*=\s*\$(\w+)',line)[1],16);begin=base&8191;end=begin+size;cursor=begin;rows=[];keeps=[]
  def memory(label,start,count):return f'{label}:start=${start:x},size=${count:x},type=ro,file=%O,fill=yes,fillval=$ff,bank=${bank:x};'
  for off,count,label,start in sorted(rs):
   assert begin<=off and off+count<=end and off>=cursor
   assert raw[16+bank*8192+off:16+bank*8192+off+count]==bytes([255])*count
   if cursor<off:
    keep=name+'_CurrentKeep'+str(len(keeps));keeps.append((cursor,off,keep));rows.append(memory(keep,base+cursor-begin,off-cursor))
   rows.append(memory(label,start,count));cursor=off+count
  if cursor<end:
   keep=name+'_CurrentKeep'+str(len(keeps));keeps.append((cursor,end,keep));rows.append(memory(keep,base+cursor-begin,end-cursor))
  mem=re.sub(pat,'\n'.join(rows),mem,count=1)
  for v in parent['segs'].values():
   if 'ooffs'not in v:continue
   phy=int(v['ooffs'],0)-16;off=phy%8192;count=int(v['size'],0)
   if phy//8192!=bank or not begin<=off<end:continue
   candidates=[keep for lo,hi,keep in keeps if lo<=off and off+count<=hi];assert len(candidates)==1,(name,v,candidates)
   seg=v['name'].strip('"');spat=r'(?m)^(\s*'+seg+r':\s*load=)'+name+r'(?=,)';segs,n=re.subn(spat,lambda m:m[1]+candidates[0],segs);assert n==1,(name,seg)
   rebind.append([seg,candidates[0],v['start'],v['size']])
 qm,qs=(Q/'quick.cfg').read_text().split('SEGMENTS {',1)
 decls=[l for l in qm.splitlines()if re.match(r'(?:N\d+|QH_PERSIST_MEM):',l)]
 decls +=[f'QW_RAM1:start=$a000,size=$2000,type=ro,fill=yes,fillval=$ff,file="{(N/"code.bin").as_posix()}",bank=1;',f'QW_RAM2:start=$c000,size=$2000,type=ro,fill=yes,fillval=$ff,file="{(N/"data.bin").as_posix()}",bank=2;']
 mem=mem.rsplit('}',1)[0]+'\n'+'\n'.join(decls)+'\n}\n'
 line=next(l for l in mem.splitlines()if re.match(r'\s*CHR\s*:',l));assert 'size = $40000'in line
 mem=mem.replace(line,line.replace('size = $40000','size = $3ec00')+'\nQH_CHR_MEM:start=$3ec00,size=$1400,type=ro,fill=yes,file=%O,fillval=$00;').replace('PRIVATE_QUICK_CARRIER_MEM:','QW_STREAM_MEM:')
 rows=[l for l in qs.splitlines()if l.startswith(('QM_','QH_PERSIST:','QW_','QP_ARENA_','ARENA_CHR:'))]
 body,close,suffix=segs.partition('}');assert close;p.write_text(mem+'SEGMENTS {'+body+'\n'+'\n'.join(rows)+'\n}'+suffix,newline='\n');save('Quick-owned-config.json',dict(regions=regions,native_rebindings=rebind))
def build():
 resolve();config();run(rewrite_command(json.loads((P/'main-build.json').read_text())['command']),'compile-main')
 for name in['union','dk-component']:run(rewrite_command(json.loads((P/(name+'-build.json')).read_text())['command']),'compile-'+name)
 ca('generation-shared')
 for name in['ff-component','publisher','loader','preview','stream','combat','terrain','pickups','veneers','typed-services','ff-render','ff-cull','ff-draw-bridge','ff-palette']:
  run(rewrite_command(json.loads((F/(name+'-build.json')).read_text())['command']),'compile-FF-'+name)
 for name in['whole','portrait','loader','stream']:ca(name,N/'quick')
 cmd=[x.replace(str(P),str(N)).replace(P.as_posix(),N.as_posix())for x in json.loads((P/'clock2-link-resume5.json').read_text())['command']]
 for path in[N/'ff-palette.o',*[N/'quick'/(n+'.o')for n in['whole','portrait','loader','stream']]]:
  if str(path)not in cmd:cmd.append(str(path))
 run(cmd,'first-link')
 b=scoped_load(N/'candidate.nes');sizes={s['name'].strip('"'):int(s['size'],0)for s in b['segs'].values()}
 code=(N/'code.bin').read_bytes();data=(N/'data.bin').read_bytes();cookie=bytes([167,9,32,4])+hashlib.sha256(code[:sizes['QW_CODE']]+data[:sizes['QW_DATA']]).digest()[:12]
 (N/'quick/cookie.bin').write_bytes(cookie);(N/'quick/stream.bin').write_bytes(code[:7168]+data[:2048])
 ram=(N/'ram3.bin').read_bytes();ffcookie=bytes([167,22,0,5])+hashlib.sha256(ram).digest()[:12];(N/'ff-cookie.bin').write_bytes(ffcookie);(N/'ff-stream.bin').write_bytes(ram)
 for name in['loader','stream']:ca(name);ca(name,N/'quick')
 run(cmd,'final-link')
 from prepare_cv3_dmc_mirror import prepare
 prepare(R,N/'candidate.nes');save('linked-stage.json',dict(status='ACTUAL_COMPONENT_SOURCE_LINKED_INGRESS_CONTROLS_PENDING',candidate=sha(N/'candidate.nes'),sizes=sizes,Quick_cookie=cookie.hex(),FF_cookie=list(ffcookie),FF_RAM3=sha(N/'ram3.bin'),native=False,installed=False))
 print(json.dumps(dict(candidate=sha(N/'candidate.nes'),common=sizes['CHARACTER_HOST_UNION'],common512=sizes['GIMMICK_COMMON_NMI'],Quick=[sizes['QW_ROUTER'],sizes['QW_CODE'],sizes['QW_DATA']],FF_RAM3=sha(N/'ram3.bin'))))
if __name__=='__main__':build()
