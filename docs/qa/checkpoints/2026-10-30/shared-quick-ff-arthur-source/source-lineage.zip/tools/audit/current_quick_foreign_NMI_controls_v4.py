"""Exact current foreign NMI, with the qualified FF C93 publication explicit."""
import itertools,json,traceback
import prepare_current_quick_transport_v4 as B
import arthur_physical_clock_presentation_v2 as P
A=P.A;O=B.O;N=B.N
def main():
 out=O/'foreign-NMI-current-controls.json';assert not out.exists();d=dict(passed=False,native=False)
 try:
  parent=A.scoped_load(B.C.P/'candidate.nes');current=A.scoped_load(N/'candidate.nes');g=P.L.L.load_nmi(current);rows=[]
  for ch,lag in itertools.product([i for i in range(34)if i!=32],[0,255]):
   pair=[]
   for v in[parent,current]:
    q=A.C.setup(v,ch);q.put(NmiDisable=lag,DisableScreenFlag=1,VRAM_Buffer_AddrCtrl=0,VRAM_Buffer1_Offset=0,FamilyMainCommit=0);q.m.writes=[];z=g.nmi(q);pair.append((q,z))
   (qa,za),(qb,zb)=pair
   aa,bb=A.C.M.fastapp(qa),A.C.M.fastapp(qb);assert aa==bb,('actual foreign NMI application',ch,lag,A.M.different(aa,bb));assert qa.m.rawtags==qb.m.rawtags
   writes=lambda q:[(a,v)for a,v in q.m.writes if not 256<=a<512]
   wa,wb=writes(qa),writes(qb);assert len(wa)==len(wb)
   delta=[(i,a,b)for i,(a,b)in enumerate(zip(wa,wb))if a!=b]
   expected=[((A.C.address(current,'CurrentBankC'),255),(A.C.address(current,'CurrentBankC'),221)),((0x5116,255),(0x5116,221))]
   assert [(a,b)for _,a,b in delta]==(expected if ch==22 else[]),('only authenticated FF C93 publication changes',ch,lag,delta)
   # 33-byte SMC image must be completely restored even on the source-own
   # graphics publication change; application values above remain exact.
   assert bytes(qa.m[0x15a:0x17b])==bytes(qb.m[0x15a:0x17b])
   rows.append(dict(raw=ch,lag=lag,CPU_delta=zb['CPU']-za['CPU'],minimumSP=zb['minimum_SP'],exact_ordered_write_delta=delta))
  d.update(passed=True,cases=len(rows),rows=rows,all_other_application_orderedwrites_rawmaps_all33SMC_exact=True,FF_selector_source='Root-approved DwResidentGraphicsBanks raw22 FF→genuine FfArtStart bankDD; exactly CurrentBankC and5116 publications, in original order. No arbitrary C normalization.')
 except Exception as e:d.update(error=repr(e),traceback=traceback.format_exc())
 d['bindings']={str(B.Path(p).resolve()):B.B.sha(p)for p in[__file__,N/'candidate.nes',N/'candidate.dbg',B.C.P/'candidate.nes',B.R/'build/ff-graphics-bank-proposal-v2/handoff.json']};out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(passed=d['passed'],error=d.get('error'))));assert d['passed'],d.get('error')
if __name__=='__main__':main()
