"""Use actual36 public export names, retaining v4c alias-only fixture negative."""
import inspect,json,re,traceback
import current_quick_transport_controls_v4 as M
receipt=M.O/'controls-v4c/transport-controls.json';old=json.loads(receipt.read_text())
assert not old['passed']and old['error']=="KeyError('HuHeadWithin')"
for p,h in old['bindings'].items():assert M.B.B.sha(p)==h,p
assert old['checks']['classifier_source_ABI']['foreign_source_endpoint_pairs']==56760
source=(M.N/'union.s').read_text().split('.proc HuCommon',1)[0]
names={}
for name,body in re.findall(r'\.proc (\w+)\n(.*?)\.endproc',source,re.S):
 found=re.search(r' ldy #(\d+)\n jmp HuCommon',body)
 if found:names[int(found[1])]=name
assert set(names)==set(range(36));M.PUBLIC=[names[i]for i in range(36)]
text=inspect.getsource(M.public_workers)
start=text.index("S.execute(b,'Hu'+");end=text.index(',P=p)',start)+len(',P=p)')
text=text[:start]+"S.execute(b,PUBLIC[index],P=p)"+text[end:]
exec(compile(text,__file__,'exec'),M.__dict__)
def main():
 out=M.O/'transport-controls-v4d.json';assert not out.exists()
 d=dict(passed=False,native=False,classifier_receipt=str(receipt),checks={'classifier_source_ABI':old['checks']['classifier_source_ABI']})
 try:d['checks']['public_real_workers']=M.public_workers();d['passed']=True
 except Exception as e:d.update(error=repr(e),traceback=traceback.format_exc())
 files=[M.N/'candidate.nes',M.N/'candidate.dbg',receipt,__file__,M.__file__]
 d['bindings']={str(M.Path(p).resolve()):M.B.B.sha(p)for p in files}
 out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(passed=d['passed'],error=d.get('error'))));assert d['passed'],d.get('error')
if __name__=='__main__':main()
