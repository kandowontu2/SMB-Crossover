"""Exact upstream Quick predicate in owned same-PC native NrDraw capsule."""
from pathlib import Path
import difflib,json,shutil
import prepare_current_quick_transport_v3 as C
from private_build_outputs_v1 import validate
B=C.B;R=C.R;P=C.N;OLD=C.O;O=R/'build/current-character-quick-transport-v4';N=O/'joint'
def rebase(cmd,p):return[x.replace(str(p),str(N)).replace(p.as_posix(),N.as_posix())for x in cmd]
def main():
 assert not O.exists();C.check_bindings(OLD/'source-stage-handoff-v3.json');O.mkdir();shutil.copytree(P,N)
 for p in N.rglob('*'):
  if p.is_file()and p.suffix in['.s','.inc','.cfg']:
   s=p.read_text();z=s.replace(str(P),str(N)).replace(P.as_posix(),N.as_posix())
   if s!=z:p.write_text(z,newline='\n')
 p=N/'src/new_roster_dispatch.s';s=p.read_text()
 old='::GmNrIndex:\n lda SelectedCharacter\n cmp #28\n bcs Rare\n cmp #20';assert s.count(old)==1
 s=s.replace(old,'::GmNrIndex:\n lda SelectedCharacter\n cmp #20',1)
 old='Low:\n cmp #2\n beq Rare\n cmp #9\n beq Rare\n ldy #0\n rts';assert s.count(old)==1
 new='''Low:
 cmp #2
 beq Rare
 cmp #9
 bne LowLegacy
 lda FmAlts
 and #32
 ; CMP#9 supplied C1, retained by LDA/AND. The rare return hash needs it.
 bne Rare
LowLegacy:
 ldy #0
 rts'''
 s=s.replace(old,new,1)
 old='Gimmick:ldy #4\n rts\n .res 2,$ff';assert s.count(old)==1;s=s.replace(old,'Gimmick:ldy #4\n rts',1)
 old='GmNrRoute NrDraw,IcDraw,RcDraw,SunnyDraw,RlDrawDispatch,GmDraw,97,GmExtraNrDraw,54,0';assert s.count(old)==1;s=s.replace(old,old.replace(',54,0',',55,0'))
 p.write_text(s,newline='\n')
 (O/'new_roster_dispatch.s.diff').write_text(''.join(difflib.unified_diff((P/'src/new_roster_dispatch.s').read_text().splitlines(True),s.splitlines(True),fromfile='parent/new_roster_dispatch.s',tofile='successor/new_roster_dispatch.s')),newline='\n')
 cmd=rebase(json.loads((OLD/'compile-main.json').read_text())['command'],P)
 link=rebase(json.loads((OLD/'final-link.json').read_text())['command'],P)
 (O/'output-preflight.json').write_text(json.dumps([validate(q,N,cwd=R)for q in[cmd,link]],indent=2)+'\n')
 B.O=O;B.N=N;B.run(cmd,'compile-main');B.run(link,'final-link')
 from prepare_cv3_dmc_mirror import prepare
 prepare(R,N/'candidate.nes')
 for name in['code.bin','data.bin','ram3.bin','ff-cookie.bin','quick/cookie.bin']:assert(N/name).read_bytes()==(P/name).read_bytes(),name
 C.check_bindings(OLD/'source-stage-handoff-v3.json')
 (O/'source-stage.json').write_text(json.dumps(dict(candidate=B.sha(N/'candidate.nes'),parent=B.sha(P/'candidate.nes'),native=False,installed=False,notes='Exact upstream raw9/FmAlts20 admission. Original public97B capsules and all36Hu11Bprologues/PCs fixed; no new mapper trip for Bass/Roll.'),indent=2)+'\n');print((O/'source-stage.json').read_text())
if __name__=='__main__':main()
