"""Genuine source composition on qualified Arthur; never overlay ROM bytes."""
from pathlib import Path
import difflib,hashlib,json,re,shutil,subprocess,sys
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
P=R/'build/arthur-physical-clock-v2/joint'
F=R/'build/ff-joint-native-flash-1030-v1/joint'
FB=R/'build/ff-joint-full-render-v2/joint'
Q=R/'build/quickman-current-draw-v3'
I=R/'build/quickman-menu-identity-v1'
O=R/'build/current-character-composition-v1';N=O/'joint'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def norm(s,p):return s.replace(str(p),'@JOINT').replace(p.as_posix(),'@JOINT')
def denorm(s):return s.replace('@JOINT',N.as_posix())
def verified(path):
 d=json.loads(path.read_text())
 for name,value in d['bindings'].items():assert sha(name)==value,name
 return dict(path=str(path.resolve()),sha256=sha(path),bindings=len(d['bindings']))
def merge(ours,base,theirs,name):
 if ours==base:return theirs
 if theirs==base or ours==theirs:return ours
 scratch=O/'merge';scratch.mkdir(exist_ok=True)
 for key,value in [('ours',ours),('base',base),('theirs',theirs)]:(scratch/key).write_text(value,newline='\n')
 cmd=['git','merge-file','-p','--diff3','-L','current-Arthur','-L','FF07cda-ancestor','-L','frozen-FF-nativeflash',*[str(scratch/key)for key in['ours','base','theirs']]]
 r=subprocess.run(cmd,cwd=R,capture_output=True,text=True);assert r.returncode in[0,1],r.stderr
 if r.returncode:
  dst=O/'merge-conflicts'/name;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_text(r.stdout,newline='\n');return None
 return r.stdout
def prepare():
 assert not O.exists()
 bindings=[verified(R/'build/arthur-physical-clock-v2/handoff.json'),verified(R/'build/ff-joint-native-flash-qualified-1030-v1/handoff.json'),verified(Q/'handoff.json'),verified(I/'handoff.json')]
 O.mkdir();shutil.copytree(P,N);(O/'input-bindings.json').write_text(json.dumps(bindings,indent=2)+'\n')
 for p in N.rglob('*'):
  if p.is_file()and p.suffix in['.s','.inc','.cfg']:
   s=p.read_text();z=denorm(norm(s,P))
   if s!=z:p.write_text(z,newline='\n')
 changed=[];conflicts=[]
 for f in F.rglob('*'):
  if not f.is_file()or f.suffix not in['.s','.inc','.cfg','.bin']:continue
  rel=f.relative_to(F);base=FB/rel;dst=N/rel
  # Root's Arthur producer is an immutable older leaf; only root's actual
  # FF descendant deltas from the genuine common ancestor are composed.
  if f.suffix=='.bin':
   if base.exists()and f.read_bytes()==base.read_bytes():continue
   shutil.copy2(f,dst);changed.append(rel.as_posix());continue
  theirs=norm(f.read_text(),F);old=norm(base.read_text(),FB)if base.exists()else''
  if old==theirs:continue
  ours=norm(dst.read_text(),N)if dst.exists()else''
  result=merge(ours,old,theirs,rel)
  if result is None:conflicts.append(rel.as_posix())
  else:dst.parent.mkdir(parents=True,exist_ok=True);dst.write_text(denorm(result),newline='\n')
  changed.append(rel.as_posix())
 # Original Quick-owned source files only; no standalone menu/common/cfg.
 shutil.copytree(Q/'quick',N/'quick')
 for p in(N/'quick').rglob('*'):
  if p.is_file()and p.suffix in['.s','.inc']:p.write_text(denorm(norm(p.read_text(),Q)),newline='\n')
 shutil.copy2(Q/'quick-parent-exports.inc',N/'quick-parent-exports.inc')
 entry=(Q/'entrypoint.s').read_text();extra=entry[entry.index('.include "quick-parent-exports.inc"'):]
 p=N/'entrypoint.s';p.write_text(p.read_text()+'\n'+denorm(norm(extra,Q)),newline='\n')
 # Same exact Start identity source hunk, retaining a7cc Celeste name and
 # current Arthur-owned preview/name work outside this unchanged block.
 a=norm((R/'build/expanded-playable-roster-1030-v1/joint/src/character_select.s').read_text(),R/'build/expanded-playable-roster-1030-v1/joint')
 z=norm((I/'src/character_select.s').read_text(),I);p=N/'src/character_select.s'
 merged=merge(norm(p.read_text(),N),a,z,Path('quick-identity-character_select.s'));assert merged is not None
 p.write_text(denorm(merged),newline='\n')
 # Genuine old18B draw guard, with source-owned worker-frame reuse.
 p=N/'src/zelda2_link_render.s';s=p.read_text();needle='.proc Z2DrawGuard\n farcall RlLegacyDrawDispatch,jmp';assert s.count(needle)==1
 p.write_text('.import QwLegacyDrawGate\n'+s.replace(needle,'.proc Z2DrawGuard\n farcall QwLegacyDrawGate,jmp'),newline='\n')
 d=dict(status='SOURCE_PREPARED_MERGE_REVIEW_REQUIRED',parent=sha(P/'candidate.nes'),FF=sha(F/'candidate.nes'),Quick=sha(Q/'candidate.nes'),FF_changed_files=changed,conflicts=conflicts,shared_canonical_edits=False,native=False)
 (O/'preparation.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))
if __name__=='__main__':prepare()
