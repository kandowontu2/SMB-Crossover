"""Bind the genuine first linked stage before any successor composition."""
from pathlib import Path
import difflib,json
import build_current_character_composition_v1 as B
O=B.O;N=B.N;P=B.P;R=B.R
def main():
 out=O/'source-stage-handoff-v1.json';assert not out.exists()
 assert B.sha(N/'candidate.nes')=='b3ddbd7bb214c275db2078affe82e571caa1bb82e2814fc7e74a17c0b3a8b048'
 changes=[];patch=[]
 for p in N.rglob('*'):
  if not p.is_file()or p.suffix not in['.s','.inc','.cfg']:continue
  rel=p.relative_to(N);q=P/rel
  a=B.B.norm(q.read_text(),P)if q.exists()else'';z=B.B.norm(p.read_text(),N)
  if a!=z:changes.append(rel.as_posix());patch.extend(difflib.unified_diff(a.splitlines(True),z.splitlines(True),fromfile='qualified1437/'+rel.as_posix(),tofile='composed/'+rel.as_posix()))
 (O/'source-stage.patch').write_text(''.join(patch),newline='\n')
 paths=[p for p in N.rglob('*')if p.is_file()]+[Path(__file__),R/'tools/audit/prepare_current_character_composition_v1.py',R/'tools/audit/build_current_character_composition_v1.py',R/'tools/audit/resume_current_character_composition_v1.py',R/'tools/audit/resume_current_character_composition_v2.py',O/'input-bindings.json',O/'preparation.json',O/'Quick-owned-config.json',O/'linked-stage.json',O/'source-stage.patch']
 d=dict(status='FROZEN_SOURCE_COMPONENT_STAGE_CPU_CONTROLS_PENDING',candidate=B.sha(N/'candidate.nes'),parent=B.sha(P/'candidate.nes'),native=False,installed=False,new_leases=False,Quick_shared_services_constructor_and_readiness=False,FF_actual_postTerrain=True,root_new_upper_645e_not_included=True,changed_sources=changes,bindings={str(p.resolve()):B.sha(p)for p in paths})
 out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(handoff=B.sha(out),bindings=len(d['bindings']),changed_sources=len(changes))))
if __name__=='__main__':main()
