"""Avoid duplicate proof-report key; source/vector assertions unchanged."""
import inspect
import current_quick_transport_ISR_controls_v4 as M
text=inspect.getsource(M.main);old='kind=kind,**proof[0]';assert text.count(old)==1
exec(compile(text.replace(old,'requested_kind=kind,**proof[0]'),__file__,'exec'),M.__dict__)
M.O=M.O/'ISR-controls-v4b';M.O.mkdir(exist_ok=False)
if __name__=='__main__':M.main()
