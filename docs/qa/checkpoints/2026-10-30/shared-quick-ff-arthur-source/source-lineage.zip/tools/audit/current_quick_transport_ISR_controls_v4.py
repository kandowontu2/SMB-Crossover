"""Real NMI/IRQ at new public selector, Nr predicate and importer seams."""
import json,traceback
import prepare_current_quick_transport_v4 as B
import current_quick_transport_controls_v4 as M
C=M.C;S=M.S;O=B.O;N=B.N
def main():
 out=O/'transport-real-ISR-controls.json';assert not out.exists();d=dict(passed=False,native=False);old=C.O;C.O=N;C.CODE=(N/'code.bin').read_bytes();C.DATA=(N/'data.bin').read_bytes()
 try:
  rows=[]
  for name,raw,bits in[('NrMovement',9,0),('NrMovement',9,32),('GmColorsGate',9,32),('HuWorldPalette',9,32),('HuMovement',3,0)]:
   template=C.Bus();template.set('SelectedCharacter',raw);template.set('FmAlts',bits)
   if bits:C.invoke(template,'QwConstruct');C.exact_cache(template)
   template.set('GameEngineSubroutine',8);template.set('Player_Y_HighPos',1);template.set('Player_Y_Position',160);template.set('Player_X_Position',96);template.set('FamilyMainCommit',1)
   m=S.clone(template);cuts=[];seen=set();step=0
   def watch(c):
    nonlocal step
    pc=c.pc;tag=m.tags[(pc-32768)//8192]if pc>=32768 else-1;op=bytes(m[pc:pc+3]);key=(tag,pc)
    eligible=(tag==207 and m.lab['HuStart']<=pc<m.lab['HuEnd'])or(tag==252 and (m.lab['GmNrIndex']<=pc<m.lab['NrPortrait']or m.lab['GmOnlyCommon']<=pc<m.lab['NrWeapons']+97))or 0x15a<=pc<0x17b or op in[b'\x8d\x15\x51',b'\x8d\x16\x51']
    if key not in seen and eligible:seen.add(key);cuts.append((step,pc,tag))
    step+=1
   S.execute(m,name,A=0x83,X=0x5a,Y=0xc7,P=0x71,hook=watch)
   for cut,pc,tag in cuts:
    for lag in[0,255]:
     for kind in['NMI','IRQ']:
      q=S.clone(template);q.set('NmiDisable',lag);age=0;proof=[]
      def inject(c):
       nonlocal age
       if age==cut:
        assert c.pc==pc and not c.p&c.INTERRUPT
        proof.append(C.interrupt_at(q,c,kind))
       age+=1
      S.execute(q,name,A=0x83,X=0x5a,Y=0xc7,P=0x71,hook=inject);assert len(proof)==1
      if bits:C.exact_cache(q)
      rows.append(dict(entry=name,raw=raw,alts=bits,step=cut,PC=pc,tag=tag,lag=lag,kind=kind,**proof[0]))
  d.update(passed=True,real_normal_lag_NMI_IRQ=len(rows),rows=rows,scope='Real source selectors/rare hash/public padding islands/genuine resident SFC/mapper transactions. Existing vector helper strictly restores AXYP/SP, all33SMC, borrowedR01/R67, static/livepage1 and rawmaps/shadows; Quick code/data/cookie exact. No native cadence claim.')
 except Exception as e:d.update(error=repr(e),traceback=traceback.format_exc())
 finally:C.O=old
 d['bindings']={str(B.Path(p).resolve()):B.B.sha(p)for p in[__file__,M.__file__,N/'candidate.nes',N/'candidate.dbg']};out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(passed=d['passed'],error=d.get('error'),vectors=d.get('real_normal_lag_NMI_IRQ'))));assert d['passed'],d.get('error')
if __name__=='__main__':main()
