"""Freeze qualified actual shared Quick ingress; cold readiness stays pending."""
from pathlib import Path
import json,re
import prepare_current_quick_transport_v4 as B
from check_tmnt_render_oa import address,location
from link_pit_rygar_sophia_audit_cpu import scoped_load
R=B.R;N=B.N;O=B.O
def main():
 out=O/'handoff.json';assert not out.exists();B.C.check_bindings(B.OLD/'source-stage-handoff-v3.json')
 assert B.B.sha(N/'candidate.nes')=='53d87216907156ec6d6330e1c9f9338802231113f1d3d6f962474080fc55ddde'
 parent=scoped_load(B.C.P/'candidate.nes');b=scoped_load(N/'candidate.nes')
 names=[]
 for name,body in re.findall(r'\.proc (\w+)\n(.*?)\.endproc',(N/'union.s').read_text().split('.proc HuCommon',1)[0],re.S):
  if re.search(r' ldy #\d+\n jmp HuCommon',body):names.append(name)
 assert len(names)==36
 checks=[]
 for name in names:
  old=location(parent,name);new=location(b,name)
  assert old==new and address(parent,name)==address(b,name)
  assert parent['raw'][old:old+11]==b['raw'][new:new+11],name
  checks.append([name,address(b,name),new,True])
 for name in ['NrMovement','NrGraphics','NrDraw','NrPortrait','NrWeapons','NrInjury','NrLegacyInjuryStatus','NrDeathStart','NrDeath','NrVisible','NrHead','NrBody','NrAdder','NrBox','NrSide','MenuResolveCharacter','FmPending','QueueSelection','InitScreen']:
  assert address(parent,name)==address(b,name)and location(parent,name)==location(b,name),name
 sizes={s['name'].strip('"'):int(s['size'],0)for s in b['segs'].values()}
 assert sizes['CHARACTER_HOST_UNION']==2591 and sizes['GIMMICK_COMMON_NMI']==502
 for name in['code.bin','data.bin','ram3.bin','ff-cookie.bin','quick/cookie.bin']:assert(N/name).read_bytes()==(B.C.P/name).read_bytes(),name
 changes={}
 for i,(a,z)in enumerate(zip(parent['raw'],b['raw'])):
  if a!=z:changes.setdefault((i-16)//8192,[]).append([(i-16)%8192,a,z])
 assert set(changes)<={79,124,125,127},changes.keys()
 for bank in[125,127]:
  assert len(changes.get(bank,[]))==1 and changes[bank][0][1:]==[255,221],changes.get(bank)
 proof=dict(passed=True,source_only=True,actual_changed_banks=changes,all36_original11Bprologues_and_PCs_exact=checks,all15Nr_public_PCs_exact=True,common_sizes=[sizes['CHARACTER_HOST_UNION'],sizes['GIMMICK_COMMON_NMI']],unchanged_payloads=['Quick6512code/1921data/full8192images/cookie4','FF8192RAM3/cookie6','Arthurcache6130/runtime550/mailbox/clockcode'],no_new_PRG_RAM_ZP_CHR_lease=True,genuine_source_tail_factoring=True,retired_symbol='Only table-private GmStatusName redundant3BJMP; genuine GmStatusNameTail targets rebound in three own metadata rows. No external producer import used old symbol.')
 (O/'source-ownership-public-PC-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
 passing=[O/'transport-controls-v4d.json',O/'ISR-controls-v4b/transport-real-ISR-controls.json',O/'foreign-NMI-current-controls.json',O/'arthur-composed-Main/complete-Main-physical-clock-v2.json',O/'FF-composed-Main/actual-FF-merged-Main-v3.json']
 for p in passing:assert json.loads(p.read_text())['passed'],p
 rgb=json.loads((O/'arthur-composed-Main/presentation-foreign-NMI-physical-clock-v2.json').read_text())
 assert not rgb['passed']and rgb['checks']['actual_NMI_source_RGB_alpha_priority']['actual_cartridge_pose_area_cases']==201
 tools=[p for p in(R/'tools/audit').glob('current_quick_*v4*.py')]+[Path(__file__),Path(B.__file__)]
 files=[p for p in O.rglob('*')if p.is_file()]+tools+[B.OLD/'source-stage-handoff-v3.json',R/'build/quickman-joint-actual-main-v2/handoff.json',R/'build/ff-graphics-bank-proposal-v2/handoff.json']
 h=dict(status='FROZEN_ACTUAL_SHARED_QUICK_SOURCE_INGRESS_CPU_PASS_COLD_PENDING',candidate=B.B.sha(N/'candidate.nes'),native=False,installed=False,checks=dict(foreign_endpoint_pairs=56760,all_altbit_routes=7936,real36public_all64flags_worker_pairs=2304,real_normal_lag_NMI_IRQ=1016,foreign_NMI_pairs=66,Arthur_real_Main_frames=40,Arthur_original_RGB_posearea=201,FF_actual_Main=64),resource_sizes=dict(A79=2591,common512=502,QW_ROUTER=755),limits=['Quick Boot/Scene/retirement and actual ready-menu launch are not yet connected; no Quick native/readiness claim.','Foreign importer CPU delta−8..+31; original mapper-entry count exact. Bass/Roll+4..9; Arthur+8..16. Severe Arthur lag remains a separate hold.','Source RGB proof on direct predecessor d55c is independently bound; exact53d pixel repeat requested.','Retained test negatives include obsolete FF C publication expectation. Separate current66NMI proof asserts the ONLY exact FF→DD owner publications, with allotherwrites/33SMC exact.'],bindings={str(p.resolve()):B.B.sha(p)for p in files})
 out.write_text(json.dumps(h,indent=2)+'\n');print(json.dumps(dict(candidate=h['candidate'],handoff=B.B.sha(out),bindings=len(h['bindings']),sizes=h['resource_sizes'])))
if __name__=='__main__':main()
