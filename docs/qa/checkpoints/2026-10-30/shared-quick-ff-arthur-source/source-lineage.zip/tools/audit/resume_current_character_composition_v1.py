"""Resume only the new-tree build after retained preparation assertions."""
import build_current_character_composition_v1 as B
if __name__=='__main__':
 B.resolve=lambda:None
 B.build()
