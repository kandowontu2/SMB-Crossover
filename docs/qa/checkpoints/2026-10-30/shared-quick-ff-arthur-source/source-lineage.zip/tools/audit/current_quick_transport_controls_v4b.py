"""Correct fixture PC ownership using the true Hu A79 bank; retain v4 negative."""
import inspect
import current_quick_transport_controls_v4 as M
text=inspect.getsource(M.endpoint)
old='if seen and not hu<=dest<hu+36*16:'
new="if seen and not (m.tags[1]==(m.bank('HuEntryBase')|128)and hu<=dest<hu+36*16):"
assert text.count(old)==1
exec(compile(text.replace(old,new),__file__,'exec'),M.__dict__)
M.O=M.O/'controls-v4b';M.O.mkdir(exist_ok=False)
if __name__=='__main__':M.main()
