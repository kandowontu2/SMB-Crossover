"""Repeat genuine Arthur clock/presentation and FF Main on exact Quick ingress."""
import sys
import prepare_current_quick_transport_v4 as B
if '--arthur'in sys.argv:
 import current_character_composition_context_v1 as V
 import arthur_physical_clock_main_v2 as M
 import arthur_physical_clock_presentation_v2 as P
 V.O=B.O/'arthur-composed-Main';V.N=B.N;V.C=B.C.B # unused dependency; A is genuine source API
 V.O.mkdir(exist_ok=False)
 # Preserve actual physical-clock C module dependency, not the builder.
 import arthur_physical_clock_context_v2 as A
 V.C=A.C
 for module in[M,P]:module.V=V;module.A=V.A;module.B=V.B;module.O=V.O;module.N=V.N
 M.main();P.main()
elif '--FF'in sys.argv:
 import current_character_composition_FF_controls_v3 as M
 M.O=B.O/'FF-composed-Main';M.O.mkdir(exist_ok=False);M.N=B.N
 # Existing runner binds a source handoff path only as read-only input. The
 # exact new ROM/DBG are independently included in its output bindings.
 source=M.O/'source-stage-handoff-v2.json'
 source.write_bytes((B.C.OLD/'source-stage-handoff-v2.json').read_bytes())
 M.main()
else:raise SystemExit('Use --arthur or --FF')
