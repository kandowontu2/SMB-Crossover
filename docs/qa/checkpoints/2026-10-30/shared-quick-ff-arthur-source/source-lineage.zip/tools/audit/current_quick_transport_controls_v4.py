"""Actual private Nr/Hu importer endpoint ABI and same-worker Quick delivery."""
from pathlib import Path
import copy,itertools,json,traceback
import prepare_current_quick_transport_v4 as B
import quickman_wram_palette_controls_v6 as C
import quickman_current_services_controls_v2 as S
from check_tmnt_render_oa import address,location
O=B.O;N=B.N;P=B.C.P
FLAGS=[n for n in range(256)if n&0x30==0x30]
FIRST=['NrMovement','NrGraphics','NrDraw','NrPortrait','NrWeapons','NrInjury','NrLegacyInjuryStatus','NrDeathStart','NrDeath','NrVisible','NrHead','NrBody','NrAdder','NrBox','NrSide']
ONLY=['GmFreshGate','GmFullBoxGate','GmMenuDrawGate','GmMenuNameGate','GmResetGate','GmPrepareGate','GmRiseGate','GmPrivateGate','GmMatureGate','GmPickupGate','GmFullPowerGate','GmColorsGate','GmStompGate','GmHeadWithinGate','GmUiGate','GmStatusGate']

def bus(path):
 old=C.O;C.O=path
 try:return C.Bus()
 finally:C.O=old

def fork(m):
 q=copy.copy(m);q.ram=bytearray(m.ram);q.tags=m.tags[:];q.banks=m.banks[:];q.chr=m.chr[:];q.wram=[bytearray(x)for x in m.wram];q.writes=[];q.cache_writes=[];q.events=[];return q

def endpoint(m,name,raw,alt,p,rd=0):
 m.set('SelectedCharacter',raw);m.set('FmAlts',alt);m.set('RdVariant',rd)
 A=raw if name in['NrAdder','NrBox']else 0x83
 m.ram[m.lab['SafecallA_SMC']+1]=A
 m.ram[m.lab['FarcallJmpTarget_SMC']+1]=m.lab[name]&255;m.ram[m.lab['FarcallJmpTarget_SMC']+2]=m.lab[name]>>8
 m.ram[0x1fe]=0xfe;m.ram[0x1ff]=0x7f
 c=C.H.N.NesMPU(memory=m,pc=m.lab['FarCallCommon']);c.a=m.bank(name)|128;c.x=0x5a;c.y=0xc7;c.p=p;c.sp=253
 hu=m.lab['HuEntryBase'];seen=0;maps=0;low=c.sp
 for i in range(2000):
  low=min(low,c.sp);m.pc=c.pc
  if c.pc in[m.lab['FarCallCommon'],m.lab['FarCallCommon']+3]:maps+=1
  if c.pc==m.lab['FarcallJmpTarget_SMC']:
   dest=m[m.lab['FarcallJmpTarget_SMC']+1]+256*m[m.lab['FarcallJmpTarget_SMC']+2]
   if seen and not hu<=dest<hu+36*16:
    return dict(dest=dest,bank=m.tags[1],regs=[c.a,c.x,c.y,c.p,c.sp],CPU=c.processorCycles,mapper_entries=maps,minimumSP=low),m,c
   seen+=1
  assert m[c.pc]!=0,('actual importer BRK',name,raw,alt,p,hex(c.pc),m.tags)
  c.step()
 raise AssertionError(('importer endpoint timeout',name,raw,alt,p,hex(c.pc),m.tags))

def same(a,b,case):
 za,ma,ca=a;zb,mb,cb=b
 # The old 3B table-only GmStatusName JMP was genuinely retired. Exactly
 # these source lookup fields now name the same existing Tail endpoint.
 metadata=set();retired=za['dest']==ma.lab.get('GmStatusName')
 if retired:
  assert ma[za['dest']]==0x4c
  za=dict(za,dest=ma[za['dest']+1]+256*ma[za['dest']+2])
  metadata={ma.lab['FarcallJmpTarget_SMC']+1,ma.lab['FarcallJmpTarget_SMC']+2}
 assert(za['dest'],za['bank'],za['regs'],za['mapper_entries'])==(zb['dest'],zb['bank'],zb['regs'],zb['mapper_entries']),('foreign endpoint/AXYP/SP/mappercount',case,za,zb)
 smc=ma.lab['NextBank_SMC'] # all other actual33SMC bytes compared below
 ignore=set(range(0x100,0x200))|set(range(0x5100,0x5140))|metadata
 for lo,hi in[(0,0x100),(0x200,0x5100),(0x5140,0x8000)]:
  if not metadata:assert ma.ram[lo:hi]==mb.ram[lo:hi],('application bytes',case,lo)
  else:assert all(ma.ram[j]==mb.ram[j]for j in range(lo,hi)if j not in metadata),('known source-metadata bytes',case,lo)
 app=lambda m:[(ad,v)for ad,v in m.writes if ad not in ignore]
 assert app(ma)==app(mb),('ordered application/SMC writes',case,app(ma),app(mb))
 assert ma.ram[:0x100]==mb.ram[:0x100]
 live=min(za['minimumSP'],zb['minimumSP']);assert ma.ram[0x100:0x100+live]==mb.ram[0x100:0x100+live],('static/livepage1',case)
 assert ma.tags==mb.tags and ma.wram==mb.wram and ma.chr==mb.chr,('rawmaps/cache/CHR',case)
 return zb['CPU']-za['CPU'],retired

def classifiers():
 templates=[bus(x)for x in[P,N]];rows=[];retired=0
 cases=list(itertools.product(range(256),FIRST+ONLY))
 for raw,name in cases:
  # One all-raw pass across every actual service ingress; every bit of P
  # additionally covers the movement/explicit-adder/Only color paths.
  flags=FLAGS if name in['NrMovement','NrAdder','GmColorsGate']else[0xf9]
  for p in flags:
   for rd in([0,1,255]if raw==2 else[0]):
    case=[raw,name,p,rd]
    pair=[endpoint(fork(t),name,raw,0,p,rd)for t in templates]
    delta,r=same(*pair,case);retired+=r;rows.append([*case,delta,pair[1][0]['mapper_entries']])
 # No other alt bit admits Quick; bit5 is isolated even with every pending
 # family bit set. Every authentic Quick service is reached by its real Nr
 # ingress with its original sourceA/P/Y restored before the true importer.
 quick=[]
 for bits in range(256):
  for index,name in enumerate(FIRST+ONLY):
   z,m,c=endpoint(fork(templates[1]),name,9,bits,0xf9)
   if bits&32:
    assert(z['dest'],z['bank'],m.get('ArenaGateBank'))==(m.lab['QwService'],m.bank('QwService')|128,index)
    assert z['regs'][:4]==[9 if name in['NrAdder','NrBox']else 0x83,0x5a,0xc7,0xf9],('Quick source ABI',bits,index,z)
   else:same(endpoint(fork(templates[0]),name,9,bits,0xf9),(z,m,c),['altbits',bits,name])
   quick.append([bits,index,z['dest'],z['mapper_entries']])
 return dict(foreign_source_endpoint_pairs=len(rows),rows=rows,exact_original_foreign_mapper_entry_count=True,foreign_CPU_delta=[min(r[4]for r in rows),max(r[4]for r in rows)],retired_status_JMP_source_metadata_pairs=retired,all256_altbit_combinations=len(quick),Quick_rows=quick)

def public_workers():
 old=C.O;C.O=N;C.CODE=(N/'code.bin').read_bytes();C.DATA=(N/'data.bin').read_bytes()
 try:
  m=C.Bus();C.invoke(m,'QwConstruct');C.exact_cache(m)
  m.set('GameEngineSubroutine',8);m.set('Player_Y_HighPos',1);m.set('Player_Y_Position',160);m.set('Player_X_Position',96)
  m.set('ObjectOffset',0);m.set('PowerUpType',0);m.set('Enemy_Flag',0)
  transport=set()
  for name,size in[('ArenaGateA',1),('ArenaGateP',1),('ArenaGatePtr',2),('ArenaGateBank',1)]:transport.update(range(m.lab[name],m.lab[name]+size))
  ignore=transport|set(range(0x100,0x200))|set(range(0x5100,0x5140))
  smc=next(s for s in m.bundle['segs'].values()if s['name']=='"SMCCODE"');at=int(smc['start'],0);sn=int(smc['size'],0);assert sn==33
  rows=[]
  for index,target in enumerate(S.ROWS):
   for p in FLAGS:
    a=S.clone(m);b=S.clone(m);a.set('ArenaGateBank',index);b.set('ArenaGateBank',index)
    ra,ca,la=S.execute(a,target,P=p);rb,cb,lb=S.execute(b,'Hu'+['Movement','Graphics','Draw','Portrait','Weapons','Injury','InjuryStatus','DeathStart','Death','Visible','Head','Body','Adder','Box','Side','Fresh','FullBox','MenuPortrait','MenuName','Reset','Prepare','Rise','Private','Mature','Pickup','FullPower','Colors','Bounce','HeadWithin','EarlyUi','Status','Stomp','WorldPalette','Powerup','WeaponTail','Vine'][index],P=p)
    assert ra==rb,('real shared/publicworker AXYP',index,p,ra,rb)
    assert a.tags==b.tags and a.chr==b.chr and a.wram==b.wram,('actual public maps/cache/CHR',index,p)
    assert not[j for j in range(0x8000)if j not in ignore and a.ram[j]!=b.ram[j]],('public application',index,p)
    assert a.ram[at:at+sn]==b.ram[at:at+sn],('actual33SMC',index,p)
    app=lambda q:[(ad,v)for ad,v in q.writes if ad not in ignore and not at<=ad<at+sn]
    assert app(a)==app(b),('public ordered writes',index,p)
    live=min(la,lb);assert a.ram[0x100:0x100+live]==b.ram[0x100:0x100+live],('public livepage1',index,p)
    rows.append([index,p,ca,cb,cb-ca,la,lb])
  return dict(real_same_worker_pairs=len(rows),all_actual_source_fields_application_orderedwrites_AXYP_SP_33SMC_maps_cache_equal=True,maximum_public_transport_CPU=max(x[4]for x in rows),rows=rows)
 finally:C.O=old

def main():
 out=O/'transport-controls.json';assert not out.exists();d=dict(passed=False,native=False,checks={})
 try:
  for name,fn in[('classifier_source_ABI',classifiers),('public_real_workers',public_workers)]:d['checks'][name]=fn();print(name,'PASS',flush=True)
  d['passed']=True
 except Exception as e:d.update(error=repr(e),traceback=traceback.format_exc())
 d['bindings']={str(p.resolve()):B.B.sha(p)for p in[Path(__file__),N/'candidate.nes',N/'candidate.dbg',Path(S.__file__),Path(C.__file__)]}
 out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(passed=d['passed'],error=d.get('error'))));assert d['passed'],d.get('error')
if __name__=='__main__':main()
