"""Resume new-tree compiled Main after retained include-path failure."""
import build_current_character_composition_v1 as B
if __name__=='__main__':
 B.resolve=lambda:None;B.config=lambda:None
 original=B.run
 B.run=lambda cmd,name:None if name=='compile-main'else original(cmd,name)
 B.build()
