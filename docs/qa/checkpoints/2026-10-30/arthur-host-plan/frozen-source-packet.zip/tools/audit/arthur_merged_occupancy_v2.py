"""Merge every frozen requested-character host component and future leases.

This is an ownership audit, never an allocator. Old snapshots are conservative:
an occupied byte remains occupied even when a newer private fork relocates it.
"""
from pathlib import Path
import hashlib,importlib.util,json,re
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'build/arthur-host-plan-v2'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('prior_capacity',ROOT/'tools/audit/arthur_host_capacity_v1.py')
prior=importlib.util.module_from_spec(spec);spec.loader.exec_module(prior)
CASES=[
 ('shared32slot80profiles','build/full-roster-menu-v5/candidate.nes'),
 ('frozen4hostunion','build/character-host-union-v2/candidate.nes'),
 ('inprogress4hostunion_conservative','build/character-host-union-v4/candidate.nes'),
 ('Rogueflagpole','build/rogue-dawn-flagpole-v1/candidate.nes'),
 ('SMB2realNMIaudioRogueunion','build/smb2-roster-real-nmi-v9/candidate.nes'),
 ('Gokureview','build/goku-admission-review-v2/candidate/candidate.nes'),
 ('GimmickNMImenu','build/gimmick-nmi-menu-v1/candidate.nes'),
 ('DKreview','build/dk-admission-review-v2/candidate.nes'),
 ('SuperMaaa','build/supermaaa-host-v1/candidate.nes')]
PACKETS=[
 'build/final-fantasy-component-v1/handoff.json','build/smb2-roster-real-nmi-v9/build-proof.json',
 'docs/qa/checkpoints/2026-10-28/smb2-allocation/root-review-and-reservations.json',
 'build/smb2-roll-relocation-v1/handoff.json','build/goku-admission-review-v2/handoff.json',
 'build/gimmick-nmi-menu-v1/handoff.json','build/gimmick-component-v2/lease-proof.json',
 'build/gimmick-admission-v3/host-lease.json','build/dk-admission-review-v2/handoff.json',
 'build/supermaaa-host-v1/handoff.json','build/rogue-dawn-flagpole-v1/handoff.json',
 'build/character-host-union-v2/lease.json','build/character-host-union-v4/lease.json',
 'build/smb3-bowser-source-assets-v1/handoff.json','build/wwf-roster-source-review-v1/handoff.json',
 'build/quickman-source-v1/handoff.json','build/arthur-source-v1/handoff.json']
def main():
    OUT.mkdir(parents=True,exist_ok=True);mask=bytearray(128*8192);chr_mask=bytearray(1024);records=[];bindings={}
    for owner,rel in CASES:
        path=ROOT/rel;dbg=path.with_suffix('.dbg');bindings[str(path.resolve())]=sha(path);bindings[str(dbg.resolve())]=sha(dbg)
        assert path.stat().st_size==2097168
        for line in dbg.read_text().splitlines():
            if not line.startswith('seg\t')or'ooffs='not in line:continue
            d={k:v.strip('"')for x in re.split(r',(?=\w+=)',line.split('\t',1)[1])for k,_,v in[x.partition('=')]}
            at=int(d['ooffs'],0)-16;size=int(d['size'],0)
            if size<=0 or at<0:continue
            end=at+size
            if at<len(mask):
                end=min(end,len(mask));mask[at:end]=b'\1'*(end-at)
                records.append(dict(owner=owner,kind='linked_PRG',segment=d['name'],physical_start=at,bytes=end-at,
                    physical_bank=at//8192,bank_offset=at%8192,CPU_start=d['start'],candidate=str(path.resolve())))
            else:
                a=(at-len(mask))//1024;b=(end-len(mask)+1023)//1024
                assert 0<=a<=b<=1024
                chr_mask[a:b]=b'\1'*(b-a)
                records.append(dict(owner=owner,kind='linked_CHR',segment=d['name'],first_page=a,end_page_exclusive=b,bytes=size,candidate=str(path.resolve())))
    reservations=list(prior.RESERVED)
    # Full approved payload budgets are retained, including unused bytes.
    # FF source uses a stand-alone multi-file linker: its component DBG file
    # offsets are NOT physical cartridge offsets; map by its explicit bank/view.
    reservations += [(125,0,0x2000,'Complete final127/current125 resident clone; no post-link tail mining'),
       (62,0xa00,0x1690,'FF nativeCORE3211B + alignment to existing Km boundary'),
       (93,0x1000,0x2000,'FF ART C:D000..DFFF full4KiB source assertion budget'),
       (85,0x900,0x1900,'Goku ART C900..D8FF full4KiB approved budget'),
       (86,0x800,0x2000,'Goku CORE A800..BFFF native host budget'),
       (66,0x1680,0x19a8,'SuperMaaa CORE B680..B9A7'),(68,0x1b20,0x1f20,'SuperMaaa ART DB20..DF1F'),
       (24,0xe80,0x1c00,'Gimmick CORE AE80..BBFF'),(24,0x1d40,0x2000,'Gimmick host BD40..BFFF'),
       (122,0x1740,0x2000,'Gimmick movement B740..BFFF'),(75,0x19c0,0x2000,'Gimmick cold and host B9C0..BFFF'),
       (73,0x1920,0x2000,'Gimmick art D920..DFFF'),
       (36,0x19fd,0x1fc0,'DK originalCORE B9FD..BFBF'),(12,0x1b13,0x2000,'DK sourceART DB13..DFFF'),
       (65,0x1c00,0x2000,'DK world/lifecycle host BC00..BFFF')]
    for b,a,e,name in reservations:
        assert 0<=b<128 and 0<=a<e<=8192
        at=b*8192+a;mask[at:b*8192+e]=b'\1'*(e-a)
        records.append(dict(owner=name,kind='explicit_reserved_PRG',physical_bank=b,bank_offset=a,bytes=e-a,physical_start=at))
    # Full named expanded-CHR owner leases, independent of incbin length.
    chr_reservations=[(256,276,'Proto'),(276,308,'Darkwing/Roll'),(308,340,'ZeldaII/Roll'),(340,380,'Kirby/Roll'),
       (380,412,'Vic'),(412,460,'ChipDale'),(460,524,'CV3'),(524,604,'SMB3'),(604,668,'TMNT'),
       (668,680,'Mac/RiverCity'),(680,696,'Rogue'),(696,700,'Kamikaze'),(700,704,'menu previews'),
       (704,708,'MacTail'),(708,712,'Mike'),(712,716,'Ice'),(716,724,'RiverCity'),(724,740,'Sunny'),
       (740,756,'Celeste'),(756,788,'FF'),(788,796,'Goku'),(796,808,'SMB2'),(808,813,'GBPit'),
       (813,816,'Maaa'),(816,820,'Gimmick'),(820,824,'DK'),(824,828,'SMB3Bowser'),(828,832,'futureSMB1Bowser'),(832,1024,'fullParodius')]
    for a,b,n in chr_reservations:chr_mask[a:b]=b'\1'*(b-a)
    # Actual standalone FF bytes must agree with their published sparse image.
    ff=ROOT/'build/final-fantasy-component-v1';raw=(ff/'candidate.nes').read_bytes()
    ffchecks=[]
    for name,bank,offset,file in[('CORE',62,0xa00,'component.bin'),('ART',93,0x1000,'art.bin')]:
        data=(ff/file).read_bytes();assert raw[16+bank*8192+offset:16+bank*8192+offset+len(data)]==data
        ffchecks.append(dict(kind=name,physical_bank=bank,bank_offset=offset,bytes=len(data),sha256=sha(ff/file)))
        bindings[str((ff/file).resolve())]=sha(ff/file)
    bindings[str((ff/'candidate.nes').resolve())]=sha(ff/'candidate.nes')
    gaps=[]
    for bank in range(128):
        i=0;data=mask[bank*8192:(bank+1)*8192]
        while i<8192:
            if data[i]:i+=1;continue
            j=i+1
            while j<8192 and not data[j]:j+=1
            if j-i>=128:
                candidates=[]
                for owner,rel in CASES:
                    path=ROOT/rel;chunk=path.read_bytes()[16+bank*8192+i:16+bank*8192+j]
                    candidates.append(dict(owner=owner,all_FF=all(n==255 for n in chunk),sha256=hashlib.sha256(chunk).hexdigest()))
                gaps.append(dict(bank=bank,offset_start=i,offset_end_exclusive=j,bytes=j-i,
                   A_start=f'{0xa000+i:04X}',C_start=f'{0xc000+i:04X}',all_inputs_FF=all(q['all_FF']for q in candidates),preimages=candidates,
                   status='MERGED_GAP_ONLY_REQUIRES_CONSUMER_CLOSURE_AND_PARENT_GRANT'))
            i=j
    chr_gaps=[];i=0
    while i<1024:
        if chr_mask[i]:i+=1;continue
        j=i+1
        while j<1024 and not chr_mask[j]:j+=1
        chr_gaps.append(dict(first_page=i,end_page_exclusive=j,pages=j-i));i=j
    for rel in PACKETS+['docs/qa/final-fantasy-component-source-2026-10-28.txt','docs/qa/smb2-roster-allocation-2026-10-28.txt',
       'src/final_fantasy_art.inc','src/dragon_power_art.inc','build/supermaaa-host-v1/component.s','build/final-fantasy-component-v1/component.cfg']:
        p=ROOT/rel;bindings[str(p.resolve())]=sha(p)
    bindings[str(Path(__file__).resolve())]=sha(__file__)
    (OUT/'PRG-occupied.bin').write_bytes(mask);(OUT/'CHR-occupied-pages.bin').write_bytes(chr_mask)
    result=dict(status='MERGED_PHYSICAL_OWNERSHIP_MAP_NO_ARTHUR_ALLOCATION',
       cases=[dict(owner=n,path=str((ROOT/p).resolve()),sha256=sha(ROOT/p))for n,p in CASES],
       packet_inventory=PACKETS,FF_standalone_payload_matches_sparse_candidate=ffchecks,
       ownership_records=records,explicit_PRG_reservations=[dict(bank=b,offset_start=a,offset_end_exclusive=e,owner=n)for b,a,e,n in reservations],
       full_CHR_owner_reservations=[dict(first_page=a,end_page_exclusive=b,owner=n)for a,b,n in chr_reservations],
       remaining_PRG_gaps=sorted(gaps,key=lambda q:q['bytes'],reverse=True),remaining_CHR_gaps=chr_gaps,
       no_host_leases=[dict(owner=n,status='Original source/art/abstract leaf only; no host PRG/CHR/RAM allocated')for n in('WWF','QuickMan','Arthur','SMB1Bowser','other visible pending alternates')],
       superseded_requests='Both118/117 and62/93 Arthur requests withdrawn. All emitted/future component ownership above takes precedence over earlier gap-only reports.',
       binary_masks=dict(PRG_sha256=sha(OUT/'PRG-occupied.bin'),CHR_page_sha256=sha(OUT/'CHR-occupied-pages.bin')),
       bindings=bindings,limits='Conservative union of private forks and full named budgets; not a coherent combined ROM or proof that conflicting forks compose. Current reservations can coexist only after their owning source union work. No newly discovered gap is allocated.')
    p=OUT/'merged-occupancy.json';p.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(dict(report_sha256=sha(p),cases=len(CASES),ownership_records=len(records),
       top_gaps=[{k:v for k,v in q.items()if k!='preimages'}for q in result['remaining_PRG_gaps'][:10]],CHR_gaps=chr_gaps)))
if __name__=='__main__':main()
