"""Compiled publisher/reference and ownership evidence; allocates nothing."""
from pathlib import Path
import hashlib,json,re
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'build/arthur-host-plan-v1'
CASES=[ROOT/'build/full-roster-menu-v5/candidate.nes',ROOT/'build/character-host-union-v2/candidate.nes',ROOT/'build/rogue-dawn-flagpole-v1/candidate.nes']
EXTRA=ROOT/'build/smb2-roster-component-v1/component.dbg'
LEDGER=ROOT/'docs/qa/checkpoints/2026-10-28/smb2-allocation/root-review-and-reservations.json'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def parse(path):
    out={k:{}for k in('file','line','seg','sym')}
    for l in path.read_text().splitlines():
        typ,_,rest=l.partition('\t')
        if typ not in out:continue
        d={k:v.strip('"')for part in re.split(r',(?=\w+=)',rest)for k,_,v in[part.partition('=')]}
        out[typ][int(d['id'])]=d
    return out
def offset(d,sym):
    s=d['seg'][int(sym['seg'])];return int(s['ooffs'],0)+int(sym['val'],0)-int(s['start'],0)
def main():
    allfiles=set();reports=[];references=[];symbols=[]
    names={'X5SetPhysicalChr','X5SetSpecialChr','X5ChrMode','X5SpecialChrUpper','X5HudChrUpper','SsChrPhysical','InvHudPhysical','CurrentCHRBank'}
    tables={'ChrPhysicalMap':256,'SsPhysicalBanks':17,'SmWeaponPhysicalBanks':2,'AvPhysicalBanks':17,'InvHudPhysicalBanks':8}
    for path in CASES:
        d=parse(path.with_suffix('.dbg'));raw=path.read_bytes();byname={s['name']:s for s in d['sym'].values()if'val'in s and'seg'in s}
        chrstart=16+128*8192;pad=raw[chrstart+247*1024:chrstart+256*1024]
        physical={}
        for name,count in tables.items():
            at=offset(d,byname[name]);data=list(raw[at:at+count]);assert len(data)==count
            used=sorted(set(data if name in('ChrPhysicalMap','InvHudPhysicalBanks')else data+[n+1 for n in data]))
            assert max(used)<247,(path,name,used)
            physical[name]=dict(values=data,physical_pages_reached=used,max_page=max(used),table_file_offset=at)
        chrseg=[s for s in d['seg'].values()if s['name']=='CHR'][0]
        assert int(chrseg['size'],0)==247*1024 and not any(pad)
        reports.append(dict(candidate=str(path.resolve()),sha256=sha(path),compiled_packed_prefix_bytes=int(chrseg['size'],0),
            unused247_255_bytes=len(pad),unused247_255_all_zero=not any(pad),unused247_255_sha256=hashlib.sha256(pad).hexdigest(),legacy_physical_publishers=physical))
        for s in d['sym'].values():
            if s.get('name')not in names:continue
            for lid in s.get('ref','').split('+'):
                if not lid:continue
                line=d['line'][int(lid)];f=Path(d['file'][int(line['file'])]['name'])
                if not f.is_absolute():f=ROOT/f
                if not f.is_file():continue
                allfiles.add(f.resolve());n=int(line['line']);lines=f.read_text(errors='replace').splitlines()
                references.append(dict(candidate=str(path.resolve()),symbol=s['name'],file=str(f.resolve()),line=n,
                    text=lines[n-1]if n<=len(lines)else'',context=lines[max(0,n-5):min(len(lines),n+3)]))
        for f in d['file'].values():
            p=Path(f['name']);p=p if p.is_absolute()else ROOT/p
            if p.is_file()and p.suffix in('.s','.inc'):allfiles.add(p.resolve())
        for s in d['sym'].values():
            if'val'in s and 0x5f80<=int(s['val'],0)<0x5fa0:
                symbols.append(dict(candidate=str(path.resolve()),name=s['name'],value=int(s['val'],0),size=s.get('size')))
    # Actual future source component and its authoritative reservation also
    # participate: it is not currently in all three linked images.
    extra=parse(EXTRA)
    for f in extra['file'].values():
        p=Path(f['name']);p=p if p.is_absolute()else ROOT/p
        if p.is_file()and p.suffix in('.s','.inc'):allfiles.add(p.resolve())
    for s in extra['sym'].values():
        if'val'in s and 0x5f80<=int(s['val'],0)<0x5fa0:symbols.append(dict(candidate=str(EXTRA.resolve()),name=s['name'],value=int(s['val'],0),size=s.get('size')))
    # Every numeric potential physical247..255 reference is retained for human
    # provenance review. Numeric hits alone include ordinary tile IDs/masks.
    numeric=[]
    pat=re.compile(r'(?<![\w$])(?:247|248|249|250|251|252|253|254|255)(?!\w)|\$[fF][7-9a-fA-F](?![0-9a-fA-F])')
    for p in sorted(allfiles):
        for i,l in enumerate(p.read_text(errors='replace').splitlines(),1):
            if pat.search(l)and re.search(r'CHR|Chr|chr|Physical|physical|\$51[23]|[Bb]ank',l):numeric.append(dict(file=str(p),line=i,text=l))
    # De-duplicate compiled references to reduce macro/alias repetition.
    unique={tuple(r[k]for k in('candidate','symbol','file','line')):r for r in references}
    result=dict(status='READ_ONLY_COMPILED_RESOURCE_EVIDENCE_NO_LEASE',CHR_candidate247_255=reports,
       actual_compiled_publisher_reference_sites=list(unique.values()),numeric247_255_CHR_context_candidates=numeric,
       persistent_candidate=dict(start='5F90',end_exclusive='5F98',existing_nearby_symbols=symbols,
          temporal_owner='Explicit selected-Arthur-only overlay of Parodius history. Not globally unused.',
          original_reach='PnHistory5F40..5FBF: native Pn8385/Pn838B ring64*XY and Pn83A9 odd-byte sweep. PnEnsure clears5F00..5FDF.',
          admission_requirements=['Every Arthur access must be gated selectedraw32 before touching state.',
            'Real selection/newgame must initialize8B before Ready can be read; life/area transitions explicitly restore earned inventory.',
            'Parodius calls must remain selected-owner gated; no late renderer/audio may call PnEnsure during Arthur.',
            'Two-player save/restore policy must be inherited explicitly; no unsaved persistence claim.']),
       reviewed_interpretation=dict(legacy='All256logical map choices≤246; explicit native2KiB special tables≤235 and HUD≤243.',
          expanded='Direct publishers use X5ChrMode bit7 and upper2; inspect compiled reference ledger, not low8 page byte alone. All existing expanded families begin≥256.',
          reservation='Authoritative SMB2 pages796..807 excluded. Existing ledger and historical report call247/256used with9KiB headroom; no reviewed247..255 owner found.',
          next_step='Parent reviews direct-producer reference ledger and grants exact pages before any host link.'),
       bindings={str(p.resolve()):sha(p)for p in sorted(allfiles|set(CASES)|{p.with_suffix('.dbg')for p in CASES}|{EXTRA,LEDGER,Path(__file__),ROOT/'build/chr-packing.json',ROOT/'tools/reference/pack_chr.py',ROOT/'docs/qa/alternate-roster-proposal-2026-10-22.md'})},
       limits='Evidence of exact linked map/table and source closure, not a runtime proof of every dynamic publisher or permission to allocate. No host ROM/source edited.')
    p=OUT/'resource-audit.json';p.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(dict(report_sha256=sha(p),source_files=len(allfiles),compiled_reference_sites=len(unique),numeric_CHR_hits=len(numeric),
       legacy_maxes={k:v['max_page']for k,v in reports[0]['legacy_physical_publishers'].items()},all3padding_zero=True)))
if __name__=='__main__':main()
