"""Private contiguous source kernel prototype; no game/header/lease mutation."""
from pathlib import Path
import hashlib,json,re,subprocess,sys
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(Path(__file__).parent))
from check_tmnt_render_oa import load,address,location
P=R/'build/quickman-host-cpu-v4';O=R/'build/quickman-wram-prep-v1'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(v,newline='\n')
def main():
    O.mkdir(exist_ok=True)
    assert sha(P/'handoff.json')=='91239729bdd6bcf95684d022dded525f19eab9f2c668f857c090fbc1a1dfad59'
    B=load(P/'candidate.nes');s=(P/'source/quick/core.s').read_text()
    s=s.replace('.include "qh_imports.inc"','.include "host-imports.inc"')
    # Keep the native kernel, its true tables and all conservative state.
    # Shared held-A mapper/world/audio/effect services remain actual imports.
    a=s.index('ArenaCallC:\n');z=s.index('G_LOW_ArenaGetFrameBody:\n',a)
    external=['ArenaCallC','QuickManWorldProbe','QuickManSound','QuickManScrollStrip','QuickManProjectileContact','QuickManEffectSpawn','QuickManDeath','QuickManYield']
    s=s[:a]+s[z:]
    # Render-phase host glue is outside this first kernel-only prototype.
    a=s.index('.import ArenaRenderCore\n');z=s.index('.segment "R1_TABLE"',a)
    s=s[:a]+s[z:]
    gates=[]
    pattern=r'(?m)^(G_[A-Za-z_0-9]+):\nsta ArenaGateA\nphp\nlda #<([A-Za-z_0-9]+)\nsta ArenaGatePtr\nlda #>\2\nsta ArenaGatePtr\+1\nlda #[^\n]+\njmp ArenaCallC\n'
    for m in re.finditer(pattern,s):gates.append((m[1],m[2]))
    s=re.sub(pattern,'',s)
    assert len(gates)>60,len(gates)
    mapper_gates=len(gates)
    thunks=re.findall(r'(?m)^(G_[A-Za-z_0-9]+): jmp ([A-Za-z_0-9]+)\n',s)
    s=re.sub(r'(?m)^G_[A-Za-z_0-9]+: jmp [A-Za-z_0-9]+\n','',s)
    gates+=thunks
    long={'bcc':'jcc','bcs':'jcs','beq':'jeq','bne':'jne','bmi':'jmi','bpl':'jpl','bvc':'jvc','bvs':'jvs'}
    for gate,target in gates:
        assert re.search(r'\b'+gate+r'\b',s),gate
        s=re.sub(r'(?im)^('+'|'.join(long)+r') '+re.escape(gate)+r'$',lambda m:long[m[1].lower()]+' '+gate,s)
        s=re.sub(r'\b'+gate+r'\b',target,s)
        assert not re.search(r'\b'+gate+r'\b',s)
    # Cold init is now in the same RAM C view. Keep every initializer byte.
    a=s.index('QuickManInit:\n');z=s.index('QuickManTick:\n',a)
    s=s[:a]+'QuickManInit: jmp QhNativeInit\n'+s[z:]
    # Every former cross-routine branch may now span more than128 bytes.
    # ca65's long form retains the original condition/A/P before a near JMP.
    s=re.sub(r'\.segment "(?:QM_COORD|R\d+|R1_TABLE|QH_INIT)"','.segment "QM_WRAM_KERNEL"',s)
    assert not re.search(r'(?m)^G_[A-Za-z_0-9]+:',s)
    s=s.replace('.export ArenaCallC,','.export ')
    assert '.bank('not in s,'No ROM-tag expression belongs in contiguous RAM source'
    # Frozen actual source symbols, not fabricated target addresses or aliases.
    imports=(P/'source/quick/qh_imports.inc').read_text().splitlines()
    existing={re.sub(r'^\.import(?:zp)?\s+','',line).strip()for line in imports}
    for n in external+['QhBonkFlag']:
        if n not in existing:imports.append('.import '+n);existing.add(n)
    put(O/'host-imports.inc','\n'.join(imports)+'\n')
    defs=[]
    for line in imports:
        m=re.fullmatch(r'\.import(zp)?\s+(\w+)',line);assert m,line
        zp,n=m.groups();v=address(B,n)
        defs+=['.export'+('zp 'if zp else' ')+n,f'{n}=${v:04x}']
    put(O/'host-definitions.s','; Actual immutable host DBG symbol binding. No ROM patch.\n'+'\n'.join(defs)+'\n')
    put(O/'kernel.s',s)
    cfg=(P/'quick.cfg').read_text();memory='\n'.join(line for line in cfg.splitlines()if re.match(r'N\d+:',line))
    state='\n'.join(line for line in cfg.splitlines()if line.startswith('QM_')and'load=N'in line)
    cfg='MEMORY {\n'+memory+'\nRAM1_KERNEL:start=$c000,size=$2000,type=ro,file=%O,fill=yes,fillval=$ff,bank=$01;\n}\nSEGMENTS {\n'+state+'\nQM_WRAM_KERNEL:load=RAM1_KERNEL,type=ro;\n}\n'
    put(O/'kernel.cfg',cfg)
    ca=R/'tools/Windows/cc65/bin/ca65.exe';ld=ca.with_name('ld65.exe');commands=[]
    for n in ['kernel','host-definitions']:commands.append([str(ca),'-g','-I',str(O),str(O/(n+'.s')),'-o',str(O/(n+'.o'))])
    commands.append([str(ld),'-C',str(O/'kernel.cfg'),'-o',str(O/'kernel.bin'),'--dbgfile',str(O/'kernel.dbg'),'-Ln',str(O/'kernel.lbl'),'-m',str(O/'kernel.map'),str(O/'kernel.o'),str(O/'host-definitions.o')])
    logs=[]
    for cmd in commands:
        cp=subprocess.run(cmd,capture_output=True,text=True);logs.append(dict(command=cmd,returncode=cp.returncode,stdout=cp.stdout,stderr=cp.stderr))
        put(O/'build-log.json',json.dumps(logs,indent=2)+'\n');assert cp.returncode==0,cp.stderr[:8000]
    labels={n:int(v,16)for v,n in re.findall(r'al ([0-9A-Fa-f]+) \.(\w+)',(O/'kernel.lbl').read_text())}
    for n in existing:assert labels[n]==address(B,n),(n,labels[n],address(B,n))
    data=(O/'kernel.bin').read_bytes();assert len(data)==8192
    actual=int(re.search(r'QM_WRAM_KERNEL\s+([0-9A-F]+)\s+([0-9A-F]+)\s+([0-9A-F]+)',(O/'kernel.map').read_text())[3],16)
    proof=dict(status='ASSEMBLED_PRIVATE_CONTIGUOUS_WRAM_KERNEL_PROTOTYPE',native=False,shared_header_changed=False,physical_storage_lease=False,host_ROM_sha256=sha(P/'candidate.nes'),host_handoff_sha256=sha(P/'handoff.json'),kernel_sha256=sha(O/'kernel.bin'),kernel_used_bytes=actual,kernel_arena_bytes=8192,remaining_bytes=8192-actual,RAM_tag=1,CPU_window='C000..DFFF',removed_mapper_gates=mapper_gates,removed_near_thunks=len(thunks),removed_gate_bytes=mapper_gates*19+len(thunks)*3,all35_native_routines_retained=True,all535_source_fields_and_direct_work_addresses_retained=True,all_source_calls_now_near=True,remaining_imports=external+['QhBonkFlag'],host_glue_and_art='Frozen v4, outside this kernel-only prototype; no readiness or savings grant.',source_call_rewrites=[dict(removed_gate=g,near_target=t)for g,t in gates],bindings={str(p):sha(p)for p in [Path(__file__),P/'handoff.json',P/'source/quick/core.s',R/'tools/audit/prepare_mmc5_overlay_lab_v1.py',R/'build/mmc5-overlay-lab-v1/ready.json',R/'build/mmc5-overlay-lab-v1/native/result.json',O/'kernel.s',O/'kernel.cfg',O/'host-imports.inc',O/'host-definitions.s',O/'kernel.dbg',O/'kernel.lbl']})
    put(O/'prepared.json',json.dumps(proof,indent=2)+'\n');print(json.dumps({k:v for k,v in proof.items()if k not in ['source_call_rewrites','bindings']},indent=2))
if __name__=='__main__':main()
