"""Freeze the two-bank Quick CPU prototype; no cartridge or loader adoption."""
from pathlib import Path
import hashlib,json,re,shutil,subprocess,sys,zipfile

R=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(Path(__file__).parent))
from check_tmnt_render_oa import load,address
W=R/'build/quickman-wram-whole-v2'
K=R/'build/quickman-wram-prep-v1'
P=R/'build/quickman-host-cpu-v4'
O=R/'build/quickman-wram-whole-cpu-v3'

def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n',newline='\n')
def labels(p):return {n:int(v,16)for v,n in re.findall(r'al ([0-9A-Fa-f]+) \.(\w+)',p.read_text())}

def main():
    assert not O.exists(),'Frozen successor already exists'
    assert sha(P/'handoff.json')=='91239729bdd6bcf95684d022dded525f19eab9f2c668f857c090fbc1a1dfad59'
    assert sha(W/'code.bin')=='14f468a2363634cf9ec7b17d6fdb6e4b40cc81a491695581b4c35f58c2bd9f02'
    assert sha(W/'data.bin')=='6b82a695049cb91f54067d0bec9fca6de85b4116005e83f0b8c6135bfd6ab435'
    prep=json.loads((W/'prepared.json').read_text());lab=labels(W/'whole.lbl');prior=load(P/'candidate.nes')
    code=(W/'code.bin').read_bytes();data=(W/'data.bin').read_bytes();source=(W/'whole.s').read_text()
    assert len(code)==len(data)==8192
    assert code[6491:]==b'\xff'*1701 and data[1921:]==b'\xff'*6271
    assert prep['sizes']==dict(QW_CODE=6491,QW_DATA=1921)
    assert not re.search(r'(?m)^G_[A-Za-z_0-9]+:',source)
    fieldnames=[n for n in lab if n.startswith('QmField_')]
    assert len(fieldnames)==535
    for n in fieldnames:assert lab[n]==address(prior,n),(n,lab[n],address(prior,n))
    native_labels=re.findall(r'(?m)^(CX_[A-F0-9_]+):',(P/'source/quick/core.s').read_text())
    assert len(native_labels)==len(set(native_labels))
    for n in native_labels:assert n in lab and 0xa000<=lab[n]<0xb95b,n
    # Bind every original DX declaration, including relocated dispatch pointers.
    # Constants must retain bytes; source pointers must encode their real linked PC.
    table_re=r'(?m)^(DX_\w+): \.byte([^\n]*)$'
    oldtables=dict(re.findall(table_re,(K/'kernel.s').read_text()))
    tables=dict(re.findall(table_re,source));assert tables==oldtables
    assert len(tables)==1166
    rows=[]
    for n,expr in tables.items():
        expr=expr.strip();assert ','not in expr,expr
        if expr.startswith('$'):expected=int(expr[1:],16)
        elif expr[:1]in ['<','>']:
            expected=(lab[expr[1:]]>>(8 if expr[0]=='>'else 0))&255
        else:expected=int(expr,0)
        at=lab[n]-0xc000;assert 0<=at<1921 and data[at]==expected,(n,expr,at)
        rows.append(dict(label=n,address=lab[n],source_expression=expr,actual_byte=data[at]))
    checks=['source-controls.json','flags-controls.json','render-controls.json','public-controls.json','real-isr-controls.json']
    for n in checks:
        d=json.loads((W/n).read_text())
        assert d.get('passed',True),n
        assert d['code_sha256']==sha(W/'code.bin')and d['data_sha256']==sha(W/'data.bin'),n
    O.mkdir()
    for n in ['whole.s','whole.cfg','whole.lbl','whole.dbg','whole.map','host-definitions.s','code.bin','data.bin','art.chr','prepared.json','build-log.json',*checks]:shutil.copy2(W/n,O/n)
    shutil.copytree(W/'bench',O/'bench')
    put(O/'source-projection-proof.json',dict(passed=True,all535_source_aliases_exact=True,source_instruction_labels_retained=len(native_labels),source_instruction_labels=native_labels,DX_declarations_moved_unchanged=1166,DX_linked_bytes_and_relocated_source_pointers_exact=True,table_bytes=rows,all35_native_routines_retained=True,removed_mapper_gates=69,removed_near_thunks=6,removed_gate_bytes=1329))
    # Compile a fresh source closure in a new directory, preserving original files.
    repro=O/'reproduction';(repro/'inc').mkdir(parents=True)
    shutil.copy2(R/'build/quickman-host-integrate-v3/frozen-inputs/inc/charmap.inc',repro/'inc/charmap.inc')
    shutil.copy2(P/'source/quick/metasprites3.bin',repro/'metasprites3.bin')
    shutil.copy2(W/'art.chr',repro/'source-art.chr')
    s=source
    paths=re.findall(r'\.incbin "([^"]+)"',s);assert len(paths)==2,paths
    for before,after in zip(paths,['metasprites3.bin','source-art.chr']):s=s.replace('"'+before+'"','"'+(repro/after).as_posix()+'"')
    (repro/'whole.s').write_text(s,newline='\n');shutil.copy2(W/'host-definitions.s',repro/'host-definitions.s')
    cfg=(W/'whole.cfg').read_text()
    for n in ['code.bin','data.bin','art.chr']:cfg=cfg.replace((W/n).as_posix(),(repro/n).as_posix())
    (repro/'whole.cfg').write_text(cfg,newline='\n')
    ca=R/'tools/Windows/cc65/bin/ca65.exe';ld=ca.with_name('ld65.exe')
    commands=[[str(ca),'-g','-I',str(repro),str(repro/(n+'.s')),'-o',str(repro/(n+'.o'))]for n in ['whole','host-definitions']]
    commands.append([str(ld),'-C',str(repro/'whole.cfg'),'--dbgfile',str(repro/'whole.dbg'),'-Ln',str(repro/'whole.lbl'),'-m',str(repro/'whole.map'),str(repro/'whole.o'),str(repro/'host-definitions.o')])
    for cmd in commands:
        cp=subprocess.run(cmd,capture_output=True,text=True);assert cp.returncode==0,cp.stderr
    for n in ['code.bin','data.bin','art.chr']:assert(repro/n).read_bytes()==(W/n).read_bytes(),n
    put(O/'reproduction.json',dict(passed=True,fresh_source_assembly=True,all_code_data_art_bytes_exact=True,commands=commands,bindings={str(p):sha(p)for p in [ca,ld,*[repro/n for n in ['whole.s','whole.cfg','host-definitions.s','inc/charmap.inc','metasprites3.bin','source-art.chr']]]}))
    # This is an interface/ownership proposal, not a root resource grant.
    routes=json.loads((P/'quick-route-table.json').read_text())['targets']
    for row in routes:
        row['RAM_component_target']=row['target']in lab and(row['target'].startswith(('Qh','QuickMan')))
        if row['RAM_component_target']:row['RAM_PC']=lab[row['target']]
    put(O/'api-and-ownership.json',dict(status='PRIVATE_PROPOSED_ABI_NOT_ADOPTED',code=dict(raw_tag=1,window=[0xa000,0xc000],used=6491,read_only_during_active_gameplay=True),data=dict(raw_tag=2,window=[0xc000,0xe000],used=1921,read_only_during_active_gameplay=True),entry=dict(service='actual parent FarCallCommon',A_raw_bank_tag=1,dispatcher=lab['QhDispatch'],target_pointer='ArenaGatePtr',input_A='actual SafecallA_SMC operand',flags='caller P retained through dispatcher',outputs='source target A/P; X/Y volatile by public hook contract',restores=['raw A hardware/shadow via genuine FarCallCommon','raw C hardware/shadow via QhDispatch','R0/R1 via QhDispatch','R6/R7 locally by world/contact workers']),existing_state=dict(transient_bytes=557,excluded_globals=[0x5cc3,0x5dcc,0x5dcd],persistent=[0x5f88,0x5f90],persistent_player_record_bytes=4,new_ZP=0),world='Actual fixed126 GetBlockBufferAddr reads live host rolling block buffer. SourceX=SMBtopLeftX+8; SourceY=SMBtopLeftY+20. PlayerCtrl retains scroll ownership.',source_audio='Frozen generic host Square1 effect20; original CX driver/theme remains open.',IRQ_NMI='Existing actual host vectors only. No Quick tick/render runs in ISR. Mapper hardware and shadow writes remain separate interruptible instructions;600 executed seam interruptions qualify current CPU fixture, including pending write seams.',temporal_ownership=['Root owns bank assignment and header/storage grants; no RAM1/2 lease is claimed by this packet.','A retired owner must invalidate readiness before any bank1/2 overwrite. Never replace C2 while any Quick foreground target or callback is live.','Cold activation must load+verify complete code1/data2 before publishing Quick ready; no call may enter incomplete or foreign cache.','Keep RAM0 and all global/live host state intact. Reconstruct all557 selected Quick transient bytes after life/area change, preserving each approved4-byte player record.','Shared Arthur temporal C2 cache is compatible only with an explicit family transition barrier, separate owner/version checks, and real renderer/ISR liveness closure.','No global write-protection change may block live RAM0 writes. Loader must restore actual5102/5103 settings; these registers protect all WRAM banks.'],loader_still_required=['Physical CHR storage lease for seven code pages plus two data pages (9216B, or exact8412B stream), separate from five art pages251..255.','Actual source-owned cold/area loader, checked source/destination lengths and verify-before-ready.','Actual PPU buffered-read copy with renderer/NMI/IRQ, all affected CHR latches5130/512x, PPU scroll/control, raw mapper shadows/hardware and write protection restored.','Actual HuCommon rawRAM1 importer and source linker export rebinding; current checks explicitly enter the component through a CPU preload fixture.'],routes=routes))
    (O/'README.txt').write_text('''Frozen private Quick Man whole-component WRAM CPU prototype. It is not a playable cartridge or admission.

The actual assembled source component uses6491B at A000..<B95B in rawRAM bank1 and1921B at C000..<C781 in rawRAM bank2. The latter contains1166 source DX declarations and755B render arrays/metadata. All35 native source routines,535 conservative fields, full movement/contact/A-edge loop, wall abilities, three-shot fan,30 authenticated poses and four shot frames remain. Sixty-nine19B mapper gates and six3B thunks are replaced by real near calls/branches; source instruction labels and every linked DX byte/pointer are checked. State aliases are identical to the frozen actual-host CPU candidate. No fragmented PRG lease is released by this prototype.

Evidence:1520 source-controller updates with all535 fields and ordered terrain queries equal;14 semantic controls;512 source register/flag comparisons;300 exact OAM cases plus cold portrait;20 fully poisoned alternating-player lifecycle reset cases plus pickup/palette/injury/death;600 real normal/lag NMI and IRQ interruptions across motion/render/shared SMC/real CHR publisher seams. Fresh source assembly reproduces all16384 padded code/data bytes and5120 art bytes exactly. Source tick maximum13053CPU versus frozen fragmented18003CPU; this is not fullMain or video-frame cadence evidence.

Entry uses actual shared FarCallCommon with rawA tag01, never OR80 for RAM. QhDispatch preserves the borrowedR0/R1 pair, saves rawC, maps rawC02 once, executes the actual ArenaGatePtr target, restores rawC/R0/R1 and outputA/P. Native source calls and live-block world callback are near inA1; host ROM services still use genuine FarCallCommon with real ROM tags. Native interrupts and shared33B SMC are not extended. See api-and-ownership.json for owner transition/loader constraints and hook target PCs.

All controls explicitly preload CPU RAM; no integrated loader, cartridge header, CHR storage lease, actual new HuCommon router, native emulator run, native RGB palette proof or shared install is claimed. Root's separate MMC5 lab proves its installed Mesen mechanism only. The original source/frozen host packet and existing leases remain unchanged. Original CX sound/theme and exact source enemy-contact integration remain open. Active fullMain timing must be measured after actual private loader/router adoption; no60Hz claim follows from this tick reduction. Pending owner switching, water/platform/automatic scenes, full campaign and Hard qualification remain.

Two discarded ISR fixture assumptions are recorded as negatives: checking NmiDisable after normal NMI falsely tested changed state, and expecting IRQ to commit a mapper shadow pending its hardwareSTA was wrong. The passing fixture captures the pre-interrupt disable state and separates raw shadow/hardware expectations; only normal NMI may commit the exact pending5115/5116 write it genuinely restores. No runtime repair was made for these harness errors.

reproduction/ contains standalone assembly inputs plus exact code/data/art reconstruction. source-closure.zip contains all direct prototype tools and inputs. Bound earlier frozen handoffs preserve actual source extraction, full parent reproduction and exact CPU candidate closure. This packet makes no change to canonical sources, Downloads, user windows, physical resource reservations or shared readiness.
''',newline='\n')
    tools=['quickman_wram_prepare_v1.py','quickman_wram_controls_v1.py','quickman_wram_whole_v2.py','quickman_wram_whole_controls_v2.py','quickman_host_controls_v3.py','quickman_host_main_v3.py','quickman_component_bench_v2.py','quickman_wram_freeze_v3.py','check_tmnt_render_oa.py']
    inputs=[R/'tools/audit'/n for n in tools]+[P/'source-closure.zip',K/'kernel.s',K/'prepared.json',K/'kernel.lbl',K/'kernel.bin',R/'build/quickman-host-arena-v1/two-zp-projection/component/source-map.json',R/'build/quickman-host-arena-v1/projection/bench/native-stage-fixture.bin']
    with zipfile.ZipFile(O/'source-closure.zip','w',zipfile.ZIP_DEFLATED)as z:
        for p in inputs:z.write(p,str(p.relative_to(R)).replace('\\','/'))
        for p in repro.rglob('*'):
            if p.is_file()and p.suffix in ['.s','.cfg','.inc','.bin','.chr']:z.write(p,'reproduction/'+p.relative_to(repro).as_posix())
    with zipfile.ZipFile(O/'source-closure.zip')as z:assert z.testzip()is None
    preimages=[P/'candidate.nes',P/'candidate.dbg',P/'candidate.lbl',P/'handoff.json',P/'source/quick/core.s',P/'source/quick/runtime.s',P/'source/quick/render.s',R/'build/mmc5-overlay-lab-v1/ready.json',R/'build/mmc5-overlay-lab-v1/native/result.json',R/'build/quickman-component-v2/palette/palette-owner.json',Path('C:/NES/the stash/Rockman_CX-world44.spcs.bio.nes')]
    files=[p for p in O.rglob('*')if p.is_file()]
    put(O/'handoff.json',dict(status='FROZEN_PRIVATE_WHOLE_COMPONENT_WRAM_CPU_PROTOTYPE',native=False,shared_adoption=False,header_adoption=False,loader_implemented=False,new_resource_lease=False,source_original_sha256=sha(preimages[-1]),parent_actual_host_sha256=sha(P/'candidate.nes'),code_sha256=sha(O/'code.bin'),data_sha256=sha(O/'data.bin'),used_bytes=dict(code=6491,data=1921),padded_load_bytes=16384,compact_storage_pages=9,compact_storage_bytes=9216,existing_art_bytes=5120,transient_bytes=557,persistent_bytes=8,new_ZP=0,files=len(files),bindings={str(p.resolve()):sha(p)for p in files+inputs+preimages}))
    print(json.dumps(dict(packet=str(O),handoff_sha256=sha(O/'handoff.json'),files=len(files),bytes=sum(p.stat().st_size for p in O.rglob('*')if p.is_file())),indent=2))

if __name__=='__main__':main()
