"""Assemble a whole private Quick engine in codeRAM1/dataRAM2; no ROM adoption."""
from pathlib import Path
import hashlib,json,re,subprocess,sys
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(Path(__file__).parent))
from check_tmnt_render_oa import load,address,location
P=R/'build/quickman-host-cpu-v4';K=R/'build/quickman-wram-prep-v1';O=R/'build/quickman-wram-whole-v2'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,newline='\n')
def main():
    O.mkdir(exist_ok=True);B=load(P/'candidate.nes')
    core=(K/'kernel.s').read_text();frozen=(P/'source/quick/core.s').read_text()
    world=frozen[frozen.index('QuickManWorldProbe:\n'):frozen.index('G_LOW_ArenaGetFrameBody:\n')]
    tables=re.findall(r'(?m)^DX_\w+: \.byte[^\n]*\n',core);assert len(tables)>100
    core=re.sub(r'(?m)^DX_\w+: \.byte[^\n]*\n','',core)
    runtime=(P/'source/quick/runtime.s').read_text()
    a=runtime.index('QhDispatch:\n');z=runtime.index('; Resync native clamps',a)
    entry='''QhDispatch:
 sta ArenaGateA
 php
 pla
 sta ArenaGateP
 lda R0
 pha
 lda R1
 pha
 lda CurrentBankC
 pha
 lda #2
 sta CurrentBankC
 sta $5116
 lda ArenaGateP
 pha
 lda ArenaGateA
 plp
 jsr QwIndirect
 sta ArenaGateA
 php
 pla
 sta ArenaGateP
 pla
 sta CurrentBankC
 sta $5116
 pla
 sta R1
 pla
 sta R0
 lda ArenaGateP
 pha
 lda ArenaGateA
 plp
 rts
QwIndirect:jmp(ArenaGatePtr)
'''
    runtime=runtime[:a]+entry+runtime[z:]
    for gate,target in [('QhHitGate','QhHitOne'),('QhReset','QhResetCore')]:
        pattern=re.escape(gate)+r':\n sta ArenaGateA\n php\n lda #<'+target+r'\n sta ArenaGatePtr\n lda #>'+target+r'\n sta ArenaGatePtr\+1\n lda #[^\n]*\n jmp ArenaCallC\n'
        runtime,n=re.subn(pattern,gate+':jmp '+target+'\n',runtime);assert n==1,(gate,n)
    runtime=runtime.replace('QhFar HuFullPower','jsr QhFullPower').replace('QhFar HuColors','jsr QhColors')
    runtime=runtime.replace('lda #.lobyte(.bank(Target)|$80)','lda #.lobyte(.ident(.concat("HostBank_",.string(Target))))')
    render=(P/'source/quick/render.s').read_text()
    a=render.index('QuickManHostRender:\n');z=render.index('.segment "ARENA_RENDER"',a)
    render=render[:a]+'QuickManHostRender:jmp QuickManRenderFrames\n'+render[z:]
    render=render.replace('QmMeta: .incbin "'+str(R/'build/quickman-host-integrate-v3/quick/metasprites3.bin').replace('\\','/')+'"','QmMeta: .incbin "'+(P/'source/quick/metasprites3.bin').as_posix()+'"')
    # Split the original lookup's code from its actual immutable data arrays.
    render=render.replace('QuickManHostPoseIds:','.segment "QW_DATA"\nQuickManHostPoseIds:',1)
    frame=frozen[frozen.index('QuickManRenderFrames:\n'):frozen.index('.segment "R1_TABLE"')]
    a=frame.index('lda QuickManWork_01\nsta ArenaGateA\n');frame=frame[:a]+'lda QuickManWork_01\njmp ArenaRenderCore\n'
    s=core+'\n.segment "QW_CODE"\n'+world+'\n'+runtime+'\n'+render+'\n.segment "QW_CODE"\n'+frame+'\n.segment "QW_DATA"\n'+''.join(tables)
    s=re.sub(r'(?m)^\.import(?:zp)? [^\n]*\n','',s)
    s=re.sub(r'(?m)^\.include "(?:host-imports.inc|qh_imports.inc|qh_fields.inc)"\n','',s)
    s=re.sub(r'(?m)^\.macpack longbranch\n','',s)
    def segment(m):
        n=m[1]
        if n.startswith('QM_')and n not in ['QM_WRAM_KERNEL','QM_COORD']or n=='QH_PERSIST':return m[0]
        if n in ['ARENA_ART_META','QW_DATA']:return '.segment "QW_DATA"'
        if n=='ARENA_CHR':return m[0]
        return '.segment "QW_CODE"'
    s=re.sub(r'\.segment "([A-Za-z_0-9]+)"',segment,s)
    # All true host calls retain their actual bank kind. Code/data RAM tags
    # are never OR80; the remaining ROM services bind to frozen source symbols.
    for n in re.findall(r'\.bank\((\w+)\)',s):
        assert n in B['syms'];s=s.replace('.lobyte(.bank('+n+')|$80)','HostBank_'+n)
    s=re.sub(r'#(HostBank_\w+)',r'#.lobyte(\1)',s)
    own=set(re.findall(r'(?m)^(\w+)\s*[:=]',s));tokens=set(re.findall(r'\b[A-Za-z_]\w*\b',re.sub(r';[^\n]*','',s)))
    external={n for n in tokens if n in B['syms']and n not in own}
    external|={'FarCallCommon','CurrentBankC','R0','R1'}
    imports=[];defs=[]
    for n in sorted(external):
        row=B['syms'][n];zp=row.get('addrsize')=='zeropage';kind='zp 'if zp else' '
        imports.append('.import'+kind+n);defs+=['.export'+kind+n,n+'=$'+format(address(B,n),'x')]
    banks=set(re.findall(r'QhFar (\w+)',runtime))|set(re.findall(r'HostBank_(\w+)',s))
    banks.discard('Target')
    for n in sorted(banks):
        assert n in B['syms'],n;bank=(location(B,n)-16)//8192
        imports.append('.importzp HostBank_'+n);defs+=['.exportzp HostBank_'+n,'HostBank_'+n+'=$'+format(bank|128,'02x')]
    s='.setcpu "6502"\n.macpack longbranch\n'+'\n'.join(imports)+'\n'+s
    put(O/'whole.s',s);put(O/'host-definitions.s','\n'.join(defs)+'\n')
    cfg=(P/'quick.cfg').read_text();mem='\n'.join(line for line in cfg.splitlines()if re.match(r'N\d+:',line));state='\n'.join(line for line in cfg.splitlines()if line.startswith('QM_')and'load=N'in line)
    cfg='MEMORY {\n'+mem+f'\nPERSIST:start=$5f88,size=8,type=rw,file="";\nRAM1:start=$a000,size=$2000,type=ro,fill=yes,fillval=$ff,file="{(O/"code.bin").as_posix()}",bank=1;\nRAM2:start=$c000,size=$2000,type=ro,fill=yes,fillval=$ff,file="{(O/"data.bin").as_posix()}",bank=2;\nCHR:start=0,size=$1400,type=ro,file="{(O/"art.chr").as_posix()}";\n}}\nSEGMENTS{{\n'+state+'\nQH_PERSIST:load=PERSIST,type=bss;\nQW_CODE:load=RAM1,type=ro;\nQW_DATA:load=RAM2,type=ro;\nARENA_CHR:load=CHR,type=ro;\n}\n'
    put(O/'whole.cfg',cfg);ca=R/'tools/Windows/cc65/bin/ca65.exe';ld=ca.with_name('ld65.exe');logs=[]
    cmds=[[str(ca),'-g','-I',str(R/'build/quickman-host-integrate-v3/frozen-inputs'),str(O/(n+'.s')),'-o',str(O/(n+'.o'))]for n in ['whole','host-definitions']]
    cmds.append([str(ld),'-C',str(O/'whole.cfg'),'--dbgfile',str(O/'whole.dbg'),'-Ln',str(O/'whole.lbl'),'-m',str(O/'whole.map'),str(O/'whole.o'),str(O/'host-definitions.o')])
    for cmd in cmds:
        cp=subprocess.run(cmd,capture_output=True,text=True);logs.append(dict(command=cmd,returncode=cp.returncode,stderr=cp.stderr));put(O/'build-log.json',json.dumps(logs,indent=2)+'\n');assert cp.returncode==0,cp.stderr[:8000]
    linked=(O/'whole.map').read_text();sizes={n:int(re.search(n+r'\s+([0-9A-F]+)\s+([0-9A-F]+)\s+([0-9A-F]+)',linked)[3],16)for n in ['QW_CODE','QW_DATA']}
    result=dict(status='ASSEMBLED_PRIVATE_WHOLE_WRAM_COMPONENT_PROTOTYPE',native=False,shared_header_changed=False,physical_storage_lease=False,code_RAM_tag=1,data_RAM_tag=2,sizes=sizes,code_headroom=8192-sizes['QW_CODE'],data_headroom=8192-sizes['QW_DATA'],source_tables_moved_losslessly=len(tables),actual_FarCallCommon_for_ROM_services=True,source_handoff_sha256=sha(P/'handoff.json'),source_kernel_sha256=sha(K/'kernel.bin'),outputs={str(O/n):sha(O/n)for n in ['whole.s','whole.cfg','whole.lbl','whole.dbg','code.bin','data.bin','art.chr']})
    put(O/'prepared.json',json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
if __name__=='__main__':main()
