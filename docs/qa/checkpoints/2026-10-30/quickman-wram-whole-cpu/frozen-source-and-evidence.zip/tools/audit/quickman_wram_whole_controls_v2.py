"""Actual source/component CPU prototype controls; no host routing/header adoption."""
from pathlib import Path
import inspect,json,re,sys
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(Path(__file__).parent))
import quickman_wram_controls_v1 as K
C,H=K.C,K.H
O=R/'build/quickman-wram-whole-v2';P=K.P
LABELS={n:int(v,16)for v,n in re.findall(r'al ([0-9A-Fa-f]+) \.(\w+)',(O/'whole.lbl').read_text())}
CODE=(O/'code.bin').read_bytes();DATA=(O/'data.bin').read_bytes()

class WholeBus(K.WramBus):
    def __init__(self,n=65536):
        super().__init__(n);self.lab.update(LABELS);self.wram[1][:]=CODE;self.wram[2][:]=DATA
    def __getitem__(self,a):
        if isinstance(a,int)and self.publish_test_world and self.tags[1]==1 and a==self.lab['QuickManWorldProbe']:
            page=self.ram[4];tab=self.lab['BlockBufferAddr'];parity=page&1;base=self[tab+parity]+256*self[tab+2+parity]
            for y in range(13):
                for x in range(16):self.ram[base+y*16+x]=self.solid if self.grid[y+2][(page&3)*16+x]else self.empty
        return super().__getitem__(a)

def invoke(m,pc,A=0,hook=None,X=0,registers=None,Pflags=0x30):
    if not isinstance(m,WholeBus):return C.b.invoke(m,pc,A,hook,X,registers)
    m.set('ArenaGatePtr',pc);m.ram[m.lab['ArenaGatePtr']+1]=pc>>8;m.set('ArenaGateBank',1)
    m.ram[m.lab['SafecallA_SMC']+1]=A
    m.ram[m.lab['FarcallJmpTarget_SMC']+1]=m.lab['QhDispatch']&255;m.ram[m.lab['FarcallJmpTarget_SMC']+2]=m.lab['QhDispatch']>>8
    m.ram[0x1fe]=0xfe;m.ram[0x1ff]=0x7f
    c=H.N.NesMPU(memory=m,pc=m.lab['FarCallCommon']);c.a=1;c.x=X;c.y=0;c.p=Pflags;c.sp=253
    for _ in range(100000):
        if c.pc==0x7fff:break
        if hook:hook(c)
        assert m[c.pc]!=0,('component BRK',hex(c.pc),m.tags);c.step()
    else:raise AssertionError(('whole component timeout',hex(c.pc),m.tags))
    assert c.sp==255
    assert m.tags==[0xfe,0xd8,0xd7,0xff]and m.get('CurrentBank')==216 and m.get('CurrentBankC')==215
    assert m.wram[1]==CODE and m.wram[2]==DATA
    if registers is not None:registers.update(A=c.a,X=c.x,Y=c.y,P=c.p)
    return c.processorCycles

def source():
    info=json.loads((C.ORACLE/'two-zp-projection/component/source-map.json').read_text());mapping={int(k,16):v for k,v in info['native_to_private_state'].items()};work=info['work_absolute']
    out=O/'bench';out.mkdir(exist_ok=True);(out/'component-fixture.bin').write_bytes(b'')
    text=inspect.getsource(C.b.differential).replace("z=labels['QuickManScratch']","z=0")
    text=text.replace("or component[labels['FixtureStatus']]:","or(component[labels['FixtureStatus']]&127):")
    for old,new in [('component[z+8]','component[3]'),('component[z+9]','component[4]'),('component[z+0xa]',f'component[{work["0A"]}]'),('component[z+0xb]',f'component[{work["0B"]}]'),('component[z]',f'component[{work["00"]}]')]:text=text.replace(old,new)
    (out/'segmented-oracle.py').write_text(text,newline='\n');ns=dict(C.b.__dict__);ns.update(O=O,bytearray=WholeBus,invoke=invoke);exec(compile(text,str(out/'segmented-oracle.py'),'exec'),ns)
    C.HostBus.publish_test_world=True
    try:proof=ns['differential'](info,mapping,WholeBus().lab,(C.ORACLE/'projection/bench/native-stage-fixture.bin').read_bytes())
    finally:C.HostBus.publish_test_world=False
    maximum=max(x['component_cycles_max']for x in proof['cases'])
    result=dict(passed=True,native=False,header_changed=False,CPU_RAM_preload_fixture=True,actual_host_ROM_sha256=K.sha(P/'candidate.nes'),code_sha256=K.sha(O/'code.bin'),data_sha256=K.sha(O/'data.bin'),source_ticks=sum(x['ticks']for x in proof['cases']),all535_source_fields_equal_each_tick=True,semantic_assertions=proof['semantic_assertions'],maximum_tick_cycles=maximum,source_native_tables_in_independent_data_RAM2=True,raw_RAM_tags_preserved=True,code_data_immutable_and_borrowed_pairs_restored=True,cases=proof['cases'])
    K.put(O/'source-controls.json',result);print('Whole WRAM source1520 PASS, maxTick',maximum)

def flags():
    rows=[];oldcpu=C.MPU;C.MPU=H.N.NesMPU
    try:
        for p in [f for f in range(256)if f&0x30==0x30]:
            for keys in [0,1,2,64,128,129,131,160]:
                pair=[]
                for wram in [False,True]:
                    m=WholeBus()if wram else C.HostBus(path=P/'candidate.nes');regs={}
                    if wram:invoke(m,m.lab['QuickManInit']);invoke(m,m.lab['QuickManTick'],A=keys,Pflags=p,registers=regs)
                    else:C.call(m,'QuickManInit');C.call(m,'QuickManTick',A=keys,P=p,registers=regs)
                    pair.append((regs,{n:m.get(n)for n in m.lab if n.startswith('QmField_')}))
                assert pair[0]==pair[1],(p,keys,pair[0][0],pair[1][0]);rows.append([p,keys,*pair[1][0].values()])
    finally:C.MPU=oldcpu
    K.put(O/'flags-controls.json',dict(passed=True,native=False,code_sha256=K.sha(O/'code.bin'),data_sha256=K.sha(O/'data.bin'),cases=len(rows),NES_flags_and_all535_source_fields_match_frozen_API=True,rows=rows));print('Whole WRAM AXYP +535 fields512 PASS')

def render():
    # Retain the frozen300 geometry/OAM cases, but route the component-owned
    # entry directly through its genuine rawRAM FarCallCommon dispatcher.
    text=inspect.getsource(C.render_controls).replace('def render_controls():','def run():')
    text=text.replace("call(m,'HuDraw')","invoke(m,m.lab['QhDraw'])").replace("call(cold,'HuMenuPortrait')","invoke(cold,cold.lab['QhPortrait'])")
    text=text.replace("call(m,'QuickManInit')","invoke(m,m.lab['QuickManInit'])")
    text=text.replace("call(cold,'HuFresh')","invoke(cold,cold.lab['QhConstruct'])")
    text=text.replace("sha(O/'candidate.nes')","sha(P/'candidate.nes')")
    ns=dict(C.__dict__);ns.update(O=O,P=P,HostBus=WholeBus,invoke=invoke);exec(compile(text,'whole-render-controls','exec'),ns);ns['run']()
    d=json.loads((O/'render-controls-v3.json').read_text());d.update(component_only=True,actual_host_ROM_sha256=K.sha(P/'candidate.nes'),code_sha256=K.sha(O/'code.bin'),data_sha256=K.sha(O/'data.bin'),host_router_not_adopted=True);K.put(O/'render-controls.json',d)

def public():
    targets={r['hook']:r['target']for r in json.loads((P/'quick-route-table.json').read_text())['targets']}
    def call(m,name,**kwargs):
        target=targets.get(name,name)
        if target.startswith(('Qh','QuickMan')):
            if'P'in kwargs:kwargs['Pflags']=kwargs.pop('P')
            return invoke(m,m.lab[target],**kwargs)
        return C.call(m,name,**kwargs)
    text=inspect.getsource(C.public_controls).replace('def public_controls():','def run():').replace("sha(O/'candidate.nes')","sha(P/'candidate.nes')")
    ns=dict(C.__dict__);ns.update(O=O,P=P,HostBus=WholeBus,call=call);exec(compile(text,'whole-public-controls','exec'),ns);ns['run']()
    d=json.loads((O/'public-controls-v3.json').read_text());d.update(component_only=True,code_sha256=K.sha(O/'code.bin'),data_sha256=K.sha(O/'data.bin'),host_router_not_adopted=True);K.put(O/'public-controls.json',d)

def interrupts():
    B=H.U.scoped_load(P/'candidate.nes');q=H.make(B);template=WholeBus();template.ram[:0x8000]=bytes(q.m[:0x8000]);template.tags=[0xfe,0xd8,0xd7,0xff];template.A,template.C=88,87;template.set('CurrentBank',216);template.set('CurrentBankC',215)
    invoke(template,template.lab['QhConstruct'])
    for age in range(10):
        template.set('SavedJoypadBits',1 if age<5 else 193);invoke(template,template.lab['QhMovement'])
    def start(target,lag=255):
        m=WholeBus();m.ram[:0x8000]=template.ram[:0x8000];m.tags=[0xfe,0xd8,0xd7,0xff];m.A,m.C=88,87;m.set('CurrentBank',216);m.set('CurrentBankC',215);m.set('NmiDisable',lag)
        pc=m.lab[target];m.set('ArenaGatePtr',pc);m.ram[m.lab['ArenaGatePtr']+1]=pc>>8
        m.ram[m.lab['SafecallA_SMC']+1]=m.get('CurrentOAMOffset')if target=='QhDraw'else 131
        m.ram[m.lab['FarcallJmpTarget_SMC']+1]=m.lab['QhDispatch']&255;m.ram[m.lab['FarcallJmpTarget_SMC']+2]=m.lab['QhDispatch']>>8;m.ram[0x1fe]=0xfe;m.ram[0x1ff]=0x7f
        c=H.N.NesMPU(memory=m,pc=m.lab['FarCallCommon']);c.a=1;c.p=0x71;c.sp=253;c.x=7;c.y=55
        return m,c
    saved=K.KERNEL;K.KERNEL=CODE;rows=[]
    try:
        for target in ['QhMovement','QhDraw']:
            m,c=start(target);cuts=[]
            for step in range(30000):
                if c.pc==0x7fff:break
                pc=c.pc
                if 0x15a<=pc<0x17b or m.lab['QhDispatch']<=pc<m.lab['QhImport']or(m.tags[1]==1 and step%64==0)or pc==m.lab['X5SetPhysicalChr']:cuts.append((step,pc))
                c.step()
            else:raise AssertionError('baseline whole component timeout')
            for step,pc in cuts:
                for lag in [0,255]:
                    for kind in ['NMI','IRQ']:
                        m,c=start(target,lag)
                        for _ in range(step):c.step()
                        assert c.pc==pc
                        proof=K.context(m,c,kind)
                        for _ in range(30000):
                            if c.pc==0x7fff:break
                            c.step()
                        else:raise AssertionError('post ISR whole timeout')
                        assert m.tags==[0xfe,0xd8,0xd7,0xff]and m.wram[1]==CODE and m.wram[2]==DATA
                        rows.append(dict(target=target,step=step,PC=pc,lag=lag,**proof))
    finally:K.KERNEL=saved
    result=dict(passed=True,native=False,CPU_preload_fixture=True,actual_host_ROM_sha256=K.sha(P/'candidate.nes'),code_sha256=K.sha(O/'code.bin'),data_sha256=K.sha(O/'data.bin'),real_vector_interruptions=len(rows),raw_A_RAM1_C_RAM2_and_all33SMC_AXYP_live_stack_restored=True,source_motion_and_actual_ROM_CHR_publisher_seams=True,rows=rows)
    K.put(O/'real-isr-controls.json',result);print('Whole WRAM actual vectors',len(rows),'PASS')

if __name__=='__main__':
    if '--source'in sys.argv:source()
    if '--flags'in sys.argv:flags()
    if '--render'in sys.argv:render()
    if '--isr'in sys.argv:interrupts()
    if '--public'in sys.argv:public()
