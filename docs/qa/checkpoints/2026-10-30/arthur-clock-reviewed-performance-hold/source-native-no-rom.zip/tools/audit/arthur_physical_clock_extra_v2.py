"""Actual player transpose, ordinary-audio rejection and unchanged FF Main."""
from pathlib import Path
import itertools,json,traceback
import arthur_physical_clock_context_v2 as V
from arthur_physical_clock_controls_v2 import fresh,mailbox
from sunny_integrated_controls_v1 import registers
A=V.A;B=V.B;O=V.O;N=V.N;P=B.R/'build/celeste-menu-name-arthur-v2/joint'
def main():
 out=O/'extra-owner-cadence-controls-v2.json';assert not out.exists();d=dict(passed=False,native=False,checks={})
 try:
  old,b=[A.scoped_load(p/'candidate.nes')for p in[P,N]];rows=[]
  for mode,keys in itertools.product(range(2),[0,129]):
   pair=[]
   for v in[old,b]:
    q=A.C.setup(v,22);q.put(CrossoverBehaviorVersion=mode,SavedJoypadBits=keys,FamilyMainCommit=1);c,tr,mn,ann,events=A.M.run_linked(q,'GameLoop',p=0x71);pair.append((q,c))
   (qa,ca),(qb,cb)=pair;assert registers(ca)==registers(cb)and A.C.M.fastapp(qa)==A.C.M.fastapp(qb)and qa.m.rawtags==qb.m.rawtags
   assert qa.m.writes==qb.m.writes;rows.append([mode,keys,cb.processorCycles-ca.processorCycles])
  d['checks']['four_FF_complete_Main_immediate_parent_exact']=rows
  q=fresh(b);q.put(FamilyMainCommit=0,SavedJoypad1Bits=129);before=mailbox(q);A.call(q,'AudioUpdate');assert mailbox(q)==before
  d['checks']['ordinary_AudioUpdate_does_not_clock']=True
  A.owned(q,'ArHostNativePickup',a=6);A.owned(q,'ArHostSave');q.put(NumberOfPlayers=1,OffScr_NumberofLives=4,OffScr_AreaNumber=3,OffScr_WorldNumber=1,FamilyMainCommit=1)
  turns=[]
  for turn in range(4):
   q.put(SavedJoypad1Bits=128);A.call(q,'ArGenClockIngress');assert mailbox(q)[1]==1
   if turn==2:q.put(NumberofLives=1)
   A.call(q,'NativeRareTransposePlayersCore');A.call(q,'HuGraphics');want=[64,68,66,64][turn]
   assert q.get('ArR_053A')==want and mailbox(q)==[1,0,0,q.get('CurrentPlayer'),167],(turn,q.get('ArR_053A'),mailbox(q))
   if turn==0:A.owned(q,'ArHostNativePickup',a=8);A.owned(q,'ArHostSave')
   turns.append([turn,q.get('CurrentPlayer'),want,mailbox(q)])
  d['checks']['actual_native_four_player_transposes_drop_old_pad_due']=turns
  d['passed']=True
 except Exception as e:d.update(error=repr(e),traceback=traceback.format_exc())
 d['bindings']={str(p.resolve()):B.sha(p)for p in[Path(__file__),N/'candidate.nes',N/'candidate.dbg',P/'candidate.nes']};out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items()if k not in['checks','bindings','traceback']}));assert d['passed'],d.get('error')
if __name__=='__main__':main()
