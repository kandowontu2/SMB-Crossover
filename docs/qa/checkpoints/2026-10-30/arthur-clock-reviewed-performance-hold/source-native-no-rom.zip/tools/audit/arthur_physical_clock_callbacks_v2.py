"""Actual SFC 36-service ABI; explicit private-pointer relocation accounting."""
from pathlib import Path
import itertools,json,traceback
import arthur_physical_clock_context_v2 as V
import arthur_joint_live_isr_v5 as I
import ff_ram3_execution_controls_v2 as E
from arthur_physical_clock_controls_v2 import fresh
from sunny_integrated_controls_v1 import registers,smc_at
A=V.A;B=V.B;O=V.O;N=V.N;P=B.R/'build/celeste-menu-name-arthur-v2/joint'
def service(q,row,p):
 c=E.start(q.m,'ArOwnServices',a=85,x=0,y=3,p=p,sp=224);c.a=A.point(q.b,'ArOwnServices')[0]|128
 at=A.address(q.b,'FarcallJmpTarget_SMC');target=A.address(q.b,'ArOwnServices')+3*row;q.m[at+1]=target&255;q.m[at+2]=target>>8
 low=c.sp;tr=[]
 for i in range(300000):
  if c.pc==0x5b00:break
  low=min(low,c.sp);bank=q.m.rawtags[(c.pc-32768)//8192]if c.pc>=32768 else-1;tr.append((bank&127,c.pc));assert q.m[c.pc],('BRK',row,hex(c.pc),bank);c.step()
 else:raise AssertionError(('bounded callback',row,hex(c.pc)))
 assert c.sp==224;return c,tr,low
def main():
 out=O/'callbacks-allflags-v2.json';assert not out.exists();d=dict(passed=False,native=False,rows=[])
 try:
  old,b=[A.scoped_load(p/'candidate.nes')for p in[P,N]];bases=[fresh(v)for v in[old,b]]
  flags=[0x30|sum(((v>>i)&1)*bit for i,bit in enumerate([1,2,4,8,64,128]))for v in range(64)]
  for row,p in itertools.product(range(36),flags):
   pair=[]
   for base in bases:
    q=I.clone(base);q.put(FamilyMainCommit=1,NmiDisable=255,VRAM_Buffer1_Offset=0);c,tr,low=service(q,row,p);pair.append((q,c,tr,low))
   qa,ca,ta,la=pair[0];qb,cb,tb,lb=pair[1]
   assert registers(ca)==registers(cb),('AXYP/SP',row,p,registers(ca),registers(cb))
   aa,bb=A.C.M.fastapp(qa),A.C.M.fastapp(qb)
   if aa!=bb:raise AssertionError(('application',row,p,A.M.different(aa,bb)))
   assert qa.m.rawtags==qb.m.rawtags,('raw maps',row,p)
   A.M.smc_contract(qa,qb,ta,tb)
   d['rows'].append([row,p,cb.processorCycles-ca.processorCycles,min(la,lb)])
  d.update(passed=True,cases=len(d['rows']),CPU_delta=[min(z[2]for z in d['rows']),max(z[2]for z in d['rows'])])
 except Exception as e:d.update(error=repr(e),traceback=traceback.format_exc())
 d['bindings']={str(p.resolve()):B.sha(p)for p in[Path(__file__),P/'candidate.nes',P/'candidate.dbg',N/'candidate.nes',N/'candidate.dbg']};out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items()if k not in['bindings','traceback','rows']}));assert d['passed'],d.get('error')
if __name__=='__main__':main()
