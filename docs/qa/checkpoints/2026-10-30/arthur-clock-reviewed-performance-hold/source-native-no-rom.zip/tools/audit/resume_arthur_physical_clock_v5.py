"""Genuine zero-byte world exports for the co-resident floor routine move."""
from pathlib import Path
import json,subprocess
import build_arthur_physical_clock_v2 as B
N=B.N;O=B.O;R=B.R;sha=B.sha
def main():
 assert not(O/'linked-stage.json').exists()
 p=N/'arthur/host-world.s';v=p.read_text().replace(',ArHostFloorTile','');p.write_text('.import ArHostFloorTile\n'+v,newline='\n')
 p=N/'arthur/host-state.s';p.write_text('.export ArHostFloorTile\n'+p.read_text(),newline='\n')
 for phase in ['arthur-own-services','arthur-host-state','arthur-host-world','clock2-link']:
  source=N/(phase+'.json')if phase=='clock2-link'else N/(phase+'-clock2-build.json')
  if not source.exists():source=B.J/('clock-link.json'if phase=='clock2-link'else phase+'-clock-build.json')
  cmd=[x.replace(str(B.J),str(N)).replace(B.J.as_posix(),N.as_posix())for x in json.loads(source.read_text())['command']]
  for flag in ['-o','-Ln','-m','--create-full-dep']:
   if flag in cmd:assert Path(cmd[cmd.index(flag)+1]).resolve().is_relative_to(N.resolve())
  for v in cmd:
   if v.startswith('--dbgfile,'):assert Path(v.split(',',1)[1]).resolve().is_relative_to(N.resolve())
  r=subprocess.run(cmd,cwd=R,capture_output=True,text=True);(N/(phase+'-resume5.json')).write_text(json.dumps(dict(command=cmd,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr),indent=2)+'\n');assert not r.returncode,r.stderr
 B.B.B.prepare(R,N/'candidate.nes');b=B.B.B.scoped_load(N/'candidate.nes');sizes={s['name'].strip('"'):int(s['size'],0)for s in b['segs'].values()}
 (O/'linked-stage.json').write_text(json.dumps(dict(native=False,candidate=sha(N/'candidate.nes'),parent=sha(B.J/'candidate.nes'),sizes=sizes,mailbox=[0xdfd0,0xdfd5],status='SOURCE_LINKED_CONTROLS_PENDING',source_v1_negative_preserved=True),indent=2)+'\n');print(json.dumps(dict(candidate=sha(N/'candidate.nes'),sizes={k:v for k,v in sizes.items()if'ARTHUR'in k or'AR_GEN'in k or k=='GIMMICK_COMMON_NMI'})))
if __name__=='__main__':main()
