"""Bounded same-controller native successor with real new clock/write PCs."""
from pathlib import Path
import difflib,json,re
import arthur_physical_clock_context_v2 as V
import arthur_body_fair_budget_v7 as Q
A=V.A;B=V.B;R=B.R;O=V.O;N=V.N
def main():
 out=O/'native-prepared-v3.json';assert not out.exists();h=json.loads((O/'handoff.json').read_text())
 for p,v in h['bindings'].items():assert B.sha(p)==v,p
 b=A.scoped_load(N/'candidate.nes');parent=R/'build/arthur-expanded-ready-v2';text=(parent/'native-controller-v1.lua').read_text()
 assert text.count("hook('ArHostNmiClock',function()clocks=clocks+1 end,1,-8192)")==1
 text=text.replace("hook('ArHostNmiClock',function()clocks=clocks+1 end,1,-8192)","hook('ArHostNmiClock',function()clocks=clocks+1 end,2,8192)")
 writers=[]
 for name,mirror in[('ArHostNmiClock',8192),('ArClockPollC70',8192),('ArHostClockColdBridge',0),('ArCacheRetire',0)]:
  at=A.location(b,name);pc=A.address(b,name);size=int(b['syms'][name]['size'],0);raw=b['raw'][at:at+size]
  for i in range(size-2):
   op=raw[i];target=raw[i+1]+256*raw[i+2]
   if op in[141,206]and(target in range(0xbfd0,0xbfd5)or target in[0xdfd4,0xdfe0]):
    # Disassemble instruction starts via explicit opcode vocabulary; these
    # matches also must be source-declared operands in the bound proc.
    writers.append(dict(name=name,PC=pc+i+mirror,bank=A.point(b,name)[0]|128,window=(pc+i+mirror-32768)//8192,target=target,opcode=op))
 assert len(writers)==13,writers
 lua='''local writeToken=nil
local function bank2read(off)
 if cacheRawA==2 then return emu.read(0xa000+off,emu.memType.nesDebug)end
 assert(cacheRawC==2,'Mailbox writer has real bank2 mapped')
 return emu.read(0xc000+off,emu.memType.nesDebug)
end
local function cacheCookie()
 for i,v in ipairs(ARTHUR_CACHE_SIGNATURE)do assert(bank2read(0x1fe0+i-1)==v,'Authenticated mailbox full16 cookie')end
end
local function armWriter(pc,bank,window,target,opcode,owner)
 emu.addMemoryCallback(function()
  local raw=window==1 and cacheRawA or cacheRawC
  if raw~=bank then return end
  writeToken={pc=pc,target=target,opcode=opcode,owner=owner,remaining=opcode==206 and 2 or 1}
 end,emu.callbackType.exec,pc)
end
'''
 for w in writers:lua+=f"armWriter({w['PC']},{w['bank']},{w['window']},{w['target']},{w['opcode']},'{w['name']}')\n"
 lua+='''local mailboxWrites=0
local function selectedWrite(at,value,raw)
 if raw~=2 then return end
 cacheWrites=cacheWrites+1
 if cacheLoading then return end
 local token=writeToken
if token then token.remaining=token.remaining-1;if token.remaining==0 then writeToken=nil end end
 assert(token and token.target==at,'Exact authenticated source clock/retire writer; DEC may issue its two hardware RMW writes')
 assert(r('SelectedCharacter')==32,'Mailbox writes only selected Arthur')
 local off=at&8191
 if off==0x1fe0 then
  assert(token.owner=='ArCacheRetire'and value==0 and r('FamilyMainCommit')&1~=0,'Exact own cookie retirement')
  return
 end
 assert(off>=0x1fd0 and off<0x1fd5,'Strict live cache/code payload-write ban')
 if token.owner=='ArHostNmiClock'then
  assert(r('OperMode')==1 and r('GameEngineSubroutine')==8 and r('GamePauseStatus')&1==0,'Physical source clock context')
  cacheCookie();assert(bank2read(0x1fd4)==167 and bank2read(0x1fd3)==r('CurrentPlayer'),'Physical source clock player generation')
 elseif token.owner=='ArClockPollC70'then
  cacheCookie();assert(r('FamilyMainCommit')&1~=0 and off==0x1fd1 and value==0,'Foreground consumes saturated Due only')
 elseif token.owner=='ArHostClockColdBridge'then
  assert(r('FamilyMainCommit')&1~=0,'Clock reset/invalidation within genuine Main busy')
 elseif token.owner=='ArCacheRetire'then
  assert(r('FamilyMainCommit')&1~=0 and off==0x1fd4 and value==0,'Own valid invalidated before retirement')
 else error('Unknown mailbox owner')end
 if off==0x1fd0 then assert(value<=3,'Original phase1..3 or DEC transition0')
 elseif off==0x1fd1 then assert(value<=1,'Saturated Due')
 elseif off==0x1fd3 then assert(value==r('CurrentPlayer'),'Current native player')
 elseif off==0x1fd4 then assert(value==0 or value==167,'Clear-first/valid-last tag')end
 mailboxWrites=mailboxWrites+1
end'''
 old='''local function selectedWrite(at,value,raw)
 if raw~=2 then return end
 cacheWrites=cacheWrites+1
 assert(cacheLoading or ((at&8191)==0x1fe0 and value==0),'No live cache/code write outside loading/own retirement')
end'''
 assert text.count(old)==1;text=text.replace(old,lua)
 # Add passive actual first-step input, absolute coordinate, and both anchors;
 # original Right/doublejump/controller/400frame assertions stay unchanged.
 text=text.replace("hook('ArStep',function()sourceSteps=sourceSteps+1 end,1)","hook('ArStep',function()sourceSteps=sourceSteps+1 end,1)")
 text=text.replace("gameStart=frame;initialX=", "gameStart=frame;initialX=")
 controller=O/'native-controller-v3.lua';controller.write_text(text,newline='\n')
 (O/'native-controller-v3.patch').write_text(''.join(difflib.unified_diff((parent/'native-controller-v1.lua').read_text().splitlines(True),text.splitlines(True),fromfile='retained-native-negative',tofile='physical-clock-native-v2')),newline='\n')
 observer=R/'tools/audit/arthur_body_fair_native_v6.lua';sig=V.C.F.signature(b)
 size=int(b['syms']['GameLoop']['size'],0);stop=A.address(b,'GameLoop')+size-1
 driver=O/'native-driver-v3.lua';driver.write_text(f'ARTHUR_HOST_MAIN_EXIT={stop}\nARTHUR_HOST_ROM_SHA256="{B.sha(N/"candidate.nes")}"\nARTHUR_CACHE_CODE_SIZE=550\nARTHUR_CACHE_SIGNATURE={{{",".join(map(str,sig))}}}\nARTHUR_FAIR_ROM=[=[{(N/"candidate.nes").as_posix()}]=]\nARTHUR_FAIR_CHR_BASE=1048592\nARTHUR_FAIR_PRIORITY_RETURN={A.address(b,"PriorityReturn")}\ndofile([=[{observer.as_posix()}]=])\ndofile([=[{controller.as_posix()}]=])\n',newline='\n')
 budget_source=O/'native-capture-budget-v3.py';budget_source.write_bytes((parent/'native-capture-budget-v1.py').read_bytes());budget=Q.load(budget_source)
 target=O/'native/cold-physical-clock-v3';assert not target.exists();storage=budget.preflight(target,reserved_bytes=536870912,reserved_files=64);(O/'native-storage-preflight-v3.json').write_text(json.dumps(storage,indent=2)+'\n')
 config=dict(max_physical_frames=1200,physical_game_frames=400,screenshots=6,files=64,reserved_bytes=536870912,timeout_seconds=60,AllZeros=True,normal8sprites=True,script_RAM_writes=False)
 d=dict(status='PREPARED_NOT_RUN_AWAITING_ROOT_ONE_GRANT',candidate=B.sha(N/'candidate.nes'),source_handoff=B.sha(O/'handoff.json'),config=config,normal_options=['--doNotSaveSettings','--nes.removeSpriteLimit=false','--nes.ramPowerOnState=AllZeros','--nes.randomizeCpuPpuAlignment=false','--nes.randomizeMapperPowerOnState=false'],command='python tools/audit/run_arthur_physical_clock_native_v3.py --launch',exact_source_mailbox_writers=writers,clock_hook=dict(bank=70,PC=A.address(b,'ArHostNmiClock')+8192,window='C'),scope='Same controller and all original semantic assertions retained; exact new source clock C-mirror and authenticated mailbox-only writer allowance. Static cache/code guard remains strict. No source/RAM writes by script. Measure genuine active Main/NMI timing, blue world, HUD/source body/first8 and authored motion/doublejump/lance; no60Hz claim.')
 paths=[Path(__file__),R/'tools/audit/run_arthur_physical_clock_native_v3.py',controller,driver,observer,budget_source,O/'native-controller-v3.patch',O/'native-storage-preflight-v3.json',O/'handoff.json',R/'tools/run_mesen.py',R/'tools/audit/capture_budget.py',N/'candidate.nes',N/'candidate.dbg',N/'candidate.lbl']
 d['bindings']={str(p.resolve()):B.sha(p)for p in paths};out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(prepared=B.sha(out),candidate=d['candidate'],source=d['source_handoff'],config=config,writers=len(writers))))
if __name__=='__main__':main()
