"""Freeze actual clock-repair source and exact CPU receipts before native prep."""
from pathlib import Path
import json
import arthur_physical_clock_context_v2 as V
B=V.B;O=V.O;N=V.N;R=B.R;P=R/'build/celeste-menu-name-arthur-v2'
def main():
 out=O/'handoff.json';assert not out.exists()
 proofs=['constructor-first-proof.json','physical-clock-controls-v2.json','complete-Main-physical-clock-v2.json','foreign-Main-expanded-v2.json','presentation-foreign-NMI-physical-clock-v2.json','actual-physical-clock-ISR-v6.json','callbacks-allflags-v7.json','source-ownership-v2.json','extra-owner-cadence-controls-v2.json']
 for name in proofs:
  d=json.loads((O/name).read_text());assert d['passed'],name
  for p,v in d.get('bindings',{}).items():assert B.sha(p)==v,p
 parent=json.loads((P/'handoff.json').read_text())
 for p,v in parent['bindings'].items():assert B.sha(p)==v,p
 assert B.sha(N/'candidate.nes')=='1437f43b3327d2e213370779fc90c32a04208416c792031bae1175c8bacbbc10'
 paragraphs=[
 'Private source-linked Arthur physical-clock successor of frozen096300 ready53 plus exact Celeste menu label. Original d8f18 native controller failure remains immutable. Source physics/run/doublejump/weapons/fair renderer and allCHR, input2326, executable550, header and resource splits remain exact. A real NMI recorder updates only temporal RAM2 DFD0..<DFD5 while Main is busy, after full16cookie/raw32/gameplay/pause/player/valid checks and without reading Arthur5C. The original1..3phase remains; saturated Due and latest genuine native pad are consumed in Main. Original phase/pad mirrors remain foreground-owned. All oldDue producers are zero resets/death. New life/area/player reset clears mailboxvalid first and publishes it last before ReadyA7; retirement invalidates before owner publication. No RAM1/newglobalRAM/ZP/PRG lease.',
 'Nine exact CPU receipts pass: real menu/forcedblank loader/Ready-last; normal/lag busy/pause/fullcookie/player/mailvalid guards;400 declared physical events with134 source steps and doublejump;40 completeMain frames coupled to real serial-input NMI;132 immediate-parent foreign Main cases at0CPU delta;66 foreign NMIs;201 sourceRGB/alpha/priority and16backdrops;2304=36x64flags actual SFC service comparisons;real Main/poll/mapper/partial-pointer/maxstack/player-constructor NMI/IRQ cuts;actual four native player transpositions dropping old input/due. All33SMC/livepage1/R01/R67/maps and exact mailbox event model pass. Original native IRQ/sound staticpage1 producer writes are explicitly accounted against exact parent source. Fixture negatives for relocated pointers, metadata-only inline targets and native low-bank IRQ/audio remain retained.',
 'Owned sizes: A26main2262/2262, tail718/718, world640/646; C63large1454/1460,small1022/1023; C70own768/768; common511/512. Factoring20 setters saves98B and adds10CPU per selected setter; scratch pointer writes become high thenlow, both complete before dispatch, busy NMI never reads them. Callback delta0..197CPU. Source20Hz acceptance is CPU-proven, but native cadence must be measured and severe lag remains. No performance/campaign/earned-items/audio/admission/install claim. Newer root FF terrain/combat/palette/flash packets are not in this candidate; oldFF07cda behavior remains.',
 'Physical-clock-v1 wrong execution-window cold bridge and original d8f18 native negative are immutable. This exact new1437 candidate is source-ready for one separately granted bounded native controller successor.'
 ]
 (O/'README.txt').write_text('\n\n'.join(paragraphs)+'\n',encoding='utf-8',newline='\n')
 files=[p for p in O.rglob('*')if p.is_file()]
 files+=list((R/'tools/audit').glob('*arthur_physical_clock*.py'))+[P/'handoff.json',R/'build/arthur-expanded-ready-v2/native-negative-handoff-v1.json',R/'tools/prepare_cv3_dmc_mirror.py']
 d=dict(status='FROZEN_PRIVATE_PHYSICAL_CLOCK_SOURCE_READY_NATIVE_PENDING',candidate=B.sha(N/'candidate.nes'),parent=B.sha(P/'joint/candidate.nes'),native=False,admitted=False,ready_count=53,no_new_lease=True,RAM1=False,temporal_RAM2_mailbox=[0xdfd0,0xdfd5],proofs=proofs,bindings={str(p.resolve()):B.sha(p)for p in files})
 out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(handoff=B.sha(out),candidate=d['candidate'],bindings=len(d['bindings']))))
if __name__=='__main__':main()
