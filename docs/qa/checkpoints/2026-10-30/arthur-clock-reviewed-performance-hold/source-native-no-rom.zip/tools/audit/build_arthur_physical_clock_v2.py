"""Correct execution-window placement, preserving source-v1 bridge negative."""
from pathlib import Path
import json,shutil,subprocess
import build_arthur_physical_clock_v1 as B
R=B.R;P=B.O;J=B.N;O=R/'build/arthur-physical-clock-v2';N=O/'joint';sha=B.sha
def proc(s,name):
 a=s.index('.proc '+name);z=s.index('.endproc',a)+len('.endproc');return s[a:z]
def main():
 assert not O.exists();bound={str(p.resolve()):sha(p)for p in P.rglob('*')if p.is_file()};O.mkdir();shutil.copytree(J,N)
 def rewrite(s):return s.replace(str(J),str(N)).replace(J.as_posix(),N.as_posix())
 for p in N.rglob('*'):
  if p.is_file()and p.suffix in ['.s','.inc','.cfg']:
   s=p.read_text();v=rewrite(s)
   if s!=v:p.write_text(v,newline='\n')
 state=N/'arthur/host-state.s';own=N/'arthur/own-services.s';world=N/'arthur/host-world.s'
 a=state.read_text();b=own.read_text();c=world.read_text()
 poll=proc(a,'ArHostClockPoll').replace('.proc ArHostClockPoll','.proc ArClockPollC70')
 assert poll.count(' sta ArHostDue')==1;poll=poll.replace(' sta ArHostDue\n','')
 cold=proc(b,'ArClockColdC70').replace('.proc ArClockColdC70','ArHostInvalidateClock:sec\n.proc ArHostClockColdBridge')
 floor=proc(c,'ArHostFloorTile')
 a=a[:a.index('.segment "ARTHUR_CLOCK"')]+'.segment "ARTHUR_CLOCK"\n'+cold+'\n'+floor+'\n'
 a=a.replace('.import CurrentBank,CurrentBankC,ArClockColdC70','.import CurrentBank,CurrentBankC').replace('.export ArHostClockPoll,ArHostClockColdBridge,ArHostInvalidateClock','.export ArHostClockColdBridge,ArHostInvalidateClock')
 b=b.replace(proc(b,'ArClockColdC70'),poll).replace('.export ArHostNmiClock,ArClockColdC70','.export ArHostNmiClock,ArClockPollC70')
 c=c.replace('.import ArHostClockPoll\n','.import ArClockPollC70\n.export ArHostClockPoll\n').replace(floor,'')
 c+='''
.segment "ARTHUR_WORLD"
; Actual A26 execution survives C70 mapping; worker survives A2 mapping.
.proc ArHostClockPoll
 lda CurrentBankC
 pha
 lda #.lobyte(.bank(ArClockPollC70)|$80)
 sta CurrentBankC
 sta $5116
 jsr ArClockPollC70+$2000
 pla
 sta CurrentBankC
 sta $5116
 rts
.endproc
'''
 c='.import CurrentBankC\n'+c
 state.write_text(a,newline='\n');own.write_text(b,newline='\n');world.write_text(c,newline='\n')
 def run(cmd,phase):
  for flag in ['-o','-Ln','-m','--create-full-dep']:
   if flag in cmd:assert Path(cmd[cmd.index(flag)+1]).resolve().is_relative_to(N.resolve()),cmd
  for v in cmd:
   if v.startswith('--dbgfile,'):assert Path(v.split(',',1)[1]).resolve().is_relative_to(N.resolve())
  r=subprocess.run(cmd,cwd=R,capture_output=True,text=True);(N/(phase+'.json')).write_text(json.dumps(dict(command=cmd,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr),indent=2)+'\n');assert not r.returncode,r.stderr
 for phase in ['arthur-own-services','arthur-host-state','arthur-host-world']:
  run([rewrite(v)for v in json.loads((J/(phase+'-clock-build.json')).read_text())['command']],phase+'-clock2-build')
 run([rewrite(v)for v in json.loads((J/'clock-link.json').read_text())['command']],'clock2-link');B.B.prepare(R,N/'candidate.nes')
 b=B.B.scoped_load(N/'candidate.nes');sizes={s['name'].strip('"'):int(s['size'],0)for s in b['segs'].values()}
 for p,v in bound.items():assert sha(p)==v,p
 (O/'linked-stage.json').write_text(json.dumps(dict(native=False,candidate=sha(N/'candidate.nes'),parent=sha(J/'candidate.nes'),sizes=sizes,mailbox=[0xdfd0,0xdfd5],status='SOURCE_LINKED_CONTROLS_PENDING',source_v1_negative_preserved=True,parent_bindings=bound),indent=2)+'\n');print(json.dumps(dict(candidate=sha(N/'candidate.nes'),sizes={k:v for k,v in sizes.items()if'ARTHUR'in k or'AR_GEN'in k or k=='GIMMICK_COMMON_NMI'})))
if __name__=='__main__':main()
