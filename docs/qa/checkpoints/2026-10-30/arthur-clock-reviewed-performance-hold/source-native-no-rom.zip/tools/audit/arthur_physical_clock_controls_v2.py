"""Real linked mailbox/clock/Main ownership controls; explicit CPU schedules."""
from pathlib import Path
import itertools,json,traceback
import build_arthur_physical_clock_v2 as B
import arthur_expanded_controls_v3 as F
import arthur_joint_live_lifecycle_v5 as L
import arthur_joint_live_isr_v5 as I
A=F.A;O=B.O;N=B.N
def fresh(b):
 q=F.cold_fresh(b);F.enter(q);assert q.get('ArHostReady')==167;return q
def mailbox(q):return list(q.m.ram[2][0x1fd0:0x1fd5])
def static(q):return bytes(q.m.ram[2][:0x1fd0])+bytes(q.m.ram[2][0x1fd5:])
def electrical_nmi(q,g,keys):
 ty=type(q.m);get=ty.__getitem__;put=ty.__setitem__;at=[0];strobes=[]
 def read(m,i):
  if m is q.m and isinstance(i,int):
   if i==0x4016:
    bit=(keys>>(7-at[0]))&1 if at[0]<8 else 1;at[0]+=1;return bit
   if i==0x4017:return 0
  return get(m,i)
 def write(m,i,v):
  if m is q.m and i==0x4016:at[0]=0;strobes.append(v)
  return put(m,i,v)
 ty.__getitem__=read;ty.__setitem__=write
 try:z=g.nmi(q)
 finally:ty.__getitem__=get;ty.__setitem__=put
 return z,dict(port1_reads=at[0],strobes=strobes)
def main():
 out=O/'physical-clock-controls-v2.json';assert not out.exists();d=dict(passed=False,native=False,checks={})
 try:
  b=A.scoped_load(N/'candidate.nes');g=L.L.load_nmi(b);base=fresh(b);assert mailbox(base)==[1,0,0,0,167]
  d['checks']['actual_constructor_ready_last']=dict(ready=base.get('ArHostReady'),PPU_reads=base.m.ppu_reads,mailbox=mailbox(base))
  # Entire native NMI, genuine serial pad reads. Lag keeps the last native pad.
  rows=[]
  for lag,busy,pause in itertools.product([0,255],[0,1,3,5],[0,1]):
   q=I.clone(base);q.put(NmiDisable=lag,FamilyMainCommit=busy,GamePauseStatus=pause,SavedJoypad1Bits=129,VRAM_Buffer_AddrCtrl=0,VRAM_Buffer1_Offset=0)
   before=static(q);rw=len(q.m.ram_writes)
   (z,port),reads,exe=L.observe(q,lambda:electrical_nmi(q,g,129))
   assert static(q)==before,('staticcache mutation',lag,busy,pause)
   if busy&1:assert not reads,('busyAr5C read',lag,busy,pause,reads[:5])
   if pause:assert mailbox(q)==[1,0,0,0,167]
   else:assert mailbox(q)==[3,1,129,0,167],(lag,busy,pause,mailbox(q),port,q.get('SavedJoypad1Bits'))
   assert all(bank==2 and 0x1fd0<=off<0x1fd5 for bank,off,v in q.m.ram_writes[rw:])
   if lag==0 and not pause:assert port['port1_reads']==8 and q.get('SavedJoypad1Bits')==129
   rows.append(dict(lag=lag,busy=busy,pause=pause,mailbox=mailbox(q),port=port,CPU=z['CPU'],minSP=z['minimum_SP']))
  d['checks']['actual_normal_lag_NMI_busy_before_Ar5C']=rows
  guards=[]
  cases=[('raw',dict(SelectedCharacter=0)),('title',dict(OperMode=0)),('auto',dict(GameEngineSubroutine=4)),('pause',dict(GamePauseStatus=1)),('player',dict(CurrentPlayer=1))]
  for name,values in cases:
   q=I.clone(base);q.put(FamilyMainCommit=1,NmiDisable=255);q.put(**values);old=mailbox(q);rw=len(q.m.ram_writes)
   z,reads,_=L.observe(q,lambda:g.nmi(q));assert not reads and mailbox(q)==old and len(q.m.ram_writes)==rw,(name,reads[:4],mailbox(q))
   guards.append(name)
  for i in range(17):
   q=I.clone(base);q.put(FamilyMainCommit=1,NmiDisable=255);old=mailbox(q)
   if i==16:q.m.ram[2][0x1fd4]=0;old=mailbox(q)
   else:q.m.ram[2][0x1fe0+i]^=1
   rw=len(q.m.ram_writes);z,reads,_=L.observe(q,lambda:g.nmi(q));assert not reads and mailbox(q)==old and len(q.m.ram_writes)==rw,('cookie/valid',i,reads[:4],mailbox(q));guards.append('cookie'+str(i))
  d['checks']['owner_context_all16cookiebytes_and_mailvalid_guard']=guards
  # Physical mailbox ticks every event even when Main is busy. Declared input
  # sampling schedule follows native normal/lag rule; no Due/Pad forcing.
  cases=[]
  for interval in [3,1]:
   q=fresh(b);q.put(OperMode=1,GameEngineSubroutine=8,GamePauseStatus=0,TimerControl=0,Player_CollisionBits=255);steps=[];maxjump=0;writes=[];cache=static(q)
   for age in range(1,401):
    keys=(128 if 20<=age<26 or 38<=age<44 else 0)|(1 if 100<=age<180 else 0)|(64 if 80<=age<260 and age%18<6 else 0);normal=(age-1)%interval==0
    if normal:q.put(SavedJoypad1Bits=keys)
    q.put(FamilyMainCommit=0 if normal else 1);before=mailbox(q);_,_,_=A.call(q,'ArGenClockIngress');after=mailbox(q)
    assert before!=after or after[1]==1
    q.put(FamilyMainCommit=1);_,tr,_=A.owned(q,'ArHostMovement')
    if A.point(b,'ArStep')in tr:steps.append([age,q.get('ArHostPad'),q.get('ArR_00CC'),q.get('ArNewButtons'),q.get('ArJumpCount'),q.get('Player_X_Position')])
    maxjump=max(maxjump,q.get('ArJumpCount'));assert q.get('ArHostDue')==0
   assert len(steps)==134 and maxjump==2,(interval,len(steps),maxjump)
   assert static(q)==cache
   cases.append(dict(normal_interval_PPU=interval,source_steps=len(steps),max_jump=maxjump,rows=steps))
  d['checks']['physical20Hz_without_forcing_Due_or_Pad']=cases
  # Saturation and player/life resets cannot replay old player's pending input.
  q=fresh(b);q.put(SavedJoypad1Bits=128,FamilyMainCommit=1)
  for _ in range(30):A.call(q,'ArGenClockIngress')
  assert mailbox(q)[1]==1
  q.put(CurrentPlayer=1,NumberofLives=4);A.owned(q,'ArHostEnsure');assert mailbox(q)==[1,0,0,1,167]
  _,tr,_=A.owned(q,'ArHostMovement');assert A.point(b,'ArStep')not in tr and q.get('ArJumpCount')==0
  q.put(NumberofLives=3);A.owned(q,'ArHostEnsure');assert mailbox(q)==[1,0,0,1,167]
  q.put(CrossoverMenuIndex=0,FamilyMainCommit=1);A.call(q,'MenuResolveCharacter');assert q.get('SelectedCharacter')==0 and q.m.ram[2][0x1fd4]==0 and q.m.ram[2][0x1fe0]==0
  d['checks']['saturating_due_player_life_and_retire']=True
  d.update(passed=True,limits=['Real linked CPU source and entire normal/lag NMI; declared physical/controller schedule is not native cadence.','Cadence fixture uses owned movement API and omits nativeBG; no native pixel-distance equivalence claimed.','FullMain flags/foreign/ISR cuts and native qualification remain separate work.'])
 except Exception as e:d.update(error=repr(e),traceback=traceback.format_exc())
 d['bindings']={str(p.resolve()):B.sha(p)for p in [Path(__file__),Path(F.__file__),N/'candidate.nes',N/'candidate.dbg',O/'linked-stage.json']};out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items()if k not in ['bindings','traceback','checks']}));assert d['passed'],d.get('error')
if __name__=='__main__':main()
