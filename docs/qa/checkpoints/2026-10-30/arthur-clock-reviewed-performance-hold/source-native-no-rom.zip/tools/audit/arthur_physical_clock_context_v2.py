"""Current physical-clock source context; cache genuine code-label lookups."""
import build_arthur_physical_clock_v2 as B
import arthur_physical_clock_controls_v2 as C
A=C.A; O=B.O; N=B.N
_code_label=A.M.code_label
_labels={}
def cached_label(b,bank,pc,exact=False):
 key=(id(b),bank,pc,exact)
 if key not in _labels:_labels[key]=_code_label(b,bank,pc,exact)
 return _labels[key]
A.M.code_label=cached_label
