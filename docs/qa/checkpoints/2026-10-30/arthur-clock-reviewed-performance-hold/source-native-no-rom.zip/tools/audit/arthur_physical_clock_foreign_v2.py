"""Actual complete foreign Main against immediate, immutable name/Ar parent."""
from pathlib import Path
import json
import arthur_physical_clock_context_v2 as V
import arthur_expanded_foreign_v2 as F
F.V=V; F.A=V.A; F.B=V.B; F.O=V.O; F.N=V.N
F.P=V.B.R/'build/celeste-menu-name-arthur-v2/joint'
if __name__=='__main__':F.main()
