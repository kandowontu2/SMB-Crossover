"""Freeze one exact passing native run, performance hold and original negative."""
from pathlib import Path
import hashlib,json,zipfile
import arthur_physical_clock_context_v2 as V
B=V.B;R=B.R;O=V.O;N=V.N;T=O/'native/cold-physical-clock-v3'
def main():
 out=O/'native-handoff-v3.json';assert not out.exists()
 h=json.loads((O/'handoff.json').read_text());p=json.loads((O/'native-prepared-v3.json').read_text())
 for d in[h,p]:
  for name,v in d['bindings'].items():assert B.sha(name)==v,name
 post=json.loads((O/'native-postflight-v3.json').read_text());assert post['exit_code']==0 and post['all_bindings_unchanged']
 result=json.loads((T/'result.json').read_text());timing=json.loads((T/'timing.json').read_text());fair=json.loads((T/'fair-body-native.json').read_text())
 assert result['passed']and result['controlled_game_frames']==400 and result['max_jump_count']==2 and result['right_pixels']>=25 and result['active_ppu_writes']==0
 assert timing['source_steps']==134 and timing['clock_calls']==400 and fair['passed']and fair['normal_eight_sprite_limit']
 old=R/'build/arthur-expanded-ready-v2'
 oldnegative=json.loads((old/'native-negative-handoff-v1.json').read_text())
 for name,v in oldnegative['bindings'].items():assert B.sha(name)==v,name
 previous=json.loads((old/'native/cold-ready53-v1/timing-at-visibility.json').read_text());current=json.loads((T/'timing-at-visibility.json').read_text())
 comparison=dict(physical_game_frames=300,source_steps=[previous['source_steps'],current['source_steps']],clock_calls=[previous['clock_calls'],current['clock_calls']],draws=[previous['draws'],current['draws']],lag_NMIs=[previous['lag_NMIs'],current['lag_NMIs']],foreground_mean_delta=current['timing']['foreground']['mean']-previous['timing']['foreground']['mean'],foreground_max_delta=current['timing']['foreground']['max']-previous['timing']['foreground']['max'],lag_NMI_mean_delta=current['timing']['lag_nmi']['mean']-previous['timing']['lag_nmi']['mean'])
 shots=[T/(n+'.png')for n in['menu-arthur','lives-arthur','game-start','double-jump','source-lance','game-controlled']]
 # A review artifact contains every original whole screenshot at original
 # resolution. Pixels in each source image are copied without correction.
 from PIL import Image,ImageDraw
 sheet=Image.new('RGB',(512,780),(24,24,24));draw=ImageDraw.Draw(sheet)
 for i,path in enumerate(shots):
  im=Image.open(path);assert im.size==(256,240);x=(i%2)*256;y=(i//2)*260;draw.text((x+4,y+3),path.stem,fill='white');sheet.paste(im,(x,y+20))
 review=O/'native-whole-frame-review-v3.png';sheet.save(review)
 summary=dict(status='NATIVE_CONTROLLER_GRAPHICS_PASS_SEVERE_PERFORMANCE_HOLD',candidate=h['candidate'],source_handoff=B.sha(O/'handoff.json'),native=True,installed=False,result=result,timing=timing,fair_body=fair,same_controller_matched_300frame_comparison=comparison,original_failure_retained=B.sha(old/'native-negative-handoff-v1.json'),source_physics_and_controller_unchanged=True,screenshots=[str(x.resolve())for x in shots],limits=['One cold selector/lives/1-1 smoke only; no campaign/earned-upgrades/audio completion.','266lagNMIs/400PPU remain severe. Source20Hz physical acceptance is restored; Main and drawing cadence are not improved.','Initial game-start capture precedes the first rendered source update; subsequent source body/ink/hardware tests pass.','Inherited cyan menu band remains. Static gold menu portrait and original blue lives palette have distinct source contexts.','Root whole-frame review and separate installation authorization are required; no Downloads changed.'])
 (O/'native-summary-v3.json').write_text(json.dumps(summary,indent=2)+'\n')
 files=list(T.rglob('*'));files=[x for x in files if x.is_file()]
 assert len(files)<=64 and sum(x.stat().st_size for x in files)<=536870912
 files +=[Path(__file__),R/'tools/audit/prepare_arthur_physical_clock_native_v3.py',R/'tools/audit/run_arthur_physical_clock_native_v3.py',O/'native-prepared-v3.json',O/'native-driver-v3.lua',O/'native-controller-v3.lua',O/'native-controller-v3.patch',O/'native-capture-budget-v3.py',O/'native-storage-preflight-v3.json',O/'native-preflight-v3.json',O/'native-postflight-v3.json',O/'native-summary-v3.json',review,O/'handoff.json']
 d=dict(**summary,bindings={str(x.resolve()):B.sha(x)for x in files})
 out.write_text(json.dumps(d,indent=2)+'\n')
 CP=R/'docs/qa/checkpoints/2026-10-30/arthur-physical-clock'
 assert not CP.exists();CP.mkdir(parents=True)
 README='Arthur physical clock/source acceptance repair. Exact ROM1437f43b, source handoff505c20f7, one root-granted native run EXIT0. Same controller400PPU:134source steps from400physical NMI calls,85Right pixels,64jump pixels/maxJump2, original lance path,0active-display uploads, six whole screenshots. All original assertions retained. Fair135permutations/401DMAfirst8/39253source-black pixels/max11records. NativeMain266 samples mean31881.380/max43410;266lagNMIs remain a severe performance hold. Matched300 comparison restores34->100 source steps while drawing100/lag200 remain unchanged; Mainmean adds1257.250CPU and lagNMImean403CPU. Current original d8f18 failure/source are immutable. Installeda7cc52 remains untouched. Arthur53 uses current-source frontend and CPU-qualified original physics/cache/palette plus a five-byte temporalRAM2 physical clock mailbox; no newlease/RAM1. Newer rootFF packets are separate future source composition.\n'
 (CP/'README.txt').write_text(README,encoding='utf-8',newline='\n')
 archive=CP/'source-native-evidence.zip'
 own_tools=[x for x in(R/'tools/audit').glob('*arthur_physical_clock*.py')]
 payload=[x for x in O.rglob('*')if x.is_file()]+own_tools
 with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as z:
  for x in sorted(set(payload)):z.write(x,x.relative_to(R).as_posix())
 manifest=dict(status=summary['status'],candidate=h['candidate'],source_handoff=B.sha(O/'handoff.json'),native_handoff=B.sha(out),evidence=dict(path=archive.name,sha256=B.sha(archive),bytes=archive.stat().st_size),summary=summary,own_tools=[str(x.relative_to(R))for x in own_tools],checkpoint_files=['README.txt','source-native-evidence.zip','manifest.json'])
 (CP/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
 print(json.dumps(dict(native_handoff=B.sha(out),bindings=len(d['bindings']),checkpoint=str(CP),manifest=B.sha(CP/'manifest.json'),archive_bytes=archive.stat().st_size,result=result,performance_hold=True)))
if __name__=='__main__':main()
