"""Output-scope guard retained inherited-path negative before compiling."""
from pathlib import Path
import json,subprocess
import build_arthur_physical_clock_v1 as B
R=B.R;O=B.O;N=B.N;J=B.J;sha=B.sha
def main():
 assert not(O/'linked-stage.json').exists()
 h=json.loads((B.P/'handoff.json').read_text())
 for p,v in h['bindings'].items():assert sha(p)==v,p
 (O/'output-scope-negative.json').write_text(json.dumps(dict(native=False,compiler_launched=False,error='Inherited per-module buildJSON still named frozen arthurexpandedreadyv2 outputs. Scope assertion rejected BEFOREsubprocess. New resume binds/replaces both real ancestor paths and validates all output destinations; all frozen bindings verified unchanged.'),indent=2)+'\n')
 def rewrite(s):
  for old in [J,R/'build/arthur-expanded-ready-v2/joint']:
   s=s.replace(str(old),str(N)).replace(old.as_posix(),N.as_posix())
  return s
 for p in N.rglob('*'):
  if p.is_file()and p.suffix in ['.s','.inc','.cfg']:
   s=p.read_text();v=rewrite(s)
   if s!=v:p.write_text(v,newline='\n')
 def run(cmd,phase):
  for flag in ['-o','-Ln','-m','--create-full-dep']:
   if flag in cmd:assert Path(cmd[cmd.index(flag)+1]).resolve().is_relative_to(N.resolve()),cmd
  for v in cmd:
   if v.startswith('--dbgfile,'):assert Path(v.split(',',1)[1]).resolve().is_relative_to(N.resolve())
  r=subprocess.run(cmd,cwd=R,capture_output=True,text=True);(N/(phase+'.json')).write_text(json.dumps(dict(command=cmd,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr),indent=2)+'\n');assert not r.returncode,r.stderr
 for phase in ['arthur-own-services','arthur-host-state','arthur-host-world','arthur-component','arthur-host-adapter','arthur-host-render','generation-predicates']:
  run([rewrite(v)for v in json.loads((J/(phase+'-build.json')).read_text())['command']],phase+'-clock-build')
 run([rewrite(v)for v in json.loads((J/'label-link.json').read_text())['command']],'clock-link');B.B.prepare(R,N/'candidate.nes')
 b=B.B.scoped_load(N/'candidate.nes');sizes={s['name'].strip('"'):int(s['size'],0)for s in b['segs'].values()}
 for p,v in h['bindings'].items():assert sha(p)==v,p
 (O/'linked-stage.json').write_text(json.dumps(dict(native=False,candidate=sha(N/'candidate.nes'),parent=sha(J/'candidate.nes'),sizes=sizes,mailbox=[0xdfd0,0xdfd5],status='SOURCE_LINKED_CONTROLS_PENDING'),indent=2)+'\n');print(json.dumps(dict(candidate=sha(N/'candidate.nes'),sizes={k:v for k,v in sizes.items()if'ARTHUR'in k or'AR_GEN'in k or k=='GIMMICK_COMMON_NMI'})))
if __name__=='__main__':main()
