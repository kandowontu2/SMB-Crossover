"""Actual SFC 36-service ABI; explicit private-pointer relocation accounting."""
from pathlib import Path
import itertools,json,traceback
import arthur_physical_clock_context_v2 as V
import arthur_joint_live_isr_v5 as I
import ff_ram3_execution_controls_v2 as E
from arthur_physical_clock_controls_v2 import fresh
from sunny_integrated_controls_v1 import registers,smc_at
A=V.A;B=V.B;O=V.O;N=V.N;P=B.R/'build/celeste-menu-name-arthur-v2/joint'
def service(q,row,p):
 c=E.start(q.m,'ArOwnServices',a=85,x=0,y=3,p=p,sp=224);c.a=A.point(q.b,'ArOwnServices')[0]|128
 at=A.address(q.b,'FarcallJmpTarget_SMC');target=A.address(q.b,'ArOwnServices')+3*row;q.m[at+1]=target&255;q.m[at+2]=target>>8
 low=c.sp;tr=[]
 for i in range(300000):
  if c.pc==0x5b00:break
  low=min(low,c.sp);bank=q.m.rawtags[(c.pc-32768)//8192]if c.pc>=32768 else-1;tr.append((bank&127,c.pc));assert q.m[c.pc],('BRK',row,hex(c.pc),bank);c.step()
 else:raise AssertionError(('bounded callback',row,hex(c.pc)))
 assert c.sp==224;return c,tr,low
def main():
 out=O/'callbacks-allflags-v6.json';assert not out.exists();d=dict(passed=False,native=False,rows=[])
 try:
  old,b=[A.scoped_load(p/'candidate.nes')for p in[P,N]];bases=[fresh(v)for v in[old,b]]
  flags=[0x30|sum(((v>>i)&1)*bit for i,bit in enumerate([1,2,4,8,64,128]))for v in range(64)]
  for row,p in itertools.product(range(36),flags):
   pair=[]
   for base in bases:
    q=I.clone(base);q.put(FamilyMainCommit=1,NmiDisable=255,VRAM_Buffer1_Offset=0);c,tr,low=service(q,row,p);pair.append((q,c,tr,low))
   qa,ca,ta,la=pair[0];qb,cb,tb,lb=pair[1]
   assert registers(ca)==registers(cb),('AXYP/SP',row,p,registers(ca),registers(cb))
   aa,bb=A.C.M.fastapp(qa),A.C.M.fastapp(qb)
   relocated=None
   if aa!=bb:
    at=A.address(old,'ArDrawPtr');va=qa.m[at]+256*qa.m[at+1];vb=qb.m[at]+256*qb.m[at+1]
    names=[n for n in old['syms']if n in b['syms']and '::'not in n and old['syms'][n].get('type')=='lab'and int(old['syms'][n].get('val','-1'),0)==va and A.address(b,n)==vb]
    reached=[]
    for name in names:
     try:
      if A.point(old,name)in ta and A.point(b,name)in tb:reached.append(name)
      elif name in ['ArHostVisible','ArHostNoop','ArHostBoxProfile','ArHostBodyPolicy','ArHostAdder','ArHostUi']:
       size=int(old['syms'][name]['size'],0);assert b['syms'][name]['size']==old['syms'][name]['size']
       assert old['raw'][A.location(old,name):A.location(old,name)+size]==b['raw'][A.location(b,name):A.location(b,name)+size]
       reached.append('source-identical inline policy pointer:'+name)
     except KeyError:pass
    assert reached,('unproved private pointer relocation',row,p,hex(va),hex(vb),names)
    zz=bytearray(aa);offset=0x1f00+at-0x5c00;zz[offset:offset+2]=bytes([vb&255,vb>>8]);assert bytes(zz)==bb,('remaining application',row,p,A.M.different(bytes(zz),bb));relocated=reached
   for bank in range(4):
    if bank==2:
     assert bytes(qa.m.ram[bank][:0x1fd0])==bytes(qb.m.ram[bank][:0x1fd0])and bytes(qa.m.ram[bank][0x1fd5:])==bytes(qb.m.ram[bank][0x1fd5:]),('static RAM2',row,p)
    else:assert qa.m.ram[bank]==qb.m.ram[bank],('RAM bank',row,p,bank)
   assert qa.m.rawtags==qb.m.rawtags,('raw maps',row,p)
   try:A.M.smc_contract(qa,qb,ta,tb)
   except AssertionError:
    assert row in [9,11,12,13,21,22,23,27,28,29,31,33,34,35],('unexpected synthetic metadata row',row,p)
    va=[qa.m[i]for i in smc_at(old)];vb=[qb.m[i]for i in smc_at(b)]
    assert va[:2]==vb[:2]and va[4:]==vb[4:]and va[2]+256*va[3]==A.address(old,'ArDispatch')and vb[2]+256*vb[3]==A.address(b,'ArDispatch'),('genuine inline policy metadata',row,p,va,vb)
   d['rows'].append([row,p,cb.processorCycles-ca.processorCycles,min(la,lb),relocated])
  d.update(passed=True,cases=len(d['rows']),CPU_delta=[min(z[2]for z in d['rows']),max(z[2]for z in d['rows'])])
 except Exception as e:d.update(error=repr(e),traceback=traceback.format_exc())
 d['bindings']={str(p.resolve()):B.sha(p)for p in[Path(__file__),P/'candidate.nes',P/'candidate.dbg',N/'candidate.nes',N/'candidate.dbg']};out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items()if k not in['bindings','traceback','rows']}));assert d['passed'],d.get('error')
if __name__=='__main__':main()
