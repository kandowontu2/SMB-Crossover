"""Actual vector cuts: only authenticated five-byte physical clock may change."""
from pathlib import Path
import itertools,json,traceback
import arthur_physical_clock_context_v2 as V
import arthur_joint_live_isr_v5 as I
import ff_ram3_execution_controls_v2 as E
from arthur_physical_clock_controls_v2 import fresh,mailbox
from verify_native_relocation import NesMPU
A=V.A;B=V.B;O=V.O;N=V.N
def interrupt(m,c,kind):
 b=m.bundle;get=lambda n:E.get(m,n)
 live_zp=kind=='IRQ'or get('NmiDisable')!=0
 before=(E.cpu_state(c),m.rawtags[:],get('CurrentBank'),get('CurrentBankC'),bytes(m[0x15a:0x17b]),bytes(m[0x101+c.sp:0x200]),bytes(m[:256]),[bytes(x)for x in m.ram])
 expected=m.rawtags[:]
 for slot,name,op in[(1,'CurrentBank',b'\x8d\x15\x51'),(2,'CurrentBankC',b'\x8d\x16\x51')]:
  if kind=='NMI'and expected[slot]!=get(name):
   assert bytes(m[c.pc:c.pc+3])==op,('unclassified pending hardware store',hex(c.pc));expected[slot]=get(name)
 oldcycles=c.processorCycles;low=c.sp
 if kind=='NMI':c.nmi()
 else:assert not c.p&c.INTERRUPT;c.irq()
 for steps in range(100000):
  if E.cpu_state(c)==before[0]:break
  low=min(low,c.sp);assert m[c.pc],('actual ISR BRK',kind,hex(c.pc),m.rawtags);c.step()
 else:raise AssertionError(('actual ISR did not RTI',kind,E.cpu_state(c),before[0]))
 assert m.rawtags==expected and[get('CurrentBank'),get('CurrentBankC')]==list(before[2:4])
 assert bytes(m[0x15a:0x17b])==before[4],('all33SMC',kind)
 assert bytes(m[0x101+c.sp:0x200])==before[5],('live page1',kind)
 assert bytes(m[3:5])==before[6][3:5]and bytes(m[9:11])==before[6][9:11],('borrowed R0/R1/R6/R7',kind)
 if live_zp:
  changed=[i for i,(a,z)in enumerate(zip(before[6],m[:256]))if a!=z]
  audio=range(A.address(b,'XgAudioPtr'),A.address(b,'XgAudioZeroPageEnd'))
  assert all(kind=='NMI'and i in audio for i in changed),('live foreground ZP',kind,changed)
 bank2=bytearray(before[7][2]);mail=list(bank2[0x1fd0:0x1fd5]);signature=V.C.F.signature(b)
 eligible=(kind=='NMI'and get('SelectedCharacter')==32 and get('OperMode')==1 and get('GameEngineSubroutine')==8 and not(get('GamePauseStatus')&1)and bytes(bank2[0x1fe0:0x1ff0])==signature and mail[4]==167 and mail[3]==get('CurrentPlayer'))
 if eligible:
  mail[0]=(mail[0]-1)&255
  if mail[0]==0:mail[0]=3;mail[1]=1
  mail[2]=m[A.address(b,'SavedJoypad1Bits')+get('CurrentPlayer')]
 bank2[0x1fd0:0x1fd5]=bytes(mail);expected_payload=before[7][:];expected_payload[2]=bytes(bank2)
 assert[bytes(x)for x in m.ram]==expected_payload,('ISR payload outside exact clock model',kind,eligible)
 return dict(kind=kind,CPU=c.processorCycles-oldcycles,minimum_SP=low,raw_maps=m.rawtags[:],mailbox=mail,clock_event=eligible,AXYP_SP_SMC33_page1_R0_R1_R6_R7_exact=True)
def main():
 out=O/'actual-physical-clock-ISR-v2.json';assert not out.exists();d=dict(passed=False,native=False,checks={})
 try:
  b=A.scoped_load(N/'candidate.nes');base=fresh(b);base.put(FamilyMainCommit=1,NmiDisable=255,SavedJoypad1Bits=129,SavedJoypadBits=129,VRAM_Buffer_AddrCtrl=0,VRAM_Buffer1_Offset=0)
  A.call(base,'ArGenClockIngress')
  rows=[];old=I.E.interrupt;I.E.interrupt=interrupt
  try:
   for name in['ArGenValidate','ArGenCheckForeground::Loop','ArHostClockPoll','ArClockPollC70','ArHostMovement','ArStep','ArHostAfterTerrain','ArGenDrawAll','ArHostDrawAll','ArCacheEmit']:
    bank,pc=A.point(b,name)
    if name=='ArClockPollC70':pc+=0x2000
    if name=='ArCacheEmit':bank=2
    for lag,kind in itertools.product([0,255],['NMI','IRQ']):
     q=I.clone(base);q.put(NmiDisable=lag);c=I.start(q,'GameLoop')
     p,low=I.run(q,c,lambda q,c,raw:(raw&127,c.pc)==(bank,pc),kind)
     assert p is not None,('cut not reached',name,bank,hex(pc));rows.append(dict(entry=name,lag=lag,min_complete_SP=low,**p))
   # Every instruction of the exact clock poll, both partial pointer writes,
   # all shadow/hardware seams, and maximum fair stack depth in complete Main.
   q=I.clone(base);c=I.start(q,'GameLoop');cuts=[];maxdepth=(0,255)
   poll=A.point(b,'ArClockPollC70')[1]+0x2000
   for k in range(300000):
    if c.pc==0x5b00:break
    raw=q.m.rawtags[(c.pc-32768)//8192]if c.pc>=32768 else-1
    if c.sp<maxdepth[1]:maxdepth=(k,c.sp)
    if(raw&127==70 and poll<=c.pc<poll+70)or(raw&127==70 and bytes(q.m[c.pc:c.pc+3])in[b'\x8d\x15\x51',b'\x8d\x16\x51',b'\x8d\x88\x5c',b'\x8d\x89\x5c']):cuts.append((k,c.pc))
    c.step()
   else:raise AssertionError('bounded complete Main')
   cuts.append((maxdepth[0],-1));seams=[]
   for k,pc in sorted(set(cuts)):
    for lag,kind in itertools.product([0,255],['NMI','IRQ']):
     q=I.clone(base);q.put(NmiDisable=lag);c=I.start(q,'GameLoop')
     for _ in range(k):c.step()
     if kind=='IRQ'and c.p&c.INTERRUPT:continue
     z=interrupt(q.m,c,kind);I.run(q,c);seams.append(dict(step=k,PC=c.pc,lag=lag,**z))
   d['checks']['complete_Main_named_source_cache_render']=rows
   d['checks']['poll_mapper_partialpointer_and_maxstack_seams']=dict(cuts=len(cuts),vectors=seams,max_foreground_stack=maxdepth[1])
  finally:I.E.interrupt=old
  d.update(passed=True,limits=['Actual linked normal/lag NMI and IRQ CPU execution, exact five-byte mailbox model; no native cadence claim.'])
 except Exception as e:d.update(error=repr(e),traceback=traceback.format_exc())
 d['bindings']={str(p.resolve()):B.sha(p)for p in[Path(__file__),Path(I.__file__),N/'candidate.nes',N/'candidate.dbg']};out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items()if k not in['bindings','traceback','checks']}));assert d['passed'],d.get('error')
if __name__=='__main__':main()
