"""One separately granted native clock-repair smoke; no automatic retry."""
import json,os,sys
import arthur_physical_clock_context_v2 as V
import arthur_body_fair_budget_v7 as Q
B=V.B;O=V.O;N=V.N;TARGET=O/'native/cold-physical-clock-v3'
def main():
 assert sys.argv[1:]==['--launch'],'Requires explicit root one-run grant.'
 assert not TARGET.exists(),'Retain result; no automatic retry.'
 p=json.loads((O/'native-prepared-v3.json').read_text());h=json.loads((O/'handoff.json').read_text())
 def verify():
  for d in[p,h]:
   for name,v in d['bindings'].items():assert B.sha(name)==v,name
  assert p['candidate']==B.sha(N/'candidate.nes')=='1437f43b3327d2e213370779fc90c32a04208416c792031bae1175c8bacbbc10'
 verify();TARGET.parent.mkdir(exist_ok=True);budget=Q.load(O/'native-capture-budget-v3.py');run=Q.run_function(budget)
 pre=dict(passed=True,candidate=p['candidate'],source_handoff=p['source_handoff'],prepared=B.sha(O/'native-prepared-v3.json'),bindings_verified=len(p['bindings'])+len(h['bindings']),config=p['config'])
 (O/'native-preflight-v3.json').write_text(json.dumps(pre,indent=2)+'\n');os.environ['SMB_RUN_OUTPUT']=str(TARGET.resolve())
 rc=run(O/'native-driver-v3.lua',N/'candidate.nes',timeout=60,emulator_options=p['normal_options'])
 verify();(O/'native-postflight-v3.json').write_text(json.dumps(dict(**pre,exit_code=rc,all_bindings_unchanged=True),indent=2)+'\n');print(json.dumps(dict(native_terminal=True,exit_code=rc,candidate=p['candidate'],output=str(TARGET),bindings_pass=True)),flush=True);raise SystemExit(rc)
if __name__=='__main__':main()
