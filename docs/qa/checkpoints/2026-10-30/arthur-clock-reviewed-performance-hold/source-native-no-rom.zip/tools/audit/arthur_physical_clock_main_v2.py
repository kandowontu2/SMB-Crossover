"""Genuine complete Main fed only by native serial-input NMI/mailbox events."""
from pathlib import Path
import json,traceback
import arthur_physical_clock_context_v2 as V
from arthur_physical_clock_controls_v2 import fresh,electrical_nmi,mailbox,static
A=V.A;B=V.B;O=V.O;N=V.N
def main():
 out=O/'complete-Main-physical-clock-v2.json';assert not out.exists();d=dict(passed=False,native=False,checks={})
 try:
  b=A.scoped_load(N/'candidate.nes');g=V.C.L.L.load_nmi(b);q=fresh(b);payload=static(q);rows=[];steps=[];maxjump=0
  # Declared physical schedule: one completed foreground frame per three NMI
  # events. Normal NMI reads actual serial bits; two lag NMIs keep native pad.
  # No writes to source Due/Pad, mailbox, source buttons, or source physics.
  for age in range(1,121):
   keys=(128 if 20<=age<26 or 38<=age<44 else 0)|(1 if 55<=age<110 else 0)|(64 if 65<=age<110 else 0)
   normal=(age-1)%3==0
   q.put(NmiDisable=0 if normal else 255,FamilyMainCommit=0 if normal else 1,VRAM_Buffer_AddrCtrl=0,VRAM_Buffer1_Offset=0)
   electrical_nmi(q,g,keys)
   if not normal:continue
   q.put(NmiDisable=255,FamilyMainCommit=1,VRAM_Buffer_AddrCtrl=0,VRAM_Buffer1_Offset=0)
   c,tr,mn,ann,events=A.M.run_linked(q,'GameLoop')
   tick=tr.count(A.point(b,'ArStep'));draw=tr.count(A.point(b,'ArHostDrawAll'))
   assert tick<=1 and draw==1,('once per Main',age,tick,draw)
   assert q.get('ArHostReady')==167 and q.get('ArHostDue')==0
   assert static(q)==payload,('static cache/code/cookie',age)
   if tick:steps.append([age,q.get('ArHostPad'),q.get('ArNewButtons'),q.get('ArJumpCount')])
   maxjump=max(maxjump,q.get('ArJumpCount'))
   rows.append([age,c.processorCycles,mn,tick,draw,*mailbox(q),q.get('Player_X_Position'),q.get('Player_Y_Position')])
  assert len(rows)==40 and len(steps)==40 and maxjump==2,(len(rows),len(steps),maxjump)
  d['checks']['complete_Main_real_serial_NMI_saturated_mailbox']=dict(frames=len(rows),source_steps=len(steps),max_jump=maxjump,CPU=[min(r[1]for r in rows),max(r[1]for r in rows)],rows=rows,steps=steps)
  d.update(passed=True,limits=['Actual linked Main and native NMI CPU execution under an explicit normal/lag schedule; not native cadence.','Flat native block-buffer fixture; source movement/renderer/hardware qualification remains separate.'])
 except Exception as e:d.update(error=repr(e),traceback=traceback.format_exc())
 d['bindings']={str(p.resolve()):B.sha(p)for p in[Path(__file__),N/'candidate.nes',N/'candidate.dbg',Path(V.__file__)]};out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items()if k not in['bindings','traceback','checks']}));assert d['passed'],d.get('error')
if __name__=='__main__':main()
