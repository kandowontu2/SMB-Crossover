"""Private physical-NMI mailbox successor inside existing Arthur owner spans."""
from pathlib import Path
import json,re,shutil,subprocess
import build_celeste_exact_menu_name_v3 as B
R=B.R;P=R/'build/celeste-menu-name-arthur-v2';J=P/'joint';O=R/'build/arthur-physical-clock-v1';N=O/'joint';sha=B.sha
def main():
 assert not O.exists();h=json.loads((P/'handoff.json').read_text())
 for p,v in h['bindings'].items():assert sha(p)==v,p
 assert N.resolve().is_relative_to(O.resolve());O.mkdir();shutil.copytree(J,N)
 def rewrite(s):return s.replace(str(J),str(N)).replace(J.as_posix(),N.as_posix())
 for p in N.rglob('*'):
  if p.is_file()and p.suffix in ['.s','.inc','.cfg']:
   s=p.read_text();z=rewrite(s)
   if s!=z:p.write_text(z,newline='\n')
 p=N/'arthur/own-services.s';s=p.read_text()
 pattern=r'ArOwnSet(\d+):\n php\n lda #<(\w+)\n sta ArDrawPtr\n lda #>\2\n sta ArDrawPtr\+1\n plp\n jmp (ArOwnTail|ArOwnProbeTail)'
 rows=re.findall(pattern,s);assert len(rows)==20
 def factor(m):return f'ArOwnSet{m[1]}:\n php\n lda #<{m[2]}\n pha\n lda #>{m[2]}\n jmp '+('ArOwnStoreProbe'if m[3]=='ArOwnProbeTail'else'ArOwnStoreNormal')
 s=re.sub(pattern,factor,s)
 common='''ArOwnStoreNormal:
 sta ArDrawPtr+1
 pla
 sta ArDrawPtr
 plp
 jmp ArOwnTail
ArOwnStoreProbe:
 sta ArDrawPtr+1
 pla
 sta ArDrawPtr
 plp
 jmp ArOwnProbeTail
'''
 s=s.replace('ArOwnTail:',common+'ArOwnTail:',1)
 s='.import CurrentBank,CurrentPlayer,ArHostPhase,ArHostDue,ArHostPad\n.importzp SavedJoypad1Bits\n'+s
 s=s.replace('ArOwnComponentEnd:','''; Private C-view entries below are called with their genuine +$2000 mirror.
; No absolute internal JMP/JSR, foreground ZP or sharedSMC. Fullcookie/raw32/
; Oper1/engine8/pause qualify at ArGenClockIngress and ArGenClockC70.
.export ArHostNmiClock,ArClockColdC70
.proc ArHostNmiClock
 tya
 pha
 lda #2
 sta $5115
 lda $bfd4
 cmp #$a7
 bne Restore
 lda CurrentPlayer
 cmp $bfd3
 bne Restore
 dec $bfd0
 bne Sample
 lda #3
 sta $bfd0
 lda #1
 sta $bfd1
Sample:
 ldy CurrentPlayer
 lda SavedJoypad1Bits,y
 sta $bfd2
Restore:
 lda #$bf                 ; genuine outerAudio manual A63 map
 sta $5115
 pla
 tay
 rts
.endproc
; Foreground only. C1 invalidates; C0 resets current generation, valid LAST.
.proc ArClockColdC70
 lda CurrentBank
 pha
 lda #2
 sta CurrentBank
 sta $5115
 lda #0
 sta $bfd4
 bcs Restore
 sta $bfd1
 sta $bfd2
 sta ArHostDue
 sta ArHostPad
 lda CurrentPlayer
 sta $bfd3
 lda #1
 sta $bfd0
 sta ArHostPhase
 lda #$a7
 sta $bfd4
Restore:
 pla
 sta CurrentBank
 sta $5115
 rts
.endproc
ArOwnComponentEnd:''',1);p.write_text(s,newline='\n')
 p=N/'arthur/host-state.s';s=p.read_text().replace('.export ArHostNativePickup,ArHostNmiClock','.export ArHostNativePickup')
 s='.import CurrentBank,CurrentBankC,ArClockColdC70\n.export ArHostClockPoll,ArHostClockColdBridge,ArHostInvalidateClock\n'+s
 old='Load:\n lda #0\n sta ArHostReady';assert s.count(old)==1;s=s.replace(old,'Load:\n jsr ArHostInvalidateClock\n lda #0\n sta ArHostReady',1)
 old=' lda #0\n sta ArHostDue\n sta ArHostPad\n lda #1\n sta ArHostPhase\n';assert s.count(old)==1
 s=s.replace(old,' php\n clc\n jsr ArHostClockColdBridge\n plp\n',1)
 at=s.index('.segment "ARTHUR_CLOCK"');s=s[:at]+'''.segment "ARTHUR_CLOCK"
; Foreground after actual Ensure; all conditional paths retain X/Y/VDI.
.proc ArHostClockPoll
 lda CurrentBank
 pha
 lda #2
 sta CurrentBank
 sta $5115
 lda $bfd4
 cmp #$a7
 bne NoDue
 lda CurrentPlayer
 cmp $bfd3
 bne NoDue
 lda $bfd2
 sta ArHostPad
 lda $bfd0
 sta ArHostPhase
 lda $bfd1
 cmp #1
 lda #0
 sta $bfd1
 sta ArHostDue
 bcs Restore
NoDue:clc
Restore:
 pla
 sta CurrentBank
 sta $5115
 rts
.endproc
ArHostInvalidateClock:sec
ArHostClockColdBridge:
 lda CurrentBankC
 pha
 lda #.lobyte(.bank(ArClockColdC70)|$80)
 sta CurrentBankC
 sta $5116
 jsr ArClockColdC70+$2000
 pla
 sta CurrentBankC
 sta $5116
 rts
''';p.write_text(s,newline='\n')
 p=N/'arthur/host-world.s';s='.import ArHostClockPoll\n'+p.read_text();old=' lda ArHostDue\n beq Done\n lda #0\n sta ArHostDue';assert s.count(old)==1;s=s.replace(old,' jsr ArHostClockPoll\n bcc Done',1);p.write_text(s,newline='\n')
 # Relocate only tiny, source-identical routines among the already co-resident
 # A26/C63 owned fragments. No extra mapper call or original instruction lost.
 p=N/'arthur/component.s';s=p.read_text();old='ArHostSfx:sta ArSoundRequest\n rts\nArHostCameraY:';assert s.count(old)==1;s=s.replace(old,'.segment "ARTHUR_ADAPTER"\nArHostSfx:sta ArSoundRequest\n rts\n.segment "ARTHUR_LEAF"\nArHostCameraY:');p.write_text(s,newline='\n')
 p=N/'arthur/host-adapter.s';s='.import ArHostInvalidateClock\n'+p.read_text();old='ArHostNoop:clc\n rts\nArHostVisible:sec\n rts\nArHostStatus:';assert s.count(old)==1;s=s.replace(old,'.segment "ARTHUR_LEAF"\nArHostNoop:clc\n rts\n.segment "ARTHUR_ADAPTER"\nArHostVisible:sec\n rts\n.segment "ARTHUR_ADAPTER_COLD"\nArHostStatus:')
 old='ArHostBoxProfile:ldy #0\n rts\nArHostBodyPolicy:';assert s.count(old)==1;s=s.replace(old,'.segment "ARTHUR_ADAPTER_COLLECT"\nArHostBoxProfile:ldy #0\n rts\n.segment "ARTHUR_ADAPTER_COLD"\nArHostBodyPolicy:')
 old=' jsr ArHostSave\n jsr ArCacheRetire';assert s.count(old)==1;s=s.replace(old,' jsr ArHostSave\n jsr ArHostInvalidateClock\n jsr ArCacheRetire');p.write_text(s,newline='\n')
 p=N/'arthur/cache-wrapper.s';s=p.read_text();old=' lda #0\n sta AR_CACHE_VALID           ; never clear an already-Quick-owned cookie';assert s.count(old)==1;s=s.replace(old,' lda #0\n sta $dfd4                  ; own mailbox invalid before cookie/selector\n sta AR_CACHE_VALID           ; never clear an already-Quick-owned cookie');p.write_text(s,newline='\n')
 p=N/'generation-predicates.s';s='.import GamePauseStatus\n.importzp GameEngineSubroutine\n'+p.read_text();start=s.index('.proc ArGenClockIngress');end=s.index('.endproc',start);v=s[start:end];old=' lda FamilyMainCommit\n and #1\n bne Done';assert v.count(old)==1;v=v.replace(old,' lda GamePauseStatus\n lsr\n bcs Done');s=s[:start]+v+s[end:]
 old=' jsr ArGenCheckNmi\n bcc Done\n jsr ArHostNmiClock-$2000\nDone:rts';assert s.count(old)==1;s=s.replace(old,' jsr ArGenCheckNmi\n bcc Done\n lda GameEngineSubroutine\n cmp #8\n bne Done\n jmp ArHostNmiClock+$2000\nDone:rts');p.write_text(s,newline='\n')
 def run(cmd,phase):
  for flag in ['-o','-Ln','-m','--create-full-dep']:
   if flag in cmd:assert Path(cmd[cmd.index(flag)+1]).resolve().is_relative_to(N.resolve()),cmd
  for v in cmd:
   if v.startswith('--dbgfile,'):assert Path(v.split(',',1)[1]).resolve().is_relative_to(N.resolve())
  r=subprocess.run(cmd,cwd=R,capture_output=True,text=True);(N/(phase+'.json')).write_text(json.dumps(dict(command=cmd,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr),indent=2)+'\n');assert not r.returncode,r.stderr
 for phase in ['arthur-own-services','arthur-host-state','arthur-host-world','arthur-component','arthur-host-adapter','arthur-host-render','generation-predicates']:
  run([rewrite(v)for v in json.loads((J/(phase+'-build.json')).read_text())['command']],phase+'-clock-build')
 run([rewrite(v)for v in json.loads((J/'label-link.json').read_text())['command']],'clock-link');B.prepare(R,N/'candidate.nes')
 b=B.scoped_load(N/'candidate.nes');sizes={s['name'].strip('"'):int(s['size'],0)for s in b['segs'].values()}
 for p,v in h['bindings'].items():assert sha(p)==v,p
 (O/'linked-stage.json').write_text(json.dumps(dict(native=False,candidate=sha(N/'candidate.nes'),parent=sha(J/'candidate.nes'),sizes=sizes,mailbox=[0xdfd0,0xdfd5],stub_factors=rows,status='SOURCE_LINKED_CONTROLS_PENDING'),indent=2)+'\n');print(json.dumps(dict(candidate=sha(N/'candidate.nes'),sizes={k:v for k,v in sizes.items()if'ARTHUR'in k or'AR_GEN'in k or k=='GIMMICK_COMMON_NMI'})))
if __name__=='__main__':main()
