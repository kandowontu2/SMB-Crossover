"""Exact source/link ownership and retained source-pixel/runtime closure."""
from pathlib import Path
import difflib,json,re
import arthur_physical_clock_context_v2 as V
A=V.A;B=V.B;O=V.O;N=V.N;P=B.R/'build/celeste-menu-name-arthur-v2/joint'
def main():
 out=O/'source-ownership-v2.json';assert not out.exists();old,b=[A.scoped_load(p/'candidate.nes')for p in[P,N]]
 x,y=old['raw'],b['raw'];assert x[:16]==y[:16]and x[1048592:]==y[1048592:]
 pub=re.findall(r'\.assert \*-(\w+)=16',(N/'union.s').read_text());assert len(pub)==36 and all(A.point(old,n)==A.point(b,n)for n in pub)
 for name,size in[('ArCacheEmit',550),('X5SetPhysicalChr',20)]:assert x[A.location(old,name):A.location(old,name)+size]==y[A.location(b,name):A.location(b,name)+size]
 for f in['body.chr','cache-input.bin','cache-runtime.s']:
  assert(P/'arthur'/f).read_bytes()==(N/'arthur'/f).read_bytes(),f
 # Physical owned intervals, not unused-byte inferences. Whole cfg remains
 # exactly the prior granted split after substituting only new output paths.
 def norm(s,p):return s.replace(str(p),'@JOINT').replace(p.as_posix(),'@JOINT')
 assert norm((P/'private.cfg').read_text(),P)==norm((N/'private.cfg').read_text(),N)
 intervals=[(26,0x57a,0x800),(26,0x132a,0x1c00),(26,0x1d32,0x2000),(63,0x1001,0x1400),(63,0x1a4c,0x2000),(63,0x1600,0x1800),(70,0x58f,0x860),(70,0x19b8,0x2000),(117,0x9c2,0xa00)]
 # Genuine source farcall immediate operand rebindings outside Arthur spans.
 external={(3,0x124e),(66,0xa41),(79,0x1ae7),(79,0x1e5f),(93,0xfc4),(125,0x486),(127,0x486)}
 changes=[]
 for bank in range(128):
  for off in range(8192):
   p=16+bank*8192+off
   if x[p]==y[p]:continue
   owned=any(bank==k and lo<=off<hi for k,lo,hi in intervals)
   assert owned or(bank,off)in external,('unowned changed byte',bank,hex(off))
   if not owned:assert x[p-1]==y[p-1]==169,('actual LDA immediate operand',bank,off)
   changes.append(dict(bank=bank,offset=off,old=x[p],new=y[p],owned=owned,old_context=x[p-1:p+13].hex(),new_context=y[p-1:p+13].hex()))
 mirror=json.loads((N/'candidate.cv3-mirror.json').read_text());assert mirror['ROM_sha256']==B.sha(N/'candidate.nes')and mirror['all_other_fixed_bytes_exact']
 patch=[];sourcechanges=[]
 for p in N.rglob('*'):
  if not p.is_file()or p.suffix not in['.s','.inc','.cfg']:continue
  rel=p.relative_to(N);q=P/rel;a=norm(q.read_text(),P)if q.exists()else'';z=norm(p.read_text(),N)
  if a!=z:sourcechanges.append(rel.as_posix());patch.extend(difflib.unified_diff(a.splitlines(True),z.splitlines(True),fromfile='parent/'+rel.as_posix(),tofile='physical-clock/'+rel.as_posix()))
 (O/'physical-clock-source.patch').write_text(''.join(patch),newline='\n')
 # Full actual source producer census: no positive old ArHostDue producer
 # remains. Reset/death keep the allocated mirror zero, so poll needn't STA0.
 refs=[]
 for p in(N/'arthur').glob('*.s'):
  lines=p.read_text().splitlines()
  for i,line in enumerate(lines):
   if re.search(r'\b(?:sta|stx|sty|inc|dec|lda|ldx|ldy)\s+ArHostDue\b',line,re.I):refs.append(dict(file=p.name,line=i+1,text=line.strip(),preceding=lines[max(0,i-10):i]))
 assert len(refs)==2 and all(v['text']=='sta ArHostDue'and[z.strip()for z in v['preceding']if z.strip().startswith('lda ')][-1]=='lda #0'for v in refs),refs
 sizes=json.loads((O/'linked-stage.json').read_text())['sizes'];measures=dict(A26main=[sum(sizes[n]for n in['ARTHUR_BODY','ARTHUR_LEAF','ARTHUR_DRAW']),2262],A26tail=[sum(sizes[n]for n in['ARTHUR_PROBES','ARTHUR_COMBAT','ARTHUR_ADAPTER','ARTHUR_PALETTE_MODE']),718],world=[sizes['ARTHUR_WORLD'],646],C63large=[sum(sizes[n]for n in['ARTHUR_COMMON','ARTHUR_CLOCK','ARTHUR_PUBLISH','ARTHUR_ADAPTER_COLD']),1460],C63small=[sum(sizes[n]for n in['ARTHUR_SHOTS','ARTHUR_LIFECYCLE','ARTHUR_ADAPTER_COLLECT']),1023],C70own=[sizes['ARTHUR_OWN_SERVICES'],768],common=[sizes['GIMMICK_COMMON_NMI'],512])
 assert all(used<=cap for used,cap in measures.values())
 d=dict(passed=True,native=False,candidate=B.sha(N/'candidate.nes'),parent=B.sha(P/'candidate.nes'),header_all_CHR_body_source_input_runtime550_nativepublisher20_exact=True,all36public_PC_bank_exact=pub,unchanged_actual_link_config=True,measured_owned_spans=measures,physical_intervals=intervals,external_changed_operand_bytes=[v for v in changes if not v['owned']],all_changed_PRG_bytes=changes,changed_sources=sourcechanges,mailbox=dict(bank=2,start=0xdfd0,end=0xdfd5,fields=['phase','saturated_due','sampled_native_pad','current_player','valid_last_A7'],new_global_RAM=False,RAM1=False),old_due_all_consumers_and_producers=refs,setter_funding=dict(normal_and_probe_setters=20,old_bytes=300,new_bytes=202,saved_bytes=98,extra_CPU_selected_setter=10,private_pointer_order='high then low; both complete before dispatch; busy NMI has zero Ar5C access'),limits=['No native performance/cadence admission.','Current ready53 source retains older FF07cda; newer root FF packets are separate composition work.'])
 d['bindings']={str(p.resolve()):B.sha(p)for p in[Path(__file__),N/'candidate.nes',N/'candidate.dbg',N/'private.cfg',O/'physical-clock-source.patch',N/'candidate.cv3-mirror.json']};out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(passed=True,candidate=d['candidate'],changes=len(changes),source_files=len(sourcechanges),external_bytes=len(external),sizes=measures)))
if __name__=='__main__':main()
