"""Freeze only source-qualified lifecycle repair; no palette scheduler/admission."""
from pathlib import Path
import hashlib,json,sys
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
from prepare_ff_current_component_v2 import qualified
from check_tmnt_render_oa import address,location
O=R/'build/ff-fx-palette-lifecycle-v8';D=O/'joint'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
    target=O/'handoff.json';assert not target.exists()
    names=['source-closure.json','lifecycle-controls-v5.json','preflush-oracle-v2.json',
        'actual-preflush-consumers-v3.json','preflush-vectors-v2.json','preflush-final-closure-v1.json']
    receipts={n:json.loads((O/n).read_text())for n in names}
    assert all(d['passed']for d in receipts.values())
    assert sha(D/'candidate.nes')=='4929545edb5a7b9224ab2d11101a4f2dba781210f1e6915fb01c8a8ee9d29b5e'
    negative_paths=[
        R/'build/ff-fx-palette-lifecycle-v3/actual-late-native-P1-negative-v1.json',
        R/'build/ff-fx-palette-lifecycle-v5/lifecycle-negative-v3.json',
        R/'build/ff-fx-palette-lifecycle-v5/preflush-C116-decoder-negative-v1.json',
        R/'build/ff-fx-palette-lifecycle-v7/preflush-oracle-negative-v1.json',
        O/'actual-preflush-consumers-negative-v1.json',O/'actual-preflush-consumers-negative-v2.json',
        O/'preflush-vectors-negative-v1.json']
    files={Path(__file__)}|{O/n for n in names}|set(negative_paths)
    for d in receipts.values():
        for p,h in d.get('bindings',{}).items():
            assert sha(p)==h,('Changed positive binding',p,h,sha(p));files.add(Path(p))
    for p in negative_paths:
        d=json.loads(p.read_text());assert d['passed']is False
        for p,h in d.get('bindings',{}).items():
            assert sha(p)==h,('Changed retained negative binding',p,h,sha(p));files.add(Path(p))
    b=qualified(D/'candidate.nes');end=location(b,'FwPalettePreflushEnd');bank_end=16+94*8192
    free=bank_end-end;assert free==138 and set(b['raw'][end:bank_end])=={255}
    assert free-130==8
    readme='''This packet repairs FF palette-mailbox retirement and acquisition only.

Parent: current-character-composition-v2 / 80628f27. Candidate: 4929545e.
It is a private source/CPU qualification, with no native run, scheduler,
readiness, shared installation or new resource lease.

An exact C0 retire packet is consumed BEFORE the complete original
PnHudPreUpdateScreen -> PnPaletteScreenUpdate -> ArPaletteScreenUpdate /
ArGenPalette -> PN continuation. Native/Samus 80 retains its original later
consumer. Both obsolete unused 26-byte FF palette-pointer exports are
explicitly retired; all 36 live service veneers and other public PCs stay.

The fixed P1 writer is checked against real UpdateScreen with C116 mapped:
all PPU writes, both PPUSTATUS reads, latch/scroll and PPUCTRL mirror effects
match. It preserves NmiR0/1, X/Y/P, stack and all 33 SMC bytes; A is F4 at
the genuine original PN continuation. Malformed C0 packets are cleared and
rejected without a PPU transaction. They cannot reconstruct unknown old
hardware colors, so rejection is not a recovery/admission claim.

Actual CF menu, InitScreen, native Samus compositor and genuine Quick palette
API tests prove later native packets win. This immutable parent still keeps
Quick pending; the Quick test is explicitly an API fixture, not its natural
shared cold constructor/Main route. InitScreen tests include life/newgame,
cold code-cookie and area contexts; no complete campaign or every possible
two-player/death controller sequence is claimed.

The original near-call attempt failed because UpdateScreen's optimized copy
worker requires C116; its BRK and exact trace remain. The first fixed writer
omitted the native second PPUSTATUS read; that negative remains. Checker
revisions retain genuine paused-menu nonselection, pending Quick identity,
and the corrected measured +41 rather than estimated +40 CPU expectation.

CPU: 1056 real parent/new NMI/IRQ pairs preserve full application state and
ordered writes. Ordinary normal NMI costs +41 instruction cycles; lag NMI
and IRQ cost 0 extra. A valid C0 fixed transfer is 41 cycles cheaper than
the parent's equivalent native post-80 packet. 252 real lifecycle instruction
cuts preserve the authentic busy interval. No hardware NMI deadline or native
cadence is asserted. Timed pre-DMA PPU events and full upload costs are kept.

Owned placement: protocol223 bytes + preflush104 =327 bytes of the465-byte
C93 tail. Current free138 bytes are all FF. A future130-byte world marker
would leave8 bytes; the marker itself is NOT installed in this packet.
Header, CHR, FF RAM3 image/cookie and all other owned spans remain exact.

Source closure schema: source-closure.json has `bindings` mapping absolute
file paths to SHA256. handoff.json binds that closure, every positive receipt,
all retained negatives and their exact dependencies. Every compiler/linker
command was checked by private_build_outputs_v1.validate before execution.
'''
    (O/'README.md').write_text(readme,newline='\n');files.add(O/'README.md')
    p=dict(passed=True,source_qualified=True,native=False,admitted=False,scheduler_installed=False,
        candidate_sha256=sha(D/'candidate.nes'),parent_sha256=receipts['source-closure.json']['parent_sha256'],
        source_closure=dict(path=str((O/'source-closure.json').resolve()),schema='bindings: absolute filepath -> SHA256'),
        own_ABI_removed=['FwPalettePointer at AEDA','FwEffectPalettePointer at AEF4'],
        placements=dict(wrapper=[0xaeda,0xaf0e],protocol_A93=[address(b,'FwMuxMenuA'),address(b,'FwMuxProtocolEnd')],
            preflush_C93=[address(b,'FwPalettePreflush'),address(b,'FwPalettePreflushEnd')],current_tail_free_bytes=138,
            future_marker_not_installed_bytes=130,forecast_after_marker_free_bytes=8),
        positive_receipts={n:sha(O/n)for n in names},retained_negatives={str(p.resolve()):sha(p)for p in negative_paths},
        foreign_normal_NMI_CPU_delta=41,foreign_lag_NMI_IRQ_CPU_delta=0,
        limits=['No scheduler/readiness/native campaign/admission or shared installation.',
            'Quick is a direct genuine palette API fixture in this parent; natural shared Quick cold/Main remains separately owned.',
            'No all-controller two-player/death campaign claim or physical VBlank deadline/cadence claim.'],
        bindings={str(p.resolve()):sha(p)for p in sorted(files)})
    target.write_text(json.dumps(p,indent=2)+'\n',newline='\n')
    assert all(sha(f)==h for f,h in p['bindings'].items())
    print(json.dumps(dict(passed=True,path=str(target),sha256=sha(target),bindings=len(p['bindings']),ROM=p['candidate_sha256'])),flush=True)

if __name__=='__main__':main()
