"""Retain/review the post-link validation separately; do not rebuild the parent."""
import inspect,json,traceback
import prepare_current_quick_ui_v13 as M
text=inspect.getsource(M.main);a=text.index(' from prepare_cv3_dmc_mirror import prepare')
text="def main():\n raw=(P/'candidate.nes').read_bytes()\n receipt=R/'docs/qa/checkpoints/2026-10-30/new-roster-source-ui-fastpath/quick-selected-successor-reservation.json'\n"+text[a:]
exec(compile(text,__file__,'exec'),M.__dict__)
if __name__=='__main__':
 try:M.main()
 except Exception as e:
  p=M.O/('retained-postlink-validation-negative-'+str(len(list(M.O.glob('retained-postlink-validation-negative*'))))+'.json')
  p.write_text(json.dumps(dict(error=repr(e),traceback=traceback.format_exc(),native=False,compiler_reran=False),indent=2)+'\n')
  raise
