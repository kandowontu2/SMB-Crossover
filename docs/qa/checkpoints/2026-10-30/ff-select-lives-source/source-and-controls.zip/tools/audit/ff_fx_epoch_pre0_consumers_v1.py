"""Actual emitted PRE0/POSTFX late-native, malformed and lifecycle consumers."""
from pathlib import Path
import itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import ff_fx_epoch_heartbeat_controls_v8 as A
H,E,T,L=A.H,A.E,A.T,A.L;N=E.N;H.O=N/'joint'
from check_tmnt_render_oa import address

def late_native(b):
    base=E.fresh(b,3);rows=[]
    for family,late,full,lag in itertools.product([0,1],[0,1],[0,1],[0,255]):
        m,c,lo=E.frame(base,2,1,1,1,'flower',[(0,144)],family)
        assert H.get(m,'SmFreezeLastBlue')==128|family
        assert H.get(m,'SmFreezePalettePending')==(192 if family==0 else 128)
        if full:L.Q.queue(m,1)
        if late:H.invoke(m,'SamusFreezePaletteStoreA',a=8)
        before=bytes(m.vram);cursor=H.get(m,'SmFreezeTurn')
        if lag:
            r=L.Q.consume(m,255)
            assert bytes(m.vram)==before and H.get(m,'SmFreezeTurn')==cursor
            assert r['pending']==(192 if family==0 else 128)
        r=A.consume(m)
        want=([0x1a,0x30,0x27]if late or full else[0x1c,0x36,0x17])if family==0 else[0x16,0x26,0x30]
        assert r['P1']==want and r['pending']==0
        rows.append(dict(family=family,lateBowser=late,fullqueue=full,lag=lag,P1=r['P1']))
    return dict(cases=len(rows),rows=rows,actual_emitted_native0_pre_and_FX_post_packets=True,
        genuine_later_native_Bowser_queue_wins_on_native0=True)

def malformed(b):
    base=A.actual_epoch(b,1);rows=[];packet=address(b,'SmFreezePalettePacket')
    for field,want in[(0,63),(1,21),(2,3),(6,0)]:
        for value in range(256):
            if value==want:continue
            m=T.copy(base);m[packet+field]=value
            H.put(m,NmiDisable=255,SmFreezePalettePending=128,VRAM_Buffer1_Offset=0,VRAM_Buffer_AddrCtrl=0)
            m[address(b,'VRAM_Buffer1')]=0;oldpacket=bytes(m[packet:packet+7]);oldowner=H.get(m,'SmFreezeLastBlue');turn=H.get(m,'SmFreezeTurn')
            H.invoke(m,'FfMuxTickROM')
            assert H.get(m,'SmFreezePalettePending')==0 and bytes(m[packet:packet+7])==oldpacket
            assert H.get(m,'SmFreezeLastBlue')==oldowner and H.get(m,'SmFreezeTurn')==turn
            if value in[0,1,255]:
                r=A.consume(m);assert r['data_writes']==0 and r['pending']==0
            rows.append([field,value])
    return dict(cases=len(rows),rows=rows,invalid_active_packet_cleared_before_original_native_decoder=True)

def main():
    p=dict(passed=False,native=False,admitted=False,performance_HOLD=True,checks={})
    try:
        b=H.C.qualified(N/'joint/candidate.nes')
        for name,fn in [('late_native',lambda:late_native(b)),('malformed_stable_packet',lambda:malformed(b)),
            ('actual_menu',lambda:L.menu(b)),('actual_scenes',lambda:L.scenes(H.C.qualified(E.P/'joint/candidate.nes'),b)),
            ('abandon_fullqueue_lag',lambda:L.full_queue_and_abandon(b)),('actual_loader',lambda:H.loader(b))]:
            p['checks'][name]=fn();print(name,'PASS',flush=True)
        p['passed']=True
    except Exception as e:p.update(error=repr(e),traceback=traceback.format_exc())
    files=[Path(__file__),Path(A.__file__),Path(E.__file__),Path(L.__file__),Path(H.__file__),N/'source-closure.json',N/'joint/candidate.nes',N/'joint/candidate.dbg',
        R/'build/ff-fx-epoch-late-native-audit-v2/counterexample.json']
    p['bindings']={str(f.resolve()):L.sha(f)for f in files}
    out=N/('consumer-controls-v1.json'if p['passed']else'consumer-negative-v1.json');assert not out.exists()
    out.write_text(json.dumps(p,indent=2)+'\n',newline='\n')
    print(json.dumps(dict(passed=p['passed'],path=str(out),error=p.get('error'))),flush=True);assert p['passed']

if __name__=='__main__':main()
