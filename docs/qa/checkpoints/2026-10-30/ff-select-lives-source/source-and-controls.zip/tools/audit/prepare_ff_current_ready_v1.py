"""Rebase only the frozen FF protocol onto genuine Quick/Arthur ready source.

Every compiler/linker output is validated beneath this new root before any
compiler runs. The shared dispatcher and other components are input objects;
they are neither rebuilt from guessed recipes nor replaced with an old union.
"""
from pathlib import Path
import difflib,hashlib,json,re,sys
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import prepare_ff_joint_source_v1 as B
from private_build_outputs_v1 import validate
from prepare_ff_current_component_v2 import qualified
from check_tmnt_render_oa import address,location
from prepare_cv3_dmc_mirror import prepare
P=R/'build/current-character-quick-ui-v13'
F=R/'build/ff-fx-epoch-pre0-v1'
O=R/'build/ff-current-ready-v1'


def write(p,s):
    p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf-8',newline='\n')


def main():
    assert not O.exists()
    files=B.validate(P/'handoff.json','c229c572e469cd3c280cdc03d485ae85c7c70ff10293c72f37c1cec84e2824a3')
    files|=B.validate(F/'handoff-source-performance-hold-v1.json','55dff985fc9b198ea93a4197d32a02e369547baabd9d9e277f9bfc0b7342362b')
    O.mkdir();d=O/'joint';d.mkdir();patch=[]
    for f in(P/'joint').rglob('*'):
        if f.is_file()and f.suffix in['.s','.inc','.cfg','.chr','.bin']:
            q=d/f.relative_to(P/'joint');q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(f.read_bytes())
    for n in['loader.s','veneers.s','ff-palette.s','ff-epoch-rom.inc','ff-epoch-workers.s',
        'ff-palette-lifecycle.s','ff-palette-preflush.s','ff-world-marker.s','ff-cookie.bin','ff-stream.bin']:
        target=d/n;old=target.read_text()if target.exists()and target.suffix not in['.bin']else''
        target.write_bytes((F/'joint'/n).read_bytes())
        if target.suffix not in['.bin']:
            patch+=list(difflib.unified_diff(old.splitlines(True),target.read_text().splitlines(True),fromfile='parent/'+n,tofile='new/'+n))
    # Retirement must precede the CURRENT Quick->Arthur->native publication
    # chain. Do not restore the old standalone Arthur-only continuation.
    p=d/'ff-palette-lifecycle.s';s=p.read_text()
    assert s.count('.import ArGenResolve,')==1 and s.count('MP_FAR ArGenResolve,jmp')==1
    write(p,s.replace('.import ArGenResolve,','.import QwMenuResolve,').replace('MP_FAR ArGenResolve,jmp','MP_FAR QwMenuResolve,jmp'))
    p=d/'src/character_select.s';old=p.read_text()
    assert old.count('farcall QwMenuResolve,jmp')==1
    new='.import FwMuxMenuResolve\n'+old.replace('farcall QwMenuResolve,jmp','farcall FwMuxMenuResolve,jmp')
    write(p,new);patch+=list(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='parent/character_select.s',tofile='new/character_select.s'))
    p=d/'src/full_roster_menu.s';old=p.read_text()
    needle=''' lda $5fef
 and #3
 clc
 adc #5
 sec
 rts
NotFF:'''
    assert old.count(needle)==1
    new=old.replace(needle,needle.replace(' sec\n',' clc\n'))
    write(p,new);patch+=list(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='parent/full_roster_menu.s',tofile='new/full_roster_menu.s'))
    p=d/'src/samus_freeze_render.s';old=p.read_text()
    assert old.count('lda #.bank(PnPaletteScreenUpdate) | MMC5_PRG_ROM')==1
    assert old.count('jmp PnHudPreUpdateScreen')==1
    new='.import FwPalettePreflush\n'+old.replace('lda #.bank(PnPaletteScreenUpdate) | MMC5_PRG_ROM','lda #.bank(FwPalettePreflush) | MMC5_PRG_ROM').replace('jmp PnHudPreUpdateScreen','jmp FwPalettePreflush')
    write(p,new);patch+=list(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='parent/samus_freeze_render.s',tofile='new/samus_freeze_render.s'))
    p=d/'src/metasprite_engine.s';old=p.read_text()
    needle='''::FwNativeFlashProbe:
  cmp #22
  beq NativeFlash
  jmp SamusFreezeFlashOwner
  .res 4,$ea
'''
    replacement='''::FwNativeFlashProbe:
  cmp #22
  bne SamusFreezeFlashOwner
  jsr FfMuxWorldDraw
  rts
  .res 3,$ea
'''
    assert old.count(needle)==1
    new='.import FfMuxWorldDraw\n'+old.replace(needle,replacement)
    write(p,new);patch+=list(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='parent/metasprite_engine.s',tofile='new/metasprite_engine.s'))
    p=d/'entrypoint.s';s=p.read_text()
    exports=['SmFreezePalettePacket','SmFreezeTurn','SmFreezeLastBlue','UpdateScreen','PnHudPreUpdateScreen',
        'SmFreezeNativeFlashEnemy','CurrentOAMOffset','RgOamRotation','Sprite_Y_Position','Sprite_Attributes']
    existing=set()
    for line in re.findall(r'^\.export (.+)$',s,re.M):existing|={v.strip()for v in line.split(',')}
    for n in exports:
        if n not in existing:s+='\n.export '+n+'\n'
    for n in['NmiR0','NmiR1']:
        if not re.search(r'^\.exportzp .*\b'+n+r'\b',s,re.M):s+='\n.exportzp '+n+'\n'
    write(p,s)
    p=d/'private.cfg';s=p.read_text().replace((P/'joint').as_posix(),d.as_posix())
    mem,segs=s.split('SEGMENTS {',1)
    mem=mem.rsplit('}',1)[0]+'FF_FX_PROTOCOL_RUN:start=$be2f,size=$1d1,type=ro,file="",bank=93;\n}\n'
    insert={
        'FF_RAM_PUBLISHER:load=FF_RAM3_MEM,type=ro,start=$a275;':'\nFF_EPOCH_CLASSIFY:load=FF_RAM3_MEM,type=ro,start=$a289;\nFF_EPOCH_HEARTBEAT:load=FF_RAM3_MEM,type=ro,start=$a2cc;',
        'FF_HOST_RENDER:load=FF_RAM3_MEM,type=ro,start=$a300;':'\nFF_EPOCH_COLORS:load=FF_RAM3_MEM,type=ro,start=$a6e5;',
        'FINAL_FANTASY_CORE:load=FF_RAM3_MEM,type=ro,start=$aa00;':'\nFF_EPOCH_PACKET:load=FF_RAM3_MEM,type=ro,start=$b68b;',
        'FF_FX_DATA3:load=FF_RAM3_MEM,type=ro,start=$bcef;':'\nFF_EPOCH_MAIN:load=FF_RAM3_MEM,type=ro,start=$becf;\nFF_EPOCH_TABLES:load=FF_RAM3_MEM,type=ro,start=$bff0;',
        'FF_HOST_PALETTE_C:load=FF_ART_MEM,type=ro;':'\nFF_FX_PROTOCOL_A:load=FF_ART_MEM,run=FF_FX_PROTOCOL_RUN,type=ro;\nFF_FX_PREFLUSH_C:load=FF_ART_MEM,type=ro;\nFF_FX_WORLD_MARKER:load=FF_ART_MEM,type=ro;'}
    for needle,extra in insert.items():assert segs.count(needle)==1;segs=segs.replace(needle,needle+extra)
    write(p,mem+'SEGMENTS {'+segs)
    commands=[]
    cmd=json.loads((P/'compile-main.json').read_text())['command']
    commands.append(('main-build',[v.replace(str(P/'joint'),str(d))for v in cmd]))
    names=['loader','veneers','ff-palette','stream','ff-palette-lifecycle','ff-palette-preflush','ff-world-marker','ff-epoch-workers']
    for n in names:
        commands.append((n+'-build',[str(R/'tools/Windows/cc65/bin/ca65.exe'),'-g','--cpu','6502x',
            '-I',str(d),'-I',str(R/'src'),'--bin-include-dir',str(d),'--bin-include-dir',str(R),
            '--create-full-dep',str(d/(n+'.dep')),'-o',str(d/(n+'.o')),str(d/(n+'.s'))]))
    link=json.loads((P/'final-link.json').read_text())['command']
    replace=['private.cfg','candidate.nes','candidate.dbg','candidate.lbl','candidate.map','main.o']+[n+'.o'for n in['loader','veneers','ff-palette','stream']]
    for n in replace:link=[v.replace(str(P/'joint'/n),str(d/n))for v in link]
    link +=[str(d/(n+'.o'))for n in['ff-palette-lifecycle','ff-palette-preflush','ff-world-marker','ff-epoch-workers']]
    # Validate the complete recipe set including every cfg MEMORY side output
    # BEFORE the first compiler runs. All unmodified object inputs stay bound
    # to their real immutable current parent, never copied from an old stage.
    for phase,cmd in commands+[('final-link',link)]:
        B.save(d/(phase+'-validated-outputs.json'),validate(cmd,O,cwd=R))
    for phase,cmd in commands:B.run(d,cmd,phase)
    B.run(d,link,'layout-link');image=(d/'ram3.bin').read_bytes()
    assert image==(F/'joint/ram3.bin').read_bytes(),'Rebased native targets changed the FF payload unexpectedly'
    assert(d/'code.bin').read_bytes()==(P/'joint/code.bin').read_bytes()
    assert(d/'data.bin').read_bytes()==(P/'joint/data.bin').read_bytes()
    cookie=bytes([167,22,0,9])+hashlib.sha256(image).digest()[:12]
    assert cookie==(F/'joint/ff-cookie.bin').read_bytes()
    assert(d/'ff-stream.bin').read_bytes()==image
    B.run(d,link,'final-link');prepare(R,d/'candidate.nes')
    old=qualified(P/'joint/candidate.nes');new=qualified(d/'candidate.nes')
    retired=['FwActionTick','FwWeapons','FwEnemyContact','FwForgetEnemy','FwPalettePointer','FwEffectPalettePointer']
    shifts={n:(address(old,n),address(new,n))for n,v in old['syms'].items()if'seg'in v and n not in retired and address(old,n)!=address(new,n)}
    assert not shifts,shifts
    for n in retired:assert n not in new['syms'],n
    assert address(new,'FfMuxWorldDrawEnd')==0xdff8
    assert address(new,'FfMuxClassifyEnd')==address(new,'FfMuxHeartbeat')==0xa2cc
    assert address(new,'FfMuxHeartbeatEnd')==0xa300
    cs=1048592
    ranges=[(location(old,'FwLoad'),location(old,'FwProjectileEntry'),'ownFFloader_retired104B'),
        (location(old,'FwPalettePointer'),location(old,'FwCookie')+16,'ownFFretired52B_cookie'),
        (location(old,'FwNativeDrawAll'),location(old,'FwNativeDrawAllEnd'),'ownnative_draw_bridge'),
        (location(old,'FwServiceVeneers')+29*3,location(old,'FwServiceVeneers')+30*3,'ownrow29'),
        (location(old,'FfHostPaletteCEnd'),location(new,'FfMuxWorldDrawEnd'),'ownART93tail'),
        (location(old,'MenuResolveCharacter'),location(old,'MenuResolveCharacter')+18,'MenuResolve_existing_operands'),
        (location(old,'SamusFreezeUpdateScreen'),location(old,'SamusFreezeUpdateScreen')+9,'NMI_existing_gateway_operands'),
        (location(old,'FwNativeFlashProbe'),location(old,'FwNativeFlashProbe')+11,'existing_native_object_marker'),
        (location(old,'FmPending'),location(old,'FmResolve'),'FF_existing_ready_gate'),
        (cs+893*1024,cs+901*1024,'ownFFcarrier')]
    differences=[i for i,(a,z)in enumerate(zip(old['raw'],new['raw']))if a!=z]
    unexpected=[i for i in differences if not any(a<=i<z for a,z,n in ranges)]
    assert not unexpected,unexpected[:30]
    # All original FF occupied data/code and native world CHR remain exact;
    # new RAM bytes are only the explicitly granted593B code holes.
    assert old['raw'][:16]==new['raw'][:16]
    assert old['raw'][cs:cs+893*1024]==new['raw'][cs:cs+893*1024]
    assert old['raw'][cs+901*1024:]==new['raw'][cs+901*1024:]
    write(O/'source.patch',''.join(patch))
    files|={Path(__file__),R/'tools/audit/private_build_outputs_v1.py'}
    files|={Path(v)for v in link if v.endswith('.o')}|{p for p in O.rglob('*')if p.is_file()}
    B.save(O/'source-closure.json',dict(passed=True,native=False,admitted=False,installed=False,
        candidate_sha256=B.sha(d/'candidate.nes'),parent_sha256=B.sha(P/'joint/candidate.nes'),
        FF_RAM3_sha256=B.sha(d/'ram3.bin'),FF_payload_cookie_exact_frozen3754=True,
        other_Quick_RAM1_C2_and_all_foreign_source_objects_exact=True,
        all_original_live_public_PCs_header_CHR_except_owncarrier_exact=True,
        shared_dispatcher_object_unchanged=True,FF_four_class_ready_gate_enabled_privately=True,
        menu_chain='FwMuxMenuResolve -> FF retirement -> QwMenuResolve -> ArGenResolve -> FmResolve',
        scene_chain='QwSceneInit -> ArGenSceneInit -> FwSceneInit -> originalMove + FF acquisition/Ensure/AreaReset',
        allowed_diff_ranges=ranges,ROM_bytes_changed=len(differences),
        limits=['Actual cold menu/Start/scene/Main and current-parent regressions remain required.',
            'No native/campaign/admission/installed claim. Lag is measured and allowed by current user priority.'],
        bindings={str(f.resolve()):B.sha(f)for f in sorted(files)}))
    print(json.dumps(dict(passed=True,candidate=B.sha(d/'candidate.nes'),changed_bytes=len(differences),RAM3=B.sha(d/'ram3.bin'))),flush=True)


if __name__=='__main__':main()
