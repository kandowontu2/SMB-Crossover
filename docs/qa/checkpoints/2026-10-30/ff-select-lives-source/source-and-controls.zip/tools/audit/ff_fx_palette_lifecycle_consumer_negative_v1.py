"""Retain real late-native-P1 queue conflicts in the unadopted lifecycle leaf."""
from pathlib import Path
import json,sys
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import ff_fx_palette_lifecycle_controls_v2 as L
H,M,T,Q=L.H,L.M,L.T,L.Q
O=L.O

def main():
    p=O/'actual-late-native-P1-negative-v1.json';assert not p.exists()
    b=H.C.qualified(H.O/'candidate.nes');base=M.setup(b);rows=[]
    m=T.copy(base);L.put_owner(m);H.put(m,SelectedCharacter=22,CrossoverMenuIndex=29,
        CrossoverMenuState=2,CrossoverMenuButtons=0,SavedJoypad1Bits=1,SavedJoypad2Bits=0,
        FmGroups=0,OperMode=0,OperMode_Task=3,NmiDisable=0,VRAM_Buffer1_Offset=0)
    M.invoke_main(m,lambda *args:None)
    assert H.get(m,'CrossoverMenuIndex')==30
    reference=T.copy(m);H.put(reference,SmFreezePalettePending=0)
    ref=Q.consume(reference,0);actual=Q.consume(m,0)
    assert ref['P1']==[0x37,0x16,0x0f] and actual['P1']!=ref['P1']
    rows.append(dict(event='actual_GameLoop_CF_menu_preview',native_P1=ref['P1'],protocol_P1=actual['P1'],
        cause='Post-native one-shot world restore overrides the new authentic CF preview P1 packet.',
        original_native_OAM_parts=sum(reference[512+4*i]<240 for i in range(64))))
    m=T.copy(base);L.put_owner(m);H.put(m,SelectedCharacter=22,AreaType=1,Mirror_PPUMASK=0,
        DisableScreenFlag=1,ScreenRoutineTask=0,NmiDisable=255)
    H.invoke(m,'InitScreen');reference=T.copy(m);H.put(reference,SmFreezePalettePending=0)
    ref=Q.consume(reference,0);actual=Q.consume(m,0)
    assert ref['P1']!=actual['P1']
    rows.append(dict(event='actual_InitScreen_then_normal_NMI',native_control=H.get(m,'SmFreezePaletteControl'),
        native_P1=ref['P1'],protocol_P1=actual['P1'],
        cause='Native InitScreen sets palette control3 after the helper; post-native area-based packet incorrectly wins.'))
    d=dict(passed=False,native=False,admitted=False,retained_product_negative=True,source_scheduler_installed=False,
        audit_executed=True,rows=rows,required_next_design='A restore must precede the ordinary native palette upload so later source-authentic menu/scene P1 packets win; current post-native mailbox path alone is insufficient.',
        bindings={str(f.resolve()):L.sha(f)for f in[Path(__file__),Path(L.__file__),O/'source-closure.json',H.O/'candidate.nes',H.O/'candidate.dbg']})
    p.write_text(json.dumps(d,indent=2)+'\n',newline='\n');print(json.dumps(d['rows']),flush=True)

if __name__=='__main__':main()
