"""Bounded actual cold/foreign/lifecycle/loader closure for the slow epoch leaf."""
from pathlib import Path
import itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import ff_fx_epoch_cart_controls_v2 as E
from check_tmnt_render_oa import address
H,M,T,L,F=E.H,E.M,E.T,E.L,E.F;P,N=E.P,E.N;H.O=N/'joint'

def sig(m,c):
    excluded=set(range(0x100,0x200))|set(range(0x5114,0x5118))
    return (bytes(m[i]for i in range(0x8000)if i not in excluded),(c.a,c.x,c.y,c.p,c.sp),m.rawtags[:])

def foreign(old,new):
    seeds=[F.seed(b)for b in[old,new]];rows=[]
    for selected,flags in itertools.product([i for i in range(33)if i!=22],[0x30,0x71]):
        pair=[];cost=[];maps=[]
        for b,s in zip([old,new],seeds):
            m=T.copy(s);H.put(m,SelectedCharacter=selected,SmFreezeLastBlue=133,SmFreezeTurn=4,
                SmFreezePalettePending=0,SmFreezeRenderState=0)
            m.writes.clear();c=H.start(m,'SamusFreezeDrawAll',p=flags);c,low=H.finish(m,c)
            pair.append(sig(m,c));cost.append(c.processorCycles)
            maps.append([(a,v)for a,v in m.writes if 0x5114<=a<=0x5117])
        assert pair[0]==pair[1],('foreign native DrawAll output',selected,flags)
        assert maps[0]==maps[1],('foreign mapper trip changed',selected,flags)
        rows.append(dict(selected=selected,flags=flags,CPU_delta=cost[1]-cost[0],no_extra_mapper_trips=True))
    return dict(cases=len(rows),rows=rows,all_original_AXYP_SP_R0_R7_OAM_application_and_mapperwrites_exact=True)

def cold(old,new):
    seeds=[E.fresh(b,1)for b in[old,new]];rows=[]
    for byte,entry in itertools.product(range(16),['draw','tick']):
        pair=[];executed=[]
        for b,s in zip([old,new],seeds):
            m=T.copy(s);m.ram[3][0x1fe0+byte]^=1
            H.put(m,SmFreezeLastBlue=133,SmFreezeTurn=4,SmFreezePalettePending=0,NmiDisable=255)
            entered=[]
            def observe(mem,c,i):
                if c.pc>=0x8000 and mem.rawtags[(c.pc-0x8000)//8192]==3:entered.append(c.pc)
            if entry=='draw':
                c=H.start(m,'SamusFreezeDrawAll');c,low=H.finish(m,c,observe)
            else:
                c,low=H.invoke(m,'FfMuxTickROM'if b is new else'FwPaletteTick',hook=observe)
            assert not entered,('executed staleRAM3',byte,entry,entered[:4])
            pair.append(sig(m,c));executed.append(len(entered))
            assert H.get(m,'SmFreezeLastBlue')==133 and H.get(m,'SmFreezeTurn')==4 and H.get(m,'SmFreezePalettePending')==0
        assert pair[0]==pair[1],('fullcookie cold exact original',byte,entry)
        rows.append(dict(corrupt_cookie_byte=byte,entry=entry,unverified_RAM3_instructions=executed))
    return dict(cases=len(rows),rows=rows,all16cookiebytes_guard_both_newworker_routes=True)

def main():
    p=dict(passed=False,native=False,admitted=False,performance_HOLD=True,checks={})
    try:
        old=H.C.qualified(P/'joint/candidate.nes');new=H.C.qualified(N/'joint/candidate.nes')
        for name,fn in [('foreign',lambda:foreign(old,new)),('cold_cookie',lambda:cold(old,new)),
            ('actual_lifecycle_menu',lambda:L.menu(new)),('actual_scenes',lambda:L.scenes(old,new)),
            ('fullqueue_abandon_lag',lambda:L.full_queue_and_abandon(new)),('genuine_new_payload_loader',lambda:H.loader(new))]:
            p['checks'][name]=fn();print(name,'PASS',flush=True)
        p['passed']=True
    except Exception as e:p.update(error=repr(e),traceback=traceback.format_exc())
    files=[Path(__file__),Path(E.__file__),Path(F.__file__),Path(L.__file__),Path(H.__file__),N/'source-closure.json',
        P/'handoff.json',P/'joint/candidate.nes',P/'joint/candidate.dbg',N/'joint/candidate.nes',N/'joint/candidate.dbg']
    p['bindings']={str(f.resolve()):L.sha(f)for f in files}
    out=N/('safety-controls-v1.json'if p['passed']else'safety-negative-v1.json');assert not out.exists()
    out.write_text(json.dumps(p,indent=2)+'\n',newline='\n')
    print(json.dumps(dict(passed=p['passed'],path=str(out),error=p.get('error'))),flush=True);assert p['passed']

if __name__=='__main__':main()
