"""Freeze coherent private current-parent FF cold/readiness source evidence."""
from pathlib import Path
import json,sys
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import prepare_ff_joint_source_v1 as B
O=R/'build/ff-current-ready-v2'


def save(p,d):p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8',newline='\n')


def main():
    out=O/'handoff-source-v1.json';assert not out.exists()
    receipts=[O/n for n in['source-closure.json','cold-controls-v2.json',
        'regression-controls-v2.json','render-controls-v1.json']]
    files={Path(__file__)}
    for p in receipts:
        d=json.loads(p.read_text());assert d['passed'];files.add(p)
        for f,h in d['bindings'].items():assert B.sha(f)==h,f;files.add(Path(f))
    negatives=[]
    for p in sorted(O.glob('*negative*.json')):
        d=json.loads(p.read_text());assert not d.get('passed',False)
        files.add(p)
        for f,h in d.get('bindings',{}).items():assert B.sha(f)==h,f;files.add(Path(f))
        negatives.append(dict(path=str(p.relative_to(R)),sha256=B.sha(p),reason=d.get('error',d.get('reason'))))
    inventory=dict(parent='7a9e2cc1246d590bebe2acd5451267894f39cdac75cd528e20109de01753d760',
        current_candidate=B.sha(O/'joint/candidate.nes'),
        entire_FF_owned_producers=['loader.s','veneers.s','ff-palette.s','ff-epoch-rom.inc','ff-epoch-workers.s',
            'ff-palette-lifecycle.s','ff-palette-preflush.s','ff-world-marker.s','ff-cookie.bin','ff-stream.bin'],
        main_producer_changes={
            'src/character_select.s':'Existing MenuResolve farcall targets FwMuxMenuResolve; retirement then calls genuine QwMenuResolve->ArGenResolve->FmResolve.',
            'src/full_roster_menu.s':'One existing SEC->CLC in FF index21/FfVariant0..3 readiness branch.',
            'src/samus_freeze_render.s':'Existing9B NMI gateway operands target C93 preflush, retaining exact full PN/Ar continuation.',
            'src/metasprite_engine.s':'Existing11B selectedFF per-actor flash probe calls complete-object marker; all live PCs fixed.',
            'entrypoint.s':'Zero-byte genuine native exports for new FF modules, including RgOamUsed.',
            'private.cfg':'Only approved FF593B RAM3 holes/457B ART93 tail are added; all current Quick/Ar MEMORY/SEGMENTS and outputs retained.'},
        recompiled=['main','loader','veneers','ff-palette','stream'],
        new_objects=['ff-palette-lifecycle','ff-palette-preflush','ff-world-marker','ff-epoch-workers'],
        unchanged='Every other actual parent object, shared dispatcher, Quick RAM1/C2, Arthur cache, all live publicPCs/header/CHR outside FF893..900 remain exact.',
        root_later_parent_delta='Root ready54 08f1a75f adds409 RCR ink +1 Chip byte to7a9; these410 bytes are NOT in this candidate. Final root merge must retain those source deltas.',
        FF_RAM3_and_stream_cookie_exact_frozen3754=True)
    save(O/'source-merge-inventory.json',inventory);files.add(O/'source-merge-inventory.json')
    (O/'README-source.md').write_text('''FF four-class private current-parent source/readiness packet.

ROM280ab646 derives genuine Quick/Arthur ready7a9e source. Its FF RAM3/carrier
and full16B cookie version9 remain byte-exact frozen3754. Shared dispatcher,
other source objects, Quick/Arthur payloads, live PCs/header and noncarrier CHR
are exact. The existing FF readiness branch alone changes SEC to CLC. The
MenuResolve wrapper retires FF before genuine Quick->Arthur->native resolver;
the current Quick->Arthur->FF InitScreen chain stays intact.

All four classes pass genuine cold menu/Start/newgame/area-clear/8192B loader,
full native screen parser and entrance, then128 Main updates with source
movement/jump/attack, one real source weapon tick and one early draw each.
All80 profiles cycle actual Select with release:58ready/22pending. Current-parent
3072 strict real-producer OAM/palette/NMI pairs,768 body/heartbeat pairs,
16 late-native packet cases,64 foreign DrawAll pairs,1056 foreign vectors,
548 active worker cuts and8 completed-Main normal NMIs pass.

Lag is measured and permitted by current user priority; no native/campaign,
controller-earned upgrade or installed admission is claimed. Native source
smokes remain required. Existing FF menu-name service18 and HUD-name30 are
still explicit rejects: current ready FF menu labels are blank in actual PPU
results. This presentation gap is recorded, not hidden by the ready count.
Other CLC rows20/21/22/35 keep their declared native fallback; no fake ability.

Prior link export/whitelist and cold-fixture failures are retained. The first
cold fixture omitted actual native world parsing and fell through its absent
floor; the corrected fixture runs every real screen/area task and normal NMI.
The original FF source physics is unchanged. The profile wrapper assertion
initially expected a pending owner instead of0 at Select wrap; it is retained.

Root ready54 later adds409 RCR ink +1 Chip byte. This7a9-derived cart deliberately
does not contain those410bytes; preserve that root delta in the final merge.
No frozen/shared source, Download, Git-index or native queue was modified.
''',encoding='utf-8',newline='\n')
    files.add(O/'README-source.md')
    d=dict(status='PRIVATE_FOUR_FF_COLD_SOURCE_READY_NATIVE_PENDING',passed=True,native=False,
        admitted=False,installed=False,candidate=B.sha(O/'joint/candidate.nes'),
        parent='7a9e2cc1246d590bebe2acd5451267894f39cdac75cd528e20109de01753d760',
        source_closure=dict(path=str(receipts[0].relative_to(R)),sha256=B.sha(receipts[0])),
        FF_RAM3_sha256=B.sha(O/'joint/ram3.bin'),FF_cookie=list((O/'joint/ff-cookie.bin').read_bytes()),
        source_ready_profiles=58,source_pending_profiles=22,all_FF_classes=[0,1,2,3],
        source_checks=dict(cold_classes=4,actual_controlled_Main=128,actual_menu_profiles=80,
            strict_real_producer_DrawAll=3072,body_heartbeat=768,foreign_DrawAll=64,
            foreign_NMI_IRQ=1056,active_worker_NMI_IRQ=548,normal_NMI_after_Main=8,late_native=16),
        known_gaps=['Native/controller/earned-pickup/campaign validation pending.',
            'Ready menu18 and HUD30 class name adapters remain explicit CLC; actual ready-menu text is blank.',
            'Root later410-byte RCR/Chip source delta must be retained in final composition.',
            'Original8sprite/OAM saturation and measured severe lag remain disclosed; lag alone is allowed.'],
        source_merge_inventory=dict(path=str((O/'source-merge-inventory.json').relative_to(R)),sha256=B.sha(O/'source-merge-inventory.json')),
        receipts={str(p.relative_to(R)):B.sha(p)for p in receipts},retained_negatives=negatives,
        bindings={str(f.resolve()):B.sha(f)for f in sorted(files)})
    save(out,d)
    print(json.dumps(dict(path=str(out),sha256=B.sha(out),bindings=len(files),candidate=d['candidate'])),flush=True)


if __name__=='__main__':main()
