"""Validate already-linked v2 with its omitted own scene-operand diff range.

No compiler runs and no cartridge/source/object bytes change. The retained
postlink negative is a missing whitelist entry for the intended JSR FwRetire
to JSR FwMuxScene operand in the approved own loader, not an unexplained diff.
"""
from pathlib import Path
import difflib,json,sys,textwrap
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import prepare_ff_joint_source_v1 as B
from private_build_outputs_v1 import validate
from prepare_ff_current_component_v2 import qualified
from check_tmnt_render_oa import address,location
P=R/'build/current-character-quick-ui-v13';F=R/'build/ff-fx-epoch-pre0-v1'
O=R/'build/ff-current-ready-v2';d=O/'joint'


def write(p,s):
    p.write_text(s,encoding='utf-8',newline='\n')


def main():
    assert not(O/'source-closure.json').exists()
    B.write=write
    files=B.validate(P/'handoff.json','c229c572e469cd3c280cdc03d485ae85c7c70ff10293c72f37c1cec84e2824a3')
    files|=B.validate(F/'handoff-source-performance-hold-v1.json','55dff985fc9b198ea93a4197d32a02e369547baabd9d9e277f9bfc0b7342362b')
    files|={Path(__file__),R/'tools/audit/prepare_ff_current_ready_v1.py',R/'tools/audit/prepare_ff_current_ready_v2.py'}
    old=qualified(P/'joint/candidate.nes');new=qualified(d/'candidate.nes')
    at=location(old,'FwSceneInit')+24
    assert old['raw'][at]==new['raw'][at]==0x20
    assert int.from_bytes(old['raw'][at+1:at+3],'little')==address(old,'FwRetire')
    assert int.from_bytes(new['raw'][at+1:at+3],'little')==address(new,'FwMuxScene')
    B.save(O/'retained-postlink-validation-negative-v2.json',dict(
        reason='The v2 validator omitted the intended own FwSceneInit JSR operand from its whitelist. The link was successful; this proof adds only that exact two-byte range.',
        original_unexpected_offsets=[at+1,at+2],original_target='FwRetire',new_target='FwMuxScene',
        candidate_sha256=B.sha(d/'candidate.nes'),source_objects_and_ROM_unchanged=True))
    files.add(O/'retained-postlink-validation-negative-v2.json')
    # Recheck every actual successful recipe's outputs/config sidefiles without
    # executing it; the original before-build validations remain unchanged.
    for n in['main','loader','veneers','ff-palette','stream','ff-palette-lifecycle',
        'ff-palette-preflush','ff-world-marker','ff-epoch-workers']:
        p=d/(n+'-build.json');q=json.loads(p.read_text());assert q['returncode']==0
        validate(q['command'],O,cwd=R)
    link=json.loads((d/'final-link.json').read_text())['command']
    assert json.loads((d/'final-link.json').read_text())['returncode']==0
    validate(link,O,cwd=R)
    patch=[]
    for p in sorted(d.rglob('*')):
        if not p.is_file()or p.suffix not in['.s','.inc','.cfg']:continue
        base=P/'joint'/p.relative_to(d)
        before=base.read_text()if base.exists()else'';after=p.read_text()
        if before!=after:
            patch+=list(difflib.unified_diff(before.splitlines(True),after.splitlines(True),
                fromfile='parent/'+p.relative_to(d).as_posix(),tofile='new/'+p.relative_to(d).as_posix()))
    # Reuse the exact v2 postlink verification statements, with the one
    # explicitly proved omitted range added. No build/compile code is executed.
    src=(R/'tools/audit/prepare_ff_current_ready_v2.py').read_text()
    post=textwrap.dedent(src[src.index("    old=qualified(P/'joint/candidate.nes')"):src.index("\n\n\nif __name__")])
    needle="differences=[i for i,(a,z)in enumerate(zip(old['raw'],new['raw']))if a!=z]"
    assert post.count(needle)==1
    post=post.replace(needle,"ranges.append((location(old,'FwSceneInit')+25,location(old,'FwSceneInit')+27,'ownSceneInit_JSR_FwMuxScene_operand'))\n"+needle)
    assert 'B.run('not in post and 'prepare('not in post
    scope=dict(globals(),files=files,patch=patch,link=link)
    exec(compile(post,__file__+'::<postlink-only>','exec'),scope)


if __name__=='__main__':main()
