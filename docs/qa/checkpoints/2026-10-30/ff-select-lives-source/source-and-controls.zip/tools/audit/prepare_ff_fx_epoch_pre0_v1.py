"""Approved private native0 PRE / stable FX POST source successor."""
from pathlib import Path
import hashlib,json,sys
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import prepare_ff_joint_source_v1 as B
from private_build_outputs_v1 import validate
from prepare_ff_current_component_v2 import qualified
from check_tmnt_render_oa import address,location
from prepare_cv3_dmc_mirror import prepare
P=R/'build/ff-fx-epoch-fast-v2';O=R/'build/ff-fx-epoch-pre0-v1'
Q=R/'build/ff-fx-native0-pre-proposal-v1'
G=R/'docs/qa/checkpoints/2026-10-30/ff-source-epoch-reservations/native-zero-preflush-reservation.json'

def run(d,cmd,n):
    B.save(d/(n+'-validated-outputs.json'),validate(cmd,O,cwd=R));B.run(d,cmd,n)

def compile(d,n,phase=None):
    cmd=[str(R/'tools/Windows/cc65/bin/ca65.exe'),'-g','--cpu','6502x','-I',str(d),'-I',str(R/'src'),
        '--bin-include-dir',str(d),'--bin-include-dir',str(R),'--create-full-dep',str(d/(n+'.dep')),'-o',str(d/(n+'.o')),str(d/(n+'.s'))]
    run(d,cmd,phase or n+'-build')

def main():
    assert not O.exists()
    assert B.sha(G)=='4422c061c45aa9f74ed26ad1a53a49be115b588dfafe8af2979f5080f6004d75'
    files={Path(__file__),G,Q/'proposal.json',Q/'source.patch'}
    for p in[P/'source-closure.json',P/'epoch-controls-v3.json',Q/'proposal.json']:
        h=json.loads(p.read_text());assert h['passed'];files.add(p)
        for f,v in h['bindings'].items():assert B.sha(f)==v,f;files.add(Path(f))
    O.mkdir();d=O/'joint';d.mkdir()
    for f in(P/'joint').rglob('*'):
        if f.is_file()and f.suffix in['.s','.inc','.cfg','.chr','.bin']:
            q=d/f.relative_to(P/'joint');q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(f.read_bytes())
    (d/'ff-epoch-workers.s').write_bytes((Q/'workers.s').read_bytes())
    p=d/'private.cfg';cfg=p.read_text().replace((P/'joint').as_posix(),d.as_posix())
    needle='FF_EPOCH_HEARTBEAT:load=FF_RAM3_MEM,type=ro,start=$a2ce;';assert cfg.count(needle)==1
    B.write(p,cfg.replace(needle,needle.replace('$a2ce','$a2cc')))
    compile(d,'ff-epoch-workers');compile(d,'loader');compile(d,'stream')
    cmd=json.loads((P/'joint/final-link.json').read_text())['command']
    for n in['private.cfg','candidate.nes','candidate.dbg','candidate.lbl','candidate.map','loader.o','stream.o','ff-epoch-workers.o']:
        cmd=[v.replace(str(P/'joint'/n),str(d/n))for v in cmd]
    run(d,cmd,'layout-link');image=(d/'ram3.bin').read_bytes()
    (d/'ff-stream.bin').write_bytes(image);cookie=bytes([167,22,0,9])+hashlib.sha256(image).digest()[:12]
    (d/'ff-cookie.bin').write_bytes(cookie)
    compile(d,'loader','loader-authenticated-build');compile(d,'stream','stream-authenticated-build')
    run(d,cmd,'final-link');prepare(R,d/'candidate.nes');assert(d/'ram3.bin').read_bytes()==image
    old=qualified(P/'joint/candidate.nes');new=qualified(d/'candidate.nes')
    assert address(new,'FfMuxPacketEnd')-address(new,'FfMuxPacket')==115
    assert address(new,'FfMuxClassifyEnd')==address(new,'FfMuxHeartbeat')==0xa2cc
    assert address(new,'FfMuxHeartbeatEnd')==0xa300
    root=qualified(R/'build/ff-fx-world-marker-proposal-v2/joint/candidate.nes')
    retired=['FwActionTick','FwWeapons','FwEnemyContact','FwForgetEnemy']
    assert not{n:(address(root,n),address(new,n))for n,v in root['syms'].items()if'seg'in v and n not in retired and address(root,n)!=address(new,n)}
    cs=1048592;ranges=[(location(old,'FfMuxNativeROM'),location(old,'FwProjectileEntry')),
        (location(old,'FwCookie'),location(old,'FwCookie')+16),(cs+893*1024,cs+901*1024)]
    dif=[i for i,(a,z)in enumerate(zip(old['raw'],new['raw']))if a!=z]
    assert all(any(a<=i<z for a,z in ranges)for i in dif)
    files|={Path(v)for v in cmd if v.endswith('.o')}|{f for f in O.rglob('*')if f.is_file()}
    B.save(O/'source-closure.json',dict(passed=True,native=False,admitted=False,performance_HOLD=True,
        candidate_sha256=B.sha(d/'candidate.nes'),parent_sha256=B.sha(P/'joint/candidate.nes'),RAM3_sha256=B.sha(d/'ram3.bin'),cookie=list(cookie),
        original_body_CORE_ART_CHR_public_PCs_native_WRAM_owner_fields_exact=True,ROM_bytes_changed=len(dif),
        kernel_new_own_bytes=539,own_ROM_bytes=98,actual_protocol='native0 C0 pre-nativequeue; FX1..5 80 post; onlystableFXheartbeat withstrictheader/terminator/clearfirst/publishlast',
        limits=['Actual newwriter/heartbeat/OAM/fullqueue/lateNative/lifecycle/fullcookie/ISR/Main qualification remains.',
                'No native/readiness/campaign/cadence or installation.'],
        bindings={str(f.resolve()):B.sha(f)for f in sorted(files)}))
    print(json.dumps(dict(passed=True,ROM=B.sha(d/'candidate.nes'),RAM3=B.sha(d/'ram3.bin'))),flush=True)

if __name__=='__main__':main()
