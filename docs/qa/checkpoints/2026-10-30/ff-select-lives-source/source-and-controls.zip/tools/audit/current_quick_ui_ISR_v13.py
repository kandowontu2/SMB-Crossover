"""Real normal/lag NMI and IRQ at selected UI helper/SMC/mapper seams."""
import json,traceback
from pathlib import Path
import current_quick_ui_controls_v13 as U
B=U.B;C=U.C;S=U.S;T=U.T;O=B.O;N=B.N
def main():
 out=O/'early-ui-real-ISR-controls.json';assert not out.exists();d=dict(passed=False,native=False)
 try:
  C.O=N;C.CODE=(N/'code.bin').read_bytes();C.DATA=(N/'data.bin').read_bytes()
  template=U.bus(N);U.put(template,SelectedCharacter=9,FmAlts=32,DisableScreenFlag=1)
  C.invoke(template,'QwConstruct');U.put(template,DisableScreenFlag=0)
  rows=[]
  for raw,bits,roll in [(0,0,0),(9,0,0),(9,0,1),(9,32,0),(9,255,1),(22,0,0),(32,0,0)]:
   base=T.fork(template);U.put(base,SelectedCharacter=raw,FmAlts=bits,RlVariant=roll)
   m=T.fork(base);age=0;seen=set();cuts=[]
   def observe(c):
    nonlocal age
    pc=c.pc;tag=m.tags[(pc-32768)//8192]if pc>=32768 else-1;op=bytes(m[pc:pc+3]);key=(tag,pc)
    changed=(tag==214 and(0xa79c<=pc<0xa7b4 or pc==m.lab['X5UiAfterLow']-4))
    if key not in seen and(changed or 0x15a<=pc<0x17b or op in[b'\x8d\x15\x51',b'\x8d\x16\x51']):
     seen.add(key);cuts.append((age,pc,tag))
    age+=1
   S.execute(m,'X5BounceUiDispatch',A=131,X=90,Y=199,P=0x71,hook=observe)
   for cut,pc,tag in cuts:
    for lag in[0,255]:
     for kind in['NMI','IRQ']:
      q=T.fork(base);q.set('NmiDisable',lag);age=0;proof=[]
      def inject(c):
       nonlocal age
       if age==cut:
        assert c.pc==pc
        if kind=='IRQ'and c.p&c.INTERRUPT:return
        proof.append(C.interrupt_at(q,c,kind))
       age+=1
      S.execute(q,'X5BounceUiDispatch',A=131,X=90,Y=199,P=0x71,hook=inject)
      if proof:rows.append(dict(raw=raw,bits=bits,roll=roll,step=cut,PC=pc,tag=tag,lag=lag,requested_kind=kind,**proof[0]))
  d.update(passed=True,real_vectors=len(rows),rows=rows,scope='Actual new helper instructions and genuine UI synthetic-stack/33SMC/mapper seams; AXYP/SP/maps/shadows/livepage1/cache preserved.')
 except Exception as e:d.update(error=repr(e),traceback=traceback.format_exc())
 d['bindings']={str(Path(p).resolve()):B.sha(p)for p in[__file__,N/'candidate.nes',N/'candidate.dbg']}
 out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(passed=d['passed'],error=d.get('error'),real_vectors=d.get('real_vectors'))));assert d['passed'],d.get('error')
if __name__=='__main__':main()
