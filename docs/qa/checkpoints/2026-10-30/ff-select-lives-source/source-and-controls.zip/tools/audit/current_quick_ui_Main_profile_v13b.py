"""Retain the report-adapter error; correct only its builder interface/path."""
import inspect,json
import current_quick_ui_Main_profile_v13 as M
M.B.B=M.B
text=inspect.getsource(M.main)
text=text.replace("text=text.replace(\"'QhBoxProfile']\"", "text=text.replace(\"'QhBoxProfile']\"")
# The first attempt created its directory before the report binding adapter
# requested B.B.sha. Give this unchanged consumer a separate output path.
text=text.replace("text=source.read_text().replace(","text=source.read_text().replace(\"O=B.O/'area-geometry'\",\"O=B.O/'area-geometry-v2'\").replace(")
exec(compile(text,__file__,'exec'),M.__dict__)
if __name__=='__main__':
 p=M.O/'retained-Main-profile-report-adapter-negative.json'
 assert not p.exists();p.write_text(json.dumps(dict(native=False,product_source_changed=False,error="The new builder intentionally exposes sha directly, but inherited geometry report adapter requested B.B.sha; retained first report-only failure. Successor provides B.B=B and a new output path."),indent=2)+'\n')
 M.main()
