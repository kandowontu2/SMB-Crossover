"""Compile exact PRE-native0/stable-FX-heartbeat proposal, install no source."""
from pathlib import Path
import difflib,json,sys
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import prepare_ff_joint_source_v1 as B
from private_build_outputs_v1 import validate
import ff_fx_epoch_cart_controls_v3 as E
from check_tmnt_render_oa import address
H,L,T=E.H,E.L,E.T;P=E.N;H.O=P/'joint';O=R/'build/ff-fx-native0-pre-proposal-v1'

def main():
    O.mkdir(exist_ok=False);old=(P/'joint/ff-epoch-workers.s').read_text();new=old
    a=''' lda #$80
 sta SmFreezePalettePending   ; normal native postflush validity LAST.
 rts'''
    z=''' lda R4
 beq FfMuxEpochNativeCommit
 lda #$80                    ; exact FX colors AFTER native palette queue.
 bne FfMuxEpochCommitPending
FfMuxEpochNativeCommit:
 lda #$c0                    ; native0 restore BEFORE queue: laterAxe/Bowser wins.
FfMuxEpochCommitPending:
 sta SmFreezePalettePending   ; complete OAM+palette packet, validity LAST.
 rts'''
    assert new.count(a)==1;new=new.replace(a,z)
    a=''' and #3
 beq FfMuxEpochNone                     ; body0 always retained.
 cmp #2'''
    z=''' and #3
 ; CMP2/BCC covers both body0 and invalidrole1; callers consume their ownCMP.
 cmp #2'''
    assert new.count(a)==1;new=new.replace(a,z)
    begin=new.index('FfMuxHeartbeat:');end=new.index('FfMuxHeartbeatEnd:',begin)
    new=new[:begin]+'''FfMuxHeartbeat:
 ; The seven-byte packet remains complete after normalNMI consumes Pending.
 ; Reissue ONLY ready-owned nonnative1..5: native0/C0 must precede newqueue.
 php
 pha
 lda SmFreezeLastBlue
 cmp #$81
 bcc FfMuxEpochHeartbeatDone
 cmp #$86
 bcs FfMuxEpochHeartbeatDone
 lda #0
 sta SmFreezePalettePending    ; invalidate FIRST, including malformedpacket.
 lda SmFreezePalettePacket
 cmp #$3f
 bne FfMuxEpochHeartbeatDone
 lda SmFreezePalettePacket+1
 cmp #$15
 bne FfMuxEpochHeartbeatDone
 lda SmFreezePalettePacket+2
 cmp #3
 bne FfMuxEpochHeartbeatDone
 lda SmFreezePalettePacket+6
 bne FfMuxEpochHeartbeatDone
 lda #$80
 sta SmFreezePalettePending    ; exact stable packet, validity LAST.
FfMuxEpochHeartbeatDone:
 pla
 plp
 rts
'''+new[end:]
    B.write(O/'workers.s',new)
    B.write(O/'source.patch',''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='fast-post80/ff-epoch-workers.s',tofile='proposal-pre0/ff-epoch-workers.s')))
    cmd=[str(R/'tools/Windows/cc65/bin/ca65.exe'),'-g','--cpu','6502x','--create-full-dep',str(O/'workers.dep'),'-o',str(O/'workers.o'),str(O/'workers.s')]
    B.save(O/'validated-outputs.json',validate(cmd,O,cwd=R));B.run(O,cmd,'compile')
    b=H.C.qualified(P/'joint/candidate.nes');base=E.fresh(b,3);rows=[]
    for family,late,full in __import__('itertools').product([0,1],[0,1],[0,1]):
        m,c,lo=E.frame(base,2,1,1,1,'flower',[(0,144)],family)
        assert H.get(m,'SmFreezeLastBlue')&7==family
        # Explicit proposed writer state only; no claim current worker emitted
        # C0. This executes the existing genuine pre/post consumer chain.
        H.put(m,SmFreezePalettePending=192 if family==0 else 128)
        if full:L.Q.queue(m,1)
        if late:H.invoke(m,'SamusFreezePaletteStoreA',a=8)
        r=L.Q.consume(m,0)
        want=([0x1a,0x30,0x27]if late or full else[0x1c,0x36,0x17])if family==0 else[0x16,0x26,0x30]
        assert r['P1']==want,(family,late,full,r)
        rows.append(dict(family=family,lateBowser=late,fullqueue=full,actual_P1=r['P1']))
    files={Path(__file__),O/'workers.s',O/'workers.o',O/'source.patch',O/'compile.json',O/'validated-outputs.json',
        P/'source-closure.json',P/'joint/candidate.nes',P/'joint/candidate.dbg',
        R/'build/ff-fx-epoch-late-native-audit-v2/counterexample.json'}
    B.save(O/'proposal.json',dict(passed=True,source_installed=False,emitted_worker_executed=False,native=False,admitted=False,
        parent_sha256=B.sha(P/'joint/candidate.nes'),proposed_sizes=dict(main=263,classify=67,heartbeat=52,packet=115,colors=27,tables=15),
        routine_packing=dict(classify='A289..<A2CC67B',heartbeat='A2CC..<A30052B',packet='B68B..<B6FE115B',main='BECF..<BFD6263B'),
        existing_pre_post_consumer_fixtures=rows,
        semantics='Completed nativefamily0 commits existing exactC0 before nativequeue; activeFX1..5 commits80 after queue. Heartbeat only reissues exclusive stableFXpacket, verifiesheader+terminator withclearfirst/publishlast; never rewritesnative0/C0.',
        obligations=['Actual linked newwriter/heartbeat tests remain pending root review; current112b stillretainslateBowserfailure.',
            'Retain original bodytick/ACK, nativeMain/lifecycle/fullqueue/lag/abandon/cold/fullcookie/33SMC/mapperproof.',
            'Kernel payload/carrier/fullcookie must advance coherently on any actual source link.'],
        bindings={str(f.resolve()):B.sha(f)for f in sorted(files)}))
    print('PROPOSAL',B.sha(O/'proposal.json'),flush=True)

if __name__=='__main__':main()
