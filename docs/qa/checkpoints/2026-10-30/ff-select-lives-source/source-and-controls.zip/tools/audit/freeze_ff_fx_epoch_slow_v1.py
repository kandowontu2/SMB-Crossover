"""Retain real color/lifecycle positives together with measured performance hold."""
from pathlib import Path
import json,sys
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import prepare_ff_joint_source_v1 as B
O=R/'build/ff-fx-epoch-cart-v4'

def main():
    target=O/'handoff-performance-hold-v1.json';assert not target.exists()
    receipts=[O/name for name in['source-closure.json','epoch-controls-v2.json','heartbeat-controls-v1.json','safety-controls-v1.json']]
    files={Path(__file__)}
    for p in receipts:
        d=json.loads(p.read_text());assert d['passed'];files.add(p)
        for f,h in d['bindings'].items():assert B.sha(f)==h,f;files.add(Path(f))
    neg=O/'epoch-negative-v1.json';d=json.loads(neg.read_text());assert not d['passed'];files.add(neg)
    for f,h in d['bindings'].items():assert B.sha(f)==h,f;files.add(Path(f))
    preparation=[]
    for version,reason in[(1,'The unlinked proposal imported FwCheck/FwCallEnter that are already local when included in loader. Compilation stopped.'),
                           (2,'Basename-only object selection met both FF and Quick loader/stream; explicit pre-link assertion stopped.'),
                           (3,'Actual ROM linked correctly, but unqualified new private Found/Done labels shadowed old DBG convenience entries; source-only unique names fixed this; v3 and v4 ROM bytes are identical.')]:
        root=R/f'build/ff-fx-epoch-cart-v{version}'
        paths=[p for p in root.rglob('*')if p.is_file()and p.suffix in['.json','.s','.inc','.cfg','.dep','.o','.nes','.dbg','.map','.lbl','.bin']]
        files.update(paths);files.add(R/f'tools/audit/prepare_ff_fx_epoch_cart_v{version}.py')
        preparation.append(dict(root=str(root),reason=reason,bindings={str(p.resolve()):B.sha(p)for p in paths}))
    B.save(O/'retained-preparation-negatives.json',dict(negatives=preparation,source_old_outputs_unchanged=True))
    files.add(O/'retained-preparation-negatives.json')
    rows=json.loads((O/'epoch-controls-v2.json').read_text())['checks']['actual_DrawAll_pairs']['rows']
    perf=dict(qualification='HOLD_NOT_NATIVE_OR_GAMEPLAY_ADMITTED',
        extra_DrawAll_CPU=[min(r['CPU_delta']for r in rows),max(r['CPU_delta']for r in rows)],
        maximum_tested_DrawAll_CPU=max(r['new_CPU']for r in rows),minimum_observed_SP=min(r['minimum_SP']for r in rows),
        reason='Repeated classification during Scan and all64 Paint slots adds5394..16004CPU; original largeFX callback is already expensive. Full native/frame deadline/campaign unqualified.')
    B.write(O/'README-performance-hold.md','''Private emitted FF exact-color scheduler: source color/lifecycle positives, performance HOLD.

ROM5797f54f, RAM3 image9170ad72, full current cookie version7. Source-built
from frozen marker5c225bb9 after exact runtime alias approval. Original occupied
CORE/art/code/CHR/publicPCs are unchanged; own104B retired ABI+18Bnative tail,
ownrow29, fullcookie and existing8KB carrier are the only changed ROM ranges.

3072 real completed nativeDrawAll/normalNMI cases match independent original
OAM filtering for all6cursor starts; body0/P0, source fields, complete mixed
world groups, nativeP2/P3/backdrop/CHR, returnedAXYP/SP, R0..7 and intentional
native C-bank publication are exact.768 all64flag bodytick/heartbeat/fullqueue
pairs preserve original bodyACK and outputs.48 actualMain pause/skip/ordinary
cases keep lastfamily without advancing cursor when drawing is skipped.

64 actualforeignDrawAll pairs keep identical application/OAM/nativeoutputs
and mapper writes (no extra foreign fartrip,+27CPU);32 malformed full-cookie
cases execute no unverifiedRAM3.128 realMenuResolve,48 realScene,32fullqueue/
abandon/lag and12 actual8192Bcopy+verify loader cases pass. Original v8
retirement/acquisition/native preflush and its prior source negatives remain.

The slow filter adds5394..16004CPU perDrawAll, reaching50832CPU in the largest
tested case. It rebuilds the active packet on every UI heartbeat (+942..953CPU).
This is explicitly NOT performance-qualified, native-run, selectable-ready,
campaign-qualified, or installed. New worker-specific ISR/full active Main
source regressions still require qualification. Preserve this slow reference
while optimizing; no admission or timing inference follows from CPU positives.

Preparation negatives and the repeated-reference-queue oracle mistake are
retained separately. All compiler/linker outputs were guarded into NEW private
roots. No frozen/shared source, installed ROM, Git index or native queue changed.
''')
    files.add(O/'README-performance-hold.md')
    out=dict(passed=True,status='SOURCE_COLOR_AND_LIFECYCLE_PASS_PERFORMANCE_HOLD',native=False,admitted=False,
        worker_ISR_qualified=False,actual_source_scheduler=True,candidate_sha256=B.sha(O/'joint/candidate.nes'),
        RAM3_sha256=B.sha(O/'joint/ram3.bin'),performance=perf,
        receipts={str(p.resolve()):B.sha(p)for p in receipts},retained_negatives=[str(neg),str(O/'retained-preparation-negatives.json')],
        bindings={str(f.resolve()):B.sha(f)for f in sorted(files)})
    B.save(target,out)
    print(json.dumps(dict(path=str(target),sha256=B.sha(target),bindings=len(files),performance=perf)),flush=True)

if __name__=='__main__':main()
