"""Real busy-Main vector cuts and foreign/cold boundaries for PRE0 worker.

This is a source CPU fixture. It neither grants runtime state nor launches a
native emulator. Normal NMI is tested after genuine Main completion; an active
Main is interrupted only through the real lag-NMI/IRQ paths.
"""
from pathlib import Path
import itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import ff_fx_epoch_heartbeat_controls_v8 as A
import ff_host_pickups_vectors_v2 as V
from ff_wram_host_isr_v4 import clone
from check_tmnt_render_oa import address
H,E,T,L=A.H,A.E,A.T,A.L;N=E.N;H.O=N/'joint'


def signature(m,c):
    exclude=set(range(0x100,0x200))|set(range(0x5114,0x5118))
    # Reading PPU registers merely to compare fixtures changes the actual
    # hardware latch. Inspect their raw bus snapshots without doing CPU reads.
    state=bytes((list.__getitem__(m,i)if 0x2000<=i<0x5c00 else m[i])
        for i in range(0x8000)if i not in exclude)
    return state,(c.a,c.x,c.y,c.p,c.sp),m.rawtags[:]


def foreign(old,new):
    seeds=[E.F.seed(b)for b in[old,new]];rows=[]
    for selected,flags in itertools.product([i for i in range(33)if i!=22],[0x30,0x71]):
        pair=[];cost=[];maps=[]
        for s in seeds:
            m=T.copy(s);H.put(m,SelectedCharacter=selected,SmFreezeLastBlue=133,
                SmFreezeTurn=4,SmFreezePalettePending=0,SmFreezeRenderState=0)
            m.writes.clear();c=H.start(m,'SamusFreezeDrawAll',p=flags);c,low=H.finish(m,c)
            pair.append(signature(m,c));cost.append(c.processorCycles)
            maps.append([(a,v)for a,v in m.writes if 0x5114<=a<=0x5117])
        assert pair[0]==pair[1],('foreign DrawAll state/output',selected,flags)
        assert maps[0]==maps[1],('foreign extra mapper trip',selected,flags)
        rows.append(dict(selected=selected,flags=flags,CPU_delta=cost[1]-cost[0]))
    return dict(cases=len(rows),rows=rows,all_original_application_OAM_AXYP_SP_rawmaps_and_mapper_writes_exact=True)


def cold(old,new):
    seeds=[E.fresh(b,1)for b in[old,new]];rows=[]
    for byte,entry in itertools.product(range(16),['draw','tick']):
        pair=[];entered=[]
        for b,s in zip([old,new],seeds):
            m=T.copy(s);m.ram[3][0x1fe0+byte]^=1
            H.put(m,SmFreezeLastBlue=133,SmFreezeTurn=4,SmFreezePalettePending=0,NmiDisable=255)
            hits=[]
            def observe(mem,c,i):
                if c.pc>=0x8000 and mem.rawtags[(c.pc-0x8000)//8192]==3:hits.append(c.pc)
            if entry=='draw':
                c=H.start(m,'SamusFreezeDrawAll');c,low=H.finish(m,c,observe)
            else:c,low=H.invoke(m,'FfMuxTickROM'if b is new else'FwPaletteTick',hook=observe)
            assert not hits,('executed unverified RAM3',byte,entry,hits[:4])
            assert H.get(m,'SmFreezeLastBlue')==133 and H.get(m,'SmFreezeTurn')==4
            assert H.get(m,'SmFreezePalettePending')==0
            pair.append(signature(m,c));entered.append(len(hits))
        assert pair[0]==pair[1],('rejected full-cookie boundary',byte,entry)
        rows.append(dict(corrupt_cookie_byte=byte,entry=entry,unverified_RAM3_instructions=entered))
    return dict(cases=len(rows),rows=rows,all16cookiebytes_required_at_both_worker_ingresses=True)


def vectors(b):
    ranges=[(3,address(b,a),address(b,z))for a,z in[
        ('FfMuxNativeLate','FfMuxNativeLateEnd'),
        ('FfMuxClassify','FfMuxClassifyEnd'),
        ('FfMuxHeartbeat','FfMuxHeartbeatEnd'),
        ('FfMuxPacket','FfMuxPacketEnd')]]
    ranges.append((0xbe,address(b,'FfMuxNativeROM'),address(b,'FfMuxNativeROMEnd')))
    samples=[];seen=set();completed=[]
    for family,skip in itertools.product([0,1,4,5],[0,1]):
        m=A.actual_epoch(b,family)
        H.put(m,NmiDisable=255,GamePauseStatus=0,ShouldSkipDrawSprites=skip,
            VRAM_Buffer1_Offset=0,VRAM_Buffer_AddrCtrl=0)
        m[address(b,'VRAM_Buffer1')]=0
        def capture(mem,c,i):
            if not 0x8000<=c.pc<0xe000:return
            tag=mem.rawtags[(c.pc-0x8000)//8192]
            if any(tag==t and a<=c.pc<z for t,a,z in ranges):
                key=(c.pc,tag)
                if key not in seen:
                    assert H.get(mem,'NmiDisable')==255,('worker outside Main-busy phase',hex(c.pc))
                    seen.add(key);samples.append((family,skip,i,clone(mem,c)))
        c,low=E.M.invoke_main(m,capture)
        assert H.get(m,'NmiDisable')==0
        pending=H.get(m,'SmFreezePalettePending');last=H.get(m,'SmFreezeLastBlue')&7
        assert pending in[0,128,192]
        r=A.consume(m)
        if pending:
            want=E.O.family_vectors(b).get(last,list(m.vram[0x3f15:0x3f18]))
            assert r['P1']==want
        assert r['pending']==0
        H.exact(m)
        completed.append(dict(prior_family=family,skip=skip,CPU=c.processorCycles,
            minimum_SP=low,normal_NMI_after_Main=r))
    assert samples
    rows=[]
    for family,skip,step,(state,cpu)in samples:
        for kind in['NMI','IRQ']:
            if kind=='IRQ'and cpu.p&cpu.INTERRUPT:continue
            m,c=clone(state,cpu)
            assert H.get(m,'NmiDisable')==255
            proof=V.interrupt(m,c,kind)
            H.finish(m,c)
            assert c.sp==224 and H.get(m,'NmiDisable')==0
            H.exact(m)
            rows.append(dict(prior_family=family,skip=skip,step=step,
                PC=cpu.pc,raw_A=state.rawtags[1],raw_C=state.rawtags[2],**proof))
    return dict(instruction_seams=len(samples),actual_vector_cases=len(rows),rows=rows,
        completed_Main_cases=completed,actual_normal_NMI_after_Main_cases=len(completed),
        actual_lag_NMI_and_IRQ_during_Main=True,
        all_AXYP_SP_33SMC_livepage1_rawmaps_R0_R1_R6_R7_RAM0_to_3_preserved=True)


def main():
    p=dict(passed=False,native=False,admitted=False,performance_HOLD=True,checks={})
    try:
        old=H.C.qualified(E.P/'joint/candidate.nes');new=H.C.qualified(N/'joint/candidate.nes')
        for name,fn in [('foreign_DrawAll',lambda:foreign(old,new)),
            ('fullcookie_rejection',lambda:cold(old,new)),('actual_Main_vectors',lambda:vectors(new))]:
            p['checks'][name]=fn();print(name,'PASS',flush=True)
        p['passed']=True
    except Exception as e:p.update(error=repr(e),traceback=traceback.format_exc())
    files=[Path(__file__),Path(A.__file__),Path(E.__file__),Path(V.__file__),Path(H.__file__),
        N/'source-closure.json',N/'joint/candidate.nes',N/'joint/candidate.dbg',
        E.P/'handoff.json',E.P/'joint/candidate.nes',E.P/'joint/candidate.dbg']
    p['bindings']={str(f.resolve()):L.sha(f)for f in files}
    out=N/('vector-controls-v1.json'if p['passed']else'vector-negative-v1.json');assert not out.exists()
    out.write_text(json.dumps(p,indent=2)+'\n',encoding='utf-8',newline='\n')
    print(json.dumps(dict(passed=p['passed'],path=str(out),error=p.get('error'))),flush=True);assert p['passed']


if __name__=='__main__':main()
