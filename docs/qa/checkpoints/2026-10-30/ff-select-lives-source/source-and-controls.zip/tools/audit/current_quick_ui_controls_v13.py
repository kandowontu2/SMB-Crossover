"""Exercise the genuine early UI consumer, not a manually selected service."""
from pathlib import Path
import json,sys,traceback
import prepare_current_quick_ui_v13 as B
import current_quick_transport_controls_v4 as T
C=T.C;S=T.S;N=B.N;P=B.P;O=B.O
FLAGS=[p for p in range(256)if p&48==48]
def put(m,**kw):
 for n,v in kw.items():m.set(n,v)
def bus(path):
 m=T.bus(path)
 put(m,OperMode=1,OperMode_Task=3,GameEngineSubroutine=8,CrossoverMenuState=0,DisableScreenFlag=0,NmiDisable=255,FamilyMainCommit=1,GamePauseStatus=0,TimerControl=0,
     InvDirty=1,InvHudActive=1,InvPrevious=0,InvRefill=0,SavedJoypad1Bits=129,VRAM_Buffer_AddrCtrl=0,VRAM_Buffer1_Offset=0,X5BounceOwner=0,NativeStatusPending=0)
 return m
def check(a,b,ra,rb,la,lb,case):
 assert ra==rb,('AXYP/SP',case,ra,rb)
 assert a.ram[:256]==b.ram[:256]and a.ram[512:0x5100]==b.ram[512:0x5100]and a.ram[0x5140:0x8000]==b.ram[0x5140:0x8000],('application',case)
 smc=a.lab['SafecallA_SMC'];lo=next(int(x['start'],0)for x in a.bundle['segs'].values()if x['name']=='"SMCCODE"')
 assert a.ram[lo:lo+33]==b.ram[lo:lo+33],('33SMC',case)
 ignore=set(range(256,512))|set(range(0x5100,0x5140))
 app=lambda q:[(ad,v)for ad,v in q.writes if ad not in ignore]
 assert app(a)==app(b),('ordered application writes',case,app(a),app(b))
 live=min(la,lb);assert a.ram[256:256+live]==b.ram[256:256+live],('live/static page1',case)
 assert a.tags==b.tags and a.chr==b.chr and a.wram==b.wram,('raw maps/CHR/cache',case)
 maps=lambda q:[(ad,v)for ad,v in q.writes if 0x5114<=ad<=0x5117]
 assert maps(a)==maps(b),('exact foreign mapper sequence',case,maps(a),maps(b))
def api():
 templates=[bus(x)for x in[P,N]];rows=[]
 for raw in range(256):
  for p in FLAGS:
   a,b=[T.fork(t)for t in templates]
   for q in[a,b]:put(q,SelectedCharacter=raw,FmAlts=0,RlVariant=0)
   ra,ca,la=S.execute(a,'X5BounceUiDispatch',A=131,X=90,Y=199,P=p)
   rb,cb,lb=S.execute(b,'X5BounceUiDispatch',A=131,X=90,Y=199,P=p)
   check(a,b,ra,rb,la,lb,[raw,p]);rows.append(cb-ca)
 # Fully active source cache: all alternate bits plus stale Roll flags must
 # use the exact existing Quick predicate, with genuine worker semantics.
 C.O=N;C.CODE=(N/'code.bin').read_bytes();C.DATA=(N/'data.bin').read_bytes()
 q=bus(N);put(q,SelectedCharacter=9,FmAlts=32,DisableScreenFlag=1);C.invoke(q,'QwConstruct')
 put(q,DisableScreenFlag=0,NativeStatusPending=0);selected=[];legacy=[]
 for bits in range(256):
  for roll in [0,1]:
   for p in [0x31,0x70,0xf9,0xb2]:
    a=T.fork(q);b=T.fork(q)
    for m in[a,b]:put(m,FmAlts=bits,RlVariant=roll)
    if bits&32:
     ra,ca,la=S.execute(a,'QhUi',A=131,X=90,Y=199,P=p)
     rb,cb,lb=S.execute(b,'X5BounceUiDispatch',A=131,X=90,Y=199,P=p)
     # Genuine transport scratch/SMC differs from directly calling the worker.
     transport=set()
     for n,size in [('ArenaGateA',1),('ArenaGateP',1),('ArenaGatePtr',2),('ArenaGateBank',1)]:transport.update(range(a.lab[n],a.lab[n]+size))
     assert ra==rb,('Quick AXYP',bits,roll,p,ra,rb)
     assert all(a.ram[i]==b.ram[i]for i in range(0x8000)if i not in transport and not 256<=i<512 and not 0x5100<=i<0x5140),('Quick application',bits,roll,p)
     assert a.wram==b.wram and a.tags==b.tags and a.chr==b.chr
     ignore=transport|set(range(256,512))|set(range(0x5100,0x5140))
     app=lambda m:[(ad,v)for ad,v in m.writes if ad not in ignore]
     assert app(a)==app(b),('Quick orderedwrites',bits,roll,p)
     selected.append(cb-ca)
    else:
     old=T.fork(templates[0]);old.ram[:]=a.ram;old.wram=[bytearray(x)for x in a.wram]
     ra,ca,la=S.execute(old,'X5BounceUiDispatch',A=131,X=90,Y=199,P=p)
     rb,cb,lb=S.execute(b,'X5BounceUiDispatch',A=131,X=90,Y=199,P=p)
     check(old,b,ra,rb,la,lb,['Bass/Roll',bits,roll,p]);legacy.append(cb-ca)
 return dict(foreign_all_raw_all64flags_pairs=len(rows),foreign_CPU_delta=[min(rows),max(rows)],Quick_exact_predicate_worker_pairs=len(selected),Quick_wrapper_CPU=[min(selected),max(selected)],Bass_Roll_all_other_alt_pairs=len(legacy),Bass_Roll_CPU_delta=[min(legacy),max(legacy)])
def main():
 out=O/'early-ui-source-controls.json';assert not out.exists();d=dict(passed=False,native=False)
 try:d.update(checks=api(),passed=True)
 except Exception as e:d.update(error=repr(e),traceback=traceback.format_exc())
 d['bindings']={str(Path(p).resolve()):B.sha(p)for p in[__file__,N/'candidate.nes',N/'candidate.dbg',P/'candidate.nes',P/'candidate.dbg']}
 out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items()if k!='bindings'}));assert d['passed'],d.get('error')
if __name__=='__main__':main()
