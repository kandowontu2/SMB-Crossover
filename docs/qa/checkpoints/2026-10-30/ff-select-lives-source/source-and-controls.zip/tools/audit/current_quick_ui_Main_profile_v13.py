"""Genuine cold/area/Main consumer proof and exact per-instruction CPU totals."""
from collections import defaultdict
from pathlib import Path
import json
import prepare_current_quick_ui_v13 as B
import quickman_wram_palette_controls_v6 as C

R=B.R;N=B.N;O=B.O
WATCH=['GameLoop','X5BounceUiDispatch','QhUi','PlayerMovementSubs','PlayerBGCollision',
       'DrawAllMetasprites','QhDraw','QhGraphics','QhMovement','QuickManTick',
       'QuickManWorldProbe','QhWeapons','QwService','QwRouter','QhDispatch',
       'HuPlayerSubsAdapter','InventoryUiTick','InventoryHud']
ROWS=[]
def profiler(m):
 points={}
 for n in WATCH:
  if n not in m.lab:continue
  pc=m.lab[n];tag=1 if n.startswith('Qh')or n.startswith('QuickMan')else(m.bank(n)|128)
  points[(tag,pc)]=n
 segs=[]
 for g in m.bundle['segs'].values():
  if 'ooffs'not in g:continue
  lo=int(g['start'],0);size=int(g['size'],0);name=g['name'].strip('"')
  if lo<0x8000:continue
  if name=='QW_CODE':tag=1
  elif Path(g.get('oname','').strip('"')).name=='candidate.nes':tag=((int(g['ooffs'],0)-16)//8192)|128
  else:continue
  segs.append((tag,lo,lo+size,name))
 pending=None;frames=[];closed=[];segments=defaultdict(int);lastcpu=None
 def charge(cpu):
  nonlocal pending
  if pending:
   cycles=cpu.processorCycles-pending['cycles'];segments[pending['segment']]+=cycles
   for f in pending['frames']:f['inclusive']+=cycles
   if pending['frames']:pending['frames'][-1]['exclusive']+=cycles
 def hook(cpu):
  nonlocal pending,lastcpu
  charge(cpu);lastcpu=cpu
  tag=m.tags[(cpu.pc-0x8000)//8192]if cpu.pc>=0x8000 else-1
  while frames and frames[-1]['returnPC']==cpu.pc and frames[-1]['SP']+2==cpu.sp:
   closed.append(frames.pop())
  name=points.get((tag,cpu.pc))
  if name:
   ret=m[0x100+((cpu.sp+1)&255)]+256*m[0x100+((cpu.sp+2)&255)]+1
   frames.append(dict(name=name,SP=cpu.sp,returnPC=ret,inclusive=0,exclusive=0))
  segment='SMC/RAM'if cpu.pc<0x8000 else next((n for t,a,b,n in segs if t==tag and a<=cpu.pc<b),'UNATTRIBUTED')
  pending=dict(cycles=cpu.processorCycles,segment=segment,frames=frames[:])
 def done(result):
  charge(lastcpu);assert sum(segments.values())==result['CPU'],(sum(segments.values()),result['CPU'])
  # The synthetic GameLoop worker may close at the unobserved sentinel.
  closed.extend(frames)
  grouped={}
  for f in closed:
   d=grouped.setdefault(f['name'],dict(calls=0,inclusive=0,exclusive=0));d['calls']+=1
   d['inclusive']+=f['inclusive'];d['exclusive']+=f['exclusive']
  return dict(CPU=result['CPU'],segments=dict(segments),functions=grouped)
 return hook,done

def main():
 source=R/'tools/audit/current_quick_actual_area_geometry_v11.py'
 text=source.read_text().replace('import prepare_current_quick_cold_v11 as B','import prepare_current_quick_ui_v13 as B')
 text=text.replace("'QhBoxProfile']","'QhBoxProfile','QhUi']")
 text=text.replace("assert all(counts[n]==1 for n in names[:6]),","assert all(counts[n]==1 for n in names[:6])and counts['QhUi']==1,")
 # Capture genuine invocations after the original mapper-output assertion is
 # installed by the area fixture; only the profiler hook is additive.
 anchor='def main():\n'
 injected='''original_invoke=C.invoke
def profiled_invoke(m,target,*args,**kwargs):
 if target!='GameLoop':return original_invoke(m,target,*args,**kwargs)
 hook,done=profiler(m)
 result=original_invoke(m,target,*args,hook=hook,**kwargs)
 ROWS.append(done(result))
 return result
C.invoke=profiled_invoke
'''
 assert text.count(anchor)==1;text=text.replace(anchor,injected+'\n'+anchor)
 ns=dict(__name__='quick_ui_geometry',__file__=str(source),profiler=profiler,ROWS=ROWS)
 exec(compile(text,str(source),'exec'),ns);ns['main']()
 assert len(ROWS)==120
 groups=defaultdict(lambda:dict(calls=0,inclusive=0,exclusive=0));segments=defaultdict(int)
 for row in ROWS:
  for n,v in row['segments'].items():segments[n]+=v
  for n,v in row['functions'].items():
   for k,x in v.items():groups[n][k]+=x
 report=dict(passed=True,native=False,Main_updates=len(ROWS),Main_CPU_range=[min(x['CPU']for x in ROWS),max(x['CPU']for x in ROWS)],
   Main_CPU_mean=sum(x['CPU']for x in ROWS)/len(ROWS),segments=dict(sorted(segments.items(),key=lambda x:-x[1])),functions=dict(groups),rows=ROWS,
   limits=['Exact instruction CPU under real parsed 1-1 geometry; no interrupt during these Main calls. Native cadence remains unqualified.',
    'Parser startup consumes genuine queues through real NMI; each Main fixture resets the queue offset, so this is not a sustained native VRAM publication claim.'],
   bindings={str(p.resolve()):B.sha(p)for p in[Path(__file__),source,N/'candidate.nes',N/'candidate.dbg']})
 (O/'actual-Main-CPU-attribution.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({k:v for k,v in report.items()if k not in ['rows','bindings']}))
if __name__=='__main__':main()
