"""Retain the actual C116 fast-copy ABI fault in the first preflush leaf."""
from pathlib import Path
import json,sys
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import ff_fx_palette_lifecycle_controls_v3 as L
from check_tmnt_render_oa import address

def main():
    p=L.O/'preflush-C116-decoder-negative-v1.json';assert not p.exists()
    b=L.H.C.qualified(L.H.O/'candidate.nes');m=L.M.setup(b)
    L.put_owner(m);L.Q.queue(m,0)
    L.H.put(m,SelectedCharacter=22,CrossoverMenuIndex=0,FmAlts=0,RdVariant=0,MarioVariant=0)
    L.H.invoke(m,'MenuResolveCharacter');L.H.put(m,NmiDisable=0)
    c=L.H.start(m,'FwCheck');c.nmi();trace=[]
    for i in range(10000):
        tag=m.rawtags[(c.pc-0x8000)//8192]if c.pc>=0x8000 else -1
        trace.append(dict(step=i,PC=c.pc,rawbank=tag,opcode=m[c.pc],A=c.a,X=c.x,Y=c.y,P=c.p,SP=c.sp))
        if m[c.pc]==0:break
        c.step()
    else:raise AssertionError('Expected actual retained preflush fault')
    copy_pc=address(b,'FastNmiVramCopy')
    assert any(t['PC']==copy_pc and t['rawbank']==0xdd for t in trace)
    assert c.pc<0x8000 and m.rawtags[2]==0xdd
    proof=dict(passed=False,retained_product_negative=True,native=False,
      cause='Resident UpdateScreen jumps to genuine FastNmiVramCopy in C116. A C93 near-call executes FF data at that C address and corrupts its return stack.',
      actual_fast_copy_PC=copy_pc,required_physical_C=116,actual_physical_C=93,trace=trace,
      bindings={str(f.resolve()):L.sha(f)for f in[Path(__file__),Path(L.__file__),L.O/'source-closure.json',L.H.O/'candidate.nes',L.H.O/'candidate.dbg']})
    p.write_text(json.dumps(proof,indent=2)+'\n',newline='\n');print(p)

if __name__=='__main__':main()
