"""Re-execute strict real-producer rendering on the current ready source cart."""
from pathlib import Path
import json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import ff_current_ready_cold_controls_v2 as C
import ff_fx_epoch_pre0_consumers_v1 as P
H,E,L=C.H,C.E,C.L;N=C.N;H.O=N/'joint'


def main():
    p=dict(passed=False,native=False,admitted=False,installed=False,checks={})
    try:
        old=H.C.qualified(E.P/'joint/candidate.nes');new=H.C.qualified(N/'joint/candidate.nes')
        for name,fn in [('strict_actual_producer_DrawAll',lambda:E.draw_pairs(old,new)),
            ('original_body_heartbeat',lambda:C.A.tick_pairs(old,new)),
            ('late_native_queue_and_actual_normal_lag_NMI',lambda:P.late_native(new))]:
            p['checks'][name]=fn();print(name,'PASS',flush=True)
        p['passed']=True
    except Exception as e:p.update(error=repr(e),traceback=traceback.format_exc())
    files=[Path(__file__),Path(C.__file__),Path(E.__file__),Path(P.__file__),Path(H.__file__),N/'source-closure.json',
        N/'joint/candidate.nes',N/'joint/candidate.dbg',E.P/'handoff.json']
    p['bindings']={str(f.resolve()):L.sha(f)for f in files}
    out=N/('render-controls-v1.json'if p['passed']else'render-negative-v1.json');assert not out.exists()
    out.write_text(json.dumps(p,indent=2)+'\n',encoding='utf-8',newline='\n')
    print(json.dumps(dict(passed=p['passed'],path=str(out),error=p.get('error'))),flush=True);assert p['passed']


if __name__=='__main__':main()
