"""Read-only source attribute ownership before transient own-OAM family tags."""
from pathlib import Path
import collections,itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import ff_fx_epoch_cart_controls_v2 as E
from check_tmnt_render_oa import address,location
H,M,T=E.H,E.M,E.T;P=E.P;O=R/'build/ff-fx-epoch-tag-audit-v2';H.O=P/'joint'

def source(m,n,**kw):return H.C.run(m,n,raw=True,**kw)[0]

def iterators(b):
    m=M.setup(b);rows=[];count=0
    for entry,face,off in itertools.product(range(158),[1,2],[0,1]):
        chunks=[]
        for chunk in range(8):
            H.put(m,FfSlot=face,PlayerOutlinesOff=off)
            c=source(m,'FfRenderChunk',a=entry,x=chunk,y=0)
            if not c.p&1:break
            n=H.get(m,'FfRenderBuffer');at=address(b,'FfRenderBuffer')
            attrs=[m[at+2+i]for i in range(0,n,4)]
            assert not any(v&0x1c for v in attrs),('source-owned metadata collision',entry,face,off,chunk,attrs)
            count+=len(attrs);chunks.append(dict(chunk=chunk,parts=len(attrs),original_attributes=sorted(set(attrs))))
        rows.append(dict(entry=entry,face=face,outlines_off=off,chunks=chunks))
    return dict(views=len(rows),parts=count,rows=rows,all_original_FF_descriptor_bits2_3_4_zero=True)

def final_OAM(b):
    seeds=[E.fresh(b,a)for a in range(4)];rows=[];attrs=set();nativeFlash=set()
    for area,variant,off,face,flash,poison in itertools.product(range(4),range(4),[0,1],[1,2],[0,12],[0,0xff]):
        m=T.copy(seeds[area]);H.put(m,FfVariant=variant,PlayerOutlinesOff=off,PlayerFacingDir=face,
            Player_SprAttrib=poison,GuestPowerupActive=0,NmiDisable=255)
        H.invoke(m,'FwHostGraphics');assert H.get(m,'Player_SprAttrib')==0
        for slot,entry in[(0,144),(12,154)]:
            if variant==2:E.U.set_projectile(m,slot,entry,face)
        for i in range(6):m[address(b,'Enemy_Flag')+i]=0
        for n,v in[('Enemy_Flag',1),('Enemy_ID',6),('Enemy_X_Position',192),('Enemy_PageLoc',0),
            ('Enemy_Y_Position',160),('Enemy_Y_HighPos',1),('MmEnemyFlash',flash)]:m[address(b,n)]=v
        m[address(b,'ObjectMetasprite')+1]=address(b,'METASPRITE_KOOPA_WALKING_1')
        H.invoke(m,'FwHostGraphics');E.F.invoke_drawall(m)
        ptr=H.get(m,'SmPosePtr')+256*m[address(b,'SmPosePtr')+1]
        end=H.get(m,'RgOamPlayerStart')+m[ptr];rot=H.get(m,'RgOamRotation');own=[];world=[]
        for logical in range(0,H.get(m,'RgOamUsed'),4):
            at=(logical+rot)&255
            if m[512+at]>=240:continue
            v=m[514+at]
            if logical<end:
                assert not v&0x1c,('actual admitted FF metadata collision',area,variant,off,face,flash,poison,logical,v)
                own.append(v);attrs.add(v)
            else:world.append(v);nativeFlash.add(v&0x0c)
        rows.append(dict(area=area,variant=variant,off=off,face=face,native_flash=flash,
            prior_Player_SprAttrib=poison,own_visible_parts=len(own),world_attributes=sorted(set(world))))
    assert nativeFlash<={0},('Visible final native metadata bits were not stripped',nativeFlash)
    return dict(cases=len(rows),rows=rows,visible_FF_attributes=sorted(attrs),native_world_ignored_bits_seen=sorted(nativeFlash),
        native_pre_OAM_bit3_is_stripped_by_native_writer=True,FF_visible_bits2_3_4_exclusively_zero=True)

def main():
    O.mkdir(exist_ok=False);p=dict(passed=False,read_only=True,native=False,admitted=False,tagging_installed=False,checks={})
    try:
        b=H.C.qualified(P/'joint/candidate.nes')
        at=location(b,'MetaspriteRenderLoop::WritePalette')
        assert list(b['raw'][at:at+5])==[0x29,0xf3,0x9d,2,2]
        p['checks']['genuine_native_writer']=dict(ROM_offset=at,opcodes=list(b['raw'][at:at+5]),meaning='AND F3; STA0202,X clears software bits2/3 before hardware-visible OAM')
        p['checks']['actual_source_iterators']=iterators(b);print('sourceiterators PASS',flush=True)
        p['checks']['actual_final_OAM']=final_OAM(b);print('actual finalOAM PASS',flush=True)
        p['proposal']=dict(FF_visible='Encode family+1 only in actual admitted FF-owned visible records bits2..4; original exact0 bits proven. Body0 tag0. Clear all own2..4 beforeDMA.',
            nativeworld='Native final visible bits2/3 are zero; native AND F3 strips pre-OAM FLASH before actual STA. Encode only visible used complete native groups; offscreen fallback preserves every old metadata byte.',
            offscreen='Do not overwrite original offscreen metadata: rare original classifier fallback retains exact slow-source output for reserved/clipped stale slots.',
            unused='Skip second-pass classify for logical>=RgOamUsed; clear only originalbit4. No source visibility/physics change.',
            no_new_RAM='Uses approved aliases plus savedR0..7 and existing hardware-ignored ownOAM bits; no added cursor/ack fields.')
        p['passed']=True
    except Exception as e:p.update(error=repr(e),traceback=traceback.format_exc())
    files=[Path(__file__),Path(E.__file__),Path(H.__file__),P/'handoff.json',P/'joint/candidate.nes',P/'joint/candidate.dbg',
        R/'src/final_fantasy_render.s',P/'joint/ff-render.s',P/'joint/src/metasprite_engine.s']
    p['bindings']={str(f.resolve()):E.L.sha(f)for f in files}
    out=O/('controls.json'if p['passed']else'negative.json');out.write_text(json.dumps(p,indent=2)+'\n',newline='\n')
    print(json.dumps(dict(passed=p['passed'],path=str(out),error=p.get('error'))),flush=True);assert p['passed']

if __name__=='__main__':main()
