"""Fixed P1 transfer against the genuine correctly-C116-mapped decoder."""
from pathlib import Path
import copy,itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import ff_fx_palette_lifecycle_controls_v4 as L
from verify_native_relocation import NesMPU
from check_tmnt_render_oa import address
H,M,T,Q=L.H,L.M,L.T,L.Q
O=R/'build/ff-fx-palette-lifecycle-v8';H.O=O/'joint'

class LoggedMemory(H.C.OverlayMemory):
    def __getitem__(self,i):
        if isinstance(i,int)and 0x2000<=i<=0x2007:self.ppu_read_events.append(i)
        return super().__getitem__(i)

def logged(m):
    n=list.__new__(LoggedMemory);list.extend(n,list.__iter__(m))
    for k,v in m.__dict__.items():setattr(n,k,v if k=='bundle'else copy.deepcopy(v))
    n.ppu_read_events=[];n.ppu_log.clear();n.writes.clear();return n

def gateway(m,*,p=0x71,x=0x96,y=0x39):
    c=NesMPU(memory=m,pc=address(m.bundle,'SamusFreezeUpdateScreen'))
    c.a=0x55;c.x=x;c.y=y;c.p=p;c.sp=224;c.stPushWord(0x5aff)
    before=bytes(m[0x1e1:0x200]);r01=bytes(m[:2]);smc=bytes(m[0x15a:0x17b]);low=c.sp
    for i in range(10000):
        if c.pc==address(m.bundle,'PnHudPreUpdateScreen')and m.rawtags[2]==0xf4:break
        low=min(low,c.sp);assert m[c.pc]!=0,('gateway BRK',hex(c.pc),m.rawtags);c.step()
    else:raise AssertionError('Gateway did not reach original PN pre-update')
    assert(c.a,c.x,c.y,c.p,c.sp)==(0xf4,x,y,(p&~0x82)|0x80,222)
    assert bytes(m[:2])==r01 and bytes(m[0x15a:0x17b])==smc and bytes(m[0x1e1:0x200])==before
    return dict(CPU=c.processorCycles,minimum_SP=low,registers=[c.a,c.x,c.y,c.p,c.sp])

def packet(m,colors):
    at=address(m.bundle,'SmFreezePalettePacket')
    for i,v in enumerate([0x3f,0x15,3,*colors,0]):m[at+i]=v

def native_oracle(m):
    # Explicit source-call fixture: actual resident decoder requires C116.
    m.raw_page(2,0xf4);H.put(m,CurrentBankC=0xf4)
    at=address(m.bundle,'SmFreezePalettePacket');m[0]=at&255;m[1]=at>>8
    c=NesMPU(memory=m,pc=address(m.bundle,'UpdateScreen'));c.sp=224;c.stPushWord(0x5aff)
    c,low=H.finish(m,c);return c.processorCycles

def valid(b):
    base=M.setup(b);rows=[]
    vectors=[[0x10,0x30,0x27],[0x1a,0x30,0x27],[0x1c,0x36,0x17],
        [0x16,0x26,0x30],[0x12,0x21,0x30],[0x0c,0x1c,0x2c]]
    for ctrl,toggle,colors,p in itertools.product([0,0xa0,0xa4,0xff],[0,1],vectors,[0x30,0x71]):
        a=logged(base);z=logged(base)
        for m in[a,z]:
            H.put(m,SmFreezePalettePending=192,Mirror_PPUCTRL=ctrl,SelectedCharacter=0)
            m.ppuctrl=ctrl;m.toggle=toggle;packet(m,colors);m.writes.clear()
        old_cpu=native_oracle(a);result=gateway(z,p=p)
        old_events=[(at,v)for at,v in a.writes if 0x2000<=at<=0x2007]
        new_events=[(at,v)for at,v in z.writes if 0x2000<=at<=0x2007]
        assert old_events==new_events,('PPU write sequence',old_events,new_events)
        assert a.ppu_read_events==z.ppu_read_events,('PPU read sequence',a.ppu_read_events,z.ppu_read_events)
        assert(a.ppuctrl,a.toggle,a.ppu_addr,bytes(a.vram),H.get(a,'Mirror_PPUCTRL'))==(z.ppuctrl,z.toggle,z.ppu_addr,bytes(z.vram),H.get(z,'Mirror_PPUCTRL'))
        assert H.get(z,'SmFreezePalettePending')==0
        rows.append(dict(CTRL=ctrl,latch=toggle,colors=colors,flags=p,oracle_CPU=old_cpu,**result))
    return dict(cases=len(rows),rows=rows,PPU_reads_writes_latch_scroll_CTRL_mirror_exact=True,
        original_PnPre_AXYP_stack_NmiR01_SMC33_preserved=True)

def flags_pending(b):
    base=M.setup(b);rows=[]
    cases=[(v,0x71)for v in range(256)]+[(v,48|p)for p in range(256)if not p&48 for v in[0,128,192]]
    for pending,p in cases:
        m=logged(base);packet(m,[0x16,0x26,0x30]);H.put(m,SmFreezePalettePending=pending)
        r=gateway(m,p=p)
        assert H.get(m,'SmFreezePalettePending')==(0 if pending==192 else pending)
        assert len(m.ppu_read_events)==(2 if pending==192 else 0)
        assert bool(m.ppu_log)==(pending==192)
        rows.append(dict(pending=pending,flags=p,**r))
    return dict(cases=len(rows),rows=rows,only_exact_C0_consumed=True,native80_and_all_other_pending_unchanged_before_original_chain=True)

def malformed(b):
    base=M.setup(b);rows=[]
    for field,expected in[(0,63),(1,21),(2,3),(6,0)]:
        for value in range(256):
            if value==expected:continue
            m=logged(base);packet(m,[0x16,0x26,0x30]);H.put(m,SmFreezePalettePending=192)
            m[address(b,'SmFreezePalettePacket')+field]=value
            old=(bytes(m.vram),m.ppuctrl,m.toggle,m.ppu_addr,H.get(m,'Mirror_PPUCTRL'))
            r=gateway(m)
            assert H.get(m,'SmFreezePalettePending')==0
            assert not m.ppu_read_events and not m.ppu_log
            assert old==(bytes(m.vram),m.ppuctrl,m.toggle,m.ppu_addr,H.get(m,'Mirror_PPUCTRL'))
            rows.append(dict(field=field,value=value,**r))
    return dict(cases=len(rows),rows=rows,invalid_C0_cleared_without_PPU_side_effects=True,
        limit='Malformed producer state is rejected; no claim that rejected data can reconstruct an unknown old hardware palette.')

def main():
    out=O/'preflush-oracle-v2.json';assert not out.exists()
    proof=dict(passed=False,native=False,admitted=False,scheduler=False,checks={})
    try:
        b=H.C.qualified(H.O/'candidate.nes');proof['checks']['valid_oracle']=valid(b);proof['checks']['flags_and_pending']=flags_pending(b);proof['checks']['malformed']=malformed(b);proof['passed']=True
    except Exception as e:proof.update(error=repr(e),traceback=traceback.format_exc())
    proof['bindings']={str(f.resolve()):L.sha(f)for f in[Path(__file__),Path(L.__file__),Path(M.__file__),Path(H.__file__),O/'source-closure.json',H.O/'candidate.nes',H.O/'candidate.dbg']}
    out=out if proof['passed']else O/'preflush-oracle-negative-v2.json'
    out.write_text(json.dumps(proof,indent=2)+'\n',newline='\n');print(json.dumps(dict(passed=proof['passed'],error=proof.get('error'),path=str(out))),flush=True)
    assert proof['passed']

if __name__=='__main__':main()
