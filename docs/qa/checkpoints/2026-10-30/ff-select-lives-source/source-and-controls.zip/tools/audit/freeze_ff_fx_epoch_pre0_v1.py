"""Freeze emitted PRE0 source/consumer/vector evidence with timing hold."""
from pathlib import Path
import json,sys
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import prepare_ff_joint_source_v1 as B
O=R/'build/ff-fx-epoch-pre0-v1'


def save(p,d):
    p.write_text(json.dumps(d,indent=2)+'\n',encoding='utf-8',newline='\n')


def main():
    out=O/'handoff-source-performance-hold-v1.json';assert not out.exists()
    receipts=[O/n for n in['source-closure.json','epoch-controls-v5.json',
        'heartbeat-controls-v8.json','consumer-controls-v1.json','vector-controls-v2.json']]
    files={Path(__file__)}
    for p in receipts:
        d=json.loads(p.read_text());assert d['passed'];files.add(p)
        for f,h in d['bindings'].items():assert B.sha(f)==h,f;files.add(Path(f))
    negatives=sorted(O.glob('*negative*.json'));negative_summary=[]
    for p in negatives:
        d=json.loads(p.read_text());assert not d['passed'];files.add(p)
        for f,h in d.get('bindings',{}).items():assert B.sha(f)==h,f;files.add(Path(f))
        negative_summary.append(dict(path=str(p.relative_to(R)),sha256=B.sha(p),error=d.get('error')))
    docs=R/'docs/qa/checkpoints/2026-10-30'
    correction=docs/'ff-epoch-coverage-correction/correction.json'
    supplement=docs/'ff-epoch-coverage-revalidation/supplement.json'
    files|={correction,supplement}
    for p in[correction,supplement]:
        d=json.loads(p.read_text())
        for f,h in d['bindings'].items():assert B.sha(f)==h,f;files.add(Path(f))
    prior=O/'epoch-controls-v4.json';assert json.loads(prior.read_text())['passed'];files.add(prior)
    save(O/'prior-unfrozen-run-scope.json',dict(
        status='EXPLICIT_ADDITIVE_SCOPE_RESTRICTION',path=str(prior.relative_to(R)),sha256=B.sha(prior),
        reason='This earlier unfrozen3072 PRE0 run used the same requested-pose fixture gap. It is retained as exact finite observed idle-body/spell/world evidence, not an actual sword-family test.',
        superseded_by=dict(path=str((O/'epoch-controls-v5.json').relative_to(R)),sha256=B.sha(O/'epoch-controls-v5.json')),
        no_receipt_or_archive_rewritten=True))
    files.add(O/'prior-unfrozen-run-scope.json')
    rows=json.loads((O/'epoch-controls-v5.json').read_text())['checks']['actual_DrawAll_pairs']['rows']
    ticks=json.loads((O/'heartbeat-controls-v8.json').read_text())['checks']['body_tick_heartbeat']['rows']
    vectors=json.loads((O/'vector-controls-v2.json').read_text())['checks']['actual_Main_vectors']
    perf=dict(status='HOLD_NO_NATIVE_DEADLINE_QUALIFICATION',
        extra_DrawAll_CPU=[min(r['CPU_delta']for r in rows),max(r['CPU_delta']for r in rows)],
        maximum_tested_DrawAll_CPU=max(r['new_CPU']for r in rows),
        extra_body_heartbeat_CPU=[min(r['new_CPU']-r['old_CPU']for r in ticks),max(r['new_CPU']-r['old_CPU']for r in ticks)],
        minimum_observed_DrawAll_SP=min(r['minimum_SP']for r in rows),
        reason='Filter overhead remains material even after transient tags and stable-packet heartbeat. These CPU results are not native cadence or completion evidence.')
    (O/'README-source-performance-hold.md').write_text('''Private FF exact-color epoch protocol, emitted source/CPU pass, performance HOLD.

ROM3754fa53 / RAM3 image14f1ac63 / full cookie version9. Native family0 writes
a complete C0 packet before the native queue; FX1..5 write80 after it. Thus a
later real Axe/Bowser native publisher wins on native0. Heartbeat reissues only
a complete validated stable nonnative packet, clearing Pending first and
publishing80 last. It leaves native0/C0/cursor/OAM alone. Original body/P0 ACK,
all occupied source code/art/CHR/public PCs and selected RAM ownership remain.

The strict3072 renderer cases derive actual source action/age, assert real
graphics pose and projectile entry, and actually admit all six families. They
cover body poses1/6; a separate20-action witness covers Fighter/Thief6..10.
Exact completed OAM/group filtering, admitted source patterns/palettes,
body0/P0, nativeP2/P3/backdrop/CHR, AXYP/SP/R0..7/native C outputs pass.

768 body/heartbeat flag+queue pairs and48 actual Main pause/skip/ordinary cases
pass.16 late-native,1020 malformed packet,128 menu,48 scene,16 fullqueue/
abandon/lag and12 real8192B copy/verify loader cases pass.64 foreign DrawAll
pairs preserve original state, output and mapper writes;32 corrupt-cookie
cases execute no unverified RAM3.548 actual lag-NMI/IRQ cuts at274 worker
instruction seams preserve AXYP/SP/live page1/all33SMC/raw maps/borrowed pairs
and all RAM0..3 payloads.8 actual normal NMIs after completed Main pass.

The older480/model and3072 Draw coverage gap is explicitly corrected beside
the immutable receipts. The additional unfrozen PRE0v4 run is also restricted
to its actually observed finite idle-body/spell/world states. Real producer
tests supersede those requested-pose labels; nothing is silently relabeled.
Heartbeat/observer setup negatives are retained with their original bindings.

Extra DrawAll cost4548..15465CPU reaches50419CPU in the largest tested callback.
Heartbeat costs+558..603CPU. This is a performance HOLD, not native-tested,
selectable-ready, admitted, installed or campaign-complete. No shared/frozen
source, installed ROM, native process or Git index changed.
''',encoding='utf-8',newline='\n')
    files.add(O/'README-source-performance-hold.md')
    d=dict(passed=True,status='SOURCE_RENDER_PROTOCOL_LIFECYCLE_ISR_PASS_PERFORMANCE_HOLD',
        native=False,admitted=False,installed=False,source_scheduler_installed_privately=True,
        candidate_sha256=B.sha(O/'joint/candidate.nes'),RAM3_sha256=B.sha(O/'joint/ram3.bin'),
        source_closure=dict(path=str(receipts[0].relative_to(R)),sha256=B.sha(receipts[0])),
        complete_receipts={str(p.relative_to(R)):B.sha(p)for p in receipts},
        actual_worker_vector_cases=vectors['actual_vector_cases'],
        actual_worker_instruction_seams=vectors['instruction_seams'],performance=perf,
        coverage_correction=dict(path=str(correction.relative_to(R)),sha256=B.sha(correction)),
        real_producer_revalidation=dict(path=str(supplement.relative_to(R)),sha256=B.sha(supplement)),
        retained_negatives=negative_summary,
        retained_prior_scope=str((O/'prior-unfrozen-run-scope.json').relative_to(R)),
        bindings={str(f.resolve()):B.sha(f)for f in sorted(files)})
    save(out,d)
    print(json.dumps(dict(path=str(out),sha256=B.sha(out),bindings=len(files),performance=perf)),flush=True)


if __name__=='__main__':main()
