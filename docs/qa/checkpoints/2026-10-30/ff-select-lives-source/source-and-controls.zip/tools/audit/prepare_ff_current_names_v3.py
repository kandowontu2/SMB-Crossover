"""Actual short JCC first gate is23B; preserve all following public PCs."""
from pathlib import Path
P=Path(__file__).with_name('prepare_ff_current_names_v1.py');s=P.read_text()
s=s.replace("O=R/'build/ff-current-names-v1'","O=R/'build/ff-current-names-v3'")
s=s.replace(' php\n phx\n phy\n lda FfVariant',' php\n txa\n pha\n tya\n pha\n lda FfVariant')
s=s.replace(' ply\n plx\n plp\n lda #0',' pla\n tay\n pla\n tax\n plp\n lda #0')
s=s.replace('.res 26-(*-FwMenuName)','.res 23-(*-FwMenuName)')
s=s.replace("location(b,'FwGlobalInit')+26","location(b,'FwGlobalInit')+23")
old="cmd=[v.replace(str(P/'joint'),str(J))for v in cmd];recipes.append((n+'-build',cmd))"
new="cmd=[v.replace(str(P/'joint'),str(J))for v in cmd];cmd[1:1]=['-I',str(R)];recipes.append((n+'-build',cmd))"
assert old in s;s=s.replace(old,new)
exec(compile(s,str(P),'exec'),dict(__name__='__main__',__file__=str(Path(__file__).resolve())))
