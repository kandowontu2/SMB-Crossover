"""Actual four-class cold sequences,80menu labels and native HUD consumers."""
from pathlib import Path
import itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import ff_current_ready_cold_controls_v2 as C
import ff_current_ready_regressions_v2 as G
from check_tmnt_render_oa import address,location
H=C.H;O=R/'build/ff-current-names-v3';H.O=O/'joint'
def enc(s):return[36 if c==' 'else ord(c)-ord('A')+10 for c in s]
def main():
 out=O/'controls-v1.json';assert not out.exists();p=dict(passed=False,native=False,admitted=False,installed=False,checks={})
 try:
  b=H.C.qualified(O/'joint/candidate.nes');old=H.C.qualified(R/'build/ff-current-ready-v2/joint/candidate.nes')
  menus=G.profiles(b);actual=[r for r in menus['rows']if r['slot']==21]
  full=['   FF FIGHTER   ','  FF WHITE MAGE ','  FF BLACK MAGE ','    FF THIEF    ']
  assert len(actual)==4
  for v,row in enumerate(actual):assert row['name']==enc(full[v]),('actual PPU menu name',v,row['name'],enc(full[v]))
  p['checks']['actual80profile_names']=menus;print('80menus PASS',flush=True)
  rows=[]
  for v in range(4):
   m=C.fresh(b,v);C.invoke(m,'MenuResolveCharacter');H.put(m,VRAM_Buffer1_Offset=0)
   z=C.invoke(m,'WriteGameText',a=0,x=83,y=91,p=0x71)
   want=enc(['FIGHTER','WHITE M','BLACK M','THIEF  '][v]);at=address(b,'VRAM_Buffer1')
   assert list(m[at+11:at+18])==want,('actual native HUD patch',v,list(m[at+11:at+18]),want)
   flush=C.A.consume(m);rows.append(dict(variant=v,whole_WriteGameText=z,Hud=want,normal_NMI=flush))
  p['checks']['actual_native_WriteGameText_all4']=dict(rows=rows)
  rows=[]
  flags=[f for f in range(256)if f&0x30==0x30]
  for v,f in itertools.product(range(4),flags):
   m=C.fresh(b,v);C.invoke(m,'MenuResolveCharacter');at=address(b,'VRAM_Buffer1');m[at:at+84]=bytes([173]*84)
   z=C.invoke(m,'NrStatusName',a=0,x=83,y=91,p=f)
   assert z['AXYP_SP'][0:3]==[0,83,91],('actual typed status AX/Y',v,f,z)
   assert list(m[at+11:at+18])==enc(['FIGHTER','WHITE M','BLACK M','THIEF  '][v])
   rows.append([v,f,z['CPU'],z['minimum_SP']])
  p['checks']['typed_status_256fullflags']=dict(rows=rows,original_XY_preserved=True)
  rows=[]
  for v,a in itertools.product(range(4),range(1,256)):
   pair=[]
   for bundle in[old,b]:
    m=C.fresh(bundle,v);C.invoke(m,'MenuResolveCharacter');at=address(bundle,'VRAM_Buffer1');m[at:at+84]=bytes([173]*84)
    z=C.invoke(m,'NrStatusName',a=a,x=83,y=91,p=0x71)
    pair.append((z['AXYP_SP'][:3],bytes(m[at:at+84]),m.rawtags[:]))
   assert pair[0]==pair[1],('nonzero status rejects',v,a,pair[0][0],pair[1][0]);rows.append([v,a])
  p['checks']['nonzero_status1020_pairs']=dict(cases=len(rows),AXY_queue_maps_exact=True)
  p['checks']['four_class_cold_sequence']=C.four_classes(b);print('4class cold/128Main PASS',flush=True)
  p['passed']=True
 except Exception as e:p.update(error=repr(e),traceback=traceback.format_exc())
 paths={Path(__file__),Path(C.__file__),Path(G.__file__),O/'source-proof.json',O/'joint/candidate.nes',O/'joint/candidate.dbg'}
 for module in list(sys.modules.values()):
  f=getattr(module,'__file__',None)
  if f and Path(f).resolve().is_relative_to(R/'tools'):paths.add(Path(f).resolve())
 p['bindings']={str(f.resolve()):C.L.sha(f)for f in paths if f.exists()};out.write_text(json.dumps(p,indent=2)+'\n',encoding='utf-8',newline='\n')
 print(json.dumps(dict(passed=p['passed'],error=p.get('error'),receipt=str(out))));assert p['passed']
if __name__=='__main__':main()
