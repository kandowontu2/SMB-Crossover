"""Freeze source/UI controls and prepare the stricter bounded native packet."""
from pathlib import Path
import difflib,json,shutil
import prepare_current_quick_ui_v13 as B
import arthur_body_fair_budget_v7 as Q
from check_tmnt_render_oa import load,address,location
R=B.R;O=B.O;N=B.N;P=B.P;F=O/'native-prepared'
def main():
 assert not F.exists()and not(O/'handoff.json').exists()
 for p in[O/'early-ui-source-controls.json',O/'early-ui-real-ISR-controls.json',O/'foreign-active-Main-controls.json',O/'actual-Main-CPU-attribution.json',O/'area-geometry-v2/actual-area-geometry.json']:
  B.verify(p);assert json.loads(p.read_text())['passed'],p
 B.verify(P.parent/'handoff.json');B.verify(P.parent/'native-qualified-physical-v3/handoff.json')
 F.mkdir();old=P.parent/'native-physical-guard-v3b/native-physical-v3.lua'
 s=old.read_text().replace(P.as_posix()+'/',N.as_posix()+'/').replace(B.sha(P/'candidate.nes'),B.sha(N/'candidate.nes'))
 s=s.replace(str(P/'native-profile-v6.lua').replace('\\','/'),str(F/'native-profile-ui-v13.lua').replace('\\','/'))
 # Observe hardware text after a completed NMI, never normalize screenshots.
 anchor="   assert(values[1]==0x22 and values[2]==0x22,'Actual steady1-1 blue universal backdrop after fresh completedNMI')"
 assert s.count(anchor)==1
 b=load(N/'candidate.nes');at=location(b,'InvName2');buster=list(b['raw'][at:at+7]);assert len(buster)==7
 addition='''
   if age>=20 then
    local hp={};for p=0x2004,0x2008 do hp[#hp+1]=emu.read(p,emu.memType.nesPpuDebug)end
    assert(hp[1]==0x11 and hp[2]==0x19 and hp[3]==0x24 and hp[4]==4 and hp[5]==0,'Actual source HP40 HUD consumed through normal NMI')
    local old='''+'{'+','.join(str(x)for x in buster)+'}'+''';local same=true
    for i,v in ipairs(old)do if emu.read(0x2022+i,emu.memType.nesPpuDebug)~=v then same=false end end
    assert(not same,'Legacy BUSTER HUD must not survive selected Quick UI ownership')
   end'''
 s=s.replace(anchor,anchor+addition)
 assert 'emu.write('not in s and s.count('wall>=1000')==1 and s.count('shots<=6')==1
 (F/'native-ui-v13.lua').write_text(s,newline='\n')
 profile=(P/'native-profile-v6.lua').read_text()
 anchor="  calls[#calls]=nil"
 assert profile.count(anchor)==1
 profile=profile.replace(anchor,"  if q.name=='GameLoop'then assert(q.quickUiCalls==1,'Exactly one genuine Quick UI consumer per sampled actual Main')end\n"+anchor)
 anchor="  serial=serial+1"
 assert profile.count(anchor)==1
 profile=profile.replace(anchor,"  if h.name=='QhUi'then for i=#calls,1,-1 do if calls[i].name=='GameLoop'and calls[i].depth==#isrs then calls[i].quickUiCalls=(calls[i].quickUiCalls or 0)+1;break end end end\n"+anchor)
 profile=profile.replace("and n('QhDraw')>50,","and n('QhDraw')>50 and n('QhUi')>100,")
 (F/'native-profile-ui-v13.lua').write_text(profile,newline='\n')
 (F/'fixture.diff').write_text(''.join(difflib.unified_diff(old.read_text().splitlines(True),s.splitlines(True),fromfile='frozen-cold-v3/observer.lua',tofile='ui-v13/observer.lua')),newline='\n')
 # Validate all inherited authenticated PCs against actual new source bytes.
 prior=load(P/'candidate.nes');points=['QwBoot','QwRetire','QwMenuRetire','QwLoaderCore','NrFreshGameInit','QhUi','QhMovement','QhDraw']
 proof=[]
 for name in points:
  assert address(b,name)==address(prior,name)
  if name.startswith('Qh'):
   pc=address(b,name)-0xa000;assert(N/'code.bin').read_bytes()[pc:pc+8]==(P/'code.bin').read_bytes()[pc:pc+8]
  else:
   a=location(b,name);z=location(prior,name);assert b['raw'][a:a+8]==prior['raw'][z:z+8]
  proof.append(dict(name=name,address=address(b,name),entry8bytes_exact=True))
 (F/'source-observer-proof.json').write_text(json.dumps(dict(passed=True,candidate=B.sha(N/'candidate.nes'),actual_entry_preimages=proof,payloads_and_full16cookie_exact=True,physical_fresh_offset=1018455,scope='Only physical86 UI helper changed; all physical ROM/Fresh/cookie/source observer sites remain actual-PC/preimage exact.'),indent=2)+'\n')
 actual=R/'tools/audit/capture_budget.py';budget=F/'capture-budget.py'
 budget.write_text(actual.read_text().replace('RUN_BYTES = 2_000_000_000','RUN_BYTES = 536_870_912').replace('receipt = preflight(output)','receipt = preflight(output, reserved_bytes=RUN_BYTES, reserved_files=RUN_FILES)'),newline='\n')
 q=Q.load(budget);storage=q.preflight(O/'native/cold-menu-ui-v13',reserved_bytes=536870912,reserved_files=64)
 (F/'storage-preflight.json').write_text(json.dumps(storage,indent=2)+'\n')
 tools=[p for p in(R/'tools/audit').glob('*quick*ui*v13*.py')]+[R/'tools/audit/freeze_current_quick_native_physical_v3.py']
 files=[p for p in O.rglob('*')if p.is_file()]+tools
 handoff=dict(status='FROZEN_SOURCE_UI_READY_NATIVE_PENDING_PERFORMANCE_HOLD',candidate=B.sha(N/'candidate.nes'),parent=B.sha(P/'candidate.nes'),native=False,installed=False,
  helper=dict(physical_bank=86,start=0xa79c,bytes=24,granted_bytes=40),
  checks=dict(foreign_UI_pairs=16384,Quick_worker_pairs=1024,Bass_Roll_alt_pairs=1024,actual_Main_QuickUi_once=120,real_ISR_cuts=648,foreign_Main=282,active_FF_Main=24,real_NMI_Arthur_Main=6,foreign_Main_CPU_delta=[6,19]),
  limits=['No native UI/PPU result yet. Severe lag and CXaudio/full1-1/powerups remain open; no admission/install.',
   'Menu Quick name at2328 and hint2346 are adjacent8px rows with no PPU field overlap; crowding remains a presentation limitation.',
   'Per-instruction Main CPU report is a source fixture with all120 draws, not a native cadence or native-frame comparison.'],
  bindings={str(p.resolve()):B.sha(p)for p in files})
 (O/'handoff.json').write_text(json.dumps(handoff,indent=2)+'\n')
 oldprepared=json.loads((P.parent/'native-prepared.json').read_text())
 prep=dict(status='PREPARED_ONLY_REQUIRES_EXPLICIT_ROOT_ONE_RUN_GRANT',candidate=handoff['candidate'],source_handoff=B.sha(O/'handoff.json'),command='python tools/audit/run_current_quick_ui_native_v13.py --launch',
  config=oldprepared['config'],options=oldprepared['options'],scope='Identical realcold Bass→Roll→Quick/controller/loader/PPU/body/fan/scroll/guard smoke, plus sampledMain→QhUi exactlyonce and source HP40/no BUSTER PPU assertions after fresh NMI.',
  bindings={str(p.resolve()):B.sha(p)for p in [O/'handoff.json',Path(__file__),R/'tools/audit/run_current_quick_ui_native_v13.py',R/'tools/run_mesen.py',Path(Q.__file__),actual]+list(F.iterdir())if p.is_file()})
 (F/'prepared.json').write_text(json.dumps(prep,indent=2)+'\n')
 print(json.dumps(dict(candidate=handoff['candidate'],handoff=B.sha(O/'handoff.json'),source_bindings=len(handoff['bindings']),prepared=B.sha(F/'prepared.json'),command=prep['command'],config=prep['config'])))
if __name__=='__main__':main()
