"""Fill genuine FF menu/HUD name routes by retiring five unused own gates."""
from pathlib import Path
import difflib,hashlib,json,re,subprocess,sys
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
from private_build_outputs_v1 import validate
from link_pit_rygar_sophia_audit_cpu import scoped_load
from check_tmnt_render_oa import address,location
from prepare_cv3_dmc_mirror import prepare
P=R/'build/ff-current-ready-v2';O=R/'build/ff-current-names-v1';J=O/'joint'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf-8',newline='\n')
def save(p,obj):write(p,json.dumps(obj,indent=2)+'\n')
def main():
 assert not O.exists();J.mkdir(parents=True)
 b=scoped_load(P/'joint/candidate.nes')
 assert sha(P/'joint/candidate.nes')=='280ab6469226d0979fe7130766d685b3613fc5e2bb1087c03b20686d1bb0f42b'
 retired=['FwGlobalInit','FwMovement','FwPickup','FwStompPolicy','FwCollisionBounds']
 commands=json.loads((P/'joint/final-link.json').read_text())['command'];imports={}
 od=R/'tools/Windows/cc65/bin/od65.exe'
 for v in commands:
  if v.endswith('.o'):
   out=subprocess.check_output([str(od),'--dump-imports',v],text=True)
   hit=[n for n in retired if '"'+n+'"'in out];assert not hit,(v,hit);imports[v]=sha(v)
 for f in(P/'joint').rglob('*'):
  if f.is_file()and f.suffix in['.s','.inc','.cfg','.chr','.bin']:
   q=J/f.relative_to(P/'joint');q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(f.read_bytes())
 patch=[];p=J/'loader.s';old=p.read_text();s='.include "inc/charmap.inc"\n.import FmQueueName,FfVariant,VRAM_Buffer1\n'+old
 replacements={
 'FW_GATE FwGlobalInit,FfGlobalInit':'''\
; Explicit own ABI retirement: old FwGlobalInit had no emitted consumer.
.export FwMenuName
FwMenuName:
 sta SafecallA_SMC+1
 lda #<FmQueueName
 sta FarcallJmpTarget_SMC+1
 lda #>FmQueueName
 sta FarcallJmpTarget_SMC+2
 lda #.lobyte(.bank(FmQueueName)|$80)
 jmp FarCallCommon
 .res 26-(*-FwMenuName),$ea''',
 'FW_GATE FwMovement,FfMovement\nFW_GATE FwPickup,FfPickup':'''\
; Retired unused source aliases; live movement/collection use typed host gates.
FwHudNames:
 .byte "FIGHTER ","WHITE M ","BLACK M ","THIEF   "
 .res 52-(*-FwHudNames),$ea''',
 'FW_GATE FwStompPolicy,FfStompPolicy\nFW_GATE FwCollisionBounds,FfCollisionBounds':'''\
; Actual status caller supplies A0 after native MARIO text was copied.
.export FwStatusName
FwStatusName:
 cmp #0
 bne FwStatusDone
 php
 phx
 phy
 lda FfVariant
 and #3
 asl
 asl
 asl
 tax
 ldy #0
FwStatusCopy:
 lda FwHudNames,x
 sta VRAM_Buffer1+11,y
 inx
 iny
 cpy #7
 bne FwStatusCopy
 ply
 plx
 plp
 lda #0
FwStatusDone:
 rts
 .res 52-(*-FwStatusName),$ea'''}
 for a,z in replacements.items():assert s.count(a)==1,a;s=s.replace(a,z)
 for n in retired:assert not re.search(r'\b'+n+r'\b',s.replace('; Explicit own ABI retirement: old FwGlobalInit had no emitted consumer.',''))
 write(p,s);patch+=list(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='parent/loader.s',tofile='new/loader.s'))
 p=J/'veneers.s';old=p.read_text();s=old.replace('.import FwPickup\n','')
 s='.import FwMenuName,FwStatusName\n'+s
 for service,fn in[(18,'FwMenuName'),(30,'FwStatusName')]:
  pat=rf'(; {service} [^\n]*\n) jmp FwServiceUnavailable';s,n=re.subn(pat,rf'\g<1> jmp {fn}',s);assert n==1
 write(p,s);patch+=list(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='parent/veneers.s',tofile='new/veneers.s'))
 p=J/'src/full_roster_menu_art.inc';old=p.read_text();s=old
 for name in['  *FF FIGHTER   ',' *FF WHITE MAGE ',' *FF BLACK MAGE ','   *FF THIEF    ']:assert s.count(name)==1;s=s.replace(name,name.replace('*',' '))
 write(p,s);patch+=list(difflib.unified_diff(old.splitlines(True),s.splitlines(True),fromfile='parent/full_roster_menu_art.inc',tofile='new/full_roster_menu_art.inc'))
 cfg=(P/'joint/private.cfg').read_text().replace(str(P/'joint'),str(J)).replace((P/'joint').as_posix(),J.as_posix());write(J/'private.cfg',cfg)
 recipes=[]
 for n in['main','loader','veneers']:
  cmd=json.loads((P/'joint'/(n+'-build.json')).read_text())['command'];cmd=[v.replace(str(P/'joint'),str(J))for v in cmd];recipes.append((n+'-build',cmd))
 link=[v.replace(str(P/'joint/private.cfg'),str(J/'private.cfg'))for v in commands]
 for i,v in enumerate(link):
  for name in['main.o','loader.o','veneers.o','candidate.nes','candidate.lbl','candidate.map']:
   if v==str(P/'joint'/name):link[i]=str(J/name)
  if v.startswith('--dbgfile,'):link[i]='--dbgfile,'+str(J/'candidate.dbg')
 for name,cmd in recipes+[('final-link',link)]:save(J/(name+'-guard.json'),validate(cmd,O,cwd=R))
 for name,cmd in recipes+[('final-link',link)]:
  p=subprocess.run(cmd,cwd=R,capture_output=True,text=True);save(J/(name+'.json'),dict(command=cmd,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr));assert p.returncode==0,p.stderr
 prepare(R,J/'candidate.nes');z=scoped_load(J/'candidate.nes')
 for n in retired:assert n not in z['syms']
 changed=[];allowed=[(location(b,'FwGlobalInit'),location(b,'FwGlobalInit')+26,'own retired menu gate'),
  (location(b,'FwMovement'),location(b,'FwMovement')+52,'own retired HUD data'),
  (location(b,'FwStompPolicy'),location(b,'FwStompPolicy')+52,'own retired HUD routine'),
  (location(b,'FwServiceVeneers')+54,location(b,'FwServiceVeneers')+57,'own row18'),
  (location(b,'FwServiceVeneers')+90,location(b,'FwServiceVeneers')+93,'own row30'),
  (location(b,'FmNames')+5*16,location(b,'FmNames')+9*16,'4 pending stars')]
 a=(P/'joint/candidate.nes').read_bytes();v=(J/'candidate.nes').read_bytes()
 for i,(x,y)in enumerate(zip(a,v)):
  if x!=y:assert any(lo<=i<hi for lo,hi,n in allowed),('unowned byte',hex(i));changed.append(i)
 assert a[:16]==v[:16] and a[1048592:]==v[1048592:]
 shifts={n:(address(b,n),address(z,n))for n in b['syms']if n not in retired and n in z['syms']and address(b,n)!=address(z,n)};assert not shifts,shifts
 assert(J/'ram3.bin').read_bytes()==(P/'joint/ram3.bin').read_bytes()
 write(O/'source.patch',''.join(patch));save(O/'source-proof.json',dict(passed=True,candidate=sha(J/'candidate.nes'),parent=sha(P/'joint/candidate.nes'),
  retired_own_ABI=retired,all_final_object_imports_checked=imports,retired_zero_emitted_consumers=True,
  native_header_CHR_FF_payload_cookie_exact=True,all_other_live_public_PCs_exact=True,changes=len(changed),allowed_ranges=allowed,
  no_new_RAM_PRG_CHR=True,native_executed=False,admitted=False,installed=False))
 print(sha(J/'candidate.nes'))
if __name__=='__main__':main()
