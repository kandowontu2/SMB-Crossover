"""Execute genuine private source epoch worker against original completed OAM.

Renderer setups and direct source actions are explicit CPU fixtures. No native
frame/campaign/admission claim follows from these controls.
"""
from pathlib import Path
import collections,itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import ff_fx_epoch_oracle_v3 as O
from check_tmnt_render_oa import address,location
H,M,T,V=O.H,O.M,O.T,O.V;F,U,L=O.F,O.U,O.L
P=R/'build/ff-fx-world-marker-proposal-v2';N=R/'build/ff-fx-epoch-cart-v4';H.O=N/'joint'

def fresh(b,area):
    m=M.setup(b)
    H.put(m,AreaType=area,Mirror_PPUMASK=0,DisableScreenFlag=1,NmiDisable=255,ScreenRoutineTask=0)
    H.invoke(m,'InitScreen');H.invoke(m,'GetAreaPalette');L.Q.consume(m,0)
    H.put(m,Mirror_PPUMASK=30,DisableScreenFlag=0,NmiDisable=255)
    return m

def frame(seed,variant,pose,off,face,kind,entries,cursor):
    m=T.copy(seed);b=m.bundle
    H.put(m,FfVariant=variant,PlayerOutlinesOff=off,PlayerFacingDir=face,FfPose=pose,
        FrameCounter=0,GuestPowerupActive=0,StarInvincibleTimer=0,SmFreezeRenderState=0,NmiDisable=255,
        VRAM_Buffer1_Offset=0,VRAM_Buffer_AddrCtrl=0,SmFreezeTurn=cursor)
    m[address(b,'VRAM_Buffer1')]=0
    H.invoke(m,'FwEnsure');H.put(m,FfPose=pose,FfPower=0)
    for i in range(36):m[address(b,'FfProjectile')+i]=0
    for slot,entry in entries:U.set_projectile(m,slot,entry,face)
    if variant==1 and entries:m[address(b,'FfProjectile')]=4
    for i in range(24):m[address(b,'ObjectMetasprite')+i]=0
    for i in range(6):m[address(b,'Enemy_Flag')+i]=0
    if kind!='empty':
        meta={'mushroom':'POWERUP_MUSHROOM','koopa':'KOOPA_WALKING_1','flower':'POWERUP_FIREFLOWER'}[kind]
        slot=0 if kind=='koopa'else 5
        m[address(b,'ObjectMetasprite')+slot+1]=address(b,'METASPRITE_'+meta)
        for name,value in[('Enemy_Flag',1),('Enemy_ID',0 if kind=='koopa'else address(b,'PowerUpObject')),
            ('Enemy_State',0 if kind=='koopa'else 128),('Enemy_X_Position',192),('Enemy_PageLoc',0),
            ('Enemy_Y_Position',160),('Enemy_Y_HighPos',1),('Enemy_SprAttrib',0)]:m[address(b,name)+slot]=value
        H.put(m,PowerUpType=2 if kind=='flower'else 0)
    H.invoke(m,'FwHostGraphics');H.invoke(m,'FwForceColors')
    m.writes.clear();m.ram_writes.clear();c,low=F.invoke_drawall(m)
    return m,c,low

def expected(old,chosen):
    b=old.bundle;raw=list(old[512:768]);result=raw[:]
    start=H.get(old,'RgOamPlayerStart');ptr=H.get(old,'SmPosePtr')+256*old[address(b,'SmPosePtr')+1]
    end=start+old[ptr];rotation=H.get(old,'RgOamRotation');used=H.get(old,'RgOamUsed')
    present=set();body=[];groups=collections.defaultdict(list)
    for logical in range(0,256,4):
        at=(logical+rotation)&255;y,tile,attr,x=raw[at:at+4];pal=attr&3;family=None
        if logical<used:
            if logical<end:
                window=U.window(tile)
                if window in[5,6,7]:
                    typ=old[address(b,'FfProjectile')+(window-5)*12]
                    family={1:1,2:3,3:2,4:2}[typ]
                else:
                    assert window==0 and pal in[0,2,3]
                    if pal==0:body.append(at)
                    else:family=4 if pal==2 else 5
            elif attr&16:family=0
            elif y<240:assert pal!=1
        result[at+2]&=239
        if family is not None:
            groups[family].append(at)
            if y<240:present.add(family)
            if family!=chosen:result[at]=248
            elif family!=0:result[at+2]=(result[at+2]&252)|1
    return result,present,body,groups

def draw_pairs(old,new):
    rows=[];seeds=[[fresh(b,a)for a in range(4)]for b in[old,new]]
    audit=json.loads((R/'build/ff-fx-sword-role-audit-v1/controls.json').read_text())
    sword={v:next(r['pose']for r in audit['rows']if r['character']==n and r['sword_parts'])for v,n in[(0,'Fighter'),(3,'Thief')]}
    scenarios=[(0,1,[]),(0,sword[0],[]),(3,sword[3],[]),(1,1,[(0,149)]),
        (2,1,[(0,144)]),(2,1,[(0,144),(12,154)]),(2,1,[(0,144),(12,149)]),
        (2,1,[(0,144),(12,145),(24,154)])]
    for area,off,face,kind,(variant,pose,entries)in itertools.product(range(4),[0,1],[1,2],['empty','mushroom','koopa','flower'],scenarios):
        # Repeat all six starting cursors to execute real next-present search.
        a,c,lo=frame(seeds[0][area],variant,pose,off,face,kind,entries,0)
        for cursor in range(6):
            z,d,lz=frame(seeds[1][area],variant,pose,off,face,kind,entries,cursor)
            owner=H.get(z,'SmFreezeLastBlue');chosen=owner&7
            want,present,body,groups=expected(a,chosen)
            select=next((k for k in[(cursor+j)%6 for j in range(6)]if k in present),0)
            assert owner==128|select and chosen==select,(area,off,face,kind,variant,pose,cursor,owner,present)
            assert list(z[512:768])==want,('actual sourceOAM vs independent model',area,off,face,kind,variant,pose,cursor,
                [(i,w,z[512+i])for i,w in enumerate(want)if z[512+i]!=w][:8])
            assert H.get(z,'SmFreezeTurn')==(select+1)%6
            assert (c.a,c.x,c.y,c.p,c.sp)==(d.a,d.x,d.y,d.p,d.sp),('native returned AXYP/SP',c.p,d.p)
            assert a.rawtags==z.rawtags and H.get(a,'CurrentBankC')==H.get(z,'CurrentBankC')
            assert all(H.get(a,'R'+str(i))==H.get(z,'R'+str(i))for i in range(8))
            assert bytes(a[0x5c00:0x5c80])==bytes(z[0x5c00:0x5c80])
            assert bytes(a[0x5fc1:0x5fd0])==bytes(z[0x5fc1:0x5fd0])
            assert H.get(z,'SmFreezePalettePending')==128
            oldP2P3=bytes(a.vram[0x3f19:0x3f20]);oldBackdrop=a.vram[0x3f00]
            colors=O.family_vectors(old).get(chosen,list(a.vram[0x3f15:0x3f18]))
            L.Q.consume(a,0) # complete original body/native queue for P0 oracle.
            L.Q.consume(z,0)
            assert list(z.vram[0x3f15:0x3f18])==colors
            assert bytes(a.vram[0x3f10:0x3f14])==bytes(z.vram[0x3f10:0x3f14])
            assert bytes(a.vram[0x3f19:0x3f20])==bytes(z.vram[0x3f19:0x3f20])
            assert a.chr_latches==z.chr_latches and a.vram[0x3f00]==z.vram[0x3f00]
            H.exact(z)
            rows.append(dict(area=area,off=off,face=face,world=kind,variant=variant,pose=pose,entries=entries,
                cursor=cursor,present=sorted(present),chosen=chosen,native_CPU=c.processorCycles,new_CPU=d.processorCycles,
                CPU_delta=d.processorCycles-c.processorCycles,minimum_SP=lz,body0_parts=len(body),native_output_C=z.rawtags[2]))
    return dict(cases=len(rows),rows=rows)

def main():
    out=N/'epoch-controls-v1.json';assert not out.exists()
    p=dict(passed=False,native=False,admitted=False,source_scheduler_installed=True,checks={})
    try:
        old=H.C.qualified(P/'joint/candidate.nes');new=H.C.qualified(N/'joint/candidate.nes')
        p['checks']['actual_DrawAll_pairs']=draw_pairs(old,new)
        p['passed']=True
    except Exception as e:p.update(error=repr(e),traceback=traceback.format_exc())
    files=[Path(__file__),Path(O.__file__),Path(F.__file__),Path(M.__file__),Path(H.__file__),Path(V.__file__),
        P/'handoff.json',P/'joint/candidate.nes',P/'joint/candidate.dbg',N/'source-closure.json',N/'joint/candidate.nes',N/'joint/candidate.dbg']
    p['bindings']={str(f.resolve()):L.sha(f)for f in files}
    out=out if p['passed']else N/'epoch-negative-v1.json';out.write_text(json.dumps(p,indent=2)+'\n',newline='\n')
    print(json.dumps(dict(passed=p['passed'],path=str(out),error=p.get('error'))),flush=True);assert p['passed']

if __name__=='__main__':main()
