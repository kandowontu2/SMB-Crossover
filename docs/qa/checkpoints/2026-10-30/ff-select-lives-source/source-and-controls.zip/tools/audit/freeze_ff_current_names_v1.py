"""Freeze own FF name source + inherited gameplay proof without native claim."""
from pathlib import Path
import hashlib,json,sys
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import prepare_ff_joint_source_v1 as B
P=R/'build/ff-current-ready-v2';O=R/'build/ff-current-names-v3'
def save(p,x):p.write_text(json.dumps(x,indent=2)+'\n',encoding='utf-8',newline='\n')
def main():
 out=O/'handoff-source-v1.json';assert not out.exists()
 files=B.validate(P/'handoff-source-v1.json','530864be96949b9f590a8640d7aa3cc1c4dbb1eea43f56c1e89c8dfdc4ebbb01')
 for n in['source-proof.json','controls-v1.json']:
  p=O/n;d=json.loads(p.read_text());assert d['passed'];files.add(p)
  for f,h in d.get('bindings',{}).items():assert B.sha(f)==h,f;files.add(Path(f))
 files|={Path(__file__)}|{f for f in O.rglob('*')if f.is_file()}
 for n in['prepare_ff_current_names_v1.py','prepare_ff_current_names_v2.py','prepare_ff_current_names_v3.py','ff_current_names_controls_v1.py']:
  files.add(R/'tools/audit'/n)
 negatives=[]
 for d,n in [('ff-current-names-v1','loader-build.json'),('ff-current-names-v2','final-link.json')]:
  p=R/'build'/d/'joint'/n;v=json.loads(p.read_text());assert v['returncode']!=0;files.add(p)
  negatives.append(dict(path=str(p),sha256=B.sha(p),cause=v['stderr']))
 inventory=dict(source_parent='280ab646',current_candidate=B.sha(O/'joint/candidate.nes'),
  apply_entire_own_producers=['loader.s','veneers.s'],
  single_main_data_producer='src/full_roster_menu_art.inc: only four FF pending stars become spaces',
  explicit_retired_own_ABI=['FwGlobalInit','FwMovement','FwPickup','FwStompPolicy','FwCollisionBounds'],
  exact_spans=['62:AC47..<AC5E menu23B','62:AC8C..<ACC0 HUD data52B','62:AD42..<AD76 status52B'],
  live_service_changes={'18':'FwMenuName -> genuine FmQueueName','30':'FwStatusName native A0 overwrite7 chars, preserves X/Y'},
  actual_labels={'menu':['FF FIGHTER','FF WHITE MAGE','FF BLACK MAGE','FF THIEF'],
   'HUD':['FIGHTER','WHITE M','BLACK M','THIEF  ']},
  payload_cookie_all_live_PCs_header_CHR_unchanged=True,
  root_merge_obligations=['Preserve later ready54 08f1 RCR409+Chip1 source delta.','Preserve root upcoming Quick/Arthur coming-soon marker data repair.','Use current coherent common source; no independent dispatcher replacement.'])
 save(O/'source-merge-inventory.json',inventory);files.add(O/'source-merge-inventory.json')
 (O/'README-source.md').write_text('''FF four-class name/readiness source successor, native pending.

03692e45 is frozen280ab gameplay plus source-exact menu and HUD class names.
The actual80-profile PPU sweep shows58ready/22pending and all four full FF
names. Genuine WriteGameText reaches the seven-character HUD names.256typed
all-flags status cases preserve X/Y,1020nonzero pairs preserve A/X/Y/queue/maps.
All four classes repeat actual cold menu/Start/forcedblank8KB loader/full area
parser and entrance, then128 realMain updates with movement/jump/attack.

Five unused OWN ROM aliases are explicitly retired; every actual final-object
import was checked absent, and all live public PCs stay exact. The first gate
is23B due to a short JCC; later gates26B. Prior missing include/6502 macro and
3B link-overflow failures are retained separately. No frozen stage was edited.
FF RAM3/8192B carrier/full16B cookie9, all CHR/header and gameplay instructions
remain byte-exact280ab/3754. Earlier strict3072render/heartbeat/vector results
remain predecessor-scoped evidence; this name packet does not retag those runs.

No native/campaign/controller-earned-pickup/install claim. Lag is allowed by
the current user priority and remains disclosed. Root must retain later410B
ready54 RCR/Chip source fixes and its upcoming ready-marker data repair when
merging this source. New unused CLC rows are not fabricated abilities.
''',encoding='utf-8',newline='\n');files.add(O/'README-source.md')
 d=dict(passed=True,status='PRIVATE_FF4_NAMES_COLD_SOURCE_READY_NATIVE_PENDING',native=False,admitted=False,installed=False,
  candidate=B.sha(O/'joint/candidate.nes'),parent=B.sha(P/'joint/candidate.nes'),
  FF_RAM3_sha256=B.sha(O/'joint/ram3.bin'),FF_cookie=list((O/'joint/ff-cookie.bin').read_bytes()),
  source_ready_profiles=58,source_pending_profiles=22,all_FF_classes=[0,1,2,3],
  own_name_source_checks=dict(actual_menu_profiles=80,all4_menu_PPU_names=True,native_WriteGameText=4,
    typed_fullflags_status=256,nonzero_pairs=1020,cold_classes=4,actual_Main=128),
  predecessor_gameplay_handoff=dict(path=str(P/'handoff-source-v1.json'),sha256=B.sha(P/'handoff-source-v1.json')),
  source_merge_inventory=dict(path=str(O/'source-merge-inventory.json'),sha256=B.sha(O/'source-merge-inventory.json')),
  retired_own_ABI=inventory['explicit_retired_own_ABI'],retained_negatives=negatives,
  bindings={str(p.resolve()):B.sha(p)for p in sorted(files)})
 save(out,d);print(json.dumps(dict(path=str(out),sha256=B.sha(out),candidate=d['candidate'],bindings=len(files))))
if __name__=='__main__':main()
