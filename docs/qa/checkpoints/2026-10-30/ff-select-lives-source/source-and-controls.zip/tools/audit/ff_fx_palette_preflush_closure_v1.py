"""Lossless own-code factoring and actual pre-DMA PPU instruction budget."""
from pathlib import Path
import copy,itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import ff_fx_palette_lifecycle_controls_v5 as L
from check_tmnt_render_oa import address
H,M,T,Q,V=L.H,L.M,L.T,L.Q,L.V
O=L.O

def app(m):return bytes(m[i]for i in range(0x8000)if not 0x100<=i<0x200 and not 0x5114<=i<=0x5117)
def ordered(m):return[(a,v)for a,v in m.writes if not 0x100<=a<0x200 and not 0x5114<=a<=0x5117]

def compact_protocol(b):
    old=H.C.qualified(R/'build/ff-fx-palette-lifecycle-v6/joint/candidate.nes')
    bases=[M.setup(x)for x in[old,b]];rows=[]
    cases=[(control,area,0x71)for control,area in itertools.product(range(256),range(4))]
    cases +=[(control,1,48|p)for control,p in itertools.product([1,2,3,4,8,255],range(256))if not p&48]
    for control,area,p in cases:
        results=[]
        for base in bases:
            m=T.copy(base);L.put_owner(m)
            H.put(m,SelectedCharacter=22,CrossoverMenuIndex=0,FmAlts=0,RdVariant=0,MarioVariant=0,
                SmFreezePaletteControl=control,AreaType=area)
            m.writes.clear();c,lo=H.invoke(m,'MenuResolveCharacter',p=p);results.append((m,c,lo))
        (a,c,_),(z,d,lo)=results
        assert(c.a,c.x,c.y,c.p,c.sp)==(d.a,d.x,d.y,d.p,d.sp)
        assert app(a)==app(z)and ordered(a)==ordered(z),('factoring changed protocol',control,area,p)
        assert a.rawtags==z.rawtags and a.ram==z.ram
        rows.append(dict(control=control,area=area,flags=p,old_CPU=c.processorCycles,new_CPU=d.processorCycles,minimum_SP=lo))
    return dict(cases=len(rows),rows=rows,source_APXY_SP_fields_ordered_writes_raw_maps_RAM_exact=True,
        factored_native8_alias_exact=True)

class TimedMemory(H.C.OverlayMemory):
    def __setitem__(self,i,v):
        if isinstance(i,int)and(i==0x4014 or 0x2000<=i<=0x2007)and hasattr(self,'clock'):
            self.hardware_events.append(dict(CPU=self.clock.processorCycles,address=i,value=v,PPU_address=self.ppu_addr))
        return super().__setitem__(i,v)

def timed(m):
    n=list.__new__(TimedMemory);list.extend(n,list.__iter__(m))
    for k,v in m.__dict__.items():setattr(n,k,v if k=='bundle'else copy.deepcopy(v))
    n.hardware_events=[];return n

def source_budget(b):
    base=M.setup(b);rows=[]
    for full,blank,pending in itertools.product([0,1],[0,1],[0,128,192]):
        m=timed(base);Q.queue(m,full);Q.stage(m,[0x1a,0x30,0x27])
        H.put(m,SelectedCharacter=0,SmFreezePalettePending=pending,SmFreezeLastBlue=0,
            SmFreezeRenderState=0,DisableScreenFlag=blank,NmiDisable=0)
        c=H.start(m,'FwCheck');m.clock=c;r=V.interrupt(m,c,'NMI');del m.clock
        data=[x for x in m.hardware_events if x['address']==0x2007]
        dma=[x for x in m.hardware_events if x['address']==0x4014]
        assert data and len(dma)==1 and data[-1]['CPU']<dma[0]['CPU']
        native_P1=[x for x in data if 0x3f15<=x['PPU_address']<0x3f18]
        if pending==192:
            assert len(native_P1)==6 and native_P1[:3]==data[:3]
        rows.append(dict(queue_full=full,blank=blank,pending=pending,NMI_instruction_CPU=r['CPU'],
            first_PPUDATA_CPU=data[0]['CPU'],last_PPUDATA_CPU=data[-1]['CPU'],DMA_store_CPU=dma[0]['CPU'],
            data_writes=len(data),native_P1_events=native_P1,hardware_events=m.hardware_events))
    return dict(cases=len(rows),rows=rows,limits=[
        'Source CPU instruction timestamps only; DMA halt/DMC steals/physical VBlank timing are not simulated.',
        'All palette writes precede the paired DMA in these actual vector executions; no hardware deadline or native cadence/admission claim.',
        'Full upload and forced-blank scene costs remain visible; this repair does not shorten the parent native upload.'])

def main():
    out=O/'preflush-final-closure-v1.json';assert not out.exists()
    p=dict(passed=False,native=False,admitted=False,scheduler=False,checks={})
    try:
        b=H.C.qualified(H.O/'candidate.nes')
        for name,fn in[('own_protocol_factoring',compact_protocol),('actual_NMI_PPU_budget',source_budget)]:
            p['checks'][name]=fn(b);print(name,'PASS',flush=True)
        p['passed']=True
    except Exception as e:p.update(error=repr(e),traceback=traceback.format_exc())
    p['bindings']={str(f.resolve()):L.sha(f)for f in[Path(__file__),Path(L.__file__),Path(M.__file__),Path(V.__file__),
        R/'build/ff-fx-palette-lifecycle-v6/joint/candidate.nes',R/'build/ff-fx-palette-lifecycle-v6/joint/candidate.dbg',O/'source-closure.json',H.O/'candidate.nes',H.O/'candidate.dbg']}
    out=out if p['passed']else O/'preflush-final-closure-negative-v1.json'
    out.write_text(json.dumps(p,indent=2)+'\n',newline='\n');print(json.dumps(dict(passed=p['passed'],error=p.get('error'),path=str(out))),flush=True);assert p['passed']

if __name__=='__main__':main()
