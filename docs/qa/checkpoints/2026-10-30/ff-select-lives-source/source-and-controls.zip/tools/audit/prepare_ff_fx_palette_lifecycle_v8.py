"""Private actual current joint FF palette lifecycle, no scheduler/readiness."""
from pathlib import Path
import difflib,json,re,sys
R=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import prepare_ff_joint_source_v1 as B
from private_build_outputs_v1 import validate as validate_outputs
from prepare_ff_current_component_v2 import qualified
from check_tmnt_render_oa import address,location
from prepare_cv3_dmc_mirror import prepare
P=R/'build/current-character-composition-v2'
H=P/'source-stage-handoff-v2.json'
O=R/'build/ff-fx-palette-lifecycle-v8'
S=R/'tools/reference/ff_fx_palette_lifecycle_v5.s'
N=R/'tools/reference/ff_fx_palette_preflush_v4.s'
P1=R/'build/current-character-composition-v1'

def guarded_run(d,cmd,phase):
    proof=validate_outputs(cmd,O,cwd=R)
    B.save(d/(phase+'-validated-outputs.json'),proof)
    for flag in ['-o','--create-full-dep','-Ln','-m']:
        if flag in cmd: assert Path(cmd[cmd.index(flag)+1]).resolve().is_relative_to(O.resolve()),(phase,flag,cmd)
    for value in cmd:
        if value.startswith('--dbgfile,'):assert Path(value.split(',',1)[1]).resolve().is_relative_to(O.resolve())
    if phase!='final-link':assert Path(cmd[-1]).resolve().is_relative_to(O.resolve()),(phase,'source',cmd[-1])
    B.run(d,cmd,phase)


def main():
    assert not O.exists()
    files=B.validate(H,'131d238ed8669a294d348dae2123557c8562b4bbe418e7fd76ab2fb5e4b7ee0a')
    O.mkdir();d=O/'joint';d.mkdir();patch=[]
    for f in(P/'joint').rglob('*'):
        if f.is_file()and f.suffix in['.s','.inc','.cfg','.chr','.bin']:
            q=d/f.relative_to(P/'joint');q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(f.read_bytes())
    (d/'ff-palette-lifecycle.s').write_bytes(S.read_bytes())
    (d/'ff-palette-preflush.s').write_bytes(N.read_bytes())
    refs={n:[]for n in['FwPalettePointer','FwEffectPalettePointer']}
    for f in(P/'joint').rglob('*'):
        if f.is_file()and f.suffix in['.s','.inc']:
            for i,line in enumerate(f.read_text(errors='replace').splitlines(),1):
                for n in refs:
                    if re.search(r'\b'+n+r'\b',line):refs[n].append(dict(path=str(f.resolve()),line=i,text=line.strip()))
    assert all(r['text'].startswith(('FW_GATE ','.import '))for rs in refs.values()for r in rs)
    prior=qualified(P/'joint/candidate.nes')
    at=location(prior,'FwServiceVeneers')
    targets=[]
    for i in range(36):
        data=prior['raw'][at+i*3:at+i*3+3];assert data[0]==0x4c
        target=int.from_bytes(data[1:],'little');targets.append(target)
        assert target not in[0xaeda,0xaef4]
    p=d/'loader.s';old=p.read_text()
    before='FW_GATE FwPalettePointer,FfPalettePointer\nFW_GATE FwEffectPalettePointer,FfEffectPalettePointer'
    after='''; Two obsolete unused exports are explicitly retired; fixed52B region.
.import FwMuxMenuA,FwMuxSceneA,SmFreezeLastBlue
.export FwMuxMenuResolve,FwMuxScene
FwMuxMenuResolve:
 sta SafecallA_SMC+1
 lda #<FwMuxMenuA
 sta FarcallJmpTarget_SMC+1
 lda #>FwMuxMenuA
 sta FarcallJmpTarget_SMC+2
 lda #.lobyte(.bank(FwMuxMenuA)|$80)
 jmp FarCallCommon
FwMuxScene:
 lda SmFreezeLastBlue
 bmi FwMuxSceneOwn
 lda SelectedCharacter
 cmp #22
 beq FwMuxSceneOwn
 jmp FwRetire
FwMuxSceneOwn:
 sta SafecallA_SMC+1
 lda #<FwMuxSceneA
 sta FarcallJmpTarget_SMC+1
 lda #>FwMuxSceneA
 sta FarcallJmpTarget_SMC+2
 lda #.lobyte(.bank(FwMuxSceneA)|$80)
 jmp FarCallCommon
 .res 52-(*-FwMuxMenuResolve),$ea
 .assert *-FwMuxMenuResolve=52,error,"Own retired gate region"
'''
    assert old.count(before)==1 and old.count(' jsr FwRetire\n')==1
    new=old.replace(before,after).replace(' jsr FwRetire\n',' jsr FwMuxScene\n')
    B.write(p,new);patch+=list(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='parent/loader.s',tofile='new/loader.s'))
    p=d/'veneers.s';old=p.read_text();assert old.count('.import FwPalettePointer\n')==1
    B.write(p,old.replace('.import FwPalettePointer\n',''))
    p=d/'src/character_select.s';old=p.read_text();assert old.count('farcall ArGenResolve,jmp')==1
    new='.import FwMuxMenuResolve\n'+old.replace('farcall ArGenResolve,jmp','farcall FwMuxMenuResolve,jmp')
    B.write(p,new);patch+=list(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='parent/character_select.s',tofile='new/character_select.s'))
    p=d/'src/samus_freeze_render.s';old=p.read_text()
    assert old.count('lda #.bank(PnPaletteScreenUpdate) | MMC5_PRG_ROM')==1
    assert old.count('jmp PnHudPreUpdateScreen')==1
    new='.import FwPalettePreflush\n'+old.replace('lda #.bank(PnPaletteScreenUpdate) | MMC5_PRG_ROM','lda #.bank(FwPalettePreflush) | MMC5_PRG_ROM').replace('jmp PnHudPreUpdateScreen','jmp FwPalettePreflush')
    B.write(p,new);patch+=list(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='parent/samus_freeze_render.s',tofile='new/samus_freeze_render.s'))
    p=d/'entrypoint.s';B.write(p,p.read_text()+'\n.export SmFreezePalettePacket,SmFreezeTurn,SmFreezeLastBlue,UpdateScreen,PnHudPreUpdateScreen\n.exportzp NmiR0,NmiR1\n')
    p=d/'private.cfg';cfg=p.read_text().replace((P/'joint').as_posix(),d.as_posix())
    for target in re.findall(r'file="([^"]+)"',cfg):
        if target!='%O':assert Path(target).resolve().is_relative_to(O.resolve()),target
    mem,segs=cfg.split('SEGMENTS {',1)
    mem=mem.rsplit('}',1)[0]+'FF_FX_PROTOCOL_RUN:start=$be2f,size=$1d1,type=ro,file="",bank=93;\n}\n'
    needle='FF_HOST_PALETTE_C:load=FF_ART_MEM,type=ro;';assert segs.count(needle)==1
    segs=segs.replace(needle,needle+'\nFF_FX_PROTOCOL_A:load=FF_ART_MEM,run=FF_FX_PROTOCOL_RUN,type=ro;\nFF_FX_PREFLUSH_C:load=FF_ART_MEM,type=ro;')
    B.write(p,mem+'SEGMENTS {'+segs)
    recipes={'main':P1/'compile-main.json','loader':P/'compile-joint-loader.json','veneers':P1/'compile-FF-veneers.json'}
    for n,recipe in recipes.items():
        cmd=json.loads(recipe.read_text())['command']
        cmd=[v.replace(str(P1/'joint'),str(d)).replace(str(P/'joint'),str(d))for v in cmd]
        guarded_run(d,cmd,n+'-build')
    cmd=[str(R/'tools/Windows/cc65/bin/ca65.exe'),'-g','--cpu','6502x','--create-full-dep',str(d/'ff-palette-lifecycle.dep'),'-o',str(d/'ff-palette-lifecycle.o'),str(d/'ff-palette-lifecycle.s')]
    guarded_run(d,cmd,'ff-palette-lifecycle-build')
    cmd=[str(R/'tools/Windows/cc65/bin/ca65.exe'),'-g','--cpu','6502x','--create-full-dep',str(d/'ff-palette-preflush.dep'),'-o',str(d/'ff-palette-preflush.o'),str(d/'ff-palette-preflush.s')]
    guarded_run(d,cmd,'ff-palette-preflush-build')
    cmd=json.loads((P/'final-link.json').read_text())['command']
    cmd=[v.replace(str(P/'joint/candidate'),str(d/'candidate')).replace(str(P/'joint/private.cfg'),str(d/'private.cfg'))
        .replace(str(P/'joint/main.o'),str(d/'main.o')).replace(str(P/'joint/loader.o'),str(d/'loader.o'))
        .replace(str(P/'joint/veneers.o'),str(d/'veneers.o'))for v in cmd]+[str(d/'ff-palette-lifecycle.o'),str(d/'ff-palette-preflush.o')]
    guarded_run(d,cmd,'final-link');prepare(R,d/'candidate.nes');new=qualified(d/'candidate.nes')
    assert address(new,'FwMuxMenuResolve')==0xaeda and address(new,'FwMuxScene')==0xaeec
    assert address(new,'FwCookie')==address(prior,'FwCookie')==0xaf0e
    assert address(new,'FwMuxMenuA')==0xbe2f
    assert 'FwPalettePointer'not in new['syms']and'FwEffectPalettePointer'not in new['syms']
    for name in['FwLoad','FwSceneInit','FwRetire','ArGenResolve','ArGenSceneInit','FwServiceVeneers','MenuResolveCharacter','FwNativeDrawAll','FfHostPaletteCEnd']:
        assert address(new,name)==address(prior,name),name
    assert(d/'ram3.bin').read_bytes()==(P/'joint/ram3.bin').read_bytes()
    for n in['ff-stream.bin','ff-cookie.bin']:assert(d/n).read_bytes()==(P/'joint'/n).read_bytes()
    protocol=location(new,'FwMuxMenuA');protocol_end=location(new,'FwMuxProtocolEnd');end=location(new,'FwPalettePreflushEnd')
    assert set(prior['raw'][protocol:end])<={255}
    menu=location(prior,'MenuResolveCharacter');scene=location(prior,'FwSceneInit')
    ranges=[(location(prior,'FwPalettePointer'),location(prior,'FwCookie'),'own_retired_unused52B'),
        (protocol,end,'own_ART_tail_A93_and_C93_views'),(menu,menu+18,'existing_MenuResolve_farcall_operands'),
        (scene,location(prior,'FwCheck'),'existing_FwSceneInit_JSR_operand'),
        (location(prior,'SamusFreezeUpdateScreen'),location(prior,'SamusFreezeUpdateScreen')+9,'existing_resident9B_gateway_operands')]
    diff=[i for i,(a,z)in enumerate(zip(prior['raw'],new['raw']))if a!=z]
    assert all(any(a<=i<z for a,z,n in ranges)for i in diff)
    B.write(O/'source.patch',''.join(patch))
    files|={Path(__file__),S,N,R/'tools/audit/prepare_ff_fx_palette_lifecycle_v1.py',R/'build/ff-fx-palette-lifecycle-v1/recovery-complete.json'}|{Path(v)for v in cmd if v.endswith('.o')}
    files|={f for f in O.rglob('*')if f.is_file()}
    B.save(O/'source-closure.json',dict(passed=True,native=False,admitted=False,scheduler=False,
        candidate_sha256=B.sha(d/'candidate.nes'),parent_sha256=B.sha(P/'joint/candidate.nes'),
        wrapper_bytes=51,wrapper_span=[0xaeda,0xaf0e],worker_bytes=protocol_end-protocol,preflush_bytes=end-protocol_end,total_ART_tail_bytes=end-protocol,
        worker_run_bank=93,worker_run_PC=address(new,'FwMuxMenuA'),worker_load_ROM_offset=protocol,
        obsolete_exports_explicitly_removed=['FwPalettePointer AEDA','FwEffectPalettePointer AEF4'],
        obsolete_source_references=refs,all36_original_targets_exact=targets,changed_bytes=len(diff),allowed_ranges=ranges,
        native_live_public_PCs_header_CHR_RAM3_cookie_exact=True,
        limits=['Exact C0 pre-native restore prototype; actual event-order/PPU/interrupt qualification is still required.',
            'No scheduler, FX palette production, readiness, native execution or shared adoption.'],
        bindings={str(f.resolve()):B.sha(f)for f in sorted(files)}))
    print(json.dumps(dict(passed=True,ROM=B.sha(d/'candidate.nes'),worker_bytes=protocol_end-protocol,preflush_bytes=end-protocol_end,total_ART_tail_bytes=end-protocol,changed_bytes=len(diff))),flush=True)

if __name__=='__main__':main()
