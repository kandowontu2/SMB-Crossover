"""Publish an explicit additive correction, never rewrite frozen receipts."""
from pathlib import Path
import json,sys,zipfile,hashlib
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import prepare_ff_joint_source_v1 as B
def checkpoint_write(p,s):
    p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,encoding='utf-8',newline='\n')
B.write=checkpoint_write
D=R/'docs/qa/checkpoints/2026-10-30/ff-epoch-coverage-correction'

def main():
    assert not D.exists();D.mkdir(parents=True)
    p=R/'build/ff-fx-epoch-action-witness-v1/controls.json';w=json.loads(p.read_text());assert w['passed']
    rows=w['actual_action_rows'];assert len(rows)==20 and all(r['sword_family_admitted']and r['chosen_family']==4 for r in rows)
    files={Path(__file__),p,R/'tools/audit/ff_fx_epoch_action_witness_v1.py',R/'src/final_fantasy_render.s'}
    for f,h in w['bindings'].items():assert B.sha(f)==h,f
    priors={
        '480_model':'build/ff-fx-epoch-oracle-v3/controls.json',
        '480_frozen_model_handoff':'build/ff-fx-epoch-model-qualified-v1/handoff.json',
        '3072_slow_Draw':'build/ff-fx-epoch-cart-v4/epoch-controls-v2.json',
        '3072_slow_frozen_handoff':'build/ff-fx-epoch-cart-v4/handoff-performance-hold-v1.json',
        '3072_tagged_Draw':'build/ff-fx-epoch-fast-v2/epoch-controls-v3.json',
        'independent576_source_sword_iterator':'build/ff-fx-sword-role-audit-v1/controls.json',
    }
    correction=dict(status='EXPLICIT_ADDITIVE_COVERAGE_CORRECTION',native=False,admitted=False,
        reason='Old frame fixtures assigned FfPose, then called real FfHostGraphics. Original FfGraphics recomputes pose from action/age/state, replacing that assigned request.',
        restricted_prior_receipts={n:{'path':v,'sha256':B.sha(R/v)}for n,v in priors.items()},
        withdrawn_claim='Those480/model and3072 Draw comparisons did not establish actual admitted sword-family4 coverage merely because their row labeled a requested swordpose.',
        preserved_scope='The finite cases retain their exact observed idle-body/spell/world/OAM/palette and lifecycle comparisons. Frozen receipts, archives and source bytes remain unchanged; no silent relabel.',
        independent_valid_scope='576 direct original source iterator views still prove body0/sword2/ink3 records and exact source palette vectors; that fixture intentionally called the iterator directly.',
        actual_replacement_witness=dict(path=str(p.relative_to(R)),sha256=B.sha(p),cases=20,
            inputs='Fighter/Thief × ShadowsON/OFF × actual action1, ages0/6/12/18/24',
            assertions='Real graphics producer emits actual poses6..10; real native DrawAll completes and emitted scheduler actually admits family4.',
            rows=rows),
        retained_negative=w['pose_only_fixture_gap'],
        required_full_revalidation='All requested pose/family combinations must derive genuine action/age/state and assert real graphics pose; real FfProjectileEntry must equal each requested active entry. Revised fullmatrix remains separately qualified, not assumed here.',
        holds=['Private source only; no native/readiness/admission/installation.',
               'Measured performance HOLD remains. This correction adds no gameplay or native campaign claim.'],
        bindings={str(f.resolve()):B.sha(f)for f in sorted(files)})
    B.save(D/'correction.json',correction)
    B.write(D/'README.md','''Coverage correction for frozen FF epoch evidence.

The480-case epoch model and3072-case Draw comparison fixtures wrote FfPose
before calling genuine FfHostGraphics. The original graphics producer then
recomputed pose from action/age/state. A requested sword pose in those rows
therefore did not prove that a sword was actually drawn or palette-scheduled.

All frozen receipts/archives remain unchanged. Their exact finite observed
body/spell/world/OAM/palette cases remain evidence within that narrower scope.
The separate576-view direct source-iterator sword audit remains valid.

The replacement20-case action witness supplies real action1 and ages0,6,12,
18,24 for Fighter/Thief with both Shadows options. It asserts actual native
graphics poses6..10 and admitted sword family4 in completed DrawAll output.
The old pose-only input is retained as an explicit requested6→actual1 negative.

Full source-color coverage requires separately rerunning the complete matrix
with genuine producer inputs and asserted actual pose/projectile entries. This
checkpoint does not infer that broader pass. Private/admission/performance
holds remain. No shared/installed/source/frozen receipt or Git-index edits.
''')
    files.add(D/'correction.json');files.add(D/'README.md')
    zpath=D/'source-witness.zip'
    with zipfile.ZipFile(zpath,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
        for f in sorted(files):z.write(f,f.relative_to(R).as_posix())
    with zipfile.ZipFile(zpath)as z:
        for f in files:assert hashlib.sha256(z.read(f.relative_to(R).as_posix())).hexdigest()==B.sha(f)
    B.save(D/'archive-proof.json',dict(passed=True,source_only=True,members=len(files),archive_sha256=B.sha(zpath),bytes=zpath.stat().st_size,
        correction_sha256=B.sha(D/'correction.json'),no_binary_game_objects_or_debug=True))
    print(json.dumps(dict(correction_sha256=B.sha(D/'correction.json'),directory=str(D),archive_bytes=zpath.stat().st_size)),flush=True)

if __name__=='__main__':main()
