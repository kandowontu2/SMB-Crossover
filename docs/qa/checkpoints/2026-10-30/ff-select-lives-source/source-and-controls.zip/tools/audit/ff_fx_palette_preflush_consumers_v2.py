"""Actual later native producers must win over a retired FF P1 packet."""
from pathlib import Path
import itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import ff_fx_palette_lifecycle_controls_v5 as L
H,M,T,Q=L.H,L.M,L.T,L.Q
from check_tmnt_render_oa import address
O=L.O

def empty(m):
    H.put(m,VRAM_Buffer1_Offset=0,VRAM_Buffer_AddrCtrl=0)
    m[address(m.bundle,'VRAM_Buffer1')]=0

def compare(m):
    ref=T.copy(m);H.put(ref,SmFreezePalettePending=0)
    expected=Q.consume(ref,0);actual=Q.consume(m,0)
    assert bytes(m.vram[0x3f00:0x3f20])==bytes(ref.vram[0x3f00:0x3f20]),('later native palette lost',expected,actual)
    assert actual['pending']==0
    assert bytes(m[512:768])==bytes(ref[512:768])
    return dict(native_P1=expected['P1'],preflush_P1=actual['P1'],native_NMI_CPU=expected['CPU'],preflush_NMI_CPU=actual['CPU'],
        native_OAM_parts=sum(m[512+4*i]<240 for i in range(64)),PPU_palette32_native_exact=True,PPU_before_DMA=True)

def late_CF(b):
    base=M.setup(b);rows=[]
    for full,pause in itertools.product([0,1],[0,1]):
        m=T.copy(base);L.put_owner(m)
        if full:Q.queue(m,1)
        else:empty(m)
        H.put(m,SelectedCharacter=22,CrossoverMenuIndex=29,CrossoverMenuState=2,CrossoverMenuButtons=0,
            SavedJoypad1Bits=1,SavedJoypad2Bits=0,FmGroups=0,OperMode=0,OperMode_Task=3,NmiDisable=0,GamePauseStatus=pause)
        c,low=M.invoke_main(m,lambda *args:None)
        if pause:
            # Genuine paused Main does not process the menu edge. Retain its
            # active FF packet rather than inventing a selection transition.
            assert H.get(m,'CrossoverMenuIndex')==29 and H.get(m,'SelectedCharacter')==22
            assert H.get(m,'SmFreezePalettePending')==128 and H.get(m,'SmFreezeLastBlue')==129
            r=Q.consume(m,0);assert r['P1']==[0x16,0x26,0x30]and r['pending']==0
            rows.append(dict(queue_full=full,pause=pause,Main_CPU=c.processorCycles,
                paused_Main_does_not_publish_selection=True,original80_source_packet_preserved=True,native_NMI=r))
            continue
        assert H.get(m,'CrossoverMenuIndex')==30 and H.get(m,'SmFreezePalettePending')==192
        r=compare(m)
        if not full:assert r['native_P1']==[0x37,0x16,0x0f]and r['native_OAM_parts']==5
        rows.append(dict(queue_full=full,pause=pause,Main_CPU=c.processorCycles,minimum_SP=low,**r))
    return dict(cases=len(rows),rows=rows,genuine_GameLoop_CF_preview_producer=True)

def late_scene(b):
    base=M.setup(b);rows=[]
    for area,full,cold in itertools.product(range(4),[0,1],[0,1]):
        m=T.copy(base);L.put_owner(m)
        if full:Q.queue(m,1)
        else:empty(m)
        if cold:m.ram[3][0x1fe0]=0
        H.put(m,SelectedCharacter=22,AreaType=area,Mirror_PPUMASK=0,DisableScreenFlag=1,
            ScreenRoutineTask=0,NmiDisable=255,SmFreezeRenderState=1)
        c,low=H.invoke(m,'InitScreen')
        assert H.get(m,'SmFreezePalettePending')==192 and H.get(m,'SmFreezeLastBlue')==128
        assert H.get(m,'SmFreezePaletteControl')==3 and H.get(m,'SmFreezeRenderState')==0
        rows.append(dict(area=area,queue_full=full,cold_code_cookie=cold,InitScreen_CPU=c.processorCycles,minimum_SP=low,**compare(m)))
    return dict(cases=len(rows),rows=rows,genuine_InitScreen_control3_after_helper_wins=True)

def late_Quick(b):
    base=M.setup(b);rows=[]
    for full,lag in itertools.product([0,1],[0,255]):
        m=T.copy(base);L.put_owner(m)
        H.put(m,SelectedCharacter=22,CrossoverMenuIndex=9,FmAlts=32,RdVariant=0,MarioVariant=0)
        H.invoke(m,'MenuResolveCharacter');assert H.get(m,'SelectedCharacter')==9
        if full:Q.queue(m,1)
        else:empty(m)
        # Actual immutable source queue producer; this stage does not yet
        # install the later shared Quick ingress or a natural cold constructor.
        c,low=H.invoke(m,'QwColors')
        if lag:
            before=bytes(m.vram);r=Q.consume(m,255)
            assert bytes(m.vram)==before and r['pending']==192
        r=compare(m)
        assert r['native_P1']==([0x1a,0x30,0x27]if full else[0x0f,0x30,0x38])
        rows.append(dict(queue_full=full,lag=lag,QwColors_CPU=c.processorCycles,minimum_SP=low,**r))
    return dict(cases=len(rows),rows=rows,genuine_QwColors_API_queue_preserved=True,
        limits=['Direct genuine source API is explicit; no natural Quick menu-to-Main/readiness claim.'])

def new_Samus_writer(b):
    base=M.setup(b);rows=[]
    for full,frozen in itertools.product([0,1],[0,1]):
        m=T.copy(base);L.put_owner(m)
        H.put(m,SelectedCharacter=22,CrossoverMenuIndex=2,FmAlts=0,RdVariant=0,MarioVariant=0)
        H.invoke(m,'MenuResolveCharacter')
        if full:Q.queue(m,1)
        else:empty(m)
        assert H.get(m,'SmFreezePalettePending')==192 and H.get(m,'SmFreezeLastBlue')==0
        # Declared admitted OAM fixture for the genuine original Samus
        # compositor. A new source producer may replace the retired packet.
        if frozen:
            m[512]=100;m[513]=0;m[514]=0x10;m[515]=100
        H.put(m,SmFreezeRenderState=1,CrossoverBehaviorVersion=1,AvFrozen=1)
        H.invoke(m,'SamusFreezeRenderFinish')
        expected=[0x11,0x31,1]if frozen else[0x1a,0x30,0x27]
        assert H.get(m,'SmFreezePalettePending')==(128 if frozen else 192)
        r=Q.consume(m,0);assert r['P1']==expected and r['pending']==0
        rows.append(dict(queue_full=full,new_frozen_actor=frozen,**r))
    return dict(cases=len(rows),rows=rows,actual_Samus80_later_producer_not_clobbered=True)

def main():
    out=O/'actual-preflush-consumers-v2.json';assert not out.exists()
    p=dict(passed=False,native=False,admitted=False,scheduler=False,checks={})
    try:
        b=H.C.qualified(H.O/'candidate.nes')
        for name,fn in [('CF',late_CF),('InitScreen',late_scene),('Quick_source_API',late_Quick),('Samus_later_source',new_Samus_writer)]:
            p['checks'][name]=fn(b);print(name,'PASS',flush=True)
        p['passed']=True
    except Exception as e:p.update(error=repr(e),traceback=traceback.format_exc())
    p['bindings']={str(f.resolve()):L.sha(f)for f in[Path(__file__),Path(L.__file__),Path(M.__file__),Path(Q.__file__),O/'source-closure.json',H.O/'candidate.nes',H.O/'candidate.dbg']}
    out=out if p['passed']else O/'actual-preflush-consumers-negative-v2.json'
    out.write_text(json.dumps(p,indent=2)+'\n',newline='\n');print(json.dumps(dict(passed=p['passed'],error=p.get('error'),path=str(out))),flush=True);assert p['passed']

if __name__=='__main__':main()
