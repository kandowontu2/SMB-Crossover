"""Route the genuine early UI consumer to Quick's existing typed service.

Use only the explicitly reserved 40-byte tail of the existing X5 UI segment.
The native-qualified cold/source packet remains immutable.
"""
from pathlib import Path
import difflib, hashlib, json, shutil, subprocess, sys
from private_build_outputs_v1 import validate
from check_tmnt_render_oa import load, address

R=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(R/'tools'))
P=R/'build/current-character-quick-cold-v12/joint'
O=R/'build/current-character-quick-ui-v13'
N=O/'joint'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def verify(p):
 d=json.loads(Path(p).read_text())
 for n,v in d['bindings'].items():assert sha(n)==v,n
 return d
def rebase(q,old=P):return[x.replace(str(old),str(N)).replace(old.as_posix(),N.as_posix())for x in q]
def run(q,name):
 p=subprocess.run(q,cwd=R,text=True,capture_output=True)
 (O/(name+'.json')).write_text(json.dumps(dict(command=q,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr),indent=2)+'\n')
 assert p.returncode==0,(name,p.stderr)
def main():
 assert not O.exists()
 verify(P.parent/'handoff.json');verify(P.parent/'native-qualified-physical-v3/handoff.json')
 receipt=R/'docs/qa/checkpoints/2026-10-30/new-roster-source-ui-fastpath/quick-selected-successor-reservation.json'
 grant=json.loads(receipt.read_text())
 raw=(P/'candidate.nes').read_bytes();at=16+86*8192+0x79c
 assert raw[at:at+100]==bytes([255])*100
 assert sha_bytes(raw[at:at+100])=='da6f14970ce356ce01a5b340291e9d8b2652eb63fbf8f328ca6a87a727fde4d9'
 O.mkdir();shutil.copytree(P,N)
 for p in N.rglob('*'):
  if p.is_file()and p.suffix in ['.s','.inc','.cfg']:
   s=p.read_text();z=s.replace(str(P),str(N)).replace(P.as_posix(),N.as_posix())
   if s!=z:p.write_text(z,newline='\n')
 p=N/'src/x5_bounce.s';s=p.read_text()
 a=s.index('.proc X5OwnInventoryUi\n');b=s.index('.export X5OwnInventoryUi',a)
 part=s[a:b];old=' cpx #13\n bcc Legacy\n cpx #15'
 assert part.count(old)==1
 part=part.replace(old,' jmp X5QuickUiAdmission\n nop\n::X5UiAfterLow:\n cpx #15')
 s=s[:a]+part+s[b:]
 old='.assert * <= $a800,error,"UI router must precede Dragon Power core"'
 new='''; Original X5 stack still holds X/A/P, and Y has already been restored.
; Only the authenticated raw9+Quick bit goes to the existing typed UI route.
; Every foreign branch returns to the exact original same-frame continuation.
.assert *=$a79c,error,"Exact root-reserved UI tail start"
.proc X5QuickUiAdmission
 cpx #13
 bcc CheckQuick
 jmp X5UiAfterLow
CheckQuick:
 cpx #9
 bne Legacy
 lda FmAlts
 and #32
 beq Legacy
 jmp X5OwnInventoryUi::NewUiBridge
Legacy:
 jmp X5OwnInventoryUi::Legacy
.endproc
.assert *<=$a7c4,error,"Exact 40B root-granted UI helper bound"
'''+old
 assert s.count(old)==1;s=s.replace(old,new)
 p.write_text(s,newline='\n')
 (O/'source.patch').write_text(''.join(difflib.unified_diff((P/'src/x5_bounce.s').read_text().splitlines(True),s.splitlines(True),fromfile='parent/src/x5_bounce.s',tofile='successor/src/x5_bounce.s')),newline='\n')
 parent7=R/'build/current-character-quick-cold-v7/joint'
 maincmd=rebase(json.loads((parent7.parent/'compile-main.json').read_text())['command'],parent7)
 link=rebase(json.loads((P.parent/'final-link.json').read_text())['command'])
 commands=[(maincmd,'compile-main'),(link,'final-link')]
 (O/'output-preflight.json').write_text(json.dumps([validate(q,N,cwd=R)for q,_ in commands],indent=2)+'\n')
 for q,name in commands:run(q,name)
 from prepare_cv3_dmc_mirror import prepare
 prepare(R,N/'candidate.nes')
 for name in ['code.bin','data.bin','ram3.bin','ff-cookie.bin','quick/cookie.bin']:
  assert(N/name).read_bytes()==(P/name).read_bytes(),name
 before=load(P/'candidate.nes');after=load(N/'candidate.nes')
 changed=[]
 for name in before['syms']:
  try:x=address(before,name);y=address(after,name)
  except (KeyError,ValueError,TypeError):continue
  if x!=y:changed.append([name,x,y])
 assert not changed,changed[:20]
 actual=(N/'candidate.nes').read_bytes()
 diffs=[i for i,(a,b)in enumerate(zip(raw,actual))if a!=b]
 assert len(raw)==len(actual)and all(16+86*8192<=i<16+87*8192 for i in diffs),diffs[:20]
 helper=address(after,'X5QuickUiAdmission');assert helper==0xa79c
 stage=dict(candidate=sha(N/'candidate.nes'),parent=sha(P/'candidate.nes'),native=False,installed=False,
  scope='Genuine early UI: exact raw9/FmAlts20 routes existing NrUi→service29 QhUi; foreign same-bank callbacks/maps retained.',
  helper_start=helper,helper_bytes=24,grant_bytes=40,all_prior_symbol_values_exact=True,ROM_changed_bytes=len(diffs),
  payloads_exact=True,source_grant=sha(receipt),qualification='PENDING',
  bindings={str(p.resolve()):sha(p)for p in [Path(__file__),receipt,O/'source.patch',O/'output-preflight.json',P.parent/'handoff.json',P.parent/'native-qualified-physical-v3/handoff.json']})
 (O/'source-stage.json').write_text(json.dumps(stage,indent=2)+'\n')
 verify(P.parent/'handoff.json');verify(P.parent/'native-qualified-physical-v3/handoff.json')
 print(json.dumps(stage))
def sha_bytes(v):return hashlib.sha256(v).hexdigest()
if __name__=='__main__':main()
