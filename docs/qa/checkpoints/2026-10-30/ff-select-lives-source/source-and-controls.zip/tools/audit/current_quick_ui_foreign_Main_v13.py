"""Repeat actual legacy Main and active FF/Arthur consumers on the UI leaf."""
from pathlib import Path
import json,traceback
import prepare_current_quick_ui_v13 as B
import quickman_wram_palette_controls_v6 as C
import new_roster_ui_source_route_controls_1030_v2 as U

def main():
 out=B.O/'foreign-active-Main-controls.json';assert not out.exists();d=dict(passed=False,native=False,checks={})
 try:
  base=C.H.U;oldload=base.scoped_load;parent=oldload(B.P/'candidate.nes')
  def load(path):return parent if Path(path)==B.R/'build/pit-retold-host-v3/candidate.nes'else oldload(path)
  base.scoped_load=load
  try:d['checks']['legacy_Main']=base.foreign(oldload(B.N/'candidate.nes'))
  finally:base.scoped_load=oldload
  U.P=B.P;U.O=B.N
  d['checks']['active_FF_Main']=U.ff()
  old,new=[U.A.scoped_load(p/'candidate.nes')for p in[B.P,B.N]]
  d['checks']['active_Arthur_Main']=U.arthur(old,new)
  d['passed']=True
 except Exception as e:d.update(error=repr(e),traceback=traceback.format_exc())
 d['bindings']={str(Path(p).resolve()):B.sha(p)for p in[__file__,Path(U.__file__),B.N/'candidate.nes',B.N/'candidate.dbg',B.P/'candidate.nes',B.P/'candidate.dbg']}
 out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(passed=d['passed'],error=d.get('error'),checks={n:{k:v for k,v in q.items()if k in['cases','actual_FF_Main_pairs','actual_Arthur_Main_real_serial_NMI_pairs','CPU_delta','source_palette_tick_always_once']}for n,q in d['checks'].items()})));assert d['passed'],d.get('error')
if __name__=='__main__':main()
