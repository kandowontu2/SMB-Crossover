"""Actual original body tick + emitted FX heartbeat and skipped Main proof."""
from pathlib import Path
import itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import ff_fx_epoch_cart_controls_v5 as E
import ff_fx_world_marker_main_v1 as W
from check_tmnt_render_oa import address,location
H,M,T,L,V=E.H,E.M,E.T,E.L,E.V
P=E.P;N=E.N;H.O=N/'joint'

def consume(m):
    # A native0 heartbeat deliberately queues nothing. Still execute real
    # normalNMI and require every actual PPU write before paired OAM DMA.
    H.put(m,NmiDisable=0);m.writes.clear();m.ppu_log.clear()
    c=H.start(m,'FwCheck');r=V.interrupt(m,c,'NMI')
    data=[i for i,(a,v)in enumerate(m.writes)if a==0x2007]
    dma=[i for i,(a,v)in enumerate(m.writes)if a==0x4014]
    assert dma and (not data or max(data)<min(dma))
    H.finish(m,c)
    return dict(P1=list(m.vram[0x3f15:0x3f18]),pending=H.get(m,'SmFreezePalettePending'),data_writes=len(data),**r)

def aliases(m):
    b=m.bundle
    return set(range(address(b,'SmFreezePalettePacket'),address(b,'SmFreezePalettePacket')+7))|{
        address(b,n)for n in ['SmFreezePalettePending','SmFreezeTurn','SmFreezeLastBlue']}

def signature(m):
    exclude=set(range(0x100,0x200))|set(range(0x5114,0x5118))|aliases(m)
    return bytes(m[i]for i in range(0x8000)if i not in exclude)

def actual_epoch(b,family):
    base=E.fresh(b,1)
    sword=next(r['pose']for r in json.loads((R/'build/ff-fx-sword-role-audit-v1/controls.json').read_text())['rows']if r['character']=='Fighter'and r['sword_parts'])
    variant,pose,off,kind,entries={0:(0,1,1,'flower',[]),1:(2,1,1,'empty',[(0,144)]),2:(2,1,1,'empty',[(0,149)]),3:(2,1,1,'empty',[(0,154)]),4:(0,sword,1,'empty',[]),5:(0,1,0,'empty',[])}[family]
    m,c,low=E.frame(base,variant,pose,off,1,kind,entries,family)
    assert H.get(m,'SmFreezeLastBlue')==128|family,(family,H.get(m,'SmFreezeLastBlue'))
    consume(m)
    return m

def old_body_context(seed,m):
    # Explicit body-tick differential projection only: old ROM+its verified
    # original RAM3 stay untouched; copy the genuine completed-frame inputs.
    n=T.copy(seed)
    for a in list(range(0x100))+list(range(0x200,0x800))+list(range(0x5c00,0x6000)):
        list.__setitem__(n,a,m[a])
    n.ram[0][:]=m.ram[0]
    for a in range(0x6000,0x8000):list.__setitem__(n,a,m[a])
    n.raw_page(1,m.rawtags[1]);n.raw_page(2,m.rawtags[2])
    n.vram[:]=m.vram;n.chr_latches[:]=m.chr_latches
    return n

def tick_pairs(old,new):
    oldseed=E.fresh(old,1);contexts={f:actual_epoch(new,f)for f in range(6)};rows=[]
    for family,full,flags in itertools.product(range(6),[0,1],[48|i for i in range(256)if not i&48]):
        result=[]
        for b,entry in zip([old,new],['FwPaletteTick','FfMuxTickROM']):
            m=old_body_context(oldseed,contexts[family])if b is old else T.copy(contexts[family]);H.put(m,SmFreezeLastBlue=128|family,SmFreezeTurn=5,
                SmFreezePalettePending=0,NmiDisable=255,FfPaletteAck=255)
            L.Q.queue(m,full);oldOAM=bytes(m[512:768]);m.writes.clear()
            c,low=H.invoke(m,entry,a=0xa5,x=0x71,y=0x39,p=flags)
            assert bytes(m[512:768])==oldOAM and H.get(m,'SmFreezeTurn')==5
            result.append((m,c,low))
        (a,c,lo),(z,d,lz)=result
        assert(c.a,c.x,c.y,c.p,c.sp)==(d.a,d.x,d.y,d.p,d.sp),('body heartbeat nativeAXYP',family,full,flags,c.p,d.p)
        assert signature(a)==signature(z) and a.rawtags==z.rawtags
        assert H.get(a,'FfPaletteAck')==H.get(z,'FfPaletteAck')
        assert H.get(z,'SmFreezeLastBlue')==128|family and H.get(z,'SmFreezePalettePending')==(0 if family==0 else 128)
        wanted=E.O.family_vectors(old).get(family,[0x1a,0x30,0x27])
        # Real active normalNMI consumes a full packet even when native queue
        # was already full and original body cache correctly stayed pending.
        r=consume(z);assert r['P1']==wanted and r['pending']==0
        rows.append(dict(family=family,queue_full=full,flags=flags,body_ACK=H.get(z,'FfPaletteAck'),
            old_CPU=c.processorCycles,new_CPU=d.processorCycles,minimum_SP=lz))
    return dict(cases=len(rows),rows=rows,actual_original_body_tick_and_outputs_exact=True,
        fullqueue_does_not_drop_P1_restore_or_active_epoch=True,heartbeat_does_not_advance_cursor_or_mutate_OAM=True)

def main_pause_skip(new):
    contexts={f:actual_epoch(new,f)for f in range(6)};rows=[]
    for family,pause,skip,full in itertools.product([0,1,2,3,4,5],[0,1],[0,1],[0,1]):
        m=T.copy(contexts[family]);H.put(m,SmFreezeLastBlue=128|family,SmFreezeTurn=4,SmFreezePalettePending=0,
            GamePauseStatus=pause,ShouldSkipDrawSprites=skip,NmiDisable=255)
        L.Q.queue(m,full);calls=[];clock=[]
        pc=address(new,'FfMuxHeartbeat');late=address(new,'FfMuxNativeLate')
        def observe(mem,c,i):
            if mem.rawtags[1]==3 and c.pc==pc:calls.append([i,H.get(mem,'NmiDisable')])
            if mem.rawtags[1]==3 and c.pc==late:clock.append(i)
        oldOAM=bytes(m[512:768]);oldTurn=H.get(m,'SmFreezeTurn')
        c,low=M.invoke_main(m,observe)
        assert calls and len(calls)==1 and calls[0][1]==255
        assert H.get(m,'NmiDisable')==0
        if pause or skip:
            assert not clock
            assert H.get(m,'SmFreezeTurn')==oldTurn and bytes(m[512:768])==oldOAM
            assert H.get(m,'SmFreezeLastBlue')==128|family
        else:assert len(clock)==1
        last=H.get(m,'SmFreezeLastBlue')&7
        wanted=E.O.family_vectors(new).get(last,[0x1a,0x30,0x27])
        r=consume(m);assert r['P1']==wanted and r['pending']==0
        rows.append(dict(prior_family=family,pause=pause,skip=skip,fullqueue=full,
            real_heartbeat_calls=calls,real_completed_DrawAll=len(clock),final_family=last,CPU=c.processorCycles,minimum_SP=low))
    return dict(cases=len(rows),rows=rows,actual_Row29_before_pause_and_skip_draw=True)

def main():
    p=dict(passed=False,native=False,admitted=False,checks={})
    try:
        old=H.C.qualified(P/'joint/candidate.nes');new=H.C.qualified(N/'joint/candidate.nes')
        p['checks']['body_tick_heartbeat']=tick_pairs(old,new);print('body/heartbeat PASS',flush=True)
        p['checks']['actual_Main_pause_skip']=main_pause_skip(new);print('actualMain pause/skip PASS',flush=True)
        p['passed']=True
    except Exception as e:p.update(error=repr(e),traceback=traceback.format_exc())
    files=[Path(__file__),Path(E.__file__),Path(M.__file__),Path(H.__file__),Path(L.__file__),N/'source-closure.json',
        P/'handoff.json',P/'joint/candidate.nes',P/'joint/candidate.dbg',N/'joint/candidate.nes',N/'joint/candidate.dbg']
    p['bindings']={str(f.resolve()):L.sha(f)for f in files}
    out=N/('heartbeat-controls-v5.json'if p['passed']else'heartbeat-negative-v5.json');assert not out.exists()
    out.write_text(json.dumps(p,indent=2)+'\n',newline='\n')
    print(json.dumps(dict(passed=p['passed'],path=str(out),error=p.get('error'))),flush=True);assert p['passed']

if __name__=='__main__':main()
