"""Real joint menu/InitScreen lifecycle and native P1/DMA consumer proof."""
from pathlib import Path
import itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import ff_joint_actual_main_v2 as M
import ff_joint_typed_controls_v1 as T
import ff_host_pickups_vectors_v2 as V
import ff_fx_palette_mailbox_audit_v2 as Q
from ff_wram_host_isr_v4 import clone
from check_tmnt_render_oa import address,location
H=M.H;sha=M.sha
P=R/'build/current-character-composition-v2/joint'
O=R/'build/ff-fx-palette-lifecycle-v3';H.O=O/'joint'
FIELDS=['SmFreezePalettePacket','SmFreezePalettePending','SmFreezeLastBlue','SmFreezeTurn','SmFreezeRenderState']

def put_owner(m,owner=129,pending=128):
    H.put(m,SmFreezeLastBlue=owner,SmFreezePalettePending=pending,SmFreezeTurn=2,
        SmFreezeRenderState=0,SmFreezePaletteControl=2,NmiDisable=255)
    for i in range(64):m[512+4*i]=120
    m.vram[0x3f15:0x3f18]=bytes([0x16,0x26,0x30])
    at=address(m.bundle,'SmFreezePalettePacket')
    for i,v in enumerate([63,21,3,22,38,48,0]):m[at+i]=v

def native_colors(control,area=1):
    return [[0x11,0x31,1],[0x10,0x30,0x27],[0x1a,0x30,0x27],
        [0x1c,0x36,0x17],[0x1c,0x36,0x17],[0x1a,0x30,0x27],
        [0x1a,0x30,0x27],[0x1a,0x30,0x27],[0x1a,0x30,0x27]][control]

def packet(m):
    at=address(m.bundle,'SmFreezePalettePacket');return list(m[at:at+7])

def event_order(m):
    b=m.bundle;selected=address(b,'SelectedCharacter');pending=address(b,'SmFreezePalettePending')
    stores=[i for i,(a,v)in enumerate(m.writes)if a==selected]
    ready=[i for i,(a,v)in enumerate(m.writes)if a==pending and v==128]
    clears=[i for i,(a,v)in enumerate(m.writes)if 512<=a<768 and a%4==0 and v==248]
    assert stores and ready and len(clears)>=64
    assert max(ready)<min(stores) and max(clears[:64])<min(stores)
    return dict(native_restore_pending_before_Selected=True,old_FF_OAM_clear_before_Selected=True,
        ready_write=ready[-1],first_Selected_write=stores[0],native_clear_parts=len(clears))

def menu(b):
    base=M.setup(b);rows=[]
    flags=[48|n for n in range(256)if not n&48]
    for slot,p in itertools.product([0,2],flags):
        m=T.copy(base);put_owner(m)
        H.put(m,SelectedCharacter=22,CrossoverMenuIndex=slot,FmAlts=0,RdVariant=0,MarioVariant=0)
        m.writes.clear();c,low=H.invoke(m,'MenuResolveCharacter',p=p)
        assert H.get(m,'SelectedCharacter')==slot
        assert H.get(m,'SmFreezeLastBlue')==0 and H.get(m,'SmFreezeRenderState')==0
        assert packet(m)==[63,21,3,*native_colors(2),0]
        assert all(m[512+4*i]==248 for i in range(64))
        rows.append(dict(slot=slot,flags=p,minimum_SP=low,CPU=c.processorCycles,**event_order(m)))
    return dict(cases=len(rows),rows=rows,actual_MenuResolve_ArGenResolve_FmResolve_chain=True)

def complete_menu(b):
    base=M.setup(b);rows=[]
    # These declared prior-owner contexts exercise natural controller delivery
    # through GameLoop. No installed FF frontend/readiness claim is made.
    for index,full in itertools.product([1,3,21],[0,1]):
        m=T.copy(base);put_owner(m);Q.queue(m,full)
        H.put(m,SelectedCharacter=22,CrossoverMenuIndex=index,CrossoverMenuState=2,
            CrossoverMenuButtons=0,SavedJoypad1Bits=2,SavedJoypad2Bits=0,OperMode=0,OperMode_Task=3,NmiDisable=0)
        m.writes.clear();entries=[]
        def hook(mem,c,i):
            if c.pc==address(b,'MenuResolveCharacter')and mem.rawtags[1]==194:
                entries.append([i,H.get(mem,'NmiDisable'),H.get(mem,'SelectedCharacter')])
        c,low=M.invoke_main(m,hook)
        assert len(entries)==1 and entries[0][1:]==[255,22]
        assert H.get(m,'SelectedCharacter')==[0,2,21][[1,3,21].index(index)]
        assert H.get(m,'NmiDisable')==0 and H.get(m,'SmFreezeLastBlue')==0
        order=event_order(m)
        # A full queue can defer the new preview, but no old FF part survives.
        reference=T.copy(m);H.put(reference,SmFreezePalettePending=0);Q.consume(reference,0)
        r=Q.consume(m,0)
        assert r['P1']==native_colors(2) and r['pending']==0
        assert list(m.vram[0x3f19:0x3f20])==list(reference.vram[0x3f19:0x3f20])
        rows.append(dict(initial_cursor=index,full_queue=full,CPU=c.processorCycles,minimum_SP=low,
            actual_busy_MenuResolve_ingress=entries,**order,native_NMI=r))
    return dict(cases=len(rows),rows=rows,actual_GameLoop_controller_menu_PauseSkip_publication=True)

def scenes(old,new):
    bases=[M.setup(b)for b in[old,new]];rows=[]
    for selected,kind,area in itertools.product([0,2,22],['warm','life','newgame','cold'],range(4)):
        memories=[T.copy(s)for s in bases];results=[]
        for m in memories:
            put_owner(m,owner=1 if selected==22 else 129)
            H.put(m,SelectedCharacter=selected,AreaType=area,SmFreezeRenderState=1 if selected==22 else 0,
                Mirror_PPUMASK=0,DisableScreenFlag=1,ScreenRoutineTask=0,NmiDisable=255)
            if kind=='cold':m.ram[3][0x1fe0]=0
            if kind=='life':H.put(m,NumberofLives=1)
            if kind=='newgame':H.invoke(m,'InventoryInit')
            m.writes.clear();c,low=H.invoke(m,'InitScreen');results.append((c,low))
        a,z=memories;(c,lo),(d,lz)=results
        assert(c.a,c.x,c.y,c.p,c.sp)==(d.a,d.x,d.y,d.p,d.sp)
        # Full original FF source and persistent gear remain independent of
        # the palette protocol, including genuine life/newgame/area effects.
        assert bytes(a[0x5c00:0x5c80])==bytes(z[0x5c00:0x5c80])
        assert bytes(a[0x5fc1:0x5fd0])==bytes(z[0x5fc1:0x5fd0])
        if selected==22:
            assert H.get(z,'SmFreezeLastBlue')==128 and H.get(z,'SmFreezeRenderState')==0
            assert packet(z)==[63,21,3,*native_colors(area+1),0]
            writes=z.writes;owner=address(new,'SmFreezeLastBlue');pending=address(new,'SmFreezePalettePending')
            pub=[i for i,(at,v)in enumerate(writes)if at==owner and v==128]
            ready=[i for i,(at,v)in enumerate(writes)if at==pending and v==128]
            assert len(pub)==1 and ready[-1]<pub[0]
        else:assert H.get(z,'SmFreezeLastBlue')==0
        rows.append(dict(selected=selected,event=kind,area=area,old_CPU=c.processorCycles,new_CPU=d.processorCycles,
            new_minimum_SP=lz,original_FF_state_exact=True,palette_owner=H.get(z,'SmFreezeLastBlue')))
    return dict(cases=len(rows),rows=rows,actual_InitScreen_ArGenSceneInit_FwSceneInit_chain=True,
        old_Samus_state_cleared_before_FF_owner_valid_last=True)

def full_queue_and_abandon(b):
    base=M.setup(b);rows=[]
    for selected,full,lag,cold in itertools.product([0,2],[0,1],[0,255],[0,1]):
        m=T.copy(base);put_owner(m);Q.queue(m,full)
        if cold:m.ram[3][0x1fe0]=0
        H.put(m,SelectedCharacter=22,CrossoverMenuIndex=selected,FmAlts=0,RdVariant=0,MarioVariant=0)
        H.invoke(m,'MenuResolveCharacter');assert H.get(m,'SmFreezeLastBlue')==0
        r=Q.consume(m,lag)
        if lag:
            assert r['pending']==128 and r['P1']==[22,38,48]
            r2=Q.consume(m,0);assert r2['P1']==native_colors(2)and r2['pending']==0
        else:assert r['P1']==native_colors(2)and r['pending']==0
        rows.append(dict(selected=selected,queue_full=full,lag=lag,cold_code_cookie=cold,**r))
    return dict(cases=len(rows),rows=rows,actual_P1_restored_before_foreign_DMA_with_full_queue=True,
        lag_retains_old_hardware_until_complete_foreign_publication=True)

def main():
    out=O/'lifecycle-controls-v2.json';assert not out.exists()
    proof=dict(passed=False,native=False,admitted=False,scheduler=False,checks={},
        fixture='Declared previous FF palette-owner/color packet states, since no scheduler/readiness producer is installed. Genuine source menu/scene/Main/NMI consumers execute; no PC/callback redirects.')
    try:
        old=H.C.qualified(P/'candidate.nes');new=H.C.qualified(H.O/'candidate.nes')
        for name,fn in [('MenuResolve',lambda:menu(new)),('actual_menu_Main',lambda:complete_menu(new)),
            ('actual_scenes',lambda:scenes(old,new)),('fullqueue_abandon',lambda:full_queue_and_abandon(new))]:
            proof['checks'][name]=fn();print(name,'PASS',flush=True)
        proof['passed']=True
    except Exception as e:proof.update(error=repr(e),traceback=traceback.format_exc())
    files=[Path(__file__),R/'tools/audit/ff_fx_palette_lifecycle_controls_v1.py',O/'lifecycle-negative-v1.json',Path(M.__file__),Path(T.__file__),Path(H.__file__),Path(Q.__file__),Path(V.__file__),
        O/'source-closure.json',P/'candidate.nes',P/'candidate.dbg',H.O/'candidate.nes',H.O/'candidate.dbg']
    proof['bindings']={str(f.resolve()):sha(f)for f in files}
    p=out if proof['passed']else O/'lifecycle-negative-v2.json'
    p.write_text(json.dumps(proof,indent=2)+'\n',newline='\n')
    print(json.dumps(dict(passed=proof['passed'],path=str(p),error=proof.get('error'))),flush=True);assert proof['passed']

if __name__=='__main__':main()
