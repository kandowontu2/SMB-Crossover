"""Source-only visible family tags; exact slow output, original offscreen bytes."""
from pathlib import Path
import difflib,hashlib,json,re,sys
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import prepare_ff_joint_source_v1 as B
from private_build_outputs_v1 import validate
from prepare_ff_current_component_v2 import qualified
from check_tmnt_render_oa import address,location
from prepare_cv3_dmc_mirror import prepare
P=R/'build/ff-fx-epoch-cart-v4';O=R/'build/ff-fx-epoch-fast-v2'

def run(d,cmd,name):
    B.save(d/(name+'-validated-outputs.json'),validate(cmd,O,cwd=R));B.run(d,cmd,name)

def compile(d,n,phase=None):
    cmd=[str(R/'tools/Windows/cc65/bin/ca65.exe'),'-g','--cpu','6502x','-I',str(d),'-I',str(R/'src'),
        '--bin-include-dir',str(d),'--bin-include-dir',str(R),'--create-full-dep',str(d/(n+'.dep')),'-o',str(d/(n+'.o')),str(d/(n+'.s'))]
    run(d,cmd,phase or n+'-build')

def main():
    assert not O.exists()
    files=B.validate(P/'handoff-performance-hold-v1.json','3a2e2299dcda6411c240b2d3cf1f7b889489d5f3bd5f654cb92df5bc17028c75')
    tag=R/'build/ff-fx-epoch-tag-audit-v2/controls.json';proof=json.loads(tag.read_text());assert proof['passed']
    for f,h in proof['bindings'].items():assert B.sha(f)==h,f
    O.mkdir();d=O/'joint';d.mkdir()
    for f in(P/'joint').rglob('*'):
        if f.is_file()and f.suffix in['.s','.inc','.cfg','.chr','.bin']:
            q=d/f.relative_to(P/'joint');q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(f.read_bytes())
    p=d/'ff-epoch-workers.s';old=p.read_text();new=old
    a=''' lda FfMuxBits,y
 ora R3
 sta R3
FfMuxEpochScanNext:'''
    z=''' lda FfMuxBits,y
 ora R3
 sta R3
 ; Source proof: every actual visible admitted part has native bits2/3=0.
 ; Encode family+1 only here, after native source marker/flash consumed them.
 tya
 clc
 adc #1
 asl
 asl
 sta R5
 lda Sprite_Attributes,x
 and #$e3
 ora R5
 sta Sprite_Attributes,x
FfMuxEpochScanNext:'''
    assert new.count(a)==1;new=new.replace(a,z)
    a='''FfMuxEpochPaint:
 jsr FfMuxClassify
 cmp #6
 bcs FfMuxEpochClearTag
 cmp R4'''
    z='''FfMuxEpochPaint:
 ; Unused and clipped parts keep every original offscreen metadata byte.
 lda #$ef
 sta R6
 lda R0
 cmp RgOamUsed
 bcs FfMuxEpochClearTag
 lda Sprite_Y_Position,x
 cmp #240
 bcs FfMuxEpochOriginalPaint
 lda #$e3
 sta R6
 lda Sprite_Attributes,x
 and #$1c
 beq FfMuxEpochClearTag          ; body0 and unrelated nativeP2/P3 unchanged.
 lsr
 lsr
 sec
 sbc #1
 jmp FfMuxEpochHaveFamily
FfMuxEpochOriginalPaint:
 jsr FfMuxClassify               ; rare original clipped/reserved exact path.
 cmp #6
 bcs FfMuxEpochClearTag
FfMuxEpochHaveFamily:
 cmp R4'''
    assert new.count(a)==1;new=new.replace(a,z)
    a='''FfMuxEpochClearTag:
 lda Sprite_Attributes,x
 and #$ef'''
    z='''FfMuxEpochClearTag:
 lda Sprite_Attributes,x
 and R6'''
    assert new.count(a)==1;new=new.replace(a,z)
    a='''FfMuxClassify:
 lda R0
 cmp RgOamUsed
 bcs FfMuxEpochNone
 cmp R2'''
    z='''FfMuxClassify:
 ; Both callers already established logical offset <actualRgOamUsed.
 lda R0
 cmp R2'''
    assert new.count(a)==1;new=new.replace(a,z)
    B.write(p,new)
    p=d/'private.cfg';cfg=p.read_text().replace((P/'joint').as_posix(),d.as_posix())
    needle='FF_EPOCH_HEARTBEAT:load=FF_RAM3_MEM,type=ro,start=$bf9f;';assert cfg.count(needle)==1
    cfg=cfg.replace(needle,'')
    needle='FF_EPOCH_CLASSIFY:load=FF_RAM3_MEM,type=ro,start=$a289;';assert cfg.count(needle)==1
    cfg=cfg.replace(needle,needle+'\nFF_EPOCH_HEARTBEAT:load=FF_RAM3_MEM,type=ro,start=$a2ce;')
    B.write(p,cfg)
    compile(d,'ff-epoch-workers');compile(d,'loader');compile(d,'stream')
    cmd=json.loads((P/'joint/final-link.json').read_text())['command']
    replacements={str(P/'joint'/n):str(d/n)for n in['private.cfg','candidate.nes','candidate.dbg','candidate.lbl','candidate.map','loader.o','stream.o','ff-epoch-workers.o']}
    for a,z in replacements.items():cmd=[v.replace(a,z)for v in cmd]
    run(d,cmd,'layout-link')
    image=(d/'ram3.bin').read_bytes();(d/'ff-stream.bin').write_bytes(image)
    cookie=bytes([167,22,0,8])+hashlib.sha256(image).digest()[:12];(d/'ff-cookie.bin').write_bytes(cookie)
    compile(d,'loader','loader-authenticated-build');compile(d,'stream','stream-authenticated-build')
    run(d,cmd,'final-link');prepare(R,d/'candidate.nes');assert(d/'ram3.bin').read_bytes()==image
    oldb=qualified(P/'joint/candidate.nes');newb=qualified(d/'candidate.nes')
    root=qualified(R/'build/ff-fx-world-marker-proposal-v2/joint/candidate.nes')
    retired=['FwActionTick','FwWeapons','FwEnemyContact','FwForgetEnemy']
    assert not{n:(address(root,n),address(newb,n))for n,v in root['syms'].items()if'seg'in v and n not in retired and address(root,n)!=address(newb,n)}
    assert address(newb,'FfMuxClassify')==0xa289 and address(newb,'FfMuxClassifyEnd')==0xa2ce
    assert address(newb,'FfMuxHeartbeat')==0xa2ce and address(newb,'FfMuxHeartbeatEnd')<=0xa300
    assert address(newb,'FfMuxNativeLate')==0xbecf and address(newb,'FfMuxNativeLateEnd')<=0xbfe0
    prior=(P/'joint/ram3.bin').read_bytes()
    gaps=json.loads((R/'docs/qa/checkpoints/2026-10-30/ff-source-epoch-reservations/receipt.json').read_text())['FF_exclusive_RAM3_code_only']['holes']
    RAMdiff=[i+0xa000 for i,(a,z)in enumerate(zip(prior,image))if a!=z]
    assert all(any(g['start']<=i<g['end']for g in gaps)for i in RAMdiff)
    cs=1048592;romdiff=[i for i,(a,z)in enumerate(zip(oldb['raw'],newb['raw']))if a!=z]
    ranges=[(location(oldb,'FfMuxNativeROM'),location(oldb,'FwProjectileEntry')),
        (location(oldb,'FwCookie'),location(oldb,'FwCookie')+16),(cs+893*1024,cs+901*1024)]
    assert all(any(a<=i<z for a,z in ranges)for i in romdiff)
    B.write(O/'source.patch',''.join(difflib.unified_diff(old.splitlines(True),new.splitlines(True),fromfile='slow/ff-epoch-workers.s',tofile='fast/ff-epoch-workers.s')))
    files|={Path(__file__),tag}|{Path(f)for f in proof['bindings']}|{Path(v)for v in cmd if v.endswith('.o')}|{f for f in O.rglob('*')if f.is_file()}
    B.save(O/'source-closure.json',dict(passed=True,native=False,admitted=False,performance_HOLD=True,
        candidate_sha256=B.sha(d/'candidate.nes'),parent_sha256=B.sha(P/'joint/candidate.nes'),RAM3_sha256=B.sha(d/'ram3.bin'),cookie=list(cookie),
        original_occupied_source_and_public_PCs_exact=True,root_body_world_lease_palette_protocol_exact=True,
        new_main_bytes=address(newb,'FfMuxNativeLateEnd')-address(newb,'FfMuxNativeLate'),
        moved_own_heartbeat=[address(oldb,'FfMuxHeartbeat'),address(newb,'FfMuxHeartbeat')],ROM_changed_bytes=len(romdiff),RAM_changed_bytes=len(RAMdiff),
        limits=['Actual all-case byte-exact slow/fast OAM+source/cookie/NMI/ISR/wholeMain equivalence not yet run.',
                'No native launch/readiness/campaign/cadence or hardware saturation repair.'],
        bindings={str(f.resolve()):B.sha(f)for f in sorted(files)}))
    print(json.dumps(dict(passed=True,ROM=B.sha(d/'candidate.nes'),RAM3=B.sha(d/'ram3.bin'),main=address(newb,'FfMuxNativeLateEnd')-address(newb,'FfMuxNativeLate'))),flush=True)

if __name__=='__main__':main()
