"""Freeze the exact successful cold-controller observation; keep performance hold."""
from pathlib import Path
import csv, hashlib, json

R=Path(__file__).resolve().parents[2]
O=R/'build/current-character-quick-cold-v12'
N=O/'native/cold-menu-game-v3'
F=O/'native-qualified-physical-v3'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def verify(p):
 d=json.loads(p.read_text())
 for name,value in d.get('bindings',{}).items():assert sha(name)==value,name
 return d
def main():
 assert not F.exists()
 source=verify(O/'handoff.json')
 prepared=verify(O/'native-physical-guard-v3b/prepared.json')
 for p in ['native-preflight.json','native-postflight.json']:
  d=json.loads((O/'native-physical-guard-v3b'/p).read_text());assert d.get('passed',d.get('status','')) not in [False,'FAIL'],p
 result=json.loads((N/'result.json').read_text());assert result['passed'] and result['native']
 profile=json.loads((N/'profile-summary.json').read_text());assert profile['passed']
 rows=list(csv.DictReader((N/'profile-frames.csv').open()))
 ui=sum(int(x['Ui'])for x in rows)
 assert ui==0,'Preserve the genuine missing UI consumer'
 game=list(csv.DictReader((N/'frames.csv').open()))
 game=[x for x in game if x['phase']=='game']
 assert game
 main=profile['aggregate']['GameLoop']
 report=dict(status='NATIVE_COLD_SMOKE_PASS_PERFORMANCE_AND_UI_HOLD',candidate=source['candidate'],native=True,installed=False,
  result=result,gameplay=dict(physical_frames=220,source_ticks=result['source_ticks'],
   NmiSkipped_first=int(game[0]['NmiSkipped']),NmiSkipped_last=int(game[-1]['NmiSkipped']),
   profile_Main_calls=main['calls'],profile_Main_foreground_mean=main['inclusive']/main['calls'],
   profile_Main_foreground_max=main['max'],profile_QhUi_calls=ui),
  limits=['No full 1-1/earned-powerup/CX-audio/all-abilities/admission or 60Hz claim.',
   'Real native QhUi coverage is zero; inherited BUSTER HUD remains an integration defect.',
   'Cold loader elapsed is excluded from gameplay cost claims; gameplay lag remains severe.',
   'Native v1/v2 failures and physical-map observer correction remain immutable.'],
  bindings={str(p.resolve()):sha(p)for p in [Path(__file__),O/'handoff.json',O/'native-prepared.json',O/'native-physical-guard-v3b/prepared.json',O/'native-physical-guard-v3b/native-ready.json',O/'native-physical-guard-v3b/native-preflight.json',O/'native-physical-guard-v3b/native-postflight.json']+list(N.iterdir())if p.is_file()})
 F.mkdir();(F/'handoff.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps(dict(path=str(F/'handoff.json'),sha256=sha(F/'handoff.json'),bindings=len(report['bindings']),gameplay=report['gameplay'])))
if __name__=='__main__':main()
