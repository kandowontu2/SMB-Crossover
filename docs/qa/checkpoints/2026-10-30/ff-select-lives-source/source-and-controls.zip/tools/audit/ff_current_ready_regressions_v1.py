"""Current-parent FF readiness, foreign and native-vector source consumers."""
from pathlib import Path
import itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import ff_current_ready_cold_controls_v2 as C
import ff_fx_epoch_pre0_vectors_v2 as W
import ff_fx_palette_preflush_vectors_v2 as P
from check_tmnt_render_oa import address
H,E,T,L=C.H,C.E,C.T,C.L;N=C.N;H.O=N/'joint'
COUNTS=[5,2,2,2,2,4,2,2,2,3,3,2,2,2,3,1,2,4,4,2,2,4,1,1,4,1,2,1,6,2,4,1]
RAW=[0,1,2,3,4,5,6,7,12,9,10,11,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32]


def pending(slot,variant):
    return(slot in[7,11]and variant==1)or(slot==10 and variant in[1,2])or slot in[24,26,28,29,30]


def profiles(b):
    rows=[]
    for slot,count in enumerate(COUNTS):
        m=C.fresh(b,0);H.put(m,CrossoverMenuIndex=slot,SelectedCharacter=0,FmAlts=0,FmGroups=0)
        C.invoke(m,'MenuResolveCharacter');C.invoke(m,'QueueSelection')
        for variant in range(count):
            if variant:
                # Actual release and new Select press, never forced alternate
                # writes. Each queue is naturally consumed by real normalNMI.
                H.put(m,SavedJoypad1Bits=0,SavedJoypad2Bits=0);C.invoke(m,'CrossoverMenuInput');C.A.consume(m)
                H.put(m,SavedJoypad1Bits=32,SavedJoypad2Bits=0);C.invoke(m,'CrossoverMenuInput')
            c,_=H.invoke(m,'FmPending')
            is_pending=bool(c.p&1);assert is_pending==pending(slot,variant),(slot,variant,is_pending)
            want=0 if is_pending else(8 if slot==0 and variant==1 else RAW[slot])
            assert H.get(m,'SelectedCharacter')==want,(slot,variant,want,H.get(m,'SelectedCharacter'))
            result=C.A.consume(m)
            visible=[list(m[512+i:516+i])for i in range(0,256,4)if m[512+i]<240]
            rows.append(dict(slot=slot,variant=variant,pending=is_pending,selected=want,
                pending_or_name_index=c.a,name=list(m.vram[0x2328:0x2338]),visible_OAM=visible,
                current_CHR=m.chr_latches[:],normal_NMI=result))
        H.put(m,SavedJoypad1Bits=0,SavedJoypad2Bits=0);C.invoke(m,'CrossoverMenuInput');C.A.consume(m)
        H.put(m,SavedJoypad1Bits=32,SavedJoypad2Bits=0);C.invoke(m,'CrossoverMenuInput')
        c,_=H.invoke(m,'FmPending')
        assert bool(c.p&1)==pending(slot,0)and H.get(m,'SelectedCharacter')==RAW[slot],('actual Select wrap',slot)
    assert len(rows)==80 and sum(not r['pending']for r in rows)==58
    return dict(cases=len(rows),ready_profiles=58,pending_profiles=22,rows=rows,
        all_alternates_cycled_by_actual_Select_with_release=True)


def main():
    p=dict(passed=False,native=False,admitted=False,installed=False,checks={})
    try:
        old=H.C.qualified(R/'build/current-character-quick-ui-v13/joint/candidate.nes')
        new=H.C.qualified(N/'joint/candidate.nes')
        for name,fn in [('all80_actual_menu_profiles',lambda:profiles(new)),
            ('foreign_DrawAll',lambda:W.foreign(old,new)),
            ('foreign_native_vectors',lambda:P.foreign(old,new)),
            ('current_worker_Main_vectors',lambda:W.vectors(new))]:
            p['checks'][name]=fn();print(name,'PASS',flush=True)
        p['passed']=True
    except Exception as e:p.update(error=repr(e),traceback=traceback.format_exc())
    files=[Path(__file__),Path(C.__file__),Path(W.__file__),Path(P.__file__),Path(H.__file__),N/'source-closure.json',
        N/'cold-controls-v2.json',N/'joint/candidate.nes',N/'joint/candidate.dbg',
        R/'build/current-character-quick-ui-v13/handoff.json']
    p['bindings']={str(f.resolve()):L.sha(f)for f in files}
    out=N/('regression-controls-v1.json'if p['passed']else'regression-negative-v1.json');assert not out.exists()
    out.write_text(json.dumps(p,indent=2)+'\n',encoding='utf-8',newline='\n')
    print(json.dumps(dict(passed=p['passed'],path=str(out),error=p.get('error'))),flush=True);assert p['passed']


if __name__=='__main__':main()
