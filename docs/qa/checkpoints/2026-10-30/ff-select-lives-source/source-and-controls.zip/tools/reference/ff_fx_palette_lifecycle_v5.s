; Private lifecycle only: no FX scheduler, recoloring or readiness change.
; This is genuine physical93 A-view code; shared SFC maps A93 while leaving
; the caller's C context intact. All native packet consumers remain unchanged.
.setcpu "6502"
.import ArGenResolve,FwRetire,SelectedCharacter,AreaType,MoveAllSpritesOffscreen
.import FarCallCommon,SafecallA_SMC,FarcallJmpTarget_SMC
.import SmFreezePalettePacket,SmFreezePalettePending,SmFreezePaletteControl
.import SmFreezeLastBlue,SmFreezeTurn,SmFreezeRenderState
.export FwMuxMenuA,FwMuxSceneA,FwMuxProtocolEnd
.segment "FF_FX_PROTOCOL_A"
.macro MP_FAR target,tail
 sta SafecallA_SMC+1
 lda #<target
 sta FarcallJmpTarget_SMC+1
 lda #>target
 sta FarcallJmpTarget_SMC+2
 lda #.lobyte(.bank(target)|$80)
 .if .xmatch({tail},{jmp})
 jmp FarCallCommon
 .else
 jsr FarCallCommon
 .endif
.endmacro
.macro MP_SAVE
 php
 pha
 txa
 pha
 tya
 pha
.endmacro
.macro MP_RESTORE
 pla
 tay
 pla
 tax
 pla
 plp
.endmacro

FwMuxMenuA:
 MP_SAVE
 jsr Retire
 MP_RESTORE
 ; Actual current owner chain retires Arthur before genuine FmResolve.
 MP_FAR ArGenResolve,jmp

FwMuxSceneA:
 MP_SAVE
 MP_FAR FwRetire,jsr
 lda SelectedCharacter
 cmp #22
 bne SceneForeign
 ; Actual InitScreen has moved every sprite offscreen and owns the forced-
 ; blank/foreground publication. Retire old Samus or FF pending data FIRST.
 lda #0
 sta SmFreezePalettePending
 sta SmFreezeLastBlue
 sta SmFreezeRenderState
 sta SmFreezeTurn
 ; Scene restoration follows the real new AreaType, not an old Bowser latch.
 jsr UseArea
 lda #$80                    ; palette-owner validity published LAST.
 sta SmFreezeLastBlue
 bne SceneDone ; LDA #$80 above guarantees nonzero; original P restored.
SceneForeign:
 jsr Retire
SceneDone:
 MP_RESTORE
 rts

Retire:
 lda SmFreezeLastBlue
 bpl NoOwner
 ; Marker highbit is exclusive FF palette ownership; Samus writes only0/1.
 lda #0
 sta SmFreezePalettePending
 sta SmFreezeLastBlue
 sta SmFreezeTurn
 sta SmFreezeRenderState
 ; A full menu queue may defer replacement preview OAM. Retire every old
 ; FF part through the genuine native clear before restoring native P1.
 MP_FAR MoveAllSpritesOffscreen,jsr
 ldx SmFreezePaletteControl
 cpx #1
 bcc UseArea
 cpx #5
 bcc NativePacket
 cpx #8
 bne UseArea
 ldx #2 ; exact Bowser vector aliases native ground row2.
 bne NativePacket
UseArea:
 ldx AreaType
 cpx #4
 bcc :+
 ldx #1
:inx
 bne NativePacket
NoOwner:rts

NativePacket:
 lda #$3f
 sta SmFreezePalettePacket
 lda #$15
 sta SmFreezePalettePacket+1
 lda #3
 sta SmFreezePalettePacket+2
 lda Native1,x
 sta SmFreezePalettePacket+3
 lda Native2,x
 sta SmFreezePalettePacket+4
 lda Native3,x
 sta SmFreezePalettePacket+5
 lda #0
 sta SmFreezePalettePacket+6
 lda #$c0                    ; complete PRE-native P1 restore, published LAST.
 sta SmFreezePalettePending
 rts
; Exact literal vectors of actual SamusFreezeRenderFinish, excluding row0
; as an accepted selection (row0 is Samus's private blue lease).
; Accepted indices1..4; row8 is losslessly canonicalized to2 above.
Native1=*-1
 .byte $10,$1a,$1c,$1c
Native2=*-1
 .byte $30,$30,$36,$36
Native3=*-1
 .byte $27,$27,$17,$17
FwMuxProtocolEnd:
.assert FwMuxProtocolEnd-FwMuxMenuA<=465,error,"Owned FF ART tail"
