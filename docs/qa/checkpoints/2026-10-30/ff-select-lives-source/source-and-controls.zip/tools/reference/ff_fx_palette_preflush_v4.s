; Fixed native P1 restore, before the complete original PN/native/Ar chain.
; UpdateScreen's MMC5 copy loop is in C116: it cannot be near-called from
; this C93 worker. This fixed literal transfer preserves its exact PPU order,
; increment-one control and zero-scroll footer without borrowing NmiR0/1.
.setcpu "6502"
.import SmFreezePalettePacket,SmFreezePalettePending,Mirror_PPUCTRL
.import PnHudPreUpdateScreen,ArNmiPhysicalCWrite
.export FwPalettePreflush,FwPalettePreflushEnd
.segment "FF_FX_PREFLUSH_C"
FwPalettePreflush:
 php
 lda SmFreezePalettePending
 cmp #$c0
 bne Continue
 ; C0 is published only after the complete producer packet. Invalidate
 ; first; reject malformed headers rather than executing an arbitrary queue.
 lda #0
 sta SmFreezePalettePending
 lda SmFreezePalettePacket
 cmp #$3f
 bne Continue
 lda SmFreezePalettePacket+1
 cmp #$15
 bne Continue
 lda SmFreezePalettePacket+2
 cmp #3
 bne Continue
 lda SmFreezePalettePacket+6
 bne Continue
 lda $2002
 lda #$3f
 sta $2006
 lda #$15
 sta $2006
 lda Mirror_PPUCTRL
 and #$fb
 sta $2000
 sta Mirror_PPUCTRL
 lda SmFreezePalettePacket+3
 sta $2007
 lda SmFreezePalettePacket+4
 sta $2007
 lda SmFreezePalettePacket+5
 sta $2007
 lda $2002 ; actual native next-command latch reset, before terminator0/footer.
 lda #0
 sta $2005
 sta $2005
Continue:
 plp
 ; Never switch out the currently executing C worker. The resident STA/RTS
 ; enters the genuine original continuation with original X/Y/P and A=$f4.
 lda #>(PnHudPreUpdateScreen-1)
 pha
 lda #<(PnHudPreUpdateScreen-1)
 pha
 lda #.lobyte(.bank(PnHudPreUpdateScreen)|$80)
 jmp ArNmiPhysicalCWrite
FwPalettePreflushEnd:
.assert FwPalettePreflushEnd-FwPalettePreflush<=220,error,"Remaining own FF ART tail"
