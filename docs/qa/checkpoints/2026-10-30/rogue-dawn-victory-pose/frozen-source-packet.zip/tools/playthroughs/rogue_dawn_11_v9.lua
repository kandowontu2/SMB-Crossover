-- Native landing state can become0 while the source is still finishing its
-- falling action. Wait for actual source jump admission and a consumed
-- release; only move across the gap after real negative-VY ascent begins.
local root=assert(ROSTER_CONFIG.out:match('^(.*)/build/'))
local base=assert(dofile(root..'/tools/playthroughs/rogue_dawn_11_v7.lua'))
local stairs={{begin=2080,peak=2192,edge=2208,far=2240,finish=2304},
 {begin=2336,peak=2432,edge=2448,far=2480,finish=2544}}
local phase,which,count='climb',1,0
return function(c)
 if c.world~=0 or c.level~=0 then return base(c) end
 local s=stairs[which]
 if s and c.x>=s.finish then which=which+1;phase='climb';s=stairs[which] end
 if s and c.x>=s.begin and c.x<s.finish then
  local t=c.block(s.edge+8,145)
  local nativeTop=c.block(s.peak+8,145)==0x61
   and c.block(s.far+8,145)==0x61 and(t==0 or t==0x23 or t==0x26)
  if nativeTop then
   local action,vy,gravity=c.r('RdAction'),c.r('RdVY'),c.r('RdGravity')
   if phase=='climb' and c.x>=s.peak and c.y<=112 and c.yHigh==1 then phase='land' end
   local b
   if phase=='land' then
    b={right=c.x<s.peak+2,left=c.x>s.peak+4}
    if c.grounded and c.y<=114 and c.yHigh==1 and vy==0 and gravity==0
     and(action==0 or action==1 or action==4)and(c.r('RdHeld')&128)==0 then
     phase='launch';b={a=true}
    end
   elseif phase=='launch' then
    b={a=true}
    if vy>=128 then phase='cross';b={right=true,a=true}
    elseif(c.r('RdHeld')&128)~=0 then phase='land';b={} end
   elseif phase=='cross' then b={right=true,a=true} end
   if b then
    if count<64 and c.poll%8==0 then
     count=count+1
     return b,{stair=which,phase=phase,x=c.x,y=c.y,yHigh=c.yHigh,action=action,VY=vy,
      gravity=gravity,held=c.r('RdHeld'),fresh=c.r('RdFresh'),nativeState=c.state}
    end
    return b
   end
  end
 end
 return base(c)
end
