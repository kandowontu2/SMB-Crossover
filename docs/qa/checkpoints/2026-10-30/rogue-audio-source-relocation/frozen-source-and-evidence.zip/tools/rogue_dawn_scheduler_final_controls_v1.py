"""Fresh actual v4 execution of unchanged request/stack CPU campaigns."""
from pathlib import Path
import sys
R=Path(__file__).resolve().parents[1];sys.path[:0]=[str(R/'tools'),str(R/'tools/audit')]
import rogue_dawn_scheduler_controls_v3 as driver
import rogue_dawn_scheduler_deep_edges_v1 as deep
O=R/'build/rogue-dawn-scheduler-v4'
if __name__=='__main__':
 driver.O=O;deep.O=O
 driver.main();deep.main()
