"""Actual title Main->menu Start->fresh->mode1/commit instruction cuts."""
from pathlib import Path
import json,sys,traceback
R=Path(__file__).resolve().parents[1];sys.path[:0]=[str(R/'tools'),str(R/'tools/audit')]
import rogue_dawn_scheduler_callers_v1 as c
q=c.q;v=c.v;ref=q.ref;address,location=v.address,v.location;get,put=q.get,q.put;O=R/'build/rogue-dawn-scheduler-v5'

def arena(b):
 m=c.o.setup(b,False);put(m,OperMode=0,OperMode_Task=3,SelectedCharacter=2,RdVariant=1,CrossoverMenuState=2,CrossoverMenuButtons=0,CrossoverContinue=0,SavedJoypad1Bits=16,SavedJoypad2Bits=0,NmiDisable=255);return m

def run(m,cut=None):
 b=m.bundle;cpu=c.NesMPU(memory=m,pc=address(b,'IdleLoop'));cpu.sp=253;cpu.p=0x71;low=253;trace=[];isr=None;modewrites=[]
 for steps in range(500000):
  if cpu.pc==address(b,'IdleLoop')and steps:break
  key=(*q.key(m,cpu),cpu.sp,cpu.x);trace.append((*key,get(m,'OperMode'),m[0x5fb6]))
  if cut and key==cut and isr is None:
   mode=get(m,'OperMode');transport=m[0x5fb6];m.reads.clear();z=q.interrupt(m,cpu,'NMI');low=min(low,z['minimum_SP'])
   count=sum(pc==address(b,'RdaNA770')and bank==97 for pc,bank in z['trace'])
   if mode==0 or transport&1:assert count==0,('partial title source clock',key,mode,transport)
   isr=dict(**q.summary(z),mode_at_entry=mode,transport_at_entry=transport,source_ticks=count)
  before=len(m.writes);at=key;assert m[cpu.pc]!=0;cpu.step();low=min(low,cpu.sp)
  for a,z in m.writes[before:]:
   if a==address(b,'OperMode'):modewrites.append(dict(value=z,writer_PC=hex(at[0]),bank=at[1],SP=at[2],counter_before=trace[-1][-1],counter_after=m[0x5fb6]))
 else:raise AssertionError('title Main timeout')
 assert cpu.sp==253 and(not cut or isr is not None)
 return dict(minimum_SP=low,CPU=cpu.processorCycles,trace=trace,NMI=isr,mode_writes=modewrites,mode=get(m,'OperMode'),task=get(m,'OperMode_Task'),counter=m[0x5fb6],health=[get(m,'RdHealthLo'),get(m,'RdHealthHi')],actual_Main_calls=sum(row[0]==address(b,'GameLoop')and row[1]==126 for row in trace))

def main():
 assert not(O/'title-start.json').exists()
 b=v.scoped_load(O/'candidate.nes');old=v.scoped_load(R/'build/rogue-dawn-scheduler-v4/candidate.nes');proof=dict(passed=False,native_run=False,source_CPU_only=True);checks={}
 try:
  bad=run(arena(old));assert(bad['mode'],bad['counter'])==(1,1)
  good=run(arena(b));assert(good['mode'],good['task'],good['counter'])==(1,0,2)
  checks['preserved_real_title_start_globalclear_counter_negative']=dict(parent=ref.binding(R/'build/rogue-dawn-scheduler-v4/candidate.nes'),mode_writes=bad['mode_writes'],actual_terminal_counter=1,classification='actual compiled complete titleMain source counter fault; no native attempt',repaired_counter=2)
  body=address(b,'RdLifeFresh');pos=location(b,'RdLifeFresh');n=int(b['syms']['RdLifeFresh']['size'],0);data=b['raw'][pos:pos+n];offset=data.index(bytes.fromhex('a9018db65f'));assert data.count(bytes.fromhex('a9018db65f'))==1
  gate=address(b,'RdsMainGate');gateEnd=gate+int(b['syms']['RdsMainGate']['size'],0);clear=address(b,'RdHsEnterScene::ClearActive')
  targets=[]
  for i,row in enumerate(good['trace']):
   pc,bank,sp,x,mode,busy=row
   role=None
   if bank==78 and((pc==0xa00c and x==0xb6)or(pc==0xa00f and x==0xb6)):role='global5Fclear before/after common byte'
   if bank==95 and pc in[body+offset,body+offset+2,body+offset+5]:role='actual owned busy rearm'
   if bank==95 and pc==clear:role='actual partial source constructor'
   if bank==63 and gate<=pc<gateEnd and i>100:role='actual final COMMIT instruction'
   if any(int(z['writer_PC'],16)==pc and z['bank']==bank for z in good['mode_writes']):role='native real mode write'
   if i and any(int(z['writer_PC'],16)==good['trace'][i-1][0]and z['bank']==good['trace'][i-1][1]for z in good['mode_writes']):role='after native real mode write'
   if role:targets.append((role,tuple(row[:4])))
  targets=list(dict.fromkeys(targets));rows=[]
  for role,cut in targets:
   m=arena(b);z=run(m,cut);assert z['mode']==1 and 1<=z['actual_Main_calls']<=2 and z['task']in[0,1]and z['counter']in[0,2,4],(role,cut,z['mode'],z['task'],z['counter'],z['actual_Main_calls'])
   assert z['health']==[0x99,9]
   rows.append(dict(role=role,PC=hex(cut[0]),bank=cut[1],SP=cut[2],X=cut[3],minimum_SP=z['minimum_SP'],terminal_counter=z['counter'],actual_Main_calls=z['actual_Main_calls'],NMI=z['NMI']))
  assert sum(z['role']=='actual partial source constructor'for z in rows)==128
  assert len(good['mode_writes'])==1 and good['mode_writes'][0]['counter_before']==1
  checks['actual_full_title_Main_all_reached_constructor_commit_cuts']=dict(cases=len(rows),mode_writes=good['mode_writes'],rows=rows,source_init_complete_before_mode1=True)
  proof.update(passed=True,checks=checks,minimum_SP=min(z['minimum_SP']for z in rows),bindings=[ref.binding(p)for p in[Path(__file__),O/'candidate.nes',O/'candidate.dbg',O/'candidate.lbl',O/'build.json',R/'tools/rogue_dawn_scheduler_callers_v1.py',R/'tools/rogue_dawn_scheduler_controls_v1.py']],limits=['Actual compiled full Main source arena starts at legally displayed character-select state2 with a real Start bit; not a native coldboot/controller capture.','No original room-script phase1 or full physical NMI timing admission.'])
 except Exception as e:
  proof.update(error=repr(e),traceback=traceback.format_exc(),checks=checks);p=O/'title-start-negative.json';i=2
  while p.exists():p=O/f'title-start-negative-{i}.json';i+=1
  p.write_text(json.dumps(proof,indent=2)+'\n');raise
 (O/'title-start.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(dict(passed=True,actual_full_Main_cuts=len(rows),minimum_SP=proof['minimum_SP'])))
if __name__=='__main__':main()
