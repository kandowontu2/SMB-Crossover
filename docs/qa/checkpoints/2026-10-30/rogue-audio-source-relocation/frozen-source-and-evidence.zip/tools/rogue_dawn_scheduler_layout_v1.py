"""Actual consumed-source/private-tail/depot/optional B600 audit, read-only."""
from pathlib import Path
import json,re,sys
R=Path(__file__).resolve().parents[1];sys.path[:0]=[str(R/'tools'),str(R/'tools/audit')]
import rogue_dawn_scheduler_controls_v3 as c
from prepare_rogue_dawn_host_body_handoff_v1 import dependencies
O=R/'build/rogue-dawn-scheduler-v5';ref=c.ref

def refs(paths,name):
 rows=[]
 for p in dict.fromkeys(paths):
  if p.suffix.lower()not in['.s','.inc']:continue
  for i,line in enumerate(p.read_text().splitlines(),1):
   code=line.split(';',1)[0]
   if re.search(r'\b'+name+r'\b',code):rows.append(dict(path=str(p),line=i,code=code.strip()))
 return rows

def main():
 assert not(O/'layout.json').exists()
 d=json.loads((O/'build.json').read_text())
 for z in d['bindings']:assert ref.binding(z['path'])==z,z['path']
 b=c.scoped_load(O/'candidate.nes');old=c.scoped_load(R/'build/rogue-dawn-live-audio-v1/candidate.nes')
 paths=[Path(z['path'])for z in d['bindings']]
 r=refs(paths,'RgAudioCpuZp');scalar=[]
 for row in r:
  code=row['code']
  z=re.search(r'RgAudioCpuZp\+(\d+)',code)
  if z:scalar.append(int(z[1]))
 assert all(x<=23 or x==155 for x in scalar)
 borrowers=[]
 for name,n in[('RdaBorrow',19),('RdaRelease',19)]:
  at=c.location(b,name);code=b['raw'][at:at+24]
  assert code[:2]==bytes([0xa2,n-1]),(name,code.hex())
  borrowers.append(dict(name=name,index_range=[0,n-1],actual_start=hex(c.address(b,name)),physical_bank=(at-16)//8192,compiled_prefix=code.hex()))
 # Old NativeRosterWrapper variants17/24 and the unrolled CV3 paths have
 # no index/constant beyond23. Frozen SMB2 adapter uses its own<=17 window.
 s2=R/'build/smb2-roster-audio-host-v8';sh=json.loads((s2/'handoff.json').read_text());s2paths=[]
 for z in sh['input_bindings']+sh['output_bindings']:
  p=Path(z['path'])
  if p.suffix.lower()in['.s','.inc']and p.exists():s2paths.append(p)
 s2refs=refs(s2paths,'RgAudioCpuZp')
 for row in s2refs:
  z=re.search(r'RgAudioCpuZp\+(\d+)',row['code'])
  assert not z or int(z[1])<=23,(row,'SMB2 tail consumer')
 assert not any(re.search(r'\bRdaAudioSet(?:Queue|Area|Mode)\b|\bRdaAudioTick\b',z['code'])for z in refs(paths,'RdaAudioTick'))
 retired=[]
 for name,n in[('RdaAudioSetQueue',50),('RdaAudioSetArea',53),('RdaAudioSetMode',44),('RdaAudioTick',64)]:
  assert name not in b['syms']
  assert not refs(paths,name)
  retired.append(dict(original_name=name,old_CPU=hex(c.address(old,name)),bytes=n,actual_new_consumed_source_references=0,scope='Removed private diagnostic APIs, not a native dispatch target.'))
 # All source code/data views stay exact; only the emitted relocated driver
 # operands/helpers change. These immutable depot spans are not regenerated.
 raw=[]
 for g in b['segs'].values():
  name=g['name'].strip('"')
  if name.startswith(('ROGUE_AUDIO_PAGES_','ROGUE_AUDIO_UPPER_RAW_'))or name=='ROGUE_AUDIO_PAGE_MAP':
   start,size=int(g['ooffs'],0),int(g['size'],0)
   assert b['raw'][start:start+size]==old['raw'][start:start+size]
   raw.append(dict(name=name,file_offset=start,bytes=size,sha256=ref.digest(b['raw'][start:start+size])))
 # Read-only future-common reservation assessment: not an allocation.
 audits=[]
 for path in[R/'build/rogue-dawn-live-audio-v1/candidate.nes',O/'candidate.nes',R/'build/smb2-roster-hud-v5/candidate.nes',R/'build/smb2-roster-audio-effects-v6/candidate.nes',R/'build/smb2-roster-palette-lifecycle-v7/candidate.nes',s2/'candidate.nes',R/'build/final-fantasy-component-v1/candidate.nes']:
  dbg=path.with_suffix('.dbg');basis=dbg;component=None
  if dbg.exists():p=c.scoped_load(path)
  else:
   assert path.parent.name=='final-fantasy-component-v1'
   hand=json.loads((path.parent/'handoff.json').read_text());basis=Path(hand['parent']['path']).with_suffix('.dbg');p=c.scoped_load(Path(hand['parent']['path']))
   actual=path.read_bytes();assert actual[16+63*8192:16+64*8192]==p['raw'][16+63*8192:16+64*8192]
   component=ref.binding(path.parent/'component.dbg')
  start=16+63*8192+0x1600;end=start+512;owners=[]
  for g in p['segs'].values():
   if'ooffs'not in g:continue
   a,n=int(g['ooffs'],0),int(g['size'],0)
   if a<end and a+n>start:owners.append(dict(name=g['name'],start=a,size=n))
  assert not owners and p['raw'][start:end]==bytes([255])*512,(str(path),owners)
  audits.append(dict(ROM=ref.binding(path),actual_DBG_owner_basis=ref.binding(basis),standalone_component_DBG=component,all512_FF=True,actual_emitted_DBG_owners=owners,scope='FF standalone sparsecandidate uses authentic parentDBG plus exactentirebank63 equality; no matching wholecandidateDBG fabricated.'if component else'Genuine matching wholecandidateDBG.'))
 # All aliases reused during ReadSave are dead at that exact source phase.
 reuse=dict(RdaSavedC='Saved sourceP only: outer realNMI owns C; old NMI Tick C save removed. Public RdaAudioInit/LowHealth envelopes unchanged.',RdsRngDelta='Counted0..2 RNG loop has completed before first source helper; reused as sourceX.',RdsDacDue='Original initbit duplicate eliminated; postdriver DAC predicate reads identical preserved NeedTheme. Reused as sourceY.',RdaReadValue='Raw reader result temporary replaces its1-byte PHA; shared return then restores P/X/Y and final LDA restores sourceNZ.',nonrecursive='ReadAbsoluteCommon/ReadE6Y/ReadECY invoke only RawReader; RawReader calls no source reader. RdaLoadVolume/AdvanceNote/LoadNoteY have no pending ReadSave when they enter one reader.',actual_differential=c.ref.binding(O/'controls.json'))
 assert b['raw'][16+95*8192+0x1f00:16+95*8192+0x1f32]==old['raw'][16+95*8192+0x1f00:16+95*8192+0x1f32]
 result=dict(passed=True,read_only=True,native_run=False,code=dict(A62_start='BD27',A62_end=hex(c.address(b,'RdaAdapterEnd')),A62_bytes=c.address(b,'RdaAdapterEnd')-0xbd27,A63_common_start='B400',A63_common_end=hex(c.address(b,'RdsCommonEnd')),A63_common_bytes=c.address(b,'RdsCommonEnd')-0xb400,A95_end=hex(c.address(b,'RdCueGateEnd')),death50bytes_BF00_exact=True),private_tail=dict(base='RgAudioCpuZp',address=hex(c.address(b,'RgAudioCpuZp')),existing_size=160,new_NMI_only_backup_offsets=[155,159],absolute=[hex(c.address(b,'RgAudioCpuZp')+155),hex(c.address(b,'RgAudioCpuZp')+159)],explicit_reference_inventory=r,compiled_Rogue_borrowers=borrowers,legacy_maximum_borrow=24,SMB2_frozen_reference_inventory=s2refs,scope='Actual consumed source + compiled borrower prefixes + complete finite Main/driver/mixer/retirement traces. Not arbitrary-RAM/indirect-execution proof.'),retired_APIs=retired,reused_private_fields=reuse,immutable_raw_data_views=raw,future_B600_B800_audit=audits,future_allocation='NO allocation. Nominal SMB2 A63 lease throughB800 still requires ROOT reassignment. These exact seven candidates only; future union must re-audit true owners/aliases.',bindings=[ref.binding(p)for p in[Path(__file__),O/'build.json',O/'candidate.nes',O/'candidate.dbg',s2/'handoff.json']])
 (O/'layout.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(passed=True,A62=result['code']['A62_bytes'],A63=result['code']['A63_common_bytes'],actual_consumed_sources=len(paths),future512B_candidates=len(audits))))
if __name__=='__main__':main()
