"""Actual cold constructor/foreign/oldDMC/boot callers; no native admission."""
from pathlib import Path
import itertools,json,sys,traceback
R=Path(__file__).resolve().parents[1];sys.path[:0]=[str(R/'tools'),str(R/'tools/audit')]
import rogue_dawn_scheduler_ownership_v1 as o
v=o.v;q=v.q;O=o.O;ref=q.ref;put,get=q.put,q.get;address,location=v.address,v.location;NesMPU=v.NesMPU
from sunny_integrated_controls_v1 import app,registers

def ctor(m,cutX=None):
 b=m.bundle;pc=address(b,'NrFreshGameInit');bank=(location(b,'NrFreshGameInit')-16)//8192;m.page(1,bank);put(m,CurrentBank=128|bank)
 c=NesMPU(memory=m,pc=pc);c.sp=224;c.p=0x71;c.stPushWord(0x5aff);low=c.sp;writes=[];seen=False;nmi=None
 target=address(b,'RdHsEnterScene::ClearActive')
 for _ in range(100000):
  if c.pc==0x5b00:break
  if q.key(m,c)==(target,95):
   writes.append(c.x)
   if c.x==cutX:
    seen=True;m.reads.clear();nmi=q.interrupt(m,c,'NMI');low=min(low,nmi['minimum_SP'])
    assert not m.reads&set(range(address(b,'RgAudioRam'),address(b,'RgAudioRam')+512)),('cold cache read',c.x)
    assert get(m,'GuestAudioCharacter')!=130
  assert m[c.pc]!=0,('constructor BRK',q.key(m,c));c.step();low=min(low,c.sp)
 assert c.pc==0x5b00 and c.sp==224 and(cutX is None or seen)
 return dict(CPU=c.processorCycles,minimum_SP=low,clear_indices=writes,NMI=q.summary(nmi)if nmi else None)

def e_nmi(m):
 b=m.bundle;c=NesMPU(memory=m,pc=0x5b00);c.sp=253;c.p=0x71
 before=(q.cpu_state(c),q.physical(m),q.image(m),bytes(m[:256]));low=c.sp;c.nmi();trace=[]
 for _ in range(100000):
  if c.pc==before[0][0]and c.sp==before[0][5]:break
  trace.append((*q.key(m,c),c.sp));assert m[c.pc]!=0;c.step();low=min(low,c.sp)
 else:raise AssertionError('retirement NMI timeout')
 after=(q.cpu_state(c),q.physical(m),q.image(m),bytes(m[:256]))
 assert after[0]==before[0]and after[1][0][:3]==before[1][0][:3]and after[1][1:]==before[1][1:]and after[2:]==before[2:]
 return dict(CPU=c.processorCycles,minimum_SP=low,entry_E=before[1][0][3],exit_E=m.banks[3],trace=trace)

def main():
 assert not(O/'callers.json').exists()
 b=v.scoped_load(O/'candidate.nes');old=v.scoped_load(R/'build/rogue-dawn-live-audio-v1/candidate.nes');checks={};proof=dict(passed=False,native_run=False,source_CPU_only=True,checks=checks)
 try:
  rows=[]
  for x in range(128):
   m=o.setup(b,False);put(m,SelectedCharacter=2,OperMode=0);o.gate(m,True)
   z=ctor(m,x);assert z['clear_indices']==list(range(127,-1,-1))
   assert get(m,'RdHealthLo')==0x99 and get(m,'RdHealthHi')==9
   assert m[0x5fb6]==1 and get(m,'GuestAudioCharacter')!=130
   put(m,OperMode=1);o.gate(m,False);r=v.nmi(m);assert get(m,'GuestAudioCharacter')==130 and m[0x5fb6]==0
   rows.append(dict(actual_clear_X=x,minimum_SP=z['minimum_SP'],cold_busy_NMI=z['NMI'],first_stable_RNG_calls=sum(pc==address(b,'RdaOriginalRng')and bank==97 for pc,bank,sp in r['trace'])))
  checks['genuine_NrFreshGameInit_all128_partial_constructor_cuts']=rows
  print('128 genuine partial constructor cuts PASS',flush=True)
  # Actual reset input-A contract: run the full real mapper initializer and
  # existing reset farcall bytes through their genuine continuation.
  # At the first source helper all incoming A is overwritten by real LDA0.
  boot=[]
  for val in[0,0x5a,255]:
   pair=[]
   for bundle in[old,b]:
    m=q.make(bundle);put(m,SelectedCharacter=0);m[0x5fb6]=0x7d
    end=address(bundle,'Start::FinializeMarioInit');pc=end-18
    c=NesMPU(memory=m,pc=pc);c.sp=255;c.a=val;c.x=13;c.y=87;c.p=0x71;low=c.sp
    for _ in range(100000):
     if c.pc==end:break
     assert m[c.pc]!=0,('Reset initializer BRK',q.key(m,c));c.step();low=min(low,c.sp)
    assert c.pc==end and c.sp==255
    z=dict(CPU=c.processorCycles,minimum_SP=low)
    class Q:pass
    a=Q();a.b=bundle;a.m=m
    # New owned common transport initialization is the sole intended newRAM.
    pair.append((registers(c),app(a,skip=[0x5fb6]),q.physical(m),m[0x5fb6],z['CPU']))
   assert pair[0][:3]==pair[1][:3],('boot caller ABI',val,pair[0][:3],pair[1][:3])
   assert pair[1][3]==0
   boot.append(dict(input_A=val,old_CPU=pair[0][4],new_CPU=pair[1][4],AXYP_applicationRAM_exact_except_transport=True))
  checks['real_CrossoverInit_complete_caller_boot_contract']=boot
  # Existing ordinary guest drivers and fullMain remain untouched; coldgate
  # adds measured CPU but never reads/writes Rogue source state.
  foreign=[]
  for char,mode in itertools.product(range(24),[0,1]):
   pair=[]
   for bundle in[old,b]:
    m=q.make(bundle,mode);put(m,SelectedCharacter=char,RdVariant=0,SavedJoypadBits=1)
    c,z=q.mainstep(m);nm=q.wake(m)
    class Q:pass
    a=Q();a.b=bundle;a.m=m
    pair.append((registers(c),app(a,skip=[0x5fb6]),q.physical(m),z['CPU'],nm['CPU']))
   assert pair[0][:3]==pair[1][:3],('foreign completeMain+NMI',char,mode)
   foreign.append(dict(character=char,mode=mode,Main_CPU_delta=pair[1][3]-pair[0][3],NMI_CPU_delta=pair[1][4]-pair[0][4]))
  checks['48_foreign_complete_Main_and_regular_NMI']=foreign
  print('48 complete foreign Main/NMI PASS',flush=True)
  # Actual initialized pre-existing CV3 DMC lease uses genuineE125 clone.
  # Stop/reset is a real owner consumer; E125->127 is the intended handoff.
  m=q.make(b);put(m,GuestAudioCharacter=14,RgAudioCharacter=14,BassDmcActive=3,Cv3DmcPriority=2,NmiDisable=255)
  m.page(3,125);z=e_nmi(m)
  assert get(m,'GuestAudioCharacter')==130 and get(m,'BassDmcActive')==0 and m.banks[3]==127
  checks['genuine_old_DMC_E125_acquire']=dict(**{k:z[k]for k in z if k!='trace'},terminal_DMC_owner=get(m,'BassDmcActive'),Rogue_driver_ticks=sum(pc==address(b,'RdaNA770')and bank==97 for pc,bank,sp in z['trace']))
  # Request a real native world effect and verify separate MMC5 routing.
  m=o.setup(b);v.nmi(m);put(m,Square1SoundQueue=2,Square2SoundQueue=1,NoiseSoundQueue=1,NmiDisable=255)
  z=v.nmi(m);hw=[(at,val)for at,val in z['writes']if 0x4000<=at<=0x4017 or 0x5000<=at<=0x5015]
  assert any(0x5000<=a<=0x5007 for a,vv in hw)and any(a==0x400c for a,vv in hw)
  assert get(m,'Square1SoundQueue')==get(m,'Square2SoundQueue')==get(m,'NoiseSoundQueue')==0
  checks['actual_native_world_sfx_mixer_hardware']=dict(CPU=z['CPU'],minimum_SP=z['minimum_SP'],ordered_actual_APU_MMC5_writes=hw,source4017_writes=[vv for a,vv in hw if a==0x4017],source_no_DMC=True)
  proof.update(passed=True,bindings=[ref.binding(p)for p in[Path(__file__),O/'candidate.nes',O/'candidate.dbg',O/'candidate.lbl',O/'build.json',R/'tools/rogue_dawn_scheduler_ownership_v1.py',R/'tools/rogue_dawn_scheduler_controls_v3.py',R/'tools/rogue_dawn_scheduler_controls_v1.py']],limits=['No native/controller/audio-listening or fullPPU deadline claim.','SMB2old-owner25/119/120 requires the separately frozen adapter and future ROOT union; this standalone parent has only genuine CV3E125 clone.'])
 except Exception as e:
  proof.update(error=repr(e),traceback=traceback.format_exc());p=O/'callers-negative-1.json';i=2
  while p.exists():p=O/f'callers-negative-{i}.json';i+=1
  p.write_text(json.dumps(proof,indent=2)+'\n');raise
 (O/'callers.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(dict(passed=True,constructor_cuts=128,foreign_Main_NMI=48)))
if __name__=='__main__':main()
