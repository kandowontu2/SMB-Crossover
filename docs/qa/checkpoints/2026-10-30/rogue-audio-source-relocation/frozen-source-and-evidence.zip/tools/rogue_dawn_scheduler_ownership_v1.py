"""Counter instruction cuts, cold/retire/pause/SoundTest; private CPU only."""
from pathlib import Path
import itertools,json,sys,traceback
R=Path(__file__).resolve().parents[1];sys.path[:0]=[str(R/'tools'),str(R/'tools/audit')]
import rogue_dawn_scheduler_controls_v3 as v
q=v.q;O=R/'build/rogue-dawn-scheduler-v4';ref=q.ref;put,get=q.put,q.get;address,location=v.address,v.location

def setup(b,active=True,count=0):
 m=v.prepared(b,1);v.nmi(m)
 if not active:put(m,SelectedCharacter=0);v.nmi(m)
 m[0x5fb6]=count*2;put(m,NmiDisable=255)
 return m

def gate(m,begin,cut=None):
 return q.invoke(m,'PauseRoutine',a=255 if begin else 0,p=0xb1 if begin else 0x33,sp=224,cut=cut)

def main():
 assert not(O/'ownership.json').exists()
 b=v.scoped_load(O/'candidate.nes');checks={};proof=dict(passed=False,native_run=False,source_CPU_only=True,checks=checks)
 try:
  rows=[];gatepc=address(b,'RdsMainGate');gatesize=int(b['syms']['RdsMainGate']['size'],0)
  for before,after,count in itertools.product([False,True],[False,True],[0,1]):
   for phase in['BEGIN','COMMIT']:
    m=setup(b,before,count)
    if phase=='COMMIT':gate(m,True);put(m,SelectedCharacter=2 if after else 0)
    c,z=gate(m,phase=='BEGIN')
    # All actual instruction boundaries in the admitted gate, not only its
    # writes. The completed-context discriminator remains a real callee.
    cuts=list(dict.fromkeys((pc,bank)for pc,bank,sp in z['trace']if bank==63 and gatepc<=pc<gatepc+gatesize))
    for pc,bank in cuts:
     m=setup(b,before,count)
     if phase=='COMMIT':gate(m,True);put(m,SelectedCharacter=2 if after else 0)
     c,z=gate(m,phase=='BEGIN',(pc,bank,'NMI'))
     if phase=='BEGIN':put(m,SelectedCharacter=2 if after else 0);gate(m,False)
     r=v.nmi(m)
     assert m[0x5fb6]==0
     rng=sum(pc==address(b,'RdaOriginalRng')and bank==97 for pc,bank,sp in r['trace'])
     # A foreign retirement must leave nothing to replay on a fresh seed.
     if not after:
      put(m,SelectedCharacter=2);re=v.nmi(m)
      assert not any(pc==address(b,'RdaOriginalRng')and bank==97 for pc,bank,sp in re['trace'])
     rows.append(dict(began_Rogue=before,ended_Rogue=after,pending_completed=count,phase=phase,cut_PC=hex(pc),bank=bank,minimum_SP=z['minimum_SP'],final_transport=0,following_rng=rng,retired_reacquire_no_old_rng=not after))
  checks['all_actual_BEGIN_COMMIT_instruction_cuts']=dict(cases=len(rows),rows=rows)
  print('all BEGIN/COMMIT instruction cuts pass',flush=True)
  # Actual NMI mask cannot be interrupted by Main; genuine IRQ can cut each
  # mask instruction and must preserve the live accumulator/flags exactly.
  m=setup(b,False);put(m,NmiDisable=255);r=v.nmi(m)
  code=(R/'src/rogue_dawn_audio_scheduler_hooks_v4.s').read_text();assert 'and #1\n sta RdsCommit             ; retire' in code
  target=[]
  for pc,bank,sp in r['trace']:
   if bank==63 and bytes(m.bundle['raw'][16+63*8192+(pc&8191):16+63*8192+(pc&8191)+3])==bytes.fromhex('adb65f'):target.append(pc)
  assert target
  mask=target[0];assert b['raw'][16+63*8192+(mask&8191):16+63*8192+(mask&8191)+8]==bytes.fromhex('adb65f29018db65f')
  masks=[]
  for value,pc in itertools.product([0,1,2,3,4,5],[mask,mask+3,mask+5]):
   m=setup(b,False);m[0x5fb6]=value;put(m,NmiDisable=255)
   z=q.wake(m,nested_irq=(pc,63));assert m[0x5fb6]==value&1
   masks.append(dict(input=value,IRQ_PC=hex(pc),after=m[0x5fb6],minimum_SP=z['minimum_SP']))
  checks['foreign_retire_mask_all_three_instruction_IRQ_cuts']=masks
  # Actual constructor clear is busy. Old-owner state cannot become a valid
  # Rogue cache until a stable acquire, even though raw selection is genuine.
  m=setup(b,False);put(m,SelectedCharacter=2);gate(m,True)
  put(m,GuestAudioCharacter=0)
  c,z=q.invoke(m,'RdLifePrepareMain',sp=224)
  constructor=[(pc,bank)for pc,bank,sp in z['trace']if bank==95 and pc==address(b,'RdHsEnterScene')]
  # A fresh-owner constructor is forced through the real public owner hook.
  put(m,GuestAudioCharacter=0);m[0x5fb6]=1;m[address(b,'RdsContext'):address(b,'RdsContext')+4]=bytes([201,202,203,204])
  oldcache=bytes(m[address(b,'RdsContext'):address(b,'RdsContext')+4]);r=v.nmi(m)
  assert get(m,'GuestAudioCharacter')==0 and bytes(m[address(b,'RdsContext'):address(b,'RdsContext')+4])==oldcache
  assert not any(pc==address(b,'RdaNA770')and bank==97 for pc,bank,sp in r['trace'])
  gate(m,False);r=v.nmi(m);assert get(m,'GuestAudioCharacter')==130
  checks['actual_constructor_busy_refuses_old_cache']=dict(real_constructor_CPU=z['CPU'],real_constructor_entries=constructor,cold_busy_driver_calls=0,first_stable_acquires=True)
  # Title SoundTest genuinely calls AudioUpdate twice per NMI, but the Rogue
  # source driver must never run in either call.
  m=setup(b);put(m,OperMode=0,CrossoverMenuState=8,SoundTestPlaying=1,SoundTestKind=0,SoundTestCommand=0,SoundTestHero=2,NmiDisable=255)
  m[address(b,'SoundTestReserved')]=2;r=v.nmi(m)
  gates=sum(pc==address(b,'RdsNmiGate')and bank==63 for pc,bank,sp in r['trace']);ticks=sum(pc==address(b,'RdaNA770')and bank==97 for pc,bank,sp in r['trace'])
  assert gates==2 and ticks==0 and get(m,'SelectedCharacter')==2 and get(m,'OperMode')==0
  checks['genuine_title_SoundTest_outer_inner_calls']=dict(common_gate_calls=gates,Rogue_driver_calls=ticks,CPU=r['CPU'],minimum_SP=r['minimum_SP'])
  # True source pause retains five live images; init retains its source
  # priority. Source counter5C22 is never a queue or cleared each NMI.
  m=setup(b);v.nmi(m) # genuine deferred initial theme commits before pause
  put(m,GamePauseStatus=1,NmiDisable=255);m[0x5c20:0x5c26]=bytes([2,4,60,8,16,32]);before=bytes(m[0x5c20:0x5c26]);r=v.nmi(m)
  assert bytes(m[0x5c20:0x5c26])==before
  put(m,GamePauseStatus=0,NmiDisable=255);r=v.nmi(m)
  assert [m[0x5c20+i]for i in[0,1,3,4,5]]==[0]*5 and m[0x5c22]==60
  checks['source_pause_live_queue_retention_counter_isolation']=dict(before=list(before),resumed_livequeues_zero=True,counter_after=60)
  proof.update(passed=True,bindings=[ref.binding(p)for p in[Path(__file__),O/'candidate.nes',O/'candidate.dbg',O/'candidate.lbl',O/'build.json',R/'tools/rogue_dawn_scheduler_controls_v1.py',R/'tools/rogue_dawn_scheduler_controls_v3.py']],limits=['Typed owner transitions and genuine compiled callbacks; not native menu/controller evidence.','Standalone Rogue-only common gate; SMB2/DMC union endpoints remain separate and require ROOT composition.','Full physical PPU deadline and audio listening remain open.'])
 except Exception as e:
  proof.update(error=repr(e),traceback=traceback.format_exc());p=O/'ownership-negative-1.json';i=2
  while p.exists():p=O/f'ownership-negative-{i}.json';i+=1
  p.write_text(json.dumps(proof,indent=2)+'\n');raise
 (O/'ownership.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(dict(passed=True,instruction_cuts=len(rows),retire_IRQ_cuts=len(masks))))
if __name__=='__main__':main()
