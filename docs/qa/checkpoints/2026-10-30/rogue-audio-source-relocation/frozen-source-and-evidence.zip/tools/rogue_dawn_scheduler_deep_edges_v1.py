"""Exact SP-qualified real Main/Control/NMI/IRQ seams on scheduler6674."""
from pathlib import Path
import itertools,json,sys,traceback
R=Path(__file__).resolve().parents[1];sys.path[:0]=[str(R/'tools'),str(R/'tools/audit')]
import rogue_dawn_scheduler_controls_v3 as v
q=v.q;O=v.O;ref=q.ref;put,get=q.put,q.get;address,location=v.address,v.location;NesMPU=v.NesMPU

def isr(m,c,nested=None):
 before=(q.cpu_state(c),q.physical(m),q.image(m),bytes(m[0x101+c.sp:0x200]),bytes(m[:256]))
 low=c.sp;cycle=c.processorCycles;trace=[];ir=None;c.nmi()
 for _ in range(100000):
  if c.pc==before[0][0]and c.sp==before[0][5]:break
  k=(*q.key(m,c),c.sp);trace.append(k)
  if nested and k==nested and ir is None:ir=q.interrupt(m,c,'IRQ');low=min(low,ir['minimum_SP'])
  assert m[c.pc]!=0,('BRK',k);c.step();low=min(low,c.sp)
 else:raise AssertionError('NMI timeout')
 after=(q.cpu_state(c),q.physical(m),q.image(m),bytes(m[0x101+c.sp:0x200]),bytes(m[:256]))
 assert after==before,('exact live NMI restoration',before[:3],after[:3])
 assert nested is None or ir is not None,('deep IRQ seam not reached',nested,min(trace,key=lambda a:a[2]))
 return dict(CPU=c.processorCycles-cycle,minimum_SP=low,actual_entry_SP=before[0][5],IRQ=q.summary(ir)if ir else None,deepest_executed=min(trace,key=lambda a:a[2]))

def execute(m,name,sp,cut=None,IRQ=None):
 b=m.bundle;pc=address(b,name);bank=(location(b,name)-16)//8192
 if 0xa000<=pc<0xc000:m.page(1,bank);put(m,CurrentBank=128|bank)
 c=NesMPU(memory=m,pc=pc);c.sp=sp;c.p=0x71
 if name!='IdleLoop':c.stPushWord(0x5aff)
 low=c.sp;trace=[];intr=None
 for steps in range(500000):
  if(name=='IdleLoop'and c.pc==pc and steps)or(name!='IdleLoop'and c.pc==0x5b00):break
  k=(*q.key(m,c),c.sp);trace.append(k)
  if cut and k==cut and intr is None:intr=isr(m,c,IRQ);low=min(low,intr['minimum_SP'])
  assert m[c.pc]!=0,('BRK',k);c.step();low=min(low,c.sp)
 else:raise AssertionError(('entry timeout',name))
 assert c.sp==sp and(not cut or intr is not None)
 return dict(minimum_SP=low,trace=trace,interrupt=intr,CPU=c.processorCycles)

def main():
 assert not(O/'deep-edges.json').exists()
 b=v.scoped_load(O/'candidate.nes');proof=dict(passed=False,native_run=False,source_CPU_only=True);checks={}
 try:
  rows=[]
  # Correct the earlier PC-only seam inventory: repeated real service entry
  # addresses can have different SP. Cut on all three genuine PC/bank/SP.
  for entry,sp,action in itertools.product(['RdControlStep','IdleLoop'],[192,253],[0,2,3,4]):
   if(entry,sp)not in[('RdControlStep',192),('IdleLoop',253)]:continue
   m=v.prepared(b,1);v.nmi(m);put(m,RdAction=action,RdClock=0,RdHealthLo=0x69,RdHealthHi=1,NmiDisable=255)
   z=execute(m,entry,sp);cut=min(z['trace'],key=lambda a:a[2])
   # Actual source area1 normal theme uses the measured29-byte NMI depth.
   m=v.prepared(b,1);v.nmi(m);put(m,RdAction=action,RdClock=0,RdHealthLo=0x69,RdHealthHi=1,NmiDisable=255)
   r=execute(m,entry,sp,cut,IRQ=(address(b,'RdaReadRom'),97,cut[2]-29))
   assert r['minimum_SP']>=128,('real fullNMI+IRQ supported guard',entry,action,r['minimum_SP'])
   rows.append(dict(entry=entry,public_SP=sp,action=action,plain_minimum_SP=z['minimum_SP'],exact_cut=[hex(cut[0]),cut[1],cut[2]],minimum_SP=r['minimum_SP'],ISR=r['interrupt']))
  checks['exact_deepest_live_PC_bank_SP_seams']=rows
  proof.update(passed=True,checks=checks,minimum_SP=min(z['minimum_SP']for z in rows),bindings=[ref.binding(p)for p in[Path(__file__),O/'candidate.nes',O/'candidate.dbg',O/'candidate.lbl',O/'controls.json',R/'tools/rogue_dawn_scheduler_controls_v1.py',R/'tools/rogue_dawn_scheduler_controls_v3.py']],limits=['Finite sourceCPU; real PPU deadline/DMAsteals remain unqualified.','Prior PC-only seams proved those actual first occurrences only; this supplement is the exact deepest-SP qualification.'])
 except Exception as e:
  proof.update(error=repr(e),traceback=traceback.format_exc(),checks=checks,bindings=[ref.binding(p)for p in[Path(__file__),O/'candidate.nes']]);p=O/'deep-edges-negative.json';assert not p.exists();p.write_text(json.dumps(proof,indent=2)+'\n');raise
 (O/'deep-edges.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(dict(passed=True,minimum_SP=proof['minimum_SP'],actual_deep_seams=len(rows))))
if __name__=='__main__':main()
