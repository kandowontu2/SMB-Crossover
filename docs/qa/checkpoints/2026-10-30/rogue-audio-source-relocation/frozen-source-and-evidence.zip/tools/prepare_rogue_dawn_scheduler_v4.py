"""Real private BEGIN/COMMIT/NMI successor on79d5. Never native/shared."""
from pathlib import Path
import json,re,subprocess,sys
R=Path(__file__).resolve().parents[1];sys.path[:0]=[str(R/'tools'),str(R/'tools/audit')]
import rogue_dawn_map_v1 as ref
from prepare_cv3_dmc_mirror import prepare
from prepare_rogue_dawn_host_body_handoff_v1 import dependencies
from link_pit_rygar_sophia_audit_cpu import scoped_load
from check_tmnt_render_oa import address,location
P=R/'build/rogue-dawn-live-audio-v1';U=R/'build/rogue-dawn-host-ui-v1';O=R/'build/rogue-dawn-scheduler-v4'
def once(s,a,z):assert s.count(a)==1,(a,s.count(a));return s.replace(a,z)
def optimize(s):
 s=once(s,'; bit0 busy, bit7 this Main STARTED active Rogue. No cue epoch/busy rule.','; bit0 busy; other bits remain zero. Five live cues have no busy rule.')
 s=once(s,'; Boot initial0; EVERY Main brackets context, but only a Main beginning or\n; finishing admitted Rogue increments completed-Rogue count. NMI never ACKs\n; odd, so bit7\'s LDA/ORA/STA is safe within the already-busy interval.','; Boot initial0; EVERY Main brackets context. A Main ending as activeRogue\n; atomically increments its completed count. Foreign retirement discards old\n; counts while preserving the current busy bit; no cached Main RMW can revive it.')
 # A completed Main contributes only while its ending owner is activeRogue.
 # Departing source clocks are discarded at retirement, never replayed into
 # a later fresh seed. BEGIN and ownedCOMMIT are each one atomic INC.
 a=s.index(' inc RdsCommit             ; atomic even->odd');z=s.index('BeginReady:',a)
 s=s[:a]+' inc RdsCommit             ; every Main marks context busy atomically\n'+s[z:]
 a=s.index('End:\n bit RdsCommit');z=s.index('EndReady:',a)
 s=s[:a]+'''End:
 jsr IsActive
 bcc ForeignMain
 inc RdsCommit             ; atomic odd->even completed activeRogueMain
 jmp EndReady
ForeignMain:
 lda #0
 sta RdsCommit             ; a retired owner never survives this Main
'''+s[z:]
 s=once(s,' php\n pha\n lda GuestAudioCharacter',' php\n pha\n lda RdsCommit\n and #1\n sta RdsCommit             ; retire count/startmark, preserve actualbusy\n lda GuestAudioCharacter')
 s=once(s,'RdsCommit=$5fb6','RdsCommit=$5fb6\nRdsSmcBackup=RgAudioCpuZp+155')
 names=['NextBank_SMC+1','SafecallA_SMC+1','FarcallJmpTarget_SMC+1','FarcallJmpTarget_SMC+2','SafereturnA_SMC+1']
 a=s.index('.macro RdsSaveSmc');z=s.index('.segment "ROGUE_SCHEDULER_COMMON"',a)
 s=s[:a]+'.macro RdsSaveSmc\n'+''.join(f' lda {n}\n sta RdsSmcBackup+{i}\n'for i,n in enumerate(names))+'.endmacro\n.macro RdsRestoreSmc\n'+''.join(f' lda RdsSmcBackup+{i}\n sta {n}\n'for i,n in enumerate(names))+'.endmacro\n\n'+s[z:]
 # InputNZ is genuinely from SafecallA's final LDA (onlyFF BEGIN/0END).
 s=once(s,' cmp #0\n beq End\n',' beq End\n')
 s=once(s,'EndReady:\n pla\n plp\n lda #0\n','EndReady:\n pla\n plp\n')
 s=once(s,' lda #3\n ldx GamePauseStatus\n txa\n',' lda GamePauseStatus\n')
 a=s.index('.proc CountRng');z=s.index('.proc CommitContext',a)
 s=s[:a]+s[z:];s=once(s,' jsr CountRng\n','')
 count=' lda RdsCommit\n and #6\n lsr\n tax\n sec\n sbc RdsApplied\n sta RdsRngDelta\n stx RdsApplied\n'
 s=once(s,'.proc RdsAudioFrame\n','.proc RdsAudioFrame\n'+count)
 a=s.index('.proc RdsScheduledTick');z=s.index('.proc RdsAudioFrame',a)
 tick=s[a:z];body=tick[tick.index(' lda #$e1'):tick.index(' lda RdaSavedC\n sta CurrentBankC')]
 s=s[:a]+s[z:];s=once(s,' jsr RdsScheduledTick\n',body)
 s=once(s,'.export RdsAudioFrame,RdsScheduledTick,RdsFrameStart,RdsFrameEnd','.export RdsAudioFrame,RdsFrameStart,RdsFrameEnd')
 # DacDue was the same initbit as NeedTheme. Reuse it for saved sourceY
 # only after the RNGloop. No context/queue/foreground state is borrowed.
 s=once(s,' sta RdsDacDue             ; sole source4011 path is init B404->B44E\n','')
 s=once(s,' lda RdsDacDue\n',' lda RdsNeedTheme\n')
 # Boot's inputA is dead at the real CrossoverInit/NrGlobalInit continuation.
 # Move only this cold20B helper to the common segment to keep A62 bounded.
 a=s.index('.proc RdsBoot');z=s.index('RdsFrameEnd:',a);boot=s[a:z]
 boot=once(boot,' RdsFar CrossoverInit,10,Tail',' lda #<CrossoverInit\n sta FarcallJmpTarget_SMC+1\n lda #>CrossoverInit\n sta FarcallJmpTarget_SMC+2\n lda #$8a\n jmp FarCallCommon')
 s=s[:a]+s[z:];s=once(s,'RdsCommonEnd:',boot+'RdsCommonEnd:')
 return s
def main():
 assert not(O/'build.json').exists(),'Frozen private candidate'
 hand=json.loads((P/'handoff.json').read_text())
 for q in hand['bindings']:assert ref.binding(q['path'])==q,q['path']
 old=scoped_load(P/'candidate.nes');assert ref.digest(old['raw'])=='79d5e8e8657a932755ec3a1f2997d0f57c1759658ce822882c680581439bbcf2'
 assert old['raw'][16+63*8192+0x1400:16+63*8192+0x1600]==b'\xff'*512
 O.mkdir(exist_ok=True)
 # Actual private caller leaves; no full tree/source/runtime copies.
 entry=(P/'entrypoint.s').read_text();entry+='\n.if ::ENABLE_MMC5_EXPANDED\n.import RdsBoot,RdsMainGate,RdsNmiGate\n.endif\n'
 (O/'entrypoint.s').write_text(entry)
 (O/'main.c').write_bytes((P/'main.c').read_bytes())
 reset=(R/'src/reset.s').read_text();reset=once(reset,'  farcall CrossoverInit','  .if ::ENABLE_MMC5_EXPANDED\n  farcall RdsBoot\n  .else\n  farcall CrossoverInit\n  .endif')
 (O/'reset.s').write_text(reset)
 game=(U/'game.s').read_text()
 game=once(game,'  sta NmiDisable\n  rts\n.endproc','  .if ::ENABLE_MMC5_EXPANDED\n  jsr PauseRoutine\n  .else\n  sta NmiDisable\n  .endif\n  rts\n.endproc')
 game=once(game,'  farcall HpPauseCold','  .if ::ENABLE_MMC5_EXPANDED\n  farcall RdsMainGate\n  .else\n  farcall HpPauseCold\n  .endif')
 (O/'game.s').write_text(game)
 # Preserve AudioUpdate's18B prefix extent. Only this private source copy is
 # rebound; real postprocessor also emits the authenticated E125 clone.
 audio=(R/'src/music_drivers/audio.s').read_text()
 a=audio.index('  lda OperMode',audio.index('.proc AudioUpdate'))
 z=audio.index('  lda CurrentBank',a)
 prefix=audio[a:z]
 replacement=''' .if ::ENABLE_MMC5_EXPANDED
  lda CurrentBank
  pha
  lda #$bf
  sta $5115
  jmp RdsNmiGate
  .res 6,$ea
 .else
'''+prefix+' .endif\n'
 audio=audio[:a]+replacement+audio[z:]
 (O/'music_drivers').mkdir(exist_ok=True);(O/'music_drivers/audio.s').write_text(audio)
 life=(U/'lifecycle-source.s').read_text();life=once(life,' jsr RdBodyNewSession\n jmp RdLifePrepareMain',' jsr RdBodyNewSession\n lda #1\n sta RdSfx                 ; genuine fresh-session sourceinit; no grant\n jmp RdLifePrepareMain')
 (O/'lifecycle-source.s').write_text(life)
 # Real driver consumer closure was proved by the frozen plan. Remove only
 # three private diagnostic setters and the old per-NMI RNG Tick.
 driver=(R/'src/rogue_dawn_audio_live_v1.s').read_text()
 driver=once(driver,'.export RdaAudioInit,RdaAudioTick,RdaAudioSetQueue,RdaAudioSetArea,RdaAudioSetMode','.export RdaAudioInit')
 for name in['RdaAudioSetQueue','RdaAudioSetArea','RdaAudioSetMode','RdaAudioTick']:
  pattern=r'\.proc '+name+r'\n.*?\.endproc\n'
  driver,n=re.subn(pattern,'',driver,flags=re.S);assert n==1,name
 driver=once(driver,'RdaAdapterEnd:','.include "rogue_dawn_audio_scheduler_hooks_v4.s"\nRdaAdapterEnd:')
 driver=once(driver,'.include "rogue_dawn_audio_live_native_v1.inc"','.include "rogue_dawn_audio_scheduled_native_v4.inc"')
 # Read helpers cannot recurse: each invokes only C97 rawreader, then the
 # shared return. Their three source registers live in dead NMI fields.
 driver=once(driver,' php\n txa\n pha\n tya\n pha\n.endmacro',' php\n pla\n sta RdaSavedC\n stx RdsRngDelta\n sty RdsDacDue\n.endmacro')
 driver=once(driver,' lda $0104,x\n sta RdaPtr\n lda $0105,x',' lda $0101,x\n sta RdaPtr\n lda $0102,x')
 driver=once(driver,' sta RdaReadValue\n pla\n tay\n pla\n tax\n plp\n lda RdaReadValue',' sta RdaReadValue\n ldx RdsRngDelta\n ldy RdsDacDue\n lda RdaSavedC\n pha\n plp\n lda RdaReadValue')
 driver=once(driver,' lda (RdaPtr),y\n pha\n lda #$be\n sta CurrentBank\n sta $5115\n pla\n rts',' lda (RdaPtr),y\n sta RdaReadValue\n lda #$be\n sta CurrentBank\n sta $5115\n lda RdaReadValue\n rts')
 mainleaf=R/'src/rogue_dawn_audio_scheduler_v4.s';mainleaf.write_text(driver)
 native=(R/'src/rogue_dawn_audio_live_native_v1.inc').read_text()
 for i,name in enumerate(['RdMissileMode','RdGear','RdVY','RdBeamSfx']):
  # Every true source projected operand remains3B and its originalPC+2000.
  pattern=r'(?m)^( lda )'+name+r'( ;49:[0-9A-F]{4} [0-9a-f]+)$'
  native,n=re.subn(pattern,lambda m:m[1]+f'RdsContext+{i}'+m[2],native);assert n==1,(name,n)
 (R/'src/rogue_dawn_audio_scheduled_native_v4.inc').write_text(native)
 hooks=(R/'src/rogue_dawn_audio_scheduler_proposal_v2.s').read_text()
 hooks=hooks[hooks.index('.include "scheduler-imports.inc"'):]
 hooks=once(hooks,'.import RdaAudioInit,RdaBorrow,RdaRelease,RdaOriginalRng,RdaNA770,RdaPublicReturn\n','')
 hooks=once(hooks,'.import GuestAudioBegin,GuestAudioFinishTick,GuestAudioNativeFlush,HpPauseCold,CrossoverInit\n','')
 hooks=once(hooks,'.macpack longbranch\n','')
 hooks=once(hooks,'.segment "RDS_COMMON_PROPOSED"','.segment "ROGUE_SCHEDULER_COMMON"')
 hooks=once(hooks,'.segment "RDS_RECLAIM_PROPOSED"','.segment "ROGUE_AUDIO_ADAPTER_A62"')
 hooks+='\n.assert RdsCommonEnd-RdsCommonStart<=512,lderror,"Approved common512B exceeded"\n'
 hooks=optimize(hooks)
 (R/'src/rogue_dawn_audio_scheduler_hooks_v4.s').write_text(hooks)
 # Constants come only from real immutable parent metadata and actual true
 # definitions which the equal-span old-hook rebindings cannot relocate.
 imports=(R/'build/rogue-dawn-scheduler-plan-v2/scheduler-imports.inc').read_text()
 for name in['RgAudioRam','CurrentBank','CurrentBankC','SelectedCharacter','RdVariant','RdMissileMode','RdGear','RdVY','RdBeamSfx','RdaZpState','RdaSavedC','RdaFrameControl','RdaDac','RdSfx']:
  imports=re.sub(r'(?m)^'+name+r'=.*\n','',imports)
 for name in re.findall(r'(?m)^(\w+)=', (P/'live-driver-imports.inc').read_text()):
  imports=re.sub(r'(?m)^'+name+r'=.*\n','',imports)
 aliases={'GuestAudioBegin':'GuestAudioBegin','GuestAudioFinishTick':'GuestAudioFinish::Tick','GuestAudioNativeFlush':'GuestAudioNativeFlush','HpPauseCold':'HpPauseCold','CrossoverInit':'CrossoverInit'}
 for n,target in aliases.items():imports+=f'{n}=${address(old,target):04x}\n'
 (O/'scheduler-imports.inc').write_text(imports)
 (O/'live-driver-imports.inc').write_bytes((P/'live-driver-imports.inc').read_bytes())
 cfg=(P/'private.cfg').read_text();cfg=once(cfg,'    PALETTE_COALESCE:load=X5_NEW_3F,type=ro,start=$b800;','    ROGUE_SCHEDULER_COMMON:load=X5_NEW_3F,type=ro,start=$b400,optional=yes;\n    PALETTE_COALESCE:load=X5_NEW_3F,type=ro,start=$b800;')
 (O/'private.cfg').write_text(cfg)
 build=json.loads((P/'build.json').read_text());commands=[]
 for i,oldcmd in enumerate(build['commands']):
  cmd=[v.replace(str(P),str(O))for v in oldcmd]
  if i==0:
   cmd=[str(mainleaf)if v==str(R/'src/rogue_dawn_audio_live_v1.s')else v for v in cmd]
  if i==3:
   index=cmd.index('--asm-include-dir');cmd[index:index]=['--asm-include-dir',str(P)]
   index=cmd.index('--asm-include-dir');cmd[index:index]=['--asm-include-dir',str(O)]
   # Relative original music includes must retain their real directory.
   index=cmd.index('--asm-include-dir');cmd[index:index]=['--asm-include-dir',str(R/'src/music_drivers')]
  commands.append(cmd)
 for i,cmd in enumerate(commands):
  log=O/f'build{i}.log'
  if log.exists()and not(O/f'first-build{i}-negative.log').exists():
   prior=log.read_text()
   if 'Error:'in prior:(O/f'first-build{i}-negative.log').write_text(prior)
  z=subprocess.run(cmd,cwd=R,capture_output=True,text=True);log.write_text(z.stdout+z.stderr);assert z.returncode==0,(i,(z.stdout+z.stderr)[-7000:])
 prepare(R,O/'candidate.nes');new=scoped_load(O/'candidate.nes')
 assert address(new,'RdaAdapterEnd')<=0xc000
 assert address(new,'RdsCommonStart')==0xb400 and address(new,'RdsCommonEnd')<=0xb600
 assert new['raw'][16+1048576:]==old['raw'][16+1048576:]
 for bank in[125,127]:
  at=16+bank*8192+0x105d;assert new['raw'][at:at+12][:9].hex()=='ad450148a9bf8d1551'
 deps=dependencies(O/'assembler-full.dep')
 for i in range(3):deps+=dependencies(O/f'audio{i}.dep')
 deps=list(dict.fromkeys(deps));delta={}
 for i,(a,z)in enumerate(zip(old['raw'],new['raw'])):
  if a!=z:delta[str((i-16)//8192)]=delta.get(str((i-16)//8192),0)+1
 output=dict(status='REAL_LINKED_PRIVATE_UNQUALIFIED_SCHEDULER',native_run=False,shared_files_changed=False,ROM=ref.binding(O/'candidate.nes'),parent=ref.binding(P/'candidate.nes'),commands=commands,actual_ASM_inputs=len(deps),A62_end=hex(address(new,'RdaAdapterEnd')),A63_end=hex(address(new,'RdsCommonEnd')),A95_end=hex(address(new,'RdCueGateEnd')),per_bank_delta=delta,bindings=[ref.binding(p)for p in dict.fromkeys(deps+[Path(__file__),P/'handoff.json',O/'private.cfg',O/'scheduler-imports.inc',U/'weapon-object.o',O/'candidate.nes',O/'candidate.dbg',O/'candidate.lbl',O/'candidate.map'])])
 (O/'build.json').write_text(json.dumps(output,indent=2)+'\n');print(json.dumps({k:output[k]for k in['ROM','A62_end','A63_end','A95_end','actual_ASM_inputs','per_bank_delta']}))
if __name__=='__main__':main()
