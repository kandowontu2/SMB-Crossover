"""Fresh final f467 execution; no previous-ROM result is retagged."""
from pathlib import Path
import sys
R=Path(__file__).resolve().parents[1];sys.path[:0]=[str(R/'tools'),str(R/'tools/audit')]
import rogue_dawn_scheduler_controls_v3 as driver
import rogue_dawn_scheduler_deep_edges_v1 as deep
import rogue_dawn_scheduler_ownership_v1 as owner
O=R/'build/rogue-dawn-scheduler-v5'
if __name__=='__main__':
 driver.O=O;deep.O=O;owner.O=O
 driver.main();deep.main();owner.main()
