"""Additive source-only handoff for the frozen f467 scheduler; no build/test/native."""
from pathlib import Path
import difflib
import hashlib
import json
import re
import sys

R = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(R / 'tools'), str(R / 'tools/audit')]
from prepare_rogue_dawn_host_body_handoff_v1 import dependencies

O = R / 'build/rogue-dawn-scheduler-v5'
P = R / 'build/rogue-dawn-live-audio-v1'
U = R / 'build/rogue-dawn-host-ui-v1'
REPORT = R / 'docs/qa/rogue-dawn-real-nmi-scheduler-source-2026-10-29.json'


def bind(path):
    p = Path(path).resolve()
    data = p.read_bytes()
    return dict(path=str(p), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def save(path, data):
    path.write_text(json.dumps(data, indent=2) + '\n')


def main():
    assert not (O / 'handoff.json').exists(), 'Frozen handoff'
    names = ['build', 'controls', 'deep-edges', 'ownership', 'callers',
             'title-start', 'ordinary-controls', 'layout']
    receipts = {n: json.loads((O / (n + '.json')).read_text()) for n in names}
    bound = {}
    for n, data in receipts.items():
        if n != 'build':
            assert data['passed'], n
        for b in data.get('bindings', []):
            assert bind(b['path']) == b, (n, b['path'])
            bound[b['path']] = b
    assert receipts['build']['ROM']['sha256'] == 'f4677c91c642c2720770b5f20e8590664d81ee5f6bcd7bcdae6994b739fb2fdb'
    assert receipts['deep-edges']['minimum_SP'] == 128
    # Include genuine C preprocessor inputs and the qualified cached weapon
    # object's own actual ca65 dependency closure. No guessed source list.
    ui = json.loads((U / 'build.json').read_text())
    ui_bound = {b['path']: b for b in ui['bindings']}
    c_inputs = dependencies(O / 'c-full.dep')
    weapon_inputs = dependencies(U / 'weapon-object.dep')
    for p in weapon_inputs:
        b = bind(p)
        assert ui_bound.get(str(p)) == b, ('cached object source drift', str(p))
        bound[str(p)] = b
    for p in c_inputs:
        bound[str(p)] = bind(p)
    # Source diff is normalized only for review; exact files remain hash-bound.
    pairs = [
        (R / 'src/reset.s', O / 'reset.s'),
        (U / 'game.s', O / 'game.s'),
        (R / 'src/music_drivers/audio.s', O / 'music_drivers/audio.s'),
        (U / 'lifecycle-source.s', O / 'lifecycle-source.s'),
        (R / 'src/rogue_dawn_audio_live_v1.s', R / 'src/rogue_dawn_audio_scheduler_v5.s'),
        (R / 'src/rogue_dawn_audio_live_native_v1.inc', R / 'src/rogue_dawn_audio_scheduled_native_v5.inc'),
        (None, R / 'src/rogue_dawn_audio_scheduler_hooks_v5.s'),
        (P / 'private.cfg', O / 'private.cfg'),
        (P / 'entrypoint.s', O / 'entrypoint.s'),
    ]
    patch = ''
    for a, z in pairs:
        before = [] if a is None else a.read_text().splitlines(keepends=True)
        patch += ''.join(difflib.unified_diff(before, z.read_text().splitlines(keepends=True),
                        fromfile='/dev/null' if a is None else a.relative_to(R).as_posix(),
                        tofile=z.relative_to(R).as_posix()))
    (O / 'source-review.patch').write_text(patch)
    labels = {}
    for line in (O / 'candidate.lbl').read_text().splitlines():
        m = re.fullmatch(r'al ([0-9A-Fa-f]+) \.(\w+)', line)
        if m:
            labels[m[2]] = int(m[1], 16)
    symbols = {n: hex(labels[n]) for n in ['RdsMainGate', 'RdsNmiGate', 'RdsBoot',
               'RdsAudioFrame', 'RdLifeFresh', 'RdBodyNewSession', 'NrFreshGameInit',
               'GameLoop', 'PauseRoutine', 'AudioUpdate', 'RdVariant']}
    controls = receipts['controls']['checks']
    callers = receipts['callers']['checks']
    ownership = receipts['ownership']['checks']
    deep = receipts['deep-edges']['checks']['exact_deepest_live_PC_bank_SP_seams']
    final_sources = [R / ('src/' + n) for n in ['rogue_dawn_audio_scheduler_v5.s',
                     'rogue_dawn_audio_scheduler_hooks_v5.s', 'rogue_dawn_audio_scheduled_native_v5.inc']]
    tools = [R / ('tools/' + n + '.py') for n in ['prepare_rogue_dawn_scheduler_v5',
        'rogue_dawn_scheduler_controls_v1', 'rogue_dawn_scheduler_controls_v3',
        'rogue_dawn_scheduler_deep_edges_v1', 'rogue_dawn_scheduler_ownership_v1',
        'rogue_dawn_scheduler_callers_v1', 'rogue_dawn_scheduler_title_start_v1',
        'rogue_dawn_scheduler_layout_v1', 'rogue_dawn_scheduler_ordinary_v1',
        'rogue_dawn_scheduler_final_controls_v2', 'rogue_dawn_scheduler_freeze_v1']]
    source_files = [O / n for n in ['entrypoint.s', 'reset.s', 'game.s',
        'music_drivers/audio.s', 'lifecycle-source.s', 'main.c', 'private.cfg',
        'scheduler-imports.inc', 'live-driver-imports.inc', 'assembler-full.dep',
        'audio0.dep', 'audio1.dep', 'audio2.dep', 'c-full.dep', 'c-closure.s', 'c-closure.json']]
    final_receipts = [O / (n + '.json') for n in names] + [O / n for n in
        ['candidate.cv3-mirror.json', 'source-review.patch', 'build0.log', 'build1.log',
         'build2.log', 'build3.log', 'flagoff-mmc3.dep', 'flagoff-mmc5.dep',
         'flagoff-mmc3.log', 'flagoff-mmc5.log']]
    history = []
    for version in range(1, 5):
        history += [R / f'src/rogue_dawn_audio_scheduler_v{version}.s',
                    R / f'src/rogue_dawn_audio_scheduler_hooks_v{version}.s',
                    R / f'src/rogue_dawn_audio_scheduled_native_v{version}.inc',
                    R / f'tools/prepare_rogue_dawn_scheduler_v{version}.py']
    history += sorted(p for v in range(1, 6) for p in
                      (R / f'build/rogue-dawn-scheduler-v{v}').glob('*negative*') if p.is_file())
    history += [R / 'build/rogue-dawn-scheduler-v3/retired-RNG-count-negative.json',
                R / 'tools/rogue_dawn_scheduler_final_controls_v1.py']
    history = sorted(set(history))
    report = dict(
        status='FROZEN_PRIVATE_SOURCE_QUALIFIED_SCHEDULER_NATIVE_ADMISSION_OPEN',
        passed=True, source_CPU_only=True, agent_native_run=False,
        canonical_shared_or_settings_changed=False,
        candidate=bind(O / 'candidate.nes'), parent=bind(P / 'candidate.nes'),
        genuine_debug_triple=[bind(O / ('candidate.' + s)) for s in ['dbg', 'lbl', 'map']],
        exact_symbols=symbols,
        build_scope=dict(actual_ASM_incbin_inputs=receipts['build']['actual_ASM_inputs'],
                         actual_C_inputs=len(c_inputs), cached_weapon_object_inputs=len(weapon_inputs),
                         cached_weapon_object=bind(U / 'weapon-object.o'),
                         cached_weapon_object_dep=bind(U / 'weapon-object.dep'),
                         cached_weapon_object_source_receipt=bind(U / 'build.json'),
                         final_direct_receipt_bindings_verified=len({b['path'] for d in receipts.values() for b in d.get('bindings', [])}),
                         note='510 is actual assembler/incbin input count, not a whole build-input count. C preprocessing and the cached object source closure are separately bound. build.json retains its historical pre-control status; this report is additive.'),
        layout=receipts['layout']['code'],
        source_hook_contracts=[
            'Reset: original 18B CrossoverInit farcall now targets RdsBoot, then genuine CrossoverInit.',
            'GameLoop: existing six-byte common exit keeps LDA0/RTS; STA NmiDisable is replaced by JSR PauseRoutine. Existing 18B pause target enters RdsMainGate for BEGIN and COMMIT.',
            'AudioUpdate F05D first18B in genuine E127 and postprocessed E125 maps A63 manually, enters RdsNmiGate, and retains original fixed F06F/F0D8 continuations and F0CE restore.',
            'RdLifeFresh re-arms busy after real generic 5F clear and before source constructor; source init cue follows constructor. Existing death50B BF00 remains exact.',
        ],
        transport=dict(byte='5FB6', semantics='bit0 Main-busy; bits1..2 completed active Rogue Mains0..2; all other bits zero. Atomic INC BEGIN/owned COMMIT, foreign retirement discards counts while retaining current busy. No cue epochs.',
                       cue_operands={'0680': '5C20', '0681': '5C21', '0683': '5C23', '0684': '5C24', '0685': '5C25'},
                       unproduced_Q2='0682 remains NMI-private; 5C22 is the actual source06C4 lowHP counter and is never queue-cleared.',
                       context='MissileMode/Gear/VY/BeamSfx captured only at stable active owner; busy cold acquisition muted without stale driver/context reads.',
                       RNG='Genuine original C000 once per completed active Rogue Main; actual two-Main catch-up verified. Retired counts never replay into a fresh seed.',
                       scratch='Only proven existing RgAudioCpuZp+155..159 /7278..727C stores5SMC, NMI-exclusive after exact raw2/RdVariant1 domain admission. Foreign path performs zero private reads/writes.'),
        authored_SMB_theme_adaptation=dict(water=4, underground=2, castle=5, ground_by_world=[1, 0, 3, 1, 0, 3, 1, 0],
                                          unsupported='Original area3/phase1 room script with low-RAM note pointers is retained as unsupported script behavior. Host never emits06EFphase1; no universal original transition pass.'),
        mixer=dict(source='Actual source driver4017 every tick,4011 only genuine source init, no source DMC.',
                   native='Actual GuestAudioBegin/Frame/shared mixer, MMC5 pulses and NES noise; selected native SQ1 bump/flagpole42, SQ2mask7F, Noisebrick01.',
                   lifecycle='NMI-first effective-owner acquire/retire, actual old CV3 E125 DMC retirement, pause source mode5 queue retention, title/SoundTest state8 inner recursion exclusion.',
                   future_union='SMB2oldowner25/DMC119/120 and Goku are not installed. ROOT must compose ONE true Main/NMI dispatcher and old-owner DMC endpoint, preserving owned APIs; no standalone E-overlay union assumption.'),
        checks={
            'six_normal_theme_source_fullNMI': dict(passed=True, ticks=sum(x['real_source_and_host_NMIs'] for x in controls['changed_helpers_actual_source_requests_and_state']), effects=23, themes=6, ordered_requests_and_projected_state_exact=True),
            'deepest_Control192_real_NMI_and_IRQ': dict(passed=True, exact_PC_bank_SP_cases=len(deep), minimum_SP=128, guard=128, spare_at_stress=0, natural_IdleLoop_minimum_SP=min(x['minimum_SP'] for x in deep if x['entry']=='IdleLoop')),
            'atomic_owner_counter_cuts': dict(passed=True, BEGIN_COMMIT=192, foreign_retire_IRQ=18),
            'complete_title_StartGame': dict(passed=True, actual_Main_cuts=146, old_V4_terminal_counter=1, final_terminal_counter_even=True, real_mode1_writer='physical9:BC29'),
            'partial_real_constructor': dict(passed=True, clear_indices=len(callers['genuine_NrFreshGameInit_all128_partial_constructor_cuts'])),
            'foreign_Main_NMI': dict(passed=True, cases=len(callers['48_foreign_complete_Main_and_regular_NMI'])),
            'old_DMC_actual_E125': dict(passed=True, evidence=callers['genuine_old_DMC_E125_acquire']),
            'ordinary_flagoff_byte_equivalence': dict(passed=True, MMC3='d444cac88e13fa02b29ad16100b8f08fa565ba90f8cedde192de43fb2dc8f3eb', MMC5='f4ffd2483c51daa4d60bb575da2da8c4d817692cda407611c243031f67520833'),
        },
        measured_CPU=dict(fullNMI_per_theme_max=[x['max_NMI_CPU'] for x in controls['changed_helpers_actual_source_requests_and_state']],
                          full_lagNMI_with_nested_IRQ_max=max(x['ISR']['CPU'] for x in deep),
                          foreign_Main_added_vs79d5=sorted(set(x['Main_CPU_delta'] for x in callers['48_foreign_complete_Main_and_regular_NMI'])),
                          foreign_NMI_added_vs79d5=sorted(set(x['NMI_CPU_delta'] for x in callers['48_foreign_complete_Main_and_regular_NMI'])),
                          reset_added_CPU=76,
                          limits='CPU interpreter excludes hardware DMA514, DMC steals and PPU phase/deadline. These finite maxima do not establish60FPS, universal NMI cost or lag-free play. Prior parent wrapper overhead remains additional.'),
        preserved_negatives=[
            dict(version='71fd V1', fact='Actual ControlStep entry192 plus full lagNMI corrupts liveSMC/stack and reaches BRK0194/SP140; plain ControlStep alone remains a separate safe component.', receipt=bind(R/'build/rogue-dawn-scheduler-v1/ControlStep192-full-scheduler-negative.json')),
            dict(version='df2894 V2', fact='Rejected experimental A63-to-A62 direct self-map draft: next opcode fetch changes bank. Never source-qualified; preserved build/source only, no successful stack claim.'),
            dict(version='6674 V3', fact='Typed foreign retirement left completed count2; fresh seed consumed one retired RNG step without a new Main.', receipt=bind(R/'build/rogue-dawn-scheduler-v3/retired-RNG-count-negative.json')),
            dict(version='9caa V4', fact='Genuine whole titleMain5Fclear caused final counter1; finalV5 re-arms only at real owned fresh boundary. Old/fixed witness preserved in final title-start.json.', receipt=bind(O/'title-start.json')),
            dict(kind='tooling/fixture', fact='Other retained negative files are scoped preparation/oracle errors, not native product failures. Includes old normalNMI all-ZP oracle, mistaken bank qualification, pause-before-deferred-theme expectation, and legitimate lag catch-up count. V3 reader-offset note is static caught preparation, not a demonstrated runtime false.'),
        ],
        native_pilot_interface=dict(owner='raw Samus2 AND RdVariant1; same menu slot2, no identity swaps.',
             cold_menu='From default Mario slot0: fresh Right/release twice to Samus slot2; fresh Select/release toggles RdVariant0->1, displayed ROGUEDAWN; fresh Start or A confirms.',
             gameplay='A jump; B source fire; Up aim; Down morph/unmorph; Select missile mode. First native pilot remains ROOT-owned; no cheats or state writes.',
             root_reported_status='ROOT subsequently reported terminal first cold pilot:970PPU/823Main, strict guards pass/minSP167, then stationary300 atX332/Y119. Actual selected wholeframe shows morph ball on top of blocks; old controller triesUp while source usesDown toggle. Controller cause remains a hypothesis pending source check. ROOT also observed black overworld sky, a separate palette defect requiring native backdrop preservation. No completed native PASS; these observations are outside the source CPU receipts.'),
        open=['Actual native render-enable deadline, wholePPU/body/item/weapon effects, source audio listening and sustained performance.',
              'First native morph-ball/controller stationary cause and black native sky palette, to be diagnosed separately without movement/clock waiver.',
              'Cross-family common bridge/DMC union and final adopted source/default build.',
              'Future B600..B800 remains UNALLOCATED despite seven exact read-only free-span audits.'],
        receipts=[bind(O/(n+'.json')) for n in names], source_review_patch=bind(O/'source-review.patch'),
    )
    save(REPORT, report)
    public = sorted(set(final_sources + tools + source_files + final_receipts + [REPORT]))
    publication = dict(status='EXPLICIT_OWNED_MAP_NO_GIT_MUTATION',
        final_source_and_cpu_packet=[bind(p) for p in public],
        historical_source_and_negatives=[bind(p) for p in history],
        reference_only_binaries=[bind(O/('candidate.'+s)) for s in ['nes','dbg','lbl','map']] +
                                [bind(U/'weapon-object.o')],
        no_public_binary_copies=True, no_source_runtime_tree_copies=True,
        note='Map itself and handoff are final additive JSON files; immutable direct inputs listed below. ROOT may publish these exact owned source/receipt files, with historical scope retained.')
    save(O/'owned-files.json', publication)
    for p in public + history + [U/'weapon-object.dep', U/'build.json', O/'owned-files.json']:
        bound[str(p.resolve())] = bind(p)
    # Parent closure refs remain their own immutable packets, not copied trees.
    for p in [P/'handoff.json', R/'build/rogue-dawn-scheduler-plan-v2/handoff.json']:
        bound[str(p.resolve())] = bind(p)
    handoff = dict(status=report['status'], passed=True, source_CPU_only=True, native_run=False,
        candidate=bind(O/'candidate.nes'), report=bind(REPORT), owned_files=bind(O/'owned-files.json'),
        source_review_patch=bind(O/'source-review.patch'), minimum_SP=128,
        final_scope='Real compiled fullMain/fullNMI/IRQ source-only qualification. ROOT cold pilot is separately terminal stationaryFALSE, not native admission.',
        current_binding_count=len(bound), bindings=[bound[p] for p in sorted(bound)])
    save(O/'handoff.json', handoff)
    print(json.dumps(dict(handoff=bind(O/'handoff.json'), report=bind(REPORT),
          owned_files=bind(O/'owned-files.json'), bindings=len(bound), final_public_files=len(public),
          historical_files=len(history), passed=True), indent=2))


if __name__ == '__main__':
    main()
