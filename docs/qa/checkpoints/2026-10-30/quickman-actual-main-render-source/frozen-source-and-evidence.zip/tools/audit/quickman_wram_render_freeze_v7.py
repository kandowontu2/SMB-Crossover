"""Freeze real-Main source-render proof; preserve foreign latency hold."""
from pathlib import Path
import hashlib,json,shutil,sys,zipfile,difflib,collections
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(Path(__file__).parent))
from check_tmnt_render_oa import load,address,location
W=R/'build/quickman-wram-render-v7';P=R/'build/quickman-wram-palette-v6';F=R/'build/quickman-wram-palette-cpu-v6';O=R/'build/quickman-wram-render-cpu-v7'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(n,d):(O/n).write_text(json.dumps(d,indent=2)+'\n',newline='\n')
def main():
 assert not(O/'handoff.json').exists(),'Do not overwrite a frozen packet'
 for p,h in json.loads((F/'handoff.json').read_text())['bindings'].items():assert sha(p)==h,('Frozen7106 source binding changed',p)
 rom=sha(W/'candidate.nes');assert rom=='df2b18c499a42660c12e81d86732afb92714952d281e0924859a3ffa14b48e1d'
 checks=['loader-controls.json','cold-preview-controls.json','lifecycle-controls.json','source-controls.json','render-controls.json','public-controls.json','full-main-controls.json','flags-controls.json','loader-isr-controls.json','active-isr-controls.json','foreign-controls.json','palette-scene-controls.json','palette-isr-controls.json','actual-main-render-controls.json','actual-main-render-warm-controls.json','actual-main-render-warm-no-fan-controls.json','actual-main-render-ISR-controls.json','render-retire-reentry-controls.json']
 for n in checks:
  x=json.loads((W/n).read_text());assert x['ROM_sha256']==rom and x.get('passed',True),n
 b=load(W/'candidate.nes');p=load(P/'candidate.nes');raw=b['raw'];old=p['raw'];cs=16+128*8192
 assert raw[:16]==old[:16]and raw[cs:]==old[cs:]
 for n in ['code.bin','data.bin','quick/cookie.bin']:assert(W/n).read_bytes()==(P/n).read_bytes(),n
 assert all(address(b,n)==address(p,n)for n in p['syms']if n.startswith('QmField_'))
 for bank in [125,127]:assert raw[16+bank*8192:16+(bank+1)*8192]==old[16+bank*8192:16+(bank+1)*8192]
 segs=[(int(s['ooffs'],0),int(s['ooffs'],0)+int(s['size'],0),s['name'].strip('"'))for s in b['segs'].values()if'ooffs'in s and s['name']not in ['"QW_CODE"','"QW_DATA"']]
 changed=[]
 for at,(a,z)in enumerate(zip(old[16:cs],raw[16:cs]),16):
  if a==z:continue
  n=next((n for start,end,n in segs if start<=at<end),'NONE');assert n in ['QW_ROUTER','QW_LOADER','QW_EMPTY34','Z2_DRAW_GATE'],(at,n)
  changed.append(dict(bank=(at-16)//8192,offset=(at-16)%8192,segment=n,before=a,after=z))
 used=[dict(segment=n,bank=(a-16)//8192,start=(a-16)%8192,end=(z-16)%8192 or 8192,bytes=z-a)for a,z,n in segs if n.startswith('QP_')or n in ['QW_ROUTER','QW_LOADER','QW_EMPTY34']]
 assert sum(x['bytes']for x in used)==1989
 assert address(b,'QwOwnedDraw')==0xaa09 and address(b,'QwEmpty34')==0xdd9d
 O.mkdir(exist_ok=True);names=['candidate.nes','candidate.dbg','candidate.lbl','candidate.map','candidate.cv3-mirror.json','code.bin','data.bin','wram.cfg','successor-commands.json','render-predecessor.json',*checks]
 for n in names:shutil.copy2(W/n,O/n)
 (O/'quick').mkdir(exist_ok=True);shutil.copy2(W/'quick/cookie.bin',O/'quick/cookie.bin')
 diff=[]
 for n in ['quick/loader.s','frozen-inputs/src/zelda2_link_render.s','entrypoint.s','wram.cfg']:
  a=(P/n).read_text().replace(P.as_posix(),'<PRIVATE>').replace(str(P),'<PRIVATE>')
  z=(W/n).read_text().replace(W.as_posix(),'<PRIVATE>').replace(str(W),'<PRIVATE>')
  diff.extend(difflib.unified_diff(a.splitlines(True),z.splitlines(True),fromfile='7106/'+n,tofile='df2b/'+n))
 (O/'source-render.diff').write_text(''.join(diff),newline='\n')
 direct=[x for x in W.rglob('*')if x.is_file()and x.suffix in ['.s','.inc','.cfg','.chr','.bin']and not x.is_relative_to(W/'bench')]
 for x in(W/'frozen-inputs').rglob('*'):
  if x.is_file()and x not in direct and x.suffix not in ['.o','.nes','.dbg','.lbl','.map','.py','.json']:direct.append(x)
 tools=[R/'tools/audit'/n for n in ['quickman_wram_render_v7.py','quickman_wram_render_controls_v7.py','quickman_wram_render_freeze_v7.py']]
 with zipfile.ZipFile(O/'source-closure.zip','w',zipfile.ZIP_DEFLATED)as z:
  for x in sorted(set(direct+tools)):z.write(x,x.relative_to(R).as_posix())
 with zipfile.ZipFile(O/'source-closure.zip')as z:assert z.testzip()is None;members=len(z.namelist())
 entries={n:dict(PC=address(b,n),physical_PRG_bank=(location(b,n)-16)//8192)for n in ['QwOwnedDraw','QwLegacyDrawGate','QwRouter','QwConstruct','QwPortrait','QwColors','QwBoot','QwRetire','QwEmpty34']}
 put('typed-draw-API.json',dict(status='OWN_ONLY_ENTRY_FOR_JOINT_SOURCE_LINKING',ROM_sha256=rom,source=str(W/'quick/loader.s'),source_sha256=sha(W/'quick/loader.s'),exports=entries,raw_owner='SelectedCharacter9 andFmAltsbit5=1, selected temporal cache validQuick cookie.',entry='Source-link onegenuine farcall toQwOwnedDraw after original HpGraphicsBankCopy/CrossoverGraphicsBank has established original Bass rawC=A2. Caller must locally select owner before call; all foreign paths retain their original ingress.',effects='QhGraphics through rawRAM1/C2 imports native resolved coordinates; QhDraw emits original body+3shot slots, then ObjectMetasprite0 suppresses only the original player tail/PlayerBankReady. SmPosePtr=DD9D points to genuine0-lengthC34 descriptor for unchanged native post-shot reservation.',preservation='Source dispatcher restores rawA/C,R0/R1; original C34 view restored. A/X/Y/P volatile, native after-call loadsCurrentOAMOffset. No new state/ZP.',native_actors='Original native enemy/item/block/brick/floating-number loops remain;120warmMain sourceRGB/OAM cases compare their exact visible cells to original native engine with player absent.',upstream_skip_contract='Do not also invoke originalRosterDrawShots forQuick or later draw its legacyObjectMetasprite. Keep native actors/float numbers/HUD and all windows1..7. If upstream bypasses the native reservation read, use a new source-linked own wrapper with an explicitly tested matching contract.',avoid='Do not import currentZ2farcall retarget into shared: it makes foreigncalls nest A70 and incurs123/132CPU. Keep wrapper as private proof negative only.',relink='Code6512/data1921 contain actual native symbol imports. Reassemble against joint parent, recompute exact cookie first12SHA256(code+data), regenerate9-page884..893 stream and realCV3mirror. Do not blit old PRG/code or copy numeric DBG PCs.',existing_lease='A70 retained ownrouter space;C82loader;C98coldportrait;1B C34DD9D is before reservedRogueDE00 pages; no physical4/120 allocation granted.'))
 foreign=json.loads((W/'foreign-controls.json').read_text());counts=collections.Counter(r[4]for r in foreign['rows'])
 put('source-linked-proof.json',dict(passed=True,ROM_sha256=rom,predecessor_ROM_sha256=sha(P/'candidate.nes'),loaded_code_bytes=6512,loaded_data_bytes=1921,loaded_code_data_cookie_all_exact=True,all535_source_aliases_exact=True,allCHR_exact_to7106=True,fixed125_and127_exact=True,exact_changed_PRG_bytes=changed,placements=used,retained_ROM_used=1989,current_joint_Quick_lease=7500,remaining_joint_headroom=5511,transient557_persistent8_unchanged=True,new_ZP=0,native=False,foreign_state_and_ordered_writes_exact=True,foreign_CPU_delta=foreign['CPU_delta'],foreign_delta_case_counts=dict(counts),shared_hold='123/132CPU foreignregression viaextraA70fallback. Rootrequires jointtypedowner ingress before shared/admission/native.',source_closure_members=members))
 (O/'README.txt').write_text('Frozen private source-renderer component proof df2b. NO native run or admission. All6017106source bindings unchanged. The preserved7106native negative proves its visiblebody used legacyMetaspriteRenderLoop;219hardware samples independently prove bluebackdrop repair. NewactualMain now reaches sourceQhGraphics/QhDraw exactlyonce and skips originalRosterDrawShots andPlayerBankReady only forQuick.\n\n180completeMain pose fixture cases:30authenticatedposes×bothfacings with3fan;60warmrepeat;60warmwithoutfan. The120warmcases include actualnextNMI palette+physicalCHR/pixelcolor checks against immutable5KB source art. NativeGoomba/mushroom/block/brick/floating-number visibleOAM matches the same native renderer with no player, including warmOAMrotation. Sourcepose/native-render requests are legalCPU draw-boundary fixtures, not claims controllers naturally reached everypose.212actualMain newgate/render/native-reservation NMI/IRQ seams preserve allsource/nativeOAM and rawmaps/R0/R1/SMC/stack; lagNMI keeps oldhardwareCHR. Quick/Bass/Quick/Roll/Quick reentry uses actualInitScreen at declared forcedblank scene fixtures then realMain; nativePlayerBankReady remains forBass/Roll. Initial constructor-in-activegameplay and outerSFC-lag-boundary fixture negatives are explained in the corresponding receipts, not normalized into enginepasses.\n\nAll11legacyCPUgroups plus80scene/384queue/68paletteISR rerunPASS:1520sourceupdates/all535fields/orderedterrain,300publicOAM,160completeMain,512flags,40loader+292activeISRs,282foreignMain. Original code6512/data1921/cookie and allCHR are byteexactto7106; only genuine18BZ2farcall operands, ownedA70worker and1B DD9D nativezero descriptor change. Fixed125/127 exact.\n\nSHARED HOLD: private Z2→A70 selector makes someforeign paths nest an additionalfarcall:198cases0,72cases+123,12cases+132CPU. ForeignAXYP/SP/application/OAM/CHR/maps/orderedwrites remain exact. No unowned4/120space taken. Root directs actualupstreamjointtyped DrawAll selection so foreignowners keep originalroute. QwOwnedDraw export atA70AA09 is a narrowlytyped own-only entry for thatsourceintegration; see typed-draw-API.json. No blindoverlay/numericPC reuse.\n\nQuickcurrentjointlease7500B uses1989B, remaining5511B; sourceROMworker plusC82loader+C98coldportrait. No newRAM/ZP/CHRleases;transient557,persistent2x4,CHR251..255, stream884..892, original32KBprivateheader remain. ReservedRogue10pages and93:0FA7..<0FE7 stayexcluded. OriginalCXaudio/theme/contact cadence, realNTSCcadence, native fullpose art and broadercampaign/Hard qualification remainOPEN. No sharedsource/Downloads/readiness/emulator/userwindow changed.\n',encoding='utf-8',newline='\n')
 refs=[F/'handoff.json',R/'build/quickman-wram-palette-native-review-v6/handoff.json',R/'docs/qa/checkpoints/2026-10-30/rogue-quick-audio-private-allocation/root-review-and-reservations.json']
 files=[x for x in O.rglob('*')if x.is_file()]
 put('handoff.json',dict(status='FROZEN_PRIVATE_ACTUAL_MAIN_SOURCE_RENDER_CPU_SHARED_HOLD',ROM_sha256=rom,native=False,shared_install=False,retained_ROM_used=1989,joint_Quick_lease=7500,joint_headroom=5511,source_members=members,foreign_latency_negative=[123,132],typed_own_entry='QwOwnedDraw',bindings={str(x.resolve()):sha(x)for x in files+direct+tools+refs}))
 print(json.dumps(dict(packet=str(O),handoff_sha256=sha(O/'handoff.json'),ROM_sha256=rom,bindings=len(json.loads((O/'handoff.json').read_text())['bindings']),source_members=members),indent=2))
if __name__=='__main__':main()
