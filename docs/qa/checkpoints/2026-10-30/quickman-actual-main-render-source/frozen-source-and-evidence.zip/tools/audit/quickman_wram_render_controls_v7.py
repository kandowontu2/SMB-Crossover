"""Actual Main/DrawAll proof for the new source renderer route."""
from pathlib import Path
import copy,json,sys,hashlib,collections
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(Path(__file__).parent))
import quickman_wram_palette_controls_v6 as C
O=R/'build/quickman-wram-render-v7';C.O=O;C.CODE=(O/'code.bin').read_bytes();C.DATA=(O/'data.bin').read_bytes()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(n,d):(O/n).write_text(json.dumps(d,indent=2)+'\n',newline='\n')
def clone(m):
 q=copy.copy(m)
 for n in ['ram','wram','tags','banks','chr','vram','scroll','pad_index','cache_writes','executed_RAM','writes','events','visits','palette_writes']:
  if hasattr(m,n):setattr(q,n,copy.deepcopy(getattr(m,n)))
 return q
def pose(m,p,facing,fan):
 for i in [0,2,3,4]:m.set('QmField_'+format(0x420+i,'04X'),0)
 for a,v in [(0x400,int(p['from_type'],16)),(0x6a0,p['index']),(0x420,facing),(0x460,128),(0x4a0,128),(0x1f,0),(0x20,0)]:m.set('QmField_'+format(a,'04X'),v)
 m.set('Player_X_Position',120);m.set('Player_PageLoc',0);m.set('Player_Y_Position',108);m.set('Player_Y_HighPos',1);m.set('ScreenLeft_X_Pos',0);m.set('ScreenLeft_PageLoc',0)
 m.set('InjuryTimer',0);m.set('MmDeathFlag',0)
 if fan:
  for i in [2,3,4]:
   for a,v in [(0x400,14),(0x6a0,i-2),(0x420,facing),(0x460,128+(i-3)*12),(0x4a0,128)]:m.set('QmField_'+format(a+i,'04X'),v)
def native_actors(m):
 for i in range(1,24):m.ram[m.lab['ObjectMetasprite']+i]=0
 for i,name,x,y in [(1,'METASPRITE_GOOMBA_WALKING_1',24,176),(2,'METASPRITE_POWERUP_MUSHROOM',64,160),(9,'METASPRITE_MISC_BLOCK',176,176),(10,'METASPRITE_MISC_BRICK_GROUND',208,160)]:
  m.ram[m.lab['ObjectMetasprite']+i]=m.lab[name]
  for key,v in [('SprObject_X_Position',x),('SprObject_PageLoc',0),('SprObject_Y_Position',y),('SprObject_Y_HighPos',1),('PlayerFacingDir',1)]:m.ram[m.lab[key]+i]=v
 for i in range(7):m.ram[m.lab['FloateyNum_Control']+i]=0
 m.set('FloateyNum_Control',1);m.set('FloateyNum_X_Pos',192);m.set('FloateyNum_Y_Pos',120)
def expected(p,facing,fan,art):
 out=[]
 entries=[(p['frame'],128,128)]+([(0x5c,116,128),(0x5d,128,128),(0x5e,140,128)]if fan else[])
 for frame,x,y in entries:
  for cell in art[frame]['cells']:
   dx=cell['x'] if facing&64 else -(cell['x']+8);attr=cell['attr']^(0 if facing&64 else 64)
   out.extend([(y+cell['y'])&255,cell['pair']*2,attr,(x+dx)&255])
 return bytes(out)
def actual_main():
 poses=json.loads((R/'build/quickman-source-v1/poses/pose-manifest.json').read_text())['frames']
 art={x['frame']:x for x in json.loads((R/'build/quickman-host-plan-v1/art/window0-proof.json').read_text())['frames']}
 template=C.seeded();rows=[]
 for p in poses:
  for facing in [0x80,0xc0]:
   fan='--no-fan'not in sys.argv;m=clone(template);C.normal_nmi(m,0);entered=False;reference=None
   def hook(c):
    nonlocal entered,reference
    if c.pc!=m.lab['DrawAllMetasprites']or m.tags[1]!=(m.bank('DrawAllMetasprites')|128):return
    assert not entered;entered=True;pose(m,p,facing,fan);native_actors(m)
    if '--warm'in sys.argv:m.set('RgOamUsed',224);m.set('RgOamFirst',200)
    # Native actor reference uses the same compiled engine with no player or
    # player shots. Pose fixtures are supplied only at the legal draw boundary.
    ref=clone(m);ref.set('FmAlts',0);ref.set('ObjectMetasprite',0);ref.set('SmPosePtr',0x9d);ref.ram[ref.lab['SmPosePtr']+1]=0xdd
    C.invoke(ref,'DrawAllMetasprites')
    reference=bytes(ref.ram[0x200:0x300])
   result=C.invoke(m,'GameLoop',hook=hook);assert entered
   source=expected(p,facing,fan,art);actual=bytes(m.ram[0x200:0x300])
   assert actual[:len(source)]==source,('Actual Main source OAM',p['frame'],facing,len(source),list(actual[:len(source)]),list(source))
   reference_cells=collections.Counter(tuple(reference[i:i+4])for i in range(0,256,4)if reference[i]<240)
   remaining=collections.Counter(tuple(actual[i:i+4])for i in range(len(source),256,4)if actual[i]<240)
   assert remaining==reference_cells,('Native enemy/item/block/number OAM preserved',p['frame'],facing,remaining,reference_cells)
   trace=result['trace'];counts={}
   for name in ['QwLegacyDrawGate','QhGraphics','QhDraw','QuickManHostRender','PlayerBankReady','RosterDrawShots']:
    pc=m.lab[name];tag=1 if name.startswith(('Qh','QuickMan'))else m.bank(name)|128
    counts[name]=sum(p==pc and tags[(p-0x8000)//8192]==tag for tags,p in trace)
   assert all(counts[n]==1 for n in ['QwLegacyDrawGate','QhGraphics','QhDraw','QuickManHostRender'])and counts['PlayerBankReady']==counts['RosterDrawShots']==0
   assert m.get('ObjectMetasprite')==0 and m.get('CurrentCHRBank')==251+art[p['frame']]['logical_page']and m.get('X5ChrMode')==128
   # Genuine next ordinary NMI consumes the real Main-produced palette packet
   # and publishes the CHR mapping. Compare source RGB roles on hardware data.
   C.normal_nmi(m,0)
   assert m.vram[0x3f00]==0x22
   assert [m.vram[x]for x in [0x3f11,0x3f12,0x3f13,0x3f15,0x3f16,0x3f17]]==[0x0f,0x28,0x15,0x0f,0x30,0x38]
   page=251+art[p['frame']]['logical_page'];assert m.chr[0]==page
   original=(R/'build/quickman-host-plan-v1/art/quick-man-window0-5pages.chr').read_bytes()
   base=16+128*8192+page*1024
   assert m.bundle['raw'][base:base+1024]==original[(page-251)*1024:(page-250)*1024]
   colored=0
   for i in range(0,len(source),4):
    _,tile,attr,_=source[i:i+4];role=attr&3;assert role in [0,1]
    for y in range(16):
     row=15-y if attr&128 else y
     at=base+(tile&254)*16+(row//8)*16+row%8
     for x in range(8):
      bit=x if attr&64 else 7-x
      value=((m.bundle['raw'][at]>>bit)&1)|(((m.bundle['raw'][at+8]>>bit)&1)<<1)
      if value:
       rgb=m.vram[0x3f10+role*4+value]
       assert rgb==[[0x0f,0x0f,0x28,0x15],[0x0f,0x0f,0x30,0x38]][role][value]
       colored+=1
   rows.append(dict(frame=p['frame'],facing=facing,fan=fan,source_OAM_bytes=len(source),native_visible_cells=sum(reference_cells.values()),native_actor_OAM_exact=True,actual_NMI_CHR_page=page,source_visible_color_pixels_checked=colored,route_counts=counts,Main_cycles=result['CPU']))
 put('actual-main-render'+('-warm'if '--warm'in sys.argv else'')+('-no-fan'if '--no-fan'in sys.argv else'')+'-controls.json',dict(passed=True,native=False,ROM_sha256=sha(O/'candidate.nes'),actual_complete_Main_cases=len(rows),all30_source_poses=True,both_facings=True,native_three_shot_fan=fan,native_enemy_item_blocks_floating_number_render_requests_preserved=True,source_OAM_compared_from_real_Main=True,explicit_HuDraw_call_used=False,PlayerBankReady_skipped_only_owned_Quick=True,fixture='Legal source pose/native actor requests supplied at actualDrawAll boundary after realMain physics; native actor reference is same realDrawAll with no player. No native controller/pose occurrence claim.',rows=rows))
 print('ActualMain source30/bothfaces/fan/nativeactors PASS',len(rows),flush=True)
def main_interrupts():
 template=C.seeded();C.normal_nmi(template,129)
 m=clone(template);cuts=[];seen=set();excluded=[];count=0
 names=['QwLegacyDrawGate','QwRouter','QhGraphics','QhDraw','QuickManHostRender','ArenaPublish','RosterProjectileOamReady','DoneDrawingPlayer']
 entries={m.lab[n]for n in names}
 def observe(c):
  nonlocal count
  pc=c.pc;op=bytes(m[pc:pc+3]);key=(tuple(m.tags),pc)
  if key not in seen and(pc in entries or op in [b'\x8d\x15\x51',b'\x8d\x16\x51']):
   seen.add(key)
   if m.get('NmiDisable')>=128:cuts.append((count,pc))
   else:excluded.append(dict(step=count,PC=pc,NmiDisable=m.get('NmiDisable'),reason='OuterSFC test wrapper before real GameLoop setsFF or after PauseSkip publishes0; not an activeMain lagNMI seam.'))
  count+=1
 base=C.invoke(m,'GameLoop',hook=observe);expected=bytes(m.ram[0x200:0x300]);rows=[]
 for step,pc in cuts:
  for kind in ['NMI','IRQ']:
   q=clone(template);at=0;proof=[]
   def inject(c):
    nonlocal at
    if at==step:
     assert c.pc==pc and q.get('NmiDisable')>=128
     if kind!='IRQ'or not c.p&c.INTERRUPT:
      before=q.chr[:];proof.append(C.interrupt_at(q,c,kind))
      if kind=='NMI':assert q.chr==before,'LagNMI changed CHR under retained hardwareOAM'
    at+=1
   C.invoke(q,'GameLoop',hook=inject)
   assert bytes(q.ram[0x200:0x300])==expected and q.get('ObjectMetasprite')==0
   C.exact_cache(q)
   if proof:rows.append(dict(step=step,PC=pc,**proof[0]))
 put('actual-main-render-ISR-controls.json',dict(passed=True,native=False,ROM_sha256=sha(O/'candidate.nes'),cases=len(rows),actual_complete_Main=True,source_graphics_draw_new_gate_and_native_reservation_boundaries=True,all_source_and_native_OAM_exact_after_ISR=True,lag_NMI_retains_hardware_CHR=True,raw_A_C_R0_R1_SMC_AXYP_stack_preserved=True,excluded_non_Main_lag_seams=excluded,negative='Initial broad mapper-cut fixture asserted Main lag ownership at an outerFarCallCommon boundary withNmiDisable0; corrected to actual GameLoop FF..PauseSkip0 source-owned interval. No ISR guard/ABI assertion weakened inside activeMain.',rows=rows))
 print('ActualMain render/NMI/IRQ exactOAM PASS',len(rows),flush=True)
def render_lifecycle():
 m=C.seeded();rows=[]
 for owner in ['Quick','Bass','Quick','Roll','Quick']:
  m.set('SelectedCharacter',9);m.set('FmAlts',32 if owner=='Quick' else 0);m.set('RlVariant',1 if owner=='Roll' else 0)
  C.invoke(m,'QwRetire')
  if owner=='Quick':
   # Re-entry is an actual InitScreen call at its declared forced-blank scene
   # boundary, not an illegal constructor attempt in still-active gameplay.
   m.set('Mirror_PPUMASK',0);m.ppu_mask=0;m.set('DisableScreenFlag',1);m.set('NmiDisable',255)
   C.invoke(m,'InitScreen');C.exact_cache(m)
  C.normal_nmi(m,1);result=C.invoke(m,'GameLoop')
  def n(name):
   pc=m.lab[name];tag=1 if name.startswith('Qh')else m.bank(name)|128
   return sum(p==pc and tags[(p-0x8000)//8192]==tag for tags,p in result['trace'])
  if owner=='Quick':assert n('QhDraw')==1 and n('PlayerBankReady')==0 and m.get('ObjectMetasprite')==0
  else:assert n('QhDraw')==0 and n('PlayerBankReady')==1
  rows.append(dict(owner=owner,source_draw_calls=n('QhDraw'),native_PlayerBankReady_calls=n('PlayerBankReady'),ObjectMetasprite=m.get('ObjectMetasprite'),raw_C_after=m.tags[2]))
 put('render-retire-reentry-controls.json',dict(passed=True,native=False,ROM_sha256=sha(O/'candidate.nes'),rows=rows,owner_only_legacy_body_suppression=True,actual_Main_each_turn=True,cache_invalidated_before_owner_reacquisition=True,scope='ActualInitScreen at a legal forcedblank CPU scene fixture, then realMain; no claim these owner changes occur through native controllers. Initial invalid attempt to call constructor during active gameplay correctly kept cookie invalid; preserved as boundary-negative explanation.'))
 print('ActualMain Quick/Bass/Roll/retire/reenter PASS',flush=True)
if __name__=='__main__':
 if '--main-render'in sys.argv:actual_main()
 if '--main-render-isr'in sys.argv:main_interrupts()
 if '--render-life'in sys.argv:render_lifecycle()
 for flag,fn in [('--loader',C.loader),('--preview',C.preview),('--life',C.lifecycle),('--source',C.source),('--public',lambda:C.render_public('public')),('--render',lambda:C.render_public('render')),('--main',C.full_main),('--flags',C.flags),('--isr',C.interrupts),('--palette',C.palette_controls),('--palette-isr',C.palette_interrupts),('--foreign',C.foreign)]:
  if flag in sys.argv:fn()
