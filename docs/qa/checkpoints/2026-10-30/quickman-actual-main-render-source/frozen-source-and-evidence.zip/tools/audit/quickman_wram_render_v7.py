"""New private real-Main source render hook, preserving frozen7106 evidence."""
from pathlib import Path
import json,hashlib,shutil,sys
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(Path(__file__).parent))
import quickman_wram_palette_v6 as B
P=R/'build/quickman-wram-palette-v6';F=R/'build/quickman-wram-palette-cpu-v6';O=R/'build/quickman-wram-render-v7'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,s):
 assert p.resolve().is_relative_to(O.resolve()),p
 p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,newline='\n')
def prepare():
 assert not O.exists()
 for n,h in json.loads((F/'handoff.json').read_text())['bindings'].items():assert sha(n)==h,n
 shutil.copytree(P,O,ignore=shutil.ignore_patterns('bench','*.o'))
 for p in O.rglob('*'):
  if p.is_file()and p.suffix in ['.s','.inc','.cfg','.json','.d']:
   try:
    s=p.read_text()
    for a,z in [(P.as_posix(),O.as_posix()),(str(P).replace('\\','\\\\'),str(O).replace('\\','\\\\')),(str(P),str(O))]:s=s.replace(a,z)
    put(p,s)
   except UnicodeDecodeError:pass
 p=O/'frozen-inputs/src/zelda2_link_render.s';s=p.read_text()
 needle='.proc Z2DrawGuard\n farcall RlLegacyDrawDispatch,jmp'
 assert s.count(needle)==1
 put(p,'.import QwLegacyDrawGate\n'+s.replace(needle,'.proc Z2DrawGuard\n farcall QwLegacyDrawGate,jmp',1))
 p=O/'quick/loader.s';s=p.read_text()
 glue='''
; Entered only at the genuine native post-shot draw fallback. Foreign A/P
; reaches exactly its original legacy owner. Own RAM dispatcher restores C34.
.export QwLegacyDrawGate,QwOwnedDraw,QwEmpty34
.import QhGraphics,QhDraw,RlLegacyDrawDispatch,ObjectMetasprite,SmPosePtr
QwLegacyDrawGate:
 php
 pha
 jsr QwActive
 bcc QwLegacyDrawForeign
 pla
 plp
QwOwnedDraw:
 lda #<QhGraphics
 sta ArenaGatePtr
 lda #>QhGraphics
 sta ArenaGatePtr+1
 jsr QwRouter
 lda #<QhDraw
 sta ArenaGatePtr
 lda #>QhDraw
 sta ArenaGatePtr+1
 jsr QwRouter
 ; Source body+fan are already complete. Suppress only the native player
 ; descriptor and its PlayerBankReady publication, not any enemy/helper.
 lda #0
 sta ObjectMetasprite
 lda #<QwEmpty34
 sta SmPosePtr
 lda #>QwEmpty34
 sta SmPosePtr+1
 rts
QwLegacyDrawForeign:
 pla
 plp
 RomCall RlLegacyDrawDispatch
 rts
'''
 assert s.count('QwCookie:\n')==1
 s=s.replace('QwCookie:\n',glue+'\nQwCookie:\n',1)
 s+='\n.segment "QW_EMPTY34"\n; CrossoverGraphicsBank selects original Bass physical34 before this hook.\n; A genuine zero-length native descriptor avoids any player reservation gap.\nQwEmpty34:.byte 0\n'
 put(p,s)
 p=O/'entrypoint.s';put(p,p.read_text()+'\n.export RlLegacyDrawDispatch,ObjectMetasprite,SmPosePtr\n')
 p=O/'wram.cfg';s=p.read_text();assert s.count('QW_LOADER:load=QH_PRG_5,type=ro;')==1
 put(p,s.replace('QW_LOADER:load=QH_PRG_5,type=ro;','QW_LOADER:load=QH_PRG_5,type=ro;\nQW_EMPTY34:load=QH_PRG_20,type=ro;',1))
 # QW_EMPTY34 DD9D is before the separately grantedRogue DE00 pages; no new
 # source producer may place bytes in any of those ten reserved pages.
 (O/'render-predecessor.json').write_text(json.dumps(dict(ROM_sha256=sha(P/'candidate.nes'),handoff_sha256=sha(F/'handoff.json'),native_negative_handoff_sha256=sha(R/'build/quickman-wram-palette-native-review-v6/handoff.json'),new_hook='Original18B Z2DrawGuard farcall operands only -> ownedA70 raw9/FmAlts32 gate -> actual sourceGraphics+Draw. Native player descriptor cleared after source drawing; native actors continue.',private_only=True),indent=2)+'\n')
def build():
 B.P=P;B.F=F;B.O=O;B.build()
 from check_tmnt_render_oa import load,address,location
 b=load(O/'candidate.nes');p=load(P/'candidate.nes')
 assert address(b,'QwEmpty34')==0xdd9d and (location(b,'QwEmpty34')-16)//8192==34
 for x in json.loads((P/'unused-PRG-review.json').read_text())['conditional_ten_page_proposal']:
  a=16+x['bank']*8192+x['start'];z=16+x['bank']*8192+x['end'];assert b['raw'][a:z]==b'\xff'*(z-a)
 assert(O/'code.bin').read_bytes()==(P/'code.bin').read_bytes()and(O/'data.bin').read_bytes()==(P/'data.bin').read_bytes()
 print('Actual new Main render candidate',sha(O/'candidate.nes'))
if __name__=='__main__':
 if '--prepare'in sys.argv:prepare()
 if '--build'in sys.argv:build()
