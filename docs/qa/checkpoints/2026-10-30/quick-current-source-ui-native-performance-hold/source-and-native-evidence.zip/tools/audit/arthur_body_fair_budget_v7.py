"""Isolate the exact capture guard with a smaller literal limit before import."""
from pathlib import Path
import sys,types
R=Path(__file__).resolve().parents[2]
def load(path):
    actual=R/'tools/audit/capture_budget.py';text=Path(path).read_text()
    original=actual.read_text();expected=original.replace('RUN_BYTES = 2_000_000_000','RUN_BYTES = 536_870_912').replace('receipt = preflight(output)','receipt = preflight(output, reserved_bytes=RUN_BYTES, reserved_files=RUN_FILES)')
    assert text==expected and text!=original
    assert original.count('RUN_BYTES = 2_000_000_000')==1 and original.count('receipt = preflight(output)')==1
    module=types.ModuleType('arthur_private_capture_budget_v7');module.__file__=str(actual);sys.modules[module.__name__]=module
    exec(compile(text,str(Path(path).resolve()),'exec'),module.__dict__)
    assert module.RUN_BYTES==536870912 and module.RUN_FILES==64 and module.PAYLOAD_BYTES==535870912
    assert module.WORKSPACE==R and module.WORKSPACE_BYTES==70_000_000_000
    return module
def run_function(module):
    actual=R/'tools/run_mesen.py';text=actual.read_text();anchor='from audit.capture_budget import run_capped'
    assert text.count(anchor)==1
    namespace=dict(__file__=str(actual),__name__='arthur_private_mesen_dependency_v7',PRIVATE_RUN_CAPPED=module.run_capped)
    exec(compile(text.replace(anchor,'run_capped = PRIVATE_RUN_CAPPED'),str(actual),'exec'),namespace)
    return namespace['run']
