"""Bounded real Main foreign/dispatch/IRQ controls. No native NMI or gameplay claim."""
from pathlib import Path
import collections,json,re,sys
import prepare_smb2_roster_main_v2 as B
sys.path.insert(0,str(B.ROOT/'tools/audit'))
from link_pit_rygar_sophia_audit_cpu import Arena,scoped_load
from check_tmnt_render_oa import address,location
from verify_native_relocation import NesMPU
from current_roster_compact_11_v1 import BASE
import smb2_roster_main_controls_v2 as T

OUT=B.OUT
def key(b,n):return(address(b,n),(location(b,n)-16)//8192)
def make(b,raw,field=None,variant=0,mode=1):
    q=Arena(b,raw);T.setup(q,dict(kind='idle',face=1,hit=False))
    q.put(OperMode_Task=3,AreaType=1,CrossoverBehaviorVersion=mode,NmiDisable=255)
    if field:q.set(field,variant)
    q.array('GameTimerDisplay',[3,9,9]);q.invoke('NrFreshGameInit')
    return q

def same_live(qs,cs,context,traces):
    a,b=(q.m for q in qs)
    assert (cs[0].a,cs[0].x,cs[0].y,cs[0].p,cs[0].sp)==(cs[1].a,cs[1].x,cs[1].y,cs[1].p,cs[1].sp),('CPU',context)
    assert a.banks==b.banks,('banks',context,a.banks,b.banks)
    # All ZP, low stack100..159, all33SMC bytes, and all nonstack RAM exact.
    live=list(range(0x17b))+list(range(0x200,0x8000))
    bad=[(p,a[p],b[p])for p in live if a[p]!=b[p]]
    assert not bad,('liveRAM',context,bad[:12])
    assert a[0x1fc:0x200]==b[0x1fc:0x200],('outer live return',context)
    # Added real call frames leave different DEAD return-PC/saved-value bytes.
    # Record each actual last writer; this is not whole-stack byte equality.
    last=[{w['address']:w for w in t if 0x17b<=w['address']<0x1fc}for t in traces]
    differences=[]
    for p in range(0x17b,0x1fc):
        if a[p]==b[p]:continue
        writers=[]
        for q,l in zip(qs,last):
            w=l.get(p)
            if w:
                pc,bank=w['pc'],w['bank']
                if pc<0x8000:op=q.m[pc]
                else:op=q.b['raw'][16+bank*8192+(pc&8191)]
                assert op in[0x20,0x48,0x08],('non-call stack writer',context,p,w,op)
                writers.append(dict(**w,opcode=op))
            else:writers.append(None)
        assert any(writers),('unattributed changed dead stack',context,p)
        differences.append(dict(address=p,old=a[p],new=b[p],last_writers=writers))
    return len(differences)

def dispatch(b):
    gates=re.findall(r'^S2MainGate (\w+),(\w+),(\w+),(\d+)$',
        (B.ROOT/'src/smb2_roster_main_gates_v2.s').read_text(),re.M)
    assert len(gates)==30
    count=0
    for raw in range(256):
      for name,own,old,index in gates:
        q=Arena(b,raw);pc,bank=key(b,name);q.m.page(1,bank);q.set('CurrentBank',bank|128)
        c=NesMPU(memory=q.m,pc=pc);c.a,c.x,c.y,c.p,c.sp=0x55,3,6,0x79,0xfd;c.stPushWord(0x5aff)
        want=key(b,own if raw==25 else old)
        for _ in range(100):
            actual=(c.pc,q.m.banks[(c.pc-0x8000)//8192]if c.pc>=0x8000 else-1)
            if actual==want:break
            assert q.m[c.pc]!=0;c.step()
        else:raise AssertionError(('dispatch bound',raw,name,want,actual))
        assert(c.a,c.x,c.y)==(0x55,3,6),('dispatch AXY',raw,name)
        assert c.p&0xcf==0x49,('genuine FarCallCommon NZ, remainingP',raw,name,c.p)
        count+=1
    return count

def interrupt(c,q):
    m=q.m;before=(c.pc,c.a,c.x,c.y,c.p&0xcf,c.sp,m.banks.copy())
    smc=bytes(m[0x15a:0x17b]);zp=bytes(m[:0x100])
    private=bytes(m[0x5c00:0x5c80])+bytes(m[0x5f98:0x5fa0]);low=c.sp
    m[0x5204]=128
    assert not c.p&4
    c.irq();assert c.pc!=before[0]
    for _ in range(10000):
        low=min(low,c.sp);c.step()
        if(c.pc,c.sp)==(before[0],before[5]):break
    else:raise AssertionError('real IRQ did not return')
    assert(c.pc,c.a,c.x,c.y,c.p&0xcf,c.sp,m.banks)==before
    assert smc==bytes(m[0x15a:0x17b])and zp==bytes(m[:0x100])
    assert private==bytes(m[0x5c00:0x5c80])+bytes(m[0x5f98:0x5fa0])
    assert low>=0x7b,('IRQ overlaps live farcallSMC',low)
    return low

def irq_cases(b):
    q=T.arena(b,0,1,y=152);T.actor(q,0,x=112)
    # Every state in this snapshot was produced by complete actual Main calls.
    for _ in range(8):T.frame(q)
    snapshot=(bytes(q.m),q.m.banks.copy())
    old=NesMPU.step;visits=collections.Counter();sites=[]
    lo,hi=address(b,'S2MainBegin'),address(b,'S2MainEndCode')
    glo,ghi=address(b,'S2MainGatesBegin'),address(b,'S2MainGatesEnd')
    def observe(c):
        bank=c.memory.banks[(c.pc-0x8000)//8192]if c.pc>=0x8000 else-1
        site=(c.pc,bank);visits[site]+=1
        if bank==118 and lo<=c.pc<hi or bank==74 and glo<=c.pc<ghi or 0x15a<=c.pc<0x17b:
            if visits[site]==1:sites.append((c.pc,bank,1))
        return old(c)
    NesMPU.step=observe
    try:T.frame(q,64)
    finally:NesMPU.step=old
    rows=[]
    for site in sites:
        r=Arena(b,25);list.__setitem__(r.m,slice(None),snapshot[0]);r.m.banks=snapshot[1].copy()
        seen=collections.Counter();fired=False;low=255
        def step(c):
            nonlocal fired,low
            bank=c.memory.banks[(c.pc-0x8000)//8192]if c.pc>=0x8000 else-1
            at=(c.pc,bank);seen[at]+=1
            if not fired and(*at,seen[at])==site:
                low=interrupt(c,r);fired=True
            return old(c)
        NesMPU.step=step
        try:T.frame(r,64)
        finally:NesMPU.step=old
        assert fired,site
        assert bytes(r.m[0x5c00:0x5c80])==bytes(q.m[0x5c00:0x5c80])
        assert bytes(r.m[0x5f98:0x5fa0])==bytes(q.m[0x5f98:0x5fa0])
        rows.append(dict(pc=site[0],bank=site[1],minimum_SP=low))
    return rows

def main():
    proof=json.loads((OUT/'build-proof.json').read_text());assert B.bind(OUT/'candidate.nes')==proof['candidate']
    assert B.bind(B.__file__)==proof['tool']
    for x in proof['new_owned_sources']:assert B.bind(x['path'])==x
    bs=list(map(scoped_load,[B.ROOT/'build/smb2-roster-audio-v1/candidate.nes',OUT/'candidate.nes']))
    dispatch_count=dispatch(bs[1]);rows=[]
    identities=[(n,x[1],x[2],x[3])for n,x in BASE.items()]
    identities += [('popo',20,'IcVariant',0),('nana',20,'IcVariant',1),('alex',21,'RcVariant',0),
        ('ryan',21,'RcVariant',1),('sunny',23,None,0),('celeste',0,'MarioVariant',4)]
    for name,raw,field,variant in identities:
      for mode in [0,1]:
        qs=[make(b,raw,field,variant,mode)for b in bs];history=[[],[]]
        for index,mask in enumerate([0,1,129,0]):
            outputs=[]
            for j,q in enumerate(qs):
                q.put(SavedJoypadBits=mask,SavedJoypad1Bits=mask)
                c,t=q.invoke('GameLoop');outputs.append(c);history[j]+=t
            dead=same_live(qs,outputs,(name,mode,index),history)
            rows.append(dict(identity=name,mode=mode,mask=mask,cycles_old=outputs[0].processorCycles,
                cycles_new=outputs[1].processorCycles,changed_dead_stack_bytes=dead))
    rise=[]
    for name,raw,field,variant in identities:
      if name not in ['mario','samus','roll','mario3','grant','mac','chip','zelda2','sunny']:continue
      for mode in [0,1]:
       for phase in [0,1]:
        for state in [1,5,16,17,128]:
         for timer in [0,32]:
            qs=[make(b,raw,field,variant,mode)for b in bs];history=[[],[]]
            for j,q in enumerate(qs):
                T.actor(q,5,kind=0x2e,x=176,y=152,item=0)
                q.invoke('RlPrepareDispatch',x=5) # genuine selected-family metadata.
                q.set('Enemy_State',state,5);q.put(FrameCounter=phase,TimerControl=timer)
            outputs=[]
            for j,q in enumerate(qs):
                c,t=q.invoke('GameLoop');outputs.append(c);history[j]+=t
            dead=same_live(qs,outputs,(name,mode,phase,state,timer),history)
            rise.append(dict(identity=name,mode=mode,phase=phase,state=state,timer=timer,
                cycles_old=outputs[0].processorCycles,cycles_new=outputs[1].processorCycles,
                changed_dead_stack_bytes=dead))
    irqs=irq_cases(bs[1])
    assert B.bind(OUT/'candidate.nes')==proof['candidate'],'Private ROM changed during CPU campaign'
    for r in proof['new_owned_sources']:assert B.bind(r['path'])==r
    result=dict(passed=True,source_CPU_only=True,native=False,candidate=proof['candidate'],
        foreign_parent=B.bind(B.ROOT/'build/smb2-roster-audio-v1/candidate.nes'),dispatch_actual_target_controls=dispatch_count,
        foreign_Main_rows=rows,foreign_rising_Main_rows=rise,actual_IRQ_rows=irqs,minimum_IRQ_SP=min(r['minimum_SP']for r in irqs),
        exact='AXYP/SP, A/C/E hardware banks, all nonstack RAM, lowstack100..159 and all33SMC at complete Main return',
        limits='Added real call frames leave different dead stack17B..1FB bytes; actual last writer opcodes checked, no whole-stack byte identity. Explicit NmiClock phase input; no raw25 shared NMI/audio/PPU execution.',
        tool=B.bind(__file__))
    p=OUT/'caller-controls.json';p.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(dict(passed=True,dispatch=dispatch_count,foreign_Main_calls=len(rows),foreign_rising_Main_calls=len(rise),IRQ_sites=len(irqs),
        minimum_IRQ_SP=result['minimum_IRQ_SP'],proof=B.bind(p)),indent=2))

if __name__=='__main__':main()
