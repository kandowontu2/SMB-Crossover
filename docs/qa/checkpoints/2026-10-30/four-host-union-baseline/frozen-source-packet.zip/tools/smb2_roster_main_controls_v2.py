"""Actual complete Main CPU campaigns; no old/unwired raw25 NMI execution."""
from pathlib import Path
import collections,hashlib,json,sys
import prepare_smb2_roster_main_v2 as B
sys.path.insert(0,str(B.ROOT/'tools/audit'))
from link_pit_rygar_sophia_audit_cpu import Arena,scoped_load
from check_tmnt_render_oa import address,location
from verify_native_relocation import NesMPU
from current_rygar_powerups_prepare_v1 import setup
OUT=B.OUT

def actor(q,slot,kind=6,x=148,y=184,item=None):
    # Disclosed source arena setup. No acquired HP/ammo/ownership is seeded.
    data=dict(Enemy_Flag=1,Enemy_ID=kind,Enemy_State=128 if item is not None else 0,
        Enemy_BoundBoxCtrl=3 if item is not None else 9,Enemy_X_Position=x,Enemy_PageLoc=0,
        Enemy_Y_Position=y,Enemy_Y_HighPos=1,Enemy_X_Speed=0,Enemy_Y_Speed=0,
        Enemy_Y_MoveForce=0,Enemy_MovingDir=2,Enemy_SprAttrib=0,Enemy_CollisionBits=0)
    if item is not None:data['PowerUpType']=item
    for n,v in data.items():q.set(n,v,slot)

def arena(b,variant,mode,y=176):
    q=Arena(b,25);setup(q,dict(kind='idle',face=1,hit=False))
    q.put(OperMode_Task=3,AreaType=1,CrossoverBehaviorVersion=mode,NmiDisable=255,
        S2Variant=variant,Player_Y_Position=y)
    q.array('GameTimerDisplay',[3,9,9]);q.invoke('NrFreshGameInit')
    return q

def frame(q,mask=0):
    q.put(SavedJoypadBits=mask,SavedJoypad1Bits=mask)
    q.invoke('S2NmiClock')       # Explicit phase input, never a native NMI claim.
    return q.invoke('GameLoop')

def components(b,hits):
    rows=[]
    for variant in range(4):
      for mode in [0,1]:
        q=arena(b,variant,mode)
        actor(q,0,x=112)
        frame(q)
        assert q.get('S2Health')==15 and q.get('S2Hurt')==126,('actual side injury',variant,mode)
        q.invoke('EraseEnemyObject',x=0)
        for protection_age in range(180):
            frame(q)
            if q.get('S2Hurt')==0:break
        else:raise AssertionError('source changing-size + natural protection expiry')
        actor(q,5,kind=0x2e,x=112,item=0)
        hits.clear();frame(q)
        assert hits['S2MainPickup']==1 and q.get('Enemy_Flag',5)==0
        assert q.get('S2Health')==47 and q.get('S2MaxHealth')==1
        for _ in range(36):frame(q)
        assert q.get('S2Size')==0 and q.get('S2State')==0
        actor(q,5,kind=0x2e,x=112,item=1)
        hits.clear();frame(q)
        assert hits['S2MainPickup']==1 and q.get('S2Vegetables')==3
        frame(q,64)
        assert q.get('S2Vegetables')==2 and q.get('S2Holding')==1
        for _ in range(32):
            frame(q)
            if q.get('S2State')==0:break
        else:raise AssertionError('real lift completion')
        frame(q);frame(q)       # actual normal carry geometry after lift-state return.
        actor(q,0,x=140)
        frame(q,64)
        assert q.get('S2Holding')==0 and q.get('S2ObjectProjectile')
        for age in range(24):
            frame(q)
            if q.get('Enemy_State',0)&32:break
        else:raise AssertionError(('real thrown-vegetable contact',variant,mode))
        assert q.get('S2ObjectState')==0 and q.get('S2Vegetables')==2
        # Genuine ordinary shared life pickup AFTER earned health/vegetables.
        q.invoke('EraseEnemyObject',x=0)
        actor(q,5,kind=0x2e,x=112,item=3)
        lives=q.get('NumberofLives')
        for _ in range(50):frame(q)  # native popup awards the life later.
        assert q.get('NumberofLives')==(lives+1)&255
        assert q.get('S2Health')==47 and q.get('S2MaxHealth')==1 and q.get('S2Vegetables')==2
        rows.append(dict(variant=variant,mode=mode,actual_injury=16,natural_protection_expiry=protection_age+1,
            physical_mushroom_health=47,physical_flower_reserve=3,successful_lift_cost=1,
            native_throw_defeat_age=age+1,native_drop_score_consumer=True,actual_1Up_preserves_earned=True))
        # Actual player/actor contact: Easy ordinary stomp, Hard stand + B lift.
        q=arena(b,variant,mode,y=152);actor(q,0,x=112)
        stood=False
        for _ in range(32):
            hits.clear();frame(q)
            if mode and hits['S2StandOnActor']:stood=True;break
            if not mode and q.get('Enemy_State',0)==4:break
        else:raise AssertionError(('actual top contact',variant,mode))
        if not mode:
            assert hits['S2MainStomp'] and q.get('S2VY')&128
        else:
            assert stood and q.get('S2Air')==0 and q.get('S2Health')==31
            frame(q,64)
            assert q.get('S2Holding')==1 and q.get('S2ObjectHost0')==0
            for native_lift_age in range(128):
                frame(q)
                assert (q.get('Enemy_X_Position'),q.get('Enemy_Y_Position'))==(
                    q.get('S2X',1),q.get('S2Y',1))
                assert q.get('Enemy_State',0)==0 and q.get('S2Health')==31
                if q.get('S2State')==0:break
            else:raise AssertionError('actual native-enemy heavy lift completion')
            rows[-1]['native_heavy_lift_completed_age']=native_lift_age+1
            # Fresh real throw; source retirement must also end the actual
            # native slot. No lifetime/result byte is seeded.
            frame(q,64)
            assert q.get('S2Holding')==0 and q.get('S2ObjectProjectile')
            for retire_age in range(96):
                frame(q)
                if q.get('S2ObjectState')==0:break
            else:raise AssertionError('source throw retirement')
            assert q.get('Enemy_Flag',0)==0 and q.get('S2ObjectHost0')==255
            rows[-1]['native_throw_actual_retirement_age']=retire_age+1
            # Distinct actual epoch authority also handles a real held record.
            q=arena(b,variant,mode,y=152);actor(q,0,x=112)
            for _ in range(32):
                hits.clear();frame(q)
                if hits['S2StandOnActor']:break
            else:raise AssertionError('second source stand')
            frame(q,64);assert q.get('S2Holding')==1
            q.invoke('EraseEnemyObject',x=0)
            assert q.get('S2ObjectState')==q.get('S2Holding')==0
            # A genuine native battle-state writer must take ownership back
            # before the next carried-actor geometry/AI prelude.
            q=arena(b,variant,mode,y=152);actor(q,0,x=112)
            for _ in range(32):
                hits.clear();frame(q)
                if hits['S2StandOnActor']:break
            else:raise AssertionError('battle takeover source stand')
            frame(q,64);assert q.get('S2Holding')==1
            q.invoke('ShellOrBlockDefeat',x=0)
            assert q.get('Enemy_State',0)&32
            frame(q)
            assert q.get('S2ObjectState')==q.get('S2Holding')==0
            assert q.get('Enemy_Flag',0) and q.get('Enemy_State',0)&32
            rows[-1]['actual_native_battle_takeover']=True
        rows[-1]['top_contact']='source stand/lift/epoch erase' if mode else 'native stomp + source bounce'
    return rows

def world_components(b):
    rows=[]
    for mode in [0,1]:
        q=arena(b,0,mode);q.set('Block_Buffer_1',0xc2,9*16+7)
        frame(q)
        assert q.get('Block_Buffer_1',9*16+7)==0 and q.get('CoinTallyFor1Ups')==1
        q=arena(b,0,mode,y=144);q.put(Player_X_Position=124)
        q.set('Block_Buffer_1',0x10,9*16+7);q.set('Block_Buffer_1',0x11,9*16+8)
        frame(q,4)
        assert q.get('GameEngineSubroutine')==3 and q.get('ChangeAreaTimer')==48
        frame(q,4)
        assert q.get('Player_Y_Position')==145 and q.get('ChangeAreaTimer')==47
        q=arena(b,0,mode);q.set('Block_Buffer_1',0xc1,8*16+7)
        born=None
        for i in range(76):
            # Native FrameCounter is an explicit external phase input here;
            # the unadmitted shared raw25 NMI is never executed.
            q.set('FrameCounter',i);frame(q,128 if i<4 else 0)
            if q.get('Enemy_ID',5)==0x2e and born is None:
                born=i
                assert q.get('InvPickupOwner',5)==25 and q.get('InvPickup',5)==0xfc
        assert born==2 and q.get('Enemy_State',5)==128 and q.get('Enemy_Y_Position',5)==135
        assert q.get('PowerUpType',5)==1  # authentic SMB block large-form selection.
        rows.append(dict(mode=mode,actual_coin_erase_reward=True,actual_pipe_entry_and_native_step=True,
            actual_A_head_bump_producer=True,pickup_owner=25,born_Main=born,full_native_rise_phase_input=True,
            mature_type=1,mature_Y=135,scope='This producer/rise case does not claim its later collection or native imagery.'))
    return rows

def main():
    proof=json.loads((OUT/'build-proof.json').read_text());rom=OUT/'candidate.nes'
    assert B.bind(rom)==proof['candidate']
    assert B.bind(B.__file__)==proof['tool'],'Source builder changed since last successful link'
    for r in proof['new_owned_sources']:assert B.bind(r['path'])==r,'Source changed since last successful link'
    b=scoped_load(rom)
    names=['GameLoop','S2MainGame','S2MainPlayer','S2Movement','S2N8A41','S2MainWorld',
        'ScrollHandler','PlayerBGCollision','S2EndFrame','S2MainBox','S2Graphics','S2DrawObjects','S2ColdInit',
        'S2MainPickup','S2GiveItem','S2MainBody','S2StandOnActor','S2MainStomp','S2ActorEpochChanged']
    sites={(address(b,n),(location(b,n)-16)//8192):n for n in names};hits=collections.Counter();lowest=255;whole_main_calls=0
    old_step=NesMPU.step
    def step(c):
        nonlocal lowest,whole_main_calls
        bank=c.memory.banks[(c.pc-0x8000)//8192]if c.pc>=0x8000 else-1
        if(c.pc,bank)in sites:
            n=sites[(c.pc,bank)];hits[n]+=1
            if n=='GameLoop':whole_main_calls+=1
        lowest=min(lowest,c.sp)
        return old_step(c)
    NesMPU.step=step
    rows=[];earned=[];world=[]
    try:
        for variant in range(4):
            for mode in[0,1]:
                q=Arena(b,25);setup(q,dict(kind='idle',face=1,hit=False))
                q.put(OperMode_Task=3,AreaType=1,CrossoverBehaviorVersion=mode,NmiDisable=255,S2Variant=variant)
                q.array('GameTimerDisplay',[3,9,9]);hits.clear();q.invoke('NrFreshGameInit')
                assert hits['S2ColdInit']==1 and q.get('S2Ready')==0xb2
                assert q.get('S2Health')==31 and q.get('S2Vegetables')==0
                for frame,mask in enumerate([0]*4+[1]*8+[0x81]*18+[1]*16+[0]*8):
                    q.put(SavedJoypadBits=mask,SavedJoypad1Bits=mask)
                    # Explicit source phase service input. This is NOT the
                    # unadmitted native host NMI or a native cadence claim.
                    q.invoke('S2NmiClock');hits.clear()
                    c,trace=q.invoke('GameLoop')
                    assert hits['S2MainGame']==1 and hits['S2Movement']==1,('sole movement',variant,mode,frame,hits)
                    assert hits['ScrollHandler']==1 and hits['PlayerBGCollision']==0,('sole terrain/camera',dict(hits))
                    assert hits['S2EndFrame']==1,('single post-render timer callback',dict(hits))
                    assert q.get('GameEngineSubroutine')==8,('unexpected engine',frame,q.get('GameEngineSubroutine'))
                    rows.append(dict(variant=variant,mode=mode,frame=frame,mask=mask,X=q.get('Player_X_Position'),
                        Y=q.get('Player_Y_Position'),source_VY=q.get('S2VY'),host_VY=q.get('Player_Y_Speed'),
                        health=q.get('S2Health'),cycles=c.processorCycles))
        earned=components(b,hits)
        world=world_components(b)
    except BaseException as error:
        p=OUT/'first-main-control-negative.json'
        if not p.exists():p.write_text(json.dumps(dict(error=repr(error),candidate=B.bind(rom),last_rows=rows[-8:],
            actual_hits=dict(hits),minimum_SP=lowest),indent=2)+'\n')
        raise
    finally:NesMPU.step=old_step
    assert B.bind(rom)==proof['candidate'],'Private ROM changed during CPU campaign'
    for r in proof['new_owned_sources']:assert B.bind(r['path'])==r
    dest=OUT/'main-controls.json';dest.write_text(json.dumps(dict(passed=True,source_CPU_only=True,native_run=False,
        candidate=proof['candidate'],actual_complete_Main_calls=whole_main_calls,rows=rows,earned_components=earned,world_components=world,minimum_SP=lowest,tool=B.bind(__file__),
        limits='Controlled flat source arenas; explicit phase-service input, no native NMI/PPU/DMC/cadence/cold-menu exposure.'),indent=2)+'\n')
    print(json.dumps(dict(passed=True,actual_complete_Main_calls=whole_main_calls,basic_motion_rows=len(rows),minimum_SP=lowest,proof=B.bind(dest)),indent=2))

if __name__=='__main__':main()
