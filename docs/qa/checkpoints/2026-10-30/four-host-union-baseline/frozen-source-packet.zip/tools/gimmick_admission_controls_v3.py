"""Finite compiled host controls. Typed CPU arenas; no native PPU/cadence claim."""
from pathlib import Path
import argparse,collections,hashlib,json,sys
R=Path(__file__).resolve().parents[1];O=R/'build/gimmick-admission-v3'
sys.path[:0]=[str(R/'tools/audit')]
from link_pit_rygar_sophia_audit_cpu import Arena,scoped_load
from check_tmnt_render_oa import address,location
from verify_native_relocation import NesMPU
from current_rygar_powerups_prepare_v1 import setup
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
B=scoped_load(O/'candidate.nes')
def arena(mode=0):
 q=Arena(B,26);setup(q,dict(kind='idle',face=1,hit=False))
 q.put(OperMode_Task=3,AreaType=1,CrossoverBehaviorVersion=mode,NmiDisable=255,PlayerStatus=0)
 q.array('GameTimerDisplay',[3,9,9]);q.invoke('NrFreshGameInit')
 assert q.get('GmReady')==0x47 and q.get('GmRam002B')==q.get('GmRam0346')==2
 return q
def frame(q,mask=0):
 q.put(SavedJoypadBits=mask,SavedJoypad1Bits=mask)
 # Explicit modeled native NMI phase. This is not installed native wiring.
 q.set('FrameCounter',(q.get('FrameCounter')+1)&255)
 q.invoke('GmNmiClock') # Explicit source phase service; NOT installed host NMI.
 return q.invoke('GameLoop')
def actor(q,kind=0):
 for n,v in dict(Enemy_Flag=1,Enemy_ID=0x2e,Enemy_State=128,Enemy_BoundBoxCtrl=3,
  Enemy_X_Position=q.get('Player_X_Position'),Enemy_PageLoc=q.get('Player_PageLoc'),Enemy_Y_Position=q.get('Player_Y_Position')+8,Enemy_Y_HighPos=1,
  Enemy_X_Speed=0,Enemy_Y_Speed=0,Enemy_Y_MoveForce=0,Enemy_MovingDir=2,
  Enemy_SprAttrib=0,Enemy_CollisionBits=0,PowerUpType=kind).items():q.set(n,v,5)
 q.invoke('NrPrepare',x=5)
def collect(q,kind):
 actor(q,kind)
 for _ in range(4):
  c,t=frame(q)
  if not q.get('Enemy_Flag',5):return c,t
 raise AssertionError(('actual actor not collected',kind))
def foreign():
 sys.path.insert(0,str(R/'tools'))
 from gimmick_resident_selector_controls_v1 import cold
 from smb2_roster_main_callers_v2 import same_live
 from current_roster_compact_11_v1 import BASE
 parent=scoped_load(R/'build/pit-retold-host-v3/candidate.nes');bs=[parent,B]
 identities=[(n,x[1],x[2],x[3])for n,x in BASE.items()]
 identities += [('popo',20,'IcVariant',0),('nana',20,'IcVariant',1),('alex',21,'RcVariant',0),('ryan',21,'RcVariant',1),('sunny',23,None,0),('celeste',0,'MarioVariant',4),('kamikaze',0,'MarioVariant',3)]
 rows=[]
 for name,raw,field,variant in identities:
  for mode in [0,1]:
   qs=[cold(b,raw,field,variant,mode)for b in bs];history=[q._prior.copy()for q in qs]
   for mask in [0,1,129,0]:
    cs=[]
    for i,q in enumerate(qs):
     q.put(SavedJoypadBits=mask,SavedJoypad1Bits=mask);c,t=q.invoke('GameLoop');cs.append(c);history[i]+=t
    dead=same_live(qs,cs,(name,mode,mask),history)
    rows.append(dict(identity=name,mode=mode,mask=mask,cycles_parent=cs[0].processorCycles,cycles_new=cs[1].processorCycles,changed_dead_stack_bytes=dead))
  if len(rows)%64==0:print('foreign Main',len(rows),flush=True)
 p=O/'foreign-main-controls.json';p.write_text(json.dumps(dict(passed=True,candidate=sha(O/'candidate.nes'),parent=sha(R/'build/pit-retold-host-v3/candidate.nes'),rows=rows,scope='Complete genuine Main comparison, both modes and four input states for44 parent identities/variants. All live AXYP/SP/banks/RAM and33SMC exact. Only actual attributed dead push frames differ; original same_live assertions unchanged. CPU typed arenas, no native cadence/PPU.'),indent=2)+'\n')
 print('foreign PASS',len(rows),min(x['cycles_new']-x['cycles_parent']for x in rows),max(x['cycles_new']-x['cycles_parent']for x in rows),flush=True)
def main():
 rows=[];proof=dict(candidate=sha(O/'candidate.nes'),scope=__doc__,native=False)
 try:
  q=arena()
  for i,mask in enumerate([0]*4+[1]*8+[129]*18+[1]*16+[0]*8):
   c,t=frame(q,mask)
   assert q.get('GameEngineSubroutine')==8,('engine',i,q.get('GameEngineSubroutine'))
   rows.append([i,mask,q.get('Player_X_Position'),q.get('Player_Y_Position'),q.get('GmRam00CC'),q.get('GmRam00C2'),c.processorCycles])
  q=arena();c,t=collect(q,0)
  assert q.get('Enemy_Flag',5)==0 and q.get('GmRam002B')==q.get('GmRam0346')==3,('physical actual collector',q.get('Enemy_Flag',5),q.get('GmRam002B'),q.get('GmRam0346'))
  assert q.get('PlayerStatus')==1,('earned Mushroom must drive genuine native later Flower selection',q.get('PlayerStatus'))
  collect(q,0);assert q.get('GmRam002B')==4 and q.get('GmRam0346')==4
  for count in [1,2,3]:
   collect(q,1);assert q.get('GmRam0039')==count
  assert[q.get('GmRam0036',i)for i in range(3)]==[2,3,2]
  collect(q,1)
  assert q.get('GmRam0039')==3 and not q.get('GuestPowerupActive')and q.get('PlayerStatus')==1,('full earned capacity must not enter legacy Mario Fire transform',q.get('GmRam0039'),q.get('GuestPowerupActive'),q.get('PlayerStatus'),q.get('GameEngineSubroutine'))
  proof.update(passed=True,rows=rows,mature_mushroom_actual_collector=True,earned_capacity4_and_three_specials=True)
 except BaseException as e:
  proof.update(passed=False,error=repr(e),rows=rows[-8:])
  if not(O/'first-admission-control-negative.json').exists():(O/'first-admission-control-negative.json').write_text(json.dumps(proof,indent=2)+'\n')
  raise
 finally:(O/'admission-controls-draft.json').write_text(json.dumps(proof,indent=2)+'\n')
 print(json.dumps(proof))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('--foreign',action='store_true');a=p.parse_args()
 if a.foreign:foreign()
 else:main()
