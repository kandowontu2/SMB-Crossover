"""Private full-source SMB2 Main successor; no shared files/menu/NMI hooks."""
from pathlib import Path
import configparser,hashlib,json,re,subprocess,sys
import prepare_smb2_roster_audio_v1 as A
ROOT=A.ROOT;OUT=ROOT/'build/smb2-roster-main-v2';bind=A.bind
FROZEN=ROOT/'build/smb2-roster-audio-v1/handoff.json'
FROZEN_SHA='2daf42602a8a3a50a813c04e3c4a7a10486d131897945d2f2f971fcaba330512'

def main():
    assert A.digest(FROZEN.read_bytes())==FROZEN_SHA
    A.Rel.check_parent();h=json.loads(FROZEN.read_text())
    for key in['owned_files','input_bindings','output_bindings']:
        for r in h[key]:assert bind(r['path'])==r,r['path']
    OUT.mkdir(exist_ok=True);overlay=OUT/'overlay';(overlay/'src').mkdir(parents=True,exist_ok=True)
    changed=[]
    def stage(name,fn):
        p=ROOT/'src'/name;old=p.read_text();new=fn(old)
        assert old!=new,name
        q=overlay/'src'/name
        guarded='.if ::ENABLE_MMC5_EXPANDED .and ::MAPPER_MMC5\n'+new+'\n.else\n'+old+'\n.endif\n'
        q.write_text(guarded,newline='\n');changed.append(dict(original=bind(p),staged=bind(q)))
    def sub(text,old,new,n=1):
        assert text.count(old)>=n,(old,text.count(old));return text.replace(old,new,n)
    stage('guest_injury.s',lambda t:sub(t,'Run:\n  farcall GameRoutines,jmp','Run:\n  farcall S2MGames,jmp'))
    def nr(t):
        for old,new in[
            ('NrGraphics,IcGraphics,RcGraphics,SunnyGraphicsIntegrated,RlGraphicsDispatch','NrGraphics,IcGraphics,RcGraphics,SunnyGraphicsIntegrated,S2MGraphics'),
            ('NrDraw,IcDraw,RcDraw,SunnyDraw,RlDrawDispatch','NrDraw,IcDraw,RcDraw,SunnyDraw,S2MDraw'),
            ('farcall JnBodyDispatch,jmp','farcall S2MBody,jmp'),
            ('NrInjury,IcInjuryStart,RcInjuryStart,SunnyInjuryIntegrated,JnInjuryStartDispatch','NrInjury,IcInjuryStart,RcInjuryStart,SunnyInjuryIntegrated,S2MInjury'),
            ('NrLegacyInjuryStatus,IcInjuryStatus,RcInjuryStatus,SunnyInjuryStatus,JnInjuryStatusDispatch','NrLegacyInjuryStatus,IcInjuryStatus,RcInjuryStatus,SunnyInjuryStatus,S2MStatus'),
            ('NrDeathStart,IcDeathStart,RcDeathStart,SunnyDeathStart,JnInventoryDeathDispatch','NrDeathStart,IcDeathStart,RcDeathStart,SunnyDeathStart,S2MDeathStart'),
            ('NrDeath,IcDeathUpdate,RcDeath,SunnyNativeDeath,JnDeathDispatch','NrDeath,IcDeathUpdate,RcDeath,SunnyNativeDeath,S2MDeath'),
            ('NrVisible,IcVisible,RcVisible,SunnyVisible,JnVisibleDispatch','NrVisible,IcVisible,RcVisible,SunnyVisible,S2MVisible'),
            ('NrHead,IcHead,RcHeadProbe,SunnyHead,JnHeadDispatch','NrHead,IcHead,RcHeadProbe,SunnyHead,S2MHead'),
            ('farcall RlAdderDispatch,jmp','farcall S2MAdder,jmp'),
            ('farcall RlBoxDispatch,jmp','farcall S2MBoxProfile,jmp'),
            ('farcall Z2SideAdmission,jmp','farcall S2MSide,jmp'),
            ('farcall JnResetDispatch,jmp','farcall S2MScene,jmp'),('farcall JnPickupDispatch,jmp','farcall S2MPickup,jmp'),
            ('farcall VvUiDispatch,jmp','farcall S2MUi,jmp'),('farcall CmHostFresh,jmp','farcall S2MFresh,jmp'),
            ('farcall X5GetPlayerColors,jmp','farcall S2MColors,jmp'),
            ('farcall RlWeaponsDispatch\n','farcall S2MWeapons\n')]:t=sub(t,old,new)
        return t
    stage('new_roster_dispatch.s',nr)
    (overlay/'src/little_mac.s').write_bytes((ROOT/'src/little_mac.s').read_bytes())
    stage('little_mac_pickups.s',lambda t:sub(sub(sub(t,'LmGate NrPrepare','LmGate S2MPrepare'),'LmGate NrPrivate','LmGate S2MPrivate'),'LmGate NrRise','LmGate S2MRise'))
    stage('player.s',lambda t:sub(t,'farcall LmBoundingBoxGate','farcall S2MBox'))
    def objects(t):
        t=sub(sub(t,'farcall NrPickupCollision','farcall S2MMature'),'farcall Z2PositionOnPlatform','farcall S2MPlatform')
        start=t.index('GrowThePowerUp:\n');end=t.index('ChkPUSte:',start)
        original=t[start:end]
        assert original.count('farcall LmRiseGate')==1
        # Approved exact52B original span. Genuine callable entry remains at
        # B7BA; its cold body moves to CORE118, freeing a29B A0 owner gate.
        t=t[:start]+'''GrowThePowerUp:
  farcall S2MainGrow,jmp
S2MainEnemyAdmission:
  lda SelectedCharacter
  cmp #25
  bne Foreign
  lda #<S2MainCarryPrelude
  SMC_StoreLowByte FarcallJmpTarget,a
  lda #>S2MainCarryPrelude
  SMC_StoreHighByte FarcallJmpTarget,a
  lda #.bank(S2MainCarryPrelude)|MMC5_PRG_ROM
  jmp FarCallCommon
Foreign:
  lda #0
  sta Enemy_SprAttrib,x
  clc
  rts
  .res 52-(*-GrowThePowerUp),$ea
'''+t[end:]
        start=t.index('RunNormalEnemies:\n');end=t.index('.if ::ENABLE_CROSSOVER',start)
        original=t[start:end]
        assert 'sta Enemy_SprAttrib,x' in original
        t=t[:start]+'''RunNormalEnemies:
  jsr S2MainEnemyAdmission
  bcs SkipMove
'''+t[end:]
        return t
    stage('object.s',objects)
    stage('level_tiles.s',lambda t:sub(t,'farcall CrossoverLevelEnemyInit, jmp','farcall S2MSpawn, jmp'))
    stage('collision.s',lambda t:sub(t,'farcall MarioSourceBodyImmunity','farcall S2MImmunity'))
    def erase(t):
        start=t.index('.proc RyuPlatformErase');end=t.index('.endproc',start)
        t=t[:start]+''' .proc RyuPlatformErase
  php
  farcall S2MainErase
  plp
  rts
  .res 4,$ea
  .assert *-RyuPlatformErase=25,lderror,"Original erase caller footprint"
'''+t[end:]
        return t
    stage('ryu_platform.s',erase)
    stage('megaman_environment.s',lambda t:sub(t,'farcall X5StompDispatch','farcall S2MStomp'))
    def game(t):
        start=t.index('.proc HpGraphicsBankCopy');end=t.index('.endproc',start)
        old=t[start:end];new=old.replace('HpPrepareNativePointers','S2MainNativePointers')
        new=sub(new,'jmp CrossoverGraphicsBank','rts\n  nop\n  nop')
        t=t[:start]+new+t[end:]
        t=sub(t,'farcall ResetPalStar','farcall S2MEnd')
        t=sub(t,'farcall CyclePlayerPalettePreload','farcall S2MEndStar')
        return t
    stage('game.s',game)
    entry=(ROOT/'src/entrypoint.s').read_text()+'''
.if ::ENABLE_MMC5_EXPANDED .and ::MAPPER_MMC5
.include "smb2_roster.s"
.include "smb2_roster_palette_v2.s"
.include "smb2_roster_audio.s"
.include "smb2_roster_main_v2.s"
.include "smb2_roster_main_gates_v2.s"
.endif
'''
    (overlay/'src/entrypoint.s').write_text(entry,newline='\n')
    cfg=(ROOT/'build/smb2-roll-relocation-v1/overlay/smb1base-mmc5-expanded.cfg').read_text()
    old='TMNT_CHR_TAIL: start=$bd000,size=$13000,type=ro,fill=yes,file=%O,fillval=$00;'
    assert cfg.count(old)==1
    cfg=cfg.replace(old,'''TMNT_CHR_TAIL: start=$bd000,size=$a000,type=ro,fill=yes,file=%O,fillval=$00;
    S2_MAIN_CHR_MEM: start=$c7000,size=$3000,type=ro,fill=yes,file=%O,fillval=$00;
    S2_MAIN_CHR_AFTER: start=$ca000,size=$6000,type=ro,fill=yes,file=%O,fillval=$00;''')
    marker='}\nSYMBOLS {';assert cfg.count(marker)==1
    cfg=cfg.replace(marker,'    SMB2_ROSTER_CHR:load=S2_MAIN_CHR_MEM,type=ro;\n'+marker)
    (overlay/'smb1base-mmc5-expanded.cfg').write_text(cfg,newline='\n')
    objects=OUT/'objects';objects.mkdir(exist_ok=True)
    (objects/'entrypoint.s').write_bytes((overlay/'src/entrypoint.s').read_bytes())
    (objects/'main.c').write_bytes((ROOT/'src/main.c').read_bytes())
    (objects/'asset.s').write_text('.segment "SMB2_ROSTER_CHR"\n.incbin "chr/characters/smb2-roster.chr"\n')
    options=configparser.ConfigParser();options.optionxform=str;options.read(ROOT/'build_options.ini')
    defs={k:v for section in options.values()for k,v in section.items()}
    defs.update(MAPPER_MMC3='0',MAPPER_MMC5='1',ENABLE_CROSSOVER='1',ENABLE_MMC5_EXPANDED='1')
    cc=ROOT/'tools/Windows/cc65/bin';dest=OUT/'candidate.nes'
    command=[str(cc/'cl65.exe'),'--cpu','6502x','-t','nes','-g','-Oisr','-vm','-T','-C',str(overlay/'smb1base-mmc5-expanded.cfg'),
        '--ld-args','--dbgfile,'+str(dest.with_suffix('.dbg')),'--include-dir',str(ROOT),
        '--asm-include-dir',str(overlay/'src'),'--asm-include-dir',str(ROOT/'src'),'--asm-include-dir',str(ROOT),
        '--bin-include-dir',str(ROOT),'-m',str(dest.with_suffix('.map')),'-Ln',str(dest.with_suffix('.lbl')),'-o',str(dest)]
    for k,v in defs.items():command+=['--asm-define',k+'='+v,'-D',k+'='+v]
    command += [str(objects/'main.c'),str(objects/'entrypoint.s'),str(objects/'asset.s')]
    r=subprocess.run(command,cwd=ROOT,capture_output=True,text=True);(OUT/'launcher.txt').write_text(r.stdout+r.stderr)
    if r.returncode:
        first=OUT/'first-link-negative.txt'
        if not first.exists():first.write_text(r.stdout+r.stderr)
        raise AssertionError(r.stdout[-3000:]+r.stderr[-3000:])
    sys.path.insert(0,str(ROOT/'tools'));from prepare_cv3_dmc_mirror import prepare
    prepare(ROOT,dest)
    raw=bytearray(dest.read_bytes());fixed=raw[16+127*8192:16+128*8192]
    source=A.S.ROM.read_bytes();plan=json.loads((ROOT/'build/smb2-roster-audio-plan-v1.json').read_text())
    for clone in plan['samples']:
        copy=bytearray(fixed)
        for e in clone['entries']:
            at=int(e['target'],16)-0xe000;p=int(e['source'],16);n=e['bytes']
            blob=source[16+114688+p-0xc000:16+114688+p-0xc000+n]
            assert A.digest(blob)==e['sha256'];copy[at:at+n]=blob
        assert copy[:0x1140]==fixed[:0x1140]and copy[0x1e11:]==fixed[0x1e11:]
        raw[16+clone['bank']*8192:16+(clone['bank']+1)*8192]=copy
    dest.write_bytes(raw)
    proof=dict(status='PRIVATE_MAIN_DRAFT_FULL_LINK_NOT_QUALIFIED_NO_NATIVE',candidate=bind(dest),audio_component=bind(FROZEN),
        canonical_parent=bind(A.Rel.BASE),changed_shared_overlay_only=changed,command=command,
        new_owned_sources=[bind(ROOT/'src'/n)for n in['smb2_roster_main_v2.s','smb2_roster_main_gates_v2.s']],
        final_current127_clones=[119,120,125],new_RAM=False,new_menu=False,NMI_audio_scheduling=False,tool=bind(__file__))
    (OUT/'build-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
    print(json.dumps(dict(candidate=bind(dest),proof=bind(OUT/'build-proof.json')),indent=2))

if __name__=='__main__':main()
