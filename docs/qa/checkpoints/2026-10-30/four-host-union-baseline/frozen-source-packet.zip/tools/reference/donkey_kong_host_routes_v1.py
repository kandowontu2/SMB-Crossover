"""Private, source-generated DK router; no callable ROM patching."""
import re

TARGETS=['DkMovement','DkHostGraphics','DkHostDraw','DkHostPortrait','DkHostWeapons',
 'DkHostInjury','DkHostInjuryStatus','DkHostDeathStart','DkHostDeath',
 'DkHostVisible','DkHostHead']

def routes(old):
    rows=re.findall(r'^NrGate (\w+),(\w+),(\w+),(\w+),(\w+)$',old,re.M)
    assert len(rows)==11
    common='''.proc DkNrCommon
 lda SelectedCharacter
 cmp #20
 beq Fetch
 cmp #21
 beq Add1
 cmp #23
 beq Add2
 cmp #28
 beq Add3
 tya
 clc
 adc #11
 tay
Add3:tya
 clc
 adc #11
 tay
Add2:tya
 clc
 adc #11
 tay
Add1:tya
 clc
 adc #11
 tay
Fetch:
 lda DkNrLo,y
 sta FarcallJmpTarget_SMC+1
 lda DkNrHi,y
 sta FarcallJmpTarget_SMC+2
 lda DkNrBank,y
 sta NextBank_SMC+1
 pla
 tay
 plp
 jmp FarCallCommon+3
.endproc
'''
    # All97B public slots remain. Four previously unreachable slot suffixes
    # hold one cold dispatcher + genuine linker expressions, not new state.
    bodies=[common]
    owners=[[r[i]for r in rows]for i in[1,2,3]]+[TARGETS]+[[r[4]for r in rows]]
    targets=[n for a in owners for n in a]
    for name,prefix in [('Lo','<'),('Hi','>'),('Bank','.bank(')]:
        values=[prefix+t if name!='Bank'else'.bank('+t+')|$80'for t in targets]
        bodies.append('DkNr'+name+':\n .byte '+','.join(values)+'\n')
    macro='''.macro NrGate Name,Ice,City,Sunny,Legacy
.proc Name
 sta SafecallA_SMC+1
 php
 tya
 pha
 ldy #NrDkIndex
 jmp DkNrCommon
.endproc
 .if NrDkIndex=0
__BODY0__
 .elseif NrDkIndex=1
__BODY1__
 .elseif NrDkIndex=2
__BODY2__
 .elseif NrDkIndex=3
__BODY3__
 .elseif NrDkIndex=4
__BODY4__
 .elseif NrDkIndex=5
__BODY5__
 .elseif NrDkIndex=6
__BODY6__
 .elseif NrDkIndex=7
__BODY7__
 .elseif NrDkIndex=8
__BODY8__
 .elseif NrDkIndex=9
__BODY9__
 .endif
 .assert *-Name<=97,error,"DK router must fit its existing97B slot"
 .res 97-(*-Name),$ff
NrDkIndex .set NrDkIndex+1
.endmacro
NrDkIndex .set 0'''
    # Keep long legacy methods within the same already allocated gate
    # capsule, using its dead slot suffixes instead of a new A-bank trip.
    moved={}
    for name in['NrSide','NrWorldPaletteIndex','NrRise','NrPrivate']:
        m=re.search(r'\.proc '+name+r'\n.*?\.endproc',old,re.S)
        assert m
        moved[name]=m[0].replace('.proc '+name,'.proc DkRelocated'+name)
        old=old[:m.start()]+'.proc '+name+'\n jmp DkRelocated'+name+'\n.endproc'+old[m.end():]
    for i,body in enumerate(bodies+list(moved.values())):
        macro=macro.replace('__BODY'+str(i)+'__',body)
    macro=macro.replace('#NrDkIndex','#::NrDkIndex').replace('.if NrDkIndex','.if ::NrDkIndex').replace('.elseif NrDkIndex','.elseif ::NrDkIndex')
    old=re.sub(r'\.macro NrGate Name,Ice,City,Sunny,Legacy\n.*?\.endmacro',lambda m:macro,old,count=1,flags=re.S)
    # Macro-private names need explicit root qualification to be real public
    # linked definitions shared by all11 entries, never scope aliases.
    # The public entry's PROC ends before its unreachable suffix, so these
    # are genuine top-level definitions emitted in the same code segment.
    for n in['NrPrepare','NrRise','NrPrivate','NrPickupCollision','NrWorldPaletteIndex']:
        target='DkRelocated'+n if n in moved else n
        # Actual raw28 enters the already shared native path; existing
        # A/P/X/Y save/restore and true actor-slot guards remain intact.
        pat=r'(\.proc (?:::)?'+target+r'\n.*?cmp #CHARACTER_SUNNY\n (?:beq \w+))'
        found=re.search(pat,old,re.S)
        assert found,n
        label=re.search(r'beq (\w+)$',found[1])[1]
        old=old[:found.end()]+ '\n cmp #CHARACTER_DONKEY_KONG\n beq '+label+old[found.end():]
    m=re.search(r'\.proc DkRelocatedNrSide\n.*?\.endproc',old,re.S);assert m
    code=m[0].replace(' lda SelectedCharacter\n',' lda SelectedCharacter\n cmp #CHARACTER_DONKEY_KONG\n beq DkOwn\n',1)
    code=code.removesuffix('.endproc')+'DkOwn:pla\n plp\n farcall DkHostSide,jmp\n.endproc'
    old=old[:m.start()]+code+old[m.end():]
    # Own cold endpoints are appended once inside the existing gate span.
    additions=[]
    endpoints={'NrReset':'DkHostReset','NrBody':'DkHostBody','NrAdder':'DkHostAdder',
       'NrBox':'DkHostBoxProfile','NrPickup':'DkHostCollect','NrUi':'DkHostUi',
       'NrStatusName':'DkHostName','NrFullPower':'DkFullPower','NrColors':'DkHostColors',
       'NrNativePowerupDispatch':'DkHostPowerup','NrObjectWeaponTail':'DkHostWeaponTail'}
    for name,target in endpoints.items():
        m=re.search(r'\.proc '+name+r'\n.*?\.endproc',old,re.S);assert m,name
        code=m[0]
        if name in ['NrAdder','NrBox']:
            needle=' cmp SelectedCharacter\n bne Legacy\n'
            assert needle in code
            code=code.replace(needle,needle+' cmp #CHARACTER_DONKEY_KONG\n beq DkOwn\n',1)
            code=code.removesuffix('.endproc')+'DkOwn:pla\n plp\n farcall '+target+',jmp\n.endproc'
        elif name in ['NrPickup','NrFullPower']:
            needle=' lda SelectedCharacter\n'
            assert needle in code
            code=code.replace(needle,needle+' cmp #CHARACTER_DONKEY_KONG\n beq DkOwn\n',1)
            code=code.removesuffix('.endproc')+'DkOwn:farcall '+target+',jmp\n.endproc'
        else:
            needle=' lda SelectedCharacter\n'
            assert needle in code
            code=code.replace(needle,needle+' cmp #CHARACTER_DONKEY_KONG\n beq DkOwn\n',1)
            code=code.removesuffix('.endproc')+'DkOwn:pla\n plp\n farcall '+target+',jmp\n.endproc'
        # Status/Colors begin with NrCeleste, which returns full A/P. The
        # subsequent actual PHP/PHA still owns exactly this pair of saves.
        if name=='NrReset':
            code=code.replace(' beq DkOwn\n bne :+',' jeq DkOwn\n lda SelectedCharacter\n bne :+',1)
        elif name in ['NrStatusName','NrColors']:
            code=code.replace(' beq DkOwn\n',' jeq DkOwn\n',1)
        old=old[:m.start()]+code+old[m.end():]
    old=old.replace('farcall CmHostFresh,jmp','farcall DkHostFresh,jmp')
    name='NrNativePowerupDispatch'
    m=re.search(r'\.proc '+name+r'\n.*?\.endproc',old,re.S);assert m
    body=m[0].replace('.proc '+name,'.proc DkRelocated'+name)
    old=old[:m.start()]+'.proc '+name+'\n jmp DkRelocated'+name+'\n.endproc'+old[m.end():]
    old=old.replace('__BODY8__',body)
    name='NrPickupCollision'
    m=re.search(r'\.proc '+name+r'\n.*?\.endproc',old,re.S);assert m
    body=m[0].replace('.proc '+name,'.proc DkRelocated'+name)
    # After CMP #2 classified Mushroom/Flower, C is already0. The following
    # LDA/BMI changes no carry; removing its redundant CLC is exact for every
    # entry flag value and leaves this genuine method86B for one dead suffix.
    assert ' lda Enemy_State,x\n bmi Allowed' in body
    body=body.replace(' clc\n rts\nAllowed:sec',' rts\nAllowed:sec')
    old=old[:m.start()]+'.proc '+name+'\n jmp DkRelocated'+name+'\n.endproc'+old[m.end():]
    old=old.replace('__BODY9__',body)
    # The existing names area ends exactly where Celeste's host begins.
    # DK's separate cold menu-name wrapper supplies a genuine C12 pointer
    # to the existing NamePage consumer; no expanded legacy names table.
    return old
