"""Actual private authentic SMB2 driver/data/sample source projection/build.

No shared files or scheduling hooks. Existing segments only; no new SRAM.
"""
from pathlib import Path
import hashlib,json,re,subprocess,sys
from py65.devices.mpu6502 import MPU
import prepare_smb2_roster_native_v1 as S
import prepare_smb2_roll_relocation_v1 as Rel

ROOT=S.ROOT;OUT=ROOT/'build/smb2-roster-audio-v1'
PARENT=ROOT/'build/smb2-roll-relocation-v1/candidate.nes'
PARENT_SHA='1b38535bca411ec400a7c3efd15ee61b9823a247d4ee0f59572f38a6beff0b85'
SIZE=dict(imp=1,acc=1,imm=2,zpg=2,zpx=2,zpy=2,inx=2,iny=2,rel=2,abs=3,abx=3,aby=3,ind=3)
bind=S.binding;digest=S.digest

def graph():
    m=S.original(2);labels=S.labels();cpu=MPU();code={};todo=[labels[n]for n in['StartProcessingSoundQueue','PlaySquare2Sweep']]
    reads=set();writes=set();apu=set()
    assert m[0x8743:0x8746]==bytes.fromhex('a208d0')and 0x8747+(m[0x8746]-256)==labels['PlayNote'],'actual final LDX8/BNE PlayNote'
    while todo:
        pc=todo.pop()
        if pc==labels['NoteFrequencyData']:
            # Native final LDX8/BNE is unconditional. Do not decode the
            # following authenticated frequency data as fictitious code.
            continue
        if pc in code:continue
        assert 0x8000<=pc<labels['NoteFrequencyData'],hex(pc)
        op,mode=cpu.disassemble[m[pc]];assert op!='???',(hex(pc),m[pc])
        n=SIZE[mode];code[pc]=(op,mode,n)
        if mode=='rel':todo.append(pc+2+(m[pc+1]if m[pc+1]<128 else m[pc+1]-256))
        elif op in['JSR','JMP']:
            assert mode=='abs';todo.append(m[pc+1]+256*m[pc+2])
        if n>1 and mode not in['imm','rel']:
            target=m[pc+1]+(256*m[pc+2]if n==3 else 0)
            if op not in['JSR','JMP']:
                if target>=0x8000:reads.add(target)
                elif 0x4000<=target<=0x4017:apu.add((op,mode,target))
                else:(writes if op in['STA','STX','STY','INC','DEC','LSR','ASL','ROR','ROL']else reads).add(target)
        if op not in['JMP','RTS','RTI']:todo.append(pc+n)
    return m,labels,code,reads,writes,apu

def source():
    m,l,code,reads,writes,apu=graph()
    assert not[p for p in reads|writes if p<0x4000 and not(0xbb<=p<=0xc6 or p==0x100 or 0x5ec<=p<=0x61f)]
    targets={m[p+1]+(256*m[p+2]if n==3 else 0)for p,(op,mode,n)in code.items()if n>1 and mode not in['imm','rel']}
    native=['; Authentic SMB2 USA source projection. Original SHA'+S.SHA,'S2AudioNativeEntry:']
    writers={};relocations=[]
    def romoperand(target):
        if target==0x8fff:return 'S2AudioMusicData-1' # real indexed-expression base, precedingFF retained
        if 0x9000<=target<=0xa3ee:return f'S2AudioMusicData+${target-0x9000:04x}'
        if 0x8f00<=target<=0x8fb2:return f'S2AudioNoteLengths+${target-0x8f00:02x}'
        assert 0x8000<=target<0x875f,hex(target)
        return f'S2AR{target:04X}'
    pc=0x8000
    while pc<0x875f:
        native.append(f'S2AR{pc:04X}:')
        if pc not in code:
            end=pc+1
            while end<0x875f and end not in code and end not in targets:end+=1
            native.append(' .byte '+','.join(f'${v:02x}'for v in m[pc:end]));pc=end;continue
        op,mode,n=code[pc];arg='';emit=op.lower();target=None
        if mode=='imm':arg=f'#${m[pc+1]:02x}'
        elif mode=='acc':arg='a'
        elif mode=='rel':arg=f'S2AR{pc+2+(m[pc+1]if m[pc+1]<128 else m[pc+1]-256):04X}'
        elif mode!='imp':
            target=m[pc+1]+(256*m[pc+2]if n==3 else 0)
            if op in['JSR','JMP']:arg=f'S2AR{target:04X}'
            elif target==0x100:arg='S2AudioPause'
            elif 0x5ec<=target<=0x61f:arg=f'S2AudioState+${target-0x5ec:02x}'
            elif target<0x100:arg=f'${target:02x}'
            elif 0x4000<=target<=0x400f:
                assert op in['STA','STX','STY']
                if target&3==3:
                    key=(op,mode,target);name='S2AudioWrite'+op+mode+f'{target:04X}'
                    writers[key]=name;emit='jsr';arg=name
                else:arg=f'GuestNativeApu+${target-0x4000:02x}'
            elif target==0x4012:
                assert op=='STA'and mode=='abs';emit='jsr';arg='S2AudioDmcAddressSTA'
            elif target==0x4015:
                assert op in['STA','STX']and mode=='abs';emit='jsr';arg='S2AudioStatus'+op
            elif target in[0x4010,0x4013,0x4017]:arg=f'${target:04x}'
            elif target>=0x8000:
                if target==l['ProcessMusicQueue']:
                    assert op=='LDA'and mode=='aby';arg='S2AudioNoiseView'
                elif target==l['GrowingSoundData']-1:
                    assert op=='LDA'and mode=='aby';arg='S2AudioGrowingView'
                elif target in[l['NoiseVolTable'],l['NoiseLoTable'],l['NoiseHiTable']]:
                    assert op=='LDA'and mode=='aby';arg=f'S2AudioNoiseTables+{target-l["NoiseVolTable"]}'
                else:arg=romoperand(target)
            else:raise AssertionError((hex(pc),hex(target)))
            if emit!='jsr':
                if mode in['zpx','abx']:arg+=',x'
                elif mode in['zpy','aby']:arg+=',y'
                elif mode=='iny':arg='('+arg+'),y'
                elif mode=='inx':arg='('+arg+',x)'
        native.append(' '+emit+(' '+arg if arg else'')+f' ; original4:{pc:04X} '+m[pc:pc+n].hex())
        relocations.append(dict(source=f'{pc:04X}',op=op,mode=mode,bytes=m[pc:pc+n].hex(),emitted=emit+' '+arg))
        pc+=n
    native += [' .res $21,$ff ; source note table aligned atB900, not a generic ROM reader',
        'S2AudioNoteLengths:',' .byte '+','.join(f'${v:02x}'for v in m[0x8f00:0x8fb3])]
    wp=['; Only actual timer-high stores add a dirty mark, all original flags retained.']
    for(op,mode,target),name in sorted(writers.items()):
        suffix=',x'if mode=='abx'else(',y'if mode=='aby'else'')
        assert mode in['abs','abx','aby']
        wp += [f'.proc {name}',f' {op.lower()} GuestNativeApu+${target-0x4000:02x}'+suffix,
            ' php',' pha',' lda #1',f' sta GuestNativeDirty+${target-0x4000:02x}'+suffix,' pla',' plp',' rts','.endproc']
    plan=json.loads((ROOT/'build/smb2-roster-audio-plan-v1.json').read_text());entries={e['request']:dict(e,bank=c['bank'])for c in plan['samples']for e in c['entries']}
    entries[2]=entries[32]
    wp += ['S2AudioSampleBank: .byte '+','.join(str(entries[1<<i]['bank'])for i in range(8)),
        'S2AudioSampleStart: .byte '+','.join(str((int(entries[1<<i]['target'],16)-0xc000)//64)for i in range(8))]
    # Original musicPart macro uses relative BYTES. Only actual header main
    # address words need genuine translation; tracks/offsets remain identical.
    header_names=re.findall(r'^(MusicHeader\w+):', (S.REF/'src/music/music-headers.asm').read_text(),re.M)
    words={}
    for name in header_names:
        if name not in l:continue
        p=l[name]+1;v=m[p]+256*m[p+1]
        assert 0x9000<=v<=0xa3ee,(name,hex(p),hex(v))
        words[p]=v
    data=['; Complete authentic9000..A3EE, only source header pointer words translated.','S2AudioMusicData:']
    p=0x9000
    while p<0xa3ef:
        if p in words:data.append(f' .word S2AudioMusicData+${words[p]-0x9000:04x}');p+=2
        else:
            end=min(p+24,0xa3ef)
            end=min([q for q in words if p<q<end]+[end])
            data.append(' .byte '+','.join(f'${v:02x}'for v in m[p:end]));p=end
    data += ['S2AudioNoiseView:',' .byte '+','.join(f'${v:02x}'for v in m[l['ProcessMusicQueue']:l['ProcessMusicQueue']+256]),
        'S2AudioGrowingView:',' .byte '+','.join(f'${v:02x}'for v in m[l['GrowingSoundData']-1:l['GrowingSoundData']-1+128]),
        'S2AudioNoiseTables:',' .byte '+','.join(f'${v:02x}'for v in m[l['NoiseVolTable']:l['NoiseHiTable']+128]),'S2AudioDataEnd:']
    for name,lines in [('native',native),('writers',wp),('data',data)]:
        (ROOT/f'src/smb2_roster_audio_{name}.inc').write_text('\n'.join(lines)+'\n')
    (OUT/'source-projection.json').write_text(json.dumps(dict(original=bind(S.ROM),instructions=len(code),
        instruction_source_bytes=sum(n for _,_,n in code.values()),exact_unused_bytes_retained=True,
        instruction_projection=relocations,header_words={f'{k:04X}':f'{v:04X}'for k,v in words.items()},
        source_RAM='52B5EC..61F plus12BB..C6;0100pause privately mapped',
        original_sources=[bind(S.REF/p)for p in['src/prg-4-5.asm','src/ram.asm','src/defs.asm','src/music/music-headers.asm',
            'src/music/music-part-pointers.asm','src/music/music-pointers.asm','src/music/music-data.asm','src/music/instruments.asm',
            'src/music/frequency-table.asm','src/music/note-lengths.asm','src/music/dpcm-samples.asm']],
        writers=list(writers.values()),sample_table=entries,tool=bind(__file__)),indent=2)+'\n')

def main():
    Rel.check_parent();assert digest(PARENT.read_bytes())==PARENT_SHA
    OUT.mkdir(exist_ok=True);source()
    overlay=OUT/'overlay';(overlay/'src').mkdir(parents=True,exist_ok=True)
    cfg=ROOT/'build/smb2-roll-relocation-v1/overlay/smb1base-mmc5-expanded.cfg'
    (overlay/cfg.name).write_bytes(cfg.read_bytes())
    main=(ROOT/'src/entrypoint.s').read_text()+'\n.if ::ENABLE_MMC5_EXPANDED .and ::MAPPER_MMC5\n.include "smb2_roster_audio.s"\n.endif\n'
    (overlay/'src/entrypoint.s').write_text(main,newline='\n')
    command=[sys.executable,str(ROOT/'tools/build_mmc5_expanded.py'),'--source-overlay',str(overlay),'--output',str(OUT/'candidate.nes')]
    r=subprocess.run(command,cwd=ROOT,capture_output=True,text=True);(OUT/'launcher.txt').write_text(r.stdout+r.stderr)
    assert r.returncode==0,(r.stdout[-2500:],r.stderr[-2500:])
    candidate=OUT/'candidate.nes';raw=bytearray(candidate.read_bytes());stage=digest(raw)
    (OUT/'linked-before-smb2.nes').write_bytes(raw)
    (OUT/'linked-before-smb2.build.json').write_bytes(candidate.with_suffix('.build.json').read_bytes())
    (OUT/'linked-before-smb2.cv3-mirror.json').write_bytes(candidate.with_suffix('.cv3-mirror.json').read_bytes())
    original=S.ROM.read_bytes();fixed=bytes(raw[16+127*8192:16+128*8192]);plan=json.loads((ROOT/'build/smb2-roster-audio-plan-v1.json').read_text())
    clone_records=[]
    for clone in plan['samples']:
        bank=clone['bank'];data=bytearray(fixed);declared=[]
        assert raw[16+bank*8192:16+(bank+1)*8192]==bytes([255])*8192
        for entry in clone['entries']:
            p=int(entry['source'],16);n=entry['bytes'];blob=original[16+114688+p-0xc000:16+114688+p-0xc000+n]
            assert digest(blob)==entry['sha256'];start=int(entry['target'],16)-0xe000
            data[start:start+n]=blob;declared.append([start,start+n])
        assert data[:0x1140]==fixed[:0x1140]and data[0x1e11:]==fixed[0x1e11:]
        assert all(x==y or 0x1140<=i<0x1e11 for i,(x,y)in enumerate(zip(data,fixed)))
        raw[16+bank*8192:16+(bank+1)*8192]=data
        clone_records.append(dict(bank=bank,sha256=digest(data),actual_complete_fetches=clone['entries'],
            all_callable_bytes_outside_F140_FE10_exact=True,declared_payload_offsets=declared))
    candidate.write_bytes(raw)
    candidate.with_suffix('.build.json').write_text(json.dumps(dict(output=str(candidate),sha256=digest(raw),bytes=len(raw),mapper=5,
        expanded=True,compiler_and125_stage_sha256=stage,postlink='private authentic SMB2 current-E119/120 clones only'),indent=2)+'\n')
    old=PARENT.read_bytes();allowed={74,117,119,120}
    assert raw[:16]==old[:16]and raw[1048592:]==old[1048592:]
    assert all(raw[16+b*8192:16+(b+1)*8192]==old[16+b*8192:16+(b+1)*8192]for b in range(128)if b not in allowed)
    assert fixed==old[16+127*8192:16+128*8192]
    # Current ordinary125 is identical to its freshly regenerated stage and
    # parent: this module adds no fixed callable byte or live hook.
    assert raw[16+125*8192:16+126*8192]==old[16+125*8192:16+126*8192]
    proof=dict(status='PRIVATE_AUTHENTIC_SOURCE_AUDIO_LINK_NO_HOST_SCHEDULING_OR_NATIVE',parent=bind(PARENT),candidate=bind(candidate),
        command=command,source_projection=bind(OUT/'source-projection.json'),final_fixed127_sha256=digest(fixed),
        linked_and_current125_stage=bind(OUT/'linked-before-smb2.nes'),samples=clone_records,
        only_changed_banks=sorted(allowed),header_CHR_other_PRG_exact=True,existing125_and127_exact=True,
        source_files=[bind(ROOT/f'src/smb2_roster_audio{suffix}')for suffix in['.s','_native.inc','_writers.inc','_data.inc']],
        overlays=[bind(overlay/cfg.name),bind(overlay/'src/entrypoint.s')],tool=bind(__file__),
        limits='Source/link only. No Main publication, shared mixer/DMC owner dispatch, NMI/audio scheduler/menu exposure or Mesen. Native APUs projected to original ordered images; hardware4017/DMC/status remain original ordered operations.')
    (OUT/'build-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
    print(json.dumps(dict(proof=bind(OUT/'build-proof.json'),candidate=proof['candidate'],source_instructions=json.loads((OUT/'source-projection.json').read_text())['instructions']),indent=2))

if __name__=='__main__':main()
