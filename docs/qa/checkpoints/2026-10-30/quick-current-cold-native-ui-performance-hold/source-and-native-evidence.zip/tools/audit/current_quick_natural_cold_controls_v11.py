"""Repeat natural source call sequence through the genuine bbox adapter."""
from pathlib import Path
text=Path(__file__).with_name('current_quick_natural_cold_controls_v7.py').read_text()
text=text.replace('import prepare_current_quick_cold_v7 as B','import prepare_current_quick_cold_v11 as B')
exec(compile(text,__file__,'exec'),globals())
