"""ONE separately root-granted fixture-only retry; never silently relaunch."""
import json,os,sys
import prepare_current_quick_cold_v12 as B
import arthur_body_fair_budget_v7 as Q
O=B.O;N=B.N;F=O/'native-fresh-guard-v2';T=O/'native/cold-menu-game-v2'
def main():
 assert sys.argv[1:]==['--launch']and not T.exists(),'Separate explicit root grant required; no automatic retries.'
 source=json.loads((O/'handoff.json').read_text());original=json.loads((O/'native-prepared.json').read_text());proof=json.loads((F/'prepared.json').read_text());ready=json.loads((F/'native-ready.json').read_text())
 def verify():
  for d in[source,original,proof,ready]:
   for path,value in d['bindings'].items():assert B.B.sha(path)==value,path
  assert ready['candidate']==source['candidate']==B.B.sha(N/'candidate.nes')
 verify();T.parent.mkdir(exist_ok=True);os.environ['SMB_RUN_OUTPUT']=str(T.resolve())
 budget=Q.load(O/'native-capture-budget.py');run=Q.run_function(budget)
 meta=dict(candidate=ready['candidate'],source_handoff=B.B.sha(O/'handoff.json'),fixture_prepared=B.B.sha(F/'prepared.json'),native_ready=B.B.sha(F/'native-ready.json'),bindings_verified=sum(len(d['bindings'])for d in[source,original,proof,ready]),options=original['options'],config=original['config'])
 (F/'native-preflight.json').write_text(json.dumps(meta,indent=2)+'\n')
 rc=run(F/'native-fresh-v2.lua',N/'candidate.nes',timeout=60,emulator_options=original['options']);verify()
 (F/'native-postflight.json').write_text(json.dumps(dict(**meta,exit_code=rc,pre_post_bindings_exact=True),indent=2)+'\n')
 print(json.dumps(dict(native_terminal=True,exit_code=rc,candidate=ready['candidate'],output=str(T.resolve()),bindings_pass=True)),flush=True);raise SystemExit(rc)
if __name__=='__main__':main()
