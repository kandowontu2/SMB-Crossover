"""Keep genuine native C34 publication, correcting API-only restore assumption."""
import inspect
import current_quick_natural_cold_controls_v6 as M
text=inspect.getsource(M.C.invoke)
old="if requested!='GameLoop':assert m.tags==incoming,('public mapper restore',requested,m.tags,incoming)"
new="if requested not in ['GameLoop','QueueSelection','InitializeArea','LoadAreaPointer','DrawSelectionPreview']:assert m.tags==incoming,('public mapper restore',requested,m.tags,incoming)"
assert text.count(old)==1;exec(compile(text.replace(old,new),__file__,'exec'),M.C.__dict__)
text=inspect.getsource(M.main)
old="z,r=invoke(m,name);rows.append(z);assert m.get('SelectedCharacter')==9 and m.get('FmAlts')==32"
new="z,r=invoke(m,name);rows.append(z);assert m.get('SelectedCharacter')==9 and m.get('FmAlts')==32\n   if name=='QueueSelection':assert m.tags[2]==(m.bank('XgBASS0_STANDRight')|128)==m.get('CurrentBankC'),('actual native Bass descriptor publication C34',m.tags)"
assert text.count(old)==1;exec(compile(text.replace(old,new),__file__,'exec'),M.__dict__)
M.O=M.O/'controls-v6b';M.O.mkdir(exist_ok=False)
if __name__=='__main__':M.main()
