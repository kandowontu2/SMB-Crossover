"""Keep both granted adjacent bbox regions in one link-time code segment."""
import json
import prepare_current_quick_cold_v11 as M
from private_build_outputs_v1 import validate
def main():
 neg=M.O/'retained-force-range-negative.json';assert not neg.exists();neg.write_bytes((M.O/'compile-bbox-local-resolved-relative.json').read_bytes())
 p=M.N/'bbox-local.s';s=p.read_text();assert s.count('.segment "QW_BBOX_TAIL"')==1
 s=s.replace('.segment "QW_BBOX_TAIL"','.segment "HOST_BBOX_LOCAL"\n .res $40-(*-HuPlayerSubsAdapter),$ff\n .assert *=$afe7,lderror,"Retained Quick suffix starts after exactly64B bbox grant"');p.write_text(s,newline='\n')
 p=M.N/'private.cfg';s=p.read_text();assert s.count('HOST_BBOX_LOCAL_MEM:start=$afa7,size=$40')==1
 s=s.replace('HOST_BBOX_LOCAL_MEM:start=$afa7,size=$40','HOST_BBOX_LOCAL_MEM:start=$afa7,size=$59')
 lines=s.splitlines();lines=[line for line in lines if not line.strip().startswith(('QW_BBOX_TAIL_MEM:','QW_BBOX_TAIL:'))];p.write_text('\n'.join(lines)+'\n',newline='\n')
 cmd=json.loads((M.O/'compile-bbox-local.json').read_text())['command'];link=M.rebase(json.loads((M.M.C.O/'final-link.json').read_text())['command'],M.M.C.N)
 cmds=[(cmd,'compile-bbox-local-single-segment'),(link,'final-link')]
 (M.O/'single-segment-output-preflight.json').write_text(json.dumps([validate(q,M.N,cwd=M.R)for q,_ in cmds],indent=2)+'\n');M.B.O=M.O;M.B.N=M.N
 for q,name in cmds:M.B.run(q,name)
 from prepare_cv3_dmc_mirror import prepare
 prepare(M.R,M.N/'candidate.nes')
 (M.O/'source-stage.json').write_text(json.dumps(dict(candidate=M.B.sha(M.N/'candidate.nes'),native=False,installed=False,scope='Exact same-bank source branches across original bbox64B + retained Quick25B combined MEMORY only; no new resource bytes. Actual code61B+13B suffix. Controls pending.'),indent=2)+'\n');print((M.O/'source-stage.json').read_text())
if __name__=='__main__':main()
