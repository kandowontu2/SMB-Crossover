"""Preserve native scene AXYP around real selected Quick acquisition."""
from pathlib import Path
import difflib,json,shutil
import prepare_current_quick_cold_v5 as C
from private_build_outputs_v1 import validate
B=C.B;R=C.R;P=C.N;OLD=C.O;O=R/'build/current-character-quick-cold-v6';N=O/'joint'
def rebase(cmd,p):return[x.replace(str(p),str(N)).replace(p.as_posix(),N.as_posix())for x in cmd]
def main():
 assert not O.exists();oldh=OLD/'source-negative-handoff.json';assert not oldh.exists()
 files=[p for p in OLD.rglob('*')if p.is_file()]+[Path(C.__file__)]
 oldh.write_text(json.dumps(dict(status='FROZEN_REAL_FOREIGN_SCENE_CARRY_NEGATIVE',candidate=B.sha(P/'candidate.nes'),native=False,bindings={str(p.resolve()):B.sha(p)for p in files}),indent=2)+'\n')
 O.mkdir();shutil.copytree(P,N)
 for p in N.rglob('*'):
  if p.is_file()and p.suffix in['.s','.inc','.cfg']:
   s=p.read_text();z=s.replace(str(P),str(N)).replace(P.as_posix(),N.as_posix())
   if s!=z:p.write_text(z,newline='\n')
 p=N/'quick/loader.s';s=p.read_text();assert s.count('QwSceneInit:\n jsr QwActive')==1
 s=s.replace('QwSceneInit:\n jsr QwActive','QwSceneInit:\n php\n pha\n txa\n pha\n tya\n pha\n jsr QwActive',1)
 assert s.count('QwSceneNative:\n RomCall ArGenSceneInit')==1
 s=s.replace('QwSceneNative:\n RomCall ArGenSceneInit','QwSceneNative:\n pla\n tay\n pla\n tax\n pla\n plp\n RomCall ArGenSceneInit',1)
 p.write_text(s,newline='\n');(O/'scene-source.diff').write_text(''.join(difflib.unified_diff((P/'quick/loader.s').read_text().splitlines(True),s.splitlines(True),fromfile='negative/quick/loader.s',tofile='successor/quick/loader.s')),newline='\n')
 cmds=[(rebase(json.loads((OLD/'compile-quick-loader.json').read_text())['command'],P),'compile-quick-loader'),(rebase(json.loads((OLD/'final-link.json').read_text())['command'],P),'final-link')]
 (O/'output-preflight.json').write_text(json.dumps([validate(q,N,cwd=R)for q,_ in cmds],indent=2)+'\n')
 B.O=O;B.N=N
 for cmd,name in cmds:B.run(cmd,name)
 from prepare_cv3_dmc_mirror import prepare
 prepare(R,N/'candidate.nes')
 for name in['code.bin','data.bin','ram3.bin','ff-cookie.bin','quick/cookie.bin']:assert(N/name).read_bytes()==(P/name).read_bytes(),name
 C.C.C.check_bindings(oldh)
 (O/'source-stage.json').write_text(json.dumps(dict(candidate=B.sha(N/'candidate.nes'),parent=B.sha(P/'candidate.nes'),native=False,installed=False,notes='Actual native scene AXYP restored before genuine ArGenSceneInit. Retained original source/runtime payloads, UInewsource route, post-IcQwBoot and privateQuickready. Naturalcold/retirement/sourcecontrols pending.'),indent=2)+'\n');print((O/'source-stage.json').read_text())
if __name__=='__main__':main()
