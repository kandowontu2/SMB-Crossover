"""Retain the actual cold sequence and assert the repaired natural movement."""
import inspect,json
import current_quick_natural_cold_controls_v6 as M
import prepare_current_quick_cold_v7 as B
M.B=B;M.N=B.N;M.O=B.O/'natural-controls';M.O.mkdir(exist_ok=False)
M.C.O=B.N;M.C.CODE=(B.N/'code.bin').read_bytes();M.C.DATA=(B.N/'data.bin').read_bytes()
text=inspect.getsource(M.C.invoke)
old="if requested!='GameLoop':assert m.tags==incoming,('public mapper restore',requested,m.tags,incoming)"
new="if requested not in ['GameLoop','QueueSelection','InitializeArea','LoadAreaPointer','DrawSelectionPreview','PrimaryGameSetup','SecondaryGameSetup','Entrance_GameTimerSetup','PlayerEntrance']:assert m.tags==incoming,('public mapper restore',requested,m.tags,incoming)"
assert text.count(old)==1;exec(compile(text.replace(old,new),__file__,'exec'),M.C.__dict__)
text=inspect.getsource(M.fresh)
old="m.ppu_ctrl=160;m.ppu_mask=24;m.sync_chr11();m.ram[0x5102]=2;m.ram[0x5103]=1;m.ram[0x5113]=0;return m"
new="m.ppu_ctrl=160;m.ppu_mask=24;m.sync_chr11();m.ram[0x5102]=2;m.ram[0x5103]=1;m.ram[0x5113]=0\n C.invoke(m,'PrimaryGameSetup')\n put(m,OperMode=0,CrossoverMenuState=2,DisableScreenFlag=0,Mirror_PPUMASK=24,FamilyMainCommit=1)\n return m"
assert text.count(old)==1;exec(compile(text.replace(old,new),__file__,'exec'),M.__dict__)
text=inspect.getsource(M.invoke)
text=text.replace("'PlayerBankReady']","'PlayerBankReady','QhWeapons','QhAdder','QhBox','QhBoxProfile','QhHead','QhSide','QhSync']")
text=text.replace("'QhGraphics','QhDraw']else","'QhGraphics','QhDraw','QhWeapons','QhAdder','QhBox','QhBoxProfile','QhHead','QhSide','QhSync']else")
exec(compile(text,__file__,'exec'),M.__dict__)
text=inspect.getsource(M.main)
old="put(m,GameEngineSubroutine=8,OperMode_Task=3,OperMode=1,Player_CollisionBits=255,VRAM_Buffer1_Offset=0)"
new="for name in ['SecondaryGameSetup','Entrance_GameTimerSetup','PlayerEntrance']:\n   z,r=invoke(m,name);d['checks'][name]=z\n  assert m.get('GameEngineSubroutine')==8,('genuine native entrance must reach player control',m.get('GameEngineSubroutine'))\n  put(m,OperMode_Task=3,OperMode=1,Player_CollisionBits=255,VRAM_Buffer1_Offset=0)"
assert text.count(old)==1;text=text.replace(old,new)
old="rows.append(dict(age=age,keys=keys,CPU=z['CPU'],HP=m.get('QmField_06C0'),X=m.get('Player_X_Position'),Y=m.get('Player_Y_Position')))"
new="rows.append(dict(age=age,keys=keys,CPU=z['CPU'],HP=m.get('QmField_06C0'),X=m.get('Player_X_Position'),Page=m.get('Player_PageLoc'),Y=m.get('Player_Y_Position'),counts=z['counts']))"
assert text.count(old)==1;text=text.replace(old,new)
text=text.replace("'Menu owner-retire-before-publication helper remains pending separately.'","'Actual menu retirement is now installed; separate lifecycle/allflags tests remain required. Universal full-body/post-terrain source consumers still pending.'")
exec(compile(text,__file__,'exec'),M.__dict__)
if __name__=='__main__':M.main()
