"""Repair genuine Bass-only Quick movement/terrain consumers in owned C98.

Universal full-box and post-terrain callers are deliberately left unchanged:
their selected-only ingress needs a separate zero-extra-map source repair.
"""
from pathlib import Path
import difflib,json,shutil
import prepare_current_quick_cold_v6 as C
from private_build_outputs_v1 import validate
B=C.B;R=C.R;P=C.N;OLD=C.O;O=R/'build/current-character-quick-cold-v7';N=O/'joint'
def rebase(cmd):return[x.replace(str(P),str(N)).replace(P.as_posix(),N.as_posix())for x in cmd]
def edit(name,a,b):
 p=N/name;s=p.read_text();assert s.count(a)==1,(name,a);p.write_text(s.replace(a,b,1),newline='\n')
BRIDGE='''; Genuine SFC-only indexed bridge. The original source A is already in
; SafecallA; save original Y/P, leave X untouched, and reuse exactly the
; existing saved-bank/caller frame. No new old-owner mapper nesting.
.setcpu "6502"
.import FarCallCommon,SafecallA_SMC,FarcallJmpTarget_SMC,NextBank_SMC
.import SelectedCharacter,FmAlts,ArenaGateBank,QwService,QwMenuRetire,ArGenResolve
.import RlMovementDispatch,HotCollisionAdder,HotCollisionBox,TnFastHeadGate
.export QwMovementGate,QwAdderGate,QwBoxProfileGate,QwHeadGate,QwMenuResolve
.segment "QW_HOST_BRIDGE"
QwMovementGate:php
 tya
 pha
 ldy #0
 jmp QwGuestGate
QwAdderGate:php
 tya
 pha
 ldy #1
 jmp QwGuestGate
QwBoxProfileGate:php
 tya
 pha
 ldy #2
 jmp QwGuestGate
QwHeadGate:php
 tya
 pha
 ldy #3
 jmp QwGuestGate
QwGuestGate:
 lda SelectedCharacter
 cmp #9
 bne QwGuestForeign
 lda FmAlts
 and #32
 beq QwGuestForeign
 lda QwGuestService,y
 sta ArenaGateBank
 lda #<QwService
 sta FarcallJmpTarget_SMC+1
 lda #>QwService
 sta FarcallJmpTarget_SMC+2
 lda #.lobyte(.bank(QwService)|$80)
 bne QwGuestFinish
QwGuestForeign:
 lda QwGuestLo,y
 sta FarcallJmpTarget_SMC+1
 lda QwGuestHi,y
 sta FarcallJmpTarget_SMC+2
 lda QwGuestBank,y
QwGuestFinish:
 sta NextBank_SMC+1
 pla
 tay
 plp
 pla
 pla
 jmp NextBank_SMC
QwGuestService:.byte 0,12,13,10
QwGuestLo:.byte <RlMovementDispatch,<HotCollisionAdder,<HotCollisionBox,<TnFastHeadGate
QwGuestHi:.byte >RlMovementDispatch,>HotCollisionAdder,>HotCollisionBox,>TnFastHeadGate
QwGuestBank:.byte .lobyte(.bank(RlMovementDispatch)|$80),.lobyte(.bank(HotCollisionAdder)|$80),.lobyte(.bank(HotCollisionBox)|$80),.lobyte(.bank(TnFastHeadGate)|$80)
.macro RomCall Target
 sta SafecallA_SMC+1
 lda #<Target
 sta FarcallJmpTarget_SMC+1
 lda #>Target
 sta FarcallJmpTarget_SMC+2
 lda #.lobyte(.bank(Target)|$80)
 jsr FarCallCommon
.endmacro
QwMenuResolve:
 RomCall QwMenuRetire
 RomCall ArGenResolve
 rts
QwHostBridgeEnd:
.assert QwMovementGate=$aefc,lderror,"Granted retained C98 headroom start"
.assert QwHostBridgeEnd<=$b000,lderror,"No overlap with real Celeste native owner"
'''
def main():
 assert not O.exists();oldh=OLD/'source-negative-handoff.json';assert not oldh.exists()
 files=[p for p in OLD.rglob('*')if p.is_file()]+[Path(C.__file__)]
 oldh.write_text(json.dumps(dict(status='FROZEN_NATURAL_MOVEMENT_BYPASS_NEGATIVE',candidate=B.sha(P/'candidate.nes'),native=False,bindings={str(p.resolve()):B.sha(p)for p in files}),indent=2)+'\n')
 # Exact retained allocation, emitted metadata closure and FF preimage.
 rom=(P/'candidate.nes').read_bytes();assert rom[16+98*8192+0xefc:16+98*8192+0x1000]==bytes([255])*260
 cfg=(P/'private.cfg').read_text();assert cfg.count('QP_META_MEM:start=$cc91,size=$26b')==1
 assert cfg.count('X5_NEW_62_CurrentKeep1:start=$aefc,size=$f0f')==1
 receipt=R/'docs/qa/checkpoints/2026-10-30/arthur-quick-private-allocation/root-review-and-reservations.json'
 assert B.sha(receipt)=='0d12cb77cb79feb9648803d6c057293ffe5686a5a94c41f9813b057b1cdac2ae'
 O.mkdir();shutil.copytree(P,N)
 for p in N.rglob('*'):
  if p.is_file()and p.suffix in['.s','.inc','.cfg']:
   s=p.read_text();z=s.replace(str(P),str(N)).replace(P.as_posix(),N.as_posix())
   if s!=z:p.write_text(z,newline='\n')
 edit('private.cfg','X5_NEW_62_CurrentKeep1:start=$aefc,size=$f0f','QW_HOST_BRIDGE_MEM:start=$aefc,size=$104,type=ro,file=%O,fill=yes,fillval=$ff,bank=$62;\nX5_NEW_62_CurrentKeep1:start=$b000,size=$e0b')
 edit('private.cfg','QW_ROUTER:load=QW_ROUTER_MEM,type=ro;','QW_HOST_BRIDGE:load=QW_HOST_BRIDGE_MEM,type=ro;\nQW_ROUTER:load=QW_ROUTER_MEM,type=ro;')
 edit('entrypoint.s','.import QwBoot,QwSceneInit','.import QwMovementGate,QwAdderGate,QwBoxProfileGate,QwHeadGate,QwMenuResolve\n.export RlMovementDispatch,HotCollisionAdder,HotCollisionBox,TnFastHeadGate\n.import QwBoot,QwSceneInit')
 edit('src/player.s','farcall RlMovementDispatch','farcall QwMovementGate')
 edit('src/expanded.s','farcall HotCollisionAdder,jmp','farcall QwAdderGate,jmp')
 edit('src/expanded.s','farcall HotCollisionBox,jmp','farcall QwBoxProfileGate,jmp')
 edit('src/expanded.s','farcall TnFastHeadGate,jmp','farcall QwHeadGate,jmp')
 edit('src/character_select.s','farcall ArGenResolve','farcall QwMenuResolve')
 edit('quick/loader.s','.import ArGenSceneInit','.import ArGenSceneInit,CrossoverMenuIndex\n.export QwMenuRetire')
 edit('quick/loader.s','QwRetire:\n php','QwMenuRetire:\n php\n pha\n txa\n pha\n lda CrossoverMenuIndex\n cmp #9\n bne QwRetireInvalidate\n lda FmAlts\n and #32\n beq QwRetireInvalidate\n jmp QwRetireDone\nQwRetire:\n php')
 edit('quick/loader.s',' bcs QwRetireDone\n lda CurrentBankC',' bcs QwRetireDone\nQwRetireInvalidate:\n lda CurrentBankC')
 p=N/'quick/loader.s';s=p.read_text()
 for prefix in['<','>']:
  name='QwServiceLo:'if prefix=='<'else'QwServiceHi:'
  a=s.index(name);b=s.index('\n',s.index(' .byte',a));line=s[a:b];parts=line.split(' .byte ')[1].split(',');assert len(parts)==36 and parts[34]==prefix+'QhNoop';parts[34]=prefix+'QhWeapons';s=s[:a]+name+'\n .byte '+','.join(parts)+s[b:]
 p.write_text(s,newline='\n');(N/'quick/host-bridge.s').write_text(BRIDGE,newline='\n')
 for name in['entrypoint.s','src/player.s','src/expanded.s','src/character_select.s','quick/loader.s','private.cfg']:
  (O/(Path(name).name+'.diff')).write_text(''.join(difflib.unified_diff((P/name).read_text().splitlines(True),(N/name).read_text().splitlines(True),fromfile='parent/'+name,tofile='successor/'+name)),newline='\n')
 cmdmain=[x.replace(str(C.C.N),str(N)).replace(C.C.N.as_posix(),N.as_posix())for x in json.loads((C.C.O/'compile-main.json').read_text())['command']]
 cmdloader=rebase(json.loads((OLD/'compile-quick-loader.json').read_text())['command'])
 cmdbridge=[x.replace(str(N/'quick/loader.'),str(N/'quick/host-bridge.'))for x in cmdloader]
 link=rebase(json.loads((OLD/'final-link.json').read_text())['command']);link.append(str(N/'quick/host-bridge.o'))
 cmds=[(cmdmain,'compile-main'),(cmdloader,'compile-quick-loader'),(cmdbridge,'compile-quick-bridge'),(link,'final-link')]
 (O/'output-preflight.json').write_text(json.dumps([validate(q,N,cwd=R)for q,_ in cmds],indent=2)+'\n')
 B.O=O;B.N=N
 for cmd,name in cmds:B.run(cmd,name)
 from prepare_cv3_dmc_mirror import prepare
 prepare(R,N/'candidate.nes')
 for name in['code.bin','data.bin','ram3.bin','ff-cookie.bin','quick/cookie.bin']:assert(N/name).read_bytes()==(P/name).read_bytes(),name
 C.C.C.C.check_bindings(oldh)
 (O/'source-stage.json').write_text(json.dumps(dict(candidate=B.sha(N/'candidate.nes'),parent=B.sha(P/'candidate.nes'),native=False,installed=False,notes='Only genuine Bass movement and existing expanded adder/box/head callback operands retargeted; original legacy callbacks retained by true SFC frame reuse. Upcoming-menu owner retirement before Selected publication. Real row34 source enemy/shot contacts.',limits=['Natural movement/collision/retire/API/ISR controls pending.','Universal native full-box and post-terrain remain unchanged pending selected-only source ingress.','No full1-1/powerup/CXaudio or native performance claim.']),indent=2)+'\n');print((O/'source-stage.json').read_text())
if __name__=='__main__':main()
