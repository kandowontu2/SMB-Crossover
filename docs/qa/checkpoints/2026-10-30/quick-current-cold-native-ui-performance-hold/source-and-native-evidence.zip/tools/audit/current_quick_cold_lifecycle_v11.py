"""Real scene resets, per-player persistence and pre-publication retirement."""
from pathlib import Path
import json,traceback
import prepare_current_quick_cold_v11 as B
import current_quick_transport_controls_v4 as T
C=T.C;S=T.S;N=B.N;O=B.O
def main():
 out=O/'cold-lifecycle-controls.json';assert not out.exists();d=dict(passed=False,native=False);C.O=N;C.CODE=(N/'code.bin').read_bytes();C.DATA=(N/'data.bin').read_bytes()
 try:
  m=C.Bus();m.set('FamilyMainCommit',1);m.set('Player_X_Position',80);m.set('Player_Y_Position',160);m.set('Player_Y_HighPos',1);m.set('OperMode',1)
  C.invoke(m,'QwBoot');C.invoke(m,'QwSceneInit');C.exact_cache(m);assert m.get('QmField_06C0')==40
  states=[]
  for player in[0,1,0,1]:
   m.set('CurrentPlayer',player);C.invoke(m,'QwSceneInit');before=m.get('QmField_06C0')
   if player==0 and len(states)==0:
    S.execute(m,'QhInjury');assert m.get('QmField_06C0')==36
   states.append(dict(player=player,HP_before=before,HP_after=m.get('QmField_06C0'),records=list(m.ram[m.lab['QhPersistent']:m.lab['QhPersistent']+8])))
   assert all(m.get('QmField_0420')==0 for _ in[0]),'Actual source reset must clear actor0'
  assert [r['HP_before']for r in states]==[40,40,36,40],states
  d['per_player_scene_resets']=states
  # Real resolver must invalidate a previous Quick cache BEFORE its actual
  # selected-store instruction, while an upcoming exact Quick retains it.
  rows=[];base=S.clone(m)
  for menu in[0,1,2,9,22,26,28,32]:
   for alt in[0,1,32,33,255]:
    q=S.clone(base);q.set('SelectedCharacter',9);q.set('CrossoverMenuIndex',menu);q.set('FmAlts',alt);events=[]
    def watch(c):
     pc=c.pc
     if bytes(q[pc:pc+3])==bytes([0x8d,q.lab['SelectedCharacter']&255,q.lab['SelectedCharacter']>>8]):events.append([pc,q.wram[2][0x1fe0]])
    S.execute(q,'QwMenuResolve',hook=watch)
    retain=menu==9 and bool(alt&32)
    assert q.wram[2][0x1fe0]==(167 if retain else 0),(menu,alt,list(q.wram[2][0x1fe0:0x1ff0]))
    assert events and all(v==(167 if retain else 0)for _,v in events),('invalidate before actual Selected publication',menu,alt,events)
    rows.append(dict(menu=menu,alt=alt,retained=retain,selected_stores=events))
  d['actual_menu_retirement']=rows
  # The explicit Quick retirement helper never invalidates another C2 owner,
  # including a potential Arthur cookie. A native constructor clears Quick.
  q=S.clone(base);q.wram[2][0x1fe1]=32;q.set('CrossoverMenuIndex',0);before=bytes(q.wram[2]);S.execute(q,'QwMenuRetire');assert bytes(q.wram[2])==before
  C.invoke(m,'QwBoot');assert m.wram[2][0x1fe0]==0 and m.ram[m.lab['QhPersistent']:m.lab['QhPersistent']+8]==bytes(8)
  d.update(passed=True,limits=['Genuine CPU constructors/scene resets and menu resolver; natural startup separately proved. Actual pause/menu/lives/death playback and source audio still need native qualification.'])
 except Exception as e:d.update(error=repr(e),traceback=traceback.format_exc())
 d['bindings']={str(Path(p).resolve()):B.B.sha(p)for p in[__file__,N/'candidate.nes',N/'candidate.dbg']};out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(passed=d['passed'],error=d.get('error'))));assert d['passed'],d.get('error')
if __name__=='__main__':main()
