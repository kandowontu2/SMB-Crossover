"""Execute native title/game setup consumers instead of skipping timer entrance."""
import inspect
import current_quick_natural_cold_controls_v6 as M
text=inspect.getsource(M.C.invoke);old="if requested!='GameLoop':assert m.tags==incoming,('public mapper restore',requested,m.tags,incoming)"
new="if requested not in ['GameLoop','QueueSelection','InitializeArea','LoadAreaPointer','DrawSelectionPreview','PrimaryGameSetup','SecondaryGameSetup','Entrance_GameTimerSetup','PlayerEntrance']:assert m.tags==incoming,('public mapper restore',requested,m.tags,incoming)"
assert text.count(old)==1;exec(compile(text.replace(old,new),__file__,'exec'),M.C.__dict__)
text=inspect.getsource(M.fresh)
old="m.ppu_ctrl=160;m.ppu_mask=24;m.sync_chr11();m.ram[0x5102]=2;m.ram[0x5103]=1;m.ram[0x5113]=0;return m"
new="m.ppu_ctrl=160;m.ppu_mask=24;m.sync_chr11();m.ram[0x5102]=2;m.ram[0x5103]=1;m.ram[0x5113]=0\n C.invoke(m,'PrimaryGameSetup')\n put(m,OperMode=0,CrossoverMenuState=2,DisableScreenFlag=0,Mirror_PPUMASK=24,FamilyMainCommit=1)\n return m"
assert text.count(old)==1;exec(compile(text.replace(old,new),__file__,'exec'),M.__dict__)
text=inspect.getsource(M.main)
old="put(m,GameEngineSubroutine=8,OperMode_Task=3,OperMode=1,Player_CollisionBits=255,VRAM_Buffer1_Offset=0)"
new="for name in ['SecondaryGameSetup','Entrance_GameTimerSetup','PlayerEntrance']:\n   z,r=invoke(m,name);d['checks'][name]=z\n  assert m.get('GameEngineSubroutine')==8,('genuine native entrance must reach player control',m.get('GameEngineSubroutine'))\n  put(m,OperMode_Task=3,OperMode=1,Player_CollisionBits=255,VRAM_Buffer1_Offset=0)"
assert text.count(old)==1;exec(compile(text.replace(old,new),__file__,'exec'),M.__dict__)
M.O=M.O/'controls-v6c';M.O.mkdir(exist_ok=False)
if __name__=='__main__':M.main()
