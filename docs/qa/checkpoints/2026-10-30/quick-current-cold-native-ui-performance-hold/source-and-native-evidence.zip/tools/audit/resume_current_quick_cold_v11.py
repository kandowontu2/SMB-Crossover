"""Permit link-resolved same-bank relative branches and prove their ranges."""
import json
import prepare_current_quick_cold_v11 as M
from private_build_outputs_v1 import validate
def main():
 p=M.N/'bbox-local.s';s=p.read_text();assert '.feature force_range'not in s
 old=M.O/'compile-bbox-local.json';neg=M.O/'retained-cross-segment-relative-negative.json';assert not neg.exists();neg.write_bytes(old.read_bytes())
 # ca65's force_range enables relocatable byte branches across two segments.
 # Actual signed branch deltas are independently decoded after linking.
 p.write_text('.feature force_range\n'+s,newline='\n')
 cmd=json.loads(old.read_text())['command'];link=M.rebase(json.loads((M.M.C.O/'final-link.json').read_text())['command'],M.M.C.N)
 cmds=[(cmd,'compile-bbox-local-resolved-relative'),(link,'final-link')]
 (M.O/'relative-output-preflight.json').write_text(json.dumps([validate(q,M.N,cwd=M.R)for q,_ in cmds],indent=2)+'\n');M.B.O=M.O;M.B.N=M.N
 for q,name in cmds:M.B.run(q,name)
 from prepare_cv3_dmc_mirror import prepare
 prepare(M.R,M.N/'candidate.nes')
 (M.O/'source-stage.json').write_text(json.dumps(dict(candidate=M.B.sha(M.N/'candidate.nes'),native=False,installed=False,scope='Selected-only actual adapter plus in-place A79 classification. Controls pending.'),indent=2)+'\n');print((M.O/'source-stage.json').read_text())
if __name__=='__main__':main()
