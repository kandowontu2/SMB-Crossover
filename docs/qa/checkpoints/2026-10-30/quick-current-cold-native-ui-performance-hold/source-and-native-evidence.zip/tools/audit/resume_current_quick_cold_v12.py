"""Use explicit new-root ca65 outputs instead of a nonexistent inherited log."""
import inspect,json
from pathlib import Path
import prepare_current_quick_cold_v12 as M
text=inspect.getsource(M.main);a=text.index(' basecmd=');text='def main():\n'+text[a:]
old="basecmd=rebase(json.loads((OLD/'compile-quick-bridge.json').read_text())['command'])"
new="basecmd=[str(B.CA),'-g','--cpu','6502x','-I',str(N),'-I',str(N/'src'),'-I',str(N/'component-src'),'-I',str(N/'quick'),'-I',str(R),'--bin-include-dir',str(N),'--bin-include-dir',str(R),'--create-full-dep',str(N/'quick/host-bridge.dep'),'-o',str(N/'quick/host-bridge.o'),str(N/'quick/host-bridge.s')]"
assert text.count(old)==1;exec(compile(text.replace(old,new),__file__,'exec'),M.__dict__)
if __name__=='__main__':
 (M.O/'retained-missing-inherited-log-negative.json').write_text(json.dumps(dict(native=False,no_compiler_ran=True,error='v11 did not rebuild bridge, so no bridge command log exists there. Explicit bounded new-root ca65 recipe replaces inherited-log lookup.'),indent=2)+'\n')
 M.main()
