"""Freeze the natural source milestone and prepare (never launch) native smoke."""
from pathlib import Path
import inspect,json
import prepare_current_quick_cold_v12 as B
import quickman_wram_palette_native_v6 as G
import arthur_body_fair_budget_v7 as Q
from check_tmnt_render_oa import load,address,location
R=B.R;O=B.O;N=B.N
def main():
 assert not(O/'handoff.json').exists()and not(O/'native-prepared.json').exists()
 reports=[O/'area-geometry/actual-area-geometry.json',O/'cold-API-controls.json',O/'cold-real-ISR-controls.json',O/'cold-lifecycle-controls.json',O/'foreign-complete-Main-controls.json']
 for p in reports:
  d=json.loads(p.read_text());assert d['passed'],p
  for path,value in d['bindings'].items():assert B.B.sha(path)==value,path
 # Source-aware historical fixture is regenerated against actual new DBG,
 # genuine cookie STA operands/RTIs and exact shifted RAM entry instructions.
 G.O=N;text=inspect.getsource(G.main);text=text.replace('source_code_bytes=6512','source_code_bytes=6541');exec(compile(text,__file__,'exec'),G.__dict__);G.main()
 p=N/'native-palette-v6.lua';s=p.read_text()
 old="else exact=exact and(r('SelectedCharacter')~=9 or r('FmAlts')&32==0)and emu.read(0xdfe1,emu.memType.nesDebug)==9 end"
 new="else exact=exact and(r('CrossoverMenuIndex')~=9 or r('FmAlts')&32==0)and emu.read(0xdfe1,emu.memType.nesDebug)==9 end"
 assert s.count(old)==1;s=s.replace(old,new,1)
 # Passive source-owned audio/OAM observations; no media frame forest.
 addition=r'''
local apu=assert(io.open(OUTPUT..'gameplay-APU.csv','w'))
apu:write('frame,address,value\n')
local oam=assert(io.open(OUTPUT..'gameplay-OAM.csv','w'))
oam:write('frame,page,offset,records64hex\n')
local apuWrites,oamDmas=0,0
emu.addMemoryCallback(function(a,v)
 if phase~='game'then return end
 apuWrites=apuWrites+1;assert(apuWrites<=20000,'Bounded passiveAPU log')
 apu:write(table.concat({wall,a,v},',')..'\n')
end,emu.callbackType.write,0x4000,0x4017)
emu.addMemoryCallback(function(_,page)
 if phase~='game'then return end
 oamDmas=oamDmas+1;assert(oamDmas<=1000,'Bounded passiveOAM log')
 local raw={};for i=0,255 do raw[#raw+1]=string.format('%02x',emu.read(page*256+i,emu.memType.nesDebug))end
 oam:write(table.concat({wall,page,r('CurrentOAMOffset'),table.concat(raw)},',')..'\n')
end,emu.callbackType.write,0x4014)
'''
 anchor="local function finish()";assert s.count(anchor)==1;s=s.replace(anchor,addition+'\n'+anchor,1)
 s=s.replace(' palette:close();guardEvents:close()',' palette:close();guardEvents:close();apu:close();oam:close()',1)
 assert 'emu.write('not in s and s.count('wall>=1000')==1 and s.count('shots<=6')==1
 p.write_text(s,newline='\n')
 # Native-only fixture files sit beside the exact ROM for TEST_DIR reads.
 # The source packet is frozen only after every generated fixture is final.
 b=load(N/'candidate.nes');sites=json.loads((N/'native-palette-prepared.json').read_text())['exact_source_cookie_store_sites']
 budget=O/'native-capture-budget.py';actual=R/'tools/audit/capture_budget.py';budget.write_text(actual.read_text().replace('RUN_BYTES = 2_000_000_000','RUN_BYTES = 536_870_912').replace('receipt = preflight(output)','receipt = preflight(output, reserved_bytes=RUN_BYTES, reserved_files=RUN_FILES)'),newline='\n')
 module=Q.load(budget);storage=module.preflight(O/'native/cold-menu-game-v1',reserved_bytes=536870912,reserved_files=64);(O/'native-storage-preflight.json').write_text(json.dumps(storage,indent=2)+'\n')
 tools=[p for p in(R/'tools/audit').glob('*.py')if p.name.startswith(('prepare_current_quick_cold_','resume_current_quick_cold_','current_quick_natural_cold_','current_quick_cold_','current_quick_actual_area_','run_current_quick_cold_'))]+[Path(__file__)]
 files=[p for p in N.rglob('*')if p.is_file()]+reports+tools+[O/'source-stage.json',O/'output-preflight.json',R/'build/current-character-quick-transport-v4/handoff.json',R/'build/current-character-quick-cold-v11/source-HP-persistence-negative-handoff.json']
 h=dict(status='FROZEN_NATURAL_QUICK_SOURCE_READY_NATIVE_PENDING',candidate=B.B.sha(N/'candidate.nes'),native=False,installed=False,code_bytes=6541,data_bytes=1921,cookie=(N/'quick/cookie.bin').read_bytes().hex(),scope='Actual cold menu/Start/post-Ic/area/scene/entrance and120genuineMain with real parsed1-1 blockbuffers/NMI; source movement/graphics/draw/weapons/fullbox/sync once; immediate two-playerHP persistence;3840allflagforeign callbacks/2540realISR/282foreignwholeMain.',resources=dict(C98_bridge_bytes=224,C98_bridge_limit=260,A70_router_bytes=788,A70_router_limit=789,A79_bytes=2591,A79_limit=2592,bbox_body_bytes=59,bbox_body_limit=64,bbox_Quick93_tail_bytes=15,bbox_Quick93_tail_limit=25,no_new_resources=True),foreign_cost=dict(vs_frozen_Quick_v4_CPU_delta=json.loads(reports[-1].read_text())['CPU_delta'],note='Includes sourceUI adoption−297 and added Bass/expanded adder/box/head C98 dispatch; no foreignfullbox/postTerrain mapper entry added. Allnativeapplication/AXYP/orderedwrites/OAM/CHR/33SMC exact.'),limits=['No native qualification yet; privateQuick readiness is for controlled WIP test only.','Nativeall1-1 clear/earnedpowerups/pause/death/area transitions and actualCXaudio stillopen.','Foreign+430CPU worstcase and severeArthurlag remainperformance holds, no60Hzclaim.'],bindings={str(p.resolve()):B.B.sha(p)for p in files})
 (O/'handoff.json').write_text(json.dumps(h,indent=2)+'\n')
 opts=['--doNotSaveSettings','--nes.ramPowerOnState=AllZeros','--nes.randomizeCpuPpuAlignment=false','--nes.randomizeMapperPowerOnState=false','--nes.removeSpriteLimit=false','--nes.adaptiveSpriteLimit=false']
 prepared=dict(status='PREPARED_ONLY_REQUIRES_EXPLICIT_ROOT_ONE_RUN_GRANT',candidate=h['candidate'],handoff=B.B.sha(O/'handoff.json'),command='python tools/audit/run_current_quick_cold_native_v12.py --launch',config=dict(max_physical_frames=1000,gameplay_physical_frames=220,screenshots=6,files=64,reserved_bytes=536870912,timeout_seconds=60,AllZeros=True,normal8sprites=True,no_debug_RAM_writes=True),options=opts,exact_cookie_STA_sites=sites,cookie=h['cookie'],profile='Gameplayages10..190 actual rawbank/stackreturn Main+source spans, realNMI/IRQ subtracted; coldloader excluded. Passive PPU/OAM/APU logs.',bindings={str(q.resolve()):B.B.sha(q)for q in[Path(__file__),R/'tools/audit/run_current_quick_cold_native_v12.py',R/'tools/run_mesen.py',Path(Q.__file__),actual,budget,O/'handoff.json',O/'native-storage-preflight.json',N/'candidate.nes',N/'candidate.dbg',N/'candidate.lbl',N/'native-palette-v6.lua',N/'native-profile-v6.lua',N/'native-profile-config-v6.json',N/'code.bin',N/'data.bin',N/'quick/cookie.bin']})
 (O/'native-prepared.json').write_text(json.dumps(prepared,indent=2)+'\n');print(json.dumps(dict(candidate=h['candidate'],handoff=B.B.sha(O/'handoff.json'),prepared=B.B.sha(O/'native-prepared.json'),bindings=len(h['bindings']),config=prepared['config'],cookie_sites=sites)))
if __name__=='__main__':main()
