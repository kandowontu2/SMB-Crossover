"""Assert transient fan slots, preserving the authentic live player actor."""
import inspect
import current_quick_cold_lifecycle_v11 as M
text=inspect.getsource(M.main)
text=text.replace("out=O/'cold-lifecycle-controls.json'","out=O/'cold-lifecycle-controls-v11b.json'")
old="assert all(m.get('QmField_0420')==0 for _ in[0]),'Actual source reset must clear actor0'"
new="assert all(m.get('QmField_042'+str(i))==0 for i in[2,3,4]),'Genuine scene reset must clear three transient fan actors; actor0 is the live original player'"
assert text.count(old)==1;exec(compile(text.replace(old,new),__file__,'exec'),M.__dict__)
if __name__=='__main__':M.main()
