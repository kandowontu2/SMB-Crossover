"""Natural Quick post-clear/forcedblank acquisition, current UI source adoption."""
from pathlib import Path
import difflib,json,shutil
import prepare_current_quick_transport_v4 as C
from private_build_outputs_v1 import validate
B=C.B;R=C.R;P=C.N;OLD=C.O;O=R/'build/current-character-quick-cold-v5';N=O/'joint'
U=R/'build/new-roster-ui-source-route-1030-v5'
def rebase(cmd,p):return[x.replace(str(p),str(N)).replace(p.as_posix(),N.as_posix())for x in cmd]
def main():
 assert not O.exists();C.C.check_bindings(OLD/'handoff.json');C.C.check_bindings(R/'build/new-roster-ui-source-route-qualified-1030-v1/handoff.json')
 O.mkdir();shutil.copytree(P,N)
 for p in N.rglob('*'):
  if p.is_file()and p.suffix in['.s','.inc','.cfg']:
   s=p.read_text();z=s.replace(str(P),str(N)).replace(P.as_posix(),N.as_posix())
   if s!=z:p.write_text(z,newline='\n')
 (N/'src/x5_bounce.s').write_text((U/'x5_bounce.s').read_text(),newline='\n')
 p=N/'entrypoint.s';s=p.read_text();p.write_text('.import QwBoot,QwSceneInit\n'+s,newline='\n')
 p=N/'src/new_roster_dispatch.s';s=p.read_text();assert s.count('farcall SunnyGlobalInit')==2;s=s.replace('farcall SunnyGlobalInit','farcall QwBoot');p.write_text(s,newline='\n')
 p=N/'screen_render.s';s=p.read_text();assert s.count('farcall ArGenSceneInit')==1;s=s.replace('farcall ArGenSceneInit','farcall QwSceneInit');p.write_text(s,newline='\n')
 p=N/'quick/loader.s';s=p.read_text();s='.import ArGenSceneInit\n'+s;assert s.count('RomCall MoveAllSpritesOffscreen')==1;s=s.replace('RomCall MoveAllSpritesOffscreen','RomCall ArGenSceneInit');p.write_text(s,newline='\n')
 p=N/'src/full_roster_menu.s';s=p.read_text();old=' lda #31\n sec\n rts\nNotQuickMan:';assert s.count(old)==1;s=s.replace(old,' lda #31\n clc\n rts\nNotQuickMan:');p.write_text(s,newline='\n')
 for name in['entrypoint.s','src/x5_bounce.s','src/new_roster_dispatch.s','screen_render.s','quick/loader.s','src/full_roster_menu.s']:
  (O/(Path(name).name+'.diff')).write_text(''.join(difflib.unified_diff((P/name).read_text().splitlines(True),(N/name).read_text().splitlines(True),fromfile='parent/'+name,tofile='successor/'+name)),newline='\n')
 cmds=[(rebase(json.loads((OLD/'compile-main.json').read_text())['command'],P),'compile-main')]
 # Compile both changed source producers explicitly, validating all outputs
 # and the actual full config's MEMORY outputs before the first command.
 q=rebase(json.loads((R/'build/current-character-composition-v1/compile-quick-loader.json').read_text())['command'],R/'build/current-character-composition-v1/joint')if(R/'build/current-character-composition-v1/compile-quick-loader.json').exists()else None
 if q is None:
  q=[str(B.CA),'-g','--cpu','6502x','-I',str(N),'-I',str(N/'src'),'-I',str(N/'component-src'),'-I',str(N/'quick'),'-I',str(R),'-I',str(R/'build/character-host-union-v13'),'--bin-include-dir',str(N),'--bin-include-dir',str(R),'--create-full-dep',str(N/'quick/loader.dep'),'-o',str(N/'quick/loader.o'),str(N/'quick/loader.s')]
 cmds.append((q,'compile-quick-loader'));cmds.append((rebase(json.loads((OLD/'final-link.json').read_text())['command'],P),'final-link'))
 (O/'output-preflight.json').write_text(json.dumps([validate(q,N,cwd=R)for q,_ in cmds],indent=2)+'\n')
 B.O=O;B.N=N
 for cmd,name in cmds:B.run(cmd,name)
 from prepare_cv3_dmc_mirror import prepare
 prepare(R,N/'candidate.nes')
 for name in['code.bin','data.bin','ram3.bin','ff-cookie.bin','quick/cookie.bin']:assert(N/name).read_bytes()==(P/name).read_bytes(),name
 C.C.check_bindings(OLD/'handoff.json')
 (O/'source-stage.json').write_text(json.dumps(dict(candidate=B.sha(N/'candidate.nes'),parent=B.sha(P/'candidate.nes'),native=False,installed=False,source_changes=['Quick row15 already genuineQwConstruct; actual post-Ic Sunny calls nowQwBoot (Sunnyexactlyonce).','Real InitScreen QwSceneInit ownconstructor then genuine ArGenSceneInit→FwSceneInit/nativeMove/ArLoad chain retained.','PrivateQuick pendingbit clear only for actual menuindex9/FmAlts20;Startidentity genuine predecessor exact.','Rootqualified source-preserving NrUi route adopted; source>=20UIremainsactive.'],limits=['Naturalcold/life/pause/cacheownercontrols pending; do not prepare native yet.','Before-selected Quickmenu cookie retirement not yet installed; own helper being coordinated.','Native1-1/powerups/CXaudio remain open obligations.']),indent=2)+'\n');print((O/'source-stage.json').read_text())
if __name__=='__main__':main()
