"""Natural cold acquisition plus genuine area-parser block buffers and Main."""
from pathlib import Path
import inspect,json,traceback
import prepare_current_quick_cold_v11 as B
import current_quick_natural_cold_controls_v6 as M
C=M.C;N=B.N;O=B.O/'area-geometry';O.mkdir(exist_ok=False)
M.B=B;M.N=N;M.O=O;C.O=N;C.CODE=(N/'code.bin').read_bytes();C.DATA=(N/'data.bin').read_bytes()
text=inspect.getsource(C.invoke);old="if requested!='GameLoop':assert m.tags==incoming,('public mapper restore',requested,m.tags,incoming)"
assert text.count(old)==1;text=text.replace(old,"assert m.tags[0:2]==incoming[0:2]and m.tags[3]==incoming[3],('real callback A/low/fixed restore',requested,m.tags,incoming)")
exec(compile(text,__file__,'exec'),C.__dict__)
def put(m,**kw):M.put(m,**kw)
def count(m,r,n):
 pc=m.lab[n];bank=1 if n.startswith('Qh')or n.startswith('QuickMan')else m.bank(n)|128
 return sum(p==pc and tags[(p-32768)//8192]==bank for tags,p in r['trace']if p>=32768)
def main():
 d=dict(passed=False,native=False,checks={});out=O/'actual-area-geometry.json'
 try:
  m=M.fresh();C.invoke(m,'PrimaryGameSetup');put(m,OperMode=0,CrossoverMenuState=2,DisableScreenFlag=0,Mirror_PPUMASK=24,FamilyMainCommit=1)
  for n in['MenuResolveCharacter','QueueSelection','DrawSelectionPreview']:C.invoke(m,n)
  put(m,SavedJoypad1Bits=16,SavedJoypad2Bits=0);C.invoke(m,'CrossoverMenuInput')
  put(m,OperMode=1,OperMode_Task=0,DisableScreenFlag=1,Mirror_PPUMASK=0,NmiDisable=255,FamilyMainCommit=1);m.ppu_mask=0
  for n in['LoadAreaPointer','InitializeArea','InitScreen']:C.invoke(m,n)
  assert m.get('QmField_06C0')==40
  parser=[]
  put(m,ScreenRoutineTask=8)
  for age in range(20):
   if m.get('ScreenRoutineTask')!=8:break
   r=C.invoke(m,'AreaParserTaskControl');parser.append([age,m.get('ColumnSets'),r['CPU']])
   # Consume the genuine native full-column queue through the real NMI.
   put(m,FamilyMainCommit=0,NmiDisable=0)
   c=C.H.N.NesMPU(memory=m,pc=0x7fff);c.sp=255;c.p=0x30
   C.interrupt_at(m,c,'NMI')
   put(m,FamilyMainCommit=1,NmiDisable=255)
  assert m.get('ScreenRoutineTask')==9,('native parser progression',parser)
  d['checks']['native_area_parser_and_real_NMI']=parser
  floor=bytes(m.ram[m.lab['Block_Buffer_1']:m.lab['Block_Buffer_1']+0xd0]);assert any(floor),'actual parsed block buffer is empty'
  for n in['SecondaryGameSetup','Entrance_GameTimerSetup','PlayerEntrance']:C.invoke(m,n)
  assert m.get('GameEngineSubroutine')==8
  put(m,OperMode=1,OperMode_Task=3,Player_CollisionBits=255)
  rows=[];names=['QhMovement','QhGraphics','QhDraw','QhWeapons','QhBox','QhSync','QhHead','QhSide','QhAdder','QhBoxProfile']
  for age in range(120):
   keys=1|(128 if 16<=age<32 else 0)|(64 if 40<=age<56 else 0)
   put(m,SavedJoypadBits=keys,SavedJoypad1Bits=keys,A_B_Buttons=keys&192,Left_Right_Buttons=keys&3,Up_Down_Buttons=0,NmiDisable=255,FamilyMainCommit=1,VRAM_Buffer_AddrCtrl=0,VRAM_Buffer1_Offset=0)
   r=C.invoke(m,'GameLoop');counts={n:count(m,r,n)for n in names}
   assert all(counts[n]==1 for n in names[:6]),('real Main exactly-once source consumers',age,counts)
   row=dict(age=age,keys=keys,X=m.get('Player_X_Position')+256*m.get('Player_PageLoc'),Y=m.get('Player_Y_Position'),YHigh=m.get('Player_Y_HighPos'),HP=m.get('QmField_06C0'),Camera=m.get('ScreenLeft_X_Pos')+256*m.get('ScreenLeft_PageLoc'),State=m.get('Player_State'),CPU=r['CPU'],counts=counts)
   rows.append(row);assert row['HP']>0 and row['YHigh']==1,('no fall/death on genuine parsed1-1 geometry',row)
  assert max(x['X']for x in rows)>rows[0]['X']+50,('actual horizontal progress',rows)
  assert min(x['Y']for x in rows)<min(x['Y']for x in rows[:12])-16,('genuine held A source jump',rows)
  d.update(passed=True,rows=rows,limits=['Actual parsed1-1 initial geometry CPU test; no native controller/cadence, full1-1 clear, allpowerups or CXaudio claim.'])
 except Exception as e:d.update(error=repr(e),traceback=traceback.format_exc());d.setdefault('rows',locals().get('rows',[]))
 d['bindings']={str(Path(p).resolve()):B.B.sha(p)for p in[__file__,N/'candidate.nes',N/'candidate.dbg']};out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(passed=d['passed'],error=d.get('error'),Main_updates=len(d.get('rows',[])))));assert d['passed'],d.get('error')
if __name__=='__main__':main()
