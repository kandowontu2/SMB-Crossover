"""Only ONE explicitly root-granted unchanged bounded native run."""
from pathlib import Path
import json,os,sys
import prepare_current_quick_cold_v12 as B
import arthur_body_fair_budget_v7 as Q
O=B.O;N=B.N;T=O/'native/cold-menu-game-v1'
def main():
 assert sys.argv[1:]==['--launch']and not T.exists(),'One explicit root grant; preserve every prior result.'
 p=json.loads((O/'native-prepared.json').read_text());h=json.loads((O/'handoff.json').read_text())
 def verify():
  for d in[p,h]:
   for path,value in d['bindings'].items():assert B.B.sha(path)==value,path
  assert p['candidate']==h['candidate']==B.B.sha(N/'candidate.nes')
 verify();T.parent.mkdir(exist_ok=True);os.environ['SMB_RUN_OUTPUT']=str(T.resolve())
 budget=Q.load(O/'native-capture-budget.py');run=Q.run_function(budget)
 meta=dict(candidate=p['candidate'],prepared=B.B.sha(O/'native-prepared.json'),handoff=B.B.sha(O/'handoff.json'),bindings_verified=len(p['bindings'])+len(h['bindings']),options=p['options'],config=p['config'])
 (O/'native-preflight.json').write_text(json.dumps(meta,indent=2)+'\n')
 rc=run(N/'native-palette-v6.lua',N/'candidate.nes',timeout=60,emulator_options=p['options']);verify()
 (O/'native-postflight.json').write_text(json.dumps(dict(**meta,exit_code=rc,pre_post_bindings_exact=True),indent=2)+'\n')
 print(json.dumps(dict(native_terminal=True,exit_code=rc,candidate=p['candidate'],output=str(T.resolve()),bindings_pass=True)),flush=True);raise SystemExit(rc)
if __name__=='__main__':main()
