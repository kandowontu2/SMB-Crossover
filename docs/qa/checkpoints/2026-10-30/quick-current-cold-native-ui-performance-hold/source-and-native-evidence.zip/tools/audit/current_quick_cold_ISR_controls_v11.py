"""Real normal/lag NMI+IRQ across the new source island and frame seams."""
import json,traceback
from pathlib import Path
import prepare_current_quick_cold_v11 as B
import current_quick_transport_controls_v4 as T
C=T.C;S=T.S;O=B.O;N=B.N
def main():
 out=O/'cold-real-ISR-controls.json';assert not out.exists();d=dict(passed=False,native=False);C.O=N;C.CODE=(N/'code.bin').read_bytes();C.DATA=(N/'data.bin').read_bytes()
 try:
  template=C.Bus();C.invoke(template,'QwConstruct');C.exact_cache(template)
  for n,v in [('GameEngineSubroutine',8),('OperMode',1),('OperMode_Task',3),('Player_Y_HighPos',1),('Player_Y_Position',160),('Player_X_Position',96),('FamilyMainCommit',1),('CrossoverMenuIndex',0),('Player_BoundBoxCtrl',12)]:template.set(n,v)
  rows=[]
  paths=[('QwMovementGate',9,32),('QwAdderGate',9,32),('QwBoxProfileGate',9,32),('QwHeadGate',9,32),('HuPlayerSubsAdapter',9,32),('HuAfterTerrainGate',9,32),('HuAfterTerrainGate',9,0),('HuDrawAll',0,0),('HuBeforeEffects',0,0),('HuAfterEffects',0,0),('QwMenuResolve',9,0)]
  for target,raw,alt in paths:
   base=S.clone(template);base.set('SelectedCharacter',raw);base.set('FmAlts',alt);m=S.clone(base);cuts=[];seen=set();age=0
   def observe(c):
    nonlocal age
    pc=c.pc;tag=m.tags[(pc-32768)//8192]if pc>=32768 else-1;op=bytes(m[pc:pc+3]);key=(tag,pc)
    owned=(tag==207 and m.lab['HuStart']<=pc<m.lab['HuEnd'])or(tag==226 and m.lab['QwMovementGate']<=pc<m.lab['QwHostBridgeEnd'])or(tag==221 and 0xafa7<=pc<0xaff6)or(tag==198 and m.lab['QwMenuRetire']<=pc<m.lab['QwPortrait'])
    if key not in seen and (owned or 0x15a<=pc<0x17b or op in[b'\x8d\x15\x51',b'\x8d\x16\x51']):seen.add(key);cuts.append((age,pc,tag))
    age+=1
   S.execute(m,target,A=9 if 'Adder'in target or 'Profile'in target else 131,X=0,Y=12,P=0x71,hook=observe)
   for cut,pc,tag in cuts:
    for lag in[0,255]:
     for kind in['NMI','IRQ']:
      q=S.clone(base);q.set('NmiDisable',lag);age=0;proof=[]
      def inject(c):
       nonlocal age
       if age==cut:
        assert c.pc==pc
        if kind=='IRQ'and c.p&c.INTERRUPT:return
        proof.append(C.interrupt_at(q,c,kind))
       age+=1
      S.execute(q,target,A=9 if 'Adder'in target or 'Profile'in target else 131,X=0,Y=12,P=0x71,hook=inject)
      if proof:rows.append(dict(target=target,raw=raw,alts=alt,step=cut,PC=pc,tag=tag,lag=lag,requested_kind=kind,**proof[0]))
  d.update(passed=True,real_vectors=len(rows),rows=rows,scope='Every executed newA79/C98/adapter/menu instruction plus resident33SMC and actualmapper seams. StrictAXYP/SP/rawmaps/shadows/R01/R67/all33SMC/livepage1/code/data preserved. No native cadence claim.')
 except Exception as e:d.update(error=repr(e),traceback=traceback.format_exc())
 d['bindings']={str(Path(p).resolve()):B.B.sha(p)for p in[__file__,N/'candidate.nes',N/'candidate.dbg']};out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(passed=d['passed'],error=d.get('error'),vectors=d.get('real_vectors'))));assert d['passed'],d.get('error')
if __name__=='__main__':main()
