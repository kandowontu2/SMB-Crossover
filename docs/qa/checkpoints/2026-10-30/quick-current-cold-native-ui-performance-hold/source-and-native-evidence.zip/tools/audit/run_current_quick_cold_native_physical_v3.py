"""ONE separately root-granted physical-ROM-qualified fixture retry."""
import json,os,sys
import prepare_current_quick_cold_v12 as B
import arthur_body_fair_budget_v7 as Q
O=B.O;N=B.N;F=O/'native-physical-guard-v3b';T=O/'native/cold-menu-game-v3'
def main():
 assert sys.argv[1:]==['--launch']and not T.exists(),'Separate explicit root grant; no automatic retry.'
 docs=[json.loads(p.read_text())for p in[O/'handoff.json',O/'native-prepared.json',F/'prepared.json',F/'native-ready.json']];source,original,proof,ready=docs
 def verify():
  for d in docs:
   for path,value in d['bindings'].items():assert B.B.sha(path)==value,path
  assert ready['candidate']==source['candidate']==B.B.sha(N/'candidate.nes')
 verify();T.parent.mkdir(exist_ok=True);os.environ['SMB_RUN_OUTPUT']=str(T.resolve());budget=Q.load(O/'native-capture-budget.py');run=Q.run_function(budget)
 meta=dict(candidate=ready['candidate'],source_handoff=B.B.sha(O/'handoff.json'),fixture_prepared=B.B.sha(F/'prepared.json'),native_ready=B.B.sha(F/'native-ready.json'),bindings_verified=sum(len(d['bindings'])for d in docs),options=original['options'],config=original['config'])
 (F/'native-preflight.json').write_text(json.dumps(meta,indent=2)+'\n')
 rc=run(F/'native-physical-v3.lua',N/'candidate.nes',timeout=60,emulator_options=original['options']);verify()
 (F/'native-postflight.json').write_text(json.dumps(dict(**meta,exit_code=rc,pre_post_bindings_exact=True),indent=2)+'\n')
 print(json.dumps(dict(native_terminal=True,exit_code=rc,candidate=ready['candidate'],output=str(T.resolve()),bindings_pass=True)),flush=True);raise SystemExit(rc)
if __name__=='__main__':main()
