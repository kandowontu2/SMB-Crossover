"""Count the original PLA/PLP as part of the moved native legacy tail."""
import json
import prepare_current_quick_cold_v11 as M
from private_build_outputs_v1 import validate
def main():
 neg=M.O/'retained-size-assertion-negative.json';assert not neg.exists();neg.write_bytes((M.O/'compile-bbox-local-single-segment.json').read_bytes())
 p=M.N/'bbox-local.s';s=p.read_text();s=s.replace('=61,error,"Exact own61B','=59,error,"Exact own59B').replace('*=$aff4','*=$aff6').replace('Only13B used','Only15B used').replace('original13B','original15B');p.write_text(s,newline='\n')
 cmd=json.loads((M.O/'compile-bbox-local.json').read_text())['command'];link=M.rebase(json.loads((M.M.C.O/'final-link.json').read_text())['command'],M.M.C.N)
 cmds=[(cmd,'compile-bbox-local-exact-size'),(link,'final-link')]
 (M.O/'exact-size-output-preflight.json').write_text(json.dumps([validate(q,M.N,cwd=M.R)for q,_ in cmds],indent=2)+'\n');M.B.O=M.O;M.B.N=M.N
 for q,name in cmds:M.B.run(q,name)
 from prepare_cv3_dmc_mirror import prepare
 prepare(M.R,M.N/'candidate.nes')
 (M.O/'source-stage.json').write_text(json.dumps(dict(candidate=M.B.sha(M.N/'candidate.nes'),native=False,installed=False,scope='Adapter59/64B; unchanged native Mario+legacy15B moved into retained Quick25B suffix; remaining10B unused. Controls pending.'),indent=2)+'\n');print((M.O/'source-stage.json').read_text())
if __name__=='__main__':main()
