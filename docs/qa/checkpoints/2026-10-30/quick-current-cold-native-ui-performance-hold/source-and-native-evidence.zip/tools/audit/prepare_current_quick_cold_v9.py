"""Correct source entry names; retain the v8 precompile lookup negative."""
import inspect,json
from pathlib import Path
import prepare_current_quick_cold_v8 as M
M.O=M.R/'build/current-character-quick-cold-v9';M.N=M.O/'joint'
text=inspect.getsource(M.main)
a=text.index(' assert not O.exists();oldh=')
b=text.index(' O.mkdir();',a)
text=text[:a]+" assert not O.exists();oldh=OLD/'source-milestone-handoff.json'\n C.C.C.C.C.check_bindings(oldh)\n"+text[b:]
for old,new in [('HuMenuDraw','HuMenuPortrait'),('HuCollision','HuMature'),('HuStomp','HuBounceOnly'),('HuTerrainHead','HuHeadWithinOnly')]:text=text.replace("('"+old+"',","('"+new+"',")
exec(compile(text,__file__,'exec'),M.__dict__)
if __name__=='__main__':
 old=M.R/'build/current-character-quick-cold-v8'
 (old/'retained-source-lookup-negative.json').write_text(json.dumps(dict(native=False,stage='before compiler/output preflight',error='Four proposed service names differ from actual Hu public names. Original v7 and all frozen bytes untouched.',bindings={str(Path(p).resolve()):M.B.sha(p)for p in [__file__,M.__file__,M.P/'candidate.nes']}),indent=2)+'\n')
 M.main()
