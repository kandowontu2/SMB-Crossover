"""Persist host contact HP immediately before scene/player retirement.

The authenticated CX movement/contact/boomerang kernel stays byte-exact.
Only its SMB injury adapter gains a register/flag-preserving persistence call.
"""
from pathlib import Path
import hashlib,json,shutil
import prepare_current_quick_cold_v11 as C
from private_build_outputs_v1 import validate
from check_tmnt_render_oa import load,address
B=C.B;R=C.R;P=C.N;OLD=C.O;O=R/'build/current-character-quick-cold-v12';N=O/'joint'
def rebase(q):return[x.replace(str(P),str(N)).replace(P.as_posix(),N.as_posix())for x in q]
def main():
 assert not O.exists();h=OLD/'source-HP-persistence-negative-handoff.json';assert not h.exists()
 h.write_text(json.dumps(dict(status='FROZEN_REAL_HP_PERSISTENCE_NEGATIVE',candidate=B.sha(P/'candidate.nes'),native=False,notes='Source injuryHP40→36; without anotherMovement persistentrecord remains40, so immediate actualscene/player reset heals to40. Positive natural120Main/API3840/ISR2540/foreign282 retained.',bindings={str(p.resolve()):B.sha(p)for p in list(OLD.rglob('*'))+[Path(C.__file__)]if p.is_file()}),indent=2)+'\n')
 O.mkdir();shutil.copytree(P,N)
 for p in N.rglob('*'):
  if p.is_file()and p.suffix in['.s','.inc','.cfg']:
   s=p.read_text();z=s.replace(str(P),str(N)).replace(P.as_posix(),N.as_posix())
   if z!=s:p.write_text(z,newline='\n')
 p=N/'quick/whole.s';s=p.read_text();a=s.index('QhInjury:\n');b=s.index('.segment "QW_CODE"\nQhStatus:',a);part=s[a:b];assert part.count(' sta QmField_06C0')==2
 part=part.replace(' sta QmField_06C0',' sta QmField_06C0\n jsr QhSaveContactHP')
 part+='''; Host persistent record must reflect damage even if the next native
; action is an area/player/life transition rather than another movement tick.
; Exact incoming A/X/Y/P survives; no new RAM or source-physics field.
QhSaveContactHP:
 php
 pha
 txa
 pha
 lda _CurrentPlayer
 and #1
 asl
 asl
 tax
 lda QmField_06C0
 sta QhPersistent,x
 pla
 tax
 pla
 plp
 rts
'''
 s=s[:a]+part+s[b:];p.write_text(s,newline='\n')
 basecmd=rebase(json.loads((OLD/'compile-quick-bridge.json').read_text())['command'])
 def ca(name):return[x.replace(str(N/'quick/host-bridge.'),str(N/('quick/'+name+'.')))for x in basecmd]
 link=rebase(json.loads((OLD/'final-link.json').read_text())['command']);cmds=[(ca(x),'compile-quick-'+x)for x in['whole','portrait','loader','stream','host-bridge']]+[(link,'initial-link'),(ca('loader'),'final-loader'),(ca('stream'),'final-stream'),(link,'final-link')]
 (O/'output-preflight.json').write_text(json.dumps([validate(q,N,cwd=R)for q,_ in cmds],indent=2)+'\n');B.O=O;B.N=N
 for q,name in cmds[:6]:B.run(q,name)
 actual=load(N/'candidate.nes');sizes={v['name'].strip('"'):int(v['size'],0)for v in actual['segs'].values()};assert sizes['QW_CODE']<=7168 and sizes['QW_DATA']<=2048
 code=(N/'code.bin').read_bytes();data=(N/'data.bin').read_bytes();cookie=bytes([167,9,32,5])+hashlib.sha256(code[:sizes['QW_CODE']]+data[:sizes['QW_DATA']]).digest()[:12]
 (N/'quick/cookie.bin').write_bytes(cookie);(N/'quick/stream.bin').write_bytes(code[:7168]+data[:2048])
 for q,name in cmds[6:]:B.run(q,name)
 from prepare_cv3_dmc_mirror import prepare
 prepare(R,N/'candidate.nes')
 native_end=address(actual,'QhDispatch')-0xa000;assert(N/'code.bin').read_bytes()[:native_end]==(P/'code.bin').read_bytes()[:native_end]
 assert(N/'data.bin').read_bytes()==(P/'data.bin').read_bytes()
 for name in['ram3.bin','ff-cookie.bin']:assert(N/name).read_bytes()==(P/name).read_bytes(),name
 raw=(N/'candidate.nes').read_bytes();assert raw[16+128*8192+884*1024:16+128*8192+893*1024]==(N/'quick/stream.bin').read_bytes()
 (O/'source-stage.json').write_text(json.dumps(dict(candidate=B.sha(N/'candidate.nes'),parent=B.sha(P/'candidate.nes'),native=False,installed=False,code_bytes=sizes['QW_CODE'],data_bytes=sizes['QW_DATA'],cookie=cookie.hex(),authenticated_native_prefix_bytes_exact=native_end,scope='Immediate per-player HP persistence in SMB injury adapter only; all native CX controller/physics routines and code/data/header leases preserved. Requalification pending.'),indent=2)+'\n');print((O/'source-stage.json').read_text())
if __name__=='__main__':main()
