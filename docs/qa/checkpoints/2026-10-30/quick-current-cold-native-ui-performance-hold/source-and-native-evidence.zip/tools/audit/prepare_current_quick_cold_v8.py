"""Selected-only full-body/post-terrain routing without new foreign mappings."""
from pathlib import Path
import difflib,json,re,shutil
import prepare_current_quick_cold_v7 as C
from private_build_outputs_v1 import validate
B=C.B;R=C.R;P=C.N;OLD=C.O;O=R/'build/current-character-quick-cold-v8';N=O/'joint'
def rebase(cmd,p=P):return[x.replace(str(p),str(N)).replace(p.as_posix(),N.as_posix())for x in cmd]
def main():
 assert not O.exists();oldh=OLD/'source-milestone-handoff.json';assert not oldh.exists()
 oldh.write_text(json.dumps(dict(status='FROZEN_GENUINE_NATURAL_COLD_MOVEMENT_MILESTONE',candidate=B.sha(P/'candidate.nes'),native=False,limits=['Full-box/post-terrain source consumers absent; no healthy-floor/native claim.'],bindings={str(p.resolve()):B.sha(p)for p in list(OLD.rglob('*'))+[Path(C.__file__)]if p.is_file()}),indent=2)+'\n')
 O.mkdir();shutil.copytree(P,N)
 for p in N.rglob('*'):
  if p.is_file()and p.suffix in['.s','.inc','.cfg']:
   s=p.read_text();z=s.replace(str(P),str(N)).replace(P.as_posix(),N.as_posix())
   if s!=z:p.write_text(z,newline='\n')
 p=N/'quick/host-bridge.s';s=p.read_text();s=s.replace('.import RlMovementDispatch,HotCollisionAdder,HotCollisionBox,TnFastHeadGate','.import RlMovementDispatch,HotCollisionAdder,HotCollisionBox,TnFastHeadGate\n.import PlayerBGCollision,HuLegacyPostBG,QwSyncGate\n.export QwFullBox,QwAfterTerrain')
 s=s.replace('QwHostBridgeEnd:','''; These entries are reached only AFTER the genuine already-mapped A79
; raw9/bit20 predicate. Ordinary owners never map this bank for these hooks.
QwFullBox:
 php
 pha
 lda #16
 sta ArenaGateBank
 pla
 plp
 RomCall QwService
 jmp PlayerBGCollision
QwAfterTerrain:
 RomCall HuLegacyPostBG
 php
 pha
 txa
 pha
 tya
 pha
 RomCall QwSyncGate
 pla
 tay
 pla
 tax
 pla
 plp
 rts
QwHostBridgeEnd:''')
 s+='\n.assert .hibyte(QwFullBox)=.hibyte(QwAfterTerrain),lderror,"Shared source high-byte installer"\n.assert .bank(QwFullBox)=.bank(QwAfterTerrain),lderror,"Shared source true bank installer"\n'
 p.write_text(s,newline='\n')
 p=N/'entrypoint.s';s=p.read_text();s='.export PlayerBGCollision\n'+s;p.write_text(s,newline='\n')
 p=N/'union.s';s=p.read_text();s='.import QwFullBox,QwAfterTerrain\n'+s
 # Exactly duplicate legacy tail instructions; the live shared tail itself
 # remains at its original PC. Replacing9 with JMP3 funds6B each in place.
 tail=' sta NextBank_SMC+1\n plp\n pla\n pla\n jmp NextBank_SMC'
 helpers={
 'HuDrawAll':'::HuQuickBodyProbe:\n lda SelectedCharacter\n jmp HuQuickBodyCompare',
 'HuBeforeEffects':'::HuQuickAfterProbe:\n lda SelectedCharacter\n jmp HuQuickAfterCompare',
 'HuAfterEffects':'::HuQuickAltTest:\n lda FmAlts\n and #32\n rts'}
 for name,code in helpers.items():
  a=s.index('.proc '+name+'\n');b=s.index('.endproc',a);chunk=s[a:b];assert chunk.count(tail)==1,name
  chunk=chunk.replace(tail,' jmp HuSourceCallbackTail\n'+code,1);s=s[:a]+chunk+s[b:]
 for name,helper,orig in [('HuPlayerSubs','HuQuickBodyProbe','HuQuickBodyOriginal'),('HuAfterTerrainGate','HuQuickAfterProbe','HuQuickAfterOriginal')]:
  a=s.index('.proc '+name+'\n');b=s.index('.endproc',a);chunk=s[a:b];assert chunk.count(' lda SelectedCharacter')==1
  chunk=chunk.replace(' lda SelectedCharacter',' jmp '+helper+'\n::'+orig+':',1);s=s[:a]+chunk+s[b:]
 islands=[
 ('HuBody','HuQuickBodyCompare',' cmp #9\n jmp HuQuickBodyDecide'),
 ('HuAdder','HuQuickBodyDecide',' beq HuQuickBodyAlt\n jmp HuQuickBodyOriginal'),
 ('HuBox','HuQuickBodyAlt',' jsr HuQuickAltTest\n bpl HuQuickBodyAltDecide'),
 ('HuSide','HuQuickBodyAltDecide',' beq HuQuickBodyNative\n jmp HuQuickBodyOwn'),
 ('HuFresh','HuQuickBodyNative',' lda #9\n jmp HuQuickBodyOriginal'),
 ('HuFullBox','HuQuickBodyOwn',' lda #<QwFullBox\n jmp HuQuickCallbackLo'),
 ('HuMenuDraw','HuQuickAfterCompare',' cmp #9\n jmp HuQuickAfterDecide'),
 ('HuMenuName','HuQuickAfterDecide',' beq HuQuickAfterAlt\n jmp HuQuickAfterOriginal'),
 ('HuReset','HuQuickAfterAlt',' jsr HuQuickAltTest\n bpl HuQuickAfterAltDecide'),
 ('HuPrepare','HuQuickAfterAltDecide',' beq HuQuickAfterNative\n jmp HuQuickAfterOwn'),
 ('HuRise','HuQuickAfterNative',' lda #9\n jmp HuQuickAfterOriginal'),
 ('HuPrivate','HuQuickAfterOwn',' lda #<QwAfterTerrain\n jmp HuQuickCallbackLo'),
 ('HuCollision','HuQuickCallbackLo',' sta FarcallJmpTarget_SMC+1\n bne HuQuickCallbackHigh'),
 ('HuPickup','HuQuickCallbackHigh',' lda #>QwFullBox\n jmp HuQuickCallbackHi'),
 ('HuFullPower','HuQuickCallbackHi',' sta FarcallJmpTarget_SMC+2\n bne HuQuickCallbackBank'),
 ('HuColors','HuQuickCallbackBank',' lda #.lobyte(.bank(QwFullBox)|$80)\n jmp HuQuickCallbackSetBank'),
 ('HuStomp','HuQuickCallbackSetBank',' sta NextBank_SMC+1\n bne HuQuickCallbackRestore'),
 ('HuTerrainHead','HuQuickCallbackRestore',' pla\n plp\n jmp HuQuickCallbackCall'),
 ('HuUi','HuQuickCallbackCall',' jmp FarCallCommon+3\n .res 2,$ff')]
 for proc,label,code in islands:
  a=s.index('.proc '+proc+'\n');b=s.index('.endproc',a);chunk=s[a:b];assert chunk.count(' .res 5,$ff')==1,proc
  chunk=chunk.replace(' .res 5,$ff','::'+label+':\n'+code,1);s=s[:a]+chunk+s[b:]
 s+='\n.assert .lobyte(QwFullBox)<>0 .and .lobyte(QwAfterTerrain)<>0,lderror,"Known-nonzero low-byte branch"\n.assert .hibyte(QwFullBox)<>0,lderror,"Known-nonzero high-byte branch"\n'
 p.write_text(s,newline='\n')
 for name in['entrypoint.s','union.s','quick/host-bridge.s']:
  (O/(Path(name).name+'.diff')).write_text(''.join(difflib.unified_diff((P/name).read_text().splitlines(True),(N/name).read_text().splitlines(True),fromfile='parent/'+name,tofile='proposal/'+name)),newline='\n')
 cmds=[(rebase(json.loads((OLD/'compile-main.json').read_text())['command']),'compile-main')]
 up=R/'build/current-character-composition-v1';cmds.append((rebase(json.loads((up/'compile-union.json').read_text())['command'],up/'joint'),'compile-union'))
 cmds.append((rebase(json.loads((OLD/'compile-quick-bridge.json').read_text())['command']),'compile-quick-bridge'))
 cmds.append((rebase(json.loads((OLD/'final-link.json').read_text())['command']),'final-link'))
 (O/'output-preflight.json').write_text(json.dumps([validate(q,N,cwd=R)for q,_ in cmds],indent=2)+'\n')
 B.O=O;B.N=N
 for cmd,name in cmds:B.run(cmd,name)
 from prepare_cv3_dmc_mirror import prepare
 prepare(R,N/'candidate.nes')
 for name in['code.bin','data.bin','ram3.bin','ff-cookie.bin','quick/cookie.bin']:assert(N/name).read_bytes()==(P/name).read_bytes(),name
 C.C.C.C.C.check_bindings(oldh)
 (O/'source-stage.json').write_text(json.dumps(dict(candidate=B.sha(N/'candidate.nes'),parent=B.sha(P/'candidate.nes'),status='PRIVATE_SOURCE_PROPOSAL_NOT_QUALIFIED',native=False,installed=False,scope='Selected-only full-box/post-terrain; all existing A79 PCs/36prologues preserved. No added foreign mapper entry. Own C98 remains within260B.'),indent=2)+'\n');print((O/'source-stage.json').read_text())
if __name__=='__main__':main()
