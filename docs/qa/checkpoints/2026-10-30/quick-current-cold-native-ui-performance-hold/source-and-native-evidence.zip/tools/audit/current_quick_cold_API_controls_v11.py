"""Genuine linked callbacks: old native routes, exact flags/maps and body join."""
from pathlib import Path
import json,traceback
import prepare_current_quick_cold_v11 as B
import current_quick_transport_controls_v4 as T
import quickman_current_services_controls_v2 as S
C=T.C;O=B.O;N=B.N;P=B.R/'build/current-character-quick-cold-v7/joint'
FLAGS=[p for p in range(256)if p&48==48]
def template(path):
 m=T.bus(path);m.set('GameEngineSubroutine',8);m.set('OperMode',1);m.set('OperMode_Task',3);m.set('Player_Y_HighPos',1);m.set('Player_Y_Position',160);m.set('Player_X_Position',96);m.set('ObjectOffset',0);m.set('Player_BoundBoxCtrl',12);m.set('Player_CollisionBits',255);return m
def compare(a,b,ra,rb,case,la,lb):
 assert ra==rb,('AXYP/SP',case,ra,rb)
 ignore=set(range(256,512))|set(range(0x5100,0x5140))
 smc=next(v for v in a.bundle['segs'].values()if v['name']=='"SMCCODE"');lo=int(smc['start'],0);size=int(smc['size'],0);assert size==33
 assert a.ram[lo:lo+size]==b.ram[lo:lo+size],('all33SMC',case)
 appignore=ignore|set(range(lo,lo+size))
 diff=[x for x in range(0x8000)if x not in ignore and a.ram[x]!=b.ram[x]];assert not diff,('application',case,[hex(x)for x in diff[:20]])
 app=lambda m:[(ad,v)for ad,v in m.writes if ad not in appignore]
 assert app(a)==app(b),('orderedapplication',case,app(a)[-25:],app(b)[-25:])
 assert a.tags==b.tags and a.chr==b.chr and a.wram==b.wram,('rawmaps/CHR/WRAM',case)
 live=min(la,lb);assert a.ram[256:256+live]==b.ram[256:256+live],('static/livepage1',case)
 return [v for ad,v in a.writes if ad==0x5115],[v for ad,v in b.writes if ad==0x5115]
def main():
 out=O/'cold-API-controls.json';assert not out.exists();d=dict(passed=False,native=False)
 try:
  old=template(P);new=template(N)
  # All actual existing global PCs and all fixed11B public prologues.
  names=[n for n in old.lab if n.startswith('Hu')and n in new.lab]
  assert all(old.lab[n]==new.lab[n]for n in names),[(n,old.lab[n],new.lab[n])for n in names if old.lab[n]!=new.lab[n]]
  roms=[(x/'candidate.nes').read_bytes()for x in[P,N]]
  for i in range(36):
   off=16+79*8192+old.lab['HuEntryBase']-0xa000+i*16;assert roms[0][off:off+11]==roms[1][off:off+11]
  rows=[]
  # These callbacks naturally retain their original mapped source endpoints.
  for target in ['HuPlayerSubsAdapter','HuPlayerSubs','HuAfterTerrainGate']:
   for raw in [0,1,2,4,6,9,10,11,13,15,18,20,21,22,23,24,25,26,28,32]:
    for p in FLAGS:
     a=S.clone(old);b=S.clone(new)
     for m in[a,b]:m.set('SelectedCharacter',raw);m.set('FmAlts',0);m.set('RdVariant',0);m.set('MarioVariant',0)
     ra,ca,la=S.execute(a,target,A=0x83,X=0,Y=12,P=p);rb,cb,lb=S.execute(b,target,A=0x83,X=0,Y=12,P=p)
     ma,mb=compare(a,b,ra,rb,[target,raw,p],la,lb);assert ma==mb,('foreign mapper sequence',target,raw,p,ma,mb)
     rows.append([target,raw,p,cb-ca,len(ma)])
  d['foreign_full_callback_pairs']=len(rows);d['foreign_CPU_delta']=[min(r[3]for r in rows),max(r[3]for r in rows)];d['rows']=rows
  # Same-bank adapter branch source destinations must be real instructions.
  m=new;branches=[]
  for name in['HuPlayerSubsAdapter']:
   start=m.lab[name];data=roms[1][16+93*8192+start-0xa000:16+93*8192+start-0xa000+59]
   # Decode by actual CPU instruction lengths, never scan data/opcode bytes.
   c=C.H.N.NesMPU(memory=m,pc=start);pc=start
   while pc<start+59:
    op=m[pc];mode=c.disassemble[op][1];size=1 if mode in['imp','acc']else 3 if mode in['abs','abx','aby','ind']else 2
    if mode=='rel':
     delta=m[pc+1];delta=delta-256 if delta>127 else delta;dest=pc+2+delta;assert start<=dest<start+64 or 0xafe7<=dest<0xaff6,(hex(pc),hex(dest));branches.append([pc,dest,delta])
    pc+=size
  d.update(passed=True,all_existing_Hu_PCs_exact=len(names),public_prologues=36,decoded_adapter_branches=branches,limits=['Exact existing native callbacks/flags/maps; selected Quick wholeMain and ISR controls separate. No native/performance/campaign claim.'])
 except Exception as e:d.update(error=repr(e),traceback=traceback.format_exc())
 d['bindings']={str(Path(p).resolve()):B.B.sha(p)for p in[__file__,P/'candidate.nes',N/'candidate.nes',N/'candidate.dbg']};out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:d.get(k)for k in['passed','error','foreign_full_callback_pairs','foreign_CPU_delta']}));assert d['passed'],d.get('error')
if __name__=='__main__':main()
