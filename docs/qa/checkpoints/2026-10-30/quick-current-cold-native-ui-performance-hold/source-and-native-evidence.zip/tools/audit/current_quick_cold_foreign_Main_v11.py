"""Repeat the genuine47identity complete-Main regression against exact v4+UI."""
from pathlib import Path
import json
import prepare_current_quick_cold_v11 as B
import quickman_wram_palette_controls_v6 as C
O=B.O;N=B.N;P=B.R/'build/current-character-quick-cold-v7/joint'
def main():
 out=O/'foreign-complete-Main-controls.json';assert not out.exists()
 U=C.H.U;oldload=U.scoped_load;parent=oldload(P/'candidate.nes')
 def load(path):return parent if Path(path)==B.R/'build/pit-retold-host-v3/candidate.nes'else oldload(path)
 U.scoped_load=load
 try:d=U.foreign(oldload(N/'candidate.nes'))
 finally:U.scoped_load=oldload
 d.update(passed=True,native=False,parent=B.B.sha(P/'candidate.nes'),candidate=B.B.sha(N/'candidate.nes'),notes='Complete Main flags/application/OAM/ordered writes/native JumpEngine semantics/livepage1/all33SMC unchanged. All47 legacy identities×2rules×3buttons. Retains actual extra Bass/expanded terrain mapper cost; selected-only universalbody/postTerrain has no added foreignmap.')
 d['bindings']={str(Path(p).resolve()):B.B.sha(p)for p in[__file__,N/'candidate.nes',N/'candidate.dbg',P/'candidate.nes']};out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(passed=True,cases=d['cases'],CPU_delta=d['CPU_delta'])))
if __name__=='__main__':main()
