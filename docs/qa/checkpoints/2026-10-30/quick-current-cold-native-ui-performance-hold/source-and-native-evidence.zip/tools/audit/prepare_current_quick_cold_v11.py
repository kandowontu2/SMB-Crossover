"""Retain ca65 scope-reopen negative; use genuine external tail labels."""
from pathlib import Path
import json,shutil
import prepare_current_quick_cold_v10 as M
from private_build_outputs_v1 import validate
B=M.B;R=M.R;P=M.N;OLD=M.O;O=R/'build/current-character-quick-cold-v11';N=O/'joint'
def rebase(q,p=P):return[x.replace(str(p),str(N)).replace(p.as_posix(),N.as_posix())for x in q]
def main():
 assert not O.exists();h=OLD/'retained-scope-compile-negative.json';assert not h.exists()
 h.write_text(json.dumps(dict(native=False,error='ca65 scopes cannot be reopened. Original source tail instructions are unchanged; explicit genuine labels replace the attempted scope extension.',bindings={str(p.resolve()):B.sha(p)for p in list(OLD.rglob('*'))+[Path(M.__file__)]if p.is_file()}),indent=2)+'\n')
 O.mkdir();shutil.copytree(P,N)
 for p in N.rglob('*'):
  if p.is_file()and p.suffix in['.s','.inc','.cfg']:
   s=p.read_text();z=s.replace(str(P),str(N)).replace(P.as_posix(),N.as_posix())
   if z!=s:p.write_text(z,newline='\n')
 p=N/'bbox-local.s';s=p.read_text();s=s.replace('beq Mario','beq QwBBoxMario').replace('bne Legacy','bne QwBBoxLegacy').replace('beq Legacy','beq QwBBoxLegacy')
 s=s.replace('.scope HuPlayerSubsAdapter\nMario:','QwBBoxMario:').replace(' cmp #2\n beq Own\nLegacy:',' cmp #2\n beq HuPlayerSubsAdapter::Own\nQwBBoxLegacy:').replace('.endscope\n.assert *=$aff4','.assert *=$aff4');p.write_text(s,newline='\n')
 cmd=rebase(json.loads((OLD/'compile-bbox-local.json').read_text())['command']);link=rebase(json.loads((M.C.O/'final-link.json').read_text())['command'],M.C.N)
 cmds=[(cmd,'compile-bbox-local'),(link,'final-link')]
 (O/'output-preflight.json').write_text(json.dumps([validate(q,N,cwd=R)for q,_ in cmds],indent=2)+'\n');B.O=O;B.N=N
 for q,name in cmds:B.run(q,name)
 from prepare_cv3_dmc_mirror import prepare
 prepare(R,N/'candidate.nes')
 for name in['code.bin','data.bin','ram3.bin','ff-cookie.bin','quick/cookie.bin']:assert(N/name).read_bytes()==(M.C.N/name).read_bytes(),name
 M.C.C.C.C.C.C.check_bindings(h)
 (O/'source-stage.json').write_text(json.dumps(dict(candidate=B.sha(N/'candidate.nes'),parent=B.sha(M.C.N/'candidate.nes'),native=False,installed=False,scope='Actual same-bank bbox adapter61/64B, original Mario/legacy13B in retained Quick25B suffix; selected-only source body and post-terrain.'),indent=2)+'\n');print((O/'source-stage.json').read_text())
if __name__=='__main__':main()
