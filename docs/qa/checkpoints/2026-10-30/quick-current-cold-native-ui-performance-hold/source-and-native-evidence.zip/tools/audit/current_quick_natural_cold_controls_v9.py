"""Repeat actual natural cold consumers after selected-only body/terrain wiring."""
from pathlib import Path
text=Path(__file__).with_name('current_quick_natural_cold_controls_v7.py').read_text()
text=text.replace('import prepare_current_quick_cold_v7 as B','import prepare_current_quick_cold_v9 as W\nB=W.M')
exec(compile(text,__file__,'exec'),globals())
