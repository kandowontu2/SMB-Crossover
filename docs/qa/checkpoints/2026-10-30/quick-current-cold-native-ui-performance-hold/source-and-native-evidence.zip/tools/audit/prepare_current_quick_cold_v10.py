"""Join the real bbox adapter using retained Quick93 tail, with no new map."""
from pathlib import Path
import difflib,json,shutil
import prepare_current_quick_cold_v9 as W
from private_build_outputs_v1 import validate
C=W.M;B=C.B;R=C.R;P=C.N;OLD=C.O;O=R/'build/current-character-quick-cold-v10';N=O/'joint'
def rebase(cmd):return[x.replace(str(P),str(N)).replace(P.as_posix(),N.as_posix())for x in cmd]
def main():
 assert not O.exists();h=OLD/'source-body-route-negative-handoff.json';assert not h.exists()
 h.write_text(json.dumps(dict(status='FROZEN_REAL_ADAPTER_BYPASSES_HU_BODY',candidate=B.sha(P/'candidate.nes'),native=False,notes='Actual natural Main reaches movement/render/sync but QhBox0: real near bbox adapter excludes raw9 before HuPlayerSubs. Retain this source route negative.',bindings={str(p.resolve()):B.sha(p)for p in list(OLD.rglob('*'))+[Path(W.__file__)]if p.is_file()}),indent=2)+'\n')
 grant=json.loads((R/'docs/qa/checkpoints/2026-10-30/arthur-quick-private-allocation/root-review-and-reservations.json').read_text())
 assert dict(bank=93,start=3520,end=4096)in grant['Quick_Man']['PRG']
 blocks=json.loads((R/'docs/qa/checkpoints/2026-10-30/rogue-quick-audio-private-allocation/root-review-and-reservations.json').read_text())['blocks'];assert not any(x['bank']==93 for x in blocks)
 raw=(P/'candidate.nes').read_bytes();assert raw[16+93*8192+0xfe7:16+93*8192+0x1000]==bytes([255])*25
 O.mkdir();shutil.copytree(P,N)
 for p in N.rglob('*'):
  if p.is_file()and p.suffix in['.s','.inc','.cfg']:
   s=p.read_text();z=s.replace(str(P),str(N)).replace(P.as_posix(),N.as_posix())
   if z!=s:p.write_text(z,newline='\n')
 p=N/'bbox-local.s';s=p.read_text();assert s.count(' cmp #32\n bne Legacy')==1
 s='.import FmAlts\n'+s;s=s.replace(' cmp #32\n bne Legacy',' cmp #32\n beq Own\n cmp #9\n bne Legacy\n lda FmAlts\n and #32\n beq Legacy',1)
 old='''Mario:
 lda MarioVariant
 cmp #2
 beq Own
Legacy:
 pla
 plp
 jsr LmBoundingBoxGate
 jmp PlayerBGCollision'''
 assert s.count(old)==1;s=s.replace(old,'',1)
 s=s.replace('.assert *-HuPlayerSubsAdapter=63,error,"Reviewed existing64B bbox layout"','.assert *-HuPlayerSubsAdapter=61,error,"Exact own61B within established64B bbox layout"')
 s+='''
; These original13B are moved intact within the SAME actual A93 mapping.
; The retained Quick25B suffix was explicitly excluded from bbox release.
.segment "QW_BBOX_TAIL"
.scope HuPlayerSubsAdapter
Mario:
 lda MarioVariant
 cmp #2
 beq Own
Legacy:
 pla
 plp
 jsr LmBoundingBoxGate
 jmp PlayerBGCollision
.endscope
.assert *=$aff4,lderror,"Only13B used in retained Quick25B suffix"
'''
 p.write_text(s,newline='\n')
 p=N/'private.cfg';s=p.read_text();old='X5_NEW_5D_AFTER_BBOX:start=$afe7,size=$19';assert s.count(old)==1;s=s.replace(old,'QW_BBOX_TAIL_MEM:start=$afe7,size=$19',1)
 old='HOST_BBOX_LOCAL:load=HOST_BBOX_LOCAL_MEM,type=ro;';assert s.count(old)==1;s=s.replace(old,old+'\nQW_BBOX_TAIL:load=QW_BBOX_TAIL_MEM,type=ro;',1);p.write_text(s,newline='\n')
 for name in['bbox-local.s','private.cfg']:(O/(name+'.diff')).write_text(''.join(difflib.unified_diff((P/name).read_text().splitlines(True),(N/name).read_text().splitlines(True),fromfile='parent/'+name,tofile='proposal/'+name)),newline='\n')
 cmd=rebase(json.loads((OLD/'compile-quick-bridge.json').read_text())['command'])
 cmd=[x.replace(str(N/'quick/host-bridge.'),str(N/'bbox-local.'))for x in cmd]
 link=rebase(json.loads((OLD/'final-link.json').read_text())['command'])
 cmds=[(cmd,'compile-bbox-local'),(link,'final-link')]
 (O/'output-preflight.json').write_text(json.dumps([validate(q,N,cwd=R)for q,_ in cmds],indent=2)+'\n')
 B.O=O;B.N=N
 for q,name in cmds:B.run(q,name)
 from prepare_cv3_dmc_mirror import prepare
 prepare(R,N/'candidate.nes')
 for name in['code.bin','data.bin','ram3.bin','ff-cookie.bin','quick/cookie.bin']:assert(N/name).read_bytes()==(P/name).read_bytes(),name
 C.C.C.C.C.C.check_bindings(h)
 (O/'source-stage.json').write_text(json.dumps(dict(candidate=B.sha(N/'candidate.nes'),parent=B.sha(P/'candidate.nes'),native=False,installed=False,scope='Actual same-bank bbox adapter now admits only raw9/bit20 before its native legacy chain. All original tail instructions retained in existing Quick93 suffix; no new mapping for foreign.'),indent=2)+'\n');print((O/'source-stage.json').read_text())
if __name__=='__main__':main()
