"""Run the unchanged strict consumers on the HP-persistence successor hash."""
from pathlib import Path
import sys
R=Path(__file__).resolve().parents[2]
def main():
 mode=sys.argv[1]
 names={'--geometry':'current_quick_actual_area_geometry_v11.py','--api':'current_quick_cold_API_controls_v11.py','--isr':'current_quick_cold_ISR_controls_v11.py','--lifecycle':'current_quick_cold_lifecycle_v11.py','--foreign':'current_quick_cold_foreign_Main_v11.py'}
 source=Path(__file__).with_name(names[mode]);text=source.read_text();old='import prepare_current_quick_cold_v11 as B';assert text.count(old)==1
 text=text.replace(old,'import prepare_current_quick_cold_v12 as B')
 if mode=='--lifecycle':
  old="assert all(m.get('QmField_0420')==0 for _ in[0]),'Actual source reset must clear actor0'"
  assert text.count(old)==1;text=text.replace(old,"assert all(m.get('QmField_042'+str(i))==0 for i in[2,3,4]),'Real transient fan reset; authentic player actor remains active'")
 if mode=='--foreign':
  old="P=B.R/'build/current-character-quick-cold-v7/joint'";assert text.count(old)==1;text=text.replace(old,"P=B.R/'build/current-character-quick-transport-v4/joint'")
  text=text.replace('against exact v4+UI','against frozen exact Quickv4 before UI/cold consumers')
 ns={'__name__':'__main__','__file__':str(source)};exec(compile(text,str(source),'exec'),ns)
if __name__=='__main__':main()
