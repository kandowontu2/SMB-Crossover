"""Real menu Start, native area clear and InitScreen before source Main."""
from pathlib import Path
import json,traceback
import prepare_current_quick_cold_v6 as B
import quickman_wram_palette_controls_v6 as C
O=B.O;N=B.N;C.O=N;C.CODE=(N/'code.bin').read_bytes();C.DATA=(N/'data.bin').read_bytes()

def put(m,**kw):
 for n,v in kw.items():m.set(n,v)

def fresh():
 b=C.H.U.scoped_load(N/'candidate.nes');base=C.H.U.setup(b,9);m=C.Bus();m.ram[:0x8000]=bytes(base.m[:0x8000]);m.wram=[bytearray(8192)for _ in range(4)]
 put(m,CurrentBank=m.tags[1],CurrentBankC=m.tags[2],SelectedCharacter=0,FmAlts=32,RlVariant=0,CrossoverMenuIndex=9,CrossoverMenuState=2,CrossoverMenuButtons=0,CrossoverContinue=0,OperMode=0,DisableScreenFlag=0,Mirror_PPUMASK=24,Mirror_PPUCTRL=160,NmiDisable=255,FamilyMainCommit=1,VRAM_Buffer1_Offset=0)
 m.ppu_ctrl=160;m.ppu_mask=24;m.sync_chr11();m.ram[0x5102]=2;m.ram[0x5103]=1;m.ram[0x5113]=0;return m

def invoke(m,name,**kw):
 r=C.invoke(m,name,**kw)
 names=['IcGlobalInit','SunnyGlobalInit','QwBoot','QwConstruct','QuickManInit','QhConstruct','MoveAllSpritesOffscreen','ArGenSceneInit','FwSceneInit','QhMovement','QhGraphics','QhDraw','QwLoaderCore','PlayerBankReady']
 counts={n:sum(pc==m.lab[n]and tags[(pc-32768)//8192]==(1 if n in['QuickManInit','QhConstruct','QhMovement','QhGraphics','QhDraw']else m.bank(n)|128)for tags,pc in r['trace']if pc>=32768)for n in names}
 return dict(entry=name,registers=r['registers'],CPU=r['CPU'],minimumSP=r['minimum_SP'],PPU_reads=m.ppu_reads,source_RAM_exec=len(m.executed_RAM),counts=counts,cookie=list(m.wram[2][0x1fe0:0x1ff0]),Selected=m.get('SelectedCharacter'),FmAlts=m.get('FmAlts'),HP=m.get('QmField_06C0')),r

def main():
 out=O/'natural-cold-controls.json';assert not out.exists();d=dict(passed=False,native=False,checks={})
 try:
  m=fresh();rows=[]
  for name in['MenuResolveCharacter','QueueSelection','DrawSelectionPreview']:
   z,r=invoke(m,name);rows.append(z);assert m.get('SelectedCharacter')==9 and m.get('FmAlts')==32
   assert not m.ppu_reads and not m.executed_RAM,('cold menu must remain ROM only',name,z)
  d['checks']['actual_ready_name_colored_preview_ROM_only']=rows
  put(m,SavedJoypad1Bits=16,SavedJoypad2Bits=0)
  z,r=invoke(m,'CrossoverMenuInput');d['checks']['actual_Start_MaaFresh_post_Ic']=z
  assert z['counts']['IcGlobalInit']==1 and z['counts']['SunnyGlobalInit']==1 and z['counts']['QwBoot']==1 and z['counts']['QwConstruct']==1,z
  assert not m.ppu_reads and not m.executed_RAM and m.get('SelectedCharacter')==9 and m.get('FmAlts')==32
  assert m.get('CrossoverMenuState')==0 and m.get('DisableScreenFlag')==1 and z['registers']['A']==16
  # Real native area initialization/low-memory reset occurs before the screen
  # loader. No source Due/Pad/HP/actor state is supplied by the fixture.
  put(m,OperMode=1,OperMode_Task=0,DisableScreenFlag=1,Mirror_PPUMASK=0,NmiDisable=255,FamilyMainCommit=1)
  m.ppu_mask=0
  for name in['LoadAreaPointer','InitializeArea']:
   z,r=invoke(m,name);d['checks'][name]=z
  put(m,ScreenRoutineTask=0,VRAM_Buffer1_Offset=0)
  z,r=invoke(m,'InitScreen');d['checks']['actual_forcedblank_InitScreen']=z
  C.exact_cache(m);assert z['counts']['QhConstruct']==1 and z['counts']['QuickManInit']==1 and z['counts']['MoveAllSpritesOffscreen']==1 and z['counts']['ArGenSceneInit']==1 and z['counts']['FwSceneInit']==1,z
  assert m.get('QmField_06C0')==40 and m.ppu_reads==18450 and not m.PPU_active_reads
  # The actual current class area dimensions/floor fixture is inherited from
  # genuine native setup. Only native controller bytes are changed for Main.
  put(m,GameEngineSubroutine=8,OperMode_Task=3,OperMode=1,Player_CollisionBits=255,VRAM_Buffer1_Offset=0)
  rows=[]
  for age in range(24):
   keys=1|(128 if 4<=age<12 else 0)|(64 if 14<=age<20 else 0)
   put(m,SavedJoypadBits=keys,SavedJoypad1Bits=keys,A_B_Buttons=keys&192,Left_Right_Buttons=keys&3,Up_Down_Buttons=0,NmiDisable=255,FamilyMainCommit=1,VRAM_Buffer_AddrCtrl=0,VRAM_Buffer1_Offset=0)
   z,r=invoke(m,'GameLoop');assert z['counts']['QhMovement']==1 and z['counts']['QhDraw']==1 and z['counts']['QhGraphics']==1 and m.get('SelectedCharacter')==9,('natural selected Main',age,z)
   C.exact_cache(m);rows.append(dict(age=age,keys=keys,CPU=z['CPU'],HP=m.get('QmField_06C0'),X=m.get('Player_X_Position'),Y=m.get('Player_Y_Position')))
  d['checks']['actual_Main_after_native_clear_and_scene_constructor']=rows
  d.update(passed=True,limits=['Controlled genuine CPU consumer order: menu/Start/native area init/InitScreen/Main. No native controller route,1-1 clear,powerup or CXaudio claim.','Menu owner-retire-before-publication helper remains pending separately.','Default source game time/input cadence is not a native performance receipt.'])
 except Exception as e:d.update(error=repr(e),traceback=traceback.format_exc())
 d['bindings']={str(Path(p).resolve()):B.B.sha(p)for p in[__file__,N/'candidate.nes',N/'candidate.dbg']};out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(passed=d['passed'],error=d.get('error'),checks=list(d['checks']))));assert d['passed'],d.get('error')
if __name__=='__main__':main()
