"""Actual vectors, pending draw and retirement controls; negatives retained."""
import importlib.util,json,traceback,itertools
from pathlib import Path
import arthur_joint_live_controls_v2 as V
A=V.A;B=V.B;O=V.O;N=V.N
def fresh(b):
 q=V.V.seed(b);A.call(q,'NrFreshGameInit');assert q.get('ArHostReady')==167;return q
def load_nmi(b):
 p=B.R/'build/character-host-union-v5/gm_verify_nmi.py';s=importlib.util.spec_from_file_location('arthur_live_nmi',p);g=importlib.util.module_from_spec(s);s.loader.exec_module(g);g.B=b;return g
def main():
 out=O/'lifecycle-vectors-v2.json';assert not out.exists();d=dict(passed=False,native=False,checks={})
 try:
  b=A.scoped_load(N/'candidate.nes');g=load_nmi(b);q=fresh(b);rows=[]
  for lag,pause,busy in itertools.product([0,255],[0,1],[0,1,3,5]):
   q.put(NmiDisable=lag,GamePauseStatus=pause,FamilyMainCommit=busy,ArHostPhase=1,ArHostDue=0,VRAM_Buffer_AddrCtrl=0,VRAM_Buffer1_Offset=0)
   z=g.nmi(q);expected=int(not pause and not(busy&1))
   assert q.get('ArHostPhase')==(3 if expected else 1)and q.get('ArHostDue')==expected,('clock',lag,pause,busy,q.get('ArHostPhase'),q.get('ArHostDue'))
   rows.append(dict(lag=lag,pause=pause,busy=busy,**g.scheduler.summary(z)))
  d['checks']['real_normal_lag_vectors']=rows
  # Ordinary Main audio does not have the qualified outer-NMI return address.
  q.put(ArHostPhase=1,ArHostDue=0,FamilyMainCommit=0);A.call(q,'AudioUpdate');assert q.get('ArHostPhase')==1 and q.get('ArHostDue')==0
  d['checks']['ordinary_audio_no_clock']=True
  # Pending raw32 is deliberately not loaded; even a stale overlay A7 must
  # not authorize reads/writes. Observe actual wrapper, not an explicit worker.
  q=V.V.seed(b);q.put(ArHostReady=167);ty=type(q.m);old=ty.__getitem__;reads=[]
  def read(m,i):
   if m is q.m and isinstance(i,int)and 0x5c00<=i<0x5cb0:reads.append(i)
   return old(m,i)
  ty.__getitem__=read
  try:c,tr,mn=A.call(q,'HuDrawAll')
  finally:ty.__getitem__=old
  assert not reads,('pending draw read Arthur overlay without full cookie',sorted(set(reads)))
  d['checks']['pending_draw_zero_Arthur_access']=True
  d['passed']=True
 except Exception as e:d.update(error=repr(e),traceback=traceback.format_exc())
 d['bindings']={str(p.resolve()):B.sha(p)for p in [Path(__file__),N/'candidate.nes',N/'candidate.dbg',O/'constructor-Main-controls-v2.json']}
 out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items()if k not in ['bindings','traceback']}));assert d['passed']
if __name__=='__main__':main()
