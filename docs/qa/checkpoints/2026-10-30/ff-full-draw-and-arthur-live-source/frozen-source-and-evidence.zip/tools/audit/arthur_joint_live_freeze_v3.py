"""Freeze scoped positive live source and the real menu-boundary limitation."""
from pathlib import Path
import json
import arthur_joint_live_build_v3 as B
def main():
 out=B.O/'handoff.json';assert not out.exists()
 proofs=['constructor-Main-controls-v3.json','lifecycle-vectors-v3.json','foreign-Main-v3.json','actual-live-ISR-v3.json','presentation-foreign-NMI-v3.json']
 for n in proofs:
  d=json.loads((B.O/n).read_text());assert d['passed'],n
  for p,h in d['bindings'].items():assert B.sha(p)==h,p
 for p,h in json.loads((B.O/'linked-layout.json').read_text())['predecessor_bindings'].items():assert B.sha(p)==h,p
 files=[p for p in B.O.rglob('*')if p.is_file()]+[Path(__file__)]+[p for p in (B.R/'tools/audit').glob('arthur_joint_live_*.py')]
 d=dict(status='FROZEN_SOURCE_POSITIVE_WITH_REAL_MENU_BOUNDARY_OPEN',native=False,admitted=False,candidate=B.sha(B.N/'candidate.nes'),source_scope='Genuine forced-blank post-Ic constructor then Main; this does NOT represent the actual visible-title menu fresh caller.',limits=['Actual menu Fresh occurs in visible OperMode0 before InitScreen. Existing constructor context guard refuses it; later source acquisition must be connected before enabling.','Frontend remains pending; no native launch or shared installation.','Own complete Main32751..38466CPU in24updates; severe performance HOLD.','Foreign Main132pairs exact semantics but+4..525CPU; foreign normal/lag NMI66cases+35..135CPU.','No new span, RAM1 or independent ready marker. Existing full16B C2 cookie and5FFF busy protocol used.'],bindings={str(p.resolve()):B.sha(p)for p in files})
 out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(handoff=B.sha(out),bindings=len(d['bindings']))))
if __name__=='__main__':main()
