"""Rebind final private source and qualify the actual ready/pending resolver."""
from pathlib import Path
R=Path(__file__).resolve().parents[2]
def main():
 for kind in ['controls','lifecycle','isr','foreign','presentation','boundary']:
  src=R/'tools/audit'/('arthur_joint_live_'+kind+'_v4.py');dst=src.with_name(src.name.replace('_v4.py','_v5.py'));assert not dst.exists()
  s=src.read_text()
  for part in ['build','controls','lifecycle','isr']:
   s=s.replace('arthur_joint_live_'+part+'_v4','arthur_joint_live_'+part+'_v5')
  for a in ['constructor-Main-controls','lifecycle-vectors','actual-live-ISR','foreign-Main','presentation-foreign-NMI','real-boundary-controls']:s=s.replace(a+'-v4.json',a+'-v5.json')
  if kind=='lifecycle':
   lo=s.index("  q=fresh(b);table=A.location(b,'X5MenuCharacters')");hi=s.index("  d['passed']=True",lo)
   s=s[:lo]+'''  table=A.location(b,'X5MenuCharacters');ids=b['raw'][table:table+32];mi=ids.index(0);ai=ids.index(32);resolver=[]
  for index in [mi,ai]:
   q=fresh(b);q.put(CrossoverMenuIndex=index,FamilyMainCommit=1);stores=[];old=NesMPU.step;selected=A.address(b,'SelectedCharacter')
   def step(c):
    if q.m[c.pc]==141 and q.m[c.pc+1]+256*q.m[c.pc+2]==selected:
     stores.append([c.a,q.get('ArHostReady'),q.m.ram[2][8160]])
     assert q.get('ArHostReady')==0 and q.m.ram[2][8160]==0,('publication before retirement',stores[-1])
    old(c)
   NesMPU.step=step
   try:A.call(q,'MenuResolveCharacter')
   finally:NesMPU.step=old
   assert q.get('SelectedCharacter')==0 and stores
   q.put(FamilyMainCommit=0,NmiDisable=255);z,reads,exe=observe(q,lambda:g.nmi(q));assert not reads and not exe
   resolver.append(dict(index=index,selected_stores=stores))
  d['checks']['actual_menu_resolver_ready_and_pending_retire_before_publication']=resolver
  d['frontend_pending_unchanged']=True
''' + s[hi:]
  dst.write_text(s,newline='\n')
if __name__=='__main__':main()
