"""Freeze actual joint source/transport/full-render CPU evidence; no admission."""
from pathlib import Path
import hashlib,json
R=Path(__file__).resolve().parents[2]
O=R/'build/ff-joint-full-render-qualified-v1';assert not O.exists();O.mkdir()
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
parents=[R/'build/ff-arthur-joint-transport-v3/source-closure.json',
 R/'build/ff-arthur-joint-transport-v3/transport-controls-v2.json',
 R/'build/ff-arthur-joint-transport-v3/actual-FF-main-v2.json',
 R/'build/ff-joint-full-render-v2/source-closure.json',
 R/'build/ff-joint-full-render-v2/actual-full-render-main-v1.json']
files={Path(__file__)}
for p in parents:
 d=json.loads(p.read_text());assert d['passed'],p
 for f,h in d.get('bindings',{}).items():assert sha(f)==h,f
 files|={p}|set(map(Path,d.get('bindings',{})))
for leaf in ['ff-arthur-joint-transport-v3','ff-joint-full-render-v1','ff-joint-full-render-v2',
             'ff-joint-full-render-builder-v2','ff-arthur-joint-builder-v3']:
 files|={f for f in(R/'build'/leaf).rglob('*')if f.is_file()and'__pycache__'not in f.parts}
rom=R/'build/ff-joint-full-render-v2/joint/candidate.nes'
assert sha(rom)=='07cda1d4b0812717334dc15e886f56474953e30b2cb2f6ddc5ecfd5ace52ea13'
p=dict(passed=True,native=False,admitted=False,status='FROZEN_PRIVATE_SOURCE_JOINT_FF_FULL_RENDER_CPU_PASS',
 candidate=str(rom),candidate_sha256=sha(rom),
 checks=dict(actual_transport_pairs=4608,invalid_service_indices=440,real_transport_ISR=6856,
  actual_prior_Main_updates=128,actual_full_render_Main_cases=96,
  actual_draw_order='Graphics -> FwHostDrawShots exactly once -> native body reservation -> native body0',
  actual_normal_NMI_body_CHR=True,all_prior_public_PCs_exact=True,
  original_CORE_ART_CHR_combat_terrain_pickups_exact=True,header_WRAM_KiB=32),
 limits=['CPU fixtures, no native or earned progression/campaign/admission claim.',
  '96 cases cover legal initial tiers, source body0, normal NMI and no live FX; active FX Main is next.',
  'Non-skipped Main CPU33921..40222 in these fixtures is a performance hold, not native cadence.',
  'FF palette/audio, feet/postBG, native enemyFresh/flash-aging and complete selectable readiness remain pending.',
  'Arthur selected-only lifecycle/NMI/palette hooks intentionally not installed; busy-guard successor separate.',
  'Inherited Rogue GmOnly raw2 routing preserved; separate lifecycle fix not silently adopted.'],
 negatives=['Full-render v1 shifted cold preview PCs by26; v2 fixed bridge in owned alignment.',
  'Transport v1 invoked C63 constructor with stale C; v2 uses genuine service15/ArDispatch.',
  'First two actual Arthur config links failed owner ordering/rewind; v3 split existing ranges.'],
 parents=[str(p)for p in parents],bindings={str(f.resolve()):sha(f)for f in sorted(files)})
(O/'handoff.json').write_text(json.dumps(p,indent=2)+'\n',newline='\n')
print(json.dumps(dict(path=str(O/'handoff.json'),sha256=sha(O/'handoff.json'),bindings=len(files),ROM=sha(rom))))
