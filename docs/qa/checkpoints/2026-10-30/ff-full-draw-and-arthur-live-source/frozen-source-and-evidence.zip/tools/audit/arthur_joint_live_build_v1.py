"""Private source-linked minimum Arthur lifecycle/live-frame integration."""
from pathlib import Path
import hashlib,json,re,shutil,subprocess,sys
import arthur_joint_busy_guards_build_v1 as B
R=B.R;P=B.O;J=B.N;O=R/'build/arthur-joint-live-v1';N=O/'joint'
sha=B.sha

def write(p,s):
 assert p.resolve().is_relative_to(N.resolve());p.write_text(s,newline='\n')
def edit(p,old,new,count=1):
 s=p.read_text();assert s.count(old)==count,(p,old,s.count(old));write(p,s.replace(old,new))
def rewrite(s):
 for old,new in [(str(J),str(N)),(J.as_posix(),N.as_posix())]:s=s.replace(old,new)
 return s

def main():
 assert not O.exists();assert sha(J/'candidate.nes')=='09678431cfb39d046280c026d73dfdbe60ba13196274f02cda0fae17e8572a65'
 for p,d in json.loads((P/'build-proof.json').read_text())['bindings'].items():assert sha(p)==d,p
 O.mkdir();shutil.copytree(J,N)
 for p in N.rglob('*'):
  assert p.resolve().is_relative_to(N.resolve())
  if p.is_file()and p.suffix in ['.s','.inc','.cfg','.dep']:
   s=p.read_text();t=rewrite(s)
   if s!=t:write(p,t)
 # Copy genuinely assembled predicates, then bind actual owned segments.
 proto=(R/'tools/audit/arthur_joint_generation_proposal_v1.s').read_text()
 lo=proto.index('; Inline before the existing shared55');hi=proto.index('; Run through C70 inside',lo)
 inline=proto[lo:hi];proto=proto[:lo]+proto[hi:]
 proto=proto.replace('.segment "AR_GEN_CLOCK_INGRESS"','.segment "GIMMICK_COMMON_NMI"')
 proto=proto.replace('.export ArGenPaletteStub','.export ArGenPaletteStub')
 proto=proto.replace('ArGenPaletteStub','ArPaletteScreenUpdate')
 proto=proto.replace(' sta $2005\n sta $2005\nDone:', ' sta $2005\n sta $2005\n.export ArPaletteScrollDone\n::ArPaletteScrollDone:\nDone:')
 proto+='''\n.segment "AR_GEN_FOREGROUND"
.export ArGenCookieOnly
ArGenCookieOnly:
 pha
 jmp ArGenCheckForeground::Cookie
'''
 write(N/'generation-predicates.s',proto)
 for name in ['shared','constructor']:
  write(N/('generation-'+name+'.s'),(R/'tools/audit'/('arthur_joint_generation_'+name+'_v1.s')).read_text())
 # The original constructor's two existing genuine source instructions change
 # target; its original21B slot shrinks to19B, no tail-span expansion.
 ad=N/'arthur/host-adapter.s';s=ad.read_text();s='.import ArGenConstruct\n'+s
 old='ArHostConstruct:\n ArFar CmHostFresh\n jmp ArHostFresh';assert s.count(old)==1
 s=s.replace(old,'ArHostConstruct:\n ArFar ArGenConstruct\n rts',1)
 start=s.index('.proc ArHostName');end=s.index('.endproc',start)+len('.endproc')
 name=s[start:end].replace('.proc ArHostName','.proc ArGenName')
 s=s[:start]+'.proc ArHostName\n ArFar ArGenName\n rts\n.endproc'+s[end:]
 s+='\n.segment "AR_GEN_NAME"\n.export ArGenName\n'+name+'\n'
 start=s.index('.proc ArHostRelease');end=s.index('.endproc',start)
 part=s[start:end];part=part.replace(' bne Done\n jsr ArCacheRetire',' bne Done\n jsr ArHostSave\n jsr ArCacheRetire',1)
 part=part.replace(' sta SmFreezePaletteControl\nDone:', ' sta SmFreezePaletteControl\n lda #0\n sta ArHostReady\nDone:',1)
 s=s[:start]+part+s[end:]
 start=s.index('.proc ArPaletteScreenUpdate');end=s.index('.endproc',start)+len('.endproc')
 # Actual entry exported by generation-predicates instead. Keep every old
 # imported native continuation as genuine source, not an absolute alias.
 s=s[:start]+s[end:];s=s.replace('.export ArPaletteScreenUpdate\n','')
 write(ad,s)
 p=N/'arthur/cache-loader.s';s=p.read_text();s+='\n.export ArCacheSignature\nArCacheSignature=ArCacheLoad::Signature\n';write(p,s)
 # Common36 public PCs stay at their original16B stride. All suffix imports
 # genuinely relink; no old numeric callback PCs are carried forward.
 u=N/'union.s';s=u.read_text();s='.import ArGenCheckForeground,ArGenResolve,ArGenAfterTerrain,ArHostDrawAll\n'+s
 s=s.replace('farcall CmHostResolveCharacter','farcall ArGenResolve',1)
 active=inline[inline.index('ArGenCommonActive:')+len('ArGenCommonActive:'):inline.index('ArGenCommonContinue:')]
 active=active.replace('ArGenCommonContinue','ArGenCookieReady')
 needle='HuExtendedArthur:\n';assert s.count(needle)==1
 s=s.replace(needle,needle+active+'ArGenCookieReady:\n',1)
 # Selected body wraps true native DrawAll once, then original fair/post-white.
 start=s.index('.proc HuDrawAll');end=s.index('.endproc',start)
 part=s[start:end];part=part.replace(' lda SelectedCharacter\n cmp #2',' lda SelectedCharacter\n cmp #32\n beq Arthur\n cmp #2',1)
 part+='''Arthur:
 lda #<ArHostDrawAll
 sta FarcallJmpTarget_SMC+1
 lda #>ArHostDrawAll
 sta FarcallJmpTarget_SMC+2
 lda #.lobyte(.bank(ArHostDrawAll)|$80)
 jmp HuSourceCallbackTail
'''
 s=s[:start]+part+s[end:]
 # Reuse both actual unreachable12B pads; no other owner's executed bytes or
 # addresses inside HuLegacyPostBG change. Only selected32 enters these pads.
 start=s.index('.proc HuLegacyPostBG');end=s.index('.endproc',start)
 part=s[start:end];assert part.count(' .res 12,$ea')==2
 first='''ArAfterLo:
 pla
 plp
 lda #<ArGenAfterTerrain
 sta FarcallJmpTarget_SMC+1
 jmp HuLegacyPostBG::ArAfterHi
 .res 2,$ea'''
 second='''ArAfterHi:
 lda #>ArGenAfterTerrain
 sta FarcallJmpTarget_SMC+2
 lda #.lobyte(.bank(ArGenAfterTerrain)|$80)
 jmp FarCallCommon
 .res 2,$ea'''
 part=part.replace(' .res 12,$ea',first,1).replace(' .res 12,$ea',second,1)
 s=s[:start]+part+s[end:]
 start=s.index('.proc HuAfterTerrainGate');end=s.index('.endproc',start)
 part=s[start:end];part=part.replace(' lda SelectedCharacter\n cmp #26',' lda SelectedCharacter\n cmp #32\n beq HuLegacyPostBG::ArAfterLo\n cmp #26',1)
 s=s[:start]+part+s[end:];write(u,s)
 # Exact63B bbox capsule; remove redundant explicit Bill classifier. Its
 # native callee overwrites incoming comparison flags; actual controls must
 # prove this instead of treating the byte budget as semantic evidence.
 p=N/'bbox-local.s';s=p.read_text();s='.import ArGenPlayerSubs\n'+s
 s=s.replace(' cmp #3\n beq Legacy\n','',1).replace(' cmp #28\n bne Legacy',' cmp #28\n beq Own\n cmp #32\n bne Legacy',1)
 s=s.replace('HuTailFar HuPlayerSubs','HuTailFar ArGenPlayerSubs',1);write(p,s)
 # Existing63B resident foot span: current hot0..27 decisions unchanged.
 # Raw>=28 routes through one typed cold wrapper (including pending high IDs).
 p=N/'src/characters.s';edit(p,'  cmp #CHARACTER_DONKEY_KONG\n  bne FootNative','  cmp #CHARACTER_DONKEY_KONG\n  bcc FootNative')
 edit(p,'farcall DkHostFeetUnionRouter,jmp','farcall ArGenFoot,jmp')
 # Native area palette gateway: true existing UpdateScreen first, fixed-size
 # prefix and source continuation labels; no custom universal/backdrop color.
 p=N/'src/parodius_bells.s';s=p.read_text();old=''' jsr UpdateScreen
 lda SelectedCharacter
 cmp #18
 bne Samus
.if ::ENABLE_MMC5_EXPANDED && ::MAPPER_MMC5
 jmp PnHudCommitAfterVram
.else
 lda OperMode
.endif'''
 assert s.count(old)==1
 s='.import ArPaletteScreenUpdate\n'+s.replace(old,''' jsr UpdateScreen
 lda #>(ArPaletteScreenUpdate-1)
 pha
 lda #<(ArPaletteScreenUpdate-1)
 pha
 lda #.lobyte(.bank(ArPaletteScreenUpdate)|$80)
 jmp ArNmiPhysicalCWrite
 .assert *-PnPaletteScreenUpdate=14,error,"Actual C116 palette prefix"
ArContinue:
''',1)
 old=' sta PnBombPaletteShadow,x\n inx\n cpx #32\n bne Copy\n lda #0';assert s.count(old)==1
 s=s.replace(old,' sta PnBombPaletteShadow,x\n .if !(::ENABLE_MMC5_EXPANDED && ::MAPPER_MMC5)\n inx\n .endif\n cpx #32\n bne Copy\nCaptureComplete:\n lda #0',1);write(p,s)
 edit(N/'src/parodius_hud_queue.s','PnPaletteScreenUpdate+13','PnPaletteScreenUpdate::ArContinue',2)
 edit(N/'src/nmi_vram_fast.s','PnPaletteScreenUpdate::Copy+11','PnPaletteScreenUpdate::CaptureComplete')
 edit(N/'gm-nmi.s','Tick:\n jsr GmNmiClock','Tick:\n jsr ArGenClockIngress\n jsr GmNmiClock')
 p=N/'gm-nmi.s';write(p,'.import ArGenClockIngress\n'+p.read_text())
 p=N/'entrypoint.s';write(p,'.import ArGenFoot\n'+p.read_text())
 # Actual layout additions only inside already-owned Arthur memory or the
 # authorized existing common512 source; automatic old native order retained.
 cfg=N/'private.cfg';s=cfg.read_text()
 s=s.replace('MEMORY {','MEMORY {\n AR_GEN_CTOR_RUN:start=$bc95,size=$6b,type=ro,file="",bank=$46;\n AR_GEN_NAME_RUN:start=$a9cf,size=$31,type=ro,file="",bank=$75;',1)
 at=s.index('\n}',s.index('SEGMENTS {'))
 extra='''
 AR_GEN_FOREGROUND:load=AR_C70_SMALL,type=ro;
 AR_GEN_NMI_PREDICATE:load=AR_C70_SMALL,type=ro;
 AR_GEN_CLOCK_C70:load=AR_C70_SMALL,type=ro;
 AR_GEN_PALETTE_C70:load=AR_C70_SMALL,type=ro;
 AR_GEN_CONSTRUCTOR:load=AR_C70_TAIL,run=AR_GEN_CTOR_RUN,type=ro;
 AR_GEN_PALETTE_STUB:load=AR_NMI_GATE_MEM,type=ro;
 AR_GEN_NAME:load=AR_NMI_GATE_MEM,run=AR_GEN_NAME_RUN,type=ro;
'''
 s=s[:at]+extra+s[at:];write(cfg,s)
 # Empty old NMI_GATEWAY consumes zero; new stub is first in that memory.
 commands=[]
 for name in ['main','union','bbox-local','gm-nmi','arthur-host-adapter','arthur-host-render']:
  original=(J/(name+'-build.json'))
  if not original.exists():original=B.J/(name+'-build.json')
  cmd=[rewrite(x)for x in json.loads(original.read_text())['command']]
  # Copied recipes can refer one immutable grandparent; output/new owned
  # source paths must resolve inside this new successor.
  cmd=[x.replace(str(B.J),str(N)).replace(B.J.as_posix(),N.as_posix())for x in cmd]
  B.outputs(cmd);commands.append(cmd)
 cc=str(R/'tools/Windows/cc65/bin/ca65.exe')
 for name in ['predicates','shared','constructor']:
  commands.append([cc,'-g','--cpu','6502x','-o',str(N/('generation-'+name+'.o')),str(N/('generation-'+name+'.s'))])
 link=[rewrite(x)for x in json.loads((B.J/'final-link.json').read_text())['command']]
 link=[x.replace(str(B.J),str(N)).replace(B.J.as_posix(),N.as_posix())for x in link]
 link +=[str(N/('generation-'+n+'.o'))for n in ['predicates','shared','constructor']];B.outputs(link);commands.append(link)
 logs=[]
 for cmd in commands:
  p=subprocess.run(cmd,cwd=N,capture_output=True,text=True);logs.append(dict(command=cmd,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr))
  (O/'commands.json').write_text(json.dumps(logs,indent=2)+'\n');assert p.returncode==0,p.stderr
 B.mirror(R,N/'candidate.nes')
 b=B.scoped_load(N/'candidate.nes');sizes={s['name'].strip('"'):int(s['size'],0)for s in b['segs'].values()}
 (O/'linked-layout.json').write_text(json.dumps(dict(candidate=sha(N/'candidate.nes'),sizes=sizes,status='ACTUAL_SOURCE_LINKED_ALL_ACCEPTANCE_PENDING',native=False),indent=2)+'\n')
 print(json.dumps(dict(candidate=sha(N/'candidate.nes'),common=sizes['CHARACTER_HOST_UNION'],common512=sizes['GIMMICK_COMMON_NMI'],ctor=sizes['AR_GEN_CONSTRUCTOR'],name=sizes['AR_GEN_NAME'])))
if __name__=='__main__':main()
