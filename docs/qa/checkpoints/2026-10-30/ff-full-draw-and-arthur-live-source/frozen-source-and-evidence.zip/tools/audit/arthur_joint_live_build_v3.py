"""Full-cookie protected actual DrawAll ingress in existing common512."""
from pathlib import Path
import json,shutil,subprocess
import arthur_joint_live_build_v2 as B
R=B.R;P=B.O;J=B.N;O=R/'build/arthur-joint-live-v3';N=O/'joint';sha=B.sha
def rewrite(s):
 for a,z in [(str(J),str(N)),(J.as_posix(),N.as_posix())]:s=s.replace(a,z)
 return s
def main():
 assert not O.exists();assert sha(J/'candidate.nes')=='d877231064ef8773b8d92ca30117a5ce741de54f3dd46de7d4894feaa2b390db'
 bound={str(p.resolve()):sha(p)for p in P.rglob('*')if p.is_file()};O.mkdir();shutil.copytree(J,N)
 for p in N.rglob('*'):
  if p.is_file()and p.suffix in ['.s','.inc','.cfg','.dep']:
   s=p.read_text();t=rewrite(s)
   if s!=t:p.write_text(t,newline='\n')
 p=N/'union.s';s=p.read_text();s=s.replace('ArGenAfterTerrain,ArHostDrawAll','ArGenAfterTerrain,ArGenDrawAll')
 assert s.count('ArHostDrawAll')==3;s=s.replace('ArHostDrawAll','ArGenDrawAll');p.write_text(s,newline='\n')
 p=N/'generation-shared.s';s=p.read_text();s='.import ArHostDrawAll,SamusFreezeDrawAll\n'+s
 s+='''
; Genuine typed DrawAll frame only. Pending raw32 follows original native
; actor renderer without reading any Arthur state or executing C2 payload.
.export ArGenDrawAll
.proc ArGenDrawAll
 php
 pha
 jsr ArGenValidate
 bcc Foreign
 pla
 plp
 GenTail ArHostDrawAll
Foreign:
 pla
 plp
 GenTail SamusFreezeDrawAll
.endproc
''';p.write_text(s,newline='\n')
 old=B.B.O
 cmd=json.loads((old/'union-compile-v3.json').read_text())[0]['command']
 cmd=[rewrite(x.replace(str(B.B.N),str(J)).replace(B.B.N.as_posix(),J.as_posix()))for x in cmd]
 cc=str(R/'tools/Windows/cc65/bin/ca65.exe')
 commands=[cmd,[cc,'-g','--cpu','6502x','-o',str(N/'generation-shared.o'),str(N/'generation-shared.s')],[rewrite(x)for x in json.loads((P/'commands.json').read_text())[-1]['command']]]
 logs=[]
 for cmd in commands:
  for flag in ['-o','-Ln','-m','--create-full-dep']:
   if flag in cmd:assert Path(cmd[cmd.index(flag)+1]).resolve().is_relative_to(N.resolve()),cmd
  for x in cmd:
   if x.startswith('--dbgfile,'):assert Path(x.split(',',1)[1]).resolve().is_relative_to(N.resolve())
  r=subprocess.run(cmd,cwd=N,capture_output=True,text=True);logs.append(dict(command=cmd,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr));(O/'commands.json').write_text(json.dumps(logs,indent=2)+'\n');assert r.returncode==0,r.stderr
 B.B.B.mirror(R,N/'candidate.nes');b=B.B.B.scoped_load(N/'candidate.nes');sizes={s['name'].strip('"'):int(s['size'],0)for s in b['segs'].values()}
 assert sizes['CHARACTER_HOST_UNION']==2590 and sizes['GIMMICK_COMMON_NMI']<=512
 for p,h in bound.items():assert sha(p)==h,p
 d=dict(native=False,parent=sha(J/'candidate.nes'),candidate=sha(N/'candidate.nes'),sizes=sizes,predecessor_bindings=bound)
 (O/'linked-layout.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(candidate=d['candidate'],common512=sizes['GIMMICK_COMMON_NMI'])))
if __name__=='__main__':main()
