"""Actual new NMI palette route against original source pixels and foreign ISR."""
from pathlib import Path
import itertools,json,traceback
import arthur_joint_live_controls_v4 as V
import arthur_joint_live_lifecycle_v4 as L
import arthur_joint_live_isr_v4 as I
A=V.A;B=V.B;O=V.O;N=V.N;P=B.R/'build/ff-arthur-joint-transport-v3/joint'
def main():
 out=O/'presentation-foreign-NMI-v4.json';assert not out.exists();d=dict(passed=False,native=False,checks={});original=A.setup
 try:
  b=A.scoped_load(N/'candidate.nes');template=L.fresh(b);template.put(FamilyMainCommit=0)
  A.setup=lambda bundle,ch=32:I.clone(template)if ch==32 and bundle is b else original(bundle,ch)
  d['checks']['actual_native_backdrop_and_status']=A.presentation(b)
  d['checks']['actual_NMI_source_RGB_alpha_priority']=A.render_pixels(b)
  old=A.scoped_load(P/'candidate.nes');g=L.L.load_nmi(b);rows=[]
  for ch,lag in itertools.product([i for i in range(34)if i!=32],[0,255]):
   pair=[]
   for v in [old,b]:
    q=A.C.setup(v,ch);q.put(NmiDisable=lag,DisableScreenFlag=1,VRAM_Buffer_AddrCtrl=0,VRAM_Buffer1_Offset=0,FamilyMainCommit=0);q.m.writes=[]
    z=g.nmi(q);pair.append((q,z))
   (qa,za),(qb,zb)=pair
   aa,bb=A.C.M.fastapp(qa),A.C.M.fastapp(qb);assert aa==bb,('foreign NMI application',ch,lag,A.M.different(aa,bb))
   assert qa.m.rawtags==qb.m.rawtags
   def writes(q):return[(a,v)for a,v in q.m.writes if not 256<=a<512 and not 0x5114<=a<=0x5117]
   assert writes(qa)==writes(qb),('foreign NMI ordered writes',ch,lag)
   rows.append([ch,lag,zb['CPU']-za['CPU'],zb['minimum_SP']])
  d['checks']['actual_foreign_normal_lag_NMI']=dict(cases=len(rows),rows=rows,CPU_delta=[min(x[2]for x in rows),max(x[2]for x in rows)])
  d['passed']=True
 except Exception as e:d.update(error=repr(e),traceback=traceback.format_exc())
 finally:A.setup=original
 d['bindings']={str(p.resolve()):B.sha(p)for p in [Path(__file__),Path(A.__file__),Path(L.__file__),Path(I.__file__),N/'candidate.nes',N/'candidate.dbg']}
 out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items()if k not in ['bindings','traceback','checks']}));assert d['passed']
if __name__=='__main__':main()
