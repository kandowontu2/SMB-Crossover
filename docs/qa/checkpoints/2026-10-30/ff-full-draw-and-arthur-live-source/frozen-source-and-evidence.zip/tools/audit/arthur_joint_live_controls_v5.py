"""Actual post-Ic constructor and full GameLoop on corrected source successor."""
import json,traceback
from pathlib import Path
import arthur_joint_live_controls_v1 as V
import arthur_joint_live_build_v5 as B
from verify_native_relocation import NesMPU
A=V.A;O=B.O;N=B.N
def main():
 out=O/'constructor-Main-controls-v5.json';assert not out.exists();d=dict(passed=False,native=False,checks={})
 try:
  b=A.scoped_load(N/'candidate.nes');q=V.seed(b);sig=b['raw'][A.location(b,'ArCacheSignature'):A.location(b,'ArCacheSignature')+16]
  saved=NesMPU.step;events=[];last=[]
  def step(c):
   raw=q.m.rawtags[(c.pc-32768)//8192]if c.pc>=32768 else-1
   last.append((raw,c.pc));del last[:-32]
   if q.m[c.pc]==141 and q.m[c.pc+1]+256*q.m[c.pc+2]==A.address(b,'ArHostReady')and c.a==167:
    assert bytes(q.m.ram[2][8160:8176])==sig,('ready before full cookie',raw,c.pc)
    events.append((raw,c.pc,q.m.ppu_reads))
   saved(c)
  NesMPU.step=step
  try:c,tr,mn=A.call(q,'NrFreshGameInit')
  finally:NesMPU.step=saved
  assert q.get('ArHostReady')==167 and bytes(q.m.ram[2][8160:8176])==sig,('constructor ready',q.get('ArHostReady'))
  assert len(events)==1 and q.m.ppu_reads>0 and q.get('ArR_053A')==64
  d['checks']['actual_post_Ic_constructor']=dict(PPU_buffered_reads=q.m.ppu_reads,ready_published_once_after_full_cookie=events,CPU=c.processorCycles,minSP=mn,trace_entries=len(tr))
  ticks=[]
  for age in range(24):
   keys=1|(128 if 4<=age<12 else 0)
   q.put(SavedJoypadBits=keys,SavedJoypad1Bits=keys,ArHostPad=keys,ArHostDue=int(age%3==0),NmiDisable=255,FamilyMainCommit=1,VRAM_Buffer1_Offset=0)
   c,tr,mn=A.M.run_linked(q,'GameLoop')[:3]
   assert q.get('ArHostReady')==167 and bytes(q.m.ram[2][8160:8176])==sig
   assert A.point(b,'ArHostMovement')in tr and A.point(b,'ArHostDrawAll')in tr,('complete Main missing route',age,A.point(b,'ArHostMovement')in tr,A.point(b,'ArHostDrawAll')in tr)
   ticks.append([age,c.processorCycles,mn,q.get('Player_X_Position'),q.get('Player_Y_Position')])
  d['checks']['complete_Main']=dict(updates=len(ticks),rows=ticks)
  d['passed']=True
 except Exception as e:d.update(error=repr(e),traceback=traceback.format_exc(),last_trace=locals().get('last',[]))
 d['bindings']={str(p.resolve()):B.sha(p)for p in [Path(__file__),Path(V.__file__),Path(B.__file__),N/'candidate.nes',N/'candidate.dbg',O/'linked-layout.json']}
 out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items()if k not in ['bindings','traceback','last_trace']}));assert d['passed']
if __name__=='__main__':main()
