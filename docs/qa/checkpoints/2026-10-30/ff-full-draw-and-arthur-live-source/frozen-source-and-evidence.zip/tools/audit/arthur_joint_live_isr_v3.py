"""Actual live Main/loader seams with native vectors and exact raw bank ABI."""
from pathlib import Path
import copy,json,traceback
import arthur_joint_live_controls_v3 as V
import arthur_joint_live_lifecycle_v3 as L
import ff_ram3_execution_controls_v2 as E
from verify_native_relocation import NesMPU
A=V.A;B=V.B;O=V.O;N=V.N
def clone(q):
 z=copy.copy(q);z.m=copy.copy(q.m)
 for n,v in vars(q.m).items():
  if n=='bundle':continue
  if isinstance(v,list):setattr(z.m,n,[bytearray(x)if isinstance(x,bytearray)else x for x in v])
  elif isinstance(v,bytearray):setattr(z.m,n,bytearray(v))
 z.m.writes=[];z.m.ram_writes=[];return z
def start(q,name):
 bank,pc=A.point(q.b,name);win=(pc-32768)//8192;q.m.page(win,bank)
 if win in [1,2]:q.set('CurrentBank'if win==1 else'CurrentBankC',bank|128)
 c=NesMPU(memory=q.m,pc=pc);c.sp=240;c.a=0x59;c.x=0;c.y=0;c.p=0x71;c.stPushWord(0x5aff);return c
def run(q,c,hit=None,kind='NMI'):
 fired=False;proof=None;low=c.sp
 for k in range(300000):
  if c.pc==0x5b00:return proof,low
  low=min(low,c.sp);raw=q.m.rawtags[(c.pc-32768)//8192]if c.pc>=32768 else-1
  if not fired and hit and hit(q,c,raw):
   proof=E.interrupt(q.m,c,kind);fired=True;low=min(low,proof['minimum_SP'])
  assert q.m[c.pc],('BRK',hex(c.pc),raw)
  c.step()
 raise AssertionError(('bounded return',hex(c.pc)))
def main():
 out=O/'actual-live-ISR-v3.json';assert not out.exists();d=dict(passed=False,native=False,checks={})
 try:
  b=A.scoped_load(N/'candidate.nes');template=L.fresh(b);template.put(FamilyMainCommit=1,ArHostDue=1,ArHostPad=129,SavedJoypadBits=129,NmiDisable=255,VRAM_Buffer_AddrCtrl=0,VRAM_Buffer1_Offset=0)
  rows=[]
  for n in ['ArGenValidate','ArGenCheckForeground::Loop','ArHostMovement','ArStep','ArHostAfterTerrain','ArGenDrawAll','ArHostDrawAll','ArCacheEmit']:
   bank,pc=A.point(b,n)
   if n=='ArCacheEmit':bank=2
   for kind in ['NMI','IRQ']:
    q=clone(template);c=start(q,'GameLoop');p,low=run(q,c,lambda q,c,raw:(raw&127,c.pc)==(bank,pc),kind)
    assert p is not None,('cut not reached',n,bank,pc)
    assert q.get('ArHostReady')==167 and bytes(q.m.ram[2][8160:8176])==L.signature(b)
    rows.append(dict(entry=n,min_complete_SP=low,**p))
  d['checks']['genuine_complete_Main_seams']=rows
  # Every mapper shadow/hardware seam in the actual foreground predicate;
  # source-ready selected32 state is acquired by the real constructor above.
  q=clone(template);c=start(q,'GameLoop');cuts=[]
  for k in range(300000):
   if c.pc==0x5b00:break
   raw=q.m.rawtags[(c.pc-32768)//8192]if c.pc>=32768 else-1
   if raw&127==70 and bytes(q.m[c.pc:c.pc+3])in [b'\x8d\x15\x51',b'\x8d\x16\x51']:cuts.append((k,c.pc))
   c.step()
  else:raise AssertionError('Main discovery bounded')
  seams=[]
  for k,pc in cuts:
   for kind in ['NMI','IRQ']:
    q=clone(template);c=start(q,'GameLoop')
    for _ in range(k):c.step()
    assert c.pc==pc
    p=E.interrupt(q.m,c,kind);run(q,c);seams.append(dict(step=k,PC=pc,**p))
  assert cuts;d['checks']['all_executed_C70_shadow_hardware_store_seams']=seams
  # Forced-blank post-Ic loader: real lag NMI keeps buffered2007 stream,
  # copied code/cache and readiness0 until original Ready-last publication.
  loaders=[]
  for n in ['ArCacheCheckpoint','ArCacheStreamBegin','ArCacheLoad::CopyPart','ArCacheLoad::CopyCode','ArCacheLoad::Cookie','ArCacheStreamDone']:
   q=V.V.seed(b);c=start(q,'NrFreshGameInit');bank,pc=A.point(b,n);capture=[]
   def hit(q,c,raw):
    if (raw&127,c.pc)!=(bank,pc):return False
    capture.append((q.m.ppu_addr,q.m.toggle,q.m.buffer,q.m.ppuctrl,q.get('ArHostReady')));return True
   old=E.interrupt
   def check(m,c,kind):
    z=old(m,c,kind);assert (m.ppu_addr,m.toggle,m.buffer,m.ppuctrl,q.get('ArHostReady'))==capture[-1];return z
   E.interrupt=check
   try:p,low=run(q,c,hit)
   finally:E.interrupt=old
   assert p is not None and q.get('ArHostReady')==167 and bytes(q.m.ram[2][8160:8176])==L.signature(b)
   loaders.append(dict(entry=n,min_complete_SP=low,**p))
  d['checks']['actual_post_Ic_loader_lag_NMI_stream_and_ready_order']=loaders
  d.update(passed=True,limits=['CPU execution of actual linked vectors and Main; no native cadence/PPU DMA timing claim.','Main seams use legal lag NMI and enabled IRQ; loader masks IRQ and is tested with lag NMI only.'])
 except Exception as e:d.update(error=repr(e),traceback=traceback.format_exc())
 d['bindings']={str(p.resolve()):B.sha(p)for p in [Path(__file__),Path(E.__file__),Path(L.__file__),N/'candidate.nes',N/'candidate.dbg']}
 out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items()if k not in ['bindings','traceback','checks']}));assert d['passed']
if __name__=='__main__':main()
