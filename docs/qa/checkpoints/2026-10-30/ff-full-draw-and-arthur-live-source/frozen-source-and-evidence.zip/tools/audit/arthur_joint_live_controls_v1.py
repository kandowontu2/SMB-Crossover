"""Actual post-Ic constructor and complete Main; no native emulator or RAM preload."""
from pathlib import Path
import json,traceback
import arthur_joint_live_build_v1 as B
import arthur_cache_host_controls_v1 as H
from verify_native_relocation import NesMPU
A=H.A;O=B.O;N=B.N
def seed(b):
 q=A.C.setup(b,32)
 q.put(OperMode=1,DisableScreenFlag=1,Mirror_PPUMASK=0,Mirror_PPUCTRL=160,NmiDisable=255,
       CurrentPlayer=0,NumberofLives=2,OffScr_NumberofLives=4,FamilyMainCommit=1,CrossoverContinue=0)
 q.m.ppuctrl=160
 return q
def main():
 out=O/'constructor-Main-controls-v1.json';assert not out.exists();d=dict(passed=False,native=False,checks={})
 try:
  b=A.scoped_load(N/'candidate.nes');q=seed(b);sig=b['raw'][A.location(b,'ArCacheSignature'):A.location(b,'ArCacheSignature')+16]
  saved=NesMPU.step;events=[];last=[]
  def step(c):
   raw=q.m.rawtags[(c.pc-0x8000)//8192]if c.pc>=0x8000 else-1
   last.append((raw,c.pc));del last[:-32]
   if q.m[c.pc]==141 and q.m[c.pc+1]+256*q.m[c.pc+2]==A.address(b,'ArHostReady')and c.a==167:
    assert bytes(q.m.ram[2][0x1fe0:0x1ff0])==sig,('ready before full cookie',raw,c.pc)
    events.append((raw,c.pc,q.m.ppu_reads))
   saved(c)
  NesMPU.step=step
  try:c,tr,mn=A.call(q,'NrFreshGameInit')
  finally:NesMPU.step=saved
  assert q.get('ArHostReady')==167 and bytes(q.m.ram[2][0x1fe0:0x1ff0])==sig
  assert len(events)==1 and q.m.ppu_reads>0 and q.get('ArR_053A')==64
  d['checks']['actual_post_Ic_constructor']=dict(native_code=True,PPU_buffered_reads=q.m.ppu_reads,ready_published_once_after_full_cookie=events,CPU=c.processorCycles,minSP=mn,trace_entries=len(tr))
  ticks=[]
  for age in range(24):
   keys=1|(128 if 4<=age<12 else 0)
   q.put(SavedJoypadBits=keys,SavedJoypad1Bits=keys,ArHostPad=keys,ArHostDue=int(age%3==0),NmiDisable=255,FamilyMainCommit=1,VRAM_Buffer1_Offset=0)
   c,tr,mn=A.M.run_linked(q,'GameLoop')[:3]
   assert q.get('ArHostReady')==167 and bytes(q.m.ram[2][0x1fe0:0x1ff0])==sig
   assert A.point(b,'ArHostMovement')in tr and A.point(b,'ArHostDrawAll')in tr
   ticks.append([age,c.processorCycles,mn,q.get('Player_X_Position'),q.get('Player_Y_Position')])
  d['checks']['complete_Main']=dict(updates=len(ticks),rows=ticks)
  d['passed']=True
 except Exception as e:d.update(error=repr(e),traceback=traceback.format_exc(),last_trace=locals().get('last',[]))
 d['bindings']={str(p.resolve()):B.sha(p)for p in [Path(__file__),Path(B.__file__),Path(H.__file__),N/'candidate.nes',N/'candidate.dbg',O/'linked-layout.json']}
 out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items()if k not in ['bindings','traceback','last_trace']}));assert d['passed']
if __name__=='__main__':main()
