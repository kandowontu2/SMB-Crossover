"""Defer visible-title reset's load to genuine native forced-blank InitScreen."""
from pathlib import Path
import json,shutil,subprocess
import arthur_joint_live_build_v3 as B
R=B.R;P=B.O;J=B.N;O=R/'build/arthur-joint-live-v4';N=O/'joint';sha=B.sha
def rewrite(s):
 roots=[J,R/'build/arthur-joint-live-v2/joint',R/'build/arthur-joint-live-v1/joint',R/'build/arthur-joint-busy-guards-v1/joint',R/'build/ff-arthur-joint-transport-v3/joint']
 for old in roots:
  for a in [str(old),old.as_posix()]:s=s.replace(a,str(N))
 return s
def main():
 assert not O.exists()
 h=json.loads((P/'handoff.json').read_text())
 for p,d in h['bindings'].items():assert sha(p)==d,p
 O.mkdir();shutil.copytree(J,N)
 for p in N.rglob('*'):
  if p.is_file()and p.suffix in ['.s','.inc','.cfg','.dep']:
   s=p.read_text();t=rewrite(s)
   if s!=t:p.write_text(t,newline='\n')
 p=N/'generation-constructor.s';s=p.read_text().replace('.import FamilyMainCommit,ArHostReady,ArProfileStart','.import FamilyMainCommit,ArHostReady,ArProfileStart,OperMode')
 s=s.replace(' sta SafecallA_SMC+1\n','')
 s=s.replace('.export ArGenConstruct','.export ArGenConstruct,ArGenSceneLoad')
 old=' GenFar ArCacheEnsure,ArCacheEnsure\n bcc Done'
 new=' lda OperMode\n cmp #1\n bne FreshDone\n jmp ArGenSceneLoad\nFreshDone:rts\n.endproc\n; Every GenFar callee below ignores incoming A. Preserve flags through the\n; genuine FarCallCommon; its saved-source-A value is deliberately not changed.\n.proc ArGenSceneLoad\n GenFar ArCacheEnsure,ArCacheEnsure\n bcc Done'
 assert s.count(old)==1;s=s.replace(old,new);p.write_text(s,newline='\n')
 p=N/'generation-predicates.s';s=p.read_text()
 old=' lda OperMode\n cmp #1\n bne ConstructorRejected\n lda FamilyMainCommit\n and #1\n beq ConstructorRejected'
 new=' lda FamilyMainCommit\n and #1\n beq ConstructorRejected\n lda OperMode\n beq ConstructorAccepted       ; visible-title post-Ic reset; no PPU loading\n cmp #1\n bne ConstructorRejected'
 assert s.count(old)==1;s=s.replace(old,new);s=s.replace(' pla\n sec\n rts\nConstructorRejected:', 'ConstructorAccepted:\n pla\n sec\n rts\nConstructorRejected:',1);p.write_text(s,newline='\n')
 p=N/'generation-shared.s';s=p.read_text();s='.import FwSceneInit,ArGenSceneLoad\n'+s
 s+='''
; Exactly60B in the remaining existing common512 span. Native/FF screen
; initialization remains first and its AXYP result survives unchanged.
.export ArGenSceneInit
.proc ArGenSceneInit
 GenFar FwSceneInit,FwSceneInit
 php
 pha
 txa
 pha
 tya
 pha
 lda SelectedCharacter
 cmp #32
 bne Done
 lda FamilyMainCommit
 and #1
 beq Done
 ; SceneLoad ignores incoming A; do not overwrite the native source-A SMC.
 lda #<ArGenSceneLoad
 sta FarcallJmpTarget_SMC+1
 lda #>ArGenSceneLoad
 sta FarcallJmpTarget_SMC+2
 lda #.lobyte(.bank(ArGenSceneLoad)|$80)
 jsr FarCallCommon
Done:
 pla
 tay
 pla
 tax
 pla
 plp
 rts
.endproc
''';p.write_text(s,newline='\n')
 p=N/'screen_render.s';s=p.read_text();assert s.count('.import FwSceneInit')==1 and s.count('farcall FwSceneInit')==1;s=s.replace('.import FwSceneInit','.import ArGenSceneInit').replace('farcall FwSceneInit','farcall ArGenSceneInit');p.write_text(s,newline='\n')
 cc=str(R/'tools/Windows/cc65/bin/ca65.exe')
 commands=[[rewrite(x)for x in json.loads((J/'main-build.json').read_text())['command']]]
 for n in ['constructor','predicates','shared']:commands.append([cc,'-g','--cpu','6502x','-o',str(N/('generation-'+n+'.o')),str(N/('generation-'+n+'.s'))])
 commands.append([rewrite(x)for x in json.loads((P/'commands.json').read_text())[-1]['command']]);logs=[]
 for cmd in commands:
  for flag in ['-o','-Ln','-m','--create-full-dep']:
   if flag in cmd:assert Path(cmd[cmd.index(flag)+1]).resolve().is_relative_to(N.resolve()),cmd
  for x in cmd:
   if x.startswith('--dbgfile,'):assert Path(x.split(',',1)[1]).resolve().is_relative_to(N.resolve())
  r=subprocess.run(cmd,cwd=N,capture_output=True,text=True);logs.append(dict(command=cmd,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr));(O/'commands.json').write_text(json.dumps(logs,indent=2)+'\n');assert r.returncode==0,r.stderr
 B.B.B.B.mirror(R,N/'candidate.nes');b=B.B.B.B.scoped_load(N/'candidate.nes');sizes={s['name'].strip('"'):int(s['size'],0)for s in b['segs'].values()}
 assert sizes['CHARACTER_HOST_UNION']==2590 and sizes['GIMMICK_COMMON_NMI']==512 and sizes['AR_GEN_CONSTRUCTOR']<=107
 for p,d in h['bindings'].items():assert sha(p)==d,p
 d=dict(native=False,parent=sha(J/'candidate.nes'),candidate=sha(N/'candidate.nes'),sizes=sizes,parent_handoff=sha(P/'handoff.json'),new_span=False,new_RAM=False)
 (O/'linked-layout.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(candidate=d['candidate'],common512=sizes['GIMMICK_COMMON_NMI'],constructor=sizes['AR_GEN_CONSTRUCTOR'])))
if __name__=='__main__':main()
