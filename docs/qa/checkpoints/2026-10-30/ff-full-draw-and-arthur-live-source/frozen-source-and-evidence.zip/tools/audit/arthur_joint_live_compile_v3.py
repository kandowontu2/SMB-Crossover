"""Continue unfrozen source preparation; preserve original compile diagnostics."""
from pathlib import Path
import json,subprocess
import arthur_joint_live_compile_v2 as V
def main():
 N=V.N;O=V.O
 assert not(O/'linked-layout.json').exists()
 p=N/'union.s';s=p.read_text()
 if not s.startswith('.import CurrentBankC\n'):s='.import CurrentBankC\n'+s
 s=s.replace(' beq HuLegacyPostBG::ArAfterLo',' jeq HuLegacyPostBG::ArAfterLo')
 p.write_text(s,newline='\n')
 logs=[]
 prior=json.loads((O/'commands-v2.json').read_text())
 cmd=prior[-1]['command'];V.check(cmd)
 r=subprocess.run(cmd,cwd=N,capture_output=True,text=True)
 logs.append(dict(command=cmd,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr))
 (O/'union-compile-v3.json').write_text(json.dumps(logs,indent=2)+'\n');assert r.returncode==0,r.stderr
 # Preserve v2 logs; compile/relink into a separate v3 log without rerunning main.
 B=V.B
 def rewrite(x):return V.V.rewrite(x).replace(str(B.J),str(N)).replace(B.J.as_posix(),N.as_posix())
 cmds=[]
 for name in ['bbox-local','gm-nmi','arthur-host-adapter','arthur-host-render']:
  cmd=[rewrite(x)for x in json.loads((B.J/(name+'-build.json')).read_text())['command']];V.check(cmd);cmds.append(cmd)
 cc=str(V.V.R/'tools/Windows/cc65/bin/ca65.exe')
 for name in ['predicates','shared','constructor']:cmds.append([cc,'-g','--cpu','6502x','-o',str(N/('generation-'+name+'.o')),str(N/('generation-'+name+'.s'))])
 cmd=[rewrite(x)for x in json.loads((B.J/'final-link.json').read_text())['command']]+[str(N/('generation-'+name+'.o'))for name in ['predicates','shared','constructor']];V.check(cmd);cmds.append(cmd)
 for cmd in cmds:
  r=subprocess.run(cmd,cwd=N,capture_output=True,text=True);logs.append(dict(command=cmd,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr))
  (O/'commands-v3.json').write_text(json.dumps(logs,indent=2)+'\n');assert r.returncode==0,r.stderr
 B.mirror(V.V.R,N/'candidate.nes');b=B.scoped_load(N/'candidate.nes');sizes={s['name'].strip('"'):int(s['size'],0)for s in b['segs'].values()}
 d=dict(candidate=B.sha(N/'candidate.nes'),sizes=sizes,status='ACTUAL_SOURCE_LINKED_ALL_ACCEPTANCE_PENDING',native=False)
 (O/'linked-layout.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(candidate=d['candidate'],common=sizes['CHARACTER_HOST_UNION'],common512=sizes['GIMMICK_COMMON_NMI'],ctor=sizes['AR_GEN_CONSTRUCTOR'],name=sizes['AR_GEN_NAME'])))
if __name__=='__main__':main()
