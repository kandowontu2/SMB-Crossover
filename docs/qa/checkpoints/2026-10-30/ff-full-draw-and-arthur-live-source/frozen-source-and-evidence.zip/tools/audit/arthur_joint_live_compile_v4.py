"""Fix source expression precedence, retain v3 assembler negative, relink."""
import json,subprocess
import arthur_joint_live_compile_v2 as V
N=V.N;O=V.O;B=V.B
def main():
 assert not(O/'linked-layout.json').exists()
 p=N/'generation-constructor.s';s=p.read_text();assert '#<Address'in s
 s=s.replace('#<Address','#<(Address)').replace('#>Address','#>(Address)');p.write_text(s,newline='\n')
 old=json.loads((O/'commands-v3.json').read_text());commands=[old[-1]['command']]
 def rewrite(x):return V.V.rewrite(x).replace(str(B.J),str(N)).replace(B.J.as_posix(),N.as_posix())
 link=[rewrite(x)for x in json.loads((B.J/'final-link.json').read_text())['command']]+[str(N/('generation-'+name+'.o'))for name in ['predicates','shared','constructor']];V.check(link);commands.append(link)
 logs=[]
 for cmd in commands:
  V.check(cmd);r=subprocess.run(cmd,cwd=N,capture_output=True,text=True);logs.append(dict(command=cmd,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr))
  (O/'commands-v4.json').write_text(json.dumps(logs,indent=2)+'\n');assert r.returncode==0,r.stderr
 B.mirror(V.V.R,N/'candidate.nes');b=B.scoped_load(N/'candidate.nes');sizes={s['name'].strip('"'):int(s['size'],0)for s in b['segs'].values()}
 d=dict(candidate=B.sha(N/'candidate.nes'),sizes=sizes,status='ACTUAL_SOURCE_LINKED_ALL_ACCEPTANCE_PENDING',native=False)
 (O/'linked-layout.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(candidate=d['candidate'],common=sizes['CHARACTER_HOST_UNION'],common512=sizes['GIMMICK_COMMON_NMI'],ctor=sizes['AR_GEN_CONSTRUCTOR'],name=sizes['AR_GEN_NAME'])))
if __name__=='__main__':main()
