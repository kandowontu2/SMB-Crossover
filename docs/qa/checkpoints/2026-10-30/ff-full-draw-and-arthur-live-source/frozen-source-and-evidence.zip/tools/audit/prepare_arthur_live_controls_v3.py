"""Freeze a successor of the constructor fixture with new explicit bindings."""
from pathlib import Path
R=Path(__file__).resolve().parents[2]
def main():
 p=R/'tools/audit/arthur_joint_live_controls_v3.py';assert not p.exists()
 s=(R/'tools/audit/arthur_joint_live_controls_v2.py').read_text()
 s=s.replace('import arthur_joint_live_build_v2 as B','import arthur_joint_live_build_v3 as B').replace('constructor-Main-controls-v2.json','constructor-Main-controls-v3.json')
 p.write_text(s,newline='\n')
if __name__=='__main__':main()
