"""Source-compose frozen full FF draw/data into a new actual joint prototype."""
from pathlib import Path
import hashlib,json,re,sys
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import prepare_ff_joint_source_v1 as B
from prepare_ff_current_component_v2 import qualified
from finalize_ff_current_component_v3 import dependencies
from check_tmnt_render_oa import address,location
from prepare_cv3_dmc_mirror import prepare
P=R/'build/ff-arthur-joint-transport-v3';F=R/'build/final-fantasy-host-render-v9'
HP=R/'build/final-fantasy-host-render-qualified-v1/handoff.json'
O=R/'build/ff-joint-full-render-v2';sha=B.sha

def main():
    assert not O.exists();files=B.validate(HP,'a3ea17134c498264c2a216c9f82ead3680f4e6b689db4a18c0291d3f5dcf5949')
    parent=json.loads((P/'source-closure.json').read_text())
    for f,h in parent['bindings'].items():assert sha(f)==h,f
    files|=set(map(Path,parent['bindings']))|{P/'source-closure.json'}
    O.mkdir();d=O/'joint';d.mkdir()
    for p in(P/'joint').rglob('*'):
        if p.is_file()and p.suffix in['.s','.inc','.cfg','.bin','.chr']:
            q=d/p.relative_to(P/'joint');q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes())
    for n in['render','cull']:(d/('ff-'+n+'.s')).write_bytes((F/(n+'.s')).read_bytes())
    image=(F/'ram3.bin').read_bytes();assert sha(F/'ram3.bin')=='c22aad37d582041d757bdde88058aad18649ce48f7f3c55f43bbc5f9f1c74e30'
    (d/'ff-stream.bin').write_bytes(image);cookie=bytes([167,22,0,4])+hashlib.sha256(image).digest()[:12];(d/'ff-cookie.bin').write_bytes(cookie)
    B.write(d/'loader.s',(d/'loader.s').read_text()+'\n.export FwGateUnavailable\n')
    bridge='''
.macpack longbranch
.segment "FF_DRAW_BRIDGE"
.import FwCheck,FwCallEnter,FwGateUnavailable,FfHostDrawShots
.import SafecallA_SMC,FarcallJmpTarget_SMC
.export FwHostDrawShots
FwHostDrawShots:
 php
 jsr FwCheck
 jcc FwGateUnavailable
 plp
 sta SafecallA_SMC+1
 lda #<FfHostDrawShots
 sta FarcallJmpTarget_SMC+1
 lda #>FfHostDrawShots
 sta FarcallJmpTarget_SMC+2
 jmp FwCallEnter
'''
    B.write(d/'ff-draw-bridge.s',bridge)
    v=(d/'veneers.s').read_text();needle='; 2 Draw explicit_unimplemented_reject\n jmp FwServiceUnavailable'
    assert v.count(needle)==1;v=v.replace(needle,'; 2 Draw actual_early_source_body_and_effects\n jmp FwHostDrawShots')
    B.write(d/'veneers.s','.import FwHostDrawShots\n'+v)
    B.write(d/'ff-component.s',(d/'ff-component.s').read_text()+'\n.export FfRectX,FfRectPage,FfRectY,FfRectW,FfRectH,FfEnemyBit\n')
    # Native bank comes from the actual linked renderer export, never a stale PC.
    entry=(d/'entrypoint.s').read_text()+'\n.exportzp FfNativeRendererBank\nFfNativeRendererBank=.lobyte(.bank(MetaspriteRenderLoop)|$80)\n'
    for n in['render','cull']:
        for m in re.finditer(r'^\.import(zp)? (.+)$',(F/(n+'.s')).read_text(),re.M):
            for name in m[2].split(','):
                name=name.strip()
                if not name.startswith('Ff'):entry+='\n.export'+('zp'if m[1]else'')+' '+name
    B.write(d/'entrypoint.s',entry+'\n')
    cfg=(d/'private.cfg').read_text().replace((P/'joint/ram3.bin').as_posix(),(d/'ram3.bin').as_posix())
    needle='FF_RAM_PUBLISHER:load=FF_RAM3_MEM,type=ro,start=$a275;'
    assert cfg.count(needle)==1
    cfg=cfg.replace(needle,'FF_FX_DATA0:load=FF_RAM3_MEM,type=ro,start=$a000;\n'+needle+'\n'
      'FF_HOST_RENDER:load=FF_RAM3_MEM,type=ro,start=$a300;\nFF_FX_DATA1:load=FF_RAM3_MEM,type=ro,start=$a700;\n'
      'FF_HOST_CULL_TABLES:load=FF_RAM3_MEM,type=ro,start=$a800;\nFF_FX_DATA2:load=FF_RAM3_MEM,type=ro,start=$a874;')
    needle='FF_HOST_PICKUPS:load=FF_RAM3_MEM,type=ro,start=$bb60;';assert cfg.count(needle)==1
    cfg=cfg.replace(needle,needle+'\nFF_FX_DATA3:load=FF_RAM3_MEM,type=ro,start=$bcef;');B.write(d/'private.cfg',cfg)
    cfg=(d/'private.cfg').read_text()
    cfg=cfg.replace('FF_SERVICE_VENEERS:load=X5_NEW_3E,type=ro,start=$b400;',
       'FF_DRAW_BRIDGE:load=X5_NEW_3E,type=ro,start=$b31c;\nFF_SERVICE_VENEERS:load=X5_NEW_3E,type=ro,start=$b400;')
    B.write(d/'private.cfg',cfg)
    before=str(P/'joint');after=str(d)
    names=['main','rogue-component','union','bbox-local','gm-nmi','dk-component','reader',
           'ff-component','publisher','loader','preview','stream','combat','terrain','pickups','veneers','typed-services']
    for n in names:
        cmd=json.loads((P/'joint'/(n+'-build.json')).read_text())['command'];B.run(d,[v.replace(before,after)for v in cmd],n+'-build')
    for n in['ff-render','ff-cull','ff-draw-bridge']:
        cmd=[str(R/'tools/Windows/cc65/bin/ca65.exe'),'-g','--cpu','6502x','-I',str(d),'-I',str(R/'src'),
          '--create-full-dep',str(d/(n+'.dep')),'-o',str(d/(n+'.o')),str(d/(n+'.s'))];B.run(d,cmd,n+'-build')
    arnames=['native-kernels','component','host-state','host-world','host-adapter','host-render','art','chr','palette','own-services']
    for n in arnames:
        phase='arthur-final-fingerprint-build'if n=='host-render'else'arthur-'+n+'-build'
        cmd=json.loads((P/'joint'/(phase+'.json')).read_text())['command'];B.run(d,[v.replace(before,after)for v in cmd],'arthur-'+n+'-build')
    cmd=json.loads((P/'joint/final-link.json').read_text())['command'];cmd=[v.replace(before,after)for v in cmd]+[str(d/'ff-render.o'),str(d/'ff-cull.o'),str(d/'ff-draw-bridge.o')]
    B.run(d,cmd,'final-link');prepare(R,d/'candidate.nes')
    b=qualified(d/'candidate.nes');old=qualified(P/'joint/candidate.nes')
    assert(d/'ram3.bin').read_bytes()==image,'Full renderer source-linked8KB differs from frozen c22 image'
    assert(d/'arthur/cache-signature.inc').read_bytes()==(P/'joint/arthur/cache-signature.inc').read_bytes()
    assert b['raw'][location(b,'ArCacheEmit'):location(b,'ArCacheExecEnd')]==old['raw'][location(old,'ArCacheEmit'):location(old,'ArCacheExecEnd')]
    raw=b['raw'];base=old['raw'];cs=1048592
    diffs=[i for i,(a,z)in enumerate(zip(raw,base))if a!=z]
    spans=[(16+62*8192+0xa00,16+62*8192+0x1690),(cs+893*1024,cs+901*1024)]
    assert all(any(a<=i<z for a,z in spans)for i in diffs),'FF render successor touched foreign bytes'
    moved={n:[s['val'],b['syms'].get(n,{}).get('val')]for n,s in old['syms'].items()if 'seg'in s and '::'not in n and b['syms'].get(n,{}).get('val')!=s['val']}
    assert not moved,moved
    for p in list(d.glob('*.dep'))+list((d/'arthur').glob('*.dep')):files.update(dependencies(p))
    files.update(Path(v)for v in cmd if v.endswith('.o'));files.update(p for p in O.rglob('*')if p.is_file());files.add(Path(__file__))
    B.save(O/'source-closure.json',dict(passed=True,native=False,admitted=False,status='PRIVATE_SOURCE_FULL_FF_DRAW_ROW_VERSION4_CPU_PENDING',
      candidate_sha256=sha(d/'candidate.nes'),parent_sha256=sha(P/'joint/candidate.nes'),RAM3_sha256=sha(d/'ram3.bin'),cookie=list(cookie),
      only_own_ROM62_and_existing_carrier893_changed=True,all_prior_publicPCs_exact=True,all_Arthur_common_classifier_header_other_CHR_exact=True,
      renderer_code_bytes=address(b,'FfHostRenderEnd')-address(b,'FfHostRenderBegin'),
      limits=['Actual early draw order/nativebody0/OAM/CHR Main consumer checks still pending.',
       'Palette/audio/feet/postBG/flash/NewEnemy and Arlifecycle/NMI still pending; no native/cadence/admission claim.'],
      bindings={str(p.resolve()):sha(p)for p in sorted(files)}))
    print('FULL DRAW SOURCE',sha(d/'candidate.nes'),flush=True)

if __name__=='__main__':main()
