"""Real constructor/Main/vector/owner-retirement controls, no native claims."""
from pathlib import Path
import itertools,json,traceback
import arthur_joint_live_controls_v3 as V
import arthur_joint_live_lifecycle_v2 as L
from verify_native_relocation import NesMPU
A=V.A;B=V.B;O=V.O;N=V.N
def fresh(b):
 q=V.V.seed(b);A.call(q,'NrFreshGameInit');assert q.get('ArHostReady')==167;return q
def signature(b):return b['raw'][A.location(b,'ArCacheSignature'):A.location(b,'ArCacheSignature')+16]
def observe(q,fn):
 ty=type(q.m);oldread=ty.__getitem__;oldstep=NesMPU.step;reads=[];execs=[];now=[None]
 def read(m,i):
  if m is q.m and isinstance(i,int)and 0x5c00<=i<0x5cb0:reads.append([i,*now[0]]if now[0]else[i])
  return oldread(m,i)
 def step(c):
  raw=q.m.rawtags[(c.pc-32768)//8192]if c.pc>=32768 else-1;now[0]=[raw,c.pc]
  if c.pc>=32768 and not raw&128 and raw&3==2:execs.append([raw,c.pc])
  oldstep(c)
 ty.__getitem__=read;NesMPU.step=step
 try:result=fn()
 finally:ty.__getitem__=oldread;NesMPU.step=oldstep
 return result,reads,execs
def main():
 out=O/'lifecycle-vectors-v3.json';assert not out.exists();d=dict(passed=False,native=False,checks={});b=A.scoped_load(N/'candidate.nes');g=L.load_nmi(b)
 try:
  q=fresh(b);rows=[]
  for lag,pause,busy in itertools.product([0,255],[0,1],[0,1,3,5]):
   q.put(NmiDisable=lag,GamePauseStatus=pause,FamilyMainCommit=busy,ArHostPhase=1,ArHostDue=0,VRAM_Buffer_AddrCtrl=0,VRAM_Buffer1_Offset=0)
   z,reads,exe=observe(q,lambda:g.nmi(q));expected=int(not pause and not(busy&1))
   assert q.get('ArHostPhase')==(3 if expected else 1)and q.get('ArHostDue')==expected,('clock',lag,pause,busy)
   if busy&1:assert not reads and not exe,('busy Ar access',lag,pause,busy,reads[:3],exe[:3])
   rows.append(dict(lag=lag,pause=pause,busy=busy,**g.scheduler.summary(z)))
  d['checks']['real_normal_lag_vectors_busy_before_overlay']=rows
  q.put(ArHostPhase=1,ArHostDue=0,FamilyMainCommit=0);A.call(q,'AudioUpdate');assert q.get('ArHostPhase')==1 and q.get('ArHostDue')==0
  d['checks']['ordinary_audio_no_clock']=True
  pending=[]
  for i in range(17):
   q=V.V.seed(b);q.put(ArHostReady=167,FamilyMainCommit=1)
   if i<16:
    q.m.ram[2][8160:8176]=signature(b);q.m.ram[2][8160+i]^=1
   result,reads,exe=observe(q,lambda:A.M.run_linked(q,'GameLoop'))
   assert not reads and not exe,('pending/stale Main Ar access',i,reads[:5],exe[:5])
   for lag in [0,255]:
    q.put(NmiDisable=lag,FamilyMainCommit=0,VRAM_Buffer_AddrCtrl=0,VRAM_Buffer1_Offset=0)
    z,reads,exe=observe(q,lambda:g.nmi(q));assert not reads and not exe,('stale NMI Ar access',i,lag,reads[:5],exe[:5])
   pending.append([i,result[0].processorCycles,result[2]])
  d['checks']['pending_and_all16_cookie_poison_Main_normal_lag_NMI_zero_Ar_access']=pending
  # Actual source state and 2-player native transposition, no second hidden state.
  q=fresh(b);A.owned(q,'ArHostNativePickup',a=6);A.owned(q,'ArHostSave');assert q.get('ArR_053A')==68
  scene=[]
  for name,value in [('AreaNumber',1),('WorldNumber',2),('AreaAddrsLOffset',7)]:
   q.set(name,value);A.call(q,'HuReset');assert q.get('ArHostReady')==167 and q.get('ArR_053A')==68;scene.append([name,value])
  q.put(NumberOfPlayers=1,OffScr_NumberofLives=4,OffScr_AreaNumber=3,OffScr_WorldNumber=1)
  for turn in range(4):
   if turn==2:q.put(NumberofLives=1)
   A.call(q,'NativeRareTransposePlayersCore');A.call(q,'HuGraphics');want=[64,68,66,64][turn]
   assert q.get('ArR_053A')==want,('player weapon',turn,q.get('ArR_053A'),want)
   if turn==0:A.owned(q,'ArHostNativePickup',a=8);A.owned(q,'ArHostSave')
   scene.append(['transpose',turn,q.get('CurrentPlayer'),q.get('ArR_053A')])
  d['checks']['actual_area_reset_native_transpose_and_life_profiles']=scene
  # Actual resolver must retire before publishing a new owner. Current real
  # menu table, not a numeric copied menu-index assumption, chooses raw0/32.
  q=fresh(b);table=A.location(b,'X5MenuCharacters');ids=b['raw'][table:table+32];mi=ids.index(0);ai=ids.index(32)
  q.put(CrossoverMenuIndex=mi,FamilyMainCommit=1);stores=[];old=NesMPU.step;selected=A.address(b,'SelectedCharacter')
  def step(c):
   if q.m[c.pc]==141 and q.m[c.pc+1]+256*q.m[c.pc+2]==selected:
    stores.append([c.a,q.get('ArHostReady'),q.m.ram[2][8160]])
    if c.a!=32:assert q.get('ArHostReady')==0 and q.m.ram[2][8160]==0,('publication before retirement',stores[-1])
   old(c)
  NesMPU.step=step
  try:A.call(q,'HuResolve')
  finally:NesMPU.step=old
  assert q.get('SelectedCharacter')==0 and stores
  q.put(CrossoverMenuIndex=ai,FamilyMainCommit=1);A.call(q,'HuResolve');assert q.get('SelectedCharacter')==32 and q.m.ram[2][8160]==0
  q.put(FamilyMainCommit=0,NmiDisable=255);z,reads,exe=observe(q,lambda:g.nmi(q));assert not reads and not exe
  q.put(FamilyMainCommit=1,NmiDisable=255,DisableScreenFlag=1,Mirror_PPUMASK=0);A.call(q,'NrFreshGameInit');assert q.get('ArHostReady')==167 and bytes(q.m.ram[2][8160:8176])==signature(b)
  d['checks']['actual_menu_resolver_retire_reselect_post_Ic_reconstruct']=dict(menu_indices=[mi,ai],selected_stores=stores)
  d['passed']=True
 except Exception as e:d.update(error=repr(e),traceback=traceback.format_exc())
 d['bindings']={str(p.resolve()):B.sha(p)for p in [Path(__file__),Path(L.__file__),N/'candidate.nes',N/'candidate.dbg',O/'constructor-Main-controls-v3.json']}
 out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items()if k not in ['bindings','traceback']}));assert d['passed']
if __name__=='__main__':main()
