"""Pending raw32 through genuine GameLoop (typed wrapper needs real frame)."""
import json,traceback
from pathlib import Path
import arthur_joint_live_controls_v2 as V
A=V.A;B=V.B;O=V.O;N=V.N
def main():
 out=O/'pending-complete-Main-v2.json';assert not out.exists();d=dict(passed=False,native=False)
 q=None;reads=[]
 try:
  b=A.scoped_load(N/'candidate.nes');q=V.V.seed(b);q.put(ArHostReady=167)
  ty=type(q.m);old=ty.__getitem__
  def read(m,i):
   if m is q.m and isinstance(i,int)and 0x5c00<=i<0x5cb0:reads.append(i)
   return old(m,i)
  ty.__getitem__=read
  try:c,tr,mn=A.M.run_linked(q,'GameLoop')[:3]
  finally:ty.__getitem__=old
  d.update(CPU=c.processorCycles,minSP=mn)
  assert not reads,('pending actual Main read Arthur overlay without full cookie',sorted(set(reads)))
  d['passed']=True
 except Exception as e:d.update(error=repr(e),traceback=traceback.format_exc())
 d['Arthur_overlay_reads']=sorted(set(reads));d['bindings']={str(p.resolve()):B.sha(p)for p in [Path(__file__),N/'candidate.nes',N/'candidate.dbg']}
 out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items()if k not in ['bindings','traceback']}));assert d['passed']
if __name__=='__main__':main()
