"""Real complete InitScreen, all64 flags and unchanged FF/native consumers."""
from pathlib import Path
import itertools,json,traceback
import arthur_joint_live_controls_v5 as V
import arthur_joint_live_isr_v5 as I
from sunny_integrated_controls_v1 import registers,smc_at
A=V.A;B=V.B;O=V.O;N=V.N;P=B.R/'build/ff-arthur-joint-transport-v3/joint'
def main():
 out=O/'actual-InitScreen-ABI-v5.json';assert not out.exists();d=dict(passed=False,native=False,rows=[])
 try:
  old,b=[A.scoped_load(p/'candidate.nes')for p in [P,N]]
  for ch in [0,22,26,28]:
   templates=[]
   for v in [old,b]:
    q=A.C.setup(v,ch);q.put(OperMode=1,DisableScreenFlag=1,Mirror_PPUMASK=0,Mirror_PPUCTRL=160,NmiDisable=255,FamilyMainCommit=1,ScreenRoutineTask=0,VRAM_Buffer1_Offset=0);q.m.ppuctrl=160
    A.call(q,'InitScreen');templates.append(q)
   for f in range(64):
    flags=0x30|(f&3)|((f&4)<<0)|((f&8)<<0)|((f&16)<<2)|((f&32)<<2);pair=[]
    for v,q in zip([old,b],templates):
     q=I.clone(q);q.put(ScreenRoutineTask=0);q.m.ppu_log=[]
     c,tr,mn=A.call(q,'InitScreen',a=91,x=3,y=27,p=flags);pair.append((q,c,tr,mn))
    (qa,ca,ta,ma),(qb,cb,tb,mb)=pair
    assert registers(ca)==registers(cb),('InitScreen AXYP/SP',ch,flags,registers(ca),registers(cb))
    assert A.C.M.fastapp(qa)==A.C.M.fastapp(qb),('InitScreen application',ch,flags)
    assert [bytes(x)for x in qa.m.ram]==[bytes(x)for x in qb.m.ram]and qa.m.rawtags==qb.m.rawtags
    assert qa.m.ppu_log==qb.m.ppu_log,('native ordered PPU',ch,flags)
    def writes(q,v):return[(i,x)for i,x in q.m.writes if not 256<=i<512 and not 0x5114<=i<=0x5117 and i not in smc_at(v)and i not in[A.address(v,'CurrentBank'),A.address(v,'CurrentBankC')]]
    assert writes(qa,old)==writes(qb,b),('InitScreen ordered writes',ch,flags)
    assert ta.count(A.point(old,'MoveAllSpritesOffscreen'))==tb.count(A.point(b,'MoveAllSpritesOffscreen'))==1
    d['rows'].append([ch,flags,cb.processorCycles-ca.processorCycles,mb])
  d.update(passed=True,cases=len(d['rows']),CPU_delta=[min(x[2]for x in d['rows']),max(x[2]for x in d['rows'])],scope='Actual complete native InitScreen and FF cold load then256 warm all64flags comparisons. AXYP/SP/application/raw RAM0..3/mappings/orderedPPU and nonmapper stores exact; original Move exactly once. No native timing claim.')
 except Exception as e:d.update(error=repr(e),traceback=traceback.format_exc())
 d['bindings']={str(p.resolve()):B.sha(p)for p in [Path(__file__),P/'candidate.nes',P/'candidate.dbg',N/'candidate.nes',N/'candidate.dbg']}
 out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items()if k not in ['bindings','traceback','rows']}));assert d['passed']
if __name__=='__main__':main()
