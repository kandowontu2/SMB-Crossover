"""Actual shared55 vs independently prepared true SFC entry; no body stubs."""
from pathlib import Path
import itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import ff_joint_typed_controls_v1 as T
import ff_host_pickups_vectors_v2 as V
from ff_wram_host_isr_v4 import clone
O=R/'build/ff-arthur-joint-transport-v3';H=T.H;H.O=O/'joint';sha=T.sha

def ready(b,owner):
    m=T.base(b)
    m.raw_page(1,0xcf);H.put(m,CurrentBank=0xcf)
    if owner==32:
        H.put(m,SelectedCharacter=32,ArHostReady=0)
        # C63 ArHostConstruct is a near worker, not an A-window SFC endpoint.
        # Service15 selects real own veneer -> actual ArDispatch C-bank owner.
        c=start(m,15,0x71);finish(m,c,15)
        c,_=H.invoke(m,'ArCacheEnsure');assert c.p&1,'real Ar forcedblank cache loader rejected'
    return m

def start(m,index,p,reference=False):
    b=m.bundle;owner=H.get(m,'SelectedCharacter');base='FwServiceVeneers'if owner==22 else'ArOwnServices'
    m[H.address(b,'SafecallA_SMC')+1]=0x55
    c=H.NesMPU(memory=m,pc=H.address(b,'HuCommon'));c.a=0x55;c.x=index%6;c.y=index;c.p=p;c.sp=224;c.stPushWord(0x5aff)
    if reference:
        # Independent source-metadata lookup. No arithmetic/branch source code
        # is substituted into the cartridge and the real callee runs to RTS.
        dest=H.address(b,base)+3*min(index,36)
        m[H.address(b,'FarcallJmpTarget_SMC')+1]=dest&255
        m[H.address(b,'FarcallJmpTarget_SMC')+2]=dest>>8
        m[H.address(b,'NextBank_SMC')+1]=0xbe if owner==22 else 0xc6
        c.pc=H.address(b,'FarCallCommon')+3;c.y=3 if index==14 else 0
    else:c.stPush(p);c.stPush(3 if index==14 else 0)
    return c

def signature(m,c):
    ex=set(range(0x100,0x200))|set(range(0x5114,0x5118))
    shadows={H.address(m.bundle,n)for n in['CurrentBank','CurrentBankC']}
    return(bytes(m[i]for i in range(0x8000)if i not in ex),
       [(a,v)for a,v in m.writes if a not in ex|shadows],
       (c.a,c.x,c.y,c.p,c.sp),m.rawtags[:],bytes(m[0x15a:0x17b]),[bytes(x)for x in m.ram])

def finish(m,c,index,hook=None):
    old=m.rawtags[:];live=bytes(m[0x1e1:0x200]);owner=H.get(m,'SelectedCharacter')
    base=H.address(m.bundle,'FwServiceVeneers'if owner==22 else'ArOwnServices')
    dest=base+3*min(index,36);bank=0xbe if owner==22 else 0xc6;seen=[]
    def observe(mem,cpu,i):
        if cpu.pc==dest and mem.rawtags[1]==bank:seen.append((cpu.a,cpu.x,cpu.y,cpu.p,cpu.sp))
        if hook:hook(mem,cpu,i)
    H.finish(m,c,observe)
    assert seen and c.sp==224 and bytes(m[0x1e1:0x200])==live
    assert m.rawtags[1]==old[1]==0xcf and H.get(m,'CurrentBank')==0xcf
    assert m.rawtags[2]==old[2]and H.get(m,'CurrentBankC')==old[2]
    return seen

def pairs(b):
    rows=[];reject=[]
    flags=[0x30|sum(((n>>i)&1)*bit for i,bit in enumerate([1,2,4,8,64,128]))for n in range(64)]
    for owner in[22,32]:
        seed=ready(b,owner)
        for index,p in itertools.product(range(36),flags):
            out=[];cost=[]
            for ref in[True,False]:
                m=T.copy(seed);m.writes.clear();m.ram_writes.clear();c=start(m,index,p,ref)
                seen=finish(m,c,index);out.append((signature(m,c),seen));cost.append(c.processorCycles)
            assert out[0]==out[1],('real arithmetic/SFC source ABI pair',owner,index,p)
            rows.append([owner,index,p,*cost])
        print('Actual joint owner',owner,'2304pairs PASS',flush=True)
        for index in range(36,256):
            m=T.copy(seed);m.writes.clear();m.ram_writes.clear();before=bytes(m[0x5c00:0x8000]);c=start(m,index,0x71)
            finish(m,c,index);assert not c.p&1 and bytes(m[0x5c00:0x8000])==before and not m.ram_writes
            reject.append([owner,index])
    return dict(actual_source_ABI_pairs=len(rows),rows=rows,invalid_indices_rejected=len(reject),reject=reject,
      source_kernel_and_ordered_application_writes_all33SMC_AXYP_SP_livepage1_R0R1_maps_allRAMbanks_exact=True,
      scope='Full genuine callee runs. Independent reference prepares source lookup metadata and enters actual SFC+3; no alternate cartridge/common fragment or callee replacement.')

def vectors(b):
    rows=[];masked=0
    for owner in[22,32]:
        seed=ready(b,owner)
        for index in[0,1,4,10,11,14,16,19,23,24,33,35,36]:
            m=T.copy(seed);H.put(m,NmiDisable=0);c=start(m,index,0x30);snap=[]
            def take(mem,cpu,i):
                if i<65 or bytes(mem[cpu.pc:cpu.pc+3])in[b'\x8d\x15\x51',b'\x8d\x16\x51']:
                    snap.append((i,cpu.pc,clone(mem,cpu)))
            finish(m,c,index,take);expected=(c.a,c.x,c.y,c.p,c.sp)
            for step,pc,(state,cpu)in snap:
                for lag,kind in itertools.product([0,255],['NMI','IRQ']):
                    q,d=clone(state,cpu);H.put(q,NmiDisable=lag)
                    if kind=='IRQ'and d.p&d.INTERRUPT:masked+=1;continue
                    proof=V.interrupt(q,d,kind);H.finish(q,d)
                    assert(d.a,d.x,d.y,d.p,d.sp)==expected and q.rawtags==m.rawtags
                    rows.append(dict(owner=owner,service=index,step=step,PC=pc,lag=lag,**proof))
    return dict(real_normal_lag_NMI_IRQ_cases=len(rows),masked_IRQ_requests=masked,rows=rows)

def main():
    out=O/'transport-controls-v2.json';assert not out.exists();p=dict(passed=False,native=False,admitted=False,actual_sourcecart=True,checks={})
    try:
        h=json.loads((O/'source-closure.json').read_text())
        for f,s in h['bindings'].items():assert sha(f)==s,f
        b=H.C.qualified(H.O/'candidate.nes')
        for n,fn in[('source_ABI',pairs),('real_vectors',vectors)]:p['checks'][n]=fn(b);print(n,'PASS',flush=True)
        p['passed']=True
    except Exception as e:p.update(error=repr(e),traceback=traceback.format_exc())
    p['bindings']={str(f.resolve()):sha(f)for f in[Path(__file__),Path(T.__file__),Path(H.__file__),Path(V.__file__),O/'source-closure.json',H.O/'candidate.nes',H.O/'candidate.dbg']}
    target=out if p['passed']else O/'transport-negative-v2.json';assert not target.exists();target.write_text(json.dumps(p,indent=2)+'\n',newline='\n')
    print(json.dumps(dict(passed=p['passed'],path=str(target),error=p.get('error'))),flush=True);assert p['passed']

if __name__=='__main__':main()
