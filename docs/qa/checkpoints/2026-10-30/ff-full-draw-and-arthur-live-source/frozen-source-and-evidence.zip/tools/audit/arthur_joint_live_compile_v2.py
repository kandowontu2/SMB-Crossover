"""Compile the unfrozen prepared successor with destinations checked locally."""
from pathlib import Path
import json,subprocess
import arthur_joint_live_build_v1 as V
import arthur_joint_busy_guards_build_v1 as B
N=V.N;O=V.O
def check(cmd):
 for flag in ['-o','-Ln','-m','--create-full-dep']:
  if flag in cmd:assert Path(cmd[cmd.index(flag)+1]).resolve().is_relative_to(N.resolve()),(flag,cmd)
 for arg in cmd:
  if arg.startswith('--dbgfile,'):assert Path(arg.split(',',1)[1]).resolve().is_relative_to(N.resolve())
def main():
 assert not(O/'linked-layout.json').exists()
 negative=O/'precompile-negative-v1.json'
 if not negative.exists():negative.write_text(json.dumps(dict(native=False,compiler_launched=False,error='Inherited output validator was bound to predecessor destination and correctly rejected new-path outputs. No predecessor write.'),indent=2)+'\n')
 commands=[]
 def rewrite(x):return V.rewrite(x).replace(str(B.J),str(N)).replace(B.J.as_posix(),N.as_posix())
 for name in ['main','union','bbox-local','gm-nmi','arthur-host-adapter','arthur-host-render']:
  p=V.J/(name+'-build.json')
  if not p.exists():p=B.J/(name+'-build.json')
  cmd=[rewrite(x)for x in json.loads(p.read_text())['command']];check(cmd);commands.append(cmd)
 cc=str(V.R/'tools/Windows/cc65/bin/ca65.exe')
 for name in ['predicates','shared','constructor']:
  commands.append([cc,'-g','--cpu','6502x','-o',str(N/('generation-'+name+'.o')),str(N/('generation-'+name+'.s'))])
 link=[rewrite(x)for x in json.loads((B.J/'final-link.json').read_text())['command']]
 link +=[str(N/('generation-'+name+'.o'))for name in ['predicates','shared','constructor']];check(link);commands.append(link)
 logs=[]
 for cmd in commands:
  p=subprocess.run(cmd,cwd=N,capture_output=True,text=True);logs.append(dict(command=cmd,returncode=p.returncode,stdout=p.stdout,stderr=p.stderr))
  (O/'commands-v2.json').write_text(json.dumps(logs,indent=2)+'\n');assert p.returncode==0,p.stderr
 B.mirror(V.R,N/'candidate.nes');b=B.scoped_load(N/'candidate.nes')
 sizes={s['name'].strip('"'):int(s['size'],0)for s in b['segs'].values()}
 d=dict(candidate=B.sha(N/'candidate.nes'),sizes=sizes,status='ACTUAL_SOURCE_LINKED_ALL_ACCEPTANCE_PENDING',native=False)
 (O/'linked-layout.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(candidate=d['candidate'],common=sizes['CHARACTER_HOST_UNION'],common512=sizes['GIMMICK_COMMON_NMI'],ctor=sizes['AR_GEN_CONSTRUCTOR'],name=sizes['AR_GEN_NAME'])))
if __name__=='__main__':main()
