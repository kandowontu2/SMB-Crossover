"""Foreign complete Main against actual full-source 5436 parent."""
from pathlib import Path
import itertools,json,traceback
import arthur_joint_live_controls_v3 as V
from sunny_integrated_controls_v1 import registers,smc_at
A=V.A;B=V.B;O=V.O;N=V.N;P=B.R/'build/ff-arthur-joint-transport-v3/joint'
def main():
 out=O/'foreign-Main-v3.json';assert not out.exists();d=dict(passed=False,native=False,rows=[])
 try:
  old,b=[A.scoped_load(p/'candidate.nes')for p in [P,N]]
  for ch,mode,keys in itertools.product([i for i in range(34)if i!=32],range(2),[0,129]):
   pair=[]
   for v in [old,b]:
    q=A.C.setup(v,ch);q.put(CrossoverBehaviorVersion=mode,SavedJoypadBits=keys,FamilyMainCommit=1)
    c,tr,mn,ann,events=A.M.run_linked(q,'GameLoop',p=0x71);pair.append((q,c,tr,mn,ann,events))
   qa,ca,ta,ma,ana,ea=pair[0];qb,cb,tb,mb,anb,eb=pair[1]
   assert [z[-1]for z in ea]==[z[-1]for z in eb],('JumpEngine',ch,mode,keys)
   assert registers(ca)==registers(cb),('AXYP/SP',ch,mode,keys,registers(ca),registers(cb))
   aa,bb=A.C.M.fastapp(qa),A.C.M.fastapp(qb)
   assert aa==bb,('application',ch,mode,keys,A.M.different(aa,bb))
   assert qa.m.rawtags==qb.m.rawtags,('raw mappings',ch)
   moved=A.M.smc_contract(qa,qb,ta,tb)
   skip=set(smc_at(old))|set(smc_at(b))
   assert bytes(qa.m[i]for i in range(256,257+min(ma,mb))if i not in skip)==bytes(qb.m[i]for i in range(256,257+min(ma,mb))if i not in skip),('live page1',ch)
   def writes(q,v,ann):return[(i,ann.get(k,x))for k,(i,x)in enumerate(q.m.writes)if not 256<=i<512 and not 0x5114<=i<=0x5117 and i not in smc_at(v)and i not in[A.address(v,'CurrentBank'),A.address(v,'CurrentBankC')]]
   assert writes(qa,old,ana)==writes(qb,b,anb),('ordered writes',ch,mode,keys)
   d['rows'].append([ch,mode,keys,cb.processorCycles-ca.processorCycles,mb,moved])
  d.update(passed=True,cases=len(d['rows']),CPU_delta=[min(z[3]for z in d['rows']),max(z[3]for z in d['rows'])],scope='Actual full Main AXYP/SP, application including active ExRAM/OAM, live page1, raw mappings, ordered nonmapper writes; actual executed relocated SMC targets authenticated. Added mapper latency remains explicit.')
 except Exception as e:d.update(error=repr(e),traceback=traceback.format_exc())
 d['bindings']={str(p.resolve()):B.sha(p)for p in [Path(__file__),P/'candidate.nes',P/'candidate.dbg',N/'candidate.nes',N/'candidate.dbg']}
 out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items()if k not in ['bindings','traceback','rows']}));assert d['passed']
if __name__=='__main__':main()
