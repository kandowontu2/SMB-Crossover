"""New actual-source successor for proven wrong-window Ensure call."""
from pathlib import Path
import json,shutil,subprocess
import arthur_joint_live_build_v1 as B
R=B.R;P=B.O;J=B.N;O=R/'build/arthur-joint-live-v2';N=O/'joint';sha=B.sha
def rewrite(s):
 for a,z in [(str(J),str(N)),(J.as_posix(),N.as_posix())]:s=s.replace(a,z)
 return s
def check(cmd):
 for flag in ['-o','-Ln','-m','--create-full-dep']:
  if flag in cmd:assert Path(cmd[cmd.index(flag)+1]).resolve().is_relative_to(N.resolve()),cmd
 for x in cmd:
  if x.startswith('--dbgfile,'):assert Path(x.split(',',1)[1]).resolve().is_relative_to(N.resolve())
def main():
 assert not O.exists();assert sha(J/'candidate.nes')=='52cb42f50a368fc47cdba271b800c678956d957729b18790a3e2d4b0b07a152f'
 bound={str(p.resolve()):sha(p)for p in P.rglob('*')if p.is_file()}
 O.mkdir();shutil.copytree(J,N)
 for p in N.rglob('*'):
  assert p.resolve().is_relative_to(N.resolve())
  if p.is_file()and p.suffix in ['.s','.inc','.cfg','.dep']:
   s=p.read_text();t=rewrite(s)
   if s!=t:p.write_text(t,newline='\n')
 p=N/'generation-constructor.s';s=p.read_text();s=s.replace('.import CmHostFresh,ArCacheRetire,ArCacheEnsure,ArHostEnsure','.import CmHostFresh,ArCacheRetire,ArCacheEnsure,ArHostEnsure,ArDrawPtr,ArDispatch')
 old=' GenFar ArHostEnsure,ArHostEnsure-$2000'
 assert s.count(old)==1
 s=s.replace(old,' lda #<ArHostEnsure\n sta ArDrawPtr\n lda #>ArHostEnsure\n sta ArDrawPtr+1\n GenFar ArDispatch,ArDispatch')
 p.write_text(s,newline='\n')
 commands=[[rewrite(x)for x in row['command']]for row in json.loads((P/'commands-v4.json').read_text())]
 logs=[]
 for cmd in commands:
  check(cmd);r=subprocess.run(cmd,cwd=N,capture_output=True,text=True);logs.append(dict(command=cmd,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr))
  (O/'commands.json').write_text(json.dumps(logs,indent=2)+'\n');assert r.returncode==0,r.stderr
 B.B.mirror(R,N/'candidate.nes');b=B.B.scoped_load(N/'candidate.nes')
 sizes={s['name'].strip('"'):int(s['size'],0)for s in b['segs'].values()}
 assert sizes['AR_GEN_CONSTRUCTOR']==106 and sizes['CHARACTER_HOST_UNION']==2590
 for p,h in bound.items():assert sha(p)==h,p
 d=dict(native=False,parent=sha(J/'candidate.nes'),candidate=sha(N/'candidate.nes'),sizes=sizes,negative_retained=str(P/'constructor-Main-controls-v1.json'),fix='Final Ensure executes through genuine ArDispatch with A26+C63 co-resident; original Ready-last source unchanged.',predecessor_bindings=bound)
 (O/'linked-layout.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(candidate=d['candidate'],ctor=sizes['AR_GEN_CONSTRUCTOR'])))
if __name__=='__main__':main()
