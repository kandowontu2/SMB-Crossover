"""Private actual joint22/32 source transport; no lifecycle/NMI/admission claim."""
from pathlib import Path
import hashlib,importlib.util,json,re,sys
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import prepare_ff_joint_source_v1 as B
from finalize_ff_current_component_v3 import dependencies
from prepare_ff_current_component_v2 import qualified
from check_tmnt_render_oa import address,location
from prepare_cv3_dmc_mirror import prepare
P=R/'build/final-fantasy-joint-typed-v1';A=R/'build/arthur-joint-source-leaf-v1'
G=R/'build/character-host-union-high-owner-classifier-v1';U=R/'build/joint-extended-transport-source-v1'
O=R/'build/ff-arthur-joint-transport-v3';sha=B.sha

def main():
    assert not O.exists();files=set()
    for p,s in[(P/'handoff.json','b44dd7368466afb584a6dc9117978718241cb1a2ef0e6f4fa90958d737d7c8a3'),
      (A/'handoff.json','03f06e994c1801ad1874faf63e96e949f8f5bdc077b200e77e6c2e1eeba2427e'),
      (G/'handoff.json','01887f66fa3506e94f2da5126cf0a413b2d651696ea01bb5deb538313836c92a')]:files|=B.validate(p,s)
    assert sha(U/'proposal.json')=='dbc0d34735c79840866e35a58f0c36d9d9c589d3834b4af873d4aa5fc931a77d'
    for f,s in json.loads((U/'proposal.json').read_text())['bindings'].items():assert sha(f)==s,f
    O.mkdir();d=O/'joint';d.mkdir()
    for p in(P/'joint').rglob('*'):
        if p.is_file()and(p.suffix in['.s','.inc','.cfg']or p.name in['ff-stream.bin','ff-cookie.bin']):
            q=d/p.relative_to(P/'joint');q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(p.read_bytes())
    ar=d/'arthur';ar.mkdir()
    for p in(A/'arthur').iterdir():
        if p.suffix in['.s','.inc','.bin','.chr']:(ar/p.name).write_bytes(p.read_bytes())
    (d/'union.s').write_bytes((U/'union.s').read_bytes())
    (d/'src/new_roster_dispatch.s').write_bytes((G/'joint/src/new_roster_dispatch.s').read_bytes())
    # Only zero-byte labels/exports from Arthur's native overrides. The unsafe
    # selected-only NMI/palette redirect and old standalone lifecycle are absent.
    (d/'src/mmc5.s').write_bytes((A/'native-overrides/mmc5.s').read_bytes())
    pn=(d/'src/parodius_bells.s').read_text()
    B.write(d/'src/parodius_bells.s',pn+'\n.export ArPnAfterPalette\nArPnAfterPalette=PnPaletteScreenUpdate::Samus\n')
    B.write(d/'entrypoint.s',(d/'entrypoint.s').read_text()+'\n'+(A/'parent-exports.inc').read_text())
    # Start from the genuine Arthur physical splits, then compose existing FF
    # splits. Every physical file span keeps its original total byte length.
    cfg=(A/'arthur-on-fast-v6.cfg').read_text();mem,segs=cfg.split('SEGMENTS {',1)
    # One ld65 cursor cannot place Arthur back inside earlier C70 holes.
    # Split exact physical boundaries, keeping C000/C380/CB80 native starts.
    n='X5_NEW_46:start=$c000,size=$1d00,type=ro,file=%O,fill=yes,fillval=$ff,bank=$46;'
    assert mem.count(n)==1
    mem=mem.replace(n,'X5_NEW_46:start=$c000,size=$58f,type=ro,file=%O,fill=yes,fillval=$ff,bank=$46;\n'
       'AR_C70_SMALL:start=$c58f,size=$2d1,type=ro,file=%O,fill=yes,fillval=$ff,bank=$46;\n'
       'X5_NEW_46_MID:start=$c860,size=$1158,type=ro,file=%O,fill=yes,fillval=$ff,bank=$46;\n'
       'AR_C70_TAIL:start=$d9b8,size=$348,type=ro,file=%O,fill=yes,fillval=$ff,bank=$46;')
    segs=segs.replace('RIVER_CITY_ART: load=X5_NEW_46,','RIVER_CITY_ART: load=X5_NEW_46_MID,')
    for n in['ARTHUR_ART_SMALL','ARTHUR_PALETTE_NMI','ARTHUR_PALETTE_WHITE']:
        segs=segs.replace(n+':load=X5_NEW_46,',n+':load=AR_C70_SMALL,')
    segs=segs.replace('ARTHUR_ART_TAIL:load=X5_NEW_46,','ARTHUR_ART_TAIL:load=AR_C70_TAIL,')
    needle='X5_NEW_5D_AFTER_BBOX:start=$afe7,size=$1019,type=ro,file=%O,fill=yes,fillval=$ff,bank=$5d;'
    assert mem.count(needle)==1;mem=mem.replace(needle,'X5_NEW_5D_AFTER_BBOX:start=$afe7,size=$19,type=ro,file=%O,fill=yes,fillval=$ff,bank=$5d;\nFF_ART_MEM:start=$d000,size=$1000,type=ro,file=%O,fill=yes,fillval=$ff,bank=$5d;')
    needle='RECLAIMED_PARODIUS_CHR_MEM:start=$dd000,size=$23000,type=ro,fill=yes,file=%O,fillval=$00;'
    assert mem.count(needle)==1;mem=mem.replace(needle,'PRIVATE_QUICK_CARRIER_MEM:start=$dd000,size=$2400,type=ro,fill=yes,file=%O,fillval=$00;\nFF_STREAM_MEM:start=$df400,size=$2000,type=ro,fill=yes,file=%O,fillval=$00;\nUNALLOCATED_CHR_MEM:start=$e1400,size=$1ec00,type=ro,fill=yes,file=%O,fillval=$00;')
    mem=mem.rsplit('}',1)[0]+'FF_RAM3_MEM:start=$a000,size=$2000,bank=3,type=ro,file="'+(d/'ram3.bin').as_posix()+'",fill=yes,fillval=$ff;\n}\n'
    src=(P/'joint/private.cfg').read_text().split('SEGMENTS {',1)[1]
    fflines='\n'.join(line for line in src.splitlines()if re.match(r'\s*(FF_|FINAL_FANTASY_)',line))
    segs=segs.replace('    KAMIKAZE_CORE: load=X5_NEW_3E,type=ro,start=$b690,optional=yes;',fflines+'\n    KAMIKAZE_CORE: load=X5_NEW_3E,type=ro,start=$b690,optional=yes;')
    # Existing automatically placed native owners must be encountered first.
    owned=[line for line in segs.splitlines()if re.match(r'\s*ARTHUR_',line)]
    assert len(owned)==28,len(owned)
    segs='\n'.join(line for line in segs.splitlines()if not re.match(r'\s*ARTHUR_',line))
    end=segs.index('}\nSYMBOLS')
    segs=segs[:end]+'\n'+'\n'.join(owned)+'\n'+segs[end:]
    B.write(d/'private.cfg',mem+'SEGMENTS {'+segs)
    before=str(B.P/'joint');after=str(d)
    for phase in['main','rogue-component','union','bbox-local','gm-nmi','dk-component','reader']:
        cmd=json.loads((B.P/'joint'/(phase+'-build.json')).read_text())['command']
        B.run(d,[x.replace(before,after)for x in cmd],phase+'-build')
    extra=[]
    for n in['ff-component','publisher','loader','preview','stream','combat','terrain','pickups','veneers','typed-services']:
        cmd=[str(R/'tools/Windows/cc65/bin/ca65.exe'),'-g','--cpu','6502x','-I',str(d),'-I',str(R/'src'),
             '--bin-include-dir',str(d),'--bin-include-dir',str(R),'--create-full-dep',str(d/(n+'.dep')),'-o',str(d/(n+'.o')),str(d/(n+'.s'))]
        B.run(d,cmd,n+'-build');extra.append(str(d/(n+'.o')))
    modules=['native-kernels','component','host-state','host-world','host-adapter','host-render','art','chr','palette','own-services']
    def assemble_ar(n,phase=None):
        cmd=[str(R/'tools/Windows/cc65/bin/ca65.exe'),'-g','--cpu','6502x','-I',str(ar),'-I',str(d),'-I',str(R/'src'),
             '--bin-include-dir',str(ar),'--bin-include-dir',str(R),'--create-full-dep',str(ar/(n+'.dep')),'-o',str(ar/(n+'.o')),str(ar/(n+'.s'))]
        B.run(d,cmd,phase or'arthur-'+n+'-build')
    for n in modules:assemble_ar(n);extra.append(str(ar/(n+'.o')))
    cmd=json.loads((B.P/'joint/link-build.json').read_text())['command'];cmd=[x.replace(before,after)for x in cmd]+extra
    B.run(d,cmd,'initial-link')
    spec=importlib.util.spec_from_file_location('arthur_final_link_signature',A/'derive_signature.py');module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    sig,code=module.derive(d/'candidate.nes',ar/'cache-input.bin',A/'expected-cache.bin')
    B.write(ar/'cache-signature.inc','\n'.join(f'AR_CACHE_SIG{i}=${v:02x}'for i,v in enumerate(sig))+'\n')
    assemble_ar('host-render','arthur-final-fingerprint-build');B.run(d,cmd,'final-link')
    sig2,code2=module.derive(d/'candidate.nes',ar/'cache-input.bin',A/'expected-cache.bin');assert(sig,code)==(sig2,code2)
    prepare(R,d/'candidate.nes');b=qualified(d/'candidate.nes');old=qualified(P/'joint/candidate.nes')
    assert(d/'ram3.bin').read_bytes()==(P/'joint/ram3.bin').read_bytes()
    assert address(b,'HuEnd')==0xb5e0+2538 and address(b,'FwServiceVeneers')==0xb400 and address(b,'ArOwnServices')==0xbd00
    assert (location(b,'FwServiceVeneers')-16)//8192==62
    assert (location(b,'ArOwnServices')-16)//8192==70
    moved={n:[s['val'],b['syms'].get(n,{}).get('val')]for n,s in old['syms'].items()if 'seg'in s and '::'not in n and b['syms'].get(n,{}).get('val')!=s['val']}
    assert all(old['segs'][old['syms'][n]['seg']]['name']=='"CHARACTER_HOST_UNION"'for n in moved),moved
    assert b['raw'][location(b,'X5SetPhysicalChr'):location(b,'X5SetPhysicalChr')+20]==old['raw'][location(old,'X5SetPhysicalChr'):location(old,'X5SetPhysicalChr')+20]
    for p in list(d.glob('*.dep'))+list(ar.glob('*.dep')):files.update(dependencies(p))
    files.update(Path(x)for x in cmd if x.endswith('.o'));files.update(p for p in O.rglob('*')if p.is_file());files|={Path(__file__),U/'proposal.json',U/'union.s'}
    B.save(O/'source-closure.json',dict(passed=True,native=False,admitted=False,status='PRIVATE_SOURCE_LINKED_SHARED55_FF_ARTHUR_PROTOTYPE_CPU_PENDING',
      candidate_sha256=sha(d/'candidate.nes'),FF_RAM3_exact=True,Arthur_C2_code_bytes=len(code),Arthur_cookie=list(sig),common_bytes=2538,common_budget=2592,
      moved_previous_symbols_only_in_owned_A79=len(moved),all_other_publicPCs_exact=True,global_publisher20B_exact=True,
      limits=['Shared55 and qualified classifier are real cartridge source hooks; CPU validation still pending.',
       'Arthur NMI/palette/clock/retire/acquire/feet/postBG/DrawAll hooks intentionally NOT installed; exact oldworkers alone are not jointready.',
       'FF fullrenderer/palette/audio,feet/wall/postBG/flash/NewEnemy lifecycle hooks remain pending; frontend readiness unchanged.',
       'No native/campaign/cadence/performance/admission claim.'],bindings={str(p.resolve()):sha(p)for p in sorted(files)}))
    print('ACTUAL SOURCE JOINT',sha(d/'candidate.nes'),flush=True)

if __name__=='__main__':main()
