"""Make explicit bound successors of affected real-source acceptance fixtures."""
from pathlib import Path
R=Path(__file__).resolve().parents[2]
def main():
 for kind in ['controls','lifecycle','isr','foreign','presentation']:
  src=R/'tools/audit'/('arthur_joint_live_'+kind+'_v3.py');dst=src.with_name(src.name.replace('_v3.py','_v4.py'));assert not dst.exists()
  s=src.read_text().replace('arthur_joint_live_build_v3','arthur_joint_live_build_v4').replace('arthur_joint_live_controls_v3','arthur_joint_live_controls_v4').replace('arthur_joint_live_lifecycle_v3','arthur_joint_live_lifecycle_v4').replace('arthur_joint_live_isr_v3','arthur_joint_live_isr_v4')
  for a,z in [('constructor-Main-controls-v3.json','constructor-Main-controls-v4.json'),('lifecycle-vectors-v3.json','lifecycle-vectors-v4.json'),('actual-live-ISR-v3.json','actual-live-ISR-v4.json'),('foreign-Main-v3.json','foreign-Main-v4.json'),('presentation-foreign-NMI-v3.json','presentation-foreign-NMI-v4.json')]:s=s.replace(a,z)
  dst.write_text(s,newline='\n')
if __name__=='__main__':main()
