"""Retain v5 unresolved-private-export negative; add genuine zero-byte export."""
from pathlib import Path
import json,subprocess
import arthur_joint_live_build_v5 as B
O=B.O;N=B.N
def main():
 assert not(O/'linked-layout.json').exists();prior=json.loads((O/'commands.json').read_text());assert prior[-1]['returncode']!=0 and "Unresolved external 'FmResolve'"in prior[-1]['stderr']
 p=N/'src/full_roster_menu.s';s=p.read_text();s='.export FmResolve\n'+s;p.write_text(s,newline='\n')
 commands=[prior[0]['command'],prior[-1]['command']];logs=[]
 for cmd in commands:
  for flag in ['-o','-Ln','-m','--create-full-dep']:
   if flag in cmd:assert Path(cmd[cmd.index(flag)+1]).resolve().is_relative_to(N.resolve()),cmd
  for x in cmd:
   if x.startswith('--dbgfile,'):assert Path(x.split(',',1)[1]).resolve().is_relative_to(N.resolve())
  r=subprocess.run(cmd,cwd=N,capture_output=True,text=True);logs.append(dict(command=cmd,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr));(O/'commands-v6.json').write_text(json.dumps(logs,indent=2)+'\n');assert r.returncode==0,r.stderr
 B.B.B.B.B.B.mirror(B.R,N/'candidate.nes');b=B.B.B.B.B.B.scoped_load(N/'candidate.nes');sizes={s['name'].strip('"'):int(s['size'],0)for s in b['segs'].values()}
 assert sizes['CHARACTER_HOST_UNION']==2590 and sizes['GIMMICK_COMMON_NMI']==512 and sizes['AR_GEN_CONSTRUCTOR']==105
 d=dict(native=False,parent=B.sha(B.J/'candidate.nes'),candidate=B.sha(N/'candidate.nes'),sizes=sizes,retained_link_negative=B.sha(O/'commands.json'))
 (O/'linked-layout.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(candidate=d['candidate'],common512=512,constructor=105)))
if __name__=='__main__':main()
