"""Actual full native DrawAll consumes source FF body0/extra chunks, no hooks."""
from pathlib import Path
import itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import ff_joint_actual_main_v2 as S
import ff_host_pickups_vectors_v2 as V
from check_tmnt_render_oa import address,location
O=R/'build/ff-joint-full-render-v2';H=S.H;H.O=O/'joint';sha=S.sha

def point(b,n):return(address(b,n),((location(b,n)-16)//8192)|128)
def find(b,end):
    names=[n for n in b['syms']if n==end or n.endswith('::'+end)]
    assert len(names)==1,(end,names);return names[0]
def bodypage(m):return H.get(m,'CurrentCHRBank')+256*(m[H.address(m.bundle,'X5ChrMode')]&3)

def runframe(m,b,skip):
    names=['FwHostGraphics','FwHostDrawShots','MetaspriteRenderLoop','RosterProjectileOamReady',
           'ExpandedDrawShots','RosterDrawShots',find(b,'PlayerBankReady'),find(b,'InitObjectLoop')]
    points={point(b,n):n for n in names};phases=[];reservation=None;reserve_end=None;bodycommit=None
    def observe(mem,c,i):
        nonlocal reservation,reserve_end,bodycommit
        tag=mem.rawtags[(c.pc-0x8000)//8192]if c.pc>=0x8000 else -1
        key=(c.pc,tag)
        if key not in points:return
        name=points[key];phases.append(name)
        if name=='RosterProjectileOamReady':
            ptr=H.get(mem,'SmPosePtr')+256*mem[H.address(b,'SmPosePtr')+1]
            assert ptr==H.address(b,'FfRenderBuffer')
            header=mem[ptr];assert header in[16,20,24,28,32],('actual body header',header)
            offset=H.get(mem,'CurrentOAMOffset');assert offset<=220-header
            reservation=dict(header=header,extra_end=offset,pointer=ptr,page=bodypage(mem),
              expected_page=756+H.get(mem,'FfRenderPage'),source_record=list(mem[ptr:ptr+header+1]))
            assert reservation['page']==reservation['expected_page']
        if name.endswith('InitObjectLoop')and reservation is not None and reserve_end is None:
            reserve_end=H.get(mem,'CurrentOAMOffset')
            assert reserve_end==reservation['extra_end']+reservation['header'],'native body reservation changed'
        if name.endswith('PlayerBankReady'):
            expected=756+H.get(mem,'FfRenderPage')
            assert c.a==H.get(mem,'SmChrBank')==expected&255
            bodycommit=dict(A=c.a,page=bodypage(mem),expected=expected)
    H.put(m,ShouldSkipDrawSprites=skip,NmiDisable=255,VRAM_Buffer1_Offset=0)
    c,low=S.invoke_main(m,observe)
    if skip:
        assert phases.count('FwHostDrawShots')==0 and reservation is None
    else:
        assert phases.count('FwHostGraphics')==1 and phases.count('FwHostDrawShots')==1,phases
        assert phases.index('FwHostGraphics')<phases.index('FwHostDrawShots')<phases.index('RosterProjectileOamReady'),phases
        assert reservation is not None and reserve_end is not None and bodycommit is not None
        assert phases.count('MetaspriteRenderLoop')>0 and not any(phases.count(n)for n in['ExpandedDrawShots','RosterDrawShots'])
        assert H.get(m,'RgOamUsed')<=252 and H.get(m,'RgOamUsed')%4==0
        assert bodypage(m)==reservation['expected_page']
        assert H.get(m,'PlayerChrBank')==H.get(m,'SmChrBank')==reservation['expected_page']&255
        # Genuine normal NMI commits that final native software publication.
        cpu=H.NesMPU(memory=m,pc=0x5b00);cpu.a=91;cpu.x=7;cpu.y=133;cpu.p=0x30;cpu.sp=224
        isr=V.interrupt(m,cpu,'NMI')
        assert m.chr_latches[0]==reservation['expected_page'],('actual normalNMI bodyCHR',m.chr_latches[0],reservation)
        assert m.upper==0
    H.exact(m)
    return dict(CPU=c.processorCycles,minimum_SP=low,phases=phases,reservation=reservation,native_reserve_end=reserve_end,
       bodycommit=bodycommit,actual_oam_used=H.get(m,'RgOamUsed'),normal_NMI_body_page=m.chr_latches[0]if not skip else None)

def main():
    out=O/'actual-full-render-main-v1.json';assert not out.exists();p=dict(passed=False,native=False,admitted=False,
       actual_sourcecart=True,observer_changes_no_PC_registers_or_SMC=True,legal_offline_initial_tiers_not_earned_claim=True,rows=[])
    try:
        h=json.loads((O/'source-closure.json').read_text())
        for f,s in h['bindings'].items():assert sha(f)==s,f
        b=H.C.qualified(H.O/'candidate.nes')
        for variant,tier,face,off,skip in itertools.product(range(4),range(3),[1,2],[0,1],[0,1]):
            m=S.setup(b);H.put(m,FfVariant=variant,FfPower=tier,FfEarned=tier,PlayerFacingDir=face,
              PlayerOutlinesOff=off,SavedJoypadBits=0,A_B_Buttons=0,Left_Right_Buttons=0)
            p['rows'].append(dict(variant=variant,tier=tier,face=face,outlines_off=off,skip=skip,**runframe(m,b,skip)))
        p['passed']=True
    except Exception as e:p.update(error=repr(e),traceback=traceback.format_exc())
    p['bindings']={str(f.resolve()):sha(f)for f in[Path(__file__),Path(S.__file__),Path(V.__file__),O/'source-closure.json',H.O/'candidate.nes',H.O/'candidate.dbg']}
    target=out if p['passed']else O/'actual-full-render-main-negative-v1.json';assert not target.exists();target.write_text(json.dumps(p,indent=2)+'\n',newline='\n')
    print(json.dumps(dict(passed=p['passed'],rows=len(p['rows']),error=p.get('error'),path=str(target))),flush=True);assert p['passed']

if __name__=='__main__':main()
