"""Real visible-menu fresh then actual forced-blank InitScreen and live Main."""
from pathlib import Path
import json,traceback,itertools
import arthur_joint_live_build_v4 as B
import arthur_joint_live_controls_v3 as V
import arthur_joint_live_lifecycle_v3 as L
import arthur_joint_live_isr_v3 as I
from verify_native_relocation import NesMPU
A=V.A;O=B.O;N=B.N
def menu_fresh(b):
 q=V.V.seed(b);q.put(OperMode=0,DisableScreenFlag=0,Mirror_PPUMASK=24,FamilyMainCommit=1,ArHostReady=167)
 A.call(q,'MaaFresh');return q
def enter(q):
 q.put(OperMode=1,DisableScreenFlag=1,Mirror_PPUMASK=0,FamilyMainCommit=1,NmiDisable=255,ScreenRoutineTask=0,VRAM_Buffer1_Offset=0)
 return A.call(q,'InitScreen')
def main():
 out=O/'real-boundary-controls-v4.json';assert not out.exists();d=dict(passed=False,native=False,checks={})
 try:
  b=A.scoped_load(N/'candidate.nes');q=menu_fresh(b)
  assert q.get('ArHostReady')==0 and not q.m.ppu_reads and not any(q.m.ram[2]),'visible title must reset without PPU load'
  assert not any(q.m[A.address(b,'ArProfileStart'):A.address(b,'ArProfileEnd')])
  d['checks']['actual_MaaFresh_NrFreshGameInit_visible_title_no_loader']=dict(ready=0,PPU_reads=0)
  q.put(OperMode=1,DisableScreenFlag=1,Mirror_PPUMASK=0,FamilyMainCommit=1,NmiDisable=255,ScreenRoutineTask=0,VRAM_Buffer1_Offset=0)
  old=NesMPU.step;events=[];last=[];sig=L.signature(b)
  def step(c):
   raw=q.m.rawtags[(c.pc-32768)//8192]if c.pc>=32768 else-1;last.append([raw,c.pc]);del last[:-32]
   if q.m[c.pc]==141 and q.m[c.pc+1]+256*q.m[c.pc+2]==A.address(b,'ArHostReady')and c.a==167:
    assert bytes(q.m.ram[2][8160:8176])==sig;events.append([raw,c.pc,q.m.ppu_reads])
   old(c)
  NesMPU.step=step
  try:c,tr,mn=A.call(q,'InitScreen')
  finally:NesMPU.step=old
  assert q.get('ArHostReady')==167 and bytes(q.m.ram[2][8160:8176])==sig
  assert len(events)==1 and q.m.ppu_reads==7485
  assert tr.count(A.point(b,'MoveAllSpritesOffscreen'))==1 and A.point(b,'FwSceneInit')in tr and A.point(b,'ArGenSceneLoad')in tr
  d['checks']['actual_InitScreen_original_Move_FF_then_Arthur_ready_last']=dict(CPU=c.processorCycles,minSP=mn,ready_publications=events,original_Move_exactly_once=True)
  rows=[]
  for age in range(24):
   keys=1|(128 if 4<=age<12 else 0);q.put(SavedJoypadBits=keys,SavedJoypad1Bits=keys,ArHostPad=keys,ArHostDue=int(age%3==0),NmiDisable=255,FamilyMainCommit=1,VRAM_Buffer1_Offset=0)
   c,tr,mn=A.M.run_linked(q,'GameLoop')[:3]
   assert A.point(b,'ArHostMovement')in tr and A.point(b,'ArHostDrawAll')in tr and q.get('ArHostReady')==167
   rows.append([age,c.processorCycles,mn,q.get('Player_X_Position'),q.get('Player_Y_Position')])
  d['checks']['subsequent_complete_Main']=dict(rows=rows,updates=len(rows))
  # Reentering screen initialization is warm and retains actual earned state.
  A.owned(q,'ArHostNativePickup',a=6);A.owned(q,'ArHostSave');assert q.get('ArR_053A')==68
  reads=q.m.ppu_reads;q.put(AreaNumber=1);enter(q);assert q.m.ppu_reads==reads and q.get('ArR_053A')==68 and q.get('ArHostReady')==167
  d['checks']['warm_area_InitScreen_no_reload_earned_weapon_preserved']=True
  # Blank eligibility remains the genuine loader's contract.
  negatives=[]
  for name,values in [('visible',dict(Mirror_PPUMASK=24)),('NMI_active',dict(NmiDisable=0)),('no_disable',dict(DisableScreenFlag=0)),('no_busy',dict(FamilyMainCommit=0)),('title',dict(OperMode=0))]:
   z=menu_fresh(b);z.put(OperMode=1,DisableScreenFlag=1,Mirror_PPUMASK=0,FamilyMainCommit=1,NmiDisable=255,ScreenRoutineTask=0);z.put(**values)
   A.call(z,'InitScreen');assert z.get('ArHostReady')==0 and z.m.ppu_reads==0 and not any(z.m.ram[2]),('bad boundary loaded',name)
   negatives.append(name)
  d['checks']['actual_InitScreen_invalid_boundaries_stay_unready']=negatives
  d.update(passed=True,limits=['Actual source-boundary CPU execution; the frontend pending guard is intentionally unchanged, so no controller/native entry or admission claim.','Original native scene/PPU timing and severe lag require a separately granted native run.'])
 except Exception as e:d.update(error=repr(e),traceback=traceback.format_exc(),last_trace=locals().get('last',[]))
 d['bindings']={str(p.resolve()):B.sha(p)for p in [Path(__file__),N/'candidate.nes',N/'candidate.dbg',O/'linked-layout.json']}
 out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps({k:v for k,v in d.items()if k not in ['bindings','traceback','last_trace']}));assert d['passed']
if __name__=='__main__':main()
