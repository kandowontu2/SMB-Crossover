"""Retire the old Arthur owner before BOTH ready and pending frontend paths."""
from pathlib import Path
import json,shutil,subprocess
import arthur_joint_live_build_v4 as B
R=B.R;P=B.O;J=B.N;O=R/'build/arthur-joint-live-v5';N=O/'joint';sha=B.sha
def rewrite(s):
 for old in [J,R/'build/arthur-joint-live-v3/joint',R/'build/arthur-joint-live-v2/joint',R/'build/arthur-joint-live-v1/joint',R/'build/arthur-joint-busy-guards-v1/joint',R/'build/ff-arthur-joint-transport-v3/joint']:
  for a in [str(old),old.as_posix()]:s=s.replace(a,str(N))
 return s
def main():
 assert not O.exists();assert sha(J/'candidate.nes')=='d014c049a26db032ef662310c93b88ae33db1929927516ce68e23c046b705eec'
 bound={str(p.resolve()):sha(p)for p in P.rglob('*')if p.is_file()};O.mkdir();shutil.copytree(J,N)
 for p in N.rglob('*'):
  if p.is_file()and p.suffix in ['.s','.inc','.cfg','.dep']:
   s=p.read_text();t=rewrite(s)
   if s!=t:p.write_text(t,newline='\n')
 p=N/'union.s';s=p.read_text();assert s.count('farcall ArGenResolve')==1;s=s.replace('farcall ArGenResolve','farcall CmHostResolveCharacter');p.write_text(s,newline='\n')
 p=N/'src/character_select.s';s=p.read_text();needle='  farcall FmResolve,jmp';assert s.count(needle)==1;s='.import ArGenResolve\n'+s.replace(needle,'  farcall ArGenResolve,jmp');p.write_text(s,newline='\n')
 p=N/'generation-shared.s';s=p.read_text();assert s.count('GenTail CmHostResolveCharacter')==1;s='.import FmResolve\n'+s.replace('GenTail CmHostResolveCharacter','GenTail FmResolve');p.write_text(s,newline='\n')
 cc=str(R/'tools/Windows/cc65/bin/ca65.exe');commands=[]
 for name in ['main','union']:commands.append([rewrite(x)for x in json.loads((J/(name+'-build.json')).read_text())['command']])
 commands.append([cc,'-g','--cpu','6502x','-o',str(N/'generation-shared.o'),str(N/'generation-shared.s')]);commands.append([rewrite(x)for x in json.loads((P/'commands.json').read_text())[-1]['command']]);logs=[]
 for cmd in commands:
  for flag in ['-o','-Ln','-m','--create-full-dep']:
   if flag in cmd:assert Path(cmd[cmd.index(flag)+1]).resolve().is_relative_to(N.resolve()),cmd
  for x in cmd:
   if x.startswith('--dbgfile,'):assert Path(x.split(',',1)[1]).resolve().is_relative_to(N.resolve())
  r=subprocess.run(cmd,cwd=N,capture_output=True,text=True);logs.append(dict(command=cmd,returncode=r.returncode,stdout=r.stdout,stderr=r.stderr));(O/'commands.json').write_text(json.dumps(logs,indent=2)+'\n');assert r.returncode==0,r.stderr
 B.B.B.B.B.mirror(R,N/'candidate.nes');b=B.B.B.B.B.scoped_load(N/'candidate.nes');sizes={s['name'].strip('"'):int(s['size'],0)for s in b['segs'].values()}
 assert sizes['CHARACTER_HOST_UNION']==2590 and sizes['GIMMICK_COMMON_NMI']==512 and sizes['AR_GEN_CONSTRUCTOR']==105
 for p,h in bound.items():assert sha(p)==h,p
 d=dict(native=False,parent=sha(J/'candidate.nes'),candidate=sha(N/'candidate.nes'),sizes=sizes,predecessor_bindings=bound)
 (O/'linked-layout.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(candidate=d['candidate'],common512=512,constructor=105)))
if __name__=='__main__':main()
