"""Retain actual constructor carry/readiness failure, no source mutation."""
import json
import arthur_joint_live_controls_v1 as V
from verify_native_relocation import NesMPU
A=V.A
def main():
 b=A.scoped_load(V.N/'candidate.nes');q=V.seed(b)
 names=['ArCacheLoad::Cleanup','ArCacheStreamDone','ArCacheLoad::NotReady','ArCacheLoad::Rejected','ArCacheEnsure::Restore','ArGenConstruct::Done','ArCachePublishCheckpoint','ArHostEnsure','ArCacheEnsure']
 points={A.point(b,n):n for n in names}
 bank,pc=A.point(b,'ArGenConstruct');points[(bank,pc+75)]='constructor offset75'
 rows=[];old=NesMPU.step
 def step(c):
  raw=q.m.rawtags[(c.pc-32768)//8192] if c.pc>=32768 else-1
  tag=(raw&127,c.pc)
  if tag in points or (raw&127==bank and pc<=c.pc<pc+96):
   rows.append(dict(entry=points.get(tag,''),raw=raw,pc=c.pc,opcode=q.m[c.pc],a=c.a,x=c.x,y=c.y,p=c.p,sp=c.sp,header=q.get('ArDrawHeader'),temp=q.get('ArTemp'),ready=q.get('ArHostReady'),maps=q.m.rawtags[:]))
  old(c)
 NesMPU.step=step
 try:c,tr,mn=A.call(q,'NrFreshGameInit')
 finally:NesMPU.step=old
 d=dict(native=False,candidate=V.B.sha(V.N/'candidate.nes'),ready=q.get('ArHostReady'),cookie=bytes(q.m.ram[2][8160:8176]).hex(),rows=rows)
 out=V.O/'constructor-carry-diagnosis-v1.json';assert not out.exists();out.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d))
if __name__=='__main__':main()
