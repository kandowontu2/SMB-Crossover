"""Measure owned-but-unused ranges. This does not release or allocate them."""
from pathlib import Path
import sys,json,hashlib,csv,collections
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(Path(__file__).parent))
from check_tmnt_render_oa import load
O=R/'build/quickman-wram-palette-v6'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def save(n,d):(O/n).write_text(json.dumps(d,indent=2)+'\n',newline='\n')
def main():
 b=load(O/'candidate.nes');raw=b['raw'];lease=json.loads((O/'lease-copy.json').read_text())['Quick_Man']['PRG'];owned=[]
 for s in b['segs'].values():
  name=s['name'].strip('"')
  if name.startswith('QP_')or name in ['QW_ROUTER','QW_LOADER']:
   at=int(s['ooffs'],0);owned.append(dict(segment=name,bank=(at-16)//8192,start=(at-16)%8192,end=(at-16)%8192+int(s['size'],0)))
 free=[];pages=[]
 for l in lease:
  bank=l['bank'];used=set()
  for s in owned:
   if s['bank']==bank:used.update(range(s['start'],s['end']))
  if bank==93:used.update(range(0xfa7,0xfe7))
  start=None
  for at in range(l['start'],l['end']+1):
   okay=at<l['end']and at not in used
   if okay and start is None:start=at
   if start is not None and not okay:
    a=16+bank*8192+start;z=16+bank*8192+at
    assert raw[a:z]==bytes([255])*(z-a)
    syms=[];markers=[]
    for n,v in b['syms'].items():
     if 'seg'not in v:continue
     seg=b['segs'][v['seg']]
     if 'ooffs'not in seg:continue
     physical=int(seg['ooffs'],0)+int(v.get('val','0'),0)-int(seg['start'],0)
     if a<=physical<z:
      if int(v['val'],0)==int(seg['start'],0)+int(seg['size'],0):markers.append(n)
      else:syms.append(n)
    assert not syms,(bank,start,at,syms[:5])
    free.append(dict(bank=bank,start=start,end=at,bytes=at-start,sha256=hashlib.sha256(raw[a:z]).hexdigest(),fill_FF=True,placed_symbol_or_export_count=0,zero_size_preceding_segment_end_markers=markers))
    for p in range((start+255)&~255,at-255,256):pages.append(dict(bank=bank,start=p,end=p+256))
    start=None
 preference=[34,84,81,32,33,66,35,20,93,82,98,70]
 pages.sort(key=lambda x:(preference.index(x['bank'])if x['bank']in preference else len(preference),x['bank'],x['start']))
 chosen=pages[:10];assert len(chosen)==10
 receipt=dict(status='CONDITIONAL_REVIEW_ONLY_NO_RELEASE',ROM_sha256=sha(O/'candidate.nes'),DBG_sha256=sha(O/'candidate.dbg'),lease_sha256=sha(O/'lease-copy.json'),permanent_union_exclusion=dict(bank=93,start=0xfa7,end=0xfe7),actual_current_ROM_used=sum(s['end']-s['start']for s in owned),retained_lease=10060,measured_FF_unused=sum(x['bytes']for x in free),allocated_source_segments=owned,unused_FF_intervals=free,all_full_256byte_page_options=pages,conditional_ten_page_proposal=chosen,conditional_bytes=2560,remaining_measured_unused_after_proposal=sum(x['bytes']for x in free)-2560,required_growth_preserved='All remaining A70 router, C82 loader and C98 cold-portrait bank headroom retained by chosen ten pages.',reference_scope='Actual ld65 segment and symbol/export closure has no placed label in free intervals. One zero-size prior-segment end marker is separately recorded. Exact source-linked bytes are FF. Existing frozen lease ownership is the authority, not fill alone. No universal claim about arbitrary numeric operands.',future_Quick_scope='Original CX audio/driver/state and active cadence remain unqualified and unmeasured for additional PRG need. Proposal is conditional; no claim future audio fits the remaining headroom.',bindings={str(p):sha(p)for p in[O/'candidate.nes',O/'candidate.dbg',O/'wram.cfg',O/'lease-copy.json',Path(__file__)]})
 save('unused-PRG-review.json',receipt)
 rows=list(csv.DictReader((R/'build/quickman-wram-native-v2/frames.csv').open()));rows=[x for x in rows if x['phase']=='game']
 changes={k:dict(collections.Counter(int(b[k])-int(a[k])for a,b in zip(rows,rows[1:])))for k in ['ticks','mains','NmiSkipped']}
 save('prior-native-cadence-negative.json',dict(status='RETAINED_NATIVE_GRAPHICAL_FAIL_CADENCE_ANALYSIS',ROM_sha256='eed0ac40e6cffbf8877f504dfde2cc5c04c85f10038192a7d16d5c3bb24dfeaa',first_frame=int(rows[0]['frame']),last_frame=int(rows[-1]['frame']),observed_samples=len(rows),sample_intervals=len(rows)-1,source_tick_difference=int(rows[-1]['ticks'])-int(rows[0]['ticks']),main_entry_difference=int(rows[-1]['mains'])-int(rows[0]['mains']),lag_NMI_difference=int(rows[-1]['NmiSkipped'])-int(rows[0]['NmiSkipped']),per_interval_deltas=changes,source_tick_semantics='Entry counters sampled asynchronously at endFrame; one interval sees2,64 see0. Total168 includes pre-game ticks and must not be compared with220 gameplay frames.',timing_scope='Old fixture has no per-gameplay Main cycle samples.661853 max includes forcedblank loader and is excluded from active timing conclusions.',native_60Hz_qualified=False,frames_csv_sha256=sha(R/'build/quickman-wram-native-v2/frames.csv')))
 print(json.dumps({k:receipt[k]for k in ['actual_current_ROM_used','measured_FF_unused','conditional_ten_page_proposal','remaining_measured_unused_after_proposal']},indent=2))
if __name__=='__main__':main()
