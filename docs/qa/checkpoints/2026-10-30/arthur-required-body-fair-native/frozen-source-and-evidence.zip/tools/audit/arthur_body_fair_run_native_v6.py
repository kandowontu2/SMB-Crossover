"""ONE explicit root-granted fair3 smoke; refuses output reuse, verifies closure."""
import hashlib,json,os,sys,zipfile
import arthur_body_fair_main_v5 as F
A=F.A;O=F.O;R=F.R;N=O/'native/cold-fair-smoke-v6'
def main():
    assert sys.argv[1:]==['--launch'],'Only explicit root grant permits --launch.'
    assert not N.exists(),'Retain prior output; no automatic retry.'
    prepared=O/'native-prepared-v6.json';p=json.loads(prepared.read_text())
    assert A.sha(prepared)=='f6380175eb1e90a0baa67b2d36a5599d315332942d0cf219bdd387268d7a9f7e'
    assert p['ROM_sha256']==A.sha(O/'candidate.nes')=='09237b6f1b88b50d9c3ba054092af36591daa435d43eb83bf21ed08ca856d671'
    h=json.loads((O/'handoff.json').read_text());closure=json.loads((O/'source-closure.json').read_text())
    def verify():
        for path,d in p['bindings'].items():assert A.sha(path)==d,(path,'prepared input changed')
        for path,d in h['bindings'].items():assert A.sha(path)==d,(path,'frozen input changed')
        with zipfile.ZipFile(O/'private-source-cpu.zip')as z:
            for path,d in closure['files'].items():
                assert hashlib.sha256(z.read(path)).hexdigest()==d and A.sha(R/path)==d,(path,'source/archive member changed')
    verify();N.parent.mkdir(exist_ok=True)
    meta=dict(passed=True,ROM_sha256=p['ROM_sha256'],prepared_sha256=A.sha(prepared),source_handoff_sha256=A.sha(O/'handoff.json'),source_members_verified=len(closure['files']),runner_sha256=A.sha(__file__),options=['--doNotSaveSettings','--nes.removeSpriteLimit=false','--nes.ramPowerOnState=AllZeros','--nes.randomizeCpuPpuAlignment=false','--nes.randomizeMapperPowerOnState=false'],byte_cap=p['run_byte_cap'],file_cap=64,timeout=60)
    (O/'native-preflight-v6.json').write_text(json.dumps(meta,indent=2)+'\n')
    os.environ['SMB_RUN_OUTPUT']=str(N.resolve());sys.path.insert(0,str(R/'tools'))
    from audit import capture_budget
    capture_budget.RUN_BYTES=p['run_byte_cap'];capture_budget.PAYLOAD_BYTES=p['run_byte_cap']-1_000_000
    from run_mesen import run
    rc=run(O/'native-driver-v6.lua',O/'candidate.nes',timeout=60,emulator_options=meta['options'])
    verify();(O/'native-postflight-v6.json').write_text(json.dumps(dict(**meta,exit_code=rc,all_prepared_and_frozen_source_bindings_unchanged=True),indent=2)+'\n')
    print(json.dumps(dict(native_terminal=True,exit_code=rc,ROM_sha256=p['ROM_sha256'],output=str(N.resolve()),pre_post_bindings_pass=True)),flush=True)
    raise SystemExit(rc)
if __name__=='__main__':main()
