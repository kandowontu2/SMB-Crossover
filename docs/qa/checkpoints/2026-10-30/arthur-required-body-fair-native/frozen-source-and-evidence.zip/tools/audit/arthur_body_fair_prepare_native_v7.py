"""Retain v6 reservation negative; prepare exact smaller guard before import."""
from pathlib import Path
import difflib,inspect,json
import arthur_body_fair_main_v5 as F
import arthur_body_fair_budget_v7 as Q
A=F.A;O=F.O;R=F.R
def main():
    out=O/'native-prepared-v7.json';assert not out.exists()
    old=O/'native-prepared-v6.json';p=json.loads(old.read_text());assert A.sha(old)=='f6380175eb1e90a0baa67b2d36a5599d315332942d0cf219bdd387268d7a9f7e'
    for path,d in p['bindings'].items():assert A.sha(path)==d
    assert not any((O/'native/cold-fair-smoke-v6').iterdir())
    negative=O/'native-preMesen-negative-v6.json'
    negative.write_text(json.dumps(dict(native=False,Mesen_launched=False,terminal_exit=1,first_failure='audit.capture_budget.CaptureBudgetExceeded: Capture reservation exceeds the per-run 2 GB / 64-file cap.',cause='Runner mutated RUN_BYTES after import; preflight reserved_bytes default remains original2000000000, exceeding new536870912. Guard correctly rejected beforePopen.',all_prepared_bindings_reverified=True,capture_directory_empty=True,bindings={str(q.resolve()):A.sha(q)for q in [old,O/'native-preflight-v6.json',R/'tools/audit/arthur_body_fair_run_native_v6.py']}),indent=2)+'\n')
    original=(R/'tools/audit/capture_budget.py').read_text();text=original.replace('RUN_BYTES = 2_000_000_000','RUN_BYTES = 536_870_912').replace('receipt = preflight(output)','receipt = preflight(output, reserved_bytes=RUN_BYTES, reserved_files=RUN_FILES)')
    source=O/'capture-budget-source-v7.py';source.write_text(text,newline='\n')
    patch=O/'native-budget-diff-v7.patch';patch.write_text(''.join(difflib.unified_diff(original.splitlines(True),text.splitlines(True),fromfile='immutable/tools/audit/capture_budget.py',tofile='private/capture-budget-source-v7.py')),newline='\n')
    budget=Q.load(source);before=budget.preflight(O/'native/cold-fair-smoke-v7',reserved_bytes=536870912,reserved_files=64)
    assert before['reserved_bytes']==before['run_byte_cap']==536870912 and before['reserved_files']==64
    probe=O/'native-budget-preflight-v7.json';probe.write_text(json.dumps(dict(passed=True,native=False,actual_API='preflight(output:Path, reserved_bytes:int=RUN_BYTES, reserved_files:int=RUN_FILES)',reserve_capture_API_present=hasattr(budget,'reserve_capture'),explicit_request='preflight(output, reserved_bytes=536870912, reserved_files=64)',signature=str(inspect.signature(budget.preflight)),result=before,public_capture_module_not_mutated=True),indent=2)+'\n')
    p.update(status='PREPARED_NOT_RUN_AWAITING_SEPARATE_ROOT_NATIVE_GRANT_V7',predecessor_prepared_sha256=A.sha(old),preflight_result_sha256=A.sha(probe),run_byte_cap=536870912,actual_dependency_API='Actual run_mesen.run function source unchanged except imported run_capped bound to isolated same-source stricter guard. Guard literal536870912 is set BEFORE module compile, _run_owned passes explicit536870912/64 reservation; no mutation of public guard/constants.',exact_CLI='python tools/audit/arthur_body_fair_run_native_v7.py --launch')
    paths=[Path(__file__),Path(Q.__file__),R/'tools/audit/arthur_body_fair_run_native_v7.py',old,negative,source,patch,probe]
    p['bindings'].update({str(q.resolve()):A.sha(q)for q in paths});out.write_text(json.dumps(p,indent=2)+'\n')
    print(json.dumps(dict(prepared_sha256=A.sha(out),ROM=p['ROM_sha256'],preflight=before)))
if __name__=='__main__':main()
