-- Passive exact source body-order + hardware8 observer; no input/RAM writes.
local rawA,rawC,goal,entry=0,0,nil,nil
local permutations,hardwareChecks,blackPixels,maxBody,frames=0,0,0,0,0
local romfile=assert(io.open(ARTHUR_FAIR_ROM,'rb'));local rom=romfile:read('*a');romfile:close()
local function r(n)return emu.read(assert(L[n],n),emu.memType.nesDebug)end
local function shadow()local a={}for i=0,255 do a[i+1]=emu.read(512+i,emu.memType.nesDebug)end;return a end
local function model(a,origin,n)
 local out,body,pos,source,holes={},{},{},{},{}
 for i=1,256 do out[i]=a[i]end
 for i=0,n-1 do local p=(origin+i)%64;pos[p]=true;for j=0,3 do body[#body+1]=a[p*4+j+1]end end
 for i=0,n-1 do if not pos[i]then source[#source+1]=i end end
 for i=0,n-1 do local p=(origin+i)%64;if p>=n then holes[#holes+1]=p end end
 assert(#source==#holes,'Exact permutation displaced-record partition')
 for i,p in ipairs(source)do for j=0,3 do out[holes[i]*4+j+1]=a[p*4+j+1]end end
 for i,v in ipairs(body)do out[i]=v end
 return out
end
local function receipt()
 local f=assert(io.open(OUTPUT..'fair-body-native.json','w'))
 f:write(string.format('{"passed":true,"ROM_sha256":"%s","actual_source_permutations":%d,"hardware_OAM_first8_checks":%d,"source_body_black_glyph_pixels_first8":%d,"maximum_body_records":%d,"normal_eight_sprite_limit":true,"script_RAM_writes":false,"scope":"Passive complete64record source permutation, actual DMA OAM and actual mapped-cartridge CHR/palette evaluation. Screenshot review still required; background priority can cover a legitimate sprite pixel. No cadence admission."}\n',ARTHUR_HOST_ROM_SHA256,permutations,hardwareChecks,blackPixels,maxBody));f:close()
end
emu.addMemoryCallback(function(_,v)rawC=v end,emu.callbackType.write,0x5116)
emu.addMemoryCallback(function(_,v)rawA=v end,emu.callbackType.write,0x5115)
emu.addMemoryCallback(function()
 if rawA==154 and r('SelectedCharacter')==32 then goal=nil end
end,emu.callbackType.exec,L.ArHostDraw)
emu.addMemoryCallback(function()
 if rawC~=2 then return end
 assert(r('SelectedCharacter')==32 and r('ArHostReady')==167,'Body priority only verified actual Arthur')
 local bytes=r('ArDrawPage');local origin=r('ArLayoutPtr')
 assert(bytes>0 and bytes<=44 and bytes%4==0 and origin%4==0,'Source body metadata bounded')
 assert(not entry,'No recursive body permutation')
 entry={before=shadow(),origin=origin//4,n=bytes//4}
end,emu.callbackType.exec,L.ArCacheBodyPriority)
emu.addMemoryCallback(function()
 if rawC~=2 then return end
 assert(entry,'Every body priority return has actual entry')
 local expected=model(entry.before,entry.origin,entry.n);local actual=shadow()
 for i=1,256 do assert(actual[i]==expected[i],'Actual complete64record body permutation byte '..i)end
 goal={n=entry.n,prefix={}}
 for i=1,entry.n*4 do goal.prefix[i]=actual[i]end
 maxBody=math.max(maxBody,entry.n);permutations=permutations+1;assert(permutations<=1200,'Finite body events')
 entry=nil
end,emu.callbackType.exec,ARTHUR_FAIR_PRIORITY_RETURN)
local dma=nil
emu.addMemoryCallback(function()
 if not goal or r('SelectedCharacter')~=32 or r('OperMode')~=1 or r('OperMode_Task')~=3 then return end
 local a=shadow()
 for i,v in ipairs(goal.prefix)do assert(a[i]==v,'Native actors/white expansion retain protected ordered body prefix')end
 local s=emu.getState();local banks={};for i=0,7 do banks[i]=assert(s['mapper.chrBanks'..i])end
 local palette={};for i=0,31 do palette[i]=emu.read(0x3f00+i,emu.memType.nesPpuDebug)end
 dma={n=goal.n,oam=a,banks=banks,palette=palette}
end,emu.callbackType.write,0x4014)
local function chr(at,banks)
 return assert(rom:byte(ARTHUR_FAIR_CHR_BASE+banks[at//1024]*1024+(at%1024)+1),'Actual carrier CHR byte')
end
emu.addEventCallback(function()
 frames=frames+1;assert(frames<=1200,'Passive1200frame bound')
 if not dma then return end
 local a=dma.oam
 for i=0,255 do assert(emu.read(i,emu.memType.nesSpriteRam)==a[i+1],'Actual DMA full64record OAM image '..i)end
 local occupancy,winners={},{}
 for i=0,63 do
  local y,t,attr,x=a[i*4+1],a[i*4+2],a[i*4+3],a[i*4+4]
  if y<240 then
   for row=0,15 do local sy=y+1+row
    if sy<240 then
     occupancy[sy]=(occupancy[sy]or 0)+1
     if i<dma.n then
      assert(occupancy[sy]<=8,'Complete protected Arthur body must fit genuine first8')
      local rr=attr&128~=0 and 15-row or row
      local at=(t&1)*4096+(t&254)*16+(rr>=8 and 16 or 0)+(rr%8)
      local lo,hi=chr(at,dma.banks),chr(at+8,dma.banks)
      for col=0,7 do local sx=x+col
       if sx<256 then
        local bit=attr&64~=0 and col or 7-col
        local pixel=((lo>>bit)&1)+2*((hi>>bit)&1)
        local key=sy*256+sx
        if pixel~=0 and winners[key]==nil then winners[key]=dma.palette[16+(attr&3)*4+pixel]end
       end
      end
     end
    end
   end
  end
 end
 for _,color in pairs(winners)do if color==15 then blackPixels=blackPixels+1 end end
 hardwareChecks=hardwareChecks+1;receipt()
end,emu.eventType.endFrame)
