"""Freeze approved exact native fairness smoke, retaining severe cadence hold."""
from pathlib import Path
import json,zipfile
import arthur_body_fair_main_v5 as F
A=F.A;R=F.R;O=F.O;P=F.P;N=O/'native/cold-fair-smoke-v7'
def main():
    out=O/'native-handoff-v7.json';assert not out.exists();h=A.sha(O/'candidate.nes')
    src=json.loads((O/'handoff.json').read_text());prep=json.loads((O/'native-prepared-v7.json').read_text());post=json.loads((O/'native-postflight-v7.json').read_text())
    assert h==src['candidate_sha256']==prep['ROM_sha256']==post['ROM_sha256'] and post['exit_code']==0 and post['all_prepared_and_frozen_source_bindings_unchanged']
    for d in [src,prep]:
        for p,digest in d['bindings'].items():assert A.sha(p)==digest,(p,'changed frozen input')
    result=json.loads((N/'result.json').read_text());timing=json.loads((N/'timing.json').read_text());body=json.loads((N/'fair-body-native.json').read_text());cap=json.loads((N/'capture-budget.json').read_text());cache=json.loads((N/'cache-native.json').read_text())
    assert cap['returncode']==0 and not cap['violations'] and result['passed']and body['passed']and cache['passed']
    assert cap['run_byte_cap']==cap['reserved_bytes']==536870912 and cap['reserved_files']==64
    assert body['actual_source_permutations']>50 and body['hardware_OAM_first8_checks']>=400 and body['source_body_black_glyph_pixels_first8']>0 and body['maximum_body_records']==11
    assert result['frames']<=1200 and result['controlled_game_frames']==400 and result['screenshots']==6 and not result['RAM_writes']and result['active_ppu_writes']==0
    files=sorted(p for p in N.iterdir()if p.is_file());assert len(files)<=64 and len([p for p in files if p.suffix=='.png'])==6
    baseline=P/'native/cold-render-smoke-v1';old=json.loads((baseline/'timing.json').read_text());oldresult=json.loads((baseline/'result.json').read_text())
    assert(N/'actual-cache.bin').read_bytes()==(baseline/'actual-cache.bin').read_bytes() and(N/'actual-cache.bin').stat().st_size==6130
    b=A.scoped_load(O/'candidate.nes');code=b['raw'][A.location(b,'ArCacheEmit'):A.location(b,'ArCacheExecEnd')]
    assert len(code)==550 and(N/'actual-cache-code.bin').read_bytes()==code
    assert(N/'actual-cache-cookie.bin').read_bytes()==bytes.fromhex(json.loads((O/'cache-final-link-proof.json').read_text())['signature'])
    comparison=dict(same_base_controller_source=True,physical_game_frames=400,baseline_ROM_sha256=old['ROM_sha256'],lag_before=old['lag_NMIs'],lag_after=timing['lag_NMIs'],source_ticks_before=old['source_steps'],source_ticks_after=timing['source_steps'],source_clocks_before=old['clock_calls'],source_clocks_after=timing['clock_calls'],draws_before=old['draws'],draws_after=timing['draws'],foreground_mean_before=old['timing']['foreground']['mean'],foreground_mean_after=timing['timing']['foreground']['mean'],foreground_mean_delta=round(timing['timing']['foreground']['mean']-old['timing']['foreground']['mean'],3),foreground_max_before=old['timing']['foreground']['max'],foreground_max_after=timing['timing']['foreground']['max'],right_pixels_before=oldresult['right_pixels'],right_pixels_after=result['right_pixels'],immediate_game_start_capture_identical_to_baseline=A.sha(N/'game-start.png')==A.sha(baseline/'game-start.png'))
    files += [O/n for n in ['native-prepared-v7.json','native-preflight-v7.json','native-postflight-v7.json','native-driver-v6.lua','native-preMesen-negative-v6.json','native-prepared-v6.json','native-preflight-v6.json','native-budget-diff-v7.patch','native-budget-preflight-v7.json','capture-budget-source-v7.py','native-review-whole-frames-v7.png']]
    files += [R/'tools/audit'/n for n in ['arthur_body_fair_prepare_native_v5.py','arthur_body_fair_prepare_native_v6.py','arthur_body_fair_prepare_native_v7.py','arthur_body_fair_native_v5.lua','arthur_body_fair_native_v6.lua','arthur_body_fair_run_native_v6.py','arthur_body_fair_run_native_v7.py','arthur_body_fair_budget_v7.py','arthur_body_fair_native_freeze_v7.py']]
    files += [R/'build/arthur-host-cache-v1/cache-native-source-v2.lua',P/'native-handoff-v1.json']+[baseline/n for n in ['result.json','timing.json','cache-native.json','game-start.png']]
    archive=O/'native-supplement-v7.zip'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9)as z:
        for p in files:z.write(p,p.relative_to(R).as_posix())
    d=dict(status='PRIVATE_FAIR_BODY_NATIVE_SMOKE_PASS_PERFORMANCE_AND_JOINT_ADMISSION_HOLD',candidate_sha256=h,source_handoff_sha256=A.sha(O/'handoff.json'),source_archive_sha256=src['source_archive_sha256'],native_archive_sha256=A.sha(archive),native_archive_bytes=archive.stat().st_size,process_exit=0,normal_eight_sprite_limit=True,AllZeros=True,script_RAM_writes=False,all_prepared_and_frozen_source_bindings_verified=True,semantic_result=result,actual_body_hardware=body,timing=timing,comparison=comparison,visual_review='Viewed all6 untouched wholeframes through derived2x3sheet. Jump/lance/final show black body contours above blue world/native floor/HUD; menu retains inherited cyan band. Game-start captures immediateengine8 entry beforefirstcompletedbody draw; comparison records whether byte-exact to2846.',limits=['216lagNMIs/400physicalframes and +521.715meanforegroundCPU vs2846 remain severe; no performancefix/60Hz/sharedinstall claim.','Native defaultShadowsOff only; bothsettings/all47poses/3area roles/nativeactor crowding are CPU/source-hardware8 proofs, not native allareas/options/campaign.','Tail first-priority opportunities are sourceCPU proven stable cycles; rows occupied by8bodyrecords physically have no nonplayer sprite capacity.','Current joint fast-v4 A79 overlaps standalonecommon; genuine source integration/resource review required before sharedcandidate. NoRAM1 grant/adoption.','No earnedallweapons/upgrades/Hard/sourceaudio/campaign clear. Pre-Mesen v6storage-default failure is retained; v7 only tightens actual guard reservation before import.'])
    d['bindings']={str(p.resolve()):A.sha(p)for p in files+[O/'candidate.nes',O/'candidate.dbg',O/'handoff.json',O/'source-proof-v5.json',O/'cache-final-link-proof.json',archive]};out.write_text(json.dumps(d,indent=2)+'\n')
    print(json.dumps(dict(native_handoff_sha256=A.sha(out),ROM=h,native_archive_sha256=A.sha(archive),comparison=comparison)))
if __name__=='__main__':main()
