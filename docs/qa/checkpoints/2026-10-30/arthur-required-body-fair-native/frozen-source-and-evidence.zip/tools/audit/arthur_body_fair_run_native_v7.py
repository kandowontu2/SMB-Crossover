"""ONE separately root-granted v7 budget-fixture retry, exact fair3 ROM/Lua."""
import hashlib,json,os,sys,zipfile
import arthur_body_fair_main_v5 as F
import arthur_body_fair_budget_v7 as Q
A=F.A;O=F.O;R=F.R;N=O/'native/cold-fair-smoke-v7'
def main():
    assert sys.argv[1:]==['--launch'],'Only explicit root grant permits --launch.'
    assert not N.exists(),'Retain prior output; no automatic retry.'
    prepared=O/'native-prepared-v7.json';p=json.loads(prepared.read_text())
    assert p['predecessor_prepared_sha256']=='f6380175eb1e90a0baa67b2d36a5599d315332942d0cf219bdd387268d7a9f7e'
    assert p['ROM_sha256']==A.sha(O/'candidate.nes')=='09237b6f1b88b50d9c3ba054092af36591daa435d43eb83bf21ed08ca856d671'
    h=json.loads((O/'handoff.json').read_text());closure=json.loads((O/'source-closure.json').read_text())
    def verify():
        for path,d in p['bindings'].items():assert A.sha(path)==d,(path,'prepared input changed')
        for path,d in h['bindings'].items():assert A.sha(path)==d,(path,'frozen input changed')
        with zipfile.ZipFile(O/'private-source-cpu.zip')as z:
            for path,d in closure['files'].items():assert hashlib.sha256(z.read(path)).hexdigest()==d and A.sha(R/path)==d,(path,'source/archive changed')
    verify();N.parent.mkdir(exist_ok=True)
    options=['--doNotSaveSettings','--nes.removeSpriteLimit=false','--nes.ramPowerOnState=AllZeros','--nes.randomizeCpuPpuAlignment=false','--nes.randomizeMapperPowerOnState=false']
    meta=dict(passed=True,ROM_sha256=p['ROM_sha256'],prepared_sha256=A.sha(prepared),source_handoff_sha256=A.sha(O/'handoff.json'),source_members_verified=len(closure['files']),runner_sha256=A.sha(__file__),options=options,explicit_reserved_bytes=536870912,explicit_reserved_files=64,timeout=60)
    (O/'native-preflight-v7.json').write_text(json.dumps(meta,indent=2)+'\n');os.environ['SMB_RUN_OUTPUT']=str(N.resolve())
    budget=Q.load(O/'capture-budget-source-v7.py');run=Q.run_function(budget)
    rc=run(O/'native-driver-v6.lua',O/'candidate.nes',timeout=60,emulator_options=options)
    verify();(O/'native-postflight-v7.json').write_text(json.dumps(dict(**meta,exit_code=rc,all_prepared_and_frozen_source_bindings_unchanged=True),indent=2)+'\n')
    print(json.dumps(dict(native_terminal=True,exit_code=rc,ROM_sha256=p['ROM_sha256'],output=str(N.resolve()),pre_post_bindings_pass=True)),flush=True)
    raise SystemExit(rc)
if __name__=='__main__':main()
