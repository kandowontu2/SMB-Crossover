"""Prepare identical400-controller smoke plus passive body observer; never run."""
from pathlib import Path
import json
import arthur_body_fair_main_v5 as F
A=F.A;O=F.O;R=F.R
def main():
    out=O/'native-prepared-v5.json';assert not out.exists()
    handoff=json.loads((O/'handoff.json').read_text());h=A.sha(O/'candidate.nes');assert h==handoff['candidate_sha256']
    for p,d in handoff['bindings'].items():assert A.sha(p)==d
    b=A.scoped_load(O/'candidate.nes');size=int(b['syms']['GameLoop']['size'],0);stop=A.address(b,'GameLoop')+size-1
    assert b['raw'][A.location(b,'GameLoop')+size-6:A.location(b,'GameLoop')+size]==bytes([169,0,141,A.address(b,'NmiDisable')&255,A.address(b,'NmiDisable')>>8,96])
    source=R/'build/arthur-host-cache-v1/cache-native-source-v2.lua';assert A.sha(source)=='4b732b7dba0c120481d2946d3f5f165491a8e35592ff5d588dfc8994344c7975'
    observer=R/'tools/audit/arthur_body_fair_native_v5.lua';driver=O/'native-driver-v5.lua';sig=json.loads((O/'cache-final-link-proof.json').read_text())
    chrbase=16+(b['raw'][4]+256*(b['raw'][9]&15))*16384;assert chrbase==1048592
    driver.write_text(f'ARTHUR_HOST_MAIN_EXIT={stop}\nARTHUR_HOST_ROM_SHA256="{h}"\nARTHUR_CACHE_CODE_SIZE={sig["emitter_bytes"]}\nARTHUR_CACHE_SIGNATURE={{{",".join(map(str,bytes.fromhex(sig["signature"])))}}}\nARTHUR_FAIR_ROM=[=[{(O/"candidate.nes").as_posix()}]=]\nARTHUR_FAIR_CHR_BASE={chrbase}\nARTHUR_FAIR_PRIORITY_RETURN={A.address(b,"PriorityReturn")}\ndofile([=[{observer.as_posix()}]=])\ndofile([=[{source.as_posix()}]=])\n',newline='\n')
    p=dict(status='PREPARED_NOT_RUN_AWAITING_ROOT_REVIEW_AND_ONE_EXPLICIT_NATIVE_GRANT',ROM_sha256=h,source_handoff_sha256=A.sha(O/'handoff.json'),physical_frames=1200,controlled_game_frames=400,screenshot_bound=6,run_file_cap=64,run_byte_cap=512*1024**2,host_timeout_seconds=60,AllZeros=True,normal_eight_sprite_limit=True,script_RAM_writes=False,base_controller_and_all_semantic_assertions_unchanged=True,passive_new_observer='Genuine priority entry/return complete64record permutation; source prefix after original mode2; actual DMA fullOAM; actual mapped-cartridge CHR/palette and normalfirst8 body evaluation. No input/API mutation.',baseline=str((F.P/'native/cold-render-smoke-v1').resolve()),baseline_lag_NMI=212,baseline_foreground_mean=23356.681,baseline_foreground_max=33210,source_added_Main_CPU=json.loads((O/'handoff.json').read_text())['own_Main']['added_CPU'],limits=['Native pending. No performance or ShadowsOn native claim; original controller uses defaultoption, CPU covers both.','Compare exact same-controller physical400frames timing afterrun; severe lag remains blocker.','Standalone A79 ownership pending joint source rebase; no sharedinstallation.'])
    paths=[Path(__file__),observer,driver,source,O/'candidate.nes',O/'candidate.dbg',O/'candidate.lbl',O/'handoff.json',O/'source-closure.json',O/'private-source-cpu.zip',O/'cache-final-link-proof.json',R/'tools/run_mesen.py',R/'tools/audit/capture_budget.py',F.P/'native-handoff-v1.json']
    p['bindings']={str(q.resolve()):A.sha(q)for q in paths};out.write_text(json.dumps(p,indent=2)+'\n')
    print(json.dumps(dict(prepared_sha256=A.sha(out),ROM=h,source_handoff=p['source_handoff_sha256'],priority_entry=A.address(b,'ArCacheBodyPriority'),priority_return=A.address(b,'PriorityReturn'))))
if __name__=='__main__':main()
