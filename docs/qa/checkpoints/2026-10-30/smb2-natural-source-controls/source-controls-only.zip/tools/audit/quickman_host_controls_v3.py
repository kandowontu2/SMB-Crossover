"""Execute the actual private host image and genuine shared mapper in py65.

RAM call/return setup and optional fixture DATA publication are test harnesses.
They neither patch the ROM nor stand in for native controller qualification.
"""
from pathlib import Path
import hashlib,inspect,json,re,sys,builtins
from py65.devices.mpu6502 import MPU
R=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(Path(__file__).parent))
import quickman_component_bench_v2 as b
from check_tmnt_render_oa import load,address,location
O=R/'build/quickman-host-integrate-v3'
ORACLE=R/'build/quickman-host-arena-v1'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n',newline='\n')

class HostBus:
    publish_test_world=False
    instances=[]
    bundles={}
    def __init__(self,n=65536,path=None):
        image=Path(path or O/'candidate.nes');key=(str(image.resolve()),image.stat().st_mtime_ns)
        if key not in HostBus.bundles:HostBus.bundles[key]=load(image)
        self.bundle=HostBus.bundles[key];self.ram=builtins.bytearray(n)
        self.lab={n:int(r['val'],0)for n,r in self.bundle['syms'].items()}
        self.A,self.C,self.low,self.high=88,87,126,127
        self.events=[];self.writes=[];self.visits={};self.fixed_service_calls=0;self.outer_calls=0
        self.banks=[self.bundle['raw'][16+i*8192:16+(i+1)*8192]for i in range(128)]
        for s in self.bundle['segs'].values():
            if s['name']=='"SMCCODE"':
                a,n,o=(int(s[k],0)for k in ['start','size','ooffs']);self.ram[a:a+n]=self.bundle['raw'][o:o+n]
        for name,value in [('CurrentBank',self.A|128),('CurrentBankC',self.C|128),('SelectedCharacter',9),('FmAlts',32)]:self.ram[self.lab[name]]=value
        self.ram[0:3]=bytes([0x5d,0xd5,0xe7]);self.ram[3:5]=bytes([0xa5,0x5a]);self.ram[9:11]=bytes([0x3c,0xc3]);self.ram[0x5cc3]=0xd7
        self.grid=b.q.make_world()[0]
        attrs=self.bundle['raw'][location(self.bundle,'MTileAttribute'):location(self.bundle,'MTileAttribute')+256]
        self.solid=next(i for i,x in enumerate(attrs)if x&1);self.empty=next(i for i,x in enumerate(attrs)if not(x&1))
        if self.publish_test_world:HostBus.instances.append(self)
    def __getitem__(self,a):
        if isinstance(a,slice):return builtins.bytearray(self[i]for i in range(a.start or 0,a.stop,a.step or 1))
        if self.publish_test_world and self.A==70 and a==self.lab['QuickManWorldProbe']:
            page=self.ram[4];tab=self.lab['BlockBufferAddr'];parity=page&1;base=self[tab+parity]+256*self[tab+2+parity]
            for y in range(13):
                for x in range(16):self.ram[base+y*16+x]=self.solid if self.grid[y+2][(page&3)*16+x]else self.empty
        if a==self.lab['GetBlockBufferAddr']:self.fixed_service_calls+=1
        if a==self.lab['FarCallCommon']:self.outer_calls+=1
        if a>=0x8000:
            bank=[self.low,self.A,self.C,self.high][(a-0x8000)//8192]
            return self.banks[bank][a&8191]
        return self.ram[a]
    def __setitem__(self,a,v):
        if isinstance(a,slice):
            assert not(a.start==0x8000 and len(v)),('flat fixture is not actual host',a,len(v))
            self.ram[a]=v;return
        assert a<0x8000,('ROM store',hex(a),v)
        v&=255;self.ram[a]=v;self.writes.append((a,v))
        if 0x5114<=a<=0x5117:
            setattr(self,['low','A','C','high'][a-0x5114],v&127);self.events.append((a,v))
    def get(self,n):return self.ram[self.lab[n]]
    def set(self,n,v):self.ram[self.lab[n]]=v&255
    def bank(self,n):return (location(self.bundle,n)-16)//8192

def invoke(memory,pc,A=0,hook=None,X=0,registers=None,Y=0,P=0x30,internal=False,target_name=None):
    if not isinstance(memory,HostBus):return b.invoke(memory,pc,A,hook,X,registers)
    m=memory;names=[n for n in ['QuickManInit','QuickManTick','QuickManGetFrame']if m.lab.get(n)==pc]
    if internal or names:
        name=target_name or(names[0]if names else next(n for n,v in m.lab.items()if v==pc and n.startswith('Qh')))
        m.set('ArenaGatePtr',pc);m.ram[m.lab['ArenaGatePtr']+1]=pc>>8;m.set('ArenaGateBank',m.bank(name)|128)
        target='QhDispatch'
    else:
        target=target_name or next(n for n,v in m.lab.items()if v==pc and n in m.bundle['syms'] and'seg'in m.bundle['syms'][n]and'ooffs'in m.bundle['segs'][m.bundle['syms'][n]['seg']])
    m.ram[m.lab['SafecallA_SMC']+1]=A
    m.ram[m.lab['FarcallJmpTarget_SMC']+1]=m.lab[target]&255;m.ram[m.lab['FarcallJmpTarget_SMC']+2]=m.lab[target]>>8
    m.ram[0x1fe]=0xfe;m.ram[0x1ff]=0x7f
    cpu=MPU(memory=m,pc=m.lab['FarCallCommon']);cpu.a=m.bank(target)|128;cpu.x=X;cpu.y=Y;cpu.p=P;cpu.sp=0xfd
    recent=[];count=0
    while cpu.pc!=0x7fff:
        if hook:hook(cpu)
        recent.append(cpu.pc);recent=recent[-32:];cpu.step();count+=1
        assert count<150000,('CPU timeout',target,hex(cpu.pc),m.A,m.C,[hex(v)for v in recent])
    assert cpu.sp==0xff,('stack leak',target,cpu.sp)
    if registers is not None:registers.update(A=cpu.a,X=cpu.x,Y=cpu.y,P=cpu.p)
    return cpu.processorCycles

def call(m,n,**kwargs):return invoke(m,m.lab[n],target_name=n,**kwargs)

def source_controls():
    info=json.loads((ORACLE/'two-zp-projection/component/source-map.json').read_text());mapping={int(k,16):v for k,v in info['native_to_private_state'].items()};fields={int(k,16):v for k,v in info['native_to_absolute_state'].items()};work=info['work_absolute']
    out=O/'bench';out.mkdir(exist_ok=True);(out/'component-fixture.bin').write_bytes(b'')
    text=inspect.getsource(b.differential).replace("z=labels['QuickManScratch']","z=0")
    text=text.replace("or component[labels['FixtureStatus']]:","or(component[labels['FixtureStatus']]&127):")
    for old,new in [('component[z+8]','component[3]'),('component[z+9]','component[4]'),('component[z+0xa]',f'component[{work["0A"]}]'),('component[z+0xb]',f'component[{work["0B"]}]'),('component[z]',f'component[{work["00"]}]')]:text=text.replace(old,new)
    (out/'segmented-oracle.py').write_text(text,newline='\n');ns=dict(b.__dict__);ns.update(O=O,bytearray=HostBus,invoke=invoke);exec(compile(text,str(out/'segmented-oracle.py'),'exec'),ns)
    before=len(HostBus.instances);HostBus.publish_test_world=True
    proof=ns['differential'](info,mapping,HostBus().lab,(ORACLE/'projection/bench/native-stage-fixture.bin').read_bytes());HostBus.publish_test_world=False
    buses=HostBus.instances[before:]
    for m in buses:
        assert(m.A,m.C)==(88,87) and(m.get('CurrentBank'),m.get('CurrentBankC'))==(216,215)
        assert m.ram[0:3]==bytes([0x5d,0xd5,0xe7]) and m.ram[3:5]==bytes([0xa5,0x5a]) and m.ram[9:11]==bytes([0x3c,0xc3]) and m.ram[0x5cc3]==0xd7
    report=dict(status='ACTUAL_V3_ROM_ALL535_SOURCE_FIELDS_AND_CONTROLLER_STREAMS_PASS',ROM_sha256=sha(O/'candidate.nes'),DBG_sha256=sha(O/'candidate.dbg'),ticks=sum(x['ticks']for x in proof['cases']),semantic_assertions=proof['semantic_assertions'],source_cases=proof['cases'],maximum_tick_cycles=max(x['component_cycles_max']for x in proof['cases']),actual_fixed_tile_calls=sum(m.fixed_service_calls for m in buses),actual_FarCallCommon_calls=sum(m.outer_calls for m in buses),all_hardware_shadows_A_C_stack_and_borrowed_R0_R1_R6_R7_restored=True,scope='Source/controller differential only. Fixture publishes terrain DATA before actual live-block-buffer callback. No native emulator claim.')
    put(O/'source-controls-v3.json',report);print(report['status'],report['ticks'],report['maximum_tick_cycles'])

def lifecycle_smoke():
    m=HostBus();m.set('Player_X_Position',80);m.set('Player_Y_Position',160);m.set('Player_Y_HighPos',1)
    call(m,'HuFresh');assert m.get('QmField_06C0')==40 and m.get('QmField_0460')==88 and m.get('QmField_04A0')==180
    m.set('GameEngineSubroutine',8);m.set('SavedJoypadBits',1);m.set('Player_Y_HighPos',1)
    for _ in range(30):call(m,'HuMovement')
    assert(m.A,m.C)==(88,87)and m.ram[3:5]==bytes([0xa5,0x5a])
    print('lifecycle smoke30',m.get('Player_X_Position'),m.get('QmField_0460'),m.get('Player_X_Scroll'))

def render_controls():
    art=json.loads((R/'build/quickman-host-plan-v1/art/window0-proof.json').read_text());byframe={v['frame']:v for v in art['frames']}
    poses=json.loads((R/'build/quickman-source-v1/poses/pose-manifest.json').read_text())['frames']
    m=HostBus();call(m,'QuickManInit');rows=[]
    for pose in poses:
        for facing in [0x80,0xc0]:
            for cursor in [0,16,220,232,252]:
                x,y=128,128
                for slot in [0,2,3,4]:m.set('QmField_'+f'{0x420+slot:04X}',0)
                for a,v in [(0x400,int(pose['from_type'],16)),(0x6a0,pose['index']),(0x420,facing),(0x460,x),(0x4a0,y),(0x1f,0)]:m.set('QmField_'+f'{a:04X}',v)
                for slot in [2,3,4]:
                    for a,v in [(0x400,14),(0x6a0,slot-2),(0x420,facing),(0x460,x+(slot-3)*12),(0x4a0,y)]:m.set('QmField_'+f'{a+slot:04X}',v)
                for i in range(1,8):m.ram[m.lab['CurrentCHRBank']+i]=0x60+i;m.ram[m.lab['X5ChrMode']+i]=i
                m.ram[0x200:0x300]=b'\xad'*256;m.set('CurrentOAMOffset',cursor)
                cycles=call(m,'HuDraw');expected=[];end=cursor
                for frame,px,py in [(pose['frame'],x,y),(0x5c,x-12,y),(0x5d,x,y),(0x5e,x+12,y)]:
                    cells=byframe[frame]['cells']
                    if end+4*len(cells)>=256:continue
                    for cell in cells:
                        dx=cell['x']if facing&64 else -(cell['x']+8);attr=cell['attr']^(0 if facing&64 else 64)
                        expected.extend([(py+cell['y'])&255,cell['pair']*2,attr,(px+dx)&255])
                    end+=4*len(cells)
                actual=m.ram[0x200:0x300]
                assert m.get('CurrentOAMOffset')==end and actual[cursor:end]==bytes(expected),(pose['frame'],facing,cursor,end,m.get('CurrentOAMOffset'),list(actual[cursor:end]),expected)
                assert actual[:cursor]==b'\xad'*cursor and actual[end:]==b'\xad'*(256-end)
                page=251+byframe[pose['frame']]['logical_page'];assert m.get('CurrentCHRBank')==page and m.get('X5ChrMode')==128
                assert all(m.ram[m.lab['CurrentCHRBank']+i]==0x60+i and m.ram[m.lab['X5ChrMode']+i]==i for i in range(1,8))
                assert(m.A,m.C)==(88,87)and m.ram[3:5]==bytes([0xa5,0x5a])and m.ram[0:3]==bytes([0x5d,0xd5,0xe7])and m.ram[0x5cc3]==0xd7
                rows.append(dict(frame=pose['frame'],facing=facing,cursor=cursor,end=end,physical_CHR=page,cycles=cycles))
    # Cold preview is frame4 using display anchors, even with arbitrary actor
    # bytes. It may change selected-owner direct work, never source actor/HP.
    fields=json.loads((ORACLE/'two-zp-projection/component/source-map.json').read_text())['native_to_absolute_state'];addresses=sorted(fields.values())
    cold=HostBus()
    for a in addresses:cold.ram[a]=(a*37+19)&255
    before=bytes(cold.ram[a]for a in addresses)
    cold.set('Player_X_Position',96);cold.set('Player_Y_Position',88);cold.set('CurrentOAMOffset',16)
    call(cold,'HuMenuPortrait')
    assert bytes(cold.ram[a]for a in addresses)==before
    expected=[]
    for cell in byframe[4]['cells']:expected.extend([(88+21+cell['y'])&255,cell['pair']*2,cell['attr'],(96+8+cell['x'])&255])
    assert cold.ram[0x210:0x210+len(expected)]==bytes(expected)
    put(O/'render-controls-v3.json',dict(status='ACTUAL_HU_DRAW_LOSSLESS3B_AND_BOUNDED_OAM_PASS',ROM_sha256=sha(O/'candidate.nes'),cases=len(rows),body_poses=30,source_fan_frames=[92,93,94],all_source_geometry_palette_role_priority_OAM_bytes_exact=True,whole_actor_rejected_before_OAM_cursor_wrap=True,CHR_window0_upper0_and_windows1_7_preserved=True,cold_preview_preserves_all535_source_fields=True,maximum_render_cycles=max(v['cycles']for v in rows),rows=rows,scope='Actual compiled host CPU and mapper. No native RGB/OAM timing claim.'))
    print('render300 and cold portrait PASS')

def public_controls():
    m=HostBus();m.set('Player_X_Position',80);m.set('Player_Y_Position',160);m.set('Player_Y_HighPos',1);m.set('GameEngineSubroutine',8)
    call(m,'HuFresh');assert m.get('QmField_06C0')==40
    records=[]
    for player,hp in [(0,12),(1,24)]:
        m.set('_CurrentPlayer',player);call(m,'HuFresh');m.set('QmField_06C0',hp)
        call(m,'HuMovement');records.append(bytes(m.ram[m.lab['QhPersistent']+4*player:m.lab['QhPersistent']+4*player+4]))
    for turn in range(20):
        player=turn&1;m.set('_CurrentPlayer',player)
        m.set('Player_X_Position',80);m.set('Player_PageLoc',0);m.set('Player_Y_Position',160);m.set('Player_Y_HighPos',1)
        source_names=[n for n in m.lab if re.fullmatch(r'QmField_[0-9A-F]{4}|QuickManWork_[0-9A-F]{2}',n)]
        for index,n in enumerate(source_names):m.set(n,(index*73+turn*19+11)&255)
        baseline=HostBus();baseline.set('_CurrentPlayer',player);baseline.set('Player_X_Position',80);baseline.set('Player_Y_Position',160);baseline.set('Player_Y_HighPos',1)
        baseline.ram[baseline.lab['QhPersistent']:baseline.lab['QhPersistent']+8]=m.ram[m.lab['QhPersistent']:m.lab['QhPersistent']+8]
        call(baseline,'HuReset')
        call(m,'HuReset')
        assert all(m.get(n)==baseline.get(n)for n in source_names),('full conservative lifecycle reset',turn,[n for n in source_names if m.get(n)!=baseline.get(n)][:8])
        assert m.get('QmField_06C0')==[12,24][player] and m.get('QmField_0099')==40
        assert all(m.get('QmField_'+f'{0x420+i:04X}')==0 for i in range(1,32))
        assert m.get('QmField_0023')==m.get('QmField_0027')==0
        for p in [0,1]:assert bytes(m.ram[m.lab['QhPersistent']+4*p:m.lab['QhPersistent']+4*p+3])==records[p][:3]
    m.set('_CurrentPlayer',0);m.ram[m.lab['QhPersistent']]=0;call(m,'HuReset');assert m.get('QmField_06C0')==40
    # Native mature gate rejects hidden mushroom/flower but admits emerged
    # objects; the selected-owner pickup heals without native form cycling.
    picks=[]
    for typ in range(4):
        m.set('PowerUpType',typ);m.set('Enemy_State',0);regs={};call(m,'HuMature',registers=regs);assert bool(regs['P']&1)==(typ>=2)
        m.set('Enemy_State',128);call(m,'HuMature',registers=regs);assert regs['P']&1
        m.set('QmField_06C0',8);m.set('Enemy_Flag',1);m.set('NumberofLives',3)
        call(m,'HuPickup',registers=regs)
        assert m.get('QmField_06C0')== (40 if typ<2 else 8) and m.get('Enemy_Flag')==0
        if typ==2:assert m.get('StarInvincibleTimer')>0
        if typ==3:
            # Native SetFor1Up queues control0B; the later floating-number
            # owner awards the life. Do not demand an invented immediate add.
            assert m.get('NumberofLives')==3 and m.get('FloateyNum_Control')==11
        if typ<2:assert m.ram[m.lab['QhPersistent']]==40 and m.get('GameEngineSubroutine')==8
        picks.append([typ,m.get('QmField_06C0'),m.get('Enemy_Flag'),m.get('StarInvincibleTimer'),m.get('NumberofLives')])
    # Real palette/HUD producers must not write when a native alternate buffer
    # owns the frame or the complete command+terminator cannot fit64 bytes.
    palette=[]
    for ctrl in [0,1,6]:
        for offset in [0,16,53,54,55,56,63]:
            m.set('VRAM_Buffer_AddrCtrl',ctrl);m.set('VRAM_Buffer1_Offset',offset)
            first=m.lab['VRAM_Buffer1'];m.ram[first:first+80]=b'\xa6'*80
            call(m,'HuColors')
            if ctrl or offset>=54:assert m.ram[first:first+80]==b'\xa6'*80
            else:
                assert m.ram[first+offset:first+offset+11]==bytes([0x3f,0x11,7,0x0f,0x28,0x15,0x0f,0x0f,0x30,0x38,0])
                assert m.get('VRAM_Buffer1_Offset')==offset+10
            palette.append([ctrl,offset,m.get('VRAM_Buffer1_Offset')])
    m.set('InjuryTimer',0);m.set('QmField_06C0',40);call(m,'HuInjury');assert m.get('QmField_06C0')==36 and m.get('InjuryTimer')==64
    call(m,'HuInjury');assert m.get('QmField_06C0')==36
    m.set('InjuryTimer',0);m.set('QmField_06C0',4);call(m,'HuInjury')
    assert m.get('QmField_06C0')==0 and m.get('MmDeathFlag') and m.get('GameEngineSubroutine')==11
    assert(m.A,m.C)==(88,87)and m.ram[3:5]==bytes([0xa5,0x5a])and m.ram[0x5cc3]==0xd7
    put(O/'public-controls-v3.json',dict(status='ACTUAL_PUBLIC_TWO_PLAYER_RESET_PICKUP_PALETTE_INJURY_PASS',ROM_sha256=sha(O/'candidate.nes'),two_player_area_life_resets=20,all_source_transients_reset=True,persistent_HP_maxHP_progress_separate=True,dead_new_life_refills_current_player_only=True,pickups=picks,palette_capacity_and_native_buffer_owner_cases=palette,native_injury_protection_and_KillPlayer_death_route=True,scope='CPU fixtures and actual host routes only; native lifecycle/audio/NMI and complete campaign remain unqualified.'))
    print('public lifecycle/pickup/palette/injury PASS')

def contact_controls():
    rows=[]
    for kind,label in [(6,'Goomba'),(2,'Buzzy'),(0x2d,'Bowser')]:
        m=HostBus();call(m,'HuFresh');m.set('GameEngineSubroutine',8)
        for n,v in dict(Enemy_Flag=1,Enemy_ID=kind,Enemy_State=0,Enemy_X_Position=128,Enemy_PageLoc=0,Enemy_Y_Position=160,Enemy_Y_HighPos=1,Enemy_MovingDir=1,EnemyOffscrBitsMasked=0).items():m.set(n,v)
        m.set('MmEnemyHealthLo',600&255);m.set('MmEnemyHealthHi',600>>8)
        for a,v in [(0x420,0xc0),(0x460,136),(0x440,0),(0x4a0,176)]:m.set('QmField_'+f'{a+2:04X}',v)
        m.ram[m.lab['BoundingBox_UL_Corner']+28:m.lab['BoundingBox_UL_Corner']+36]=bytes(range(8))
        before=bytes(m.ram[m.lab['BoundingBox_UL_Corner']+28:m.lab['BoundingBox_UL_Corner']+36]);held=bytes(m.ram[3:5]+m.ram[9:11]);regs={}
        cycles=call(m,'HuWeapons',registers=regs)
        hp=m.get('MmEnemyHealthLo')+256*m.get('MmEnemyHealthHi')
        assert hp==(600 if kind==2 else 500),(label,hp)
        assert bytes(m.ram[m.lab['BoundingBox_UL_Corner']+28:m.lab['BoundingBox_UL_Corner']+36])==before
        assert bytes(m.ram[3:5]+m.ram[9:11])==held and(m.A,m.C)==(88,87)
        rows.append(dict(enemy=label,native_HP_before=600,native_HP_after=hp,cycles=cycles,active_source_bolt=m.get('QmField_0422')))
    put(O/'contact-controls-v3.json',dict(status='ACTUAL_NATIVE_ENEMY_HP_ARMOR_AND_BORROWED_CONTEXT_PASS',ROM_sha256=sha(O/'candidate.nes'),rows=rows,policy='Host adapter uses native type10 piercing100-unit hit consumer. Source fan AI, lifetime and positions retained. Native hit cadence and original CX enemy-contact dictionaries remain acceptance work.',scope='CPU fixture only.'))
    print('native Goomba/Buzzy/Bowser contact PASS')

def abi_controls():
    parent=R/'build/character-host-union-v5/candidate.nes';rows=[]
    for entry in ['NrAdder','NrBox']:
        for argument in [0,1]:
            for flags in range(256):
                if flags&0x30!=0x30:continue
                regs=[]
                for image in [parent,O/'candidate.nes']:
                    m=HostBus(path=image);before=bytes(m.ram[0x5c00:0x5f00]);r={}
                    call(m,entry,A=argument,X=7,Y=55,P=flags,registers=r)
                    assert bytes(m.ram[0x5c00:0x5f00])==before
                    assert(m.A,m.C)==(88,87)
                    regs.append((r['A'],r['X'],r['Y'],r['P']&0xcf))
                assert regs[0]==regs[1],(entry,argument,flags,regs)
                rows.append([entry,argument,flags,*regs[1]])
    put(O/'negative00-01-ABI-v3.json',dict(status='ACTUAL_PARENT_NEGATIVE00_01_EXPLICIT_OWNER_ABI_PASS',ROM_sha256=sha(O/'candidate.nes'),parent_sha256=sha(parent),pairs=len(rows),raw_selector=9,FmAlts=32,all64_input_flags=True,source_overlay_untouched=True,actual_foreign_fallback_registers_flags_equal=True,rows=rows))
    print('negative00/01 actual ABI',len(rows),'PASS')

if __name__=='__main__':
    if '--source'in sys.argv:source_controls()
    if '--smoke'in sys.argv:lifecycle_smoke()
    if '--render'in sys.argv:render_controls()
    if '--public'in sys.argv:public_controls()
    if '--contact'in sys.argv:contact_controls()
    if '--abi'in sys.argv:abi_controls()
