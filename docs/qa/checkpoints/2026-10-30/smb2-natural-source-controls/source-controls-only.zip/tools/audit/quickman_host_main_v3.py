"""Complete actual Quick Main and real vector controls; CPU fixtures only."""
from pathlib import Path
import hashlib,importlib.util,json,sys
R=Path(__file__).resolve().parents[2];O=R/'build/quickman-host-integrate-v3';P=R/'build/character-host-union-v5'
sys.path[:0]=[str(P),str(R/'tools'),str(R/'tools/audit')]
def mod(name,path):
    s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);s.loader.exec_module(m);return m
U=mod('quick_v3_bound_parent_controls',P/'controls.py')
N=mod('quick_v3_bound_parent_nmi',P/'gm_verify_nmi.py')
from check_tmnt_render_oa import Memory
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()

class PadMemory(Memory):
    """Only model the two original serial controller ports; ROM stays exact."""
    def __getitem__(self,at):
        if isinstance(at,int)and at in (0x4016,0x4017):
            port=at-0x4016;index=self.pad_index[port]
            value=((self.pad_bits[port]>>(7-index))&1)if index<8 else 1
            if not self.pad_strobe:self.pad_index[port]+=1
            self.pad_reads[port]+=1
            return value
        return super().__getitem__(at)
    def __setitem__(self,at,value):
        if at==0x4016:
            self.pad_strobe=value&1;self.pad_index=[0,0]
        return super().__setitem__(at,value)

def input_nmi(q,keys,player2=0):
    if not isinstance(q.m,PadMemory):
        q.m.__class__=PadMemory;q.m.pad_index=[0,0];q.m.pad_strobe=0;q.m.pad_reads=[0,0]
    q.m.pad_bits=(keys,player2);q.put(NmiDisable=0)
    result=N.nmi(q)
    assert q.get('SavedJoypad1Bits')==keys,('actual controller1 latch',keys,q.get('SavedJoypad1Bits'))
    assert q.get('SavedJoypad2Bits')==player2,('actual controller2 latch',player2,q.get('SavedJoypad2Bits'))
    return result

def latch_controls(B):
    q=make(B);N.B=B;rows=[];held=None;resume=False
    for age in range(65):
        keys=0 if age<6 else(16 if age==6 else(209 if age==55 else 193))
        irq=input_nmi(q,keys);before=q.get('QmField_001C');input_before=q.get('QmField_0023')
        c,tr,mn=U.C.M.runtrace(q,'GameLoop');paused=q.get('GamePauseStatus')&1
        ticks=tr.count(U.point(B,'QuickManTick'))
        assert ticks==(0 if paused else 1),(age,paused,ticks)
        if paused:
            assert q.get('QmField_001C')==before and q.get('QmField_0023')==input_before
        elif age>=55:
            resume=True
            assert q.get('QmField_0023')&12==0,('host-owned Start/Select reached source',age)
        rows.append(dict(age=age,hardware_mask=keys,latch1=q.get('SavedJoypad1Bits'),pause=paused,source_ticks=ticks,source_held=q.get('QmField_0023'),source_edges=q.get('QmField_0027'),foreground_CPU=c.processorCycles,NMI_CPU=irq['CPU']))
    assert any(r['pause']for r in rows)and resume
    proof=dict(passed=True,ROM_sha256=hashlib.sha256(B['raw']).hexdigest(),native=False,actual_serial_ports4016_4017=True,no_post_NMI_RAM_input_injection=True,host_pause_owns_Start_and_suspends_source_tick=True,held_inputs_sampled_by_native_NMI_during_pause=True,rows=rows)
    (O/'controller-latch-pause-v3.json').write_text(json.dumps(proof,indent=2)+'\n')
    print('actual serial controller + pause/resume65 PASS')
def make(B,mode=0):
    q=U.setup(B,9,mode);q.put(FmAlts=32,RlVariant=0,PlayerSize=0,PlayerStatus=0)
    q.invoke('NrFreshGameInit')
    assert q.get('QmField_06C0')==40 and q.get('QmField_009B')==128
    return q
def isr_controls(B):
    N.B=B;q=make(B);q.put(NmiDisable=0);N.nmi(q);q.put(NmiDisable=255,SavedJoypadBits=129)
    _,trace,_=U.C.M.runtrace(q,'GameLoop')
    ranges=[]
    for first,end in [('QhDispatch','QhImport'),('ArenaCallC','QuickManWorldProbe'),('HuCommon','HuQuickLo')]:
        bank,pc=U.point(B,first);ranges.append((bank,pc,U.address(B,end)))
    entries=['QhMovement','QuickManTick','CX_3C_8609','QuickManWorldProbe','QhImport','QhExport','QhSync','QhGraphics','QhDraw','QhWeapons','QhHitOne','QuickManRenderFrames','ArenaRenderCore','HuAfterTerrainGate']
    points=set(U.point(B,n)for n in entries)
    cuts=sorted({(bank,pc)for bank,pc in trace if(bank,pc)in points or any(bank==bb and lo<=pc<hi for bb,lo,hi in ranges)})
    assert cuts
    rows=[]
    for bank,pc in cuts:
        for kind in ['NMI','IRQ']:
            q=make(B);q.put(NmiDisable=0);N.nmi(q);q.put(NmiDisable=255,SavedJoypadBits=129)
            _,result=N.scheduler.invoke(q.m,'GameLoop',cut=(pc,bank,kind))
            irq=result['interrupt'];assert irq and q.get('GameEngineSubroutine')==8
            rows.append(dict(bank=bank,PC=pc,kind=kind,ISR_CPU=irq['CPU'],minimum_SP=irq['minimum_SP'],ZP_differences=irq['ZP_differences']))
    receipt=dict(passed=True,ROM_sha256=sha(O/'candidate.nes'),native=False,actual_vector_interruptions=len(rows),unique_executed_Main_seams=len(cuts),all_actual33SMC_live_stack_AXYP_and_A_C_hardware_shadows_restored=True,borrowed_foreground_ZP_preserved=True,source='Exact parent checked_interrupt implementation rebound to this actual candidate DBG/ROM, with real linked vectors. Every executed instruction in dispatcher/C mapper/HuCommon ranges plus actual source/world/render/public entries.',rows=rows)
    (O/'real-isr-controls-v3.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print('real ISR seams',len(cuts),'interrupts',len(rows),'PASS')
def foreign_controls(B):
    input_sha=hashlib.sha256(B['raw']).hexdigest()
    # Reuse the parent's unchanged complete-Main comparator and actual dynamic
    # pointer/SMC normalization, explicitly rebinding its old-baseline resolver
    # to the immutable union-v5 parent used by this integration.
    native_loader=U.scoped_load;old=native_loader(P/'candidate.nes')
    def bound_loader(path):
        return old if Path(path)==R/'build/pit-retold-host-v3/candidate.nes'else native_loader(path)
    U.scoped_load=bound_loader
    native_run=U.M.run_linked;calls=0
    def checked_run(q,name,**kwargs):
        nonlocal calls
        calls+=1
        try:return native_run(q,name,**kwargs)
        except BaseException as e:
            names=['SelectedCharacter','FmAlts','CrossoverBehaviorVersion','SavedJoypadBits','MarioVariant','ProtoVariant','BillVariant','Z2Variant','Cv3Variant','PitVariant','DarkwingVariant','RlVariant','KbVariant','CdVariant','MacVariant','M3Variant','VvVariant','TnVariant','IcVariant','RcVariant']
            receipt=dict(status='ACTUAL_FOREIGN_MAIN_NEGATIVE',call_number=calls,error=repr(e),fields={n:q.get(n)for n in names if n in q.b['syms']},physical_banks=q.m.banks,stack_1D0_1FF=list(q.m[0x1d0:0x200]),new_ROM_sha256=sha(O/'candidate.nes'),parent_sha256=sha(P/'candidate.nes'))
            p=O/'first-foreign-main-negative-v3.json'
            if not p.exists():p.write_text(json.dumps(receipt,indent=2)+'\n')
            print(json.dumps(receipt,indent=2),flush=True)
            raise
    U.M.run_linked=checked_run
    try:proof=U.foreign(B)
    finally:U.scoped_load=native_loader;U.M.run_linked=native_run
    proof.update(passed=True,ROM_sha256=input_sha,actual_parent_sha256=sha(P/'candidate.nes'),comparator_source_sha256=sha(P/'controls.py'),native=False)
    (O/'foreign-main-controls-v3.json').write_text(json.dumps(proof,indent=2)+'\n')
    print('actual-parent foreign Main',proof['cases'],'PASS')
def main():
    B=U.scoped_load(O/'candidate.nes');N.B=B;rows=[];proof=dict(passed=False,ROM_sha256=sha(O/'candidate.nes'),CPU_only=True,native=False)
    if '--isr'in sys.argv:isr_controls(B);return
    if '--foreign'in sys.argv:foreign_controls(B);return
    if '--latch'in sys.argv:latch_controls(B);return
    try:
        for mode in [0,1]:
            q=make(B,mode);nmi_rows=[]
            mode_rows=[]
            for age in range(80):
                keys=1|(128 if 5<=age<18 else 0)|(64 if 10<=age<40 else 0)
                irq=input_nmi(q,keys)
                c,tr,minimum=U.C.M.runtrace(q,'GameLoop')
                assert tr.count(U.point(B,'QuickManTick'))==1,('source body ticks',age,tr.count(U.point(B,'QuickManTick')))
                assert q.get('CurrentBank')&127==q.m.banks[1] and q.get('CurrentBankC')&127==q.m.banks[2]
                assert q.get('GameEngineSubroutine')==8,('engine',age,q.get('GameEngineSubroutine'))
                assert (q.get('QmField_0460')-q.get('Player_X_Position'))&255==8
                assert (q.get('QmField_04A0')-q.get('Player_Y_Position'))&255==20
                row=dict(mode=mode,age=age,keys=keys,X=q.get('Player_X_Position'),page=q.get('Player_PageLoc'),Y=q.get('Player_Y_Position'),screen_left=q.get('ScreenLeft_X_Pos'),screen_page=q.get('ScreenLeft_PageLoc'),source_state=q.get('QmField_002C'),source_held=q.get('QmField_0023'),source_edges=q.get('QmField_0027'),source_VY=[q.get('QmField_0640'),q.get('QmField_0660')],HP=q.get('QmField_06C0'),foreground_CPU=c.processorCycles,NMI_CPU=irq['CPU'],minimum_SP=minimum,active_boomerangs=[i for i in range(2,5)if q.get('QmField_0420',i)&128])
                rows.append(row);mode_rows.append(row)
                q.m.writes.clear()
            assert mode_rows[5]['source_VY']==[4,223],('native A-edge jump store',mode)
            assert min(r['Y']for r in mode_rows)<140 and mode_rows[-1]['Y']==176,('jump/land',mode)
            assert any(r['active_boomerangs']==[2,3,4]for r in mode_rows),('native fan',mode)
            assert any(r['screen_left']or r['screen_page']for r in mode_rows),('native scroll',mode)
        proof.update(passed=True,updates=len(rows),rows=rows,maximum_foreground_cycles=max(r['foreground_CPU']for r in rows),maximum_normal_NMI_cycles=max(r['NMI_CPU']for r in rows),minimum_SP=min(r['minimum_SP']for r in rows),complete_source_motion_native_terrain_scrolling_graphics_weapons_UI=True,limits='Finite CPU fixture only. No native NTSC frame cadence, ROM admission, clear, or palette visibility claim.')
    except BaseException as e:
        proof.update(error=repr(e),rows=rows[-8:])
        p=O/'first-full-main-negative-v3.json'
        if not p.exists():p.write_text(json.dumps(proof,indent=2)+'\n')
        raise
    finally:(O/'full-main-controls-v3.json').write_text(json.dumps(proof,indent=2)+'\n')
    print(json.dumps({k:v for k,v in proof.items()if k!='rows'},indent=2))
if __name__=='__main__':main()
