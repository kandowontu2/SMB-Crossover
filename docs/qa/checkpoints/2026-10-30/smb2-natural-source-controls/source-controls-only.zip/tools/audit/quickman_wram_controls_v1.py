"""Offline actual-host mapper + contiguous WRAM source controls. No native run."""
from pathlib import Path
import hashlib,inspect,json,re,sys
from py65.devices.mpu6502 import MPU
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(Path(__file__).parent))
import quickman_host_controls_v3 as C
import quickman_host_main_v3 as H
O=R/'build/quickman-wram-prep-v1';P=R/'build/quickman-host-cpu-v4'
LABELS={n:int(v,16)for v,n in re.findall(r'al ([0-9A-Fa-f]+) \.(\w+)',(O/'kernel.lbl').read_text())}
KERNEL=(O/'kernel.bin').read_bytes()
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,v):p.write_text(json.dumps(v,indent=2)+'\n',newline='\n')

class WramBus(C.HostBus):
    """Four independent RAM banks and raw bit7 mapping; explicit CPU preload."""
    def __init__(self,n=65536):
        super().__init__(n,path=P/'candidate.nes')
        self.tags=[0xfe,0xd8,0xd7,0xff]
        self.wram=[bytearray(8192)for _ in range(4)];self.wram[1][:]=KERNEL
        self.lab.update(LABELS)
        self.ram[0x5102]=2;self.ram[0x5103]=1;self.ram[0x5113]=0
        self.ram_reads=0;self.blocked_code_writes=0
    def __getitem__(self,a):
        if isinstance(a,int)and a>=0x8000:
            tag=self.tags[(a-0x8000)//8192]
            if not tag&128:
                self.ram_reads+=1;return self.wram[tag&3][a&8191]
        return super().__getitem__(a)
    def __setitem__(self,a,v):
        if isinstance(a,int):
            if 0x5114<=a<=0x5117:self.tags[a-0x5114]=v&255
            if a>=0x8000:
                tag=self.tags[(a-0x8000)//8192];assert not tag&128,('ROM write',hex(a),tag)
                if self.ram[0x5102]==2 and self.ram[0x5103]==1:self.wram[tag&3][a&8191]=v&255
                else:self.blocked_code_writes+=1
                return
        return super().__setitem__(a,v)

def invoke(memory,pc,A=0,hook=None,X=0,registers=None):
    if not isinstance(memory,WramBus):return C.b.invoke(memory,pc,A,hook,X,registers)
    # The exact frozen ROM FarCallCommon maps A70; its actual QhDispatch and
    # ArenaCallC write tag01 unchanged, stack old rawC and restore it afterward.
    memory.set('ArenaGatePtr',pc);memory.ram[memory.lab['ArenaGatePtr']+1]=pc>>8
    memory.set('ArenaGateBank',1)
    return C.invoke(memory,memory.lab['QhDispatch'],A=A,X=X,hook=hook,registers=registers,target_name='QhDispatch')

def source():
    info=json.loads((C.ORACLE/'two-zp-projection/component/source-map.json').read_text());mapping={int(k,16):v for k,v in info['native_to_private_state'].items()};work=info['work_absolute']
    out=O/'bench';out.mkdir(exist_ok=True);(out/'component-fixture.bin').write_bytes(b'')
    text=inspect.getsource(C.b.differential).replace("z=labels['QuickManScratch']","z=0")
    text=text.replace("or component[labels['FixtureStatus']]:","or(component[labels['FixtureStatus']]&127):")
    for old,new in [('component[z+8]','component[3]'),('component[z+9]','component[4]'),('component[z+0xa]',f'component[{work["0A"]}]'),('component[z+0xb]',f'component[{work["0B"]}]'),('component[z]',f'component[{work["00"]}]')]:text=text.replace(old,new)
    (out/'segmented-oracle.py').write_text(text,newline='\n');ns=dict(C.b.__dict__);ns.update(O=O,bytearray=WramBus,invoke=invoke);exec(compile(text,str(out/'segmented-oracle.py'),'exec'),ns)
    before=len(C.HostBus.instances);C.HostBus.publish_test_world=True
    proof=ns['differential'](info,mapping,WramBus().lab,(C.ORACLE/'projection/bench/native-stage-fixture.bin').read_bytes());C.HostBus.publish_test_world=False
    buses=C.HostBus.instances[before:]
    for m in buses:
        assert m.tags==[0xfe,0xd8,0xd7,0xff]and(m.get('CurrentBank'),m.get('CurrentBankC'))==(216,215)
        assert m.ram[0:3]==bytes([0x5d,0xd5,0xe7])and m.ram[3:5]==bytes([0xa5,0x5a])and m.ram[9:11]==bytes([0x3c,0xc3])and m.ram[0x5cc3]==0xd7
        assert m.wram[1]==KERNEL
        assert all(v==0 for v in m.wram[2]+m.wram[3])
        assert all(v==1 or v&128 for reg,v in m.events),('RAM tag accidentally OR80/mixed',m.events[:8])
    old=json.loads((P/'source-controls-v3.json').read_text());maximum=max(x['component_cycles_max']for x in proof['cases'])
    result=dict(passed=True,native=False,kernel_sha256=sha(O/'kernel.bin'),actual_host_ROM_sha256=sha(P/'candidate.nes'),actual_host_dispatch_and_FarCallCommon=True,raw_RAM_tag=1,header_adoption=False,CPU_preload_fixture_not_native_loader=True,source_ticks=sum(x['ticks']for x in proof['cases']),all535_source_fields_equal_each_tick=True,all14_semantic_assertions=proof['semantic_assertions'],maximum_tick_cycles=maximum,frozen_fragmented_tick_max=old['maximum_tick_cycles'],maximum_reduction=old['maximum_tick_cycles']-maximum,actual_fixed_world_calls=sum(m.fixed_service_calls for m in buses),raw_mapper_shadows_and_hardware_and_borrowed_pairs_restored=True,RAM_code_unchanged=True,unused_RAM_banks2_3_untouched=True,cases=proof['cases'])
    put(O/'source-controls.json',result);print('WRAM source1520 PASS, maxTick',maximum,'prior',old['maximum_tick_cycles'])

def flags():
    rows=[]
    # Match actual fragmented host API registers for all64 stable input flags,
    # using the NES CPU (decimal flag retained but decimal arithmetic disabled).
    oldcpu=C.MPU;C.MPU=H.N.NesMPU
    try:
        for p in [f for f in range(256)if f&0x30==0x30]:
            for keys in [0,1,2,64,128,129,131,160]:
                pair=[]
                for wram in [False,True]:
                    m=WramBus()if wram else C.HostBus(path=P/'candidate.nes')
                    if wram:invoke(m,m.lab['QuickManInit'])
                    else:C.call(m,'QuickManInit')
                    regs={}
                    if wram:
                        m.set('ArenaGatePtr',m.lab['QuickManTick']);m.ram[m.lab['ArenaGatePtr']+1]=m.lab['QuickManTick']>>8;m.set('ArenaGateBank',1)
                        C.invoke(m,m.lab['QhDispatch'],A=keys,P=p,registers=regs,target_name='QhDispatch')
                    else:C.call(m,'QuickManTick',A=keys,P=p,registers=regs)
                    names=[n for n in m.lab if n.startswith('QmField_')]
                    pair.append((regs,{n:m.get(n)for n in names}))
                assert pair[0]==pair[1],(p,keys,pair[0][0],pair[1][0])
                rows.append([p,keys,*pair[1][0].values()])
    finally:C.MPU=oldcpu
    put(O/'flags-controls.json',dict(passed=True,native=False,kernel_sha256=sha(O/'kernel.bin'),actual_host_ROM_sha256=sha(P/'candidate.nes'),cases=len(rows),NES_decimal_flag_contract=True,AXYP_and_all535_source_fields_equal_to_frozen_fragmented_API=True,rows=rows))
    print('WRAM flags/AP +535 state512 PASS')

def seeded():
    B=H.U.scoped_load(P/'candidate.nes');q=H.make(B);m=WramBus()
    m.ram[:0x8000]=bytes(q.m[:0x8000]);m.ram[0x5102]=2;m.ram[0x5103]=1
    m.tags=[q.m.banks[0]|128,q.get('CurrentBank'),q.get('CurrentBankC'),q.m.banks[3]|128]
    m.low,m.A,m.C,m.high=[v&127 for v in m.tags]
    for age in range(10):invoke(m,m.lab['QuickManTick'],A=128 if age<5 else 131)
    return m

def cpu_start(m,oldA=0xd8,oldC=0xd7,lag=255):
    m.tags[1:3]=[oldA,oldC];m.A,m.C=oldA&127,oldC&127
    m.set('CurrentBank',oldA);m.set('CurrentBankC',oldC);m.set('NmiDisable',lag)
    pc=m.lab['QuickManTick'];m.set('ArenaGatePtr',pc);m.ram[m.lab['ArenaGatePtr']+1]=pc>>8;m.set('ArenaGateBank',1)
    m.ram[m.lab['SafecallA_SMC']+1]=131;m.ram[m.lab['FarcallJmpTarget_SMC']+1]=m.lab['QhDispatch']&255;m.ram[m.lab['FarcallJmpTarget_SMC']+2]=m.lab['QhDispatch']>>8
    m.ram[0x1fe]=0xfe;m.ram[0x1ff]=0x7f
    c=H.N.NesMPU(memory=m,pc=m.lab['FarCallCommon']);c.sp=253;c.a=m.bank('QhDispatch')|128;c.x=7;c.y=55;c.p=0x71
    return c

def context(m,c,kind):
    cpu=lambda:(c.pc,c.a,c.x,c.y,c.p,c.sp)
    expected=list(m.tags);shadows=[m.get('CurrentBank'),m.get('CurrentBankC')];live=kind=='IRQ'or m.get('NmiDisable')!=0;before=(cpu(),bytes(m.ram[:256]),bytes(m.ram[0x101+c.sp:0x200]))
    smc=next(s for s in m.bundle['segs'].values()if s['name']=='"SMCCODE"');sa=int(smc['start'],0);sn=int(smc['size'],0);image=bytes(m.ram[sa:sa+sn]);assert sn==33
    for slot,name,opcode in [(1,'CurrentBank',b'\x8d\x15\x51'),(2,'CurrentBankC',b'\x8d\x16\x51')]:
        if kind=='NMI'and expected[slot]!=m.get(name):
            assert bytes(m[c.pc:c.pc+3])==opcode,('not actual pending mapper store',hex(c.pc),slot,expected[slot],m.get(name))
            expected[slot]=m.get(name)
    if kind=='NMI':c.nmi()
    else:
        assert not c.p&c.INTERRUPT;c.irq()
    cycles=c.processorCycles;low=c.sp
    for _ in range(100000):
        if c.pc==before[0][0]and c.sp==before[0][5]:break
        low=min(low,c.sp);assert m[c.pc]!=0,('ISR BRK',hex(c.pc),m.tags);c.step()
    else:raise AssertionError('real vector timeout')
    assert cpu()==before[0],('actual AXYP/SP',kind,cpu(),before[0])
    assert m.tags==expected and[m.get('CurrentBank'),m.get('CurrentBankC')]==shadows,('raw tag lost',kind,m.tags,expected,shadows)
    assert bytes(m.ram[sa:sa+sn])==image and bytes(m.ram[0x101+c.sp:0x200])==before[2]
    changes=[i for i,(a,b)in enumerate(zip(before[1],m.ram[:256]))if a!=b]
    if live:
        first=m.lab['XgAudioPtr'];end=m.lab['XgAudioZeroPageEnd'];assert all(kind=='NMI'and first<=i<end for i in changes),(kind,changes)
    assert m.ram[3:5]==before[1][3:5]and m.ram[9:11]==before[1][9:11]
    assert m.wram[1]==KERNEL
    return dict(kind=kind,CPU=c.processorCycles-cycles,minimum_SP=low,ZP_differences=changes,raw_tags=m.tags[:])

def interrupts():
    m=seeded();c=cpu_start(m);trace=[]
    entries={v for n,v in LABELS.items()if n in ['QuickManTick','CX_3C_84EE','CX_3C_8609','CX_3C_8B76','CX_3C_8C5E','CX_3E_DCDF','CX_3E_DF31','CX_1E_8290','CX_3F_EECD','CX_3F_F18B']}
    a0=m.lab['QhDispatch'];a1=m.lab['QhImport'];c0=m.lab['ArenaCallC'];c1=m.lab['QuickManWorldProbe']
    for step in range(30000):
        if c.pc==0x7fff:break
        if a0<=c.pc<a1 or c0<=c.pc<c1 or c.pc in entries or(c.pc>=0xc000 and m.tags[2]==1 and step%32==0):trace.append((step,c.pc))
        c.step()
    else:raise AssertionError('baseline dispatch timeout')
    assert m.tags==[0xfe,0xd8,0xd7,0xff]
    rows=[]
    for step,pc in trace:
        for lag in [0,255]:
            for kind in ['NMI','IRQ']:
                m=seeded();c=cpu_start(m,lag=lag)
                for _ in range(step):c.step()
                assert c.pc==pc
                proof=context(m,c,kind)
                for _ in range(30000):
                    if c.pc==0x7fff:break
                    c.step()
                else:raise AssertionError('post ISR timeout')
                assert m.tags==[0xfe,0xd8,0xd7,0xff]
                rows.append(dict(step=step,PC=pc,lag=lag,**proof))
    # Incoming raw RAM2 versus ROM2 and RAM3 versus ROM3 must remain distinct.
    tag_rows=[]
    for aa in [3,0x83,0xd8]:
        for cc in [1,2,0x81,0xd7]:
            m=seeded();c=cpu_start(m,oldA=aa,oldC=cc)
            for _ in range(30000):
                if c.pc==0x7fff:break
                c.step()
            else:raise AssertionError('tag dispatch timeout')
            assert m.tags==[0xfe,aa,cc,0xff]and m.get('CurrentBank')==aa and m.get('CurrentBankC')==cc
            tag_rows.append([aa,cc,c.processorCycles])
    result=dict(passed=True,native=False,CPU_preload_fixture=True,actual_host_ROM_sha256=sha(P/'candidate.nes'),kernel_sha256=sha(O/'kernel.bin'),real_vector_interruptions=len(rows),executed_seams=len(trace),raw_mapper_tags_not_masked_or_OR80=True,actual_frozen33SMC_live_stack_AXYP_SP_and_borrowed_pairs_restored=True,ordinary_and_lag_NMI=True,rows=rows,incoming_RAM_and_ROM_distinction_controls=tag_rows)
    put(O/'real-isr-controls.json',result);print('WRAM actual vectors',len(rows),'at',len(trace),'seams +12 tag restores PASS')

if __name__=='__main__':
    if '--source'in sys.argv:source()
    if '--flags'in sys.argv:flags()
    if '--isr'in sys.argv:interrupts()
