"""Private genuine FF graphics-selector data correction; no new code/lease."""
from pathlib import Path
import difflib,json,sys
R=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import prepare_ff_joint_source_v1 as B
from prepare_ff_current_component_v2 import qualified
from check_tmnt_render_oa import address,location
from prepare_cv3_dmc_mirror import prepare
P=R/'build/ff-joint-native-flash-1030-v1'
O=R/'build/ff-graphics-bank-proposal-v2'
H=R/'build/ff-joint-native-flash-qualified-1030-v1/handoff.json'

def main():
    assert not O.exists()
    files=B.validate(H,'802e29144ea73f3a4d2a2a68cebd881f9e93f27efe5c5e349c73b1947bb4e42d')
    O.mkdir();d=O/'joint';d.mkdir()
    for f in(P/'joint').rglob('*'):
        if f.is_file()and f.suffix in ['.s','.inc','.cfg','.chr','.bin']:
            q=d/f.relative_to(P/'joint');q.parent.mkdir(parents=True,exist_ok=True);q.write_bytes(f.read_bytes())
    p=d/'src/mmc5.s';old=p.read_text()
    before='(.bank(RcArtStart))|MMC5_PRG_ROM,$ff,(94)|MMC5_PRG_ROM'
    after='(.bank(RcArtStart))|MMC5_PRG_ROM,.lobyte(.bank(FfArtStart)|MMC5_PRG_ROM),(94)|MMC5_PRG_ROM'
    assert old.count(before)==1
    B.write(p,'.import FfArtStart\n'+old.replace(before,after))
    cfg=(d/'private.cfg').read_text().replace((P/'joint/ram3.bin').as_posix(),(d/'ram3.bin').as_posix())
    B.write(d/'private.cfg',cfg)
    cmd=json.loads((P/'joint/main-build.json').read_text())['command']
    B.run(d,[v.replace(str(P/'joint'),str(d))for v in cmd],'main-build')
    cmd=json.loads((P/'joint/final-link.json').read_text())['command']
    cmd=[v.replace(str(P/'joint/candidate'),str(d/'candidate')).replace(str(P/'joint/private.cfg'),str(d/'private.cfg'))
         .replace(str(P/'joint/main.o'),str(d/'main.o'))for v in cmd]
    B.run(d,cmd,'final-link');prepare(R,d/'candidate.nes')
    new=qualified(d/'candidate.nes');prior=qualified(P/'joint/candidate.nes')
    at=location(new,'DwResidentGraphicsBanks')+22-6
    diff=[i for i,(a,z)in enumerate(zip(prior['raw'],new['raw']))if a!=z]
    assert diff==[at] and prior['raw'][at]==255 and new['raw'][at]==221,diff
    assert {k:{n:v for n,v in s.items()if n!='oname'}for k,s in new['segs'].items()}=={k:{n:v for n,v in s.items()if n!='oname'}for k,s in prior['segs'].items()}
    for n in ['DwResidentGraphicsSelector','DwResidentGraphicsBanks','CrossoverGraphicsBank','FwNativeFlashProbe','FwNativeDrawAll']:
        assert address(new,n)==address(prior,n),n
    for n in ['ram3.bin','ff-stream.bin','ff-cookie.bin']:
        assert(d/n).read_bytes()==(P/'joint'/n).read_bytes()
    B.write(O/'source.patch',''.join(difflib.unified_diff(old.splitlines(True),p.read_text().splitlines(True),fromfile='parent/mmc5.s',tofile='proposal/mmc5.s')))
    files|={Path(__file__),R/'tools/audit/prepare_ff_graphics_bank_v1.py',R/'build/ff-graphics-bank-proposal-v1/negative-debug-path-check.json',P/'source-closure.json'}|{Path(v)for v in cmd if v.endswith('.o')}
    files|={f for f in O.rglob('*')if f.is_file()}
    B.save(O/'source-closure.json',dict(passed=True,native=False,admitted=False,
        candidate_sha256=B.sha(d/'candidate.nes'),parent_sha256=B.sha(P/'joint/candidate.nes'),
        changed_bytes=1,changed_ROM_offset=at,source='DwResidentGraphicsBanks raw22 row',
        old_raw_bank=255,new_raw_bank=221,all_public_PCs_segments_header_CHR_RAM3_cookie_exact=True,
        limits=['One source-linked table correction only. No new hook, marker, scheduler or admission.'],
        bindings={str(f.resolve()):B.sha(f)for f in sorted(files)}))
    print(json.dumps(dict(passed=True,ROM=B.sha(d/'candidate.nes'),changed_offset=at)),flush=True)

if __name__=='__main__':main()
