"""Actual immutable source iterator's body/sword/ink role partition, both faces."""
from pathlib import Path
import collections,itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import ff_fx_palette_audit_v2 as A
from check_tmnt_render_oa import address,location
H=A.H
P=R/'build/ff-upper-fx-windows-1030-v1';H.O=P/'joint'
O=R/'build/ff-fx-sword-role-audit-v1'

def main():
    O.mkdir(exist_ok=False);p=dict(passed=False,native=False,admitted=False,read_only=True)
    try:
        b=H.C.qualified(P/'joint/candidate.nes');m=A.T.base(b)
        raw=(R/'chr/characters/final-fantasy.chr').read_bytes();rows=[]
        for entry,face,off in itertools.product(range(144),[1,2],[0,1]):
            parts=[]
            for chunk in range(8):
                H.put(m,FfSlot=face,PlayerOutlinesOff=off)
                c=A.source(m,'FfRenderChunk',a=entry,x=chunk,y=0)
                if not c.p&1:break
                n=H.get(m,'FfRenderBuffer');page=H.get(m,'FfRenderPage')
                yoff=H.get(m,'FfRenderYOffset')+256*m[address(b,'FfRenderYOffset')+1]
                if yoff&32768:yoff-=65536
                for i in range(0,n,4):
                    tile,attr,y,x=m[address(b,'FfRenderBuffer')+1+i:address(b,'FfRenderBuffer')+5+i]
                    parts.append(dict(chunk=chunk,part=i//4,page=page,tile=tile,role=attr&3,
                        x=x-256 if x&128 else x,y=yoff+(y-256 if y&128 else y),
                        indices=dict(A.pattern_indices(raw,page,tile))))
            roles=collections.Counter(r['role']for r in parts)
            assert set(roles)<={0,2,3}
            if entry//36 in[1,2]:assert not roles[2]
            if off:assert not roles[3]
            # Exact original roles are already separate 8x16 records. Filtering
            # cannot remove body0 records or change any bitplane/pixel.
            body=[r for r in parts if r['role']==0]
            sword=[r for r in parts if r['role']==2]
            ink=[r for r in parts if r['role']==3]
            assert len(body)+len(sword)+len(ink)==len(parts)
            assert all(set(r['indices'])=={1}for r in ink)
            rows.append(dict(entry=entry,character=['Fighter','White','Black','Thief'][entry//36],
                tier=(entry%36)//18,pose=(entry%18)+1,face=face,outlines_off=off,
                body_parts=len(body),sword_parts=len(sword),ink_parts=len(ink),parts=parts))
        sword=[r for r in rows if r['sword_parts']]
        assert {r['character']for r in sword}=={'Fighter','Thief'}
        assert set(i for r in sword for a in r['parts']if a['role']==2 for i in a['indices'])=={1,2,3}
        palettes={n:A.data(b,n,s)for n,s in [('FfPaletteRed',16),('FfPaletteBlue',16),('FfPaletteIce',4),('FfPaletteBolt',4)]}
        assert palettes['FfPaletteRed'][9:12]==palettes['FfPaletteBlue'][9:12]==[12,28,44]
        assert set(palettes['FfPaletteIce'][1:]).isdisjoint(palettes['FfPaletteRed'][9:12])
        p.update(passed=True,actual_source_iterator_views=len(rows),sword_views=len(sword),palettes=palettes,
            rows=rows,all_body_sword_ink_separate_records=True,source_sword_indices=[1,2,3],
            sword_exact_P1=[12,28,44],ice_white_exact_P1=[18,33,48],ink_exact_P1=[15,15,15],
            sword_ice_bitplane_permutation_lossless=False,
            scheduling_proposal=dict(body_role0='Always preserved; neither hidden nor recolored.',
              sword_role2='Whole original sword record set is one own palette family, even when interleaved in chunk0.',
              ink_role3='Optional original black mask record set is a separate P1-black epoch; preserve original glyphs, no worldP3 donor.',
              remap='Palette attribute only 2/3->1 within genuine FF early/body range; source tile/flip/coordinates/bitplanes exact.',
              early_body_boundary='logical0..<RgOamPlayerStart+actual body header, mapped through RgOamRotation; native world follows that end.',
              spell_identity='Unique final spritewindow5/6/7 identifies original slot0/12/24; existing source records supply Fire/Bolt/Ice/White family.',
              maximum_legal_families=dict(Fighter_or_Thief=3,White=3,Black=4),
              visibility_limit='Fair admitted draw epochs may flicker at1/3 or1/4 when nativeP1 and optionalink conflict. Not native cadence/readiness proof.'),
            limits=['No source/CHR/OAM growth or palette implementation. Original complete record partition only.',
              'Exact P1 packet/owner retirement and actual fullMain filtering/admission controls remain owed.'])
    except Exception as e:p.update(error=repr(e),traceback=traceback.format_exc())
    files=[Path(__file__),Path(A.__file__),P/'source-closure.json',P/'joint/candidate.nes',P/'joint/candidate.dbg',
        R/'chr/characters/final-fantasy.chr',R/'src/final_fantasy_render.s']
    p['bindings']={str(f.resolve()):A.sha(f)for f in files}
    t=O/('controls.json'if p['passed']else'negative-controls.json');t.write_text(json.dumps(p,indent=2)+'\n',newline='\n')
    print(json.dumps(dict(passed=p['passed'],path=str(t),error=p.get('error'))),flush=True);assert p['passed']

if __name__=='__main__':main()
