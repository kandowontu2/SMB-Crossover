"""One-byte genuine FF C-bank publication: actual selector/Main/vector controls."""
from pathlib import Path
import itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import ff_joint_actual_main_v2 as M
import ff_joint_typed_controls_v1 as T
import ff_host_pickups_vectors_v2 as V
from ff_wram_host_isr_v4 import clone
from check_tmnt_render_oa import address,location
from verify_native_relocation import NesMPU
H=M.H;sha=M.sha
P=R/'build/ff-joint-native-flash-1030-v1/joint'
O=R/'build/ff-graphics-bank-proposal-v2';H.O=O/'joint'

def direct(m,name,p):
    c=NesMPU(memory=m,pc=address(m.bundle,name));c.a=85;c.x=7;c.y=91;c.p=p;c.sp=224;c.stPushWord(0x5aff)
    return H.finish(m,c)[0]

def selectors(old,new):
    seeds=[H.make(b)for b in[old,new]];rows=[]
    for selected in range(256):
        for p in [0x30|n for n in range(256)if not n&0x30]:
            results=[]
            for s in seeds:
                m=T.copy(s);H.put(m,SelectedCharacter=selected,DarkwingVariant=0)
                m.writes.clear();c=direct(m,'DwResidentGraphicsSelector',p)
                results.append((m,c))
            (a,c),(z,d)=results
            expected=221 if selected==22 else c.a
            assert(d.a,d.x,d.y,d.p,d.sp)==(expected,c.x,c.y,c.p,c.sp)
            assert c.processorCycles==d.processorCycles
            assert z.rawtags[:2]+z.rawtags[3:]==a.rawtags[:2]+a.rawtags[3:]
            assert z.rawtags[2]==expected==H.get(z,'CurrentBankC')
            exceptC=address(new,'CurrentBankC')
            assert all(a[i]==z[i]for i in range(0x8000)if i not in[exceptC,0x5116]), ('unexpected selector application write',selected,p)
            writes=[(at,221 if selected==22 and at in[exceptC,0x5116]else val)for at,val in a.writes]
            assert writes==z.writes
        rows.append(dict(raw=selected,flags=64,old_rawC=H.get(a,'CurrentBankC'),new_rawC=H.get(z,'CurrentBankC'),CPU=d.processorCycles))
    return dict(cases=256*64,rows=rows,all_foreign_raws_flags_cycles_and_writes_exact=True,
      selected22_only_A_shadow_hardware_FF_to_DD=True)

def full_main(old,new):
    rows=[]
    for variant,off,skip in itertools.product(range(4),[0,1],[0,1]):
        states=[M.setup(b)for b in[old,new]]
        for m in states:
            H.put(m,FfVariant=variant,PlayerOutlinesOff=off,ShouldSkipDrawSprites=skip)
            for i,(kind,x)in enumerate([(0,176),(6,208)]):
                for n,v in [('Enemy_Flag',1),('Enemy_ID',kind),('Enemy_State',0),('Enemy_X_Position',x),
                    ('Enemy_PageLoc',0),('Enemy_Y_Position',176),('Enemy_Y_HighPos',1),('Enemy_MovingDir',1)]:
                    m[address(m.bundle,n)+i]=v
        for tick in range(4):
            results=[]
            for m in states:
                H.put(m,SavedJoypadBits=0,A_B_Buttons=0,Left_Right_Buttons=0,NmiDisable=255,VRAM_Buffer1_Offset=0)
                m.writes.clear();entries=[]
                def observer(mem,c,i):
                    if c.pc==address(mem.bundle,'FwNativeFlashProbe'):
                        entries.append([mem.rawtags[1],mem.rawtags[2],c.y])
                c,low=M.invoke_main(m,observer)
                results.append((m,c,low,entries))
            (a,c,low,ae),(z,d,zlow,ze)=results
            at=address(new,'CurrentBankC')
            # The sole intended semantic change is the persistent genuine FF
            # graphics context. No OAM, queue, source-state or scratch masks.
            assert all(a[i]==z[i]for i in range(0x8000)if not 0x100<=i<0x200 and i not in[at,0x5116])
            writes=[(i,221 if i in[at,0x5116]and v==255 else v)for i,v in a.writes if not 0x100<=i<0x200]
            assert writes==[(i,v)for i,v in z.writes if not 0x100<=i<0x200]
            assert(c.a,c.x,c.y,c.p,c.sp)==(d.a,d.x,d.y,d.p,d.sp)
            assert c.processorCycles==d.processorCycles and low==zlow
            assert a.rawtags[2]==255 and z.rawtags[2]==221
            assert ze==[[x,221,y]for x,oldC,y in ae]
            if not skip:assert ze
            H.exact(z)
            rows.append(dict(variant=variant,outlines_off=off,skip=skip,tick=tick,
                old_probe=ae,new_probe=ze,CPU=d.processorCycles,minimum_SP=zlow))
    return dict(pairs=len(rows),rows=rows,actual_Main_native_DrawAll_C93_ingress=True,
        no_source_OAM_queue_scratch_SMC_or_cycle_change=True)

def vectors(new):
    m=M.setup(new);H.put(m,NmiDisable=255)
    c=H.start(m,'CrossoverGraphicsBank');samples=[];seen=set()
    start=address(new,'DwResidentGraphicsSelector');end=address(new,'DwResidentGraphicsBanks')
    def snap(mem,c,i):
        key=(c.pc,mem.rawtags[1],mem.rawtags[2])
        if start<=c.pc<end and key not in seen:
            seen.add(key);samples.append((i,clone(mem,c)))
    H.finish(m,c,snap);rows=[]
    for i,(state,cpu)in samples:
        for kind,lag in itertools.product(['NMI','IRQ'],[0,255]):
            q,d=clone(state,cpu);H.put(q,NmiDisable=lag)
            if kind=='IRQ'and d.p&d.INTERRUPT:continue
            proof=V.interrupt(q,d,kind);H.finish(q,d)
            assert q.rawtags[2]==221 and H.get(q,'CurrentBankC')==221
            H.exact(q);rows.append(dict(step=i,PC=cpu.pc,lag=lag,**proof))
    return dict(instruction_seams=len(samples),actual_vector_cases=len(rows),rows=rows,
        actual_pending_hardware_store_reconciled=True)

def main():
    out=O/'controls-v2.json';assert not out.exists()
    p=dict(passed=False,native=False,admitted=False,checks={})
    try:
        old=H.C.qualified(P/'candidate.nes');new=H.C.qualified(H.O/'candidate.nes')
        p['checks']['selectors']=selectors(old,new);print('all raw/flags selectors PASS',flush=True)
        p['checks']['Main']=full_main(old,new);print('actual Main C93 ingress PASS',flush=True)
        p['checks']['vectors']=vectors(new);print('actual NMI/IRQ selector cuts PASS',flush=True)
        p['passed']=True
    except Exception as e:p.update(error=repr(e),traceback=traceback.format_exc())
    files=[Path(__file__),R/'tools/audit/ff_graphics_bank_controls_v1.py',O/'negative-controls-v1.json',Path(M.__file__),Path(T.__file__),Path(H.__file__),Path(V.__file__),
        P/'candidate.nes',P/'candidate.dbg',O/'source-closure.json',H.O/'candidate.nes',H.O/'candidate.dbg']
    p['bindings']={str(f.resolve()):sha(f)for f in files}
    t=out if p['passed']else O/'negative-controls-v2.json'
    t.write_text(json.dumps(p,indent=2)+'\n',newline='\n')
    print(json.dumps(dict(passed=p['passed'],path=str(t),error=p.get('error'))),flush=True);assert p['passed']

if __name__=='__main__':main()
