"""Fresh DK V13 controller-only min-eight-poll A fixture; native launch needs root grant."""
from pathlib import Path
import argparse
import csv
import difflib
import hashlib
import json
import re
import sys

R = Path(__file__).resolve().parents[2]
sys.path[:0] = [str(R/'tools'), str(R/'tools/audit')]
import prepare_union13_remaining_routes_v1 as base
from current_roster_compact_11_v1 import linked, lua

O = R/'build/dk-union13-min8-v1'
OLD = R/'build/character-host-union-remaining-routes-v1/dk'
EXPECTED = '5fe355f56e7bb138fb5b7a4195edaca24eceab21c230903305094b663c10d198'
SCRIPT = R/'tools/audit/roster_expansion_cold_capture_v3.lua'


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def write(p, text):
    p = p.resolve()
    assert p.is_relative_to(O.resolve()) and p != O.resolve(), p
    p.write_text(text, newline='\n')


POLICY = """-- Only extend original fresh A requests to at least eight policy input polls.
-- All geometry, native jump physics, B/left/right and combat decisions stay original.
local original=assert(dofile(ROSTER_CONFIG.original_policy))
local remaining=0
return function(c)
 local b=original(c)
 if b.a and not c.lastA then remaining=8 end
 if remaining>0 then b.a=true;remaining=remaining-1 end
 return b
end
"""

TELEMETRY = """-- BEGIN DK_PASSIVE_INPUT_TELEMETRY_V1
local inputRows=0
local inputLog=file('input-consumption.csv','kind,frame,poll,completedMain,cpuCycle,pc,bank,sp,requestedMask,savedJoypad1,savedJoypad2,masterJoypad,ab,previousAB,dkPrevious,dkFresh,dkAttack,dkAge,dkTier,x,y,yHigh,state,vx,vy,engine,mode,task,pause,timer,nmiSkipped,frameCounter,world,level,enemy0flag,enemy0id,enemy0state,enemy0x,enemy0y')
local function inputTelemetry(kind)
 if done then return end
 inputRows=inputRows+1;assert(inputRows<=120000,'Bounded passive input telemetry')
 local s=emu.getState()
 local row={kind,frame,polls,loops,s['cpu.cycleCount'],s['cpu.pc'],bank(s['cpu.pc']),s['cpu.sp'],mask,
  r('SavedJoypad1Bits'),r('SavedJoypad2Bits'),r('SavedJoypadBits'),r('A_B_Buttons'),r('PreviousA_B_Buttons'),
  r('DkPrevious'),r('DkFresh'),r('DkAttack'),r('DkAge'),r('DkTier'),
  pos('Player_X_Position','Player_PageLoc'),r('Player_Y_Position'),r('Player_Y_HighPos'),r('Player_State'),
  r('Player_X_Speed'),r('Player_Y_Speed'),r('GameEngineSubroutine'),r('OperMode'),r('OperMode_Task'),
  r('GamePauseStatus'),r('TimerControl'),r('NmiSkipped'),r('FrameCounter'),r('WorldNumber'),r('LevelNumber'),
  r('Enemy_Flag'),r('Enemy_ID'),r('Enemy_State'),pos('Enemy_X_Position','Enemy_PageLoc'),r('Enemy_Y_Position')}
 inputLog:write(table.concat(row,',')..'\\n')
 if inputRows%128==0 or polls>=345 and polls<=385 then inputLog:flush()end
end
for _,kind in ipairs({'dk-movement','native-physics','save-ab','input-read-complete','catchup-entry'})do
 local h=assert(C.input_hooks[kind]);hook(h,function()inputTelemetry(kind)end)
end
-- END DK_PASSIVE_INPUT_TELEMETRY_V1
"""


def prepare():
    assert not O.exists(), 'Fresh output only'
    assert sha(OLD/'ready.json') == EXPECTED
    prior = json.loads((OLD/'ready.json').read_text())
    for p, h in prior['bindings'].items():
        assert sha(p) == h, p
    old_files = [OLD/n for n in ['ready.json', 'binding.json', 'result.json', 'inputs.csv', 'trace.csv',
                                'events.jsonl', 'capture-review.json', 'captures.nesppuv1']]
    old_hashes = {str(p): sha(p) for p in old_files}
    base.O = O
    base.prepare('dk')
    out = O/'dk'
    ready = json.loads((out/'ready.json').read_text())
    cfg = ready['config']
    cfg['original_policy'] = cfg['policy']
    cfg['policy'] = (out/'policy-min8.lua').as_posix()
    raw, syms, address, location, hook = linked(base.ROM)
    cfg['input_hooks'] = {k: hook(n, tail=t) for k,n,t in [
        ('dk-movement', 'DkMovement', False), ('native-physics', 'PlayerPhysicsSub', False),
        ('save-ab', 'SaveAB', False), ('input-read-complete', 'OAMandReadJoypad', True),
        ('catchup-entry', 'CatchUpOnce', False)]}
    read = cfg['input_hooks']['input-read-complete']
    read['banks'] = [125,127]
    start = location('OAMandReadJoypad')
    count = int(syms['OAMandReadJoypad']['size'], 0)
    clone = 16+125*8192+(address('OAMandReadJoypad')&8191)
    assert raw[start:start+count] == raw[clone:clone+count]
    at = 16+125*8192+(read['pc']&8191)
    assert raw[at:at+3] == bytes(read['bytes'])
    for n in ['DkPrevious','DkFresh','DkAttack','DkAge','DkTier']:
        assert syms[n]['type']=='equ' and 0x5c00<=address(n)<0x5cc3
        cfg['extra_ram'][n] = address(n)
    source = SCRIPT.read_text()
    capture = source
    anchor = 'local function shadowWindow(pc,target,shadow)'
    assert capture.count(anchor)==1
    capture = capture.replace(anchor,TELEMETRY+anchor)
    before = "activeLoop={sp=s['cpu.sp'],start=s['cpu.cycleCount'],interrupt=0}end)"
    after = "activeLoop={sp=s['cpu.sp'],start=s['cpu.cycleCount'],interrupt=0};inputTelemetry('main-entry')end)"
    assert capture.count(before)==1
    capture = capture.replace(before,after)
    before = "loops=loops+1;lastCycles=s['cpu.cycleCount']-a.start;lastInterrupt=a.interrupt;activeLoop=nil"
    assert capture.count(before)==1
    capture = capture.replace(before,before+";inputTelemetry('main-return')")
    before = "mask=pack(b);inputs:write(polls..','..frame..','..mask..'\\n');emu.setInput(b,0)"
    assert capture.count(before)==1
    capture = capture.replace(before,"mask=pack(b);inputTelemetry('input-selected');inputs:write(polls..','..frame..','..mask..'\\n');emu.setInput(b,0)")
    # Every edit is additive passive telemetry. Reverse it and require exact original text.
    restored = capture.replace(TELEMETRY,'').replace(after,"activeLoop={sp=s['cpu.sp'],start=s['cpu.cycleCount'],interrupt=0}end)")
    restored = restored.replace(";inputTelemetry('main-return')",'').replace("inputTelemetry('input-selected');",'')
    assert restored == source
    assert not re.search(r'\bemu\.(?:write\w*|setState|loadSavestate|reset)\s*\(', capture+POLICY)
    assert capture.count('emu.setInput(')==source.count('emu.setInput(')==1
    labels = {}
    for line in base.ROM.with_suffix('.lbl').read_text().splitlines():
        m=re.fullmatch(r'al ([0-9A-Fa-f]+) \.([\w]+)',line)
        if m: labels[m[2]]=int(m[1],16)
    for n in set(re.findall(r'''\br\(['"]([^'"]+)['"]''',capture)):
        value=address(n)
        if n in labels: assert labels[n]==value
        else:
            assert syms[n]['type']=='equ' and (value<0x2000 or 0x5c00<=value<0x8000)
            cfg['extra_ram'][n]=value
    write(out/'policy-min8.lua',POLICY)
    write(out/'capture-min8.lua',capture)
    write(out/'capture-diff.patch',''.join(difflib.unified_diff(source.splitlines(True),capture.splitlines(True),
            fromfile=SCRIPT.as_posix(),tofile=(out/'capture-min8.lua').as_posix())))
    write(out/'config.json',json.dumps(cfg,indent=2)+'\n')
    write(out/'run.lua','ROSTER_CONFIG='+lua(cfg)+'\n'+
        'for name,value in pairs(ROSTER_CONFIG.extra_ram)do assert(L[name]==nil or L[name]==value,"RAM alias conflict: "..name);L[name]=value end\n'+
        'dofile('+lua((out/'capture-min8.lua').as_posix())+')\n')
    inputs=list(csv.DictReader((OLD/'inputs.csv').open()))
    row=next(q for q in inputs if int(q['mask'])&128)
    assert int(row['poll'])==358 and int(row['mask'])==193
    # Contract model bound to the exact simple Lua wrapper above, not a claim of Lua runtime/native execution.
    remaining=0; output=[]; previous=False
    for q in inputs:
        mask=int(q['mask']); a=bool(mask&128)
        if a and not previous: remaining=8
        if remaining>0: a=True;remaining-=1
        output.append((int(q['poll']),mask&127|(128 if a else 0)))
        previous=a
    assert [m for p,m in output if 358<=p<=365]==[193]*8
    assert all((int(q['mask'])&127)==(m&127) for q,(_,m) in zip(inputs,output))
    failure=json.loads((OLD/'result.json').read_text())
    assert failure['frames']==413 and not failure['zero_deaths'] and failure['reason']=='Zero-death 1-1 route'
    notes=dict(native_executed=False,ROM_sha256=sha(base.ROM),source_changes=False,prior_ready_sha256=EXPECTED,
        preserved_negative=old_hashes,minimum_hold=8,unit='eligible policy input polls, not Main updates or PPU frames',
        controls=dict(wrapper_model_not_Lua_runtime=True,original_first_A_poll=358,original_mask=193,
                      extended_polls=[358,365],all_non_A_buttons_identical=True,reverse_telemetry_diff_exact=True),
        source_path=[str(R/'build/character-host-union-v13/src'/n) for n in ['game.s','player.s','reset.s','donkey_kong_core.s']],
        diagnosis='One input-poll A pulse; next poll releases while grounded. Source allows immediate catchup and saves AB per engine update. Prior endFrame trace does not locate exact consumption; no source-physics defect inferred.',
        telemetry=dict(hooks=cfg['input_hooks'],row_limit=120000,read_only=True,
                       main_counts='existing genuinely completed GameLoop count; main-return logs after increment',
                       input_selected='requested mask logged before setInput; latched RAM reflects the prior hardware read',
                       input_read_complete='genuine final RTS after eight serial controller bits; fixed125 clone verified'),
        unchanged=['ROM/CHR','default native jump','original 42px DK bounds','all original geometry/B/combat decisions',
                   'zero-death/1-1→25actual1-2/IRQ/NMI/DMA/CHR/SMC/stack/watchdog assertions','11000PPU/600hostsec/512MiB capture limits'],
        open=['native replay','first later climb/combat failure diagnosis','source powerup/ability qualification'])
    write(out/'preparation-controls.json',json.dumps(notes,indent=2)+'\n')
    for p,h in old_hashes.items(): assert sha(p)==h,p
    bindings=ready['bindings']
    bindings.update(old_hashes)
    for p in [Path(__file__).resolve(),out/'policy-min8.lua',out/'capture-min8.lua',out/'capture-diff.patch',
              out/'config.json',out/'run.lua',out/'preparation-controls.json',*[Path(p) for p in notes['source_path']]]:
        bindings[str(p)]=sha(p)
    ready.update(config=cfg,bindings=bindings,fixture_successor=True,
                 predecessor_native_negative_preserved=True,passive_input_telemetry=True,
                 minimum_A_hold_input_polls=8,scope=ready['scope']+' Minimum8poll A controller successor; no ROM changes.')
    write(out/'ready.json',json.dumps(ready,indent=2)+'\n')
    for p,h in bindings.items(): assert sha(p)==h,p
    print(json.dumps(dict(final_ready=str(out/'ready.json'),sha256=sha(out/'ready.json'),bindings=len(bindings),
                          ROM_sha256=sha(base.ROM),native_executed=False)))


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--launch',action='store_true')
    args=parser.parse_args()
    if args.launch:
        base.O=O
        base.launch('dk')
    else: prepare()
