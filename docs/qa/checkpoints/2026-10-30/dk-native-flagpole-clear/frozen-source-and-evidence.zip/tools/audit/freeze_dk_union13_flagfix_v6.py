"""Freeze exact DK source-only successor and existing-tail/source-consumer closure."""
from pathlib import Path
import json,sys
R=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import donkey_kong_host_controls_v1 as D
O=R/'build/dk-union13-flagfix-v6';P=R/'build/character-host-union-v13'


def main():
 assert not (O/'handoff.json').exists()
 controls=json.loads((O/'controls.json').read_text());reg=json.loads((O/'regressions.json').read_text())
 assert controls['passed']and reg['passed']
 old=D.scoped_load(P/'candidate.nes');b=D.scoped_load(O/'candidate/candidate.nes')
 base=D.location(old,'DkHostSide')-0x1ce6
 start=16+65*8192+0x1fd1;end=start+19
 assert base==16+65*8192 and old['raw'][start:base+8192]==bytes([255])*47
 names=[]
 for n,s in old['syms'].items():
  if 'seg'not in s or 'ooffs'not in old['segs'][s['seg']]:continue
  at=D.location(old,n)
  if start<=at<end:names.append(n)
 assert not names,('preexisting source labels in gate tail',names)
 cfg=(P/'union.cfg').read_text()
 assert 'DK_HOST_A65: start=$bc00,size=$0400' in cfg
 assert 'DONKEY_KONG_HOST:load=DK_HOST_A65,type=ro,start=$bc00' in cfg
 proto=[]
 count=D.address(old,'ProtoPoseRightHi')-D.address(old,'ProtoPoseRightLo')
 for face in ['Right','Left']:
  for k in range(count):
   ptr=old['raw'][D.location(old,'ProtoPose'+face+'Lo')+k]+256*old['raw'][D.location(old,'ProtoPose'+face+'Hi')+k]
   assert 0xc000<=ptr<0xdc00
   header=old['raw'][16+65*8192+ptr-0xc000]
   assert ptr+header+1<=D.address(old,'ProtoArtEnd')<=0xdc00
   proto.append([face,k,ptr,header])
 route=D.address(old,'DkHostFeetUnionRouter');assert route==0xbfb0 and int(old['syms']['DkHostFeetUnionRouter']['size'],0)==33
 a=D.location(old,'DkHostFeetUnionRouter');z=D.location(b,'DkHostFeetUnionRouter')
 assert old['raw'][a:a+33]==b['raw'][z:z+33]
 ownership=dict(physical=65,existing_private_DK_host_lease=['BC00','C000'],existing_cfg_declares1024B=True,
   old_segment_bytes=977,old_last_union_borrowed_feet_router=[route,route+33],borrowed_Gimmick_feet_all33bytes_exact=True,
   new_gate=['BFD1','BFE4'],new_gate_bytes=19,preexisting_actual_label_consumers_in_gate=names,
   changed_entry=['BCE6','BCE9'],all_other_parent_ROM_bytes_exact=True,old_true_scoped_labels_exact=True,
   legacy_C65_Proto_pointer_records=proto,legacy_C65_all_published_records_end_before_DC00=True,
   source_cap_after_gate996_of1024=True,remaining_owned_bytes=28,
   genuine_new_import='BlockBufferColli_Side; actual main.o already exports it; near target in permanent bank126',
   no_new_PRG_RAM_ZP_CHR_header_or_global_hooks=True)
 (O/'ownership.json').write_text(json.dumps(ownership,indent=2)+'\n')
 bindings={}
 for data in [controls,reg,reg['source_abilities'],reg['source_contacts']]:
  for p,h in data['bindings'].items():assert D.sha(p)==h,p;bindings[p]=h
 source=json.loads((O/'source-build.json').read_text())
 for p,h in source['inputs'].items():assert D.sha(p)==h,p;bindings[p]=h
 for p in [*O.rglob('*'),Path(__file__).resolve(),P/'handoff.json',P/'frozen-3f24a0e1.zip',
           R/'tools/audit/prepare_dk_union13_flagfix_v6.py',
           R/'build/dk-union13-facing-review-v3/handoff.json',
           R/'build/dk-union13-flagfix-v5/source-build.json',R/'build/dk-union13-flagfix-v5/controls.json']:
  if p.is_file():bindings[str(p)]=D.sha(p)
 handoff=dict(status='SOURCE_ABI_MAIN_ISR_FOREIGN_PASS_NATIVE_ROUTE_PENDING',candidate=str(O/'candidate/candidate.nes'),
   candidate_sha256=D.sha(O/'candidate/candidate.nes'),parent_sha256=D.sha(P/'candidate.nes'),bindings=bindings,
   actual_source_compiler_linker=True,manual_binary_patch=False,installation_ready=False,native_executed=False,
   changed_bytes=22,new_gate_bytes=19,existing_DK_host_bytes=996,existing_DK_host_cap=1024,
   source_CPU_endpoint='Genuine220-column1-1parser,fullMain+normalNMI,realflag4→5→1-2+25forwardupdates,zero deaths.',
   retained_negatives=['Original413missedA','1372vertical-lanepipe stop','1897missed-facing death','11000native flag4stall','v4flatteneddebuglabel checker','v5sourceengine5pole recatch'],
   open=['Exact07d5 nativecoldroutequalification','Nativeall-items/abilities','Hardnativeclear','two-playernativecampaign','fullcadence/audio completion'])
 (O/'handoff.json').write_text(json.dumps(handoff,indent=2)+'\n')
 for p,h in bindings.items():assert D.sha(p)==h,p
 print(json.dumps(dict(handoff=str(O/'handoff.json'),sha256=D.sha(O/'handoff.json'),bindings=len(bindings),candidate=handoff['candidate_sha256'])))


if __name__=='__main__':main()
