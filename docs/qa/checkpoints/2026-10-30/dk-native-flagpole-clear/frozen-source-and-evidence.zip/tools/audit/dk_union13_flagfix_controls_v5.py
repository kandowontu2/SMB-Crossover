"""Genuine source flag fix ABI, original-area parser/Main/NMI and ISR controls."""
from pathlib import Path
import itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(R/'tools/audit'),str(R/'tools'),str(R/'tools/reference')]
import donkey_kong_host_controls_v1 as D
O=R/'build/dk-union13-flagfix-v5';P=R/'build/character-host-union-v13'


def pole(b):
 q=D.setup(b);q.put(CrossoverBehaviorVersion=0,AreaPointer=37,WorldNumber=0,Hidden1UpFlag=1)
 D.run(q,'GetAreaDataAddrs')
 for j in range(3):q.set('AreaObjectLength',255,j)
 cols=[]
 for _ in range(220):
  D.run(q,'AreaParserCore');cols.append([q.get('MetatileBuffer',y)for y in range(13)]);D.run(q,'IncrementColumnPos')
 assert cols[198][:11]==[0x24]+[0x25]*9+[0x61]
 for x,col in enumerate(cols):
  for y,t in enumerate(col):q.m[D.address(b,'Block_Buffer_1')+((x//16)%2)*208+y*16+x%16]=t
 q.put(Player_PageLoc=12,Player_X_Position=89,Player_Y_Position=160,Player_State=3,Player_Y_Speed=0,
       Player_X_Speed=0,GameEngineSubroutine=4,Player_CollisionBits=255,Player_Rel_XPos=127,
       ScreenLeft_PageLoc=11,ScreenLeft_X_Pos=218,ScreenRight_PageLoc=12,ScreenRight_X_Pos=217,
       Player_Pos_ForScroll=127,SavedJoypadBits=0,Up_Down_Buttons=0,Left_Right_Buttons=0)
 return q


def state_writes(q):
 old=D.NesMPU.step;rows=[]
 def step(c):
  pc=c.pc;bank=q.m.banks[(pc-0x8000)//8192]if pc>=0x8000 else -1
  n=len(q.m.writes);before=q.get('Player_State');old(c)
  for at,v in q.m.writes[n:]:
   if at==D.address(q.b,'Player_State'):rows.append(dict(pc=pc,physical=bank,before=before,value=v,
       engine=q.get('GameEngineSubroutine'),y=q.get('Player_Y_Position'),tile=q.get('R3'),local_eb=q.get('Local_eb')))
 D.NesMPU.step=step
 try:c,tr,mn=D.M.C.M.runtrace(q,'GameLoop')
 finally:D.NesMPU.step=old
 return c,tr,mn,rows


def side(b,y,flags,engine,entry='DkHostSide'):
 q=D.setup(b);q.put(GameEngineSubroutine=engine,Player_X_Position=89,Player_PageLoc=12,Player_Y_Position=160,Local_eb=0)
 for n in ['Block_Buffer_1','Block_Buffer_2']:
  for i in range(208):q.m[D.address(b,n)+i]=[0,0x25,0x61,0x54][i%4]
 for i in range(8):q.set('R0',(i*17+83)&255,i)
 q.m.page(1,65);q.set('CurrentBank',193)
 c,w,_=D.run(q,entry,a=197,x=73,y=y,p=flags)
 return D.registers(c),bytes(q.m[:0x8000]),w,tuple(q.m.banks),c.processorCycles


def main():
 target=O/'controls.json';assert not target.exists()
 b=D.scoped_load(O/'candidate/candidate.nes');old=D.scoped_load(P/'candidate.nes');checks={}
 proof=dict(passed=False,source_CPU_only=True,native_executed=False,candidate=D.sha(O/'candidate/candidate.nes'),checks=checks)
 try:
  flags=[f for f in range(256)if f&0x30==0x30];deltas=[]
  for engine,y,f in itertools.product([5,7,8,9,11],range(3,7),flags):
   a=side(old,y,f,engine);z=side(b,y,f,engine)
   assert a[:4]==z[:4],('normal complete side ABI/orderedwrites',engine,y,f,a[0],z[0])
   deltas.append(z[-1]-a[-1])
  checks['normal_wide_side_64flags']=dict(cases=len(deltas),all_AXYP_SP_32KB_RAM_orderedwrites_maps_exact=True,CPU_delta=[min(deltas),max(deltas)])
  deltas=[]
  for y,f in itertools.product(range(3,7),flags):
   a=side(old,y,f,4,'BlockBufferColli_Side');z=side(b,y,f,4)
   assert a[:4]==z[:4],('engine4 genuine native side ABI/orderedwrites',y,f,a[0],z[0])
   deltas.append(z[-1]-a[-1])
  checks['engine4_actual_native_callback_64flags']=dict(cases=len(deltas),all_AXYP_SP_32KB_RAM_orderedwrites_maps_exact=True,CPU_delta=[min(deltas),max(deltas)],incoming_C_NZ_A_killed_by_genuine_source_before_use=True,V_D_I_preserved=True)
  negatives=[]
  for bundle,label in [(old,'parent'),(b,'successor')]:
   q=pole(bundle);c,tr,mn,writes=state_writes(q)
   assert q.get('Player_State')==(0 if label=='parent'else 3)
   assert (D.point(bundle,'PutPlayerOnVine')in tr)==(label=='successor')
   negatives.append(dict(case=label,final_state=q.get('Player_State'),writes=writes,
      reached={n:tr.count(D.point(bundle,n))for n in ['DkHostFeet','DkHostSide','BlockBufferColli_Side','PutPlayerOnVine','FlagpoleRoutine']}))
  checks['original220column_parser_first_state_writes']=dict(rows=negatives,original_flag_column198_24_25_base61=True,native_observed_start_X3161_Y160_state3_engine4=True)
  q=pole(b);transitions=[];last=None;controlled=0;first12=None;minimum=255;cost=[];nmis=[];seen=set()
  start_lives=q.get('NumberofLives')
  for age in range(1500):
   q.put(SavedJoypadBits=1,NmiDisable=255)
   c,tr,mn=D.M.C.M.runtrace(q,'GameLoop');minimum=min(minimum,mn);seen.update(tr);cost.append(c.processorCycles)
   nmis.append(D.M.T.nmi(q,c))
   state=tuple(q.get(n)for n in ['OperMode_Task','GameEngineSubroutine','AreaType','LevelNumber'])
   if state!=last:transitions.append([age,*state,q.get('Player_PageLoc')*256+q.get('Player_X_Position'),q.get('Player_Y_Position')]);last=state
   assert q.get('NumberofLives')==start_lives and q.get('GameEngineSubroutine')!=11
   if q.get('LevelNumber')==1 and q.get('AreaType')==2 and q.get('GameEngineSubroutine')==8:
    controlled+=1
    if first12 is None:first12=q.get('Player_PageLoc')*256+q.get('Player_X_Position')
   if controlled>=25:break
  assert controlled>=25,transitions
  assert q.get('Player_PageLoc')*256+q.get('Player_X_Position')>first12
  checks['real_Main_normal_NMI_flag_to25_underground']=dict(updates=age+1,controlled12=controlled,transitions=transitions,zero_deaths=True,
    Main_CPU=[min(cost),max(cost)],normal_NMI_CPU=[min(nmis),max(nmis)],minSP=minimum,
    reached={n:D.point(b,n)in seen for n in ['FlagpoleRoutine','PlayerEndLevel','InitializeArea','DkHostSide','BlockBufferColli_Side']},
    scope='Actual original parser and fullMain+normalNMI in staged CPU scene; no native route/PPU deadline claim.')
  # Existing real injection helper protects registers, stack, native aliases,
  # maps and SMC. Extra independent snapshots below include all33 live bytes.
  smc=json.loads((R/'build/dk-union13-facing-v3/dk/config.json').read_text())['smc_fields']
  assert len(smc)==33;events=[]
  for mode,kind in itertools.product([4,8],['NMI','IRQ']):
   q=pole(b)if mode==4 else D.setup(b)
   q.put(NmiDisable=255,SavedJoypadBits=0)
   original=D.NesMPU.step;hits=set()
   def step(c):
    here=(q.m.banks[(c.pc-0x8000)//8192]if c.pc>=0x8000 else -1,c.pc)
    if here[0]==65 and 0xbfd1<=here[1]<0xbfe0 and here not in hits:
     hits.add(here)
     def snap():return(c.pc,c.a,c.x,c.y,c.p,c.sp,tuple(q.m.banks),q.get('CurrentBank'),q.get('CurrentBankC'),bytes(q.m[a]for a in smc),bytes(q.m[:8]),bytes(q.m[0x101+c.sp:0x200]),bytes(q.m[0x5c00:0x6000]))
     before=snap()
     if kind=='IRQ':q.m[0x5204]=128;c.irq()
     else:c.nmi()
     for _ in range(60000):
      original(c)
      if c.pc==before[0]and c.sp==before[5]:break
     else:raise AssertionError(('ISRtimeout',kind,here))
     assert snap()==before,('gate actual ISR live contract',mode,kind,here)
    original(c)
   D.NesMPU.step=step
   try:D.M.C.M.runtrace(q,'GameLoop',p=0x30)
   finally:D.NesMPU.step=original
   assert hits
   events.append(dict(engine=mode,kind=kind,actual_points=sorted(hits),SMC_bytes=33))
  checks['actual_Main_gate_IRQ_lag_NMI_33SMC']=dict(rows=events,AXYP_SP_live_stack_R0_R7_ExRAM_maps_all33SMC_exact=True)
  proof['passed']=True
 except Exception as e:proof.update(failure=repr(e),traceback=traceback.format_exc())
 paths={Path(__file__).resolve(),O/'source-build.json',O/'candidate/candidate.nes',O/'candidate/candidate.dbg',O/'candidate/candidate.lbl',P/'candidate.nes',P/'candidate.dbg',P/'candidate.lbl'}
 for module in list(sys.modules.values()):
  p=getattr(module,'__file__',None)
  if p and Path(p).resolve().is_relative_to(R/'tools'):paths.add(Path(p).resolve())
 proof['bindings']={str(p):D.sha(p)for p in sorted(paths)if p.is_file()}
 target.write_text(json.dumps(proof,indent=2)+'\n')
 print(json.dumps(dict(passed=proof['passed'],failure=proof.get('failure'),checks=list(checks),receipt=str(target),sha256=D.sha(target))))
 assert proof['passed']


if __name__=='__main__':main()
