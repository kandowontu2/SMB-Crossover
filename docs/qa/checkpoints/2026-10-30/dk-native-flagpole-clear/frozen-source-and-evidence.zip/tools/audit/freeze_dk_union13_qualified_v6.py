"""Freeze exact native DK route, complete PPU checksum review and source handoff."""
from pathlib import Path
import csv,json,sys
R=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(R/'tools/audit')]
from current_roster_compact_11_v1 import linked
from prepare_union13_remaining_routes_v1 import sha
P=R/'build/dk-union13-flagfix-native-v6/dk';S=R/'build/dk-union13-flagfix-v6';O=R/'build/dk-union13-qualified-v6'


def main():
 assert not O.exists()
 ready=json.loads((P/'ready.json').read_text());source=json.loads((S/'handoff.json').read_text())
 assert sha(P/'ready.json')=='ab6a59e2c104297c57c3c5123ac5a9b74ba02fdaa0e6f69eccefea5d9c792436'
 assert sha(S/'handoff.json')=='0e363371e9257bc55ddf7dea5e22506faca97b929de726168ec3816e655f4521'
 for data in [ready,source]:
  for p,h in data['bindings'].items():assert sha(p)==h,p
 result=json.loads((P/'result.json').read_text());binding=json.loads((P/'binding.json').read_text());ppu=json.loads((P/'capture-review.json').read_text())
 assert binding['exit_code']==0 and result['passed']and result['zero_deaths']and result['frames']==4000
 assert result['real_1_2_control_updates']==25 and result['lives']['decreased']==0
 assert result['ROM_sha256']==source['candidate_sha256']=='07d5ca6530b8ae984d8da6765f8c90c4b1d9a6653c95e07184c32e4065f2e85f'
 assert ppu['passed'] and ppu['full_frames']==3330 and ppu['decoded_full_sha256']=='9eac1efe67807c7e9bda76ca9681be5ea972c9ff47b781ff2d64e79b8c19bd50'
 rows=list(csv.DictReader((P/'input-consumption.csv').open()));main=[q for q in rows if q['kind']=='main-return']
 pole=[q for q in main if q['engine']=='4'];assert len(pole)==62 and all(q['state']=='3'for q in pole)
 underground=[q for q in main if q['level']=='1'and q['engine']=='8'];assert len(underground)==25
 assert int(underground[-1]['x'])>int(underground[0]['x'])
 writes=list(csv.DictReader((P/'state-writes.csv').open()));reattach=[q for q in writes if q['engine']=='4'and q['value']=='3']
 assert reattach and all(q['R3']=='37'for q in reattach)
 raw,syms,address,location,hook=linked(S/'candidate/candidate.nes')
 state_address=address('Player_State')
 for q in reattach:
  pc=int(q['callbackPC'])-2;physical=int(q['physical']);at=16+physical*8192+(pc&8191)
  assert raw[at:at+2]==bytes([0x85,state_address])
  assert pc==address('PutPlayerOnVine')+2
 O.mkdir()
 report=dict(native_route_pass=True,exact_candidate=source['candidate_sha256'],source_handoff=str(S/'handoff.json'),
  native_fixture=str(P/'ready.json'),native_result=result,
  full_PPU=dict(checksum_pass=True,frames=3330,decoded_bytes=ppu['decoded_full_bytes'],decoded_sha256=ppu['decoded_full_sha256'],
                container_bytes=ppu['container_bytes'],reviewed_sheet=str(P/'selected-whole-frames.png'),actual_whole_frames=[86,266,1700,1800,2750,2820,3200,4000],
                view='Viewed8wholehardwareframes: overworld blue, genuine DK barrel combat, flag/exit, actual1-2 underground body/scene. Native oldV13 menu retains its preexistingcyan band; menu bytes unchanged by this source repair.'),
  native_flag_handoff=dict(engine4_completedMain=len(pole),all_return_state3=True,actual_native_shaft_tile=37,
      native_reattach_writes=len(reattach),source_writer=hook('PutPlayerOnVine',offset=2),
      callback_PC_contract='Mesen memory-write callback PC follows2-byte STA zp; independently decoded actual85/1E at callbackPC-2.',
      first_reattach=reattach[0],real12_first=underground[0],real12_last=underground[-1],gate_entries=sum(q['kind']=='pole-side-gate'for q in rows)),
  source_only_powerup_abilities=dict(receipt=str(S/'abilities/controls.json'),pickup144=True,star_delayed1Up12=True,B_edges_capacity_down24=True,lifecycle2=True,
                                   contacts108=str(S/'contacts/controls.json'),source_roll_updates=48),
  source_changes=dict(own_entry_bytes=3,own_gate_bytes=19,owned_DK_A65_lease=['BC00','C000'],used=996,capacity=1024,
                      native_side_only_for_automatic_engine=[4,5],normal42px_DK_collision_preserved=True,all_other_ROM_bytes_exact=True,
                      source_patch=str(S/'candidate/source.patch'),source=str(S/'candidate/src/donkey_kong_host.s'),new_import='BlockBufferColli_Side',
                      genuine_source_build=True,no_new_global_RAM_ZP_PRG_CHR_or_header=True),
  retained_negatives=[str(R/'build/dk-union13-min8-review-v1/handoff.json'),str(R/'build/dk-union13-los-review-v2/handoff.json'),
     str(R/'build/dk-union13-facing-review-v3/handoff.json'),str(R/'build/dk-union13-flagfix-v4/checker-negative.json'),str(R/'build/dk-union13-flagfix-v5/controls.json')],
  shared_modified=False,Downloads_modified=False,native_queue_released=True,
  limits=['NativeEasy1-1→25real1-2 proved only for private07d5; original3f24 retains genuineflaghandoff defect.',
          'Nativeall-items/allabilities/Hard/two-playercampaign/fullcadence/audio completion remain open.',
          'Source/publicpowerup/ability/contact cases are explicitly staged6502CPU controls, not native item claims.',
          'ParentV13 menucyan band remains outside this gate-only repair; rebase into genuine joint source/qualified frontend still required.',
          'No shared installation or current-all-profile/nativeadmission claim.'])
 (O/'review.json').write_text(json.dumps(report,indent=2)+'\n')
 bindings={**ready['bindings'],str(S/'handoff.json'):sha(S/'handoff.json')}
 for p in [*P.iterdir(),Path(__file__).resolve(),O/'review.json']:
  if p.is_file():bindings[str(p)]=sha(p)
 for p in report['retained_negatives']:bindings[p]=sha(p)
 handoff=dict(status='FROZEN_PRIVATE_DK_EASY_NATIVE_ROUTE_SOURCE_CONTROLS_PASS_JOINT_REBASE_PENDING',candidate=source['candidate'],
   candidate_sha256=source['candidate_sha256'],bindings=bindings,native_route_pass=True,source_CPU_controls_pass=True,
   zero_deaths=True,real1_2_updates=25,installed=False,shared_modified=False,source_lease_unchanged=True,
   limits=report['limits'],source_patch=report['source_changes']['source_patch'])
 (O/'handoff.json').write_text(json.dumps(handoff,indent=2)+'\n')
 for p,h in bindings.items():assert sha(p)==h,p
 print(json.dumps(dict(handoff=str(O/'handoff.json'),sha256=sha(O/'handoff.json'),bindings=len(bindings),candidate=source['candidate_sha256'])))


if __name__=='__main__':main()
