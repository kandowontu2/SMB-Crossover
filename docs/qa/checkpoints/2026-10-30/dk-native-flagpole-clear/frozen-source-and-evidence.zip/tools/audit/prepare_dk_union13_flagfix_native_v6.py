"""Fresh exact-source DK flag successor native fixture; root grant required to launch."""
from pathlib import Path
import argparse,copy,difflib,json,sys
R=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import prepare_union13_remaining_routes_v1 as B
from current_roster_compact_11_v1 import linked,lua
P=R/'build/dk-union13-facing-v3/dk'
S=R/'build/dk-union13-flagfix-v6/handoff.json'
ROM=S.parent/'candidate/candidate.nes'
O=R/'build/dk-union13-flagfix-native-v6'

OBSERVER="""-- BEGIN DK_PASSIVE_STATE_WRITES_V6
local stateRows=0
local stateLog=file('state-writes.csv','poll,frame,cpuCycle,callbackPC,physical,before,value,engine,x,y,probeIndex,probeDX,probeDY,R2,R3,R4,R6,R7,localEb,opMinus3,opMinus2,opMinus1')
emu.addMemoryCallback(function(_,v)
 if done or r('SelectedCharacter')~=28 then return end
 stateRows=stateRows+1;assert(stateRows<=100000,'Bounded passive native state writes')
 local s=emu.getState();local pc=s['cpu.pc']
 stateLog:write(table.concat({polls,frame,s['cpu.cycleCount'],pc,bank(pc),r('Player_State'),v,
  r('GameEngineSubroutine'),pos('Player_X_Position','Player_PageLoc'),r('Player_Y_Position'),
  r('DkProbeIndex'),r('DkProbeDX'),r('DkProbeDY'),r('R2'),r('R3'),r('R4'),r('R6'),r('R7'),r('Local_eb'),
  emu.read(pc-3,emu.memType.nesDebug),emu.read(pc-2,emu.memType.nesDebug),emu.read(pc-1,emu.memType.nesDebug)},',')..'\\n')
 if stateRows%128==0 or r('GameEngineSubroutine')==4 or r('GameEngineSubroutine')==5 then stateLog:flush()end
end,emu.callbackType.write,L.Player_State)
-- END DK_PASSIVE_STATE_WRITES_V6
"""


def prepare():
 assert not O.exists() and B.sha(P/'ready.json')=='32f75fffc1ce261da28c6c6b941d21313bd21c47d85dac40c125daf825cb8d07'
 assert B.sha(S)=='0e363371e9257bc55ddf7dea5e22506faca97b929de726168ec3816e655f4521'
 old=json.loads((P/'ready.json').read_text());source=json.loads(S.read_text())
 for data in [old,source]:
  for p,h in data['bindings'].items():assert B.sha(p)==h,p
 assert B.sha(ROM)==source['candidate_sha256']=='07d5ca6530b8ae984d8da6765f8c90c4b1d9a6653c95e07184c32e4065f2e85f'
 out=O/'dk';out.mkdir(parents=True);cfg=copy.deepcopy(old['config'])
 cfg.update(out=out.as_posix()+'/',prefix=out.as_posix()+'/',policy=(out/'policy-min8.lua').as_posix(),
            original_policy=(out/'policy-los.lua').as_posix(),ROM_sha256=B.sha(ROM))
 for n in ['policy-min8.lua','policy-los.lua']:(out/n).write_bytes((P/n).read_bytes())
 raw,syms,address,location,hook=linked(ROM)
 for table in ['hooks','input_hooks']:
  for key,h in cfg[table].items():
   q=hook(h['name'],offset=h['pc']-address(h['name']))
   assert q=={k:v for k,v in h.items()if k!='banks'},('Changed preexisting fixture hook',key,q,h)
 cfg['input_hooks']['pole-side-gate']=hook('DkFlagSideGate')
 for n in ['DkProbeIndex','DkProbeDX','DkProbeDY']:
  assert syms[n]['type']=='equ' and 0x5c00<=address(n)<0x5cc3;cfg['extra_ram'][n]=address(n)
 assert cfg['dk_tile_attributes']==list(raw[location('MTileAttribute'):location('MTileAttribute')+256])
 capture=(P/'capture-min8.lua').read_text()
 before="'weapons-return'})do";assert capture.count(before)==1
 capture=capture.replace(before,"'weapons-return','pole-side-gate'})do")
 marker='-- END DK_LIVE_POLICY_GEOMETRY_V2\n';assert capture.count(marker)==1
 capture=capture.replace(marker,marker+OBSERVER)
 (out/'capture-min8.lua').write_text(capture,newline='\n')
 (out/'capture-diff.patch').write_text(''.join(difflib.unified_diff((P/'capture-min8.lua').read_text().splitlines(True),capture.splitlines(True),
       fromfile=(P/'capture-min8.lua').as_posix(),tofile=(out/'capture-min8.lua').as_posix())),newline='\n')
 (out/'config.json').write_text(json.dumps(cfg,indent=2)+'\n')
 (out/'run.lua').write_text('ROSTER_CONFIG='+lua(cfg)+'\n'+
  'for name,value in pairs(ROSTER_CONFIG.extra_ram)do assert(L[name]==nil or L[name]==value,"RAM alias conflict: "..name);L[name]=value end\n'+
  'dofile('+lua((out/'capture-min8.lua').as_posix())+')\n',newline='\n')
 bindings={**old['bindings'],**source['bindings'],str(S):B.sha(S),str(P/'ready.json'):B.sha(P/'ready.json')}
 for p in [Path(__file__).resolve(),*out.iterdir()]:
  if p.is_file():bindings[str(p)]=B.sha(p)
 ready={**old,'ROM_sha256':B.sha(ROM),'config':cfg,'bindings':bindings,'source_changes':True,
   'source_handoff':str(S),'source_handoff_sha256':B.sha(S),'native_run':False,
   'preserved_native_negative':str(R/'build/dk-union13-facing-review-v3/handoff.json'),
   'source_delta':'Only ownDK side-entry3B+gate19B; engine4/5 delegates genuine native side,42px normalcollision preserved.',
   'scope':'Exact source07d5 coldEasy menu/lives/controller1-1→25real1-2 zero-death. All prior assertions unchanged; added passive gate and state-write callback PC/value/probe telemetry. No native all-items/Hard/cadence claim.'}
 (out/'ready.json').write_text(json.dumps(ready,indent=2)+'\n')
 for p,h in bindings.items():assert B.sha(p)==h,p
 print(json.dumps(dict(ready=str(out/'ready.json'),sha256=B.sha(out/'ready.json'),bindings=len(bindings),native_executed=False,candidate=B.sha(ROM))))


if __name__=='__main__':
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--launch',action='store_true');a=parser.parse_args()
 if a.launch:B.O=O;B.ROM=ROM;B.launch('dk')
 else:prepare()
