"""Genuine DK component compile/link successor in existing private host1KB lease."""
from pathlib import Path
import difflib,hashlib,json,re,subprocess,sys
R=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
from current_roster_compact_11_v1 import linked
from prepare_cv3_dmc_mirror import prepare as mirror
P=R/'build/character-host-union-v13';O=R/'build/dk-union13-flagfix-v5'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()


def write(p,s):
 p=p.resolve();assert p.is_relative_to(O.resolve()) and p!=O.resolve()
 p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,newline='\n')


def true_symbols(path):
 scopes={};symbols=[]
 for line in path.with_suffix('.dbg').read_text().splitlines():
  if not line.startswith(('scope\t','sym\t')):continue
  q=dict(x.split('=',1)for x in line.split('\t',1)[1].split(',')if '='in x)
  if line.startswith('scope\t'):scopes[q['id']]=q
  elif 'val'in q:symbols.append(q)
 def prefix(i):
  q=scopes.get(i,{})
  return '::'.join(x for x in [(prefix(q['parent'])if'parent'in q else ''),q.get('name','').strip('"')]if x)
 result={}
 for q in symbols:
  n='::'.join(x for x in [prefix(q.get('scope')),q['name'].strip('"')]if x)
  result[n]=int(q['val'],0)
 return result


def build(d,fix=False):
 d.mkdir();(d/'src').mkdir()
 for n in ['donkey_kong_core.s','donkey_kong_render.s','donkey_kong_host.s','donkey_kong_state.inc']:
  write(d/'src'/n,(P/'src'/n).read_text())
 for n in ['dk-component.s','dk-imports.inc','dk-p0-art.inc','union.cfg']:
  write(d/n,(P/n).read_text())
 source=(d/'src/donkey_kong_host.s').read_text()
 if fix:
  before='.proc DkHostSide\n sty DkProbeIndex\n'
  after='.proc DkHostSide\n jmp DkFlagSideGate\n::DkHostSideWide:\n'
  assert source.count(before)==1;source=source.replace(before,after)
  gate='''.export DkFlagSideGate,DkHostSideWide
; Native pole snap places the shaft inside DK's42px outer side probes.
; Only the genuine automatic flag-slide state needs original native probes.
; Native BlockBufferColli_Side and wide-side bodies overwrite incomingA/NZ/C
; before use; source differential controls separately prove all64live flags.
.proc DkFlagSideGate
 lda GameEngineSubroutine
 cmp #4
 bne Wide
 jmp BlockBufferColli_Side
Wide:
 sty DkProbeIndex
 jmp DkHostSideWide
.endproc
'''
  marker='.assert *<=$c000,lderror,"Existing DK host1024B cap"'
  assert source.count(marker)==1;source=source.replace(marker,gate+marker)
  write(d/'src/donkey_kong_host.s',source)
  write(d/'dk-imports.inc',(d/'dk-imports.inc').read_text()+'.import BlockBufferColli_Side\n')
  old=(P/'src/donkey_kong_host.s').read_text()
  write(d/'source.patch',''.join(difflib.unified_diff(old.splitlines(True),source.splitlines(True),
      fromfile=(P/'src/donkey_kong_host.s').as_posix(),tofile=(d/'src/donkey_kong_host.s').as_posix())))
 commands=json.loads((P/'build-proof.json').read_text())['commands']
 compile_=next(c[:] for c in commands if c[-1]==str(P/'dk-component.s'))
 compile_[1:1]=['-I',str(d/'src'),'-I',str(d)]
 for flag,name in [('--create-full-dep','dk-component.d'),('-o','dk-component.o')]:
  compile_[compile_.index(flag)+1]=str(d/name)
 compile_[-1]=str(d/'dk-component.s')
 link=commands[-1][:]
 for flag,name in [('-C','union.cfg'),('-Ln','candidate.lbl'),('-o','candidate.nes'),('-m','candidate.map')]:
  link[link.index(flag)+1]=str(d/name)
 index=link.index('--ld-args')+1
 assert link[index]=='--dbgfile,'+str(P/'candidate.dbg')
 link[index]='--dbgfile,'+str(d/'candidate.dbg')
 link[link.index(str(P/'dk-component.o'))]=str(d/'dk-component.o')
 # The unchanged real objects are read-only dependencies, validated by a whole
 # exact-preimage replay before any changed source is linked. No symbol aliases.
 for c in [compile_,link]:
  for flag in ['--create-full-dep','-o','-Ln','-m']:
   if flag in c:assert Path(c[c.index(flag)+1]).resolve().is_relative_to(O.resolve())
  for v in c:
   if v.startswith('--dbgfile,'):assert Path(v.split(',',1)[1]).resolve().is_relative_to(O.resolve())
 with (d/'build.log').open('w')as log:
  for c in [compile_,link]:
   result=subprocess.run(c,cwd=R,text=True,capture_output=True)
   log.write(subprocess.list2cmdline(c)+'\n'+result.stdout+result.stderr+'\n');log.flush()
   assert result.returncode==0,(d,result.stdout,result.stderr)
 receipt=mirror(R,d/'candidate.nes')
 write(d/'commands.json',json.dumps([compile_,link],indent=2)+'\n')
 return receipt


def main():
 assert not O.exists() and sha(P/'candidate.nes')=='3f24a0e1bc73d8655811b333aa52285ace1af5e469fcc7b6158b06afce54f72c'
 frozen=json.loads((P/'handoff.json').read_text())
 # Verify the actual source closure; archived gameplay receipts need no replay.
 for p,h in frozen['bindings'].items():
  if Path(p).suffix in ['.s','.inc','.cfg','.py','.chr','.bin']:assert sha(p)==h,p
 inputs={str(p):sha(p)for p in [P/'candidate.nes',P/'candidate.dbg',P/'candidate.lbl',P/'handoff.json',P/'build-proof.json',Path(__file__).resolve()]}
 commands=json.loads((P/'build-proof.json').read_text())['commands']
 for c in commands:
  for p in c:
   if Path(p).is_file() and Path(p).suffix in ['.exe','.o','.cfg','.s','.inc']:inputs[str(Path(p).resolve())]=sha(p)
 O.mkdir();build(O/'replay')
 assert sha(O/'replay/candidate.nes')==sha(P/'candidate.nes'),'Exact unchanged DK source compile/link preimage replay required'
 build(O/'candidate',True)
 a,sa,aa,la,ha=linked(P/'candidate.nes');b,sb,ab,lb,hb=linked(O/'candidate/candidate.nes')
 oldsymbols=true_symbols(P/'candidate.nes');newsymbols=true_symbols(O/'candidate/candidate.nes')
 for n,value in oldsymbols.items():
  assert n in newsymbols and value==newsymbols[n],('Old genuine scoped symbol moved/missing',n,value,newsymbols.get(n))
 assert ab('DkFlagSideGate')==0xbfd1 and ab('DkHostSideWide')==aa('DkHostSide')+3
 size=int(sb['DkFlagSideGate']['size'],0);assert size==15
 lo=lb('DkFlagSideGate');at=la('DkHostSide');diff=[i for i,(x,y)in enumerate(zip(a,b))if x!=y]
 assert len(a)==len(b) and set(diff)==set(range(at,at+3))|set(range(lo,lo+size))
 assert a[lo:lo+47]==bytes([255])*47 and lo+size<=16+66*8192
 for p,h in inputs.items():assert sha(p)==h,p
 proof=dict(status='SOURCE_LINKED_CANDIDATE_CPU_NATIVE_PENDING',ROM_sha256=sha(O/'candidate/candidate.nes'),parent_ROM_sha256=sha(P/'candidate.nes'),
   unchanged_DK_source_replay_exact=True,unchanged_objects_preimage_relinked=True,source_manual_binary_patch=False,
   gate=hb('DkFlagSideGate'),gate_bytes=size,entry=hb('DkHostSide'),resumption=hb('DkHostSideWide'),
   native_callback=hb('BlockBufferColli_Side'),actual_new_import='BlockBufferColli_Side; existing genuine main.o export',
   old_symbol_PCs_preserved=True,physical=65,owned_lease=['BC00','C000'],old_bytes=977,new_bytes=992,remaining_bytes=32,
   exact_changed_offsets=diff,all_other_ROM_bytes_including125_127_CHR_exact=True,PRG_RAM_ZP_lease_expansion=False,
   inputs=inputs,scope='Source-linked private successor only. Source ABI/Main/ISR controls and native endpoint still required.')
 write(O/'source-build.json',json.dumps(proof,indent=2)+'\n')
 print(json.dumps(dict(candidate=proof['ROM_sha256'],proof=str(O/'source-build.json'),gate_bytes=size,changed_bytes=len(diff))))


if __name__=='__main__':main()
