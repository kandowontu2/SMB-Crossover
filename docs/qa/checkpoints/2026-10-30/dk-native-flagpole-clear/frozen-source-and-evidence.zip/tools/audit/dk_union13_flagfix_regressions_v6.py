"""Actual candidate source ability/contact reruns plus exact foreign fullMain."""
from pathlib import Path
import itertools,json,subprocess,sys
R=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(R/'tools/audit'),str(R/'tools'),str(R/'tools/reference')]
import donkey_kong_host_controls_v1 as D
O=R/'build/dk-union13-flagfix-v6';ROM=O/'candidate/candidate.nes';P=R/'build/character-host-union-v13/candidate.nes'


def main():
 target=O/'regressions.json';assert not target.exists()
 h=D.sha(ROM);assert h=='07d5ca6530b8ae984d8da6765f8c90c4b1d9a6653c95e07184c32e4065f2e85f'
 for name,stem in [('abilities','ability'),('contacts','contact')]:
  path=R/f'tools/audit/dk_union13_{stem}_controls_v1.py';source=path.read_text()
  source=source.replace(f"O=R/'build/dk-union13-{name}-cpu-v1'",f"O=R/'build/dk-union13-flagfix-v6/{name}'")
  source=source.replace("ROM=R/'build/character-host-union-v13/candidate.nes'","ROM=R/'build/dk-union13-flagfix-v6/candidate/candidate.nes'")
  source=source.replace('3f24a0e1bc73d8655811b333aa52285ace1af5e469fcc7b6158b06afce54f72c',h)
  script=O/(name+'-controls.py');assert not script.exists();script.write_text(source,newline='\n')
  subprocess.run([sys.executable,str(script)],cwd=R,check=True)
 old,b=D.scoped_load(P),D.scoped_load(ROM)
 fields={0:'MarioVariant',1:'ProtoVariant',3:'BillVariant',4:'Z2Variant',5:'Cv3Variant',6:'PitVariant',12:'DarkwingVariant',9:'RlVariant',
         13:'KbVariant',14:'CdVariant',15:'MacVariant',17:'M3Variant',18:'VvVariant',19:'TnVariant',20:'IcVariant',21:'RcVariant'}
 counts={0:5,1:2,2:1,3:2,4:2,5:4,6:2,7:1,9:2,10:1,11:1,12:2,13:2,14:2,15:3,16:1,17:2,18:4,19:4,20:2,21:2,23:1}
 identities=[(ch,v)for ch,n in counts.items()for v in range(n)]+[(24,0),(26,0)]
 assert len(identities)==50
 rows=[]
 for (ch,var),mode,keys in itertools.product(identities,range(2),[0,1,129]):
  raw=8 if(ch,var)==(0,1)else ch;pair=[]
  for bundle in [old,b]:
   q=D.M.C.setup(bundle,raw);q.put(CrossoverBehaviorVersion=mode,SavedJoypadBits=keys)
   if ch in fields:
    if fields[ch]=='PitVariant':q.m[0x5fe0]=var
    else:q.set(fields[ch],var)
   c,tr,mn=D.M.C.M.runtrace(q,'GameLoop',p=0x71)
   pair.append((D.registers(c),bytes(q.m[:0x8000]),list(q.m.writes),tuple(q.m.banks),c.processorCycles,mn))
  assert pair[0]==pair[1],('foreign entireMain/orderedwrites/CPU',ch,var,mode,keys)
  rows.append([ch,var,mode,keys,pair[1][-2],pair[1][-1]])
 proof=dict(passed=True,source_CPU_only=True,native_executed=False,candidate=h,
   foreign=dict(cases=len(rows),profiles=50,full_AXYP_SP_32KB_RAM_including_page1_all_orderedwrites_maps_CPU_exact=True,CPU_delta=[0,0],rows=rows),
   source_abilities=json.loads((O/'abilities/controls.json').read_text()),source_contacts=json.loads((O/'contacts/controls.json').read_text()))
 paths={Path(__file__).resolve(),ROM,ROM.with_suffix('.dbg'),ROM.with_suffix('.lbl'),P,P.with_suffix('.dbg'),P.with_suffix('.lbl'),
        O/'abilities-controls.py',O/'contacts-controls.py',O/'abilities/controls.json',O/'contacts/controls.json'}
 for module in list(sys.modules.values()):
  path=getattr(module,'__file__',None)
  if path and Path(path).resolve().is_relative_to(R/'tools'):paths.add(Path(path).resolve())
 proof['bindings']={str(p):D.sha(p)for p in sorted(paths)if p.is_file()}
 target.write_text(json.dumps(proof,indent=2)+'\n')
 print(json.dumps(dict(passed=True,foreign_cases=len(rows),receipt=str(target),sha256=D.sha(target))))


if __name__=='__main__':main()
