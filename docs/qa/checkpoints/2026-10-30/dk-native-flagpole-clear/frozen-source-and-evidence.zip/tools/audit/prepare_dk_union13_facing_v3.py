"""Controller-only DK successor: await real serial-input/source-facing acknowledgement."""
from pathlib import Path
import argparse,difflib,json,sys
R=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import prepare_dk_union13_los_v2 as V
from current_roster_compact_11_v1 import linked,lua
O=R/'build/dk-union13-facing-v3'
P=R/'build/dk-union13-los-review-v2/handoff.json'
OLD=R/'build/dk-union13-los-v2/dk'


def prepare():
 assert not O.exists() and V.M.sha(P)=='91c0e6c41399c8773313ad076e5f8b17bc409a1dc43d778879463e53c4c89887'
 frozen=json.loads(P.read_text())
 for p,h in frozen['bindings'].items():assert V.M.sha(p)==h,p
 V.O=O;V.prepare();out=O/'dk';ready=json.loads((out/'ready.json').read_text());cfg=ready['config']
 p=out/'policy-los.lua';source=p.read_text()
 old="if combat=='face' then combat='throw';return{}end"
 new="""if combat=='face' then
  -- A requested poll is not proof of a serial read or a completed native turn.
  if c.r('SavedJoypad1Bits')&1==0 or c.r('PlayerFacingDir')~=1 then return{right=true}end
  combat='throw';return{}
 end"""
 assert source.count(old)==1
 policy=source.replace(old,new);assert policy.replace(new,old)==source
 V.M.write(p,policy)
 prior=(OLD/'policy-los.lua').read_text();assert source==prior
 V.M.write(out/'facing-policy.patch',''.join(difflib.unified_diff(prior.splitlines(True),policy.splitlines(True),
                    fromfile=(OLD/'policy-los.lua').as_posix(),tofile=p.as_posix())))
 # Keep a complete diff against the genuine frozen original v3 controller as well.
 orig=R/'build/dk-admission-route-v3/policy-v3.lua'
 V.M.write(out/'policy-los.patch',''.join(difflib.unified_diff(orig.read_text().splitlines(True),policy.splitlines(True),
                    fromfile=orig.as_posix(),tofile=p.as_posix())))
 raw,syms,address,location,hook=linked(V.M.base.ROM)
 cfg['input_hooks']['weapons-entry']=hook('DkHostWeapons')
 cfg['input_hooks']['weapons-return']=hook('DkHostWeapons',tail=True)
 for n in ['DkSpawn','DkShots']:
  assert syms[n]['type']=='equ' and 0x5c00<=address(n)<0x5cc3
  cfg['extra_ram'][n]=address(n)
 cap=out/'capture-min8.lua';capture=cap.read_text()
 before='dkTier,x,y,yHigh,state'
 after='dkTier,facing,spawn,shot0type,shot0x,shot0y,shot0facing,shot1type,shot1x,shot1y,shot1facing,shot2type,shot2x,shot2y,shot2facing,x,y,yHigh,state'
 assert capture.count(before)==1;capture=capture.replace(before,after)
 before="r('DkPrevious'),r('DkFresh'),r('DkAttack'),r('DkAge'),r('DkTier'),\n"
 after=before+"  r('PlayerFacingDir'),r('DkSpawn'),\n"+''.join(
  "  r('DkShots',%d),r('DkShots',%d)+256*r('DkShots',%d),r('DkShots',%d),r('DkShots',%d),\n"%(n,n+4,n+5,n+6,n+7)
  for n in [0,12,24])
 assert capture.count(before)==1;capture=capture.replace(before,after)
 before="'catchup-entry'})do";after="'catchup-entry','weapons-entry','weapons-return'})do"
 assert capture.count(before)==1;capture=capture.replace(before,after)
 V.M.write(cap,capture)
 V.M.write(out/'capture-diff.patch',''.join(difflib.unified_diff(V.M.SCRIPT.read_text().splitlines(True),capture.splitlines(True),
                    fromfile=V.M.SCRIPT.as_posix(),tofile=cap.as_posix())))
 V.M.write(out/'config.json',json.dumps(cfg,indent=2)+'\n')
 V.M.write(out/'run.lua','ROSTER_CONFIG='+lua(cfg)+'\n'+
   'for name,value in pairs(ROSTER_CONFIG.extra_ram)do assert(L[name]==nil or L[name]==value,"RAM alias conflict: "..name);L[name]=value end\n'+
   'dofile('+lua(cap.as_posix())+')\n')
 controls=dict(prepared_only=True,native_executed=False,source_modified=False,unchanged_ROM=V.M.sha(V.M.base.ROM),
   preserved_negative=str(P),change='Face phase keeps ordinary right input until both genuine SavedJoypad1Bits right and PlayerFacingDir1 are observed, then releases for the existing throw phase.',
   exact_failed_pulse=dict(request_poll=1687,requested_mask=1,no_serial_read=True,next_poll=1688,next_latched_mask=0),
   source_controls='Bound predecessor review includes47 genuine fullMain CPU updates proving once-per-update weapons and correct direction from source-facing.',
   offline_ack_truth_table=[dict(saved=s,facing=f,hold_right=not(s&1 and f==1))for s,f in [(0,2),(1,2),(0,1),(1,1)]],
   telemetry=dict(new_actual_hooks=cfg['input_hooks'],fields='Source PlayerFacingDir, pending spawn and all3 complete shot type/worldX/Y/direction, at actual Main/physics/input/weapons entry+return.',
                  bounded_rows=120000,read_only=True),
   preserved=['8pollminimumA','source vertical lane','actualROM MTileAttribute/liveblock LOS','original travel/jump/42pxbody','B pattern/sourceattack','zero-death/300stationary/1-1+25real1-2/all native guards','11000PPU/600hostsec/512MiB'],
   claim='Controller prep only; no route/native all-items/Hard/completion claim.')
 V.M.write(out/'facing-controls.json',json.dumps(controls,indent=2)+'\n')
 bindings=ready['bindings'];bindings[str(P)]=V.M.sha(P)
 for p,h in frozen['bindings'].items():
  if Path(p).is_relative_to(OLD) or Path(p).is_relative_to(P.parent):bindings[p]=h
 for p in [Path(__file__).resolve(),out/'policy-los.lua',out/'policy-los.patch',out/'facing-policy.patch',out/'capture-min8.lua',
           out/'capture-diff.patch',out/'config.json',out/'run.lua',out/'facing-controls.json']:
  bindings[str(p)]=V.M.sha(p)
 ready.update(config=cfg,bindings=bindings,actual_facing_ack_controller_successor=True,
    scope=ready['scope']+' Face-right waits for real serial byte and native facing acknowledgement; passive shot telemetry.')
 V.M.write(out/'ready.json',json.dumps(ready,indent=2)+'\n')
 for p,h in bindings.items():assert V.M.sha(p)==h,p
 print(json.dumps(dict(final_ready=str(out/'ready.json'),sha256=V.M.sha(out/'ready.json'),bindings=len(bindings),native_executed=False)))


if __name__=='__main__':
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--launch',action='store_true');args=parser.parse_args()
 if args.launch:V.M.base.O=O;V.M.base.launch('dk')
 else:prepare()
