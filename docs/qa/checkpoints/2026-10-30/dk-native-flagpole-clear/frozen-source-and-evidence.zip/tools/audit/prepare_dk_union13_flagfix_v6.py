"""Extend the genuine native pole side contract through automatic engine5 exit."""
from pathlib import Path
import difflib,json,subprocess,sys
R=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import prepare_dk_union13_flagfix_v4 as M
from current_roster_compact_11_v1 import linked
O=R/'build/dk-union13-flagfix-v6';P=M.P;V=R/'build/dk-union13-flagfix-v5'


def write(p,s):
 p=p.resolve();assert p.is_relative_to(O.resolve()) and p!=O.resolve()
 p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,newline='\n')


def main():
 assert not O.exists() and M.sha(V/'candidate/candidate.nes')=='eddc92b2d19db6768efd66c0c797911a79a61e97609cc82f892121737db428a3'
 prior=json.loads((V/'source-build.json').read_text())
 for p,h in prior['inputs'].items():assert M.sha(p)==h,p
 assert M.sha(V/'controls.json')=='b42e9fe40b8877e9acfb40948213af60b85cfa33cc76a2ef5d68aef6bc640398'
 O.mkdir();d=O/'candidate';d.mkdir();(d/'src').mkdir()
 for p in (V/'candidate/src').iterdir():write(d/'src'/p.name,p.read_text())
 for n in ['dk-component.s','dk-imports.inc','dk-p0-art.inc','union.cfg']:
  write(d/n,(V/'candidate'/n).read_text())
 path=d/'src/donkey_kong_host.s';source=path.read_text()
 before=' cmp #4\n bne Wide\n jmp BlockBufferColli_Side\nWide:'
 after=' cmp #4\n beq Native\n cmp #5\n bne Wide\nNative:\n jmp BlockBufferColli_Side\nWide:'
 assert source.count(before)==1;source=source.replace(before,after)
 source=source.replace('Only the genuine automatic flag-slide state needs original native probes.',
                       'Only genuine automatic flag-slide/exit states4/5 need original native probes.')
 write(path,source)
 write(d/'source.patch',''.join(difflib.unified_diff((P/'src/donkey_kong_host.s').read_text().splitlines(True),source.splitlines(True),
               fromfile=(P/'src/donkey_kong_host.s').as_posix(),tofile=path.as_posix())))
 commands=json.loads((V/'candidate/commands.json').read_text())
 commands=[[s.replace(str(V/'candidate'),str(d))for s in c]for c in commands]
 with (d/'build.log').open('w')as log:
  for c in commands:
   for flag in ['--create-full-dep','-o','-Ln','-m']:
    if flag in c:assert Path(c[c.index(flag)+1]).resolve().is_relative_to(O.resolve())
   for x in c:
    if x.startswith('--dbgfile,'):assert Path(x.split(',',1)[1]).resolve().is_relative_to(O.resolve())
   result=subprocess.run(c,cwd=R,text=True,capture_output=True)
   log.write(subprocess.list2cmdline(c)+'\n'+result.stdout+result.stderr+'\n');log.flush()
   assert result.returncode==0,(result.stdout,result.stderr)
 M.mirror(R,d/'candidate.nes');write(d/'commands.json',json.dumps(commands,indent=2)+'\n')
 a,sa,aa,la,ha=linked(P/'candidate.nes');b,sb,ab,lb,hb=linked(d/'candidate.nes')
 old=M.true_symbols(P/'candidate.nes');new=M.true_symbols(d/'candidate.nes')
 assert all(new.get(n)==v for n,v in old.items())
 assert ab('DkFlagSideGate')==0xbfd1 and int(sb['DkFlagSideGate']['size'],0)==19
 lo=lb('DkFlagSideGate');at=la('DkHostSide');diff=[i for i,(x,y)in enumerate(zip(a,b))if x!=y]
 assert len(a)==len(b) and set(diff)==set(range(at,at+3))|set(range(lo,lo+19))
 inputs=dict(prior['inputs']);inputs[str(Path(__file__).resolve())]=M.sha(__file__)
 for p in [V/'candidate/candidate.nes',V/'source-build.json',V/'controls.json',R/'tools/audit/dk_union13_flagfix_controls_v5.py']:
  inputs[str(p)]=M.sha(p)
 proof=dict(status='SOURCE_LINKED_CANDIDATE_CPU_NATIVE_PENDING',ROM_sha256=M.sha(d/'candidate.nes'),parent_ROM_sha256=M.sha(P/'candidate.nes'),
   unchanged_DK_source_preimage_replay=str(V/'replay/candidate.nes'),unchanged_DK_source_replay_sha256=M.sha(V/'replay/candidate.nes'),
   source_manual_binary_patch=False,gate=hb('DkFlagSideGate'),gate_bytes=19,entry=hb('DkHostSide'),native_callback=hb('BlockBufferColli_Side'),
   old_symbol_PCs_preserved=True,physical=65,owned_lease=['BC00','C000'],old_bytes=977,new_bytes=996,remaining_bytes=28,
   exact_changed_offsets=diff,all_other_ROM_bytes_including125_127_CHR_exact=True,PRG_RAM_ZP_lease_expansion=False,
   retained_v5_source_negative='Engine4 reattaches/advances, engine5 wide side catches pole again atX3186 and native snap returnsX3161; preserve genuine native side probes through both automatic states.',
   inputs=inputs,scope='Source-linked private successor only. ABI/Main/ISR and native endpoint still required.')
 write(O/'source-build.json',json.dumps(proof,indent=2)+'\n')
 # Keep predecessor control source immutable. The successor changes only the
 # automatic-state expectation and the genuine new gate size/range.
 source=(R/'tools/audit/dk_union13_flagfix_controls_v5.py').read_text()
 source=source.replace("O=R/'build/dk-union13-flagfix-v5'","O=R/'build/dk-union13-flagfix-v6'")
 source=source.replace('[5,7,8,9,11]','[6,7,8,9,11]')
 source=source.replace('for y,f in itertools.product(range(3,7),flags):','for engine,y,f in itertools.product([4,5],range(3,7),flags):')
 source=source.replace("side(old,y,f,4,'BlockBufferColli_Side');z=side(b,y,f,4)","side(old,y,f,engine,'BlockBufferColli_Side');z=side(b,y,f,engine)")
 source=source.replace('[4,8]','[4,5,8]').replace('mode==4 else','mode in [4,5] else')
 source=source.replace('0xbfd1<=here[1]<0xbfe0','0xbfd1<=here[1]<0xbfe4')
 source=source.replace("q.put(NmiDisable=255,SavedJoypadBits=0)","q.put(GameEngineSubroutine=mode,NmiDisable=255,SavedJoypadBits=0)")
 write(O/'controls.py',source)
 for p,h in inputs.items():assert M.sha(p)==h,p
 print(json.dumps(dict(candidate=proof['ROM_sha256'],source_proof=str(O/'source-build.json'),gate_bytes=19,changed_bytes=len(diff))))


if __name__=='__main__':main()
