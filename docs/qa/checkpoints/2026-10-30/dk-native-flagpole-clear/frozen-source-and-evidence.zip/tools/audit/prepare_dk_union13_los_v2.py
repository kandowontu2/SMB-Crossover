"""DK controller successor: real barrel lane/block-buffer LOS before combat braking."""
from pathlib import Path
import argparse,difflib,json,re,sys
R=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import prepare_dk_union13_min8_v1 as M
from current_roster_compact_11_v1 import linked,lua
O=R/'build/dk-union13-los-v2'
P=R/'build/dk-union13-min8-review-v1/handoff.json'

HELPERS="""-- Exact actual native MTileAttribute/MTILE_SOLID, extracted from this ROM.
-- Source barrel starts at bodyY+16; its native actor Y difference is [-15,+15].
local function solid(c,wx,y)
 local tile=c.block(wx,y)
 return (assert(ROSTER_CONFIG.dk_tile_attributes[tile+1])&ROSTER_CONFIG.dk_solid_mask)~=0,tile
end
local function trace(c,e,reason,wx,y,tile)
 if ROSTER_CONFIG.dk_policy_trace then ROSTER_CONFIG.dk_policy_trace(c,e,reason,wx,y,tile)end
end
local function clearLane(c,e)
 if e.y<c.y+1 or e.y>c.y+31 then trace(c,e,'vertical-lane');return false end
 for wx=c.x+40,e.x-1,8 do
  local blocked,tile=solid(c,wx,c.y+24)
  if blocked then trace(c,e,'solid-before-target',wx,c.y+24,tile);return false end
 end
 trace(c,e,'clear-shot-lane');return true
end
"""
OBSERVER="""-- BEGIN DK_LIVE_POLICY_GEOMETRY_V2
local geometryRows=0
local geometryLog=file('policy-geometry.csv','poll,frame,x,y,enemySlot,enemyX,enemyY,reason,blockX,blockY,tile,supportTile,aheadUpperTile,aheadLowerTile')
C.dk_policy_trace=function(c,e,reason,wx,y,tile)
 geometryRows=geometryRows+1;assert(geometryRows<=100000,'Bounded passive policy geometry')
 geometryLog:write(table.concat({c.poll,c.frame,c.x,c.y,e.slot,e.x,e.y,reason,wx or -1,y or -1,tile or -1,
  c.block(c.x+24,c.y+32),c.block(c.x+40,c.y+8),c.block(c.x+40,c.y+24)},',')..'\\n')
 if geometryRows%128==0 then geometryLog:flush()end
end
-- END DK_LIVE_POLICY_GEOMETRY_V2
"""


def prepare():
 assert not O.exists()
 assert M.sha(P)=='825c12c65f38587040f34f71861fdba4544c81d6bb8626897575056065df7f4f'
 frozen=json.loads(P.read_text())
 for p,h in frozen['bindings'].items():assert M.sha(p)==h,p
 M.O=O
 M.prepare()
 out=O/'dk';ready=json.loads((out/'ready.json').read_text());cfg=ready['config']
 original=Path(cfg['original_policy']);src=original.read_text()
 policy=src.replace('local combat=nil\n','local combat=nil\n'+HELPERS)
 old="if dx> -24 and dx<160 and y>=c.y-16 and y<c.y+96 and(not best or dx<best.dx)then best={dx=dx,id=id}end"
 new="if dx> -24 and dx<160 then\n    local e={slot=i,dx=dx,id=id,x=x,y=y}\n    if clearLane(c,e)and(not best or dx<best.dx)then best=e end\n   end"
 assert policy.count(old)==1
 policy=policy.replace(old,new)
 assert policy.replace(new,old).replace(HELPERS,'')==src
 assert not re.search(r'\bemu\.',policy)
 M.write(out/'policy-los.lua',policy)
 M.write(out/'policy-los.patch',''.join(difflib.unified_diff(src.splitlines(True),policy.splitlines(True),
                    fromfile=original.as_posix(),tofile=(out/'policy-los.lua').as_posix())))
 cfg['original_policy']=(out/'policy-los.lua').as_posix()
 raw,syms,address,location,hook=linked(M.base.ROM)
 at=location('MTileAttribute');cfg['dk_tile_attributes']=list(raw[at:at+256]);cfg['dk_solid_mask']=address('MTILE_SOLID')
 assert cfg['dk_solid_mask']==1 and len(cfg['dk_tile_attributes'])==256
 capture=(out/'capture-min8.lua').read_text()
 marker='-- END DK_PASSIVE_INPUT_TELEMETRY_V1\n'
 assert capture.count(marker)==1
 capture=capture.replace(marker,marker+OBSERVER)
 assert capture.replace(OBSERVER,'')==(out/'capture-min8.lua').read_text()
 M.write(out/'capture-min8.lua',capture)
 original_capture=M.SCRIPT.read_text()
 M.write(out/'capture-diff.patch',''.join(difflib.unified_diff(original_capture.splitlines(True),capture.splitlines(True),
                    fromfile=M.SCRIPT.as_posix(),tofile=(out/'capture-min8.lua').as_posix())))
 M.write(out/'config.json',json.dumps(cfg,indent=2)+'\n')
 M.write(out/'run.lua','ROSTER_CONFIG='+lua(cfg)+'\n'+
  'for name,value in pairs(ROSTER_CONFIG.extra_ram)do assert(L[name]==nil or L[name]==value,"RAM alias conflict: "..name);L[name]=value end\n'+
  'dofile('+lua((out/'capture-min8.lua').as_posix())+')\n')
 attrs=cfg['dk_tile_attributes'];solid_tile=next(i for i,a in enumerate(attrs)if a&1)
 def clear(y,ey,tiles):
  if not y+1<=ey<=y+31:return False,'vertical-lane'
  if any(attrs[t]&1 for t in tiles):return False,'solid-before-target'
  return True,'clear-shot-lane'
 assert clear(112,184,[0]*16)==(False,'vertical-lane')
 assert clear(176,184,[0]*16)==(True,'clear-shot-lane')
 assert clear(176,184,[0,solid_tile,0])==(False,'solid-before-target')
 assert [clear(100,z,[])[0]for z in[100,101,131,132]]==[False,True,True,False]
 controls=dict(native_executed=False,source_modified=False,controller_only=True,predecessor_negative=str(P),
  unchanged_ROM=M.sha(M.base.ROM),minimum_A_hold=8,actual_solid_table=dict(symbol='MTileAttribute',pc=address('MTileAttribute'),
      physical=(at-16)//8192,ROM_offset=at,mask_symbol='MTILE_SOLID',mask=1,table_sha256=__import__('hashlib').sha256(bytes(attrs)).hexdigest()),
  source_contract=dict(spawn_symbol='DkSpawnBarrel',spawnY_offset=16,shot_center_offset=8,actor_symbol='DkBarrelActors',native_y_delta_inclusive=[-15,15],
                       valid_enemy_top_relative_to_body=[1,31],horizontal_probe_start=40,probe_stride=8),
  offline_controls=dict(contract_model_not_Lua_runtime=True,actual_pipe_top112_enemy184_rejected=True,same_ground_lane176_184_accepted=True,
      actual_source_solid_tile_blocks=True,vertical_boundary_cases=4,all_other_policy_bytes_exact_after_reverse=True),
  passive_geometry_log='Genuine c.block tiles at support/ahead and first solid before target; existing native enemy positions retained.',
  unchanged_guards=['stationary300actualMain','zero deaths','native1-1→25real1-2','NMI/IRQ/DMA/CHR/SMC/stack'],
  claim='Prepared only; neither route success nor source ability completeness nor Lua runtime execution is claimed.')
 M.write(out/'los-controls.json',json.dumps(controls,indent=2)+'\n')
 bindings=ready['bindings'];bindings[str(P)]=M.sha(P)
 bindings.update({p:h for p,h in frozen['bindings'].items() if Path(p).is_relative_to(M.OLD) or Path(p).is_relative_to(R/'build/dk-union13-min8-v1')})
 for p in [Path(__file__).resolve(),out/'policy-los.lua',out/'policy-los.patch',out/'capture-min8.lua',out/'capture-diff.patch',
           out/'config.json',out/'run.lua',out/'los-controls.json']:
  bindings[str(p)]=M.sha(p)
 ready.update(config=cfg,bindings=bindings,line_of_sight_controller_successor=True,
    scope=ready['scope']+' Live source-solid LOS/launch-height priority before combat braking; original actors preserved.')
 M.write(out/'ready.json',json.dumps(ready,indent=2)+'\n')
 for p,h in bindings.items():assert M.sha(p)==h,p
 print(json.dumps(dict(final_ready=str(out/'ready.json'),sha256=M.sha(out/'ready.json'),bindings=len(bindings),native_executed=False)))


if __name__=='__main__':
 parser=argparse.ArgumentParser(description=__doc__);parser.add_argument('--launch',action='store_true');args=parser.parse_args()
 if args.launch:M.base.O=O;M.base.launch('dk')
 else:prepare()
