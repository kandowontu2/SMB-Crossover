"""New exact-color palette-role atlas. Relative pages only, no CHR allocation."""
from pathlib import Path
import collections,hashlib,importlib.util,itertools,json,subprocess
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'build/arthur-palette-leaf-v6';BASE=ROOT/'build/arthur-source-v1';BIN=ROOT/'tools/Windows/cc65/bin'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
spec=importlib.util.spec_from_file_location('privatepal',ROOT/'tools/audit/arthur_private_palettes_v3.py');v3=importlib.util.module_from_spec(spec);spec.loader.exec_module(v3);m=v3.m
def canonical_picture(pixels):
 normal=tuple(sorted((x,y,c,p)for(x,y),(c,p)in pixels.items()));flip=tuple(sorted((-x-1,y,c,p)for(x,y),(c,p)in pixels.items()))
 return (flip,True)if flip<normal else(normal,False)
def main():
 OUT.mkdir(exist_ok=True);d=json.loads((BASE/'art-source.json').read_text());src=(BASE/'arthur-original-sprites.chr').read_bytes();sourcepal=d['palette']['hardware_indices'][16:32];records={r['pose']:r for r in d['records']}
 body={p:8 for p in range(0x16)}|{p:2 for p in range(0x20,0x36)}|{0x16:2,0x18:1,0x1a:1}
 shots={54:1,55:1,56:1,57:1,64:0,65:0,66:0,67:0,68:2,69:2,79:0,86:0,102:0,160:0,161:0,162:0,169:0,170:0,248:0,249:0}
 masters=[];posemap={};observed=json.loads((ROOT/'build/arthur-palette-role-controls-v1/roles.json').read_text())['roles']
 for role in observed:
  assert(body if role['family']=='body'else shots).get(role['pose'])==role['source_row'],role
 for family,roles in [('body',body),('shots',shots)]:
  for pose,row in roles.items():
   pixels={xy:(48 if c==32 else c,p)for xy,(c,p)in m.raster(records[pose],row,src,sourcepal).items()};key,flip=canonical_picture(pixels);ident=(family,key)
   if ident not in [x['identity']for x in masters]:masters.append(dict(identity=ident,family=family,pixels={(x,y):(c,p)for x,y,c,p in key},source_pose=pose,source_row=row,source_flip=flip))
   idx=[x['identity']for x in masters].index(ident);posemap[pose]=(idx,flip)
 assert len(masters)<127
 plans=[[(0,{54:1,24:2,18:3}),(3,{15:1}),(2,{22:1,48:2})],[(0,{15:1,24:2,18:3}),(1,{54:2}),(2,{22:1,48:2})]]
 palettes=[[[15,54,24,18],[15,26,48,39],[15,22,48,39],[15,15,54,23]],[[15,15,24,18],[15,28,54,23],[15,22,48,39],[15,0,48,16]]]
 cases=[];seen={};rectnegative=[];knownlayouts=set()
 for mode,plan in enumerate(plans):
  for mid,master in enumerate(masters):
   family=master['family'];known=seen.setdefault((mode,family),set());pixels=master['pixels'];options=[sorted(m.choices(pixels,mp),key=lambda ps:(len({p['pattern']for p in ps}-known),sum(abs(p['x'])+abs(p['y'])for p in ps)))[:8]for _,mp in plan];candidates=[]
   for combo in itertools.product(*options):
    parts=[p|dict(attribute=p['attribute']|plan[i][0])for i,group in enumerate(combo)for p in group];peak=max(sum(p['y']<=y<p['y']+16 for p in parts)for y in range(-48,48));new={p['pattern']for p in parts}
    if peak<=8:candidates.append(((len(new-known),peak,len(parts)),parts))
   # Source-part merge often saves more atlas space for the small weapons.
   if family=='shots':
    mp=[(pal,{32 if c==48 else c:value for c,value in color.items()})for pal,color in plan]
    pose,row=master['source_pose'],master['source_row'];original_expected={xy:(48 if c==32 else c,p)for xy,(c,p)in m.raster(records[pose],row,src,sourcepal).items()}
    parts=v3.merge(v3.split(records[pose],row,src,sourcepal,mp),palettes[mode],original_expected,known)
    if master['source_flip']:parts=[p|dict(x=-p['x']-8,attribute=p['attribute']^64)for p in parts]
    assert m.reconstruct(parts,palettes[mode])==pixels
    peak=max(sum(p['y']<=y<p['y']+16 for p in parts)for y in range(-48,48));new={p['pattern']for p in parts}
    if peak<=8:candidates.append(((len(new-known),peak,len(parts)),parts))
   assert candidates,(mode,mid,'no8sprite construction')
   _,parts=min(candidates,key=lambda c:c[0] if family=='shots'else ((0 if tuple((p['x'],p['y'],p['attribute']&35)for p in c[1])in knownlayouts else 1+2*len(c[1]))+0.15*c[0][0],len(c[1]),c[0]));knownlayouts.add(tuple((p['x'],p['y'],p['attribute']&35)for p in parts));assert m.reconstruct(parts,palettes[mode])==pixels
   known|={p['pattern']for p in parts};cases.append(dict(key=f'{mode}:{mid}',mode=mode,master=mid,family=family,parts=parts,max_scanline=max(sum(p['y']<=y<p['y']+16 for p in parts)for y in range(-48,48))))
 bodycases=[c for c in cases if c['family']=='body'];groups=v3.binpack(bodycases)
 pages=[];bodymap={}
 for g in groups:
  pats=sorted(g['patterns']);page=len(pages);pages.append(pats)
  for key in g['keys']:bodymap[key]=(page,{p:i for i,p in enumerate(pats)})
 # Exact source white masks fit one common bank; source skin becomes P3index2
 # only in boss mode, with every original white pixel composited in P2white.
 audit=json.loads((ROOT/'build/arthur-palette-window-audit-v1/window7-consumers.json').read_text());worldmasks=set();masklookup=[]
 for r in audit['native_P3_white_pairs']:
  raw=bytes.fromhex(r['white_mask']);values=[[(raw[(y//8)*16+y%8]>>(7-x)&1)|((raw[(y//8)*16+y%8+8]>>(7-x)&1)<<1)for x in range(8)]for y in range(16)]
  tile=(r['window']%4)*64|r['local_tile']|(1 if r['window']>=4 else 0)
  if not any(map(any,values)):masklookup.append((tile,None,0));continue
  code,flip=m.canonical(values);worldmasks.add(code);masklookup.append((tile,code,flip))
 assert len(worldmasks)<=32
 modepages=[];shotmap={};commoncounts=[]
 for mode in range(2):
  counts=collections.Counter(p['pattern']for c in cases if c['mode']==mode and c['family']=='shots'for p in c['parts']);ordered=sorted(counts,key=lambda p:(-counts[p],p));main=ordered[:32];extra=ordered[32:]
  base7=sorted(worldmasks)if mode==1 else[]
  combined=list(dict.fromkeys(base7+extra));commoncounts.append(dict(mode=mode,weapon_pairs=len(ordered),window6_pairs=len(main),window7_world_pairs=len(base7),window7_extra_weapon_pairs=len(extra),window7_total_pairs=len(combined)))
  assert len(combined)<=32,commoncounts
  p6=len(pages);pages.append(main);p7=len(pages);pages.append(combined);modepages.append((p6,p7))
  for p in ordered:shotmap[mode,p]=(6,main.index(p))if p in main else(7,combined.index(p))
 # Compact coordinate layouts: palette in Xupper2; priority in Ybit7.
 # Coalescing may pad above a source part by15px, so Y needs seven signed bits.
 layouts=[];rawrecords=[];recordmap={}
 for c in cases:
  layout=[];encoded=[]
  if c['family']=='body':page,look=bodymap[c['key']]
  else:page=15
  for p in c['parts']:
   assert -32<=p['x']<32 and -64<=p['y']<64,(c,p)
   layout += [(p['x']&63)|((p['attribute']&3)<<6),(p['y']&127)|(128 if p['attribute']&32 else 0)]
   if c['family']=='body':pair=look[p['pattern']];win=0
   else:win,pair=shotmap[c['mode'],p['pattern']]
   encoded.append(pair|((p['attribute']&192)>>1)|(128 if win==7 else 0))
  layout=bytes(layout)
  if layout not in layouts:layouts.append(layout)
  raw=bytes([(len(c['parts'])<<4)|page,layouts.index(layout)]+encoded)
  if raw not in rawrecords:rawrecords.append(raw)
  recordmap[c['mode'],c['master']]=rawrecords.index(raw)
 poseindex=[255]*256
 for pose,(idx,flip)in posemap.items():poseindex[pose]=idx|(128 if flip else 0)
 a=['; Relative lossless source atlas, no physical grant assumed.','.segment "ARTHUR_PALETTE_ART"',
  '.export ArPalPoseIndex,ArPalBodyPoseIndex,ArPalShotPose,ArPalShotIndex,ArPalRecordLo,ArPalRecordHi,ArPalLayoutLo,ArPalLayoutHi,ArPalMode6,ArPalMode7,ArPalWhiteLookup,ArPalMasterCount,ArPalMaskCount,ArPalArtStart,ArPalArtEnd',
  f'ArPalMasterCount={len(masters)}',f'ArPalMaskCount={len(masklookup)}','ArPalArtStart:','ArPalPoseIndex:']
 def emit(values):
  for i in range(0,len(values),16):a.append(' .byte '+','.join(str(v)for v in values[i:i+16]))
 emit(poseindex[:54])
 a.append('ArPalBodyPoseIndex=ArPalPoseIndex')
 a.append('ArPalShotPose:');emit(list(shots))
 a.append('ArPalShotIndex:');emit([poseindex[p]for p in shots])
 for name,op in [('ArPalRecordLo','<'),('ArPalRecordHi','>')]:
  a.append(name+':');a.append(' .byte '+','.join(op+'ArPalRecord'+str(recordmap[mode,mid])for mode in range(2)for mid in range(len(masters))))
 for name,op in [('ArPalLayoutLo','<'),('ArPalLayoutHi','>')]:a += [name+':',' .byte '+','.join(op+'ArPalLayout'+str(i)for i in range(len(layouts)))]
 a += ['ArPalMode6:'];emit([p[0]for p in modepages]);a += ['ArPalMode7:'];emit([p[1]for p in modepages])
 white_lookup=[255]*128
 for tile,pattern,flip in masklookup:
  assert not tile&1
  if pattern is not None:white_lookup[tile//2]=pages[modepages[1][1]].index(pattern)|(flip>>1)
 a.append('ArPalWhiteLookup:');emit(white_lookup)
 for i,raw in enumerate(rawrecords):a.append(f'ArPalRecord{i}:');emit(list(raw))
 for i,raw in enumerate(layouts):a.append(f'ArPalLayout{i}:');emit(list(raw))
 a.append('ArPalArtEnd:');(OUT/'art.s').write_text('\n'.join(a)+'\n');(OUT/'art.cfg').write_text('MEMORY { ROM:start=$C000,size=$2000,type=ro,file=%O; }\nSEGMENTS { ARTHUR_PALETTE_ART:load=ROM,type=ro; }\n')
 commands=[[str(BIN/'ca65.exe'),'-g','-o',str(OUT/'art.o'),str(OUT/'art.s')],[str(BIN/'ld65.exe'),'-C',str(OUT/'art.cfg'),'-o',str(OUT/'art.bin'),'-Ln',str(OUT/'art.lbl'),'--dbgfile',str(OUT/'art.dbg'),str(OUT/'art.o')]]
 for cmd in commands:subprocess.run(cmd,check=True,cwd=ROOT)
 atlas=bytearray()
 for ps in pages:atlas.extend(b''.join(ps)+bytes(1024-32*len(ps)))
 (OUT/'arthur-lossless.chr').write_bytes(atlas)
 result=dict(status='SOURCE_EXACT_RELATIVE_ATLAS_GRANTED_CHR868_884_PRIVATE_LEAF',body_source_cases=len(body),weapon_source_cases=len(shots),canonical_masters=len(masters),body_physical_pages=len(groups),
  total_pages=len(pages),CHR_bytes=len(atlas),metadata_bytes=(OUT/'art.bin').stat().st_size,unique_records=len(rawrecords),layouts=len(layouts),common_pages=commoncounts,
  worst_body_scanline=max(c['max_scanline']for c in cases if c['family']=='body'),worst_weapon_scanline=max(c['max_scanline']for c in cases if c['family']=='shots'),
  pages=[dict(relative=i,pairs=len(p))for i,p in enumerate(pages)],posemap={p:dict(master=i,mirror=f)for p,(i,f)in posemap.items()},
  cases=[c|dict(parts=[p|dict(pattern=p['pattern'].hex())for p in c['parts']])for c in cases],
  limits='Private CHR868..<884 and raw32-only window7 grant c8b7476a; uses13pages. No host edits/ROM emitted. World-white wrapper and actual palette-shadow lifecycle still to execute. White20→30 display alias only; every other opaque RGB/color/priority preserved.',commands=commands,
  bindings={str(p.resolve()):sha(p)for p in[Path(__file__),BASE/'art-source.json',BASE/'arthur-original-sprites.chr',ROOT/'build/arthur-palette-window-audit-v1/window7-consumers.json',ROOT/'build/arthur-palette-role-controls-v1/roles.json',OUT/'art.s',OUT/'art.bin',OUT/'arthur-lossless.chr']})
 p=OUT/'atlas-proof.json';p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items()if k not in ['cases','bindings','commands','posemap']}|dict(receipt_sha256=sha(p))))
if __name__=='__main__':main()
