"""Private frozen-source parent closure followed by qualified dense PN producer."""
from pathlib import Path
import hashlib,importlib.util,json,subprocess,sys
R=Path(__file__).resolve().parents[2];O=R/'build/arthur-host-integration-v1';D=R/'build/parodius-chr-compact-v1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 spec=importlib.util.spec_from_file_location('sourceclosure',Path(__file__).with_name('quickman_host_integrate_v3.py'));q=importlib.util.module_from_spec(spec);spec.loader.exec_module(q);q.O=O;q.T=O/'frozen-inputs'
 if not (O/'parent-reproduction.json').exists():q.prepare();q.build_parent()
 assert sha(O/'candidate.nes')==sha(q.P/'candidate.nes')
 dense=O/'dense';dense.mkdir(exist_ok=True)
 for name in ['vic_viper.s','parodius.s','parodius_art.inc','parodius_death.s','compact.cfg','parodius-compact.chr']:
  raw=(D/name).read_bytes()
  if name.endswith(('.s','.inc','.cfg')):raw=raw.decode().replace(D.as_posix(),dense.as_posix()).replace(str(D),str(dense)).encode()
  (dense/name).write_bytes(raw)
 commands=json.loads((O/'parent-commands.json').read_text());maincmd=commands[0][:];maincmd[1:1]=['-I',str(dense)];link=commands[-1][:];link[link.index('-C')+1]=str(dense/'compact.cfg');logs=[]
 for cmd in [maincmd,link]:
  cp=subprocess.run(cmd,cwd=q.T,capture_output=True,text=True);logs.append(dict(command=cmd,rc=cp.returncode,stdout=cp.stdout,stderr=cp.stderr));assert cp.returncode==0,cp.stderr[:10000]
 sys.path.insert(0,str(R/'tools'));from prepare_cv3_dmc_mirror import prepare as mirror
 mirror(R,O/'candidate.nes');assert sha(O/'candidate.nes')==sha(D/'candidate.nes'),('dense source reproduction',sha(O/'candidate.nes'),sha(D/'candidate.nes'))
 for ext in ['nes','dbg','lbl','map']:(O/('dense-parent.'+ext)).write_bytes((O/('candidate.'+ext)).read_bytes())
 result=dict(status='EXACT_DENSE_PN_PARENT_PRIVATE_SOURCE_REPRODUCTION_PASS',candidate_sha256=sha(O/'candidate.nes'),commands=logs,bindings={str(p.resolve()):sha(p)for p in [Path(__file__),O/'parent-reproduction.json',O/'dense-parent.nes',D/'build-proof.json',R/'docs/qa/checkpoints/2026-10-30/parodius-dense-chr-native/root-review.json']+[dense/n for n in ['compact.cfg','parodius.s','parodius_art.inc','parodius_death.s','parodius-compact.chr']]})
 p=O/'dense-parent-reproduction.json';p.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(status=result['status'],sha256=result['candidate_sha256'],receipt_sha256=sha(p))))
if __name__=='__main__':main()
