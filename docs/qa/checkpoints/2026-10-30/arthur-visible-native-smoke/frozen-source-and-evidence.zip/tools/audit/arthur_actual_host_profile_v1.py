"""Real linked Main instruction attribution in an isolated legal CPU scene."""
from pathlib import Path
import argparse,collections,hashlib,json,sys
R=Path(__file__).resolve().parents[2];O=R/'build/arthur-host-integration-v1'
sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import arthur_actual_host_controls_v1 as A
from sunny_integrated_controls_v1 import NesMPU

def run(b):
 q=A.setup(b);ranges=[]
 for s in b['segs'].values():
  if 'ooffs'not in s or not int(s['size'],0):continue
  ranges.append(((int(s['ooffs'],0)-16)//8192,int(s['start'],0),int(s['start'],0)+int(s['size'],0),s['name'].strip('"')))
 names=['ArDispatch','ArHostMovement','ArHostGraphics','ArHostDraw','ArHostEnsure','ArHostAfterTerrain','ArHostShotContacts','ArStep','ArHostPoint','SamusFreezeDrawAll','DrawAllMetasprites','HuCommon','PlayerBGCollision','AudioUpdate']
 watch={A.point(b,n):n for n in names if n in b['syms']}
 original=NesMPU.step;segments=collections.Counter();costs=collections.defaultdict(list);active=[];updates=[]
 def step(c):
  for e in active[:]:
   if c.sp==((e['SP']+2)&255)and c.pc==e['return']:
    costs[e['name']].append(c.processorCycles-e['CPU']);active.remove(e)
  pc=c.pc;bank=q.m.banks[(pc-0x8000)//8192]if pc>=0x8000 else -1
  n=watch.get((bank,pc))
  if n:
   ret=q.m[0x100+((c.sp+1)&255)]|q.m[0x100+((c.sp+2)&255)]<<8
   active.append(dict(name=n,SP=c.sp,CPU=c.processorCycles,**{'return':(ret+1)&65535}))
  owner=next((n for bk,lo,hi,n in ranges if bk==bank and lo<=pc<hi),'SMC/RAM'if pc<0x8000 else 'UNATTRIBUTED')
  before=c.processorCycles;original(c);segments[owner]+=c.processorCycles-before
 NesMPU.step=step
 try:
  for age in range(48):
   keys=1|(128 if age in[6,16]else 0)|(64 if age in[24,36]else 0)
   q.put(SavedJoypadBits=keys,SavedJoypad1Bits=keys,ArHostPad=keys,ArHostDue=int(age%3==0),NmiDisable=255,VRAM_Buffer1_Offset=0)
   c,tr,mn=A.call(q,'GameLoop');updates.append(c.processorCycles)
 finally:NesMPU.step=original
 return dict(updates=len(updates),complete_Main_CPU_cycles=dict(min=min(updates),max=max(updates),mean=sum(updates)/len(updates)),exclusive_instruction_segment_CPU=dict(segments.most_common()),inclusive_actual_stack_return_costs={n:dict(calls=len(v),total=sum(v),min=min(v),max=max(v),mean=sum(v)/len(v))for n,v in sorted(costs.items(),key=lambda x:-sum(x[1]))},scope='Isolated legal Main scene; source clock/input boundary supplied. Exclusive instruction segments sum without overlap; named routine costs are inclusive and overlap. No native frame-rate claim.')

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();assert not a.output.exists()
 b=A.scoped_load(O/'candidate.nes');d=run(b);d['bindings']={str(p.resolve()):hashlib.sha256(p.read_bytes()).hexdigest()for p in[Path(__file__),O/'candidate.nes',O/'candidate.dbg']}
 a.output.write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(d['complete_Main_CPU_cycles']))
if __name__=='__main__':main()
