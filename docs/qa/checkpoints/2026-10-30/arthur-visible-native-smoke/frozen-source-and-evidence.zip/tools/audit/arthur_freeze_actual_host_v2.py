"""Freeze an exact private smoke packet, explicitly unadmitted for campaign/timing."""
from pathlib import Path
import argparse,ast,hashlib,json,re,sys,zipfile
R=Path(__file__).resolve().parents[2];O=R/'build/arthur-host-integration-v2';T=O/'frozen-inputs';OLD=R/'build/arthur-host-integration-v1'
sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
from link_pit_rygar_sophia_audit_cpu import scoped_load
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--native',required=True);ap.add_argument('--visual-note',required=True);a=ap.parse_args()
 handoff=O/'arthur-handoff.json';assert not handoff.exists(),'Already frozen; use a successor leaf.'
 n=O/'native'/a.native;result=json.loads((n/'result.json').read_text());timing=json.loads((n/'timing.json').read_text())
 h=sha(O/'candidate.nes');assert result['passed'] and timing['ROM_sha256']==h
 controls=O/'actual-controls-final-v1.json';c=json.loads(controls.read_text());assert c['passed']and c['bindings'][str((O/'candidate.nes').resolve())]==h
 files=set()
 # All actual assembler dependencies, not a guessed include list.
 for p in O.glob('*.d'):
  for line in p.read_text().splitlines():
   if '\t'not in line:continue
   for token in re.split(r'(?<!\\)\s+',line.split('\t',1)[1]):
    if token:
     q=Path(token.replace('\\ ',' '));q=q if q.is_absolute()else T/q
     assert q.exists(),q;files.add(q.resolve())
 for folder in [O/'arthur',O/'dense',O/'src']:
  files.update(p.resolve()for p in folder.rglob('*')if p.is_file()and p.suffix in['.s','.inc','.cfg','.chr','.nam','.rle'])
 files.update(p.resolve()for p in O.iterdir()if p.is_file()and p.suffix in['.s','.inc','.cfg','.chr','.nam','.rle'])
 # The existing C object is an explicitly inherited frozen input, not newly
 # authored Arthur code. Parent source/reproduction receipts bind its origin.
 files.add((T/'build/kamikaze-mario-host-v4/c-full.o').resolve())
 for name in ['arthur-build-proof.json','arthur-build-log.json','dense-parent-reproduction.json','parent-reproduction.json','parent-commands.json','candidate.cv3-mirror.json','native-smoke-binding.json','native-smoke-driver.lua','actual-controls-final-v1.json','actual-page-commit-v1.json','source-byte-diff-v1.json','source-ready-v2.json']:
  files.add((O/name).resolve())
 for name in ['arthur-hooks.json','native-fixture-normal-nmi-correction-v1.json','actual-page-commit-negative-v1.json','actual-instruction-profile-v1.json','visual-negative-v2.json','controller-column-discovery-v1.json','controller-column-discovery-v2.json']:
  files.add((OLD/name).resolve())
 # Existing parent objects are explicit immutable inputs. All Arthur code,
 # its Main source hooks and family gates are newly assembled by the recipe.
 recipe=json.loads((O/'arthur-build-proof.json').read_text())['commands'];produced=set()
 for row in recipe[:-1]:
  cmd=row['command'];produced.add(Path(cmd[cmd.index('-o')+1]).resolve())
 inherited=[]
 for token in recipe[-1]['command']:
  p=Path(token)
  if p.suffix=='.o'and p.resolve()not in produced:
   files.add(p.resolve());inherited.append(dict(path=p.relative_to(R).as_posix(),sha256=sha(p)))
 toolnames=['arthur_integrate_host_v2.py','arthur_integrate_host_v1.py','arthur_prepare_actual_host_v1.py','arthur_actual_host_controls_v2.py','arthur_actual_host_controls_v1.py','arthur_host_commit_controls_v2.py','arthur_actual_host_profile_v1.py','arthur_actual_host_smoke_v2.lua','arthur_actual_host_smoke_v1.lua','arthur_prepare_native_smoke_v2.py','arthur_build_lossless_atlas_v6.py','arthur_coalesced_palette_v1.py','arthur_freeze_actual_host_v2.py','run_mesen_output_v2.py']
 files.update((R/'tools/audit'/name).resolve()for name in toolnames)
 # Bind project-local Python imports used by the real CPU/runner controls.
 # Third-party py65 remains an environment dependency, not a source claim.
 pending=[R/'tools/audit'/name for name in toolnames if name.endswith('.py')]
 pending += [R/'build/character-host-union-v5/gm_verify_nmi.py',R/'tools/prepare_cv3_dmc_mirror.py']
 seen=set()
 while pending:
  p=pending.pop().resolve()
  if p in seen:continue
  seen.add(p);assert p.exists(),p;files.add(p)
  for node in ast.walk(ast.parse(p.read_text())):
   names=[v.name for v in node.names]if isinstance(node,ast.Import)else[node.module]if isinstance(node,ast.ImportFrom)and node.module else[]
   for name in names:
    rel=Path(*name.split('.')).with_suffix('.py')
    q=next((folder/rel for folder in[p.parent,R/'tools/audit',R/'tools',R]if(folder/rel).is_file()),None)
    if q is not None:pending.append(q)
 files.update(p.resolve()for p in (R/'build/arthur-host-prep-v6').iterdir()if p.suffix in['.s','.inc'])
 for name in ['atlas-proof.json','arthur-lossless.chr','palette-controls.json']:
  files.add((R/'build/arthur-palette-leaf-v6'/name).resolve())
 for name in ['art-source.json','arthur-original-sprites.chr','handoff.json']:
  files.add((R/'build/arthur-source-v1'/name).resolve())
 files.add((R/'build/arthur-palette-role-controls-v1/roles.json').resolve())
 receipts=['arthur-quick-private-allocation','arthur-nmi-gateway-allocation','arthur-ice-alias-allocation','parodius-dense-chr']
 files.update((R/'docs/qa/checkpoints/2026-10-30'/x/'root-review-and-reservations.json').resolve()for x in receipts)
 files.update(p.resolve()for p in n.iterdir()if p.is_file())
 # Retain the native negatives compactly, including their exact scripts/logs.
 for old in ['cold-smoke-v1','cold-smoke-v2','cold-smoke-v3','cold-smoke-v4']:
  files.update(p.resolve()for p in (OLD/'native'/old).iterdir()if p.is_file())
 segments=[];b=scoped_load(O/'candidate.nes')
 for s in b['segs'].values():
  if not s['name'].startswith('"ARTHUR_'):continue
  row=dict(name=s['name'].strip('"'),CPU_start=int(s['start'],0),bytes=int(s['size'],0))
  if 'ooffs'in s:row['physical_offset']=int(s['ooffs'],0)-16
  segments.append(row)
 manifest=O/'arthur-source-closure.json'
 d=dict(status='PRIVATE_HOST_SMOKE_ONLY_UNADMITTED',ROM_sha256=h,inherited_frozen_parent_objects=inherited,source_and_evidence=[dict(path=p.relative_to(R).as_posix(),bytes=p.stat().st_size,sha256=sha(p))for p in sorted(files)],actual_segments=segments,visual_review_note=a.visual_note,native=result,native_timing=timing,limits=['No controller-earned Mushroom/Flower/five-weapon route or Easy/Hard1-1 clear yet.','Measured233/400lagNMIs is a performance blocker, not a60Hz or installation qualification.','Parent is immutable union-v5 plus exact dense Parodius and Ice overrides; latest Rogue/Gimmick/Quick source changes require reviewed three-way composition.','Shared Arthur remains pending. Private Start readiness is test-only.','Original motion/art/weapon instructions are preserved; requested second jump restart is the intentional adaptation.','Native negatives and source saturation/timing limits remain retained.','The actual compilation/link commands are authoritative; v2 cloning/preparation tools are historical construction, not a standalone new parent reproduction.'])
 manifest.write_text(json.dumps(d,indent=2)+'\n');files.add(manifest.resolve())
 archive=O/'arthur-private-source.zip';assert not archive.exists()
 with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
  for p in sorted(files):z.write(p,p.relative_to(R).as_posix())
 data=dict(status=d['status'],ROM=dict(path=str(O/'candidate.nes'),sha256=h),source_archive=dict(path=str(archive),sha256=sha(archive),bytes=archive.stat().st_size,members=len(files)),source_closure=dict(path=str(manifest),sha256=sha(manifest)),CPU_controls=dict(path=str(controls),sha256=sha(controls)),native=dict(path=str(n),result_sha256=sha(n/'result.json'),timing_sha256=sha(n/'timing.json')),visual_review_note=a.visual_note,limits=d['limits'])
 handoff.write_text(json.dumps(data,indent=2)+'\n');print(json.dumps(dict(handoff=str(handoff),sha256=sha(handoff),archive_sha256=sha(archive),status=data['status'])))
if __name__=='__main__':main()
