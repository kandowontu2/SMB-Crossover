"""Successor controls add the real later player-bank/NMI commit consumer."""
from pathlib import Path
import json,sys
import arthur_actual_host_controls_v1 as A
import arthur_host_commit_controls_v2 as K
R=Path(__file__).resolve().parents[2];A.O=R/'build/arthur-host-integration-v2'
A.commit=lambda b:K.run(b,False)
if __name__=='__main__':
 A.main()
 p=Path(sys.argv[sys.argv.index('--output')+1]);d=json.loads(p.read_text())
 for q in[Path(__file__),Path(K.__file__)]:d['bindings'][str(q.resolve())]=A.sha(q)
 p.write_text(json.dumps(d,indent=2)+'\n')
