"""Bind passive v2 visibility/commit profiling to exact actual source symbols."""
from pathlib import Path
import hashlib,json,sys
R=Path(__file__).resolve().parents[2];O=R/'build/arthur-host-integration-v2'
sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
from link_pit_rygar_sophia_audit_cpu import scoped_load
from check_tmnt_render_oa import address,location
b=scoped_load(O/'candidate.nes');size=int(b['syms']['GameLoop']['size'],0)
exit=address(b,'GameLoop')+size-1;assert b['raw'][location(b,'GameLoop')+size-1]==96
h=hashlib.sha256((O/'candidate.nes').read_bytes()).hexdigest();source=R/'tools/audit/arthur_actual_host_smoke_v2.lua'
driver=O/'native-smoke-driver.lua';driver.write_text(f'ARTHUR_HOST_MAIN_EXIT={exit}\nARTHUR_HOST_ROM_SHA256="{h}"\ndofile([=[{source.as_posix()}]=])\n',newline='\n')
(O/'native-smoke-binding.json').write_text(json.dumps(dict(ROM_sha256=h,Main_entry=address(b,'GameLoop'),Main_exit=exit,Main_size=size,driver_sha256=hashlib.sha256(driver.read_bytes()).hexdigest(),source_sha256=hashlib.sha256(source.read_bytes()).hexdigest()),indent=2)+'\n')
print(json.dumps(dict(ROM_sha256=h,driver=str(driver))))
