"""Private successor: keep the real native Samus body-bank publisher coherent."""
from pathlib import Path
import argparse,json,shutil,sys
import arthur_integrate_host_v1 as B
R=Path(__file__).resolve().parents[2];OLD=R/'build/arthur-host-integration-v1';O=R/'build/arthur-host-integration-v2'

def replace_paths(s):
 for old,new in [(str(OLD),str(O)),(OLD.as_posix(),O.as_posix()),(str(OLD).replace('\\','\\\\'),str(O).replace('\\','\\\\'))]:s=s.replace(old,new)
 return s

def prepare():
 assert B.sha(OLD/'candidate.nes')=='fd4da7dd9efcb05baeb6a63cfa2635a48b1e74ee35400876ab18f326e0dbf7b8'
 assert not O.exists(),'Do not overwrite an existing successor.'
 O.mkdir()
 # Bounded private source/parent-object copy, without old native media/DBG.
 for folder in ['frozen-inputs','src','dense','arthur']:
  shutil.copytree(OLD/folder,O/folder)
 for p in OLD.iterdir():
  if not p.is_file()or p.name.startswith(('candidate.','negative-','actual-','controls-','controller-','source-ready-','visual-negative-','native-')):continue
  if p.suffix in['.s','.inc','.cfg','.chr','.nam','.rle','.o','.d']or p.name in['parent-commands.json','parent-reproduction.json','dense-parent-reproduction.json']:
   shutil.copy2(p,O/p.name)
 for p in O.rglob('*'):
  if p.is_file()and p.suffix in['.s','.inc','.cfg','.d','.json']:
   text=p.read_text();new=replace_paths(text)
   if new!=text:p.write_text(new,newline='\n')
 render=(O/'arthur/host-render.s').read_text()
 render=render.replace('.import CurrentOAMOffset,GuestOamRotationActive,RgOamRotation','.import CurrentOAMOffset,GuestOamRotationActive,RgOamRotation,SmChrBank',1)
 needle=' adc #100\n ldy #0\n jsr Publish';assert render.count(needle)==1
 render=render.replace(needle,' adc #100\n sta SmChrBank                 ; later native PlayerBankReady consumes this same page\n ldy #0\n jsr Publish',1)
 (O/'arthur/host-render.s').write_text(render,newline='\n')
 # prepare() already ran in the pinned parent. Do not regenerate it from
 # abstract prep; the actual successor files are the source of this link.
 B.O=O;B.A=O/'arthur';B.D=O/'dense';B.T=O/'frozen-inputs'

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--build',action='store_true');a=ap.parse_args();prepare()
 if a.build:B.build()
if __name__=='__main__':main()
