-- Cold actual host discovery. Controller inputs only; no RAM/state writes.
local frame,phase,age,step,shots=0,'title',0,1,0
local route={'down','down','down','right','right','right','right','right','right','right'}
local bankA,bankC=0,0
local sourceSteps,clocks,draws,portraits,sourceShots=0,0,0,0,0
local mainCount,lagCount,lateWrites=0,0,0
local mask,ctrl=0,0
local lastDMA,chrChecks=nil,0
local gameStart=nil
local initialX,minY,maxX,initialY=nil,255,0,nil
local maxJump=0
local livesSeen=false
local portraitFirst,previousSkipped=nil,0
local scrollChecks,worldPixels,bodyPixels=0,0,0
local mainExit=assert(ARTHUR_HOST_MAIN_EXIT,'Exact source-derived Main RTS')
local mainCycle,mainInterrupted,mainProfile=nil,0,false
local nmiCycle,nmiLag,nmiProfile,nmiEntry=nil,false,false,nil
local irqCycle,irqInNmi=nil,false
local timing={foreground={count=0,total=0,min=1000000000,max=0},normal_nmi={count=0,total=0,min=1000000000,max=0},lag_nmi={count=0,total=0,min=1000000000,max=0},irq={count=0,total=0,min=1000000000,max=0}}
local baseSteps,baseClocks,baseDraws=0,0,0
local function cycles()return emu.getState()['cpu.cycleCount']end
local function measure(n,v)local t=timing[n];t.count=t.count+1;t.total=t.total+v;t.min=math.min(t.min,v);t.max=math.max(t.max,v)end
local log=assert(io.open(OUTPUT..'frames.csv','w'))
log:write('frame,phase,age,oper,task,engine,raw,x,page,y,lives,ready,steps,clock,draws,jumps,weapon,parts,lag\n')
local function r(n,i)return emu.read(assert(L[n],n)+(i or 0),emu.memType.nesDebug)end
local function timingFile(name)
 local t=assert(io.open(OUTPUT..name,'w'));local rows={}
 for n,v in pairs(timing)do rows[#rows+1]=string.format('"%s":{"count":%d,"total_CPU_cycles":%d,"min":%d,"max":%d,"mean":%.3f}',n,v.count,v.total,v.min,v.max,v.total/math.max(v.count,1))end
 t:write(string.format('{"ROM_sha256":"%s","physical_game_frames":%d,"source_steps":%d,"clock_calls":%d,"draws":%d,"lag_NMIs":%d,"timing":{%s},"scope":"Actual CPU cycleCounter; foreground excludes intercepted NMI/IRQ elapsed, ISR includes DMA/stalls; no60Hz performance admission."}\n',ARTHUR_HOST_ROM_SHA256,age,sourceSteps-baseSteps,clocks-baseClocks,draws-baseDraws,lagCount,table.concat(rows,',')));t:close()
end
local function shot(n)
 shots=shots+1;assert(shots<=8,'Screenshot bound')
 local f=assert(io.open(OUTPUT..n..'.png','wb'));f:write(emu.takeScreenshot());f:close()
 local pal=assert(io.open(OUTPUT..n..'.palette.bin','wb'))
 for i=0,31 do pal:write(string.char(emu.read(0x3f00+i,emu.memType.nesPpuDebug)))end;pal:close()
 local oam=assert(io.open(OUTPUT..n..'.oam.bin','wb'))
 for i=0,255 do oam:write(string.char(emu.read(i,emu.memType.nesSpriteRam)))end;oam:close()
 local s=emu.getState();local pages,cache,modes={},{},{}
 for i=0,11 do pages[#pages+1]=assert(s['mapper.chrBanks'..i]);cache[#cache+1]=r('CurrentCHRBank',i);modes[#modes+1]=r('X5ChrMode',i)end
 local h=assert(io.open(OUTPUT..n..'.hardware.json','w'))
 h:write(string.format('{"frame":%d,"game_age":%d,"PPUCTRL":%d,"PPUMASK":%d,"CHR_physical":[%s],"CHR_software_low":[%s],"CHR_software_mode":[%s],"SmChrBank":%d,"nativeX":%d,"nativeY":%d,"CHR_commit_checks":%d}\n',frame,age,ctrl,mask,table.concat(pages,','),table.concat(cache,','),table.concat(modes,','),r('SmChrBank'),r('Player_Rel_XPos'),r('Player_Y_Position'),chrChecks));h:close()
end
emu.addMemoryCallback(function(_,v)bankA=v&127 end,emu.callbackType.write,0x5115)
emu.addMemoryCallback(function(_,v)bankC=v&127 end,emu.callbackType.write,0x5116)
local function hook(n,fn,bank,offset)
 emu.addMemoryCallback(function()if (bank==1 and bankA or bankC)==B[n]then fn()end end,emu.callbackType.exec,L[n]+(offset or 0))
end
hook('ArStep',function()sourceSteps=sourceSteps+1 end,1)
hook('ArHostNmiClock',function()clocks=clocks+1 end,1,-8192)
hook('ArHostDraw',function()draws=draws+1 end,1)
hook('ArHostPortrait',function()portraits=portraits+1;portraitFirst=portraitFirst or frame end,1)
hook('ArNativeLance',function()sourceShots=sourceShots+1 end,2)
hook('ArPaletteScrollDone',function()
 local s=emu.getState();local t=assert(s['ppu.tmpVideoRamAddr'],'Actual PPU t')
 assert((t&0x73ff)==0 and s['ppu.xScroll']==0 and not s['ppu.writeToggle'],'Actual native palette scroll/latch restore')
 assert(nmiCycle~=nil and not nmiLag and r('NmiDisable')==((nmiEntry-1)&255),'Palette restore follows genuine normal-entry DEC NmiDisable contract')
 scrollChecks=scrollChecks+1
end,2)
emu.addMemoryCallback(function()
 mainCount=mainCount+1;mainCycle=cycles();mainInterrupted=0;mainProfile=phase=='game'
end,emu.callbackType.exec,L.GameLoop)
emu.addMemoryCallback(function()
 if mainCycle and mainProfile then measure('foreground',cycles()-mainCycle+6-mainInterrupted)end
 mainCycle=nil;mainProfile=false
end,emu.callbackType.exec,mainExit)
emu.addMemoryCallback(function()nmiCycle=cycles();nmiEntry=r('NmiDisable');nmiLag=nmiEntry&128~=0;nmiProfile=phase=='game'end,emu.callbackType.exec,L.NonMaskableInterrupt)
emu.addMemoryCallback(function()
 if nmiCycle then
  local elapsed=cycles()-nmiCycle+13
  if nmiProfile then measure(nmiLag and 'lag_nmi'or'normal_nmi',elapsed)end
  if mainCycle then mainInterrupted=mainInterrupted+elapsed end
 end
 nmiCycle=nil
end,emu.callbackType.exec,assert(L.NonMaskableInterrupt_RTI,'Real source NMI RTI'))
emu.addMemoryCallback(function()irqCycle=cycles();irqInNmi=nmiCycle~=nil end,emu.callbackType.exec,L.IrqScrollSplit)
emu.addMemoryCallback(function()
 if irqCycle then
  local elapsed=cycles()-irqCycle+13
  if phase=='game'then measure('irq',elapsed)end
  if mainCycle and not irqInNmi then mainInterrupted=mainInterrupted+elapsed end
 end
 irqCycle=nil
end,emu.callbackType.exec,assert(L.IrqScrollSplit_RTI,'Real source IRQ RTI'))
emu.addMemoryCallback(function(_,v)mask=v end,emu.callbackType.write,0x2001)
emu.addMemoryCallback(function(_,v)ctrl=v end,emu.callbackType.write,0x2000)
emu.addMemoryCallback(function()
 if phase~='game'then return end
 lastDMA={}
 for _,i in ipairs({0,6,7})do lastDMA[i]=r('CurrentCHRBank',i)+256*(r('X5ChrMode',i)&3)end
 assert(lastDMA[0]>=868 and lastDMA[0]<877,'Complete native player-bank publisher retains actual Arthur body page')
end,emu.callbackType.write,0x4014)
emu.addMemoryCallback(function()
 local line=emu.getState()['ppu.scanline']
 if gameStart and mask&24~=0 and line>=0 and line<240 then lateWrites=lateWrites+1 end
end,emu.callbackType.write,0x2007)
emu.addEventCallback(function()
 local b={}
 if phase=='open'and age<6 then b.start=true
 elseif phase=='browse'and age<4 then b[route[step]]=true
 elseif phase=='launch'and age<6 then b.start=true
 elseif phase=='game'then
  b.a=(age>=20 and age<26)or(age>=38 and age<44)
  b.right=age>=100 and age<180
  b.b=age>=80 and age<260 and age%18<6
 end
 emu.setInput(b,0)
end,emu.eventType.inputPolled)
emu.addEventCallback(function()
 frame=frame+1;age=age+1;assert(frame<=1200,'Bounded1200 native frames')
 if phase=='title'and frame==100 then
  assert(r('OperMode')==0 and r('CrossoverMenuState')==0,'Actual cold title')
  phase='open';age=0
 elseif phase=='open'and age>=36 then
  assert(r('CrossoverMenuState')==2,'Actual Start opens menu');phase='browse';age=0
 elseif phase=='browse'and age>=24 then
  local want=step<=3 and step*8 or 24+(step-3)
  assert(r('CrossoverMenuIndex')==want,'Actual controller menu route '..want)
  step=step+1;age=0
  if step>#route then
   assert(r('SelectedCharacter')==32,'Actual raw32 menu owner')
   shot('menu-arthur');phase='launch';age=0
  end
 elseif phase=='launch'then
  if r('OperMode')==1 and portraitFirst and frame-portraitFirst>=8 and not livesSeen and r('GameEngineSubroutine')~=8 then
   livesSeen=true;shot('lives-arthur')
  end
  if r('OperMode')==1 and r('OperMode_Task')==3 and r('GameEngineSubroutine')==8 then
   assert(r('SelectedCharacter')==32 and r('ArHostReady')==167,'Real Arthur gameplay admission')
   gameStart=frame;initialX=r('Player_X_Position')+256*r('Player_PageLoc');initialY=r('Player_Y_Position')
   maxX=initialX;phase='game';age=0;shot('game-start')
   previousSkipped=r('NmiSkipped')
   baseSteps,baseClocks,baseDraws=sourceSteps,clocks,draws
  end
 elseif phase=='game'then
  assert(r('SelectedCharacter')==32 and r('ArHostReady')==167,'Raw32 owner remains valid')
  assert(r('CheatInvincible')==0,'No invincibility cheat')
  assert(r('ArDead')==0 and r('NumberofLives')==2,'No death in bounded smoke')
  assert(r('PlayerStatus')==(r('ArR_04F0')&32==0 and 1 or 0),'Native powerup chooser projects actual source armor')
  if lastDMA then
   local s=emu.getState()
   for _,i in ipairs({0,6,7})do assert(s['mapper.chrBanks'..i]==lastDMA[i],'Actual hardware CHR matches the last completed OAM DMA')end
   assert(ctrl&32~=0 and mask&16~=0,'Actual gameplay uses8x16 sprites with sprite display enabled')
   chrChecks=chrChecks+1
  end
  local x=r('Player_X_Position')+256*r('Player_PageLoc')
  maxX=math.max(maxX,x);minY=math.min(minY,r('Player_Y_Position'));maxJump=math.max(maxJump,r('ArJumpCount'))
  local skipped=r('NmiSkipped');lagCount=lagCount+((skipped-previousSkipped)&255);previousSkipped=skipped
  if age==48 then shot('double-jump')elseif age==156 then shot('source-lance')elseif age==300 then
   shot('game-controlled');timingFile('timing-at-visibility.json')
   local screen=emu.getScreenBuffer();assert(#screen==61440,'Actual rendered256x240 PPU pixels')
   local sky=screen[80*256+240]
   for y=208,239 do for x=8,247 do if screen[y*256+x+1]~=sky then worldPixels=worldPixels+1 end end end
   local px=r('Player_Rel_XPos');local py=r('Player_Y_Position')
   for y=py,math.min(py+23,239)do for x=math.max(px-4,0),math.min(px+20,255)do if screen[y*256+x+1]~=sky then bodyPixels=bodyPixels+1 end end end
   assert(worldPixels>=2000,'Actual world floor visible in its native screen area')
   assert(bodyPixels>=64,'Actual Arthur body visible above the floor')
   assert(emu.read(0x3f11,emu.memType.nesPpuDebug)==0x36 and emu.read(0x3f12,emu.memType.nesPpuDebug)==0x18 and emu.read(0x3f13,emu.memType.nesPpuDebug)==0x12,'Actual Arthur source P0 colors')
   assert(emu.read(0x3f00,emu.memType.nesPpuDebug)==0x22,'Original native1-1 blue universal backdrop')
   local name={10,27,29,17,30,27}
   for i,v in ipairs(name)do assert(emu.read(0x2042+i,emu.memType.nesPpuDebug)==v,'Actual ARTHUR status font cells')end
  end
  if age>=400 then
   assert(livesSeen and portraits>0,'Real lives portrait path observed')
   assert(maxX-initialX>=25,'Controller Right produces actual source movement')
   assert(maxJump==2 and initialY-minY>=55,'Actual authored second jump restart')
   assert(sourceSteps>=90 and clocks>sourceSteps and sourceShots>0 and draws>50,'Actual original engine/weapon/NMI/draw execution')
   assert(lateWrites==0,'No active-display PPU upload')
   assert(scrollChecks>50 and worldPixels>=2000 and bodyPixels>=64,'Actual palette-scroll-world-body presentation checks')
   assert(timing.foreground.count>100 and timing.normal_nmi.count>50 and chrChecks>100,'Actual active foreground/NMI/CHR commit profiling coverage')
   log:close()
   local f=assert(io.open(OUTPUT..'result.json','w'))
   f:write(string.format('{"passed":true,"frames":%d,"controlled_game_frames":%d,"raw":32,"source_steps":%d,"source_clock_calls":%d,"source_lance_calls":%d,"draws":%d,"portraits":%d,"right_pixels":%d,"jump_pixels":%d,"max_jump_count":%d,"main_calls":%d,"lag_observations":%d,"active_ppu_writes":%d,"screenshots":%d,"scroll_checks":%d,"actual_world_pixels":%d,"actual_body_pixels":%d,"RAM_writes":false,"limits":"Cold host smoke only; no earned upgrades or campaign clear."}\n',frame,age,sourceSteps,clocks,sourceShots,draws,portraits,maxX-initialX,initialY-minY,maxJump,mainCount,lagCount,lateWrites,shots,scrollChecks,worldPixels,bodyPixels));f:close()
   timingFile('timing.json')
   print('PASS actual private Arthur cold selector/lives/400controlled gameplay frames, source motion/doublejump/lance');emu.stop(0)
  end
 end
 if frame%6==0 then
  log:write(table.concat({frame,phase,age,r('OperMode'),r('OperMode_Task'),r('GameEngineSubroutine'),r('SelectedCharacter'),r('Player_X_Position'),r('Player_PageLoc'),r('Player_Y_Position'),r('NumberofLives'),r('ArHostReady'),sourceSteps,clocks,draws,r('ArJumpCount'),r('ArR_053A'),r('CurrentOAMOffset'),r('NmiSkipped')},',')..'\n');log:flush()
 end
end,emu.eventType.endFrame)
