"""Full real DrawAll ownership/capacity and reached ISR boundaries; CPU only."""
from pathlib import Path
import argparse,itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import dragon_power_gameplay_controls_v1 as C
import dragon_power_movement_consumers_v2 as I
import dragon_power_art_v1 as ART
import dragon_power_mixed_render_controls_v3 as T
from sunny_integrated_controls_v1 import *
O=C.O
def draw(q,name='DrawAllMetasprites'):
 b=q.b;pc=address(b,name);bank=(location(b,name)-16)//8192;q.m.page((pc-0x8000)//8192,bank)
 if pc>=0xa000:q.set('CurrentBank',bank|128)
 q.m.writes=[];c=NesMPU(memory=q.m,pc=pc);c.sp=253;c.p=0x30;c.stPushWord(0x5aff)
 events=[];active=None;minimum=253;tr=[]
 for _ in range(300000):
  if c.pc==0x5b00:return c,events,minimum,tr
  minimum=min(minimum,c.sp);physical=q.m.banks[(c.pc-0x8000)//8192]if c.pc>=0x8000 else-1;tr.append((physical,c.pc))
  if active and c.pc==active['return']and c.sp==active['sp']:
   active['accepted']=bool(c.p&1);active['after']=q.get('CurrentOAMOffset');active['OAM_after']=bytes(q.m[0x200:0x300]).hex();events.append(active);active=None
  if physical==4 and c.pc==address(b,'MetaspriteRenderLoop'):
   assert active is None
   ptr=q.get('R0')+256*q.get('R1');header=q.m[ptr]
   active=dict(ptr=ptr,C=q.m.banks[2],header=header,before=q.get('CurrentOAMOffset'),rotation=q.get('RgOamRotation'),sp=c.sp,**{'return':q.m[0x101+c.sp]+256*q.m[0x102+c.sp]+1})
  assert q.m[c.pc]!=0,('BRK',hex(c.pc),physical);c.step()
 raise AssertionError(('draw timeout',hex(c.pc)))
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();assert not a.output.exists()
 b=scoped_load(O/'candidate.nes');old=scoped_load(C.P/'candidate.nes');proof=dict(passed=False,source_CPU_only=True,native_run=False,checks={});ck=proof['checks']
 try:
  rows=[];costs=[]
  for pose,face,wave,pivot in itertools.product(range(32),[0,64],[False,True],[0,252]):
   q=C.setup(b);run(q,'DpEnsure');q.put(DpPose=pose,DpAttribute=face,Player_Y_Position=100,Player_Rel_YPos=100,RgOamFirst=pivot,RgOamUsed=256-4,FrameCounter=0)
   q.put(DpShotState=(0x43 if face else 0x82)if wave else 0,DpShotX=120,DpShotY=116)
   run(q,'DpGraphics');c,events,mn,tr=draw(q)
   body=[e for e in events if e['C']==85 and 0xc900<=e['ptr']<=0xcdee and e['header']>0]
   assert len(body)==(2 if wave else 1),('body/shot emission once',pose,face,wave,[(hex(e['ptr']),e['header'])for e in events])
   assert q.get('ObjectMetasprite')==0 and q.m[q.get('SmPosePtr')+256*q.get('SmPosePtr',1)]==0
   assert all(e['accepted'] for e in body)
   # Actual logical ranges become disjoint rotated physical spans. The final
   # page must still contain every emitted body+wave byte after all consumers.
   spans=[]
   final=bytes(q.m[0x200:0x300])
   for e in body:
    offsets=[(e['before']+i+e['rotation'])&255 for i in range(e['header'])]
    for off in offsets:assert final[off]==bytes.fromhex(e['OAM_after'])[off],('later writer overlaps body',pose,face,wave,off)
    assert not(set(offsets)&set(spans));spans+=offsets
   rows.append([pose,face,wave,pivot,len(spans),q.get('RgOamUsed'),mn]);costs.append(c.processorCycles)
  ck['complete_DrawAll_body_wave_once_zero_following_reservation']=dict(cases=len(rows),rows=rows,actual_ring_byte_retention=True,CPU=[min(costs),max(costs)])
  # Clipped and capacity boundary through actual pre-body owner. A rejected
  # group cannot wrap/write earlier groups; its successor reservation is0.
  rows=[]
  for cursor,x,y,face in itertools.product([0,192,208,224,240,252],[0,96,250],[0,100,230],[0,64]):
   q=C.setup(b);run(q,'DpEnsure');q.put(DpPose=6,DpAttribute=face,Player_Rel_XPos=x,Player_Y_Position=y,CurrentOAMOffset=cursor,GuestOamRotationActive=1,RgOamRotation=44,DpShotState=0x82,DpShotX=120,DpShotY=116)
   run(q,'DpGraphics');c,events,mn,tr=draw(q,'DpGameDraw')
   used=set()
   for e in events:
    if not e['accepted']:assert e['after']==e['before'];continue
    assert e['after']==e['before']+e['header']<=255
    span={(e['before']+i+e['rotation'])&255 for i in range(e['header'])};assert not used&span;used|=span
   assert q.get('ObjectMetasprite')==0 and q.get('DpRenderBuffer')==0
   rows.append([cursor,x,y,face,[(e['header'],e['accepted'],e['before'],e['after'])for e in events],mn])
  ck['prebody_capacity_clipping']=dict(cases=len(rows),rows=rows)
  # Full native firebar/score paths share the remaining logical pool. Native
  # 40/64 partial writer starting cursor is compared at actual Main threshold.
  rows=[]
  for count,pivot in itertools.product([0,1,6],[0,252]):
   q=C.setup(b);run(q,'DpEnsure');q.put(DpPose=6,RgOamFirst=pivot,RgOamUsed=252,FrameCounter=1,DpShotState=0x82,DpShotX=120,DpShotY=116)
   for slot in range(count):
    C.actor(q,slot,0x1f,112+slot*8,112);q.set('FirebarSpinState_High',0,slot)
    q.set('FloateyNum_Control',6,slot);q.set('FloateyNum_Timer',32,slot);q.set('FloateyNum_X_Pos',96+slot*8,slot);q.set('FloateyNum_Y_Pos',80,slot)
   run(q,'DpGraphics');c,events,mn,tr=draw(q)
   own=[e for e in events if e['C']==85 and 0xc900<=e['ptr']<=0xcdee]
   final=bytes(q.m[0x200:0x300]);n=0
   for e in own:
    for i in range(e['header']):
     off=(e['before']+i+e['rotation'])&255;assert final[off]==bytes.fromhex(e['OAM_after'])[off];n+=1
   assert any(pc==address(b,'DrawWorldFirebars')for bank,pc in tr)
   # Main's actual native partial allocation remains64 for raw24. Reached
   # native Vine must therefore start beyond this bounded max56byte body+wave.
   run(q,'PlayerOAMReservation');assert q.get('SelectedCharacter')==24
   rows.append([count,pivot,n,q.get('RgOamUsed'),len(events),mn])
  ck['crowded_native_firebar_and_score_pool']=dict(cases=len(rows),rows=rows)
  # Next actual Main restores the real source graphics descriptor after the
  # preceding DrawAll cleared ObjectMetasprite. It is cleared again ONLY at draw.
  q=C.setup(b);run(q,'DpEnsure');q.put(DpPose=6);run(q,'DpGraphics');draw(q);assert q.get('ObjectMetasprite')==0
  q.put(ShouldSkipDrawSprites=1,FramesSinceLastSpriteDraw=0);c,tr,mn=C.M.runtrace(q,'GameLoop');assert q.get('ObjectMetasprite')==address(b,'METASPRITE_SAMUS_BODY')
  ck['next_real_Main_reconstructs_body']=dict(no_draw_Main_publishes_body=True,minimum_SP=mn)
  # Actual reached source service/publication/body instructions. Strict IRQ
  # and lagNMI context includes physicalC and all interrupted5SMC.
  events=[];minimum=255
  for name in['DpGameStep','DpGameWeapons','DpGamePickup','DpGameDraw','DpGameBounce']:
   q=C.setup(b);run(q,'DpEnsure')
   if name=='DpGamePickup':C.actor(q,0,0x2e,96,176);q.set('Enemy_State',128,0)
   c,tr,mn=C.M.runtrace(q,name,p=0x30)
   points=sorted(set((bank,pc)for bank,pc in tr if bank==86 and address(b,'DpGameCoreStart')<=pc<0xc000))
   for kind,point in itertools.product(['IRQ','NMI'],points):
    q=C.setup(b);run(q,'DpEnsure')
    if name=='DpGamePickup':C.actor(q,0,0x2e,96,176);q.set('Enemy_State',128,0)
    c,_,mn,_,hit=I.interrupt_actual(q,name,flags=0x30,inject=point,kind=kind)
    assert hit;events.append([name,kind,*point]);minimum=min(minimum,mn)
  ck['actual_reached_IRQ_lagNMI_services']=dict(cases=len(events),minimum_SP=minimum,events=events)
  proof['passed']=True
 except Exception as e:proof.update(failure=repr(e),traceback=traceback.format_exc())
 proof['bindings']={str(p.resolve()):sha(p)for p in[Path(__file__),Path(C.__file__),Path(I.__file__),Path(T.__file__),Path(ART.__file__),O/'candidate.nes',O/'candidate.dbg',O/'candidate.lbl',R/'build/dragon_power_gameplay_core_v1.inc',R/'build/dragon_power_gameplay_c_v1.inc']}
 a.output.write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(dict(passed=proof['passed'],failure=proof.get('failure'),checks=list(ck))));assert proof['passed']
if __name__=='__main__':main()
