"""Independently rebuild/review Claude's ac126 Goku unit in a new packet.

No frozen packet, canonical source, shared ROM, or emulator launch is modified.
"""
from pathlib import Path
import argparse
import hashlib
import itertools
import json
import re
import shutil
import subprocess
import sys
import traceback

R = Path(__file__).resolve().parents[2]
U = R / 'build/goku-admission-agent-v1'
O = R / 'build/goku-admission-review-v2'
P = R / 'build/pit-retold-host-v3/candidate.nes'
EXPECTED = 'e55f73a22f92d3564f14dff5700e262a32327777ae413a2663dfef4a91e17ecf'
PARENT = 'ac126b545ceb0c27f4843dbbf2eed647f07288a74a7a036d6769db6e3df0b1d2'


def sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def write(name, value):
    (O / name).write_text(json.dumps(value, indent=2) + '\n')


def build():
    assert sha(P) == PARENT
    assert sha(U / 'candidate/candidate.nes') == EXPECTED
    assert not O.exists(), 'Fresh review packet required'
    O.mkdir(parents=True)
    shutil.copytree(U / 'overlay', O / 'overlay')
    for name in ['entrypoint.s', 'dp_component.s', 'smb1base-mmc5-expanded.cfg']:
        shutil.copyfile(U / name, O / name)
    original = json.loads((U / 'candidate/build-result.json').read_text())['commands']
    passes = []
    sys.path.insert(0, str(R / 'tools'))
    from prepare_cv3_dmc_mirror import prepare
    for tag in ['candidate', 'independent']:
        out = O / tag
        out.mkdir()
        commands, results = [], []
        for command in original:
            command = [a.replace(str(U / 'candidate'), str(out)).replace(str(U), str(O)) for a in command]
            z = subprocess.run(command, cwd=R, capture_output=True, text=True)
            commands.append(command)
            results.append(dict(rc=z.returncode, stdout=z.stdout, stderr=z.stderr))
            assert z.returncode == 0, z.stderr
        mirror = prepare(R, out / 'candidate.nes')
        assert sha(out / 'candidate.nes') == EXPECTED
        assert sha(out / 'candidate.lbl') == sha(U / 'candidate/candidate.lbl')
        deps = {}
        for file in out.glob('*.d'):
            rhs = file.read_text().split(':\t', 1)[1].splitlines()[0].strip()
            for word in re.split(r'(?<!\\)\s+', rhs):
                path = Path(word.replace('\\ ', ' '))
                if not path.is_absolute():
                    path = R / path
                path = path.resolve()
                assert path.is_file(), path
                deps[str(path)] = sha(path)
        passes.append(dict(name=tag, commands=commands, logs=results,
                           ROM_sha256=sha(out / 'candidate.nes'),
                           LBL_sha256=sha(out / 'candidate.lbl'),
                           DBG_sha256=sha(out / 'candidate.dbg'),
                           cv3_mirror=mirror, actual_ASM_dependencies=deps))
    for row in passes:
        for path, digest in row['actual_ASM_dependencies'].items():
            assert sha(path) == digest
    write('closure.json', dict(passed=True, parent_ROM=PARENT, candidate_ROM=EXPECTED,
                              independent_ROM_and_LBL_exact=True,
                              DBG_note='Real source/debug paths differ; no debug aliases used.', passes=passes))
    print('Exact independent ROM/LBL rebuilds; actual dependency files:', len(passes[0]['actual_ASM_dependencies']))


def source():
    sys.path[:0] = [str(R / 'tools/audit'), str(R / 'tools')]
    from sunny_integrated_controls_v1 import scoped_load, address
    p, b = [scoped_load(q) for q in [P, O / 'candidate/candidate.nes']]
    aliases = {s.get('id') for n, s in p['syms'].items() if '::' in n}
    moves, removed = [], []
    for name, sym in p['syms'].items():
        if name == '_FARCALL_COUNT' or ('::' not in name and sym.get('id') in aliases):
            continue
        if name not in b['syms']:
            removed.append(name)
        elif address(p, name) != address(b, name):
            moves.append([name, address(p, name), address(b, name)])
    assert all('::' in n for n in removed)
    assert all('::' in row[0] for row in moves)
    assert p['raw'][:16] == b['raw'][:16]
    changes = {}
    for bank in range(256):
        start = 16 + bank * 8192
        offsets = [i for i, (x, y) in enumerate(zip(p['raw'][start:start+8192], b['raw'][start:start+8192])) if x != y]
        if not offsets:
            continue
        ranges = []
        lo = last = offsets[0]
        for i in offsets[1:]:
            if i != last + 1:
                ranges.append([lo, last + 1])
                lo = i
            last = i
        ranges.append([lo, last + 1])
        changes[str(bank)] = dict(kind='PRG' if bank < 128 else 'CHR', bytes=len(offsets),
                                  file_base=start, ranges_bank_offsets=ranges)
    old = (R / 'build/dragon-power-two-platforms-v1/candidate.nes').read_bytes()
    retained = {}
    for bank in [85, 86]:
        start = 16 + bank * 8192
        retained[str(bank)] = dict(exact=old[start:start+8192] == b['raw'][start:start+8192],
                                   different_bytes=sum(x != y for x, y in zip(old[start:start+8192], b['raw'][start:start+8192])))
    write('source-audit.json', dict(passed=True, parent_ROM=PARENT, candidate_ROM=EXPECTED,
                                   header_exact=True, public_PCs_and_RAM_exact=True,
                                   private_moves=moves, private_removed=removed,
                                   exact_changed_ranges=changes, original_Goku_banks=retained,
                                   platform=[address(b, 'DpPlatformStart'), address(b, 'DpPlatformEnd')],
                                   SamusFreezeFlushPalette=address(b, 'SamusFreezeFlushPalette'),
                                   GuestGameRoutinesBridge=address(b, 'GuestGameRoutinesBridge')))
    print('Public PCs/RAM exact; changed banks:', {k: v['bytes'] for k, v in changes.items()})


def cpu():
    sys.path[:0] = [str(R / 'tools/audit'), str(R / 'tools')]
    import dragon_power_gameplay_controls_v1 as C
    from sunny_integrated_controls_v1 import scoped_load, registers, smc_at, address
    p, b = [scoped_load(q) for q in [P, O / 'candidate/candidate.nes']]
    proof = dict(passed=False, source_CPU_only=True, native_run=False, checks={})
    try:
        rows = []
        for char, mode, keys in itertools.product([0, 1, 2, 3, 4, 5, 6, 7, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 23], range(2), [0, 129]):
            pair = []
            for v in [p, b]:
                q = C.setup(v, char)
                q.put(CrossoverBehaviorVersion=mode, SavedJoypadBits=keys)
                c, trace, mn = C.M.runtrace(q, 'GameLoop', p=0x71)
                state = (registers(c), C.M.fastapp(q), bytes(q.m[0x100:0x17b]), tuple(q.m.banks))
                writes = [(i, z) for i, z in q.m.writes if not 0x100 <= i < 0x200 and not 0x5114 <= i <= 0x5117 and i not in smc_at(v)]
                pair.append((state, writes, c.processorCycles, mn))
            assert pair[0][:2] == pair[1][:2], ('foreign complete Main', char, mode, keys, pair[0][0][0], pair[1][0][0])
            rows.append([char, mode, keys, pair[1][2] - pair[0][2], pair[1][3]])
        proof['checks']['foreign_complete_Main'] = dict(cases=len(rows), rows=rows,
            AXYP_SP_application_OAM_CHR_live_stack_final_banks_remaining_ordered_writes_exact=True,
            comparison_scope='Existing CPU helper fastapp excludes declared farcall SMC operands; full live page1 below 017B retained; stack transient and mapper register writes excluded from ordered-write comparison.',
            CPU_delta=[min(r[3] for r in rows), max(r[3] for r in rows)])
        rows = []
        for mode, face in itertools.product(range(2), [1, 2]):
            q = C.setup(b)
            q.put(CrossoverBehaviorVersion=mode, PlayerFacingDir=face)
            for age in range(64):
                keys = (1 if face == 1 else 2) | (128 if 2 <= age < 12 else 0) | (64 if 30 <= age < 32 else 0)
                q.put(SavedJoypadBits=keys, NmiDisable=255, VRAM_Buffer1_Offset=0)
                c, trace, mn = C.M.runtrace(q, 'GameLoop')
                assert trace.count((86, address(b, 'DpSourceFrame'))) == 1
                assert (126, address(b, 'PlayerBGCollision')) not in trace
                assert q.get('DpHP') == 100 - (age + 1) // 60
                assert q.get('CurrentBank') & 127 == q.m.banks[1]
                assert q.get('CurrentBankC') & 127 == q.m.banks[2]
            rows.append([mode, face, q.get('DpClock'), q.get('DpHP'), mn])
        proof['checks']['owned_complete_Main'] = dict(updates=256, rows=rows,
            one_original_source_frame_per_update=True, native_solid_second_resolver_absent=True,
            original_hunger_retained=True)
        proof['passed'] = True
    except Exception as e:
        proof.update(failure=repr(e), traceback=traceback.format_exc())
    proof['bindings'] = {str(path): sha(path) for path in [Path(__file__), Path(C.__file__), Path(C.M.__file__),
        P, P.with_suffix('.dbg'), O / 'candidate/candidate.nes', O / 'candidate/candidate.dbg']}
    write('cpu-controls.json', proof)
    print(json.dumps(dict(passed=proof['passed'], failure=proof.get('failure'), checks=list(proof['checks']))))
    assert proof['passed']


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=['build', 'source', 'cpu'])
    args = parser.parse_args()
    {'build': build, 'source': source, 'cpu': cpu}[args.action]()
