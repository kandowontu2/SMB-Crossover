"""Prepare/run serial short cold native A/B checks; root controls the queue."""
from pathlib import Path
import argparse
import csv
import hashlib
import json
import os
import sys
R=Path(__file__).resolve().parents[2]
O=R/'build/goku-admission-review-v2'
sys.path[:0]=[str(R/'tools'),str(R/'tools/audit')]
import run_mesen
from current_roster_compact_11_v1 import lua
ROMS={'parent':R/'build/pit-retold-host-v3/candidate.nes','candidate':O/'candidate/candidate.nes'}
SHAS={'parent':'ac126b545ceb0c27f4843dbbf2eed647f07288a74a7a036d6769db6e3df0b1d2','candidate':'e55f73a22f92d3564f14dff5700e262a32327777ae413a2663dfef4a91e17ecf'}
EMU=R/'build/verification/kamikaze-private-emulator-v1/Mesen.exe'
OPTIONS=['--doNotSaveSettings','--nes.removeSpriteLimit=false','--nes.ramPowerOnState=AllZeros','--nes.randomizeCpuPpuAlignment=false','--nes.randomizeMapperPowerOnState=false']
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def launch(name):
 rom=ROMS[name];assert sha(rom)==SHAS[name]
 out=O/'native'/('cold-hard-mario-'+name)
 assert not out.exists();out.mkdir(parents=True)
 script=out/'run.lua'
 script.write_text('AB_CONFIG='+lua(dict(mode=1,slot=0,character=0,nav=['']*28,limit=1050))+'\ndofile('+lua((O/'cold-ab.lua').as_posix())+')\n')
 os.environ['SMB_RUN_OUTPUT']=str(out)
 rc=run_mesen.run(script,rom,str(EMU),300,emulator_options=OPTIONS)
 proof=dict(exit_code=rc,ROM_sha256=sha(rom),DBG_sha256=sha(rom.with_suffix('.dbg')),script_sha256=sha(script),harness_sha256=sha(O/'cold-ab.lua'),emulator_sha256=sha(EMU),options=OPTIONS)
 (out/'launch.json').write_text(json.dumps(proof,indent=2)+'\n')
 assert rc==0
def compare():
 paths=[O/'native'/('cold-hard-mario-'+x)for x in ['parent','candidate']]
 a,b=[list(csv.DictReader((x/'cold-ab.csv').open()))for x in paths]
 proof=dict(rows=[len(a),len(b)],parent_ROM=SHAS['parent'],candidate_ROM=SHAS['candidate'],phases={})
 for phase in ['menu','lives','game']:
  x,y=[[r for r in z if r['phase']==phase]for z in [a,b]]
  assert len(x)==len(y),(phase,len(x),len(y))
  n=len(x)
  proof['phases'][phase]=dict(frames=n,screen_diff=sum(p['screen']!=q['screen']for p,q in zip(x,y)),ram_diff=sum(p['ram']!=q['ram']for p,q in zip(x,y)),wram_diff=sum(p['wram']!=q['wram']for p,q in zip(x,y)),identities=sorted({r['char']for r in x+y}),modes=sorted({r['mode']for r in x+y}))
 proof['controller_inputs_exact']=(paths[0]/'inputs.csv').read_bytes()==(paths[1]/'inputs.csv').read_bytes()
 proof['passed']=proof['controller_inputs_exact'] and all(proof['phases'][p]['screen_diff']==0 for p in ['lives','game'])
 proof['scope']='One cold-process Mario Hard route, 1050 video frames; menu art intentionally differs for added Goku. No full-roster, NMI audio, drop, Hard Goku, or constant-FPS claim.'
 proof['bindings']={str(p):sha(p)for out in paths for p in out.iterdir()if p.is_file()}
 (O/'native/cold-hard-mario-comparison.json').write_text(json.dumps(proof,indent=2)+'\n')
 print(json.dumps({k:v for k,v in proof.items()if k!='bindings'},indent=2))
def presentation():
 paths=[O/'native'/('cold-hard-mario-'+x)for x in ['parent','candidate']]
 rows=[list(csv.DictReader((x/'cold-ab.csv').open()))for x in paths]
 negative=O/'native/cold-hard-mario-comparison.json'
 original=json.loads(negative.read_text())
 retained=[]
 for i,(a,b)in enumerate(zip(*rows)):
  if a['phase']=='lives'and a['screen']!=b['screen']:
   assert a['task']==b['task']=='0'and i>0
   assert all(z[i]['screen']==z[i-1]['screen'] for z in rows)
   assert all(z[i-1]['phase']=='menu' for z in rows)
   retained.append(dict(frame=int(a['frame']),task=0,
     prior_menu_hashes=[z[i-1]['screen']for z in rows],current_hashes=[z[i]['screen']for z in rows]))
 assert len(retained)==1
 retained_frames={q['frame']for q in retained}
 displayed_lives=[(a,b)for a,b in zip(*rows)if a['phase']=='lives'and int(a['frame'])not in retained_frames]
 game=[(a,b)for a,b in zip(*rows)if a['phase']=='game']
 assert len(displayed_lives)==162 and len(game)==764
 assert all(a['screen']==b['screen']for a,b in displayed_lives+game)
 assert original['controller_inputs_exact']
 proof=dict(passed=True,parent_ROM=SHAS['parent'],candidate_ROM=SHAS['candidate'],
  initial_strict_comparator_passed=False,initial_negative_receipt_sha256=sha(negative),
  retained_menu_at_state_transition=retained,displayed_lives_frames=len(displayed_lives),
  gameplay_video_frames=len(game),displayed_lives_and_gameplay_frame_hashes_exact=True,
  controller_inputs_exact=True,WRAM_frame_hashes_exact=True,
  scope='FNV32 actual framebuffer A/B; state-labelled frame124 still displays each prior menu. RAM is not claimed equal. No full-roster equivalence, Goku Hard clear, or FPS claim.')
 (O/'native/cold-hard-mario-presentation-review.json').write_text(json.dumps(proof,indent=2)+'\n')
 print(json.dumps(proof,indent=2))
if __name__=='__main__':
 p=argparse.ArgumentParser();p.add_argument('action',choices=['parent','candidate','compare','presentation']);a=p.parse_args()
 if a.action=='compare':compare()
 elif a.action=='presentation':presentation()
 else:launch(a.action)
