; Private DK host services. Storage measurement precedes callable admission.
; No source NPC walking/physics is invented: native Mario traversal is the
; disclosed playable adaptation, and the frozen NPC art/barrel clocks remain.
.pushseg
.segment "DONKEY_KONG_CORE"
DkHostStart:
DkProbeDX=$5c38
DkProbeDY=$5c39
DkProbeIndex=$5c3a
DkProbeCoordinate=$5c3b
DkProbePage=$5c3c
DkProbeMode=$5c3d
DkHitMask=$5c3e
DkHostTemp=$5c3f
DkPublishedSize=$5c7b

.proc DkSceneKey
 lda AreaType
 asl
 asl
 asl
 asl
 asl
 ora AreaAddrsLOffset
 rts
.endproc

; Called after the real resolver publishes raw28, before colors/portrait.
.proc DkHostResolve
 php
 lda SelectedCharacter
 pha
 farcall CmHostResolveCharacter
 pla
 cmp #CHARACTER_DONKEY_KONG
 bne NewOwner
 lda SelectedCharacter
 cmp #CHARACTER_DONKEY_KONG
 bne Done
 lda CrossoverContinue
 beq Construct
 jsr DkEnsure
 jmp Done
NewOwner:
 lda SelectedCharacter
 cmp #CHARACTER_DONKEY_KONG
 bne Done
Construct:
 jsr DkConstruct
Done:plp
 lda SelectedCharacter
 rts
.endproc
.proc DkHostFresh
 farcall CmHostFresh
 php
 pha
 lda SelectedCharacter
 cmp #CHARACTER_DONKEY_KONG
 bne Done
 pla
 plp
 jmp DkConstruct
Done:pla
 plp
 rts
.endproc
.proc DkHostMenuName
 php
 pha
 lda SelectedCharacter
 cmp #CHARACTER_DONKEY_KONG
 beq Own
 pla
 plp
 farcall GbPitQueueName,jmp
Own:pla
 plp
 BankPRGC #12
 jmp DkMenuName
.endproc
.proc DkHostGraphics
 BankPRGC #12
 jmp DkGraphics
.endproc
.proc DkHostDraw
 lda DkRenderBuffer
 sta DkPublishedSize
 BankPRGC #12
 jmp DkDraw
.endproc
.proc DkHostPortrait
 BankPRGC #12
 jmp DkPortrait
.endproc
.proc DkHostColors
 jsr DkEnsure
 BankPRGC #12
 jmp DkColors
.endproc
.proc DkHostReset
 lda #0
 farcall SpecialRosterClear
 jmp DkEnsure
.endproc
.proc DkHostBody
 pha
 lda AreaType
 sta GuestBodyStompAllowed
 lda CrossoverBehaviorVersion
 sta GuestBodyNoStomp
 pla
 clc
 rts
.endproc
.proc DkHostInjuryStatus
 jsr DkEnsure
 ldx DkTier
 txa
 rts
.endproc
.proc DkHostInjury
 jsr DkEnsure
 lda InjuryTimer
 bne Done
 lda DkTier
 beq Fatal
 dec DkTier
 lda DkTier
 sta PlayerStatus
 lda #90
 sta InjuryTimer
 lda #Sfx_PipeDown_Injury
 sta Square1SoundQueue
 lda #0
 sta DkAttack
 sta DkSpawn
Done:sec
 rts
Fatal:jmp KillPlayer
.endproc
.proc DkHostDeathStart
 lda #0
 sta DkTier
 sta DkAttack
 sta DkSpawn
 ldx #35
Clear:sta DkShots,x
 dex
 bpl Clear
 rts
.endproc
.proc DkHostDeath
 farcall NativePlayerDeath,jmp
.endproc
.proc DkHostVisible
 lda InjuryTimer
 beq Yes
 lda FrameCounter
 lsr
 bcs No
Yes:sec
 rts
No:clc
 rts
.endproc
.proc DkHostUi
 lda InvHudActive
 beq Done
 lda #0
 sta InvHudActive
 inc ReloadCHRBank
Done:rts
.endproc
.proc DkHostName
 cmp #0
 bne Done
 phy
 ldy #6
Copy:lda Name,y
 sta VRAM_Buffer1+11,y
 dey
 bpl Copy
 ply
 lda #0
Done:rts
Name:.byte "DK     "
.endproc

; Native emergence gate, followed by one physical erase/score/SFX and an
; explicit 60-update hosted freeze. No inventory or owner table is indexed.
.proc DkHostCollect
 lda PowerUpType,x
 cmp #2
 bcs Native
 lda Enemy_State,x
 bpl Done
 phx
 lda PlayerStatus
 sta GuestPowerupOld
 sta GuestPowerupDisplay
 lda PowerUpType,x
 jsr DkGrant
 lda DkTier
 sta GuestPowerupTarget
 jsr EraseEnemyObject
 plx
 phx
 lda #6
 jsr SetupFloateyNumber
 lda #Sfx_PowerUpGrab
 sta Square2SoundQueue
 farcall MarioSourceBeginFreeze
 plx
Done:rts
Native:farcall MarioSourcePowerupCollision,jmp
.endproc
.proc DkHostPowerup
 farcall GuestPowerupUpdate
 lda DkTier
 sta PlayerStatus
 lda #0
 sta PlayerSize
 rts
.endproc
.proc DkHostWeaponTail
 farcall DkHostWeapons
 farcall ProcFireball_Bubble::ProcAirBubbles,jmp
.endproc

.segment "DONKEY_KONG_HOST"
; Real signed world query. R0/R1 and Local_eb belong to the native caller.
; R2/R3/R4/R6/R7 remain the exact selected cell tuple for coin/block writers.
.proc DkTerrainRead
 lda Player_X_Position
 clc
 adc DkProbeDX
 sta R5
 lda Player_PageLoc
 ldx DkProbeDX
 bpl Positive
 adc #$ff
 jmp Page
Positive:adc #0
Page:sta DkProbePage
 and #1
 tay
 lda #>Block_Buffer_1
 sta R7
 lda R5
 lsr
 lsr
 lsr
 lsr
 clc
 adc BlockBufferAddr,y
 sta R6
 lda Player_Y_Position
 clc
 adc DkProbeDY
 sta DkProbeCoordinate
 bcs Empty
 cmp #32
 bcc Empty
 cmp #240
 bcs Empty
 and #$f0
 sec
 sbc #32
 sta R2
 tay
 lda (R6),y
 sta R3
Return:
 lda DkProbeMode
 beq Vertical
 lda R5
 jmp Low
Vertical:lda DkProbeCoordinate
Low:and #15
 sta R4
 ldx #0
 ldy DkProbeIndex
 lda R3
 rts
Empty:lda #0
 sta R3
 jmp Return
.endproc
.proc DkHostHead
 sty DkProbeIndex
 lda #0
 sta DkProbeMode
 sta DkProbeDY
 lda #8
 sta DkProbeDX
 jsr DkTerrainRead
 bne Done
 lda #$f3
 sta DkProbeDX
 jsr DkTerrainRead
 bne Done
 lda #29
 sta DkProbeDX
 jsr DkTerrainRead
Done:rts
.endproc
.proc DkHostFeetRouter
 lda SelectedCharacter
 cmp #CHARACTER_DONKEY_KONG
 beq Own
 cmp #CHARACTER_SOPHIA
 bne Cold
 cpy #31
 bne Cold
 bit SmClearance
 bpl Cold
 jmp BlockBufferColli_Feet
Cold:farcall Z2SourceFeetDispatch,jmp
Own:jmp DkHostFeet
.endproc
.proc DkHostFeet
 iny
 sty DkProbeIndex
 lda #0
 sta DkProbeMode
 lda #32
 sta DkProbeDY
 ; The actual caller's first/second foot indices are1/2 for the fixed big
 ; profile; each endpoint falls back to the center only if it is empty.
 lda #$f3
 cpy #1
 beq :+
 lda #29
:sta DkProbeDX
 jsr DkTerrainRead
 bne Done
 lda #8
 sta DkProbeDX
 jsr DkTerrainRead
Done:rts
.endproc
.proc DkHostSide
 sty DkProbeIndex
 lda #1
 sta DkProbeMode
 tya
 cmp #5
 lda #$f3
 bcc Left
 lda #29
Left:sta DkProbeDX
 tya
 and #1
 beq Lower
 lda #8
 bne Upper
Lower:
 lda #24
Upper:sta DkProbeDY
 jmp DkTerrainRead
.endproc
.proc DkHostAdder
 ldy #0
 sec
 rts
.endproc
.proc DkHostBox
 ; Called instead of the actual native BoundingBoxCore only forraw28.
 lda Player_Y_Position
 cmp #$f0
 bcs Hidden
 lda Player_Rel_XPos
 sec
 sbc #13
 bcs :+
 lda #0
: 
 sta BoundingBox_UL_Corner
 lda Player_Rel_XPos
 clc
 adc #29
 bcc :+
 lda #$ff
:
 sta BoundingBox_LR_Corner
 lda Player_Rel_YPos
 sta BoundingBox_UL_Corner+1
 clc
 adc #32
 bcc :+
 lda #$ff
:
 sta BoundingBox_LR_Corner+1
 ldx #0
 ldy #0
 farcall X5EasyFootBox,jmp
Hidden:lda #$ff
 sta BoundingBox_UL_Corner
 sta BoundingBox_UL_Corner+1
 sta BoundingBox_LR_Corner
 sta BoundingBox_LR_Corner+1
 rts
.endproc
.proc DkHostBoxProfile
 ldy #0
 rts
.endproc
.proc DkHostBoxGate
 php
 pha
 lda SelectedCharacter
 cmp #CHARACTER_DONKEY_KONG
 beq Own
 pla
 plp
 farcall LmBoundingBoxGate,jmp
Own:pla
 plp
 jmp DkHostBox
.endproc

; The existing shell/block defeat routine owns drops, scoring, erasure,
; Bowser's real terminal and audio. Each barrel contact retires that barrel;
; no broad fake-fireball state or remote result write is used.
.proc DkHostWeapons
 farcall DkSpawnBarrel
 lda #0
 sta DkSlot
Loop:
 ldx DkSlot
 lda DkShots,x
 beq Next
 jsr DkBarrelTerrain
 ldx DkSlot
 farcall DkBarrelStep
 ldx DkSlot
 lda DkShots,x
 beq Next
 jsr DkBarrelActors
Next:
 lda DkSlot
 clc
 adc #12
 sta DkSlot
 cmp #36
 bcc Loop
 rts
.endproc
.proc DkBarrelRead
 ; Actual shot world X/Y, not Player_X/Y substitution. Mode0 checks its
 ; support center+8/bottom16; mode1 leading edge/right16 orleft0/center8.
 lda DkShots+4,x
 clc
 adc DkProbeDX
 sta R5
 lda DkShots+5,x
 adc #0
 and #1
 tay
 lda #>Block_Buffer_1
 sta R7
 lda R5
 lsr
 lsr
 lsr
 lsr
 clc
 adc BlockBufferAddr,y
 sta R6
 lda DkShots+6,x
 clc
 adc DkProbeDY
 bcs Empty
 cmp #32
 bcc Empty
 cmp #240
 bcs Empty
 and #$f0
 sec
 sbc #32
 tay
 lda (R6),y
 tay
 lda MTileAttribute,y
 and #MTILE_SOLID
 rts
Empty:lda #0
 rts
.endproc
.proc DkBarrelTerrain
 lda #0
 sta DkQuery
 lda #8
 sta DkProbeDX
 lda #16
 sta DkProbeDY
 jsr DkBarrelRead
 beq Side
 inc DkQuery
Side:
 ldx DkSlot
 lda DkShots+7,x
 cmp #2
 lda #0
 bcs :+
 lda #16
:sta DkProbeDX
 lda #8
 sta DkProbeDY
 jsr DkBarrelRead
 beq Done
 lda DkQuery
 ora #2
 sta DkQuery
Done:rts
.endproc
.proc DkBarrelActors
 ldy #5
Scan:
 lda Enemy_Flag,y
 jeq Next
 lda Enemy_State,y
 and #$20
 jne Next
 lda EnemyOffscrBitsMasked,y
 jne Next
 lda Enemy_Y_HighPos,y
 cmp #1
 jne Next
 lda Enemy_ID,y
 cmp #Goomba
 bne Kind
 lda Enemy_State,y
 cmp #2
 jcs Next
 lda Enemy_ID,y
Kind:
 cmp #$15
 bcc Eligible
 cmp #Bowser
 bne Next
Eligible:
 ; AABB difference predicates use actual world pages, no camera alias.
 lda Enemy_X_Position,y
 sec
 sbc DkShots+4,x
 sta DkHostTemp
 lda Enemy_PageLoc,y
 sbc DkShots+5,x
 beq Right
 cmp #$ff
 bne Next
 lda DkHostTemp
 cmp #$f1
 bcc Next
 bcs Vertical
Right:lda DkHostTemp
 cmp #16
 bcs Next
Vertical:
 lda Enemy_Y_Position,y
 sec
 sbc DkShots+6,x
 clc
 adc #15
 cmp #31
 bcs Next
 sty DkProbeIndex
 txa
 pha
 tya
 tax
 stx R1
 jsr HandleEnemyFBallCol
 pla
 tax
 lda #0
 sta DkShots,x
 rts
Next:dey
 jpl Scan
 rts
.endproc

; A native late Vine group must follow the retained DK image's logical
; ownership. No image copy: each native sprite writes its true rotated OAM
; index, with the normal24-byte group rejected before cursor overflow.
.proc DkHostVine
 php
 pha
 lda SelectedCharacter
 cmp #CHARACTER_DONKEY_KONG
 bne Native
 lda GuestOamRotationActive
 cmp #1
 beq Own
Native:pla
 plp
 farcall MmReserveVine,jmp
Own:pla
 plp
 sty R0
 lda CurrentOAMOffset
 sta DkHostTemp
 lda RgOamPlayerStart
 clc
 adc DkPublishedSize
 jcs Done
 cmp DkHostTemp
 bcc Cursor
 sta DkHostTemp
Cursor:
 lda DkHostTemp
 cmp #232
 bcs Done
 clc
 adc #24
 sta CurrentOAMOffset
 lda DkHostTemp
 clc
 adc RgOamRotation
 tay
 sty R2
 ldx R0
 lda Enemy_Rel_YPos
 clc
 adc VineY,x
 sta DkProbeCoordinate
 ldx #0
Part:
 lda DkProbeCoordinate
 sta Sprite_Y_Position,y
 lda Vine_Start_Y_Position
 sec
 sbc DkProbeCoordinate
 cmp #100
 bcc Visible
 lda #$f8
 sta Sprite_Y_Position,y
Visible:
 txa
 and #1
 beq Left
 lda Enemy_Rel_XPos
 clc
 adc #6
 sta Sprite_X_Position,y
 lda #$61
 bne Attribute
Left:
 lda Enemy_Rel_XPos
 sta Sprite_X_Position,y
 lda #$21
Attribute:sta Sprite_Attributes,y
 lda #VINE_TILE_2
 cpx #0
 bne Tile
 lda R0
 bne Tip
 lda #VINE_TILE_1
 bne Tile
Tip:lda #VINE_TILE_2
Tile:sta Sprite_Tilenumber,y
 lda DkProbeCoordinate
 clc
 adc #8
 sta DkProbeCoordinate
 iny
 iny
 iny
 iny
 inx
 cpx #6
 bcc Part
Done:
 ldx #6
 sec
 ldy R0
 rts
VineY:.byte 0,48
.endproc
DkHostEnd:
.segment "DONKEY_KONG_ART"
.proc DkMenuName
 lda #<Name
 sta R2
 lda #>Name
 sta R3
 lda #0
 farcall NrQueueSelectName::NamePage,jmp
Name:.byte "  DONKEY KONG   "
.endproc
.popseg
