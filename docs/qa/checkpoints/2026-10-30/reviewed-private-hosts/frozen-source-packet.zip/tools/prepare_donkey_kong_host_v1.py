"""Sparse genuine DK host build on immutable ac126; no native/shared writes."""
from pathlib import Path
import hashlib,json,re,subprocess,sys
R=Path(__file__).resolve().parents[1]
P=R/'build/pit-retold-host-v3';C=R/'build/donkey-kong-component-v1';O=R/'build/donkey-kong-host-v1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def once(s,a,z):
 assert s.count(a)==1,(a[:90],s.count(a));return s.replace(a,z)
def p0_assets():
 from PIL import Image,ImageDraw
 original=(R/'build/dk-playable-assets-v3/dk.chr').read_bytes();pixels=bytearray(original)
 art=(R/'build/dk-playable-assets-v3/dk-art.inc').read_text()
 body_pages=list(map(int,re.search(r'DkPosePages:\n \.byte ([^\n]+)',art)[1].split(',')))
 bodies=[]
 for i in range(9):
  body=list(map(int,re.search('DkPose'+str(i)+r':\n \.byte ([^\n]+)',art)[1].split(',')))
  if body_pages[i]==3:assert all(body[k]<24 for k in range(1,len(body),4))
  bodies.append(body)
 for t in range(24,48):
  at=3072+t*16
  for y in range(8):pixels[at+8+y]=original[at+8+y]|original[at+y]
 # Body/portrait patterns, including the death pose that shares page3,
 # remain literally exact. Only independent barrel high planes merge.
 assert pixels[:3072+24*16]==original[:3072+24*16] and pixels[3072+48*16:]==original[3072+48*16:]
 for i in range(6):
  m=re.search('DkBarrel'+str(i)+r': \.byte ([^\n]+)',art);values=list(map(int,m[1].split(',')))
  for k in range(2,len(values),4):assert values[k]==1;values[k]=0
  art=art[:m.start(1)]+','.join(map(str,values))+art[m.end(1):]
 art=art.replace('DkPalette: .byte $0f,$30,$36,$06','DkPalette: .byte $0f,$30,$27,$06')
 (O/'dk-p0.chr').write_bytes(pixels);(O/'dk-p0-art.inc').write_text(art)
 colors={0x0f:(0,0,0),0x30:(252,252,252),0x36:(252,176,176),0x06:(108,6,0),0x27:(252,152,56),0x02:(0,0,188)}
 sheet=Image.new('RGB',(540,184),(24,32,40));d=ImageDraw.Draw(sheet)
 d.text((4,2),'AUTHENTIC SOURCE COLORS / PRIVATE P0 ADAPTATION',(235,235,235))
 def draw(rec,page,patterns,palette,x0,y0,left=16,scale=2):
  for k in range(1,len(rec),4):
   tile,attr,yy,xx=rec[k:k+4];xx=xx if xx<128 else xx-256;yy=(yy if yy<128 else yy-256)+1
   for y in range(16):
    at=page*1024+(tile+y//8)*16+y%8
    for x in range(8):
     v=(patterns[at]>>(7-x)&1)|((patterns[at+8]>>(7-x)&1)<<1)
     if v:
      dx=7-x if attr&64 else x;dy=15-y if attr&128 else y
      px=x0+(xx+left+dx)*scale;py=y0+(yy+dy)*scale
      d.rectangle((px,py,px+scale-1,py+scale-1),fill=colors[palette[v]])
 for j,i in enumerate([0,3,8]):
  x=j*180;d.text((x+4,20),'pose'+str(i),(235,235,235))
  draw(bodies[i],body_pages[i],original,[15,48,54,6],x,32)
  draw(bodies[i],body_pages[i],pixels,[15,48,39,6],x+82,32)
 for i in range(6):
  rec=list(map(int,re.search('DkBarrel'+str(i)+r': \.byte ([^\n]+)',art)[1].split(',')))
  x=12+i*86;draw(rec,3,original,[15,6,39,2],x,118,0)
  draw(rec,3,pixels,[15,48,39,6],x+36,118,0)
 d.text((4,162),'Body36->27; barrel02->06. Native palettes1/2/3 retained.',(235,235,235))
 sheet.save(O/'p0-source-preview.png')
 (O/'p0-assets.json').write_text(json.dumps(dict(body_colors_source=[15,48,54,6],body_and_weapon_P0=[15,48,39,6],barrel_source=[15,6,39,2],barrel_class_map=[0,3,2,3],source_quantization={'36':'27','02':'06'},geometry_HV_opacity_unchanged=True,body_and_portrait_CHR_literal_exact=True,changed_pattern_tile_indices=list(range(24,48)),only_source_page3_barrel_high_planes_changed=True),indent=2)+'\n')
def menu_assets(raw,table_source):
 from PIL import Image
 sys.path.insert(0,str(R/'tools/reference'))
 from build_roster_expansion_menu import navigation,encode
 nt=bytearray((R/'chr/raw/roster-expansion-menu.bin').read_bytes())
 packed=bytearray((R/'chr/characters/packed-mmc5-roster-expanded.chr').read_bytes())
 assert packed[4096:8192]==raw[1048592+4096:1048592+8192]
 dk=(R/'build/dk-playable-assets-v3/dk.chr').read_bytes()[3072:4096]
 pic=Image.new('P',(24,16))
 for col,tile in enumerate([48,50,52]):
  for y in range(16):
   for x in range(8):
    p=tile*16+(y//8)*16+y%8
    value=(dk[p]>>(7-x)&1)|((dk[p+8]>>(7-x)&1)<<1)
    pic.putpixel((col*8+x,y),[0,3,2,1][value])
 pic=pic.resize((16,11),Image.Resampling.NEAREST)
 canvas=Image.new('P',(16,24));canvas.paste(pic,(0,13))
 used=set(nt[:960]);available=[i for i in range(64,252)if i not in used]
 tiles={bytes(packed[4096+i*16:4096+(i+1)*16]):i for i in range(252)}
 new=[]
 for ty in range(3):
  for tx in range(2):
   data=encode([[canvas.getpixel((tx*8+x,ty*8+y))for x in range(8)]for y in range(8)])
   if data not in tiles:
    assert available,'Measured menu tile capacity exhausted'
    i=available.pop(0);tiles[data]=i;packed[4096+i*16:4096+(i+1)*16]=data;new.append(i)
   nt[(16+ty)*32+27+tx]=tiles[data]
 (O/'menu.chr').write_bytes(packed);(O/'menu.bin').write_bytes(nt)
 def array(name):
  m=re.search(name+r':\n \.byte ([^\n]+)',table_source);assert m,name
  return[int(x)for x in m[1].split(',')]
 presence=array('X5MenuPresent');presence[27]=1
 chars=array('X5MenuCharacters');chars[27]=28
 live=[i for i,v in enumerate(presence)if v];nav=navigation(live)
 result=table_source
 arrays={'X5Menu'+d.capitalize():[nav[i][d]if i in nav else 0 for i in range(28)]for d in['left','right','up','down']}
 arrays.update(X5MenuCharacters=chars,X5MenuPresent=presence)
 for name,values in arrays.items():
  result=re.sub('('+name+r':\n \.byte )[^\n]+',lambda m:m[1]+','.join(map(str,values)),result)
 (O/'menu-assets.json').write_text(json.dumps(dict(source='Frozen DK original idle record, same component24x16 portrait, nearest-neighbor16x11 grayscale menu adaptation',new_tiles=new,present=live,DK_slot=27,DK_raw=28),indent=2)+'\n')
 return result
def main():
 assert not(O/'handoff.json').exists(),'Frozen packets need a successor'
 (O/'src').mkdir(parents=True,exist_ok=True)
 # These two provisional leaves are no longer assembler inputs. Remove only
 # these exact unbound scratch files, so include search cannot select stale
 # collision hooks or the audio leaf's obsolete directory.
 for stale in [O/'src/collision.s',O/'src/audio.s']:
  assert stale.resolve().is_relative_to(O.resolve())
  stale.unlink(missing_ok=True)
 parent=json.loads((P/'closure.json').read_text())
 assert sha(P/'candidate.nes')=='ac126b545ceb0c27f4843dbbf2eed647f07288a74a7a036d6769db6e3df0b1d2'
 for p,h in parent['actual_dependencies'].items():assert sha(p)==h,p
 assert sha(C/'handoff.json')=='40035c4d8810253763f7a5e3a9fbc499d35cbdb89c14bb724875aecbe0047228'
 p0_assets()
 sys.path.insert(0,str(R/'tools/reference'))
 from donkey_kong_host_routes_v1 import routes
 sources={}
 def actual(name):
  choices=[Path(p)for p in parent['actual_dependencies']if Path(p).name==name]
  assert len(choices)==1,(name,choices)
  return choices[0]
 def change(name,fn):
  source=actual(name);before=source.read_text();after=fn(before)
  sources[name]=dict(path=str(source),sha256=sha(source))
  destination=O/'src'/('music_drivers/audio.s'if name=='audio.s'else name)
  destination.parent.mkdir(exist_ok=True);destination.write_text(after)
 raw=(P/'candidate.nes').read_bytes()
 change('new_roster_dispatch.s',routes)
 selector=R/'build/gimmick-resident-selector-v1/src/mmc5.s'
 assert sha(selector)=='3823474c74e30dde960448a0f5c25bf79a539f4e32aa2ca063c29d2b5b15c549'
 change('mmc5.s',lambda _:selector.read_text())
 change('roster_expansion_menu.inc',lambda s:menu_assets(raw,s))
 def feet(s):
  start=s.index('::CrossoverSourceFootProbe:');end=s.index('  .assert *-CrossoverHeadProbe=62',start)
  old=s[start:end]
  new="""::CrossoverSourceFootProbe:
.if ::ENABLE_MMC5_EXPANDED
  lda SelectedCharacter
  cmp #CHARACTER_LINK
  beq FootCold
  cmp #CHARACTER_SOPHIA
  beq FootCold
  cmp #CHARACTER_DONKEY_KONG
  bne FootNative
FootCold:
  farcall DkHostFeetRouter,jmp
FootNative:
  jmp BlockBufferColli_Feet
  .res 5,$ea
"""
  return s[:start]+new+s[end:]
 change('characters.s',feet)
 change('tmnt.s',lambda s:once(s,'.include "tmnt_head_ceiling.inc"','.include "build/donkey-kong-host-v1/src/tmnt_head_ceiling.inc"'))
 change('tmnt_head_ceiling.inc',lambda s:once(s,'farcall JnHeadDispatch,jmp','farcall NrHead,jmp'))
 change('sprite_render.s',lambda s:once(s,'  farcall MmReserveVine','  farcall DkHostVine'))
 change('player.s',lambda s:once(s,'farcall LmBoundingBoxGate','farcall DkHostBoxGate'))
 def select(s):
  s=once(s,'farcall CmHostResolveCharacter,jmp','farcall DkHostResolve,jmp')
  s=once(s,'  jmp GbPitQueueName\n  .res 15,$ea','  farcall DkHostMenuName,jmp')
  return once(s,'.incbin "chr/raw/roster-expansion-menu.bin"','.incbin "build/donkey-kong-host-v1/menu.bin"')
 change('character_select.s',select)
 def audio(s):
  s=re.sub(r'(?m)^(\.include ")([^"/]+)(")$',lambda m:m[1]+'src/music_drivers/'+m[2]+m[3],s)
  s=once(s,'  cmp #CHARACTER_SUNNY\n  beq CrossoverVanillaAudio','  cmp #CHARACTER_DONKEY_KONG\n  beq CrossoverVanillaAudio\n  cmp #CHARACTER_SUNNY\n  beq CrossoverVanillaAudio')
  return once(s,'  .res 5,$ea                    ; unexecuted, keeps native/following public PCs','  .res 1,$ea                    ; four bytes consumed by exact DK native admission')
 change('audio.s',audio)
 core=(R/'src/donkey_kong_core.s').read_text()
 core=core.replace('lda AreaAddrsLOffset','jsr DkSceneKey')
 (O/'src/donkey_kong_core.s').write_text(core)
 render=(R/'src/donkey_kong_render.s').read_text()
 render=once(render,' jsr DkSetPose\n jmp DkColors',' jsr DkSetPose\n jsr DkDraw\n jmp DkColors')
 render=once(render,' lda Player_SprAttrib\n and #$fc\n sta Player_SprAttrib',''' lda StarInvincibleTimer
 beq NormalAttributes
 lda Player_SprAttrib
 and #$23
 jmp Attributes
NormalAttributes:
 lda Player_SprAttrib
 and #$20
Attributes:sta Player_SprAttrib''')
 start=render.index('.proc DkQueuePalette');end=render.index('.endproc',start)+len('.endproc')
 render=render[:start]+'''.proc DkQueuePalette
 lda StarInvincibleTimer
 ora GuestPowerupActive
 beq Normal
 lda #$ff
 sta DkPaletteAck
 rts
Normal:
 lda DkPaletteAck
 beq Done
 ldx VRAM_Buffer1_Offset
 cpx #78
 bcs Done
 lda #$3f
 sta VRAM_Buffer1,x
 lda #$11
 sta VRAM_Buffer1+1,x
 lda #3
 sta VRAM_Buffer1+2,x
 lda #$30
 sta VRAM_Buffer1+3,x
 lda #$27
 sta VRAM_Buffer1+4,x
 lda #6
 sta VRAM_Buffer1+5,x
 txa
 clc
 adc #6
 tax
 stx VRAM_Buffer1_Offset
 lda #0
 sta VRAM_Buffer1,x
 sta DkPaletteAck
Done:rts
.endproc'''+render[end:]
 (O/'src/donkey_kong_render.s').write_text(render)
 host=(R/'tools/reference/donkey_kong_host_v1.s').read_text()
 (O/'src/donkey_kong_host.s').write_text(host)
 entry=(C/'entrypoint.s').read_text()
 entry=entry.replace('.include "src/donkey_kong_core.s"','.include "'+(O/'src/donkey_kong_core.s').relative_to(R).as_posix()+'"')
 entry=entry.replace('.include "src/donkey_kong_render.s"','.include "'+(O/'src/donkey_kong_render.s').relative_to(R).as_posix()+'"')
 entry=once(entry,'.pushseg\n.segment "DONKEY_KONG_CHR"\n.incbin "build/dk-playable-assets-v3/dk.chr"\n.popseg','; DK CHR is assembled as a separate genuine object to retain the ca65 segment limit.')
 entry=once(entry,'.incbin "chr/characters/packed-mmc5-roster-expanded.chr"','.incbin "build/donkey-kong-host-v1/menu.chr"')
 (O/'chr.s').write_text('.segment "DONKEY_KONG_CHR"\n.incbin "build/donkey-kong-host-v1/dk-p0.chr"\n')
 entry=once(entry,'.include "build/dk-playable-assets-v3/dk-art.inc"','.include "build/donkey-kong-host-v1/dk-p0-art.inc"')
 entry+='\n.if ::ENABLE_MMC5_EXPANDED .and ::MAPPER_MMC5\n.include "'+(O/'src/donkey_kong_host.s').relative_to(R).as_posix()+'"\n.endif\n'
 (O/'entrypoint.s').write_text(entry)
 cfg=(C/'smb1base-mmc5-expanded.cfg').read_text()
 cfg=once(cfg,'X5_NEW_41: start=$c000, size=$2000,','X5_NEW_41: start=$c000, size=$1c00,')
 cfg=once(cfg,'    X5_NEW_42:', '    DK_HOST_A65: start=$bc00,size=$0400,type=ro,file=%O,fill=yes,fillval=$ff,bank=$41;\n    X5_NEW_42:')
 cfg=once(cfg,'    DONKEY_KONG_ART:', '    DONKEY_KONG_HOST:load=DK_HOST_A65,type=ro,start=$bc00,optional=yes;\n    DONKEY_KONG_ART:')
 (O/'smb1base-mmc5-expanded.cfg').write_text(cfg)
 assert raw[16+65*8192+0x1c00:16+66*8192]==bytes([255])*1024
 command=parent['commands'][0][:]
 command[4:4]=['-I',str(O/'src'),'-I',str(R/'src/music_drivers')]
 command[command.index('-o')+1]=str(O/'main.o')
 command[command.index('--create-full-dep')+1]=str(O/'main.d')
 command[-1]=str(O/'entrypoint.s')
 q=subprocess.run(command,cwd=R,capture_output=True,text=True)
 (O/'assemble.log').write_text(q.stdout+q.stderr)
 assert not q.returncode,q.stderr
 # Require the assembler's real include closure to consume every staged
 # source leaf. Relative nested includes otherwise prefer the owner's cwd.
 dep=(O/'main.d').read_text().split(':\t',1)[1].strip().removesuffix(':')
 consumed={str((Path(w.replace('\\ ',' '))if Path(w.replace('\\ ',' ')).is_absolute()else R/w.replace('\\ ',' ')).resolve()).lower()for w in re.split(r'(?<!\\)\s+',dep)}
 for name in sources:
  leaf=O/'src'/('music_drivers/audio.s'if name=='audio.s'else name)
  assert str(leaf.resolve()).lower()in consumed,('Staged source not actually assembled',leaf)
 chr_command=[str(R/'tools/Windows/cc65/bin/ca65.exe'),'-g','-I',str(R),'-o',str(O/'chr.o'),str(O/'chr.s')]
 q=subprocess.run(chr_command,cwd=R,capture_output=True,text=True);assert not q.returncode,q.stderr
 dump=subprocess.run([str(R/'tools/Windows/cc65/bin/od65.exe'),'--dump-segments',str(O/'main.o')],capture_output=True,text=True,check=True).stdout
 (O/'size.txt').write_text(dump)
 sizes={name:int(size)for name,size in re.findall(r'Name:\s+"(DONKEY_KONG_\w+)"\s+Flags:\s+\d+\s+Size:\s+(\d+)',dump)}
 assert sizes['DONKEY_KONG_CORE']<=1475 and sizes['DONKEY_KONG_HOST']<=1024 and sizes['DONKEY_KONG_ART']<=1261,sizes
 link=json.loads((C/'build-proof.json').read_text())['commands'][1][:]
 for i,value in enumerate(link):
  for name in['main.o','smb1base-mmc5-expanded.cfg','candidate.nes','candidate.dbg','candidate.lbl','candidate.map']:
   value=value.replace(str(C/name),str(O/name))
  link[i]=value
 link+=[str(O/'chr.o')]
 q=subprocess.run(link,cwd=R,capture_output=True,text=True)
 (O/'link.log').write_text(q.stdout+q.stderr);assert not q.returncode,q.stderr
 sys.path.insert(0,str(R/'tools'))
 from prepare_cv3_dmc_mirror import prepare
 prepare(R,O/'candidate.nes')
 candidate=(O/'candidate.nes').read_bytes()
 changes={k:sum(a!=z for a,z in zip(raw[16+k*8192:16+(k+1)*8192],candidate[16+k*8192:16+(k+1)*8192]))for k in range(128)}
 changes={k:v for k,v in changes.items()if v}
 result=dict(status='PRIVATE_DRAFT_LINKED_NOT_QUALIFIED',native_run=False,sizes=sizes,
    core_limit=1475,core_shortfall=max(0,sizes['DONKEY_KONG_CORE']-1475),
    existing_component_core=799,host_bytes=sizes['DONKEY_KONG_CORE']-799,
    source_preimages=sources,
    open=['Frozen independent resident selector included; own combined controls still required','Full caller/foreign/IRQ controls pending','No native or playable claim'],
    ROM_sha256=sha(O/'candidate.nes'),diff_by_bank=changes,
    commands=[command,chr_command,link],bindings={str(p):sha(p)for p in[Path(__file__),R/'tools/reference/donkey_kong_host_v1.s',O/'entrypoint.s',O/'src/donkey_kong_core.s',O/'src/donkey_kong_host.s',C/'handoff.json',P/'candidate.nes',P/'candidate.dbg',P/'candidate.lbl']})
 (O/'draft-size.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps({k:v for k,v in result.items()if k not in ['commands','bindings','source_preimages']},indent=2))
if __name__=='__main__':main()
