"""Freeze only the actual source-linked CPU qualification; never install a ROM."""
from pathlib import Path
import hashlib,json,re,shutil,sys,zipfile
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(Path(__file__).parent))
from check_tmnt_render_oa import load,address,location
W=R/'build/quickman-host-integrate-v3';O=R/'build/quickman-host-cpu-v4';P=R/'build/character-host-union-v5'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def digest(b):return hashlib.sha256(b).hexdigest()
def put(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n',newline='\n')
def main():
    assert not O.exists(),'Frozen packet already exists'
    new=load(W/'candidate.nes');old=load(P/'candidate.nes');raw=new['raw'];prior=old['raw'];rom=digest(raw)
    assert rom=='774a78ed9b9ca4bee3276019fac40a0233abc71f5d5d26f9dacb2963b7bd329d'
    controls=['source-controls-v3.json','render-controls-v3.json','public-controls-v3.json','contact-controls-v3.json','negative00-01-ABI-v3.json','full-main-controls-v3.json','controller-latch-pause-v3.json','ceiling-item-controls-v3.json','real-isr-controls-v3.json','foreign-main-controls-v3.json']
    for n in controls:
        d=json.loads((W/n).read_text());assert d['ROM_sha256']==rom,(n,d['ROM_sha256'])
        if'passed'in d:assert d['passed'],n
    layout=json.loads((W/'quick-layout.json').read_text());lease=json.loads((W/'lease-copy.json').read_text());spans=lease['Quick_Man']['PRG'];owned=set();rows=[]
    for row in layout['placements']:
        start=row['offset'];end=start+row['bytes'];bank=row['bank']
        assert any(s['bank']==bank and s['start']<=start and end<=s['end']for s in spans),row
        assert not(bank==93 and start<0xfe7 and end>0xfa7),row
        seg=next(s for s in new['segs'].values()if s['name'].strip('"')==row['segment']);at=int(seg['ooffs'],0)
        assert at==16+8192*bank+start and int(seg['size'],0)==row['bytes'],row
        assert prior[at:at+row['bytes']]==b'\xff'*row['bytes'],row
        owned.update(range(at,at+row['bytes']));rows.append(dict(row,linked_sha256=digest(raw[at:at+row['bytes']]),actual_parent_FF_preimage=True))
    assert len(owned)==9886 and layout['headroom_bytes']==174
    # Exact linked retained-near targets, not a hypothetical co-residency claim.
    near=json.loads((W/'quick/near-source-proof.json').read_text())
    for row in near['changes']:
        assert row['removed_gate']not in new['syms'],row
        assert(location(new,row['retained_source_target'])-16)//8192==row['physical_bank_required'],row
    # Every non-Quick parent mutation is enumerated by exact source segment.
    segs=[(int(s['ooffs'],0),int(s['ooffs'],0)+int(s['size'],0),s['name'].strip('"'))for s in new['segs'].values()if'ooffs'in s]
    diffs=[];counts={}
    for at,(before,after)in enumerate(zip(prior,raw)):
        if before==after or at in owned or not 16<=at<16+128*8192:continue
        segment=next((n for a,z,n in segs if a<=at<z),'CV3_FIXED_MIRROR')
        assert segment in ['PLAYER','PROTO_MENU','FULL_ROSTER_MENU','CHARACTER_HOST_UNION','NEW_ROSTER_GATE','FIXED','CV3_FIXED_MIRROR'],(hex(at),segment)
        bank=(at-16)//8192;offset=(at-16)%8192
        if segment=='CV3_FIXED_MIRROR':assert bank==125
        counts[segment]=counts.get(segment,0)+1
        diffs.append(dict(bank=bank,offset=offset,before=before,after=after,segment=segment))
    fixed=[d for d in diffs if d['bank']in [125,127]];assert len(fixed)==4
    target=address(new,'HuAfterTerrainGate');oldtarget=address(old,'HuAfterTerrainGate')
    for bank in [125,127]:
        rr=[d for d in fixed if d['bank']==bank];assert len(rr)==2
        assert rr[0]['offset']+5==rr[1]['offset']
        assert all(raw[16+bank*8192+r['offset']-1]==prior[16+bank*8192+r['offset']-1]==0xa9 for r in rr)
        assert [r['before']for r in rr]==[oldtarget&255,oldtarget>>8]
        assert [r['after']for r in rr]==[target&255,target>>8]
    smc=next(s for s in new['segs'].values()if s['name']=='"SMCCODE"');at=int(smc['ooffs'],0);n=int(smc['size'],0)
    osm=next(s for s in old['segs'].values()if s['name']=='"SMCCODE"');oa=int(osm['ooffs'],0)
    assert n==int(osm['size'],0)==33 and raw[at:at+n]==prior[oa:oa+n]
    # Actual source-state projection and linker sections exclude all live globals.
    state=[]
    for s in new['segs'].values():
        name=s['name'].strip('"')
        if name.startswith('QM_')and'ooffs'not in s:
            a=int(s['start'],0);z=a+int(s['size'],0);assert 0x5c00<=a<z<=0x5e30
            assert not any(a<=v<z for v in [0x5cc3,0x5dcc,0x5dcd])
            state.append(dict(segment=name,start=a,end_exclusive=z))
    assert sum(s['end_exclusive']-s['start']for s in state)==557
    persistent=new['syms']['QhPersistent'];assert int(persistent['val'],0)==0x5f88
    chrstart=16+128*8192;art=R/'build/quickman-host-plan-v1/art/quick-man-window0-5pages.chr'
    assert raw[chrstart:chrstart+251*1024]==prior[chrstart:chrstart+251*1024]
    assert raw[chrstart+251*1024:chrstart+256*1024]==art.read_bytes()
    assert location(new,'QuickManHostChr')==chrstart+251*1024
    assert raw[chrstart+256*1024:]==prior[chrstart+256*1024:]
    O.mkdir();source=[]
    names=['candidate.nes','candidate.dbg','candidate.lbl','candidate.cv3-mirror.json','quick.cfg','quick-layout.json','quick-route-table.json','parent-commands.json','parent-reproduction.json','quick-build-log.json']+controls
    for n in names:shutil.copy2(W/n,O/n)
    for n in ['union.s','entrypoint.s','quick-parent-exports.inc','src/new_roster_dispatch.s','src/player.s','src/character_select.s','src/full_roster_menu.s']:
        dest=O/'source'/n;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(W/n,dest);source.append(W/n)
    for p in (W/'quick').iterdir():
        if p.suffix in ['.s','.inc','.bin','.json']:dest=O/'source/quick'/p.name;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(p,dest);source.append(p)
    artifacts=[Path(__file__),*[R/'tools/audit'/n for n in ['quickman_host_integrate_v3.py','quickman_host_runtime_v3.s','quickman_host_controls_v3.py','quickman_host_main_v3.py','quickman_host_ceiling_v3.py','quickman_host_trace_v3.py']],R/'tools/prepare_cv3_dmc_mirror.py',art]
    artifacts += [R/'build/quickman-host-prep-v2'/n for n in ['core.s','render.s','parent-symbols.json','joint-request.json','fragmented.cfg']]
    artifacts += [W/'frozen-inputs/build/kamikaze-mario-host-v4/c-full.s']
    with zipfile.ZipFile(O/'source-closure.zip','w',zipfile.ZIP_DEFLATED)as z:
        for p in sorted(set(source+artifacts)):
            z.write(p,str(p.relative_to(R)).replace('\\','/'))
    preimages=[P/'candidate.nes',P/'candidate.dbg',P/'candidate.lbl',P/'handoff.json',P/'frozen-1a71b8b5.zip',R/'build/quickman-host-prep-v2/handoff.json',R/'build/quickman-host-plan-v1/art/window0-proof.json',R/'build/quickman-component-v2/palette/palette-owner.json',R/'build/quickman-component-v2/handoff.json',R/'docs/qa/checkpoints/2026-10-30/arthur-quick-private-allocation/root-review-and-reservations.json',R/'docs/qa/checkpoints/2026-10-30/union-bbox-reallocation/root-review-and-reservations.json',Path('C:/NES/the stash/Rockman_CX-world44.spcs.bio.nes')]
    inventory=json.loads((W/'quick-route-table.json').read_text())
    inventory.update(actual_source_audio_callback='QuickManSound preserves caller A/P, queues host Square1 effect20; original CX effect/theme driver is NOT integrated or qualified.',actual_NMI_ownership='Existing parent NMI/audio/CHR publication only. Quick source runs once per active foreground update, never from NMI; host pause suppresses Tick.',readiness=False)
    put(O/'public-hook-inventory.json',inventory)
    put(O/'linked-source-proof.json',dict(passed=True,ROM_sha256=rom,payload_bytes=len(owned),retained_PRG_lease=10060,headroom=174,placements=rows,near_transfers=near,active_RAM=state,active_RAM_bytes=557,persistent_RAM=[0x5f88,0x5f90],new_ZP=0,borrowed_ZP=['R0/R1 restored at public dispatch','R6/R7 restored locally by world/hit workers'],shared_SMC_33bytes_exact=True,fixed_operand_edits=fixed,parent_changed_segment_byte_counts=counts,parent_changed_bytes=diffs,CHR_pages=[251,256],CHR_bytes=5120,CHR_prior_pages0_250_exact=True,unchanged_parent_archive_sha256=sha(P/'frozen-1a71b8b5.zip')))
    report='''This packet is a private actual-host Quick Man CPU candidate, not an admission or installed shared ROM.

The linked source preserves all35 authenticated CX routines and the conservative535 source fields, plus source A edges, movement, wall abilities and native three-shot fan. Thirty authentic body poses and four shot frames use five granted CHR pages, window0/upper0 only. Full lifecycle reset is compared across every projected source field/work byte for20 alternating-player resets; each player keeps HP/maxHP/progression in its4-byte record.

Actual CPU evidence:1520 source-controller differential updates;300 exact pose/facing/cursor OAM cases;256 explicit00/01 fallback ABI cases;282 foreign complete-Main cases;160 active Main updates through real serial controller ports, native scrolling, jump/land and fan;65 pause/resume updates;164 real vector NMI/IRQ interruptions across82 executed seams. The source ceiling bonk and native question block occur together at hostY151 and retain source VY FF.C0. No post-NMI controller-RAM injection supports these active-input proofs.

Coordinate contract: sourceX=SMB X+8, sourceY=SMB top-left+20. Original CX floor/support clamp is tileTop-12; native SMB foot is+32. Import preserves fractions on unchanged integer axes and does not force source gravity/state to zero. Native clamps resync after terrain, and PlayerCtrl owns scrolling. Quick's head adapter uses its admitted profile0 explicitly because the live generic chain arrives with a clobbered Y.

Resources:9886 of10060 retained granted PRG bytes;174 fragmented headroom;557 selected-owner transient bytes excluding5CC3 and5DCC/DD;8 persistent bytes;no new ZP;borrow/restoredR0/R1 andR6/R7;5120 CHR bytes at251..255. The64 bytes93:0FA7..<0FE7 released to Union Bill remain permanently excluded. A79 changes fit inside its existing B5E0..<C000 allocation. Original33-byte shared SMC is exact. Fixed127 has only two linked HuAfterTerrainGate operand edits; genuine prepare_cv3_dmc_mirror regenerates the same two edits in125. Exact changed bytes are enumerated.

Limits:active Main max39208 CPU; normal NMI fixture max11206 CPU. NTSC cadence has NOT passed. Root's future WRAM mechanism is not adopted. Native boot/menu/controller/render/palette/gameplay/campaign/Hard qualification is still required. Palette queue capacity and decoded source palette fixture do not prove native RGB installation/unlock. Original CX sound/theme driver and native enemy-contact cadence/dictionaries are open; source sound currently queues generic host effect20. Native Goomba/Buzzy/Bowser100-unit HP/armor fixtures pass as an explicit SMB adaptation. Water, automatic transitions, noninteractive state controls, platforms and audio/world ownership need broader actual-host/native evidence. No canonical sources, Downloads or user Mesen window were modified.

Reproduction:source-closure.zip contains private changed/generated sources, tools, direct prep inputs and art; apply it with the exact immutable parent source archive bound in handoff.json. The earlier parent reproduction is bit-exact. Build via the saved builder and actual command list; do not rerun --prepare on this frozen packet. Earlier fixture/foreign negatives remain in the working predecessor and are bound as evidence, not passing claims.
'''
    (O/'README.txt').write_text(report,newline='\n')
    negatives=sorted([p for p in W.glob('first-*.json')]+[W/'active-input-before-anchor-correction-v3.json',W/'physical-chr-order-negative-v3.json'])
    for p in negatives:dest=O/'negatives'/p.name;dest.parent.mkdir(exist_ok=True);shutil.copy2(p,dest)
    files=[p for p in O.rglob('*')if p.is_file()]
    bindings={str(p.resolve()):sha(p)for p in files+preimages+artifacts}
    handoff=dict(status='FROZEN_ACTUAL_HOST_CPU_CANDIDATE_NATIVE_AND_CADENCE_OPEN',ROM_sha256=rom,shared_install=False,native_qualification=False,source_original_sha256=sha(preimages[-1]),code_bytes=9886,retained_PRG_lease=10060,headroom_bytes=174,transient_RAM_bytes=557,persistent_RAM_bytes=8,new_ZP_bytes=0,CHR_bytes=5120,files=len(files),bindings=bindings)
    put(O/'handoff.json',handoff)
    print(json.dumps(dict(packet=str(O),handoff_sha256=sha(O/'handoff.json'),ROM_sha256=rom,files=len(files),CPU_only=True),indent=2))
if __name__=='__main__':main()
