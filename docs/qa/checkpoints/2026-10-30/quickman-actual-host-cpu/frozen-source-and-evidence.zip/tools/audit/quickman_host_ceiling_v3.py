"""Controller-stream actual-Main ceiling/item contract, CPU fixture only."""
from pathlib import Path
import hashlib,json,sys
sys.path.insert(0,str(Path(__file__).parent))
import quickman_host_main_v3 as h
def main():
    B=h.U.scoped_load(h.O/'candidate.nes');h.N.B=B;q=h.make(B)
    at=h.U.location(B,'MTileAttribute');attrs=B['raw'][at:at+256]
    tile=0xc1;assert attrs[tile]&1,('question tile is not solid',attrs[tile])
    cell=h.U.address(B,'Block_Buffer_1')+7*16+6;q.m[cell]=tile
    rows=[]
    for age in range(24):
        mask=128 if 5<=age<18 else 0
        h.input_nmi(q,mask)
        c,tr,mn=h.U.C.M.runtrace(q,'GameLoop')
        rows.append(dict(age=age,Y=q.get('Player_Y_Position'),state=q.get('QmField_002C'),VY=[q.get('QmField_0640'),q.get('QmField_0660')],host_VY=q.get('Player_Y_Speed'),tile=q.m[cell],bounce=q.get('BlockBounceTimer'),source_bonk=tr.count(h.U.point(B,'QhBonkFlag')),native_head_calls=tr.count(h.U.point(B,'PlayerHeadCollision'))))
    passed=any(r['native_head_calls']and r['source_bonk']and r['Y']==151 and r['VY']==[255,192]for r in rows)and any(r['tile']!=tile or r['bounce']for r in rows)
    assert all(not r['native_head_calls']or r['source_bonk']for r in rows),'native effect preceded genuine source bonk'
    receipt=dict(passed=passed,ROM_sha256=h.sha(h.O/'candidate.nes'),native=False,fixture='Native flat floor208, actual solid mushroom question tileC1 at144..159 above controller-driven source jump. No geometry/velocity RAM injection after initialization.',rows=rows)
    (h.O/'ceiling-item-controls-v3.json').write_text(json.dumps(receipt,indent=2)+'\n')
    if not passed:
        negative=h.O/'first-ceiling-item-negative-v3.json'
        if not negative.exists():negative.write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps(dict(passed=passed,ROM_sha256=receipt['ROM_sha256'],bonk_rows=[r for r in rows if r['source_bonk']or r['native_head_calls']]),indent=2))
    assert passed,'Actual native question-block effect was not reached'
if __name__=='__main__':main()
