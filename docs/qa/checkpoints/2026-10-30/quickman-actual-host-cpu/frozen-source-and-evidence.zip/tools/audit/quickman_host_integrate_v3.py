"""Source-only private Quick Man integration into the frozen union-v5 parent."""
from pathlib import Path
import hashlib,json,re,subprocess,sys,zipfile
R=Path(__file__).resolve().parents[2]
sys.path.insert(0,str(Path(__file__).parent))
import quickman_host_prepare_v2 as prep
from check_tmnt_render_oa import load
O=R/'build/quickman-host-integrate-v3';T=O/'frozen-inputs';P=R/'build/character-host-union-v5'
LEASE=R/'docs/qa/checkpoints/2026-10-30/arthur-quick-private-allocation/root-review-and-reservations.json'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def put(p,s):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(s,newline='\n')
def translate(s):
    substitutions={str(P):str(O),P.as_posix():O.as_posix(),str(R):str(T),R.as_posix():T.as_posix(),'build/character-host-union-v5/src/':'','build/character-host-union-v5/':O.as_posix()+'/'}
    return re.sub('|'.join(re.escape(x)for x in sorted(substitutions,key=len,reverse=True)),lambda m:substitutions[m[0]],s)

def prepare():
    assert sha(LEASE)=='0d12cb77cb79feb9648803d6c057293ffe5686a5a94c41f9813b057b1cdac2ae'
    assert sha(P/'candidate.nes')=='1a71b8b5a5752aeec7440c4dc2de91a136d6285c98922c99b52f39f4047f2b25'
    O.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(P/'frozen-1a71b8b5.zip')as z:
        for name in z.namelist():
            if name.endswith('/'):continue
            prefix='build/character-host-union-v5/'
            dest=O/name[len(prefix):]if name.startswith(prefix)else T/name
            assert dest.resolve().is_relative_to(O.resolve())
            raw=z.read(name);dest.parent.mkdir(parents=True,exist_ok=True)
            if dest.suffix in ['.s','.inc','.cfg','.py']:
                try:raw=translate(raw.decode()).encode()
                except UnicodeDecodeError:pass
            dest.write_bytes(raw)
    commands=json.loads((P/'build-proof.json').read_text())['commands']
    # Tool binaries remain the workspace's tools; all source/assets are private
    # frozen copies. Exact original command order and options are retained.
    mapped=[]
    for cmd in commands:
        row=[str(v)if i==0 else translate(str(v))for i,v in enumerate(cmd)];mapped.append(row)
    put(O/'parent-commands.json',json.dumps(mapped,indent=2)+'\n')
    put(O/'lease-copy.json',LEASE.read_text())

def build_parent():
    commands=json.loads((O/'parent-commands.json').read_text());logs=[]
    # The parent archive omitted its debug-only generated C translation unit.
    # Reassemble that genuine source rather than importing an opaque object.
    ccsrc=R/'build/kamikaze-mario-host-v4/c-full.s';ccdest=T/'build/kamikaze-mario-host-v4/c-full.s'
    put(ccdest,translate(ccsrc.read_text()))
    cccmd=[str(R/'tools/Windows/cc65/bin/ca65.exe'),'--cpu','6502x','-t','nes','-g','-o',str(ccdest.with_suffix('.o')),str(ccdest)]
    commands=[cccmd]+(commands[-1:]if '--link-only'in sys.argv else commands)
    for cmd in commands:
        p=subprocess.run(cmd,cwd=T,capture_output=True,text=True)
        logs.append(dict(command=cmd,rc=p.returncode,stdout=p.stdout,stderr=p.stderr))
        put(O/'build-log.json',json.dumps(logs,indent=2)+'\n')
        if p.returncode:raise AssertionError(p.stderr[:12000])
    # The project's source-level DMC mirror finalizer is required by its parent
    # build. This is its existing owner, not a manual patch of Quick code.
    sys.path.insert(0,str(R/'tools'));from prepare_cv3_dmc_mirror import prepare as mirror
    mirror(R,O/'candidate.nes')
    actual=sha(O/'candidate.nes');expected=sha(P/'candidate.nes')
    assert actual==expected,('private source parent reproduction',actual,expected)
    put(O/'parent-reproduction.json',json.dumps(dict(status='EXACT_PARENT_SOURCE_REPRODUCTION_PASS',sha256=actual,archive_sha256=sha(P/'frozen-1a71b8b5.zip'),lease_sha256=sha(LEASE)),indent=2)+'\n')
    print('exact parent source',actual)

def quick_sources():
    Q=O/'quick';Q.mkdir(exist_ok=True);base=prep.O;bundle=load(P/'candidate.nes')
    for n in ['core','render']:
        s=(base/(n+'.s')).read_text().replace('.include "host-imports.inc"','.include "qh_imports.inc"').replace('.include "placement.inc"','')
        # Actual parent labels and bank expressions are linker imports, rather
        # than carrying fixed numeric callbacks forward from an older DBG.
        syms=json.loads((base/'parent-symbols.json').read_text())['symbols']
        for name,row in sorted(syms.items(),key=lambda x:-len(x[0])):
            s=s.replace('Host_'+name+'Bank',f'.lobyte(.bank({row["source_symbol"]})|$80)')
            s=s.replace('Host_'+name,row['source_symbol'])
        s=s.replace('Host_X5SetPhysicalChrBank','.lobyte(.bank(X5SetPhysicalChr)|$80)')
        if n=='core':
            # Publish the genuine source head-clamp event to the host's native
            # item/block effect pass. This helper restores A/P and never edits
            # any source field or replaces the original bonk instructions.
            s=s.replace('CX_3C_8BE6:\n','CX_3C_8BE6:\njsr QhBonkFlag\n',1)
            s='.import QhBonkFlag\n'+s
            # Animate is an internal phase of Tick. The host-facing dispatcher
            # borrows once; do not pay a second public wrapper on that phase.
            # All source animation instructions and poses remain retained.
            s=s.replace('QuickManInit,QuickManAnimate,QuickManGetFrame','QuickManInit,QuickManGetFrame')
            s=s.replace('jsr QuickManAnimate\n','jsr QuickManAnimate_Core\n')
            s=re.sub(r'QuickManAnimate:\n[\s\S]*?QuickManAnimate_Foreign:\npla\nplp\nrts\n','',s)
            # Actual public ownership/borrow now belongs to HuCommon/QhDispatch.
            # These trusted internal phases cannot be reached by a foreign
            # roster path. Removing duplicate nested wrappers retains every
            # original source instruction and one outer borrowed-pair receipt.
            for public in ['QuickManInit','QuickManTick','QuickManGetFrame']:
                s=re.sub(public+r':\n[\s\S]*?'+public+r'_Foreign:\npla\nplp\nrts\n','',s)
            # The genuine public gate is now HuQuickActive in the parent. No
            # trusted internal leaf calls the retired duplicate owner test.
            assert len(re.findall(r'\bArenaIsActive\b',s))==2
            s=re.sub(r'ArenaIsActive:\n[\s\S]*?ArenaForeign: clc\nrts\n','',s)
            s=s.replace(',ArenaIsActive,',',')
            a=s.index('QuickManInit_Core:');z=s.index('QuickManTick_Core:');body=s[a:z].replace('QuickManInit_Core:','QhNativeInit:',1)
            gate='''QuickManInit_Core:
sta ArenaGateA
php
lda #<QhNativeInit
sta ArenaGatePtr
lda #>QhNativeInit
sta ArenaGatePtr+1
lda #.lobyte(.bank(QhNativeInit)|$80)
jmp ArenaCallC
'''
            s=s[:a]+gate+s[z:]+ '\n.segment "QH_INIT"\n'+body
            for public in ['QuickManInit','QuickManTick','QuickManGetFrame']:s=s.replace(public+'_Core:',public+':')
            # Keep the live world callback in the held A phase. This removes
            # two C transactions per native tile probe, without a cache or a
            # replacement material/physics implementation.
            a=s.index('.segment "ARENA_HOST_WORLD"\n');world=s[a:].split('\n.export',1)[0]
            world=world.replace('.segment "ARENA_HOST_WORLD"\nQuickManHostWorldCore:','QuickManWorldProbe:',1)
            # The QH_INIT appended leaf follows world in this source revision.
            world=world.split('.segment "QH_INIT"',1)[0]
            wend=s.index('.segment "QH_INIT"',a)
            s=s[:a]+s[wend:]
            s=re.sub(r'QuickManWorldProbe:\n[\s\S]*?(?=QuickManSound:)',lambda _:world,s,count=1)
            s=re.sub(r'\.segment "ARENA_ZP": zeropage\nQuickManBorrowedPtr: \.res 2','QuickManBorrowedPtr=R0',s)
            own=set(re.findall(r'(?m)^(QmField_[0-9A-F]{4}|QuickManWork_[0-9A-F]{2}):',s))
            s+='\n'+','.join([]) # Keep the export list source-authored/generated.
            s+='\n.export '+','.join(sorted(own))+'\n.export FixtureStatus\n'
            s+='''
.import ArenaRenderCore
.export QuickManRenderFrames
.segment "QH_FRAMES"
; Render-phase cache only: these direct-work scalars are not persistent state.
; All native frame/zero-deactivation instructions still run in their C82 owner.
QuickManRenderFrames:
sta QuickManWork_01
ldx #4
QhFrameLoop:
jsr ArenaGetFrameBody
sta QuickManWork_0A,x
dex
cpx #1
bne QhFrameLoop
ldx #0
jsr ArenaGetFrameBody
sta QuickManWork_0A
lda QuickManWork_01
sta ArenaGateA
php
lda #<ArenaRenderCore
sta ArenaGatePtr
lda #>ArenaRenderCore
sta ArenaGatePtr+1
lda #.lobyte(.bank(ArenaRenderCore)|$80)
jmp ArenaCallC
'''
            # Actual source SFX entry is now a host feedback adaptation. The
            # source invocation/held-shot timing stays owned by the CX kernel.
            s=s.replace('QuickManSound:\nQuickManScrollStrip:\nQuickManProjectileContact:\nrts','QuickManSound:\nphp\npha\nlda #$20\nsta Square1SoundQueue\npla\nplp\nrts\nQuickManScrollStrip:\nQuickManProjectileContact:\nrts')
        else:
            s=s.replace(',ArenaIsActive,',',')
            s+="\n.import QuickManRenderFrames,QuickManWork_0A,QuickManWork_0B,QuickManWork_0C,QuickManWork_0D,QuickManWork_0E\n.export ArenaRenderCore\n"
            s=re.sub(r'QuickManHostRender:\n[\s\S]*?RenderForeign: pla\nplp\nrts\n','',s)
            s=s.replace('GateRender:','QuickManHostRender:')
            # Enter the real C82 frame owner once for the complete four-actor
            # render, then map C98 once. Keep the public source GetFrame API.
            s=s.replace('lda #<ArenaRenderCore','lda #<QuickManRenderFrames',1).replace('lda #>ArenaRenderCore','lda #>QuickManRenderFrames',1)
            s=s.replace('lda #$E2\njmp ArenaCallC','lda #.lobyte(.bank(QuickManRenderFrames)|$80)\njmp ArenaCallC',1)
            # The frozen renderer used an explicit bank literal. Resolve it
            # from the new genuine imported frame-owner label in every case.
            s=re.sub(r'(lda #<QuickManRenderFrames\nsta ArenaGatePtr\nlda #>QuickManRenderFrames\nsta ArenaGatePtr\+1\n)lda #[^\n]+',r'\g<1>lda #.lobyte(.bank(QuickManRenderFrames)|$80)',s,count=1)
            s=s.replace('jsr QuickManGetFrame\n','lda QuickManWork_0A,x\n',1)
            art=json.loads((R/'build/quickman-host-plan-v1/art/window0-proof.json').read_text());raw=bytearray();old=bytearray();offsets=[];proof=[]
            for frame in art['frames']:
                offsets.append(len(raw));raw.append(len(frame['cells']));old.append(len(frame['cells']))
                for cell in frame['cells']:
                    x,y,pair,attr=(cell[k]for k in ['x','y','pair','attr'])
                    assert -32<=x<32 and -128<=y<128 and pair<32 and attr&3<2
                    packed=[y&255,pair|((attr&1)<<5)|((attr&32)<<1),(x+32)|(attr&192)];raw.extend(packed);old.extend([y&255,pair*2,attr,x&255])
                    decoded=dict(x=(packed[2]&63)-32,y=packed[0]-(256 if packed[0]&128 else 0),pair=packed[1]&31,attr=(packed[2]&192)|((packed[1]>>5)&1)|((packed[1]>>1)&32))
                    assert decoded==cell,(frame['frame'],cell,decoded)
                proof.append(dict(frame=frame['frame'],cells=len(frame['cells']),offset=offsets[-1],all_original_geometry_palette_role_priority_fields_equal=True))
            original=R/'build/quickman-host-plan-v1/art/metasprites.bin';assert bytes(old)==original.read_bytes()
            (Q/'metasprites3.bin').write_bytes(raw)
            s=s.replace(original.as_posix(),(Q/'metasprites3.bin').as_posix())
            for lab,fmt in [('QuickManHostPoseLo','<'),('QuickManHostPoseHi','>')]:s=re.sub(lab+r': \.byte [^\n]+',lab+': .byte '+','.join(fmt+'(QmMeta+'+str(x)+')'for x in offsets),s)
            a=s.index('RenderCell:');z=s.index('dec QuickManWork_02',a)
            s=s[:a]+'''RenderCell:
lda (QuickManBorrowedPtr),y
clc
adc QuickManWork_05
sta $0200,x
iny
lda (QuickManBorrowedPtr),y
sta QuickManWork_07
and #31
asl
sta $0201,x
stx QuickManWork_01
lda QuickManWork_07
and #$60
asl
asl
rol
rol
tax
lda QhRoleAttr,x
sta QuickManWork_07
ldx QuickManWork_01
iny
lda (QuickManBorrowedPtr),y
sta QuickManWork_03
and #$c0
ora QuickManWork_07
sta QuickManWork_07
lda QuickManWork_06
bne RenderAttr
lda QuickManWork_07
eor #$40
sta QuickManWork_07
RenderAttr:
lda QuickManWork_07
sta $0202,x
lda QuickManWork_03
and #63
sec
sbc #32
sta QuickManWork_03
lda QuickManWork_06
bne RenderRight
lda QuickManWork_03
eor #$ff
sec
sbc #7
jmp RenderX
RenderRight: lda QuickManWork_03
RenderX: clc
adc QuickManWork_04
sta $0203,x
iny
inx
inx
inx
inx
'''+s[z:]
            s+='\nQhRoleAttr:.byte 0,1,$20,$21\n'
            # A cold portrait consumes only authenticated frame4 and host
            # display anchors. It does not initialize/read the source actors,
            # HP, lifecycle marker, or hidden gameplay timers.
            s=s.replace('ldy #0\nlda (QuickManBorrowedPtr),y\n','RenderHeader:\nldy #0\nlda (QuickManBorrowedPtr),y\n',1)
            s+='''
.export QhPortrait
QhPortrait:
lda CurrentOAMOffset
sta QuickManWork_01
lda #4
sta QuickManWork_00
jsr QuickManHostPoseLookup
lda #251
jsr ArenaPublish
lda Player_X_Position
clc
adc #8
sta QuickManWork_04
lda Player_Y_Position
clc
adc #21
sta QuickManWork_05
lda #$40
sta QuickManWork_06
jmp RenderHeader
'''
            s=s.replace('sta QuickManWork_02\njeq RenderNext\niny','sta QuickManWork_02\njeq RenderNext\nasl\nasl\nclc\nadc QuickManWork_01\njcs RenderNext\niny')
            put(Q/'art3-proof.json',json.dumps(dict(status='ALL34_SOURCE_FRAMES_LOSSLESS_THREE_BYTE_METADATA',original_sha256=sha(original),original_bytes=len(old),new_bytes=len(raw),new_sha256=hashlib.sha256(raw).hexdigest(),format='Ysigned8;pair5+role1+BGpriority1;Xbiased6+Hflip+Vflip',frames=proof),indent=2)+'\n')
        # Physical source fragments may be repacked inside the granted arena.
        # Every imported bank operand is derived from its genuine linked label.
        s=re.sub(r'(lda #<([^\n]+)\nsta ArenaGatePtr\nlda #>[^\n]+\nsta ArenaGatePtr\+1\n)lda #\$[0-9A-F]{2}(\njmp ArenaCallC)',lambda m:m[1]+'lda #.lobyte(.bank('+m[2]+')|$80)'+m[3],s)
        if n=='core':
            # Explicit C84 hot cohort: relocate only the genuine26B high/low
            # dispatch tables into its other owned gap, preserving all entries.
            rows=re.findall(r'(?m)^DX_3C_87[89][0-9A-F]_CX_3C_84EE: \.byte [<>]G_[^\n]+\n',s)
            assert len(rows)==26,len(rows)
            for row in rows:s=s.replace(row,'',1)
            s+='\n.segment "R1_TABLE"\n'+''.join(rows)
            near=[]
            calls=[('G_CX_3C_84EE_CX_3C_8609','CX_3C_8609',84)]
            # All CX source executes under held A70. The pure29B facing leaf
            # has no table/indirect/callee dependency, so its A-tail projection
            # is a genuine near target for every C-side source caller.
            calls += [(g,'CX_3C_87FD',70)for g in re.findall(r'(?m)^(G_\w+_CX_3C_87FD):\n',s)]
            # The authentic rectangle-prefix leaf is pure RAM and tail-calls
            # the held-A live-world reader. Keeping it in A70 removes a C
            # transaction pair from every source head/side/foot tile query.
            calls += [(g,'CX_3E_CB9F',70)for g in re.findall(r'(?m)^(G_\w+_CX_3E_CB9F):\n',s)]
            assert len(calls)==11,len(calls)
            for gate,target,bank in calls:
                pattern=r'(?m)^'+gate+r':\nsta ArenaGateA\nphp\nlda #<'+target+r'\nsta ArenaGatePtr\nlda #>'+target+r'\nsta ArenaGatePtr\+1\nlda #[^\n]+\njmp ArenaCallC\n'
                s,count=re.subn(pattern,'',s);assert count==1,(gate,count)
                refs=len(re.findall(r'\b'+gate+r'\b',s));assert refs>0
                s=re.sub(r'\b'+gate+r'\b',target,s)
                assert not re.search(r'\b'+gate+r'\b',s)
                near.append(dict(removed_gate=gate,retained_source_target=target,physical_bank_required=bank,window='A'if bank==70 else'C',all_source_references_replaced=refs,removed_mapper_stub_bytes=19))
            put(Q/'near-source-proof.json',json.dumps(dict(status='SOURCE_NEAR_TRANSFERS_REQUIRE_LINKED_COHORT_PROOF',original_dispatch_table_entries=26,all_original_dispatch_entries_retained=True,changes=near),indent=2)+'\n')
        put(Q/(n+'.s'),s)
    runtime=(Path(__file__).with_name('quickman_host_runtime_v3.s')).read_text();put(Q/'runtime.s',runtime)
    combined='\n'.join((Q/(n+'.s')).read_text()for n in ['core','render','runtime']);tokens=set(re.findall(r'\b[A-Za-z_][A-Za-z_0-9]*\b',re.sub(r';[^\n]*','',combined)))
    tokens.update({'FmAlts','FmQueueName','GmIceBody','RlMovementDispatch'})  # Actual parent-only selector/name/body routes in union.s.
    parent={n:row for n,row in bundle['syms'].items()if n in tokens and row.get('scope')=='1'and not n.startswith(('Quick','Qm','Qh','Arena'))}
    # This genuine scoped label already has a root-owned linker export in
    # gimmick_link_exports.inc; the flat DBG loader retains its inner record.
    external={'BeginEnemyLoop','GmPublishEmpty','HuColors','HuFullPower'}
    for n in external:
        if n in tokens:parent[n]=bundle['syms'][n]
    # These source constants are already assembler values in the parent; use
    # the genuine declarations from common.inc where required.
    imports=[];export=[]
    for n,row in sorted(parent.items()):
        kind='zp 'if row.get('addrsize')=='zeropage'else' '
        imports.append('.import'+kind+n)
        if n not in external:export.append('.export'+kind+n)
    put(Q/'qh_imports.inc','\n'.join(imports)+'\n')
    core=(Q/'core.s').read_text();own=set(re.findall(r'(?m)^(QmField_[0-9A-F]{4}|QuickManWork_[0-9A-F]{2}):',core))
    own|={'ArenaGateA','ArenaGateP','ArenaGateBank','ArenaGatePtr','ArenaCallC','QuickManInit','QuickManTick','QuickManHostRender','FixtureStatus'}
    put(Q/'qh_fields.inc','.import '+','.join(sorted(own))+'\n')
    put(O/'quick-parent-exports.inc','\n'.join(export)+'\n.export GmFreshGate\n')
    ca=R/'tools/Windows/cc65/bin/ca65.exe';od=ca.with_name('od65.exe');sizes={}
    for n in ['core','render','runtime']:
        cmd=[str(ca),'-g','-I',str(Q),'-I',str(T),str(Q/(n+'.s')),'-o',str(Q/(n+'.o'))]
        cp=subprocess.run(cmd,capture_output=True,text=True);assert not cp.returncode,cp.stderr[:12000]
        pp=subprocess.run([str(od),'--dump-segments',str(Q/(n+'.o'))],capture_output=True,text=True);assert not pp.returncode,pp.stderr
        for k,v in re.findall(r'Name:\s+"([^"]+)"[\s\S]*?Size:\s+(\d+)',pp.stdout):sizes[k]=sizes.get(k,0)+int(v)
    put(Q/'segment-sizes.json',json.dumps(sizes,indent=2)+'\n');print({k:v for k,v in sizes.items()if k=='QM_COORD'or k.startswith('QH_')})

def patch_host():
    # Always derive the changed private files from their bound parent source,
    # never from a prior mutation of this working candidate.
    with zipfile.ZipFile(P/'frozen-1a71b8b5.zip')as z:
        def parent(n):return translate(z.read('build/character-host-union-v5/'+n).decode())
        union=parent('union.s');nr=parent('src/new_roster_dispatch.s');player=parent('src/player.s');cs=parent('src/character_select.s');fm=parent('src/full_roster_menu.s');entry=parent('entrypoint.s')
    routes=re.findall(r'\.proc (Hu\w+)\n sta SafecallA_SMC\+1\n php\n tya\n pha\n ldy #(\d+)',union)
    assert len(routes)==36,routes
    mapping={
        'HuMovement':'QhMovement','HuGraphics':'QhGraphics','HuDraw':'QhDraw','HuPortrait':'GmPublishEmpty',
        'HuWeapons':'QhWeapons','HuInjury':'QhInjury','HuInjuryStatus':'QhStatus','HuDeathStart':'QhDeathStart',
        'HuDeath':'QhDeath','HuVisible':'QhVisible','HuHead':'QhHead','HuBody':'GmIceBody','HuAdder':'QhAdder',
        'HuBox':'QhBoxProfile','HuSide':'QhSide','HuFresh':'QhConstruct','HuFullBox':'QhBox','HuMenuPortrait':'QhPortrait',
        'HuMenuName':'FmQueueName','HuReset':'QhConstruct','HuPrepare':'QhPrepare','HuRise':'QhDecline','HuPrivate':'QhDecline',
        'HuMature':'GmMatureOwn','HuPickup':'QhPickup','HuFullPower':'QhFullPower','HuColors':'QhColors',
        'HuBounceOnly':'QhDecline','HuHeadWithinOnly':'QhDecline','HuUi':'QhUi','HuStatus':'QhStatusName',
        'HuBounce':'QhDecline','HuWorldPalette':'HuNativeWorldPalette','HuPowerup':'QhNoop','HuWeaponTail':'QhNoop','HuVine':'QhDecline'}
    targets=[mapping[n]for n,i in sorted(routes,key=lambda r:int(r[1]))]
    imports=(set(targets)-{'HuNativeWorldPalette'})|{'QhDispatch','QhSync','ArenaGatePtr','ArenaGateBank','FmAlts','GmFreshGate','RlMovementDispatch','MaaQueueName'}
    union='.import '+','.join(sorted(imports))+'\n'+union
    test='''HuQuickActive:
 lda SelectedCharacter
 cmp #9
 bne HuQuickNo
 lda FmAlts
 and #32
 beq HuQuickNo
 sec
 rts
HuQuickNo:clc
 rts
.res $20-(*-HuStart),$ff
'''
    union=union.replace('.res $20,$ff\n',test,1)
    union=union.replace('.proc HuCommon\n lda SelectedCharacter\n','''.proc HuCommon
 jsr HuQuickActive
 bcc Native
 ; Existing A-window callbacks retain their real native ABI. Only C-window
 ; Quick leaves need the held-A dispatcher and selected-owner borrowed pair.
 lda HuQuickHi,y
 cmp #$c0
 bcs QuickLeaf
 sta FarcallJmpTarget_SMC+2
 lda HuQuickLo,y
 sta FarcallJmpTarget_SMC+1
 lda HuQuickBank,y
 sta NextBank_SMC+1
 jmp RestoreCaller
QuickLeaf:
 lda HuQuickLo,y
 sta ArenaGatePtr
 lda HuQuickHi,y
 sta ArenaGatePtr+1
 lda HuQuickBank,y
 sta ArenaGateBank
 lda #<QhDispatch
 sta FarcallJmpTarget_SMC+1
 lda #>QhDispatch
 sta FarcallJmpTarget_SMC+2
 lda #.lobyte(.bank(QhDispatch)|$80)
 sta NextBank_SMC+1
 jmp RestoreCaller
Native:
 lda SelectedCharacter
''',1)
    # Raw9 now reaches the rare router. Preserve the original legacy leaves,
    # rather than sending its FullBox/MenuName/Bounce back into their newly
    # intercepted GmOnly gates. Movement retains the genuine PlayerCtrl target.
    bass=re.search(r'HuLo:\n \.byte ([^\n]+)',union).group(1).split(',')[:36]
    bass=[t[1:]for t in bass]
    for i,n in {0:'RlMovementDispatch',16:'MaaBox',18:'MaaQueueName',31:'X5StompDispatch'}.items():bass[i]=n
    bass_tables=''
    for label,expr in [('HuBassLo','<{t}'),('HuBassHi','>{t}'),('HuBassBank','.lobyte(.bank({t})|$80)')]:bass_tables+=label+':\n.byte '+','.join(expr.format(t=t)for t in bass)+'\n'
    union=union.replace('HuLo:\n',bass_tables+'HuLo:\n',1)
    union=union.replace('Native:\n lda SelectedCharacter\n cmp #28','''Native:
 lda SelectedCharacter
 cmp #9
 bne OtherOwner
 lda HuBassLo,y
 sta FarcallJmpTarget_SMC+1
 lda HuBassHi,y
 sta FarcallJmpTarget_SMC+2
 lda HuBassBank,y
 sta NextBank_SMC+1
 jmp RestoreCaller
OtherOwner:
 lda SelectedCharacter
 cmp #28''',1)
    union=union.replace(' sta NextBank_SMC+1\n pla\n tay\n plp\n jmp FarCallCommon+3',' sta NextBank_SMC+1\nRestoreCaller:\n pla\n tay\n plp\n jmp FarCallCommon+3',1)
    pos=union.index('HuLo:')
    tables=''
    for label,expr in [('HuQuickLo','<{t}'),('HuQuickHi','>{t}'),('HuQuickBank','.lobyte(.bank({t})|$80)')]:tables+=label+':\n.byte '+','.join(expr.format(t=t)for t in targets)+'\n'
    union=union[:pos]+tables+union[pos:]
    union=union.replace('.proc HuAfterTerrainGate\n php\n pha\n','.proc HuAfterTerrainGate\n php\n pha\n jsr HuQuickActive\n bcc Original\n pla\n plp\n farcall QhSync,jmp\nOriginal:\n',1)
    fresh='''.export HuQuickFresh
.proc HuQuickFresh
 php
 pha
 jsr HuQuickActive
 bcc Legacy
 pla
 plp
 jmp HuFresh
Legacy:pla
 plp
 farcall GmFreshGate,jmp
.endproc
'''
    union=union.replace('HuEnd:\n',fresh+'HuEnd:\n',1)
    # Route raw9 through the exact existing rare caller-key protocol. Other
    # owners keep the same local table rows and genuine fixed-size capsules.
    a=nr.index('::GmNrIndex:');z=nr.index('.endscope',a)
    nr=nr[:a]+'''::GmNrIndex:
 lda SelectedCharacter
 ldy #0
 cmp #9
 beq Rare
 cmp #24
 beq Rare
 cmp #28
 beq Rare
 cmp #20
 beq One
 cmp #21
 beq Two
 cmp #23
 beq Three
 cmp #26
 beq Four
 rts
Four:iny
Three:iny
Two:iny
One:iny
 rts
Rare:
 txa
 tay
 tsx
 lda $0101,x
 adc $0102,x
 jmp GmNrRare
'''+nr[z:]
    nr=nr.replace('97,GmExtraNrDraw,54,0','97,GmExtraNrDraw,51,0')
    nr=nr.replace('::GmOnlyCommon:\n lda SelectedCharacter\n','::GmOnlyCommon:\n lda SelectedCharacter\n cmp #9\n beq Rare\n',1)
    nr=nr.replace('97,GmExtraNrPortrait,47,0','97,GmExtraNrPortrait,51,0')
    nr=nr.replace(' jmp GmFreshGate\n .res 15,$ea',' farcall HuQuickFresh,jmp',1)
    nr='.import HuQuickFresh\n'+nr
    player=player.replace('farcall RlMovementDispatch','farcall HuMovement')
    # Preserve the selected alternate on confirm in exactly the old3B span.
    cs=cs.replace('FmStartReady:\n  lda #0\n  sta FmAlts','FmStartReady:\n  lda #0\n  .res 3,$ea',1)
    # Only a private cold-test admission. Shared frontend readiness is untouched.
    fm=fm.replace(' lda #31\n sec\n rts\nNotQuickMan:',' lda #31\n clc\n rts\nNotQuickMan:',1)
    entry+='\n.include "quick-parent-exports.inc"\n'
    for n,s in [('union.s',union),('src/new_roster_dispatch.s',nr),('src/player.s',player),('src/character_select.s',cs),('src/full_roster_menu.s',fm),('entrypoint.s',entry)]:put(O/n,s)
    put(O/'quick-route-table.json',json.dumps(dict(status='WORKING_PRIVATE_SOURCE_ROUTES_ACCEPTANCE_IN_PROGRESS',targets=[dict(index=int(i),hook=n,target=mapping[n])for n,i in routes],private_cold_test_admission=True,remaining_unimplemented=[n for n in mapping if mapping[n]=='QhNoop']),indent=2)+'\n')

def quick_config():
    Q=O/'quick';sizes=json.loads((Q/'segment-sizes.json').read_text());lease=json.loads(LEASE.read_text());base=json.loads((prep.O/'joint-request.json').read_text());places=[]
    gaps=[dict(bank=r['bank'],start=r['start'],end=r['end'])for r in lease['Quick_Man']['PRG']]
    # Explicitly relinquished to the root for the Union Bill near adapter.
    # Keep it excluded on every rebuild, rather than relying on incidental FF
    # fill after a particular bin assignment. Root grants the next owner.
    release=[dict(bank=93,start=0x0fa7,end=0x0fe7)]
    for r in release:
        g=next(g for g in gaps if g['bank']==r['bank'] and g['start']<=r['start'] and r['end']<=g['end'])
        gaps.remove(g)
        if g['start']<r['start']:gaps.append(dict(bank=g['bank'],start=g['start'],end=r['start']))
        if r['end']<g['end']:gaps.append(dict(bank=g['bank'],start=r['end'],end=g['end']))
    def place(n,window='C',bank=None,at=None):
        size=sizes[n];options=[g for g in gaps if g['end']-g['start']>=size and(bank is None or bank==g['bank'])and(at is None or g['start']<=at and at+size<=g['end'])]
        assert options,('Quick granted fragmentation',n,size)
        g=min(options,key=lambda x:(x['end']-x['start']-size,x['bank'],x['start']));gaps.remove(g);start=g['start']if at is None else at
        if g['start']<start:gaps.append(dict(bank=g['bank'],start=g['start'],end=start))
        if start+size<g['end']:gaps.append(dict(bank=g['bank'],start=start+size,end=g['end']))
        row=dict(segment=n,bank=g['bank'],offset=start,bytes=size,window=window,CPU_start=(0xa000 if window=='A'else 0xc000)+start);places.append(row);return row
    fixed={'QM_COORD','ARENA_ART_META','ARENA_ART_LOOKUP','ARENA_ART_PUBLISH','ARENA_RENDER','R25','R1','R2','R3','R4','R10','R8','R1_TABLE','R6','R12','R24','QH_FRAMES'}
    for row in base['Quick_placements']:
        n=row['segment']
        if n not in fixed or n not in sizes or not sizes[n]or n in ['R1','R2','R3','R4','R10','R8','R1_TABLE','R6','R12','R24']:continue
        place(n,row['window'],row['bank'],row['offset'])
    # Native source dispatch and wall/jump phase share actual C84. The two
    # leased gaps are separate physical spans but one hardware C-bank view.
    cursor=0x1529
    for n in ['R1','R3']:place(n,'C',84,cursor);cursor+=sizes[n]
    cursor=0x1e00
    for n in ['R2','R4','R10','R8','R1_TABLE']:place(n,'C',84,cursor);cursor+=sizes[n]
    cursor=0x1020
    for n in ['R6']:place(n,'C',87,cursor);cursor+=sizes[n]
    anim=next(p for p in places if p['segment']=='R25')
    place('QH_FRAMES','C',anim['bank'],anim['offset']+anim['bytes'])
    # The hot native facing and rectangle-prefix leaves use the held A-tail.
    # Cold lifecycle retains its genuine19B A gate and a movable C worker.
    coord=next(p for p in places if p['segment']=='QM_COORD')
    place('R12','A',coord['bank'],coord['offset']+coord['bytes'])
    place('R24','A',coord['bank'],coord['offset']+coord['bytes']+sizes['R12'])
    # This is a genuinely fragmented lease: greedy best-fit can strand large
    # routines despite enough total bytes. Solve the small routine/bin request
    # and keep constructor/reset co-resident for their actual near transfer.
    names=[n for n in sizes if(n.startswith('QH_')and n not in fixed|{'QH_PERSIST'}or re.fullmatch(r'R\d+',n)and n not in fixed)]
    groups=[[n]for n in names]
    groups.sort(key=lambda g:-sum(sizes[n]for n in g));bins=[dict(g)for g in gaps];caps=[g['end']-g['start']for g in bins]
    # Exact small binary assignment, using the installed HiGHS MILP solver.
    # This bounds search time/memory instead of enumerating millions of native
    # fragment permutations. The result is still checked by the real linker.
    import numpy as np
    import scipy
    from scipy.optimize import milp,Bounds,LinearConstraint
    from scipy.sparse import lil_matrix
    choices=[(i,j)for i,g in enumerate(groups)for j,cap in enumerate(caps)if sum(sizes[n]for n in g)<=cap]
    a=lil_matrix((len(groups)+len(bins),len(choices)),dtype=float)
    for col,(i,j)in enumerate(choices):a[i,col]=1;a[len(groups)+j,col]=sum(sizes[n]for n in groups[i])
    low=np.r_[np.ones(len(groups)),np.zeros(len(bins))];high=np.r_[np.ones(len(groups)),np.array(caps)]
    cost=np.array([(caps[j]-sum(sizes[n]for n in groups[i]))**2 for i,j in choices],dtype=float)
    solution=milp(cost,integrality=np.ones(len(choices)),bounds=Bounds(0,1),constraints=LinearConstraint(a.tocsc(),low,high),options={'time_limit':45,'presolve':True,'mip_rel_gap':0.5})
    assert solution.x is not None,('fragment fit failure',solution.message)
    solved=[choices[i]for i,x in enumerate(solution.x)if x>0.5]
    assert len(solved)==len(groups)
    put(O/'quick-fit.json',json.dumps(dict(solver='scipy.optimize.milp/HiGHS',scipy=scipy.__version__,status=int(solution.status),message=solution.message,assignments=[dict(segments=groups[i],bin=bins[j])for i,j in solved]),indent=2)+'\n')
    cursor=[g['start']for g in bins]
    for i,j in solved:
        for name in groups[i]:place(name,'C',bins[j]['bank'],cursor[j]);cursor[j]+=sizes[name]
    # Original physical memory/file sequence is preserved. Every split parent
    # segment remains at its real parent offset, with its original runtime view.
    cfg=(O/'union.cfg').read_text();memory,segments=cfg.split('SEGMENTS {',1);bundle=load(P/'candidate.nes');patterns=list(re.finditer(r'([A-Za-z_]\w*)\s*:\s*([^;]+);',memory));position=0;rewrites=[];loadmap={};seen=set()
    def number(expr):
        s=re.sub(r'\$([0-9a-fA-F]+)',lambda m:str(int(m[1],16)),expr.strip());assert re.fullmatch(r'[0-9+*/() -]+',s),expr
        return int(eval(s,{'__builtins__':{}},{}))
    for m in patterns:
        name,props=m.groups();attrs=dict(re.findall(r'(\w+)\s*=\s*([^,;]+)',props));size=number(attrs.get('size','$0'));start=number(attrs.get('start','$0'))
        if attrs.get('file','').strip()!='%O':continue
        file_start=position;position+=size
        if not(16<=file_start<16+128*8192):continue
        owned=[(i,p)for i,p in enumerate(places)if file_start<=16+p['bank']*8192+p['offset']and 16+p['bank']*8192+p['offset']+p['bytes']<=file_start+size]
        if not owned:continue
        owned.sort(key=lambda x:16+x[1]['bank']*8192+x[1]['offset']);ranges=[];cursor=file_start;part=0
        def native(end):
            nonlocal cursor,part
            if end==cursor:return
            nm=name if part==0 else name+'_QhKeep'+str(part);part+=1
            view=start+(cursor-file_start);newprops=re.sub(r'start\s*=\s*[^,;]+',f'start=${view:x}',props);newprops=re.sub(r'size\s*=\s*[^,;]+',f'size=${end-cursor:x}',newprops)
            ranges.append((cursor,end,nm,view));output.append(nm+':'+newprops+';');cursor=end
        output=[]
        for i,p in owned:
            at=16+p['bank']*8192+p['offset'];native(at);nm='QH_PRG_'+str(i);output.append(f'{nm}:start=${p["CPU_start"]:x},size=${p["bytes"]:x},type=ro,file=%O,fill=yes,fillval=$ff,bank=${p["bank"]:x};');cursor=at+p['bytes'];seen.add(p['segment'])
        native(file_start+size)
        for seg in bundle['segs'].values():
            if'ooffs'not in seg:continue
            begin=int(seg['ooffs'],0);end=begin+int(seg['size'],0)
            if not(file_start<=begin<file_start+size):continue
            if end==begin:continue
            native_range=next((r for r in ranges if r[0]<=begin and end<=r[1]),None)
            assert native_range,('Quick split overlaps actual parent segment',seg['name'],hex(begin),hex(end))
            loadmap[seg['name'].strip('"')]=(name,native_range[2])
        rewrites.append((m.start(),m.end(),'\n'.join(output)))
    assert seen=={p['segment']for p in places},('unplaced physical memory',seen^{p['segment']for p in places})
    for a,z,s in reversed(rewrites):memory=memory[:a]+s+memory[z:]
    # Retain first251physical CHR pages, then link granted Quick pixels natively.
    # ld65 emits MEMORY areas in declaration order, independently of start.
    # Insert this physical payload immediately after the shortened legacy
    # memory; appending it after expanded CHR would put pixels at page1019.
    memory,n=re.subn(r'(CHR:\s*start\s*=\s*\$0000,\s*size\s*=\s*)\$40000([^;]*;)',r'\g<1>$3ec00\g<2>\nQH_CHR_MEM:start=$3ec00,size=$1400,type=ro,file=%O,fill=yes,fillval=$00;',memory);assert n==1
    memory=memory.rsplit('}',1)[0]
    oldcfg=(prep.O/'fragmented.cfg').read_text()
    memory+='\n'.join(s for s in oldcfg.splitlines()if re.match(r'N\d+:',s))+'\nQH_PERSIST_MEM:start=$5f88,size=$8,type=rw,file="";\n}\n'
    for seg,(old,new)in loadmap.items():
        if old==new:continue
        pattern=r'('+re.escape(seg)+r'\s*:\s*load\s*=\s*)'+re.escape(old)+r'\b'
        segments,n=re.subn(pattern,r'\g<1>'+new,segments);assert n==1,('parent segment load definition',seg,old,new,n)
    extra=['ARENA_CHR:load=QH_CHR_MEM,type=ro;','QH_PERSIST:load=QH_PERSIST_MEM,type=bss;']
    extra += [s for s in oldcfg.splitlines()if s.startswith('QM_')and'load=N'in s]
    extra += [f'{p["segment"]}:load=QH_PRG_{i},type=ro;'for i,p in enumerate(places)]
    close=segments.index('}');segments=segments[:close]+'\n'+'\n'.join(extra)+'\n'+segments[close:];put(O/'quick.cfg',memory+'SEGMENTS {'+segments)
    total=sum(p['bytes']for p in places);available=10124-sum(r['end']-r['start']for r in release);put(O/'quick-layout.json',json.dumps(dict(status='PRIVATE_GRANTED_SOURCE_LAYOUT_WORKING',lease_sha256=sha(LEASE),placements=places,payload_bytes=total,original_reserved_bytes=10124,reserved_bytes=available,headroom_bytes=available-total,released_to_root=release,remaining_intervals=gaps,permanent_resident_bytes=0,active_RAM_bytes=557,persistent_RAM_bytes=8,new_ZP_bytes=0,parent_load_reassignments=loadmap),indent=2)+'\n');print('Quick actual source',total,'remaining',available-total)

def build_quick():
    commands=json.loads((O/'parent-commands.json').read_text());link=commands.pop();ca=commands[0][0]
    for n in ['core','render','runtime']:
        commands.append([ca,'-g','-I',str(O/'quick'),'-I',str(T),str(O/'quick'/(n+'.s')),'-o',str(O/'quick'/(n+'.o'))])
        link.append(str(O/'quick'/(n+'.o')))
    link[link.index('-C')+1]=str(O/'quick.cfg');commands.append(link);logs=[]
    if '--link-only'in sys.argv:commands=commands[-1:]
    elif '--main-only'in sys.argv:commands=commands[:1]+commands[-4:]
    for cmd in commands:
        r=subprocess.run(cmd,cwd=T,capture_output=True,text=True);logs.append(dict(command=cmd,rc=r.returncode,stdout=r.stdout,stderr=r.stderr));put(O/'quick-build-log.json',json.dumps(logs,indent=2)+'\n')
        if r.returncode:raise AssertionError(r.stderr[:16000])
    sys.path.insert(0,str(R/'tools'));from prepare_cv3_dmc_mirror import prepare as mirror
    mirror(R,O/'candidate.nes')
    print('private actual host',sha(O/'candidate.nes'))

if __name__=='__main__':
    if '--prepare'in sys.argv:prepare()
    if '--parent'in sys.argv:build_parent()
    if '--quick-sources'in sys.argv:quick_sources()
    if '--patch-host'in sys.argv:patch_host()
    if '--quick-config'in sys.argv:quick_config()
    if '--build-quick'in sys.argv:build_quick()
