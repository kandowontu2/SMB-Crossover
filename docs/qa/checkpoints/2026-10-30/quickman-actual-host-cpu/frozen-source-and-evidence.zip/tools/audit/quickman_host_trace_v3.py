"""Readonly bounded actual-ROM diagnostic trace; no emulator or ROM changes."""
import json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent))
import quickman_host_main_v3 as h

def run(q,age):
    B=q.b;name='GameLoop';pc=h.U.address(B,name);bank=h.U.point(B,name)[0];win=(pc-0x8000)//8192;q.m.page(win,bank)
    if win in [1,2]:q.set('CurrentBank'if win==1 else'CurrentBankC',bank|128)
    c=h.U.C.M.NesMPU(memory=q.m,pc=pc);c.sp=253;c.stPushWord(0x5aff)
    names=['HuMovement','RlMovementDispatch','SpecialMovement','NrMovement','HuCommon','GmNrIndex','QhMovement','QuickManTick','CX_3C_8560','CX_3C_859F','CX_3C_85A9','CX_3C_85AD','QhExport','PlayerBGCollision','QhSync','QhGraphics','QhImport','QhHead','QhProbe','PlayerHeadCollision','CX_3C_8BE6','QhBonkFlag']
    points={h.U.point(B,n):n for n in names if n in B['syms']}
    fields=['SavedJoypadBits','A_B_Buttons','Player_State','Player_Y_Position','Player_Y_Speed','QmField_0023','QmField_0027','QmField_002C','QmField_003B','QmField_003C','QmField_0640','QmField_0660','FixtureStatus','R2','R3','R4','R6','R7']
    rows=[]
    for step in range(100000):
        if c.pc==0x5b00:return rows
        bank=q.m.banks[(c.pc-0x8000)//8192]if c.pc>=0x8000 else -1
        n=points.get((bank,c.pc))
        if n:rows.append(dict(age=age,name=n,A=c.a,X=c.x,Y=c.y,P=c.p,SP=c.sp,fields={f:q.get(f)for f in fields}))
        if q.m[c.pc]==0 or c.sp<40:return rows+[dict(error='BRK/stack',pc=c.pc,bank=bank,SP=c.sp)]
        c.step()
    raise AssertionError('timeout')

def main():
    B=h.U.scoped_load(h.O/'candidate.nes');h.N.B=B;rows=[]
    if '--bass'in sys.argv:
        q=h.U.C.setup(B,9);q.put(RlVariant=0,FmAlts=0)
        rows=run(q,0)
    else:
        q=h.make(B)
        if '--ceiling'in sys.argv:q.m[h.U.address(B,'Block_Buffer_1')+7*16+6]=0xc1
        for age in range(14):
            keys=(0 if '--ceiling'in sys.argv else 1)|(128 if age>=5 else 0)
            h.input_nmi(q,keys)
            rows+=run(q,age)
    p=h.O/('bass-diagnostic-v3.json'if '--bass'in sys.argv else'jump-diagnostic-v3.json')
    p.write_text(json.dumps(dict(ROM_sha256=h.sha(h.O/'candidate.nes'),rows=rows),indent=2)+'\n')
    for r in rows:
        if '--ceiling'not in sys.argv or r.get('name')in ['QhHead','QhProbe','PlayerHeadCollision','CX_3C_8BE6','QhBonkFlag','QhExport','QhSync']:print(r)

if __name__=='__main__':main()
