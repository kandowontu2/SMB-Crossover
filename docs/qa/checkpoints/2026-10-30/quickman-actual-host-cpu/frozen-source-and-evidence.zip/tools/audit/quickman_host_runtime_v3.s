; Private host adaptations around the unmodified CX controller/physics kernel.
; Source anchor: X=center, Y=center; CX floor/support clamps at top-12,
; therefore SMB foot32 == CX foot12 and Ybias20.
.setcpu "6502"
.macpack longbranch
.include "qh_imports.inc"
.include "qh_fields.inc"
.include "inc/charmap.inc"

.macro QhFar Target
 sta SafecallA_SMC+1
 lda #<Target
 sta FarcallJmpTarget_SMC+1
 lda #>Target
 sta FarcallJmpTarget_SMC+2
 lda #.lobyte(.bank(Target)|$80)
 jsr FarCallCommon
.endmacro

.segment "QH_PERSIST"
QhPersistent: .res 8           ; Per player: HP,maxHP,progress,constructor marker.
.export QhPersistent

.segment "QM_COORD"
.export QhDispatch,QhImport,QhExport,QhSync
QhDispatch:
 sta ArenaGateA
 php
 pla
 sta ArenaGateP
 lda R0
 pha
 lda R1
 pha
 jsr QhDispatchGate
 sta ArenaGateA
 php
 pla
 sta ArenaGateP
 pla
 sta R1
 pla
 sta R0
 lda ArenaGateP
 pha
 lda ArenaGateA
 plp
 rts
QhDispatchGate:
 lda ArenaGateP
 pha
 lda ArenaGateBank
 jmp ArenaCallC

; Resync native clamps without reintegrating. Fractions survive unchanged axes.
QhImport:
 lda Player_X_Position
 clc
 adc #8
 php
 cmp QmField_0460
 beq :+
 sta QmField_0460
 lda #0
 sta QmField_0480
:
 plp
 lda Player_PageLoc
 adc #0
 sta QmField_0440
 lda Player_Y_Position
 clc
 adc #20
 php
 cmp QmField_04A0
 beq :+
 sta QmField_04A0
 lda #0
 sta QmField_04C0
:
 plp
 lda Player_Y_HighPos
 adc #$ff
 sta QmField_00F9
 ; Preserve source gravity and ground/air state. A native standing result can
 ; occur on a zero-integer-speed subpixel update; clearing the source here
 ; would prevent its next original downward floor probe and A-edge jump.
 lda ScreenLeft_X_Pos
 sta QmField_001F
 lda ScreenLeft_PageLoc
 sta QmField_0020
 rts
QhSync:
 jsr QhImport
 lda FixtureStatus
 bpl SyncVelocity
 and #$7f
 sta FixtureStatus
 lda #0
 sta Player_Y_Speed
 beq SyncHorizontal
SyncVelocity:
 ; Native terrain/platform code can change vertical velocity after the source
 ; update. Import only an actual change, retaining source fractions otherwise.
 lda #0
 sec
 sbc QmField_0660
 lda #0
 sbc QmField_0640
 cmp Player_Y_Speed
 beq :+
 lda #0
 sec
 sbc Player_Y_Speed
 sta QmField_0640
 lda #0
 sta QmField_0660
:
SyncHorizontal:lda Player_X_Speed
 bne :+
 lda #0
 sta QmField_0600
 sta QmField_0620
:rts

QhExport:
 lda QmField_0460
 sec
 sbc #8
 pha
 sec
 sbc Player_X_Position
 sta Player_X_Scroll
 pla
 sta Player_X_Position
 lda QmField_0460
 cmp #8
 lda QmField_0440
 sbc #0
 sta Player_PageLoc
 lda QmField_04A0
 sec
 sbc #20
 sta Player_Y_Position
 lda QmField_00F9
 sbc #0
 clc
 adc #1
 sta Player_Y_HighPos
 lda QmField_0620
 lsr
 lsr
 lsr
 lsr
 sta QuickManWork_07
 lda QmField_0600
 asl
 asl
 asl
 asl
 ora QuickManWork_07
 sta Player_X_Speed
 bpl :+
 eor #$ff
 clc
 adc #1
:sta Player_XSpeedAbsolute
 lda #0
 sec
 sbc QmField_0660
 lda #0
 sbc QmField_0640
 sta Player_Y_Speed
 bit FixtureStatus
 bpl :+
 lda #$ff                    ; One native head-effect pass after source bonk.
 sta Player_Y_Speed
:
 lda #1
 ldx QmField_0640
 bmi :+
 bne State
 lda QmField_0660
 bne AirUp
:lda #2
 bne State
AirUp:lda #1
State:
 ldx QmField_002C
 cpx #3
 bne :+
 lda #0
:sta Player_State
 lda QmField_0420
 and #$40
 bne :+
 lda #2
 bne Facing
:lda #1
Facing:sta PlayerFacingDir
 lda #0
 sta PlayerSize
 sta PlayerStatus
 sta CrouchingFlag
 sta SideCollisionTimer
 rts

; Publish six native SMB targets into the retained source16..21 actor cache.
.segment "QH_MOVE"
QhCache:
 ldx #5
CacheLoop:
 lda #0
 sta QmField_0430,x
 lda Enemy_Flag,x
 beq CacheNext
 bmi CacheNext
 lda Enemy_State,x
 and #$20
 bne CacheNext
 lda Enemy_Y_HighPos,x
 cmp #1
 bne CacheNext
 lda Enemy_X_Position,x
 clc
 adc #8
 sta QmField_0470,x
 lda Enemy_PageLoc,x
 adc #0
 sta QmField_0450,x
 lda Enemy_Y_Position,x
 clc
 adc #8
 sta QmField_04B0,x
 lda #$82
 sta QmField_0430,x
CacheNext:dex
 bpl CacheLoop
 rts
.segment "QH_WEAPONS"
QhHitGate:
 sta ArenaGateA
 php
 lda #<QhHitOne
 sta ArenaGatePtr
 lda #>QhHitOne
 sta ArenaGatePtr+1
 lda #.lobyte(.bank(QhHitOne)|$80)
 jmp ArenaCallC

.segment "QM_COORD"
.export QhBonkFlag
QhBonkFlag:
 php
 pha
 lda QmField_0640
 ora QmField_0660
 beq :+
 lda #$80
 sta FixtureStatus
:pla
 plp
 rts

.segment "QH_MOVE"
.export QhMovement
QhMovement:
 lda Player_X_Position
 sec
 sbc ScreenLeft_X_Pos
 sta Player_Pos_ForScroll
 jsr QhImport
 jsr QhCache
 lda SavedJoypadBits
 ldx #8
 ldy #0
Reverse:lsr
 pha
 tya
 rol
 tay
 pla
 dex
 bne Reverse
 tya
 and #$f3                    ; Pause/Select remain host-owned.
 jsr QuickManTick
 lda FixtureStatus
 cmp #1
 bne :+
 jsr KillPlayer               ; Genuine fixed126 low-window service.
:
 lda _CurrentPlayer
 and #1
 asl
 asl
 tax
 lda QmField_06C0
 cmp QhPersistent,x
 beq :+
 sta QhPersistent,x
 lda QhPersistent+3,x
 ora #$80
 sta QhPersistent+3,x
:
 lda QmField_0099
 sta QhPersistent+1,x
 lda QmField_009B
 sta QhPersistent+2,x
 jmp QhExport

.segment "QH_CONSTRUCT"
.export QhConstruct,QhReset
QhConstruct:
 lda _CurrentPlayer
 and #1
 asl
 asl
 tax
 lda QhPersistent+3,x
 and #$1f
 cmp #$11
 jeq QhReset
 lda #40
 sta QhPersistent,x
 sta QhPersistent+1,x
 lda #$80
 sta QhPersistent+2,x
 lda #$d1
 sta QhPersistent+3,x
 jmp QhReset
.segment "QM_COORD"
QhReset:
 sta ArenaGateA
 php
 lda #<QhResetCore
 sta ArenaGatePtr
 lda #>QhResetCore
 sta ArenaGatePtr+1
 lda #.lobyte(.bank(QhResetCore)|$80)
 jmp ArenaCallC
.segment "QH_RESET"
QhResetCore:
 jsr QuickManInit
 lda _CurrentPlayer
 and #1
 asl
 asl
 tax
 lda QhPersistent,x
 bne :+
 lda QhPersistent+1,x
 sta QhPersistent,x
:sta QmField_06C0
 lda QhPersistent+1,x
 sta QmField_0099
 lda QhPersistent+2,x
 ora #$80
 sta QmField_009B
 lda QhPersistent+3,x
 ora #$c0
 sta QhPersistent+3,x
 lda #$ff                    ; SMB owns full-level camera bounds.
 sta QmField_0015
 lda #0
 ldx #3
:sta MmBulletType,x
 dex
 bpl :-
 sta MmDeathFlag
 sta GuestHurtTicks
 sta GuestHurtKind
 sta PlayerChangeSizeFlag
 jmp QhImport

.segment "QH_DRAW"
.export QhDraw,QhGraphics,QhVisible,QhNoop,QhDecline,QhBoxProfile,QhAdder,QhBox,QhStatusName
QhDraw:
 lda MmDeathFlag
 beq Alive
 QhFar MegaManDrawDeath
 rts
Alive:
 lda InjuryTimer
 beq :+
 lda FrameCounter
 and #2
 bne QhNoop
:lda CurrentOAMOffset
 jsr QuickManHostRender
 sta CurrentOAMOffset
QhNoop:rts
QhDecline:clc
 rts
.segment "QH_GRAPHICS"
QhGraphics:
 QhFar GmPublishEmpty
 lda Player_X_Position
 sec
 sbc ScreenLeft_X_Pos
 sta Player_Pos_ForScroll
 jmp QhImport
.segment "QH_BOX"
QhVisible:sec
 rts
QhBoxProfile:ldy #12
 rts
QhAdder:ldy #0
 sec
 rts
QhBox:
 lda Player_Rel_XPos
 clc
 adc #1
 sta BoundingBox_UL_Corner
 clc
 adc #14
 sta BoundingBox_LR_Corner
 lda Player_Y_Position
 clc
 adc #9
 sta BoundingBox_UL_Corner+1
 clc
 adc #23
 sta BoundingBox_LR_Corner+1
 rts
.segment "QH_NAME"
QhStatusName:
 cmp #0
 bne NameDone
 tya
 pha
 ldy #6
NameCopy:lda QhName,y
 sta VRAM_Buffer1+11,y
 dey
 bpl NameCopy
 pla
 tay
 lda #0
NameDone:rts
QhName:.byte "QUICK M"

.segment "QH_PROBE"
.export QhHead,QhSide
QhHead:ldy #0                  ; Quick's admitted terrain profile is always0.
 lda #0
 jmp QhProbe
QhSide:lda #1
QhProbe:
 pha
 tya
 pha
 lda Player_X_Position
 clc
 adc XAdd,y
 sta R5
 lda Player_PageLoc
 adc #0
 and #1
 tay
 lda #>Block_Buffer_1
 sta R7
 lda R5
 lsr
 lsr
 lsr
 lsr
 clc
 adc BlockBufferAddr,y
 sta R6
 pla
 tay
 lda YAdd,y
 cpy #0
 bne :+
 bit FixtureStatus
 bpl :+
 lda #8                     ; Last pixel inside the original bonked ceiling.
:
 clc
 adc Player_Y_Position
 and #$f0
 sec
 sbc #32
 sta R2
 sty QuickManWork_07
 tay
 lda (R6),y
 sta R3
 ldy QuickManWork_07
 pla
 bne Horizontal
 lda Player_Y_Position
 jmp Fraction
Horizontal:lda Player_X_Position
Fraction:and #15
 sta R4
 ldx #0
 lda R3
 sec
 rts
XAdd:.byte 8,1,15,1,1,15,15
YAdd:.byte 9,32,32,11,29,11,29

.segment "QH_HURT"
.export QhInjury,QhStatus,QhDeathStart,QhFullPower
QhInjury:
 lda InjuryTimer
 bne Protected
 lda QmField_06C0
 sec
 sbc #4                     ; Explicit SMB contact damage adaptation.
 bcc Dead
 beq Dead
 sta QmField_06C0
 lda #64
 sta InjuryTimer
 lda #4
 sta Square1SoundQueue
 sec
 rts
Dead:
 lda #0
 sta QmField_06C0
 jsr KillPlayer
Protected:sec
 rts
.segment "QH_STATUS"
QhStatus:lda #1
 tax
 rts
.segment "QH_DEATHSTART"
QhDeathStart:
 lda #0
 sta QmField_06C0
 lda _CurrentPlayer
 and #1
 asl
 asl
 tax
 lda #0
 sta QhPersistent,x
 ldx #4
:sta QmField_0420,x
 dex
 bpl :-
 jsr MegaManDeathStart        ; Genuine fixed127, mirrored by real CV3 owner.
 rts
.segment "QH_DEATH"
QhDeath:
 QhFar MegaManDeathUpdate
 rts
.export QhDeath
.segment "QH_HEAL"
QhFullPower:
 lda QmField_0099
 sta QmField_06C0
 tay
 lda _CurrentPlayer
 and #1
 asl
 asl
 tax
 tya
 sta QhPersistent,x
 lda QhPersistent+3,x
 ora #$80
 sta QhPersistent+3,x
 rts

.segment "QH_ITEM"
.export QhPrepare,QhPickup
QhPrepare:
 lda #9
 sta InvPickupOwner,x
 lda #$fc
 sta InvPickup,x
 lda #0
 sta InvRisePhase,x
 sta InvPickupSaveLo,x
 sta InvPickupSaveHi,x
 rts
QhPickup:
 lda PowerUpType,x
 cmp #2
 bcs NativePickup
 txa
 pha
 QhFar HuFullPower
 pla
 tax
 lda #$10
 sta Square2SoundQueue
 txa
 pha
 jsr EraseEnemyObject
 pla
 tax
 lda #6
 jsr SetupFloateyNumber
 sec
 rts
NativePickup:
 QhFar MarioSourcePowerupCollision
 rts

.segment "QH_COLORS"
.export QhColors,QhUi
QhColors:
 lda VRAM_Buffer_AddrCtrl
 bne ColorDone
 ldx VRAM_Buffer1_Offset
 cpx #54
 bcs ColorDone
 lda #$3f
 sta VRAM_Buffer1,x
 lda #$11
 sta VRAM_Buffer1+1,x
 lda #7
 sta VRAM_Buffer1+2,x
 ldy #6
:lda QhSourceColors,y
 sta VRAM_Buffer1+3,x
 inx
 dey
 bpl :-
 txa
 clc
 adc #3
 tax
 stx VRAM_Buffer1_Offset
 lda #0
 sta VRAM_Buffer1,x
 lda _CurrentPlayer
 and #1
 asl
 asl
 tax
 lda QhPersistent+3,x
 and #$bf
 sta QhPersistent+3,x
ColorDone:rts
QhSourceColors:.byte $38,$30,$0f,$0f,$15,$28,$0f
.segment "QH_UI"
QhUi:
 lda #0
 sta InvHudActive
 sta InvDirty
 lda _CurrentPlayer
 and #1
 asl
 asl
 tax
 lda QhPersistent+3,x
 and #$40
 beq :+
 QhFar HuColors
:
 lda VRAM_Buffer_AddrCtrl
 bne UiDone
 lda _CurrentPlayer
 and #1
 asl
 asl
 tay
 lda QhPersistent+3,y
 and #$80
 beq UiDone
 ldx VRAM_Buffer1_Offset
 cpx #56
 bcs UiDone
 lda #$20
 sta VRAM_Buffer1,x
 lda #4
 sta VRAM_Buffer1+1,x
 lda #5
 sta VRAM_Buffer1+2,x
 lda #$11                    ; H, P, space, two health digits.
 sta VRAM_Buffer1+3,x
 lda #$19
 sta VRAM_Buffer1+4,x
 lda #$24
 sta VRAM_Buffer1+5,x
 lda QmField_06C0
 ldy #0
Decimal:cmp #10
 bcc Digits
 sec
 sbc #10
 iny
 bne Decimal
Digits:sta VRAM_Buffer1+7,x
 tya
 sta VRAM_Buffer1+6,x
 txa
 clc
 adc #8
 tax
 stx VRAM_Buffer1_Offset
 lda #0
 sta VRAM_Buffer1,x
 lda _CurrentPlayer
 and #1
 asl
 asl
 tax
 lda QhPersistent+3,x
 and #$7f
 sta QhPersistent+3,x
UiDone:rts

.segment "QH_WEAPONS"
.export QhWeapons
QhWeapons:
 lda TimerControl
 jne WeaponsDone
 lda GameEngineSubroutine
 cmp #8
 jne WeaponsDone
 ldx #7
SaveBoxes:lda BoundingBox_UL_Corner+28,x
 pha
 dex
 bpl SaveBoxes
 lda MmSlot
 pha
 lda MmEnemySlot
 pha
 lda SmSlot
 pha
 lda SmBombHits
 pha
 lda MmBulletType
 pha
 lda ObjectOffset
 pha
 ldx #5
FlashLoop:lda MmEnemyFlash,x
 beq :+
 dec MmEnemyFlash,x
:dex
 bpl FlashLoop
 lda #2
 sta QuickManWork_06
WeaponLoop:
 jsr QhHitGate
 inc QuickManWork_06
 lda QuickManWork_06
 cmp #5
 bne WeaponLoop
 pla
 sta ObjectOffset
 pla
 sta MmBulletType
 pla
 sta SmBombHits
 pla
 sta SmSlot
 pla
 sta MmEnemySlot
 pla
 sta MmSlot
 ldx #0
RestoreBoxes:pla
 sta BoundingBox_UL_Corner+28,x
 inx
 cpx #8
 bne RestoreBoxes
WeaponsDone:rts

.segment "QH_HIT"
QhHitOne:
 ldx QuickManWork_06
 lda QmField_0420,x
 jpl HitDone
 lda QmField_0460,x
 sec
 sbc ScreenLeft_X_Pos
 sta QuickManWork_07
 lda QmField_0440,x
 sbc ScreenLeft_PageLoc
 bne HitDone
 lda QuickManWork_07
 cmp #4
 bcc HitDone
 cmp #252
 bcs HitDone
 sec
 sbc #4
 sta BoundingBox_UL_Corner+28
 clc
 adc #8
 sta BoundingBox_LR_Corner+28
 lda QmField_04A0,x
 cmp #4
 bcc HitDone
 cmp #236
 bcs HitDone
 sec
 sbc #4
 sta BoundingBox_UL_Corner+29
 clc
 adc #8
 sta BoundingBox_LR_Corner+29
 lda #0
 sta MmSlot
 sta SmSlot
 sta SmBombHits
 lda #10                     ; Native guarded piercing100-damage consumer.
 sta MmBulletType
 lda R6
 pha
 lda R7
 pha
 QhFar BeginEnemyLoop
 pla
 sta R7
 pla
 sta R6
HitDone:rts
