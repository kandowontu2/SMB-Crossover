from pathlib import Path
import hashlib,json,os,sys
O=Path(__file__).resolve().parent
R=next(p for p in O.parents if(p/'AGENTS.md').is_file())
sys.path[:0]=[str(R/'tools'),str(R/'tools/audit')]
from run_mesen import run
from mesen_session_guard_v1 import require_free_workspace
q=json.loads((O/'ready.json').read_text())
for p,h in q['bindings'].items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
other=require_free_workspace(R,Path(q['ROM']))
print('Other-project Mesen sessions left untouched: '+json.dumps([p['ProcessId'] for p in other]),flush=True)
os.environ['SMB_RUN_OUTPUT']=str(O/'capture')
O.joinpath('capture').mkdir()
(O/'capture/session-before.json').write_text(json.dumps(other,indent=2)+'\n')
result=run(O/'controller.lua',Path(q['ROM']),timeout=q['timeout'],emulator_options=['--doNotSaveSettings','--nes.removeSpriteLimit=false','--nes.ramPowerOnState=AllZeros','--nes.randomizeCpuPpuAlignment=false','--nes.randomizeMapperPowerOnState=false'])
for p,h in q['bindings'].items():assert hashlib.sha256(Path(p).read_bytes()).hexdigest()==h,p
(O/'capture/binding.json').write_text(json.dumps(dict(ROM_sha256=q['ROM_sha256'],ready_sha256=hashlib.sha256((O/'ready.json').read_bytes()).hexdigest(),exit_code=result),indent=2)+'\n')
raise SystemExit(result)
