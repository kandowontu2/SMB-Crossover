.setcpu "6502"
.macpack longbranch
SelectedCharacter=$6002
CurrentBankC=$7da1
ReloadCHRBank=$0146
NextBank_SMC=$0161
SafecallA_SMC=$0169
FarcallJmpTarget_SMC=$016b
SafereturnA_SMC=$0178
FarCallCommon=$015a
OperMode=$0771
FamilyMainCommit=$5fff
DisableScreenFlag=$0775
Mirror_PPUMASK=$077a
NmiDisable=$0139
X5PublishChr=$a03d
Mirror_PPUCTRL=$0779
HorizontalScroll=$0742
VerticalScroll=$0743
R0=$0003
R1=$0004
R2=$0005
Bank_X5PublishChr=$be
ShCacheServices=$a000
.include "shinobi_resident_loader_1101_v1.inc"
.include "shinobi_resident_dispatch_1101_v1.inc"
CurrentCHRBank=$0147
X5ChrMode=$73e0
SsChrActive=$7e05
X5WideChrActive=$73ee
.include "shinobi_chr_1101_v6.inc"
ShPriorScene=$bfcc
.include "shinobi_scene_1101_v7.inc"
.include "shinobi_damage_1101_v10.inc"
VRAM_Buffer1=$04af
VRAM_Buffer1_Offset=$04ae
BackgroundColorCtrl=$0747
AreaType=$0753
.include "shinobi_palette_1101_v12.inc"
ShBackgroundColors:.byte 34,34,15,15,15,34,15,15
CrossoverMenuIndex=$7309
FmAlts=$5fe5
ShPriorResolve=$b38e
.include "shinobi_menu_1101_v13.inc"
