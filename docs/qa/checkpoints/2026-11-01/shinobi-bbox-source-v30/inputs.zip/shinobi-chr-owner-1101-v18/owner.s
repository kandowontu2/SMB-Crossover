SelectedCharacter=$6002
.segment "OWNER"
php
pha
lda SelectedCharacter
cmp #36
bne Legacy
pla
plp
rts
Legacy:pla
plp
.byte $8d,$6a,$01,$a9,$bc,$8d,$6c,$01,$a9,$bb,$8d,$6d,$01,$a9,$ce,$4c,$5a,$01
