.setcpu "6502"
.macpack longbranch
.import MsState,MsLifeUnsupported
.include "metal_storm_render_host_1101_v7.inc"
