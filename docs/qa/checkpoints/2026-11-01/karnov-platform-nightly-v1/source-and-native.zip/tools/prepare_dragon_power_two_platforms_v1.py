"""Approved private two-placement native25 manager, exact frozen7c5a parent."""
from pathlib import Path
import difflib,json,re,subprocess,sys
R=Path(__file__).resolve().parents[1];sys.path[:0]=[str(R/'tools'),str(R/'tools/audit')]
from sunny_integrated_controls_v1 import scoped_load,address,sha
P=R/'build/dragon-power-flagpole-v3';B=R/'build/dragon-power-platform-v1'
O=R/'build/dragon-power-two-platforms-v1'

def main():
 assert not(O/'handoff.json').exists()
 assert sha(P/'candidate.nes')=='7c5a0f1ee9d924f76857d97d8b194472cb01bf7f2a49a60daf7a32ede4268cd4'
 for p,h in json.loads((P/'closure.json').read_text())['actual_ASM_dependencies'].items():assert sha(p)==h,p
 old=scoped_load(P/'candidate.nes');start=address(old,'DpPlatformEnd')
 assert old['raw'][16+26*8192+start-0xa000:16+26*8192+0x1600]==bytes([255])*(0xb600-start)
 O.mkdir(exist_ok=True)
 source=(B/'platform.inc').read_text()
 before=''' lda #$d8
 sta HpSupport                ; exclusive while raw24 scene25 cache is valid
 lda #<888
 sta HpXLo
 lda #>888
 sta HpXHi
 ldx #0
 jsr DpPlatformFind
 bcc Missing
 lda PlatformCollisionFlag,y
 bpl Done                     ; retain genuine support through any pickup
 jsr HpInSourceMargin'''
 after=''' ; Never retire or retarget a genuine passenger, including after pickup
 ; or a crossing of the selection boundary. Only one owned native actor.
 ldx #0
 jsr DpPlatformFind
 bcc Select
 lda PlatformCollisionFlag,y
 jpl Done
Select:
 lda Player_PageLoc
 cmp #3
 bcc First
 bne Second
 lda Player_X_Position
 cmp #24                       ; world792: between third and fourth pipes
 bcc First
Second:
 lda #<888
 ldx #>888
 jmp Chosen
First:
 lda #<704
 ldx #>704
Chosen:
 cmp HpXLo
 bne Switch
 cpx HpXHi
 beq Same
Switch:
 pha
 phx
 jsr DpPlatformRelease         ; exact reciprocal owner only; no native steal
 plx
 pla
Same:
 sta HpXLo
 stx HpXHi
 lda #$d8
 sta HpSupport
 ldx #0
 jsr DpPlatformFind
 bcc Missing
 jsr HpInSourceMargin'''
 assert source.count(before)==1;source=source.replace(before,after)
 before=''' lda #<872                     ; source center888, actual32px native girder
 sta Enemy_X_Position,x
 lda #>872
 sta Enemy_PageLoc,x'''
 after=''' ; Existing helper coordinate owns the selected native32px girder.
 lda HpXLo
 sec
 sbc #16
 sta Enemy_X_Position,x
 lda HpXHi
 sbc #0
 sta Enemy_PageLoc,x'''
 assert source.count(before)==1;source=source.replace(before,after)
 source=source.replace('; PRIVATE one-placement list cbe66b; actual native25, not helper sine.',
  '; PRIVATE approved centers704/888, one actual native25, not helper sine.')
 (O/'platform.inc').write_text(source)
 for n in['main.c','entrypoint.s']:(O/n).write_bytes((P/n).read_bytes())
 comp=(P/'component.s').read_text();line='.include "build/dragon-power-platform-v1/platform.inc"'
 assert comp.count(line)==1
 (O/'component.s').write_text(comp.replace(line,'.include "build/dragon-power-two-platforms-v1/platform.inc"'))
 replacements={str(P/n):str(O/n)for n in['main.c','entrypoint.s','component.s','candidate.nes','candidate.dbg','candidate.lbl','candidate.map']}
 cmd=[]
 for v in json.loads((P/'build-proof.json').read_text())['command']:
  for a,z in replacements.items():v=v.replace(a,z)
  cmd.append(v)
 z=subprocess.run(cmd,cwd=R,capture_output=True,text=True);(O/'build.log').write_text(z.stdout+z.stderr)
 assert not z.returncode,z.stderr
 from prepare_cv3_dmc_mirror import prepare
 prepare(R,O/'candidate.nes');b=scoped_load(O/'candidate.nes')
 diff={k:sum(a!=z for a,z in zip(old['raw'][16+k*8192:16+(k+1)*8192],b['raw'][16+k*8192:16+(k+1)*8192]))for k in range(128)}
 diff={k:v for k,v in diff.items()if v};assert set(diff)=={26},diff
 assert old['raw'][:16]==b['raw'][:16]and old['raw'][1048592:]==b['raw'][1048592:]
 ids={s.get('id')for n,s in old['syms'].items()if'::'in n};moves=[]
 for n,s in old['syms'].items():
  if n=='_FARCALL_COUNT'or('::'not in n and s.get('id')in ids):continue
  assert n in b['syms'],n
  if address(old,n)!=address(b,n):
   assert n.startswith('DpPlatform'),('unrelated PC moved',n)
   moves.append(dict(name=n,old=f'{address(old,n):04X}',new=f'{address(b,n):04X}'))
 assert address(old,'DpPlatformWeapons')==address(b,'DpPlatformWeapons')==0xb140
 patch=''.join(difflib.unified_diff((B/'platform.inc').read_text().splitlines(True),source.splitlines(True),fromfile='parent/platform.inc',tofile='two-platforms/platform.inc'))
 (O/'source.patch').write_text(patch)
 proof=dict(assembled=True,qualified=False,native_run=False,parent=sha(P/'candidate.nes'),candidate=sha(O/'candidate.nes'),DBG=sha(O/'candidate.dbg'),LBL=sha(O/'candidate.lbl'),changed_banks=diff,command=cmd,own_internal_moves=moves,external_PCs_RAM_CHR_header_exact=True,helper_start=address(b,'DpPlatformStart'),helper_end=address(b,'DpPlatformEnd'),helper_bytes=address(b,'DpPlatformEnd')-address(b,'DpPlatformStart'),approved_end=0xb600,extra_placement=dict(center=704,left=688,top=208,native_type=37),selection='704 while worldX<792, otherwise888; retain every genuine passenger before selection')
 (O/'build-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
 print(json.dumps({k:v for k,v in proof.items()if k not in['command','own_internal_moves']}))

def freeze():
 assert not(O/'handoff.json').exists()
 receipt=json.loads((O/'controls-frozen.json').read_text());assert receipt['passed']
 for path,h in receipt['bindings'].items():assert sha(path)==h,path
 parent=json.loads((P/'handoff.json').read_text())
 for path,h in parent['bindings'].items():assert sha(path)==h,('parent changed',path)
 replacements={str(P/n):str(O/n)for n in['entrypoint.s','component.s','main.c','main-final.d','main-final.o','component-final.d','component-final.o','c-final.o','independent.lbl','independent.dbg','independent.nes']}
 commands=[]
 for cmd in json.loads((P/'closure.json').read_text())['actual_commands']:
  cmd=cmd[:]
  for i,v in enumerate(cmd):
   for before,after in replacements.items():v=v.replace(before,after)
   cmd[i]=v
  z=subprocess.run(cmd,cwd=R,capture_output=True,text=True);assert not z.returncode,z.stderr
  commands.append(cmd)
 from prepare_cv3_dmc_mirror import prepare
 prepare(R,O/'independent.nes');assert sha(O/'independent.nes')==sha(O/'candidate.nes')
 deps={}
 for path in[O/'main-final.d',O/'component-final.d']:
  for word in re.split(r'(?<!\\)\s+',path.read_text().split(':\t',1)[1].strip().removesuffix(':')):
   target=Path(word.replace('\\ ',' '));target=(target if target.is_absolute()else R/target).resolve()
   assert target.is_file();deps[str(target)]=sha(target)
 ordinary={}
 for mapper in['mmc3','mmc5']:
  row=json.loads((P/'closure.json').read_text())['fresh_ordinary'][mapper];cmd=row['command'][:]
  for suffix in['.c','-entry.s']:(O/('ordinary-'+mapper+suffix)).write_bytes((P/('ordinary-'+mapper+suffix)).read_bytes())
  cmd=[v.replace(str(P/('ordinary-'+mapper)),str(O/('ordinary-'+mapper)))for v in cmd]
  z=subprocess.run(cmd,cwd=R,capture_output=True,text=True);assert not z.returncode,z.stderr
  assert sha(O/('ordinary-'+mapper+'.nes'))==row['sha256']
  ordinary[mapper]=dict(sha256=row['sha256'],command=cmd)
 closure=dict(passed=True,actual_ASM_dependencies=deps,actual_commands=commands,independent_link_exact=True,fresh_ordinary=ordinary)
 (O/'closure.json').write_text(json.dumps(closure,indent=2)+'\n')
 checks=receipt['checks'];approaches=checks['actual_complete_Main_normal_NMI_approaches']
 report=R/'docs/qa/dragon-power-two-platforms-source-2026-10-29.txt'
 text='''PRIVATE GOKU TWO-NATIVE25-PLACEMENT SUCCESSOR; SOURCE CPU ONLY, NATIVE UNRUN.
Exact frozen7c5a parent retained. Only platform manager in approved physical26:B140..<B600 changes. Additional approved center704/left688/top208/32px native25 elevator; original center888/left872 retained. One actor maximum: select704 while player worldX<792, otherwise888. Before selection, exact live reciprocal owner83/native25/state40 with genuine native passenger flag is retained, including after a genuine mature pickup and threshold crossing. Retarget only after the passenger leaves; true native EraseEnemyObject, free-slot search, InitEnemyObject, YMovingPlatform/carry/collision and actual four-part native girder remain owners. No sine/drawable-only support, actor stealing, new global mask, RAM, physics, source jump or global level-data edits.
The native actor left position is computed from HpXLo/Hi minus16. Cache uses the existing raw24 scene25/zero-authored-count exclusive state; the original34helper records and all foreign paths remain exact. Future AreaPointer pipe destination does not change stable scene ownership. Real InitializeArea clears actors/cache. Stale owner/ID/state/flag/pointer never erases an unrelated actor. All six slots busy declines without a spawn.
The original source apex-kick negative is preserved separately: it is a real one-per-airtime kick, but best tested high displacement68px and exact7c5a completeMain pipe arenas only reach705 at anchor112, so it does not bridge to736. This candidate does not invent boost or change that source behavior.
'''
 text+=f"Actual controls: {checks['actual_NrWeapons_full_return']['cases']} full NrWeapons return cases cover both centers, both modes, all64 legal flag combinations and cold/warm state; AXYP/SP/R0..7/ObjectOffset/final banks exact. "
 text+=f"{len(approaches)} actual completeMain+normalNMI arenas use authentic parsed1-1 tiles, typed starting position on each elevator and three real wait timings per mode. Each boards/carries, fresh-A jumps, releases Right over the pipe and lands naturally at anchor112/action1; zero source action/velocity/contact/HP/equipment/outcome grants seeded."
 text+='\nApproach results (mode,center,wait,updates,firstA,support,finalXY):\n'
 for row in approaches:text+=str([row['mode'],row['center'],row['wait'],row['updates'],row['first_fresh_A'],row['support_updates'],row['rows'][-1][2:4]])+'\n'
 text+=f"\n{checks['foreign_full_Main']['cases']} foreign completeMain cases retain wholeAXYP/SP/entirestack/application/OAM/CHR/5SMC/orderedwrites/banks/CPU exactly. Actual ownedMain CPU deltas include real actor work, not just branch counter cost: {checks['owned_complete_Main_CPU']['rows']}. Unequal actor presence at704 explains larger deltas; these are source arenas, no native cadence/FPS claim.\n"
 text+='Actual reached IRQ/lagNMI seams: '+str(sum(x['seams']for x in checks['actual_reached_IRQ_lagNMI']))+'; minimumSP '+str(min(x['minimum_SP']for x in checks['actual_reached_IRQ_lagNMI']))+'. Register/live stack/scratch/hardware+shadow banks/5SMC/helper91B/source-state restoration checked.\n'
 text+='The first control negative incorrectly expected704 to spawn88px behind the old888 camera; actual native margin correctly declined. Original receipt and exact tool preimage retained. The second successful control stopped above pipe height; final controls strengthen it to actual landings, without changing the candidate.\n'
 text+='No native run, whole-route clear, hardware deadline, palette/audio/drop/fairness or authentic enemy-population claim. ROOT alone launches native. No shared/default/Downloads/settings/Git changes.\n'
 build=json.loads((O/'build-proof.json').read_text())
 text+='Candidate '+sha(O/'candidate.nes')+'; helper bytes '+str(build['helper_bytes'])+'; end '+f"{build['helper_end']:04X}"+'; delta '+str(build['changed_banks'])+'.\n'
 report.write_text(text)
 files=set(Path(p)for p in parent['bindings'])|set(Path(p)for p in deps)|{Path(__file__),report,P/'handoff.json',R/'tools/audit/dragon_power_two_platforms_controls_v1.py',R/'tools/audit/dragon_power_apex_kick_pipe_v1.py',R/'build/dragon_power_apex_kick_pipe_v1.json',R/'docs/qa/dragon-power-apex-kick-pipe-source-2026-10-29.txt'}
 files.update(p for p in O.iterdir()if p.is_file()and p.suffix in['.json','.inc','.s','.c','.patch','.nes','.dbg','.lbl','.log','.d','.py'])
 hand=dict(status='FROZEN_PRIVATE_TWO_NATIVE25_PLACEMENTS_SOURCE_CPU_NATIVE_UNRUN',parent=sha(P/'candidate.nes'),candidate=sha(O/'candidate.nes'),DBG=sha(O/'candidate.dbg'),LBL=sha(O/'candidate.lbl'),native_run=False,source_report=str(report),actual_ASM_dependencies=deps,bindings={str(p.resolve()):sha(p)for p in sorted(files)},limits=text)
 for path,h in hand['bindings'].items():assert sha(path)==h,path
 (O/'handoff.json').write_text(json.dumps(hand,indent=2)+'\n')
 print(json.dumps(dict(candidate=hand['candidate'],DBG=hand['DBG'],LBL=hand['LBL'],handoff=sha(O/'handoff.json'),bindings=len(hand['bindings']),actual_ASM_dependencies=len(deps),report=sha(report))))

if __name__=='__main__':freeze()if'--freeze'in sys.argv else main()
