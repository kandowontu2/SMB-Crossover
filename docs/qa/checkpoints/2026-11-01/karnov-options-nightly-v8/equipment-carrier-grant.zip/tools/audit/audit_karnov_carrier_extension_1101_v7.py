"""Extend the closed old-owner CHR lease; review conditional Karnov C2 space."""
from pathlib import Path
import collections,hashlib,io,itertools,json,re,sys,zipfile
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
from link_pit_rygar_sophia_audit_cpu import scoped_load
from check_tmnt_render_oa import address,location
from verify_native_relocation import NesMPU
import check_hogan_current_bounded_v1 as M
P=R/'build/karnov-host-resource-base-1101-v1';O=R/'build/karnov-carrier-extension-1101-v7'
V6=R/'build/karnov-carrier-final-1101-v6'
PIN='0ffb1d79c4fbc52bb337a4726f8e61f984f30e4795fd2555b204322140c0a717'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
save=lambda p,q:p.write_text(json.dumps(q,indent=2)+'\n',encoding='utf-8')
NEW_PAGES={1021,1022,1023}

class Bus(M.Bus):
 def __init__(self,b):
  self.bad=[];self.pages=collections.Counter();self.serial=0;self.phase='init';self.leased_writes=[]
  super().__init__(b)
 def __setitem__(self,i,v):
  oldtag=self.rawtags[(i-0x8000)//8192]if isinstance(i,int)and i>=0x8000 else None
  super().__setitem__(i,v)
  if not isinstance(i,int):return
  if 0x5120<=i<=0x512b:
   page=self.chr_latches[i-0x5120];self.pages[page]+=1
   if page in NEW_PAGES:self.bad.append((self.phase,i,v,self.upper))
  if i in range(0x147,0x153)or i in range(0x73e0,0x73ec):self.serial+=1
  if oldtag==2 and 0x1600<=i&8191<0x1e00:self.leased_writes.append((self.phase,0xc000+(i&8191),v&255))

def irq(m):
 c=NesMPU(memory=m,pc=0x5b00);c.sp=224;c.p=0x30;c.irq()
 for _ in range(200):
  if(c.pc,c.sp)==(0x5b00,224):return
  assert m[c.pc]!=0;c.step()
 raise AssertionError('IRQ bound')

def read_pins():
 assert sha(P/'candidate.nes')==PIN;b=scoped_load(P/'candidate.nes')
 assert hashlib.sha256(b['raw']).hexdigest()==PIN
 checkpoint=R/'docs/qa/checkpoints/2026-11-01/karnov-combat-nightly-v7/source.zip'
 assert sha(checkpoint)=='d4160bbdda88160a74f735975a9899a69c4d2c3bd82d4c6467f39ab545379ca5'
 z=zipfile.ZipFile(io.BytesIO(checkpoint.read_bytes()))
 snapshot={name:z.read(name)for name in z.namelist()}
 images={}
 for g in b['segs'].values():
  if 'ooffs'not in g:continue
  p=Path(g['oname'].strip('"'))
  if p not in images:images[p]=b['raw']if p==P/'candidate.nes'else p.read_bytes()
 proofs={n:json.loads((V6/n).read_text())for n in['carrier-grant.json','compiled-writers.json','finite-writer-domains.json','cf-current-binding.json','current-reproduction.json']}
 successor_path=R/'build/karnov-combat-native-1101-v7/carrier-successor.json';successor=json.loads(successor_path.read_text())
 assert successor['passed']and successor['ROM_sha256']==PIN and successor['unchanged_other_owner_bytes']
 assert successor['grant_sha256']==sha(V6/'carrier-grant.json')=='d012a79d81bd7fe45f1f6c288154ae002626b3c07001fe67e09459de213854cd'
 assert successor['bindings'][str((P/'candidate.dbg').resolve())]==sha(P/'candidate.dbg')
 root_native=R/'docs/qa/checkpoints/2026-11-01/karnov-combat-nightly-v7/native-results.zip'
 assert sha(root_native)=='81a42673097b9ef87782d803fcb4cd31d08a04c76960e7b5550050f259c41341'
 assert json.loads(snapshot['verification/carrier-successor.json'])==successor,'Successor proof must equal published frozen source/verification packet'
 pins=dict(ROM_sha256=PIN,debug_sha256=sha(P/'candidate.dbg'),checkpoint_sha256=sha(checkpoint),native_packet_sha256=sha(root_native),successor_sha256=sha(successor_path),pinned_images=len(images))
 print(json.dumps(dict(pinned=True,ROM_sha256=PIN,no_more_live_O_reads=True)),flush=True)
 return b,snapshot,images,proofs,successor,pins

def compiled_extension(b,images,proofs,successor):
 segs={g['name'].strip('"'):g for g in b['segs'].values()};same=[];owned=[]
 for w in proofs['compiled-writers.json']['writers']:
  g=segs[w['segment']];at=int(g['ooffs'],0)+w['offset'];path=Path(g['oname'].strip('"'))
  actual=images[path][at:at+len(bytes.fromhex(w['bytes']))]
  s=w['witnesses'][0]
  if '/karnov-host-resource-base-'in s['path']and Path(s['path']).name.startswith('kr-'):
   owned.append(dict(segment=w['segment'],PC=w['PC'],source=s['path'],old=w['bytes'],current=actual.hex()));continue
  assert int(g['start'],0)+w['offset']==w['PC']and actual.hex()==w['bytes'],('Other writer changed',w,actual.hex())
  same.append(dict(segment=w['segment'],PC=w['PC'],bytes=w['bytes']))
 assert len(same)+len(owned)==845
 assert proofs['finite-writer-domains.json']['unclassified']==proofs['cf-current-binding.json']['unclassified']==[]
 # Every old high3 family ends1018; override upper domains0..2 work for
 # *every* lowbyte. New combat carrier1019/20 is explicitly private cold code.
 return dict(passed=True,base_ROM_sha256=PIN,inherited_base=successor['base_ROM_sha256'],unchanged_compiled_other_writer_spans=len(same),Karnov_owned_writer_spans=len(owned),other_writers=same,Karnov_changes=owned,
  inherited_indirect_domains=123,CF_private_writers=19,CF_private_indirect=1,unclassified=[],
  closed_publisher_family_maximum=1018,source_argument_extension='Existing named high3 arguments/atlas descriptors are bounded756..1018; FF crosses quarter2/3 and requires the actual lag publication barrier repeated below for low253/254/255. Override upper0..2 and native modezero cannot map1021..1023.',
  successor_allowed_intervals=successor['exact_allowed_intervals'],successor_other_owner_bytes_preserved=True)

def ff_barrier(b):
 M.Bus=Bus;m=M.fresh(b);M.put(m,SelectedCharacter=22,OperMode=1,DisableScreenFlag=1,Mirror_PPUMASK=0,Mirror_PPUCTRL=160,NmiDisable=255,FfVariant=0,PlayerFacingDir=1,PlayerOutlinesOff=1,GameEngineSubroutine=8,CurrentOAMOffset=0)
 m.ppuctrl=160;assert M.invoke(m,'FwLoad')['P']&1
 cut_pages=collections.Counter();cut_pcs=collections.Counter();minimum=224
 def interrupt(c,kind):
  nonlocal minimum
  before=(c.pc,c.sp,c.a,c.x,c.y,c.p&~16);getattr(c,kind)()
  for _ in range(200000):
   if(c.pc,c.sp)==before[:2]:break
   minimum=min(minimum,c.sp);assert m[c.pc]!=0;c.step()
  else:raise AssertionError('Actual interrupt bound')
  assert(c.a,c.x,c.y,c.p&~16)==before[2:]
 def ram(name,a=0):
  m.raw_page(1,3);M.put(m,CurrentBank=3,NmiDisable=255)
  c=NesMPU(memory=m,pc=address(b,name));c.a=a;c.p=0x31;c.sp=224;c.stPushWord(0x5aff)
  for _ in range(60000):
   if c.pc==0x5b00:break
   old=m.serial;assert m[c.pc]!=0;c.step()
   if old!=m.serial:
    dangerous={M.get(m,'CurrentCHRBank',i)+768 for i in range(12)if M.get(m,'X5ChrMode',i)&0x83==0x83 and M.get(m,'CurrentCHRBank',i)in range(251,256)}
    if dangerous:
     assert M.get(m,'NmiDisable')&128
     cut_pages.update(dangerous);cut_pcs[c.pc]+=1;interrupt(c,'nmi');interrupt(c,'irq')
  else:raise AssertionError(('FF source bound',name))
  assert c.sp==224
 pages=set();cases=0
 for variant,tier,pose,face in itertools.product(range(4),range(3),range(1,19),[1,2]):
  # Prime through the real typed publisher to the valid source FF page787.
  # This covers any legal preceding FF frame rather than depending on the
  # incidental enumeration order of poses/tier changes in a test loop.
  M.invoke(m,'X5SetPhysicalChr',a=19,x=3,y=0);M.invoke(m,'X5PublishChr')
  M.put(m,FfVariant=variant,FfPower=tier,PlayerFacingDir=face,FfReady=247,DisableScreenFlag=0,Mirror_PPUMASK=30)
  m.phase=f'FF:{variant}:{tier}:{pose}:{face}';ram('FfSetPose',pose);ram('FfPublishChunk')
  page=756+M.get(m,'FfRenderPage');assert M.get(m,'CurrentCHRBank')+256*(M.get(m,'X5ChrMode')&3)==page
  M.consume(m);irq(m);assert m.chr_latches[0]==page and not m.bad
  pages.add(page);cases+=1;m.writes.clear();m.ram_writes.clear();m.ppu_log.clear()
 assert NEW_PAGES<=set(cut_pages),(cut_pages,NEW_PAGES)
 return dict(passed=True,actual_source_profile_cases=cases,source_pages=sorted(pages),partial_pair_cuts_by_hypothetical_page=dict(cut_pages),cut_resume_PCs={hex(k):v for k,v in cut_pcs.items()},actual_NMI_and_IRQ_each_cut=True,normal_NMI_and_IRQ_each_case=True,AXYP_SP_exact=True,minimum_cut_SP=minimum,forbidden_hardware_writes=0,
  scope='Actual current0ff source FF code and real in-flight interrupt vectors. Prior valid FF page787 is admitted with genuine typed publisher before each source transition. This is source-state closure, not controller-earned footage or composed new-equipment Main stack qualification.')

def c2_review(b,snapshot):
 def snap(name):return snapshot['host/'+name]
 meta=snap('kr-pose-meta.bin');kernel=b['raw'][1048592+399*1024:1048592+407*1024]
 assert len(meta)==1345
 a=address(b,'KrArtImage');end=address(b,'KrArtEnd');base=int(next(g['start']for g in b['segs'].values()if g['name']=='"KR_KERNEL"'),0)
 assert end-a==1345 and kernel[a-base:end-base]==meta
 source_names=['kr-kernel.s','kr-host-actor.inc','kr-terrain.inc','kr-render.inc','kr-rebound.inc','kr-health.inc','kr-pickup-kernel-v3.inc','kr-combat-v7.inc','kr-resident.inc','kr-loader-carrier-v6.inc','kr-loader-invalidate-v6.inc','kr-loader-offsets-v6.inc','kr-pickup-rom-context-v3.inc','kr-pickup-rom-tail-v3.inc','kr-pickup-rom-align-v3.inc','kr-pickup-rom-auth-v5.inc','kr-pickup-rom-route-v4.inc']
 source={n:snap(n).decode()for n in source_names}
 for name in['portable_dispatch.inc','portable_weapon.inc','portable_clear.inc']:
  source['original-source/'+name]=snapshot['original-source/'+name].decode()
 syms={n:int(z['val'],0)for n,z in b['syms'].items()};stores=[];indirect=[];unclassified=[]
 def expr(text):
  text=re.sub(r'\$([0-9a-f]+)',lambda m:str(int(m[1],16)),text,flags=re.I)
  text=re.sub(r'\b[A-Za-z_]\w*\b',lambda m:str(syms[m[0]])if m[0]in syms else m[0],text)
  if not re.fullmatch(r'[0-9+\-() ]+',text):raise ValueError(text)
  return eval(text,{'__builtins__':{}},{})
 for name,text in source.items():
  for line_no,line in enumerate(text.splitlines(),1):
   text=line.split(';',1)[0].strip();hit=re.match(r'(?:(?:[\w@]+)?:\s*)?(sta|stx|sty|inc|dec|asl|lsr|rol|ror)\s+(.+)$',text,re.I)
   if not hit:continue
   operand=hit[2].strip()
   if operand.lower()=='a':continue
   row=dict(source=name,line=line_no,instruction=text)
   if operand.startswith('('):
    assert name in['kr-render.inc','kr-terrain.inc','kr-resident.inc'],row
    if name=='kr-render.inc':row['target']=[0xd000,0xd540];row['owner']='KrCopyArt exact1345-byte metadata copy.'
    elif name=='kr-terrain.inc':row['target']=[0xc000,0xc7ff];row['owner']='New-life source state clear8 pages only.'
    else:row['target']=[0xc000,0xdfff];row['owner']='Cold loader wholeC2 zero BEFORE new payload copy/cookies, or existing row copier C2C900..CDFF / C3C000..DFFF.'
    indirect.append(row);continue
   index=bool(re.search(r',\s*[xy]$',operand,re.I));operand=re.sub(r',\s*[xy]$','',operand,flags=re.I)
   try:target=expr(operand)
   except ValueError:
    if re.fullmatch(r'R[07][+\-]I',operand):row.update(target=[3,10],owner='Eight-byte foreground zero-page save/restore macro.');stores.append(row);continue
    unclassified.append(row);continue
   high=target+(255 if index else 0);row.update(target=[target,high])
   # Even a conservative full-byte index cannot reach the proposed range.
   assert not(target<0xde00 and high>=0xd600),('Existing C2 writer overlaps equipment code',row)
   stores.append(row)
 assert not unclassified,unclassified
 render=source['kr-render.inc'];resident=source['kr-resident.inc'];carrier=source['kr-loader-carrier-v6.inc']
 assert 'lda #$d0\n sta R1'in render and'lda #<(KrArtEnd-KrArtImage)'in render
 assert 'ldx #32\nKrZeroPage:'in resident and'jsr KrInvalidateBoth'in resident and'cmp #10'in resident
 assert '$c0,$c4,$c8,$cc,$d0,$d4,$d8,$dc,$c9,$cd'in carrier
 combat_start=address(b,'KrCombatRom');combat_end=address(b,'KrCombatRomEnd')
 assert combat_start==0xc900 and combat_end<=0xce00
 return dict(passed=True,conditional_owner='Authenticated Karnov only, selected34; both C2/C3 complete cookies required before service entry.',
  proposed_code_interval=[0xd600,0xde00],code_component_bytes=1701,placed_code_interval=[0xd600,0xd600+1701],two_carrier_copy_rows=[dict(CHR=1021,destination=0xd600,bytes=1024),dict(CHR=1022,destination=0xda00,bytes=1024)],
  actual_existing_C2_ownership=[dict(owner='Original actor/options RAM incl saved R0/R1',interval=[0xc000,0xc800]),dict(owner='Host terrain/render/health/pickup/combat context incl17-byte parked Main frame',interval=[0xc800,0xc87a]),dict(owner='Combat image copy inclpadding',interval=[0xc900,0xce00]),dict(owner='Body metadata exact1345B',interval=[0xd000,0xd541]),dict(owner='Complete paired cache cookie',interval=[0xdfe0,0xdff0])],
  metadata_source_span=[a,end],metadata_sha256=hashlib.sha256(meta).hexdigest(),existing_combat_code_span=[combat_start,combat_end],
  direct_store_sites=len(stores),indirect_store_sites=len(indirect),unclassified=[],stores=stores,indirect=indirect,
  source_bindings={name:hashlib.sha256(text.encode()).hexdigest()for name,text in source.items()},
  cold_loader_condition='Existing wholeC2 clear intentionally destroys D600..DDFF before copies. Extend row copy/readback after that clear and before BOTH cookie publications. New-life KrConstruct only clearsC000..C7FF and metadata copy onlyD000..D540, so code survives later life/scene construction.',
  alias_condition='C2 D600..DDFF aliases A2 B600..BDFF. No other conditional owner may execute/write this cache while Karnov owns it; new revision cookie must bind equipment and combat together.')

def ram_call(m,name):
 m.raw_page(1,3);m.raw_page(2,2);M.put(m,CurrentBank=3,CurrentBankC=2,NmiDisable=255)
 c=NesMPU(memory=m,pc=address(m.bundle,name));c.sp=224;c.p=0x31;c.stPushWord(0x5aff)
 for _ in range(100000):
  if c.pc==0x5b00:break
  assert m[c.pc]!=0;c.step()
 else:raise AssertionError(('RAM call bound',name))
 assert c.sp==224

def c2_controls(b,snapshot):
 M.Bus=Bus;m=M.fresh(b);M.put(m,CrossoverMenuIndex=7);M.invoke(m,'MenuResolveCharacter');M.invoke(m,'QueueSelection')
 M.put(m,CrossoverMenuButtons=0,SavedJoypad1Bits=32,SavedJoypad2Bits=0,VRAM_Buffer1_Offset=0);M.invoke(m,'CrossoverMenuInput');assert M.get(m,'SelectedCharacter')==34
 M.put(m,SavedJoypad1Bits=16,SavedJoypad2Bits=0,CrossoverMenuButtons=0,VRAM_Buffer1_Offset=0)
 start=M.invoke(m,'CrossoverMenuInput');M.invoke(m,'NativeRareGameMenuRoutineCore::ChkContinue',a=start['A'],x=start['X'],y=start['Y'],p=start['P']);M.invoke(m,'PauseRoutine',a=0)
 for frame in range(700):
  if M.get(m,'OperMode_Task')==3 and M.get(m,'GameEngineSubroutine')==8:break
  M.put(m,SavedJoypadBits=0,SavedJoypad1Bits=0,SavedJoypad2Bits=0,A_B_Buttons=0,Left_Right_Buttons=0,Up_Down_Buttons=0,NmiDisable=255);M.invoke(m,'GameLoop');M.consume(m)
 else:raise AssertionError('Karnov initial scene bound')
 assert m.ram[2][0x810]==m.ram[2][0x1fe0]==m.ram[3][0x1fe0]==167
 assert bytes(m.ram[2][0x1000:0x1541])==snapshot['host/kr-pose-meta.bin']
 initial_zero_writes=len(m.leased_writes);assert initial_zero_writes==2048 and all(v==0 for _,_,v in m.leased_writes)
 pattern=bytes((i*29+71)&255 for i in range(2048));m.ram[2][0x1600:0x1e00]=pattern;m.leased_writes.clear();m.phase='runtime'
 ram_call(m,'KrCopyArt');assert bytes(m.ram[2][0x1600:0x1e00])==pattern and not m.leased_writes
 for age in range(80):
  keys=(1 if age<55 else 0)|(128 if 20<=age<32 else 0)|(64 if age%12<2 else 0)
  M.put(m,SavedJoypadBits=keys,SavedJoypad1Bits=keys,SavedJoypad2Bits=0,A_B_Buttons=keys&192,Left_Right_Buttons=keys&3,Up_Down_Buttons=keys&12,NmiDisable=255)
  M.invoke(m,'GameLoop');M.consume(m);irq(m);assert not m.leased_writes and bytes(m.ram[2][0x1600:0x1e00])==pattern
  m.writes.clear();m.ram_writes.clear();m.ppu_log.clear()
 assert not m.bad
 return dict(passed=True,cold_Main_frames=frame,actual_whole_C2_zero_writes_to_proposal=initial_zero_writes,exact_metadata_bytes=1345,actual_KrCopyArt_guarded=True,actual_gameplay_Main_NMI_IRQ_frames=80,post_load_code_guard_bytes=2048,post_load_code_writes=0,forbidden_CHR_pages_written=0,
  scope='Existing current0ff cold Select/Start/parser/entrance and Main via CPU peripheral model. Proposed RAM code bytes are a controlled sentinel fixture, not an executable overlay. Confirms copier/state operations leave the source-granted interval untouched after cold zero; no new equipment/native qualification.')

def main():
 O.mkdir(exist_ok=True);b,snapshot,images,proofs,successor,pins=read_pins()
 out=dict(passed=False,carrier_granted=False,base_ROM_sha256=PIN,pins=pins)
 out['compiled_owner_extension']=compiled_extension(b,images,proofs,successor)
 out['FF_interrupt_extension']=ff_barrier(b)
 out['C2_source_ownership']=c2_review(b,snapshot)
 out['C2_actual_controls']=c2_controls(b,snapshot)
 out.update(passed=True,carrier_granted=True,CHR_pages=[1021,1022,1023],CHR_code_pages=[1021,1022],CHR_optional_icon_page=1023,C2_code_lease_granted=True,C2_code_interval=[0xd600,0xde00],
  conditions=['Exact0ff old-owner graph only. Preserve other code/data/public PCs and existing combat carrier1019/1020; bind successor delta as for v6.','New code copies both full1KB rows and readbacks AFTER wholeC2 zero, BEFORE BOTH code cookies publish; cookie revision binds equipment and combat. Keep metadata D000..D540 and parked context C868..C879 intact.','CHR1023 is available to a new explicitly owned Karnov icon publisher. Existing HUD/special upper-bit domain0..2 must remain true for old owners; any new upper3 icon override needs exact low255 pairing, owner/scene clearing and interrupt validation.','Actual new-equipment composed Main stack, farcall/service routing, loader failures/native gameplay and nightly delivery qualification remain root work.'],
  limits=['No relink, ROM copy, broad dependency tree, Mesen, video or per-frame outputs. Reuses frozen exact v6 compiler closure and published current0ff allowed-delta proof.','C2 lease is conditional on authenticated Karnov ownership, not a global free RAM grant to all characters.','Arbitrary damaged RAM and invalid externally fabricated API arguments remain outside legal source-domain proof.'])
 save(O/'carrier-grant.json',out)
 files=[Path(__file__),O/'carrier-grant.json'];packet=O/'source-and-proof.zip'
 with zipfile.ZipFile(packet,'w',zipfile.ZIP_DEFLATED,compresslevel=9)as z:
  for p in files:z.write(p,p.relative_to(R).as_posix())
 save(O/'publication.json',dict(passed=True,carrier_granted=True,base_ROM_sha256=PIN,grant_sha256=sha(O/'carrier-grant.json'),source_sha256=sha(__file__),packet_sha256=sha(packet),packet_bytes=packet.stat().st_size,no_live_outputs_retained=True))
 print(json.dumps(dict(passed=True,carrier_granted=True,grant_sha256=sha(O/'carrier-grant.json'),packet_sha256=sha(packet),packet_bytes=packet.stat().st_size)),flush=True)
if __name__=='__main__':main()
