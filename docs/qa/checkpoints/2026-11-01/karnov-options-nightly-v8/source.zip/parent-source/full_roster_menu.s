.export FmQueueName
.export FmResolve
; Front-end only admission layer. Pending profiles never reach gameplay tables.
; Two previously unused ExRAM variant bytes; cleared on screen entry and launch.
.if ::ENABLE_MMC5_EXPANDED && ::MAPPER_MMC5
FmAlts=$5fe5                   ; Karnov/Metal/Shinobi/Bowser/Prince/Quick/Thomas
FmGroups=$5fe8                 ; WWF low3, ContraForce bits3..4
.pushseg
.segment "FULL_ROSTER_MENU"

; Carry set: A is a pending portrait/name index. Carry clear: playable owner.
.proc FmPending
 ldx CrossoverMenuIndex
 cpx #0
 bne NotMario
 lda MarioVariant
 cmp #2
 bne Ready
 lda #0
 clc
 rts
NotMario:
 cpx #2
 bne NotRogue
 lda $5fee
 and #1
 beq Ready
 lda #1
 clc
 rts
NotRogue:
 cpx #7
 bne NotKarnov
 lda FmAlts
 and #1
 beq Ready
 lda #2
 sec
 rts
NotKarnov:
 cpx #9
 bne NotQuickMan
 lda FmAlts
 and #32
 beq Ready
 lda #31
 clc
 rts
NotQuickMan:
 cpx #10
 bne NotShinobi
 lda FmAlts
 and #4
 bne Shinobi
 lda FmAlts
 and #64
 beq Ready
 lda #32
 clc
 rts
Shinobi:
 lda #3
 sec
 rts
NotShinobi:
 cpx #11
 bne Groups
 lda FmAlts
 and #2
 beq Ready
 lda #4
 sec
 rts
Ready:
 clc
 rts
Groups:
 cpx #21
 bne NotFF
 lda $5fef
 and #3
 clc
 adc #5
 clc
 rts
NotFF:
 cpx #25
 beq Ready
 cpx #27
 beq Ready
 cpx #23
 bcc Ready
 lda #9
 cpx #23
 beq Ready
 cpx #24
 bne NotSMB2
 lda $5fe3
 and #3
 clc
 adc #10
 clc
 rts
NotSMB2:
 cpx #26
 bne NotBowser
 lda FmAlts
 and #8
 beq Bowser3
 lda #16
 clc
 rts
Bowser3:lda #15
 clc
 rts
NotBowser:
 cpx #28
 bne NotWWF
 lda FmGroups
 and #7
 clc
 adc #18
 cmp #24
 rts
NotWWF:
 cpx #29
 bne ContraForce
 lda FmAlts
 and #16
 beq Bike
 lda #25
 bne Pending
Bike:lda #24
 bne Pending
ContraForce:
 cpx #31
 bne ForceVariant
 lda FmAlts
 bmi Goku
 lda #30
 bne ArthurGokuReady
Goku:lda #9
ArthurGokuReady:clc
 rts
ForceVariant:
 lda FmGroups
 and #24
 lsr
 lsr
 lsr
 clc
 adc #26
 clc
 rts
Pending:sec
 rts
.assert *-FmPending<=243,lderror,"Existing248B pending envelope"
.res 4,$ea
.endproc

.proc FmResolve
 jsr FmPending
 bcc Native
 lda #0
 sta SelectedCharacter
 sta CmActive
 rts
Native:
 farcall HuResolve,jmp
.endproc

; Handle the newly visible alternate families before legacy Select handlers.
.proc FmToggle
 lda CrossoverMenuPressed
 and #Select_Button
 bne HasSelect
 clc
 rts
HasSelect:ldx CrossoverMenuIndex
 bne NotMario
 farcall KmNextVariant
 sec
 rts
NotMario:
 cpx #2
 bne NotRogue
 lda $5fee
 eor #1
 sta $5fee
 sec
 rts
NotRogue:
 cpx #7
 bne NotKarnov
 lda #1
 jmp Flip
NotKarnov:
 cpx #9
 bne NotBass
 lda FmAlts
 and #32
 beq BassOrRoll
 eor FmAlts
 sta FmAlts
 lda #0
 sta RlVariant
 beq BassReady
BassOrRoll:
 lda RlVariant
 beq Roll
 lda FmAlts
 ora #32
 sta FmAlts
 lda #0
 sta RlVariant
 beq BassReady
Roll:inc RlVariant
BassReady:
 lda #0
 sta RlPalette
 sec
 rts
NotBass:
 cpx #10
 bne NotShinobi
 lda FmAlts
 and #68
 beq SelectShinobi
 cmp #4
 bne Flip
 lda #68
 bne Flip
SelectShinobi:lda #4
 bne Flip
NotShinobi:
 cpx #11
 bne NotMetal
 lda #2
 bne Flip
NotMetal:
 cpx #26
 bne NotBowser
 lda #8
 bne Flip
NotBowser:
 cpx #29
 bne NotPrince
 lda #16
Flip:eor FmAlts
 sta FmAlts
 sec
 rts
NotPrince:
 cpx #31
 bne NotArthur
 lda #$80
 jmp Flip
NotArthur:
 cpx #21
 bne NotFF
 inc $5fef
 lda $5fef
 and #3
 sta $5fef
 sec
 rts
NotFF:
 cpx #24
 bne NotSMB2
 inc $5fe3
 lda $5fe3
 and #7
 sta $5fe3
 sec
 rts
NotSMB2:
  cpx #23
  bne NotBattletoads
  lda FmGroups
  eor #$20
  sta FmGroups
  sec
  rts
NotBattletoads:
  cpx #28
 bne NotWWF
 lda FmGroups
 and #7
 clc
 adc #1
 cmp #6
 bcc WwfLegal
 lda #0
WwfLegal:sta R0
 lda FmGroups
 and #$f8
 ora R0
 sta FmGroups
 sec
 rts
NotWWF:
 cpx #30
 bne No
 lda FmGroups
 clc
  adc #8
  eor FmGroups
  and #24
  eor FmGroups
 sta FmGroups
Yes:sec
 rts
No:clc
 rts
.assert *-FmToggle<=278,lderror,"Existing Select span"
.res 0,$ea
.assert *-FmToggle=278,lderror,"Preserve Select entry span"
.endproc

.proc FmQueueName
 jsr FmPending
 ; Fixed-width rows, index*16 forms a real16-bit pointer without wrap.
 ldx #<FmNames
 stx R2
 ldx #>FmNames
 stx R3
Page:cmp #16
 bcc Low
 inc R3
 sec
 sbc #16
 bcs Page
Low:asl
 asl
 asl
 asl
 tay
 ldx VRAM_Buffer1_Offset
 lda #$23
 sta VRAM_Buffer1,x
 lda #$28
 sta VRAM_Buffer1+1,x
 lda #16
 sta VRAM_Buffer1+2,x
 sta R0
Copy:lda (R2),y
 sta VRAM_Buffer1+3,x
 inx
 iny
 dec R0
 bne Copy
 txa
 clc
 adc #3
 tax
 stx VRAM_Buffer1_Offset
 lda #0
 sta VRAM_Buffer1,x
 rts
.endproc

; Pending previews borrow all four body windows. Restore both the page bytes
; and their direct/legacy interpretation before a native owner rebuilds art.
.proc FmNativePrepare
 farcall X5ClearChrModes
 ldx #7
Restore:
 lda CHRBankInitValues,x
 sta CurrentCHRBank,x
 dex
 bpl Restore
 rts
.endproc

.proc FmDrawDkPreview
 ; Sole typed caller supplies actualSelectedA28or32 through genuine SFC.
 cmp #32
 lda #17
 bcc Draw
 lda #30
Draw:
 jmp FmDrawPreviewSelected
.endproc
.proc FmDrawPreview
 jsr FmPending
.endproc
.proc FmDrawPreviewSelected
 pha
 farcall MoveAllSpritesOffscreen
 farcall X5ClearChrModes
 ldy #0
Map:
 tya
 clc
 adc #$bc                     ; physical700..703, direct MMC5 upper2
 ldx #2
 farcall X5SetPhysicalChr
 iny
 cpy #4
 bcc Map
 pla
 pha
 cmp #17
 beq WideDK
 asl
 asl
 tay
 ldx #0
Copy:
 lda FmPreviewTiles,y
 sta Sprite_Data+1,x
 lda #0
 sta Sprite_Data+2,x
 txa
 and #4
 asl
 adc #120
 sta Sprite_Data+3,x
 txa
 and #8
 asl
 adc #159
 sta Sprite_Data,x
 iny
 inx
 inx
 inx
 inx
 cpx #16
 bcc Copy
 bcs PreviewCopied
WideDK:
 ldy #23
WideCopy:
 lda FmDkPreviewOam,y
 sta Sprite_Data,y
 dey
 bpl WideCopy
 ldx #24
PreviewCopied:
 stx CurrentOAMOffset
 pla
 sta R0
 asl
 clc
 adc R0
 tay
 ldx VRAM_Buffer1_Offset
 lda #$3f
 sta VRAM_Buffer1,x
 lda #$11
 sta VRAM_Buffer1+1,x
 lda #3
 sta VRAM_Buffer1+2,x
 lda FmPreviewColors,y
 sta VRAM_Buffer1+3,x
 lda FmPreviewColors+1,y
 sta VRAM_Buffer1+4,x
 lda FmPreviewColors+2,y
 sta VRAM_Buffer1+5,x
 txa
 clc
 adc #6
 tax
 stx VRAM_Buffer1_Offset
 lda #0
 sta VRAM_Buffer1,x
 rts
FmDkPreviewOam:.byte 159,132,0,116,159,134,0,124,159,132,64,132,175,252,0,116,175,254,0,124,175,252,64,132
.endproc

.include "full_roster_menu_art.inc"
;28B funded by26B coordinate/data compaction plus the old2B tail.
; Only the real Start path calls this; original flags survive except native
; final A0 N/Z, X/Y unchanged, and every foreign alternate byte is cleared.
.proc FmStartFlags
 farcall FmStartRetireFlags,jmp
 .res 10,$ea
.endproc
.assert *-FmStartFlags=28,lderror,"Start identity worker exact funding"
.assert * <= $c000,lderror,"Full roster UI exceeds bank76 A-view tail"
.popseg
.endif
