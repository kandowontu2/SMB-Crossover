.import ThGmHeadWithinOwn
.include "union_main_imports.inc"
.include "gimmick_state.inc"
.import GmNewGame,GmScene,GmEnsure,GmMovement,GmAfterTerrain,GmImport,GmGraphics,GmDraw,GmColors,GmPortrait,GmWeapons,GmInjury,GmHead,GmFoot,GmSide,GmBox,GmAdder,GmHealth,GmPickup,GmStompPolicy,GmBounce,GmDeathStart,GmFullPower,GmNmiClock
.import GmDeathUpdate
.import GmConstruct,GmForcePalette,GmHostBounce,GmHostFullBox,GmHostGraphics,GmHostInjury,GmHostMovement,GmHostPickup,GmHudTemplate,GmHurtFinish,GmInjuryStatus,GmMenuResolve,GmNativePickup,GmPaletteAttempt,GmPortraitPrepare,GmPublishEmpty,GmResetOwn,GmResolveTail,GmSyncForm,GmUi,GmUiFinish,GmVisibleGate
; Dedicated admission for the October roster expansion. Never index the
; old twelve-owner inventory or graphics tables with a new character ID.
; Each adapter restores incoming A/P before entering its actual owner.
.pushseg
.segment "NEW_ROSTER_GATE"
.macro NrCeleste Target
 php
 pha
 lda SelectedCharacter
 bne :+
 lda MarioVariant
 cmp #4
 bne :+
 pla
 plp
 farcall Target,jmp
:pla
 plp
.endmacro
.macro NrGate Name,Ice,City,Sunny,Legacy
.proc Name
 php
 pha
 lda SelectedCharacter
 cmp #CHARACTER_ICE_CLIMBERS
 beq ToIce
 cmp #CHARACTER_RIVER_CITY
 beq ToCity
 cmp #CHARACTER_SUNNY
 beq ToSunny
 pla
 plp
 farcall Legacy,jmp
ToIce:
 pla
 plp
 farcall Ice,jmp
ToCity:
 pla
 plp
 farcall City,jmp
ToSunny:
 pla
 plp
 farcall Sunny,jmp
.endproc
.endmacro

.macro GmNrRoute Name,Ice,City,Sunny,Legacy,Gimmick,Size,Extra,ExtraSize,Explicit
.proc Name
 sta SafecallA_SMC+1
 php
 .if Explicit
 cmp SelectedCharacter
 beq ArgumentOwned
 plp
 farcall Legacy,jmp
ArgumentOwned:
 .endif
 tya
 pha
 jsr GmNrIndex
::.ident(.concat(.string(Name),"UnionReturn")):
 lda TargetLo,y
 sta FarcallJmpTarget_SMC+1
 lda TargetHi,y
 sta FarcallJmpTarget_SMC+2
 lda TargetBank,y
 jmp GmNrFinish
TargetLo:.byte <Legacy,<Ice,<City,<Sunny,<Gimmick
TargetHi:.byte >Legacy,>Ice,>City,>Sunny,>Gimmick
 .if .xmatch({Name},{NrGraphics})
TargetBank=ThNrDrawBankTable
 .elseif .xmatch({Name},{NrPortrait})
TargetBank=NrMovement::TargetBank
 .else
 .if .xmatch({Name},{NrDraw})
::ThNrDrawBankTable:
 .endif
TargetBank:.byte .lobyte(.bank(Legacy)|$80),.lobyte(.bank(Ice)|$80),.lobyte(.bank(City)|$80),.lobyte(.bank(Sunny)|$80),.lobyte(.bank(Gimmick)|$80)
 .endif
 Extra
 .assert *-Name<=Size,lderror,"Gimmick same-entry capsule overflow"
 .if .xmatch({Name},{NrGraphics}) .or .xmatch({Name},{NrPortrait})
 .res Size-37-24*Explicit-ExtraSize,$ff
 .else
 .res Size-42-24*Explicit-ExtraSize,$ff
 .endif
 .assert *-Name=Size,lderror,"Gimmick genuine original capsule size"
.endproc
.endmacro

.macro GmExtraNrMovement
.scope GmOwnedHelper9
::GmAfterTerrainGate:
 php
 pha
 lda SelectedCharacter
 cmp #26
 beq Own
 pla
 plp
 jmp GmLegacyPostBG
Own:pla
 plp
 farcall GmAfterTerrain
 farcall GmSyncForm,jmp

.endscope
.endmacro
GmNrRoute NrMovement,IcMovement,RcMovement,SunnyNativeMovement,JnMovementDispatch,GmHostMovement,97,GmExtraNrMovement,52,0
.macro GmExtraNrGraphics
.scope GmOwnedHelper51
 .byte $ff
::GmMenuName:
 farcall HuGmMenuName,jmp
::HuOnlyRare:
 tya
 clc
 adc #15
 asl
 asl
 asl
 asl
 sta FarcallJmpTarget_SMC+1
 lda #>HuEntryBase
 adc #0
 sta FarcallJmpTarget_SMC+2
 lda #.lobyte(.bank(HuEntryBase)|$80)
 jmp GmNrFinish
::ThOnlyCheck:
 cmp #10
 bne Foreign
 lda FmAlts
 and #$44
 cmp #$40
 beq HuOnlyRare
 lda #10
Foreign:jmp GmOnlyCompareStart
.endscope
.endmacro
GmHeadWithinOwn=ThGmHeadWithinOwn
GmNrRoute NrGraphics,IcGraphics,RcGraphics,SunnyGraphicsIntegrated,RlGraphicsDispatch,GmHostGraphics,97,GmExtraNrGraphics,60,0
.macro GmExtraNrDraw
.scope GmOwnedHelper0
::GmNrIndex:
 lda SelectedCharacter
 cmp #20
 bcc Low
 cmp #27
 bcs Rare
 sec
 sbc #20
 tay
 lda HighMap,y
 bmi Rare
 tay
 rts
Rare:jmp HuNrRarePrefix
Low:
 cmp #2
 beq Rare
 cmp #10
 beq Rare
 cmp #9
 bne Legacy
 lda FmAlts
 and #32
 bne Rare
Legacy:ldy #0
 rts
HighMap:.byte 1,2,$ff,3,$ff,$ff,4
 .byte $ff
.endscope
.endmacro
GmNrRoute NrDraw,IcDraw,RcDraw,SunnyDraw,RlDrawDispatch,GmDraw,97,GmExtraNrDraw,55,0
.macro GmExtraNrPortrait
.scope GmOwnedHelper36
 .word $ffff
::GmOnlyCommon:
 lda SelectedCharacter
 jmp ThOnlyCheck
::GmOnlyCompareStart:
 cmp #2
 beq GmOnlyRogueLow
 cmp #9
 beq GmOnlyQuick
 cmp #26
 beq Own
 cmp #22
 beq GmOnlyHigh
 cmp #31
 bcs GmOnlyHigh
 cmp #24
 bcc GmOnlyLegacy
 cmp #30
 bcc GmOnlyHigh
 .res 2,$ea
::GmOnlyLegacy:
Legacy:
 tya
 ora #16
 tay
Own:
 lda GmOnlyLo,y
 sta FarcallJmpTarget_SMC+1
 lda GmOnlyHi,y
 sta FarcallJmpTarget_SMC+2
 lda GmOnlyBank,y
 jmp GmNrFinish

.endscope
.endmacro
GmNrRoute NrPortrait,IcPortrait,RcPortrait,SunnyPortrait,JnPortraitDispatch,GmPortraitPrepare,97,GmExtraNrPortrait,60,0
.macro GmExtraNrWeapons
.scope GmOwnedHelper39
::GmOnlyBank:
 .byte .lobyte(.bank(GmConstruct)|$80),.lobyte(.bank(GmHostFullBox)|$80),.lobyte(.bank(GmHostPortrait)|$80),.lobyte(.bank(GmMenuName)|$80),.lobyte(.bank(GmResetOwn)|$80),.lobyte(.bank(GmPrepareOwn)|$80),.lobyte(.bank(GmNativeNoop)|$80),.lobyte(.bank(GmNativeNoop)|$80),.lobyte(.bank(GmMatureOwn)|$80),.lobyte(.bank(GmHostPickup)|$80),.lobyte(.bank(GmFullPower)|$80),.lobyte(.bank(GmForcePalette)|$80),.lobyte(.bank(GmHostBounce)|$80),.lobyte(.bank(GmHeadWithinOwn)|$80),.lobyte(.bank(GmUi)|$80),.lobyte(.bank(GmStatusNameTail)|$80),.lobyte(.bank(BmFresh)|$80),.lobyte(.bank(MaaBox)|$80),.lobyte(.bank(KmPortrait)|$80),.lobyte(.bank(MaaQueueName)|$80),.lobyte(.bank(JnResetDispatch)|$80),.lobyte(.bank(JnPrepareDispatch)|$80),.lobyte(.bank(JnRiseDispatch)|$80),.lobyte(.bank(JnPrivateDispatch)|$80),.lobyte(.bank(JnCollisionDispatch)|$80),.lobyte(.bank(JnPickupDispatch)|$80),.lobyte(.bank(CheatsFullPower)|$80),.lobyte(.bank(BmColors)|$80),.lobyte(.bank(X5StompDispatch)|$80),.lobyte(.bank(Z2HeadWithinTerrain)|$80),.lobyte(.bank(VvUiDispatch)|$80),.lobyte(.bank(JnStatusName)|$80)

.endscope
.scope GmOwnedHelper53
::GmOnlyRogueLow:
 lda RdVariant
 cmp #1
 beq GmOnlyRare
 bne GmOnlyLegacy
::GmOnlyQuick:
 lda FmAlts
 and #32
 beq GmOnlyLegacy
::GmOnlyHigh:
 cmp #35
 bcs GmOnlyLegacy
::GmOnlyRare:
 jmp HuOnlyRare

.endscope
.endmacro
GmNrRoute NrWeapons,IcWeapons,RcWeapons,SunnyWeapons,JnWeaponsDispatch,GmWeapons,97,GmExtraNrWeapons,55,0
.macro GmExtraNrInjury
.scope GmOwnedHelper3
::GmHostPortrait:
 lda Player_X_Position
 sta R4
 lda #0
 sta R5
 lda Player_Y_Position
 sta R6
 lda #0
 farcall GmPortraitAnchored,jmp

.endscope
.scope GmOwnedHelper4
::GmBodyPolicy:
 lda AreaType
 sta GuestBodyStompAllowed
 lda CrossoverBehaviorVersion
 sta GuestBodyNoStomp
 lda GmRam038C
 beq Vulnerable
 sec
 rts
Vulnerable:clc
 rts

.endscope
.endmacro
GmNrRoute NrInjury,IcInjuryStart,RcInjuryStart,SunnyInjuryIntegrated,JnInjuryStartDispatch,GmHostInjury,97,GmExtraNrInjury,53,0
.proc NrInjuryStatus
 NrCeleste CmHostInjuryStatus
 jmp NrLegacyInjuryStatus
.endproc
.macro GmExtraNrLegacyInjuryStatus
.scope GmOwnedHelper44
::GmPrepareOwn:
 lda #26
 sta InvPickupOwner,x
 lda #$fc
 sta InvPickup,x
 lda #0
 sta InvRisePhase,x
 sta InvPickupSaveLo,x
 sta InvPickupSaveHi,x
 rts
::GmNativeNoop:
 clc
 rts

.endscope
.scope GmOwnedHelper19
::GmIceBody:
 lda AreaType
 sta GuestBodyStompAllowed
 lda CrossoverBehaviorVersion
 sta GuestBodyNoStomp
 clc
 rts
::GmNativeSide:
 jmp BlockBufferColli_Side

.endscope
.scope GmOwnedHelper45
::GmMatureOwn:
 lda PowerUpType,x
 cmp #2
 bcs Allowed
 lda Enemy_State,x
 bmi Allowed
 clc
 rts
Allowed:sec
 rts

.endscope
.endmacro
GmNrRoute NrLegacyInjuryStatus,IcInjuryStatus,RcInjuryStatus,SunnyInjuryStatus,JnInjuryStatusDispatch,GmInjuryStatus,97,GmExtraNrLegacyInjuryStatus,55,0
.macro GmExtraNrDeathStart
.scope GmOwnedHelper20
::GmFreshGate:
 php
 sta SafecallA_SMC+1
 tya
 pha
 ldy #0
 jmp GmOnlyCommon

.endscope
.scope GmOwnedHelper21
::GmFullBoxGate:
 php
 sta SafecallA_SMC+1
 tya
 pha
 ldy #1
 jmp GmOnlyCommon

.endscope
.scope GmOwnedHelper22
::GmMenuDrawGate:
 php
 sta SafecallA_SMC+1
 tya
 pha
 ldy #2
 jmp GmOnlyCommon

.endscope
.scope GmOwnedHelper23
::GmMenuNameGate:
 php
 sta SafecallA_SMC+1
 tya
 pha
 ldy #3
 jmp GmOnlyCommon

.endscope
.scope GmOwnedHelper24
::GmResetGate:
 php
 sta SafecallA_SMC+1
 tya
 pha
 ldy #4
 jmp GmOnlyCommon

.endscope
.endmacro
GmNrRoute NrDeathStart,IcDeathStart,RcDeathStart,SunnyDeathStart,JnInventoryDeathDispatch,GmDeathPrepare,97,GmExtraNrDeathStart,55,0
.macro GmExtraNrDeath
.scope GmOwnedHelper25
::GmPrepareGate:
 php
 sta SafecallA_SMC+1
 tya
 pha
 ldy #5
 jmp GmOnlyCommon

.endscope
.scope GmOwnedHelper26
::GmRiseGate:
 php
 sta SafecallA_SMC+1
 tya
 pha
 ldy #6
 jmp GmOnlyCommon

.endscope
.scope GmOwnedHelper27
::GmPrivateGate:
 php
 sta SafecallA_SMC+1
 tya
 pha
 ldy #7
 jmp GmOnlyCommon

.endscope
.scope GmOwnedHelper28
::GmMatureGate:
 php
 sta SafecallA_SMC+1
 tya
 pha
 ldy #8
 jmp GmOnlyCommon

.endscope
.scope GmOwnedHelper29
::GmPickupGate:
 php
 sta SafecallA_SMC+1
 tya
 pha
 ldy #9
 jmp GmOnlyCommon

.endscope
.endmacro
; agent-v1: raw26 death owner is GmDeathUpdate (host.s), not bare NativePlayerDeath.
GmNrRoute NrDeath,IcDeathUpdate,RcDeath,SunnyNativeDeath,JnDeathDispatch,GmDeathUpdate,97,GmExtraNrDeath,55,0
.macro GmExtraNrVisible
.scope GmOwnedHelper30
::GmFullPowerGate:
 php
 sta SafecallA_SMC+1
 tya
 pha
 ldy #10
 jmp GmOnlyCommon

.endscope
.scope GmOwnedHelper31
::GmColorsGate:
 php
 sta SafecallA_SMC+1
 tya
 pha
 ldy #11
 jmp GmOnlyCommon

.endscope
.scope GmOwnedHelper32
::GmStompGate:
 php
 sta SafecallA_SMC+1
 tya
 pha
 ldy #12
 jmp GmOnlyCommon

.endscope
.scope GmOwnedHelper33
::GmHeadWithinGate:
 php
 sta SafecallA_SMC+1
 tya
 pha
 ldy #13
 jmp GmOnlyCommon

.endscope
.scope GmOwnedHelper34
::GmUiGate:
 php
 sta SafecallA_SMC+1
 tya
 pha
 ldy #14
 jmp GmOnlyCommon

.endscope
.endmacro
GmNrRoute NrVisible,IcVisible,RcVisible,SunnyVisible,JnVisibleDispatch,GmVisibleGate,97,GmExtraNrVisible,55,0
.macro GmExtraNrHead
.scope GmOwnedHelper35
::GmNrRare:
 ; Original Y/P remain on the native stack. Its caller prologue preserves X
 ; in Y and adds the linked return bytes with C=1 from the taken raw24/28 CMP.
 ldx #14
Find:cmp GmNrReturnLow,x
 beq Found
 dex
 bpl Find
 brk                           ; impossible under the linked closure below
Found:
 txa
 asl
 asl
 asl
 asl
 sta FarcallJmpTarget_SMC+1
 lda #>HuEntryBase
 adc #0
 sta FarcallJmpTarget_SMC+2
 tya
 tax
 pla                           ; discard only the local JSR return
 pla
 lda #.lobyte(.bank(HuEntryBase)|$80)
 jmp GmNrFinish
GmNrReturnLow:
 .byte .lobyte((<(NrMovementUnionReturn-1)) + (>(NrMovementUnionReturn-1)) + 1),.lobyte((<(NrGraphicsUnionReturn-1)) + (>(NrGraphicsUnionReturn-1)) + 1),.lobyte((<(NrDrawUnionReturn-1)) + (>(NrDrawUnionReturn-1)) + 1),.lobyte((<(NrPortraitUnionReturn-1)) + (>(NrPortraitUnionReturn-1)) + 1),.lobyte((<(NrWeaponsUnionReturn-1)) + (>(NrWeaponsUnionReturn-1)) + 1),.lobyte((<(NrInjuryUnionReturn-1)) + (>(NrInjuryUnionReturn-1)) + 1),.lobyte((<(NrLegacyInjuryStatusUnionReturn-1)) + (>(NrLegacyInjuryStatusUnionReturn-1)) + 1),.lobyte((<(NrDeathStartUnionReturn-1)) + (>(NrDeathStartUnionReturn-1)) + 1),.lobyte((<(NrDeathUnionReturn-1)) + (>(NrDeathUnionReturn-1)) + 1),.lobyte((<(NrVisibleUnionReturn-1)) + (>(NrVisibleUnionReturn-1)) + 1),.lobyte((<(NrHeadUnionReturn-1)) + (>(NrHeadUnionReturn-1)) + 1),.lobyte((<(NrBodyUnionReturn-1)) + (>(NrBodyUnionReturn-1)) + 1),.lobyte((<(NrAdderUnionReturn-1)) + (>(NrAdderUnionReturn-1)) + 1),.lobyte((<(NrBoxUnionReturn-1)) + (>(NrBoxUnionReturn-1)) + 1),.lobyte((<(NrSideUnionReturn-1)) + (>(NrSideUnionReturn-1)) + 1)
.assert (.lobyte((<(NrMovementUnionReturn-1)) + (>(NrMovementUnionReturn-1)) + 1)) <> (.lobyte((<(NrGraphicsUnionReturn-1)) + (>(NrGraphicsUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrMovementUnionReturn-1)) + (>(NrMovementUnionReturn-1)) + 1)) <> (.lobyte((<(NrDrawUnionReturn-1)) + (>(NrDrawUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrMovementUnionReturn-1)) + (>(NrMovementUnionReturn-1)) + 1)) <> (.lobyte((<(NrPortraitUnionReturn-1)) + (>(NrPortraitUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrMovementUnionReturn-1)) + (>(NrMovementUnionReturn-1)) + 1)) <> (.lobyte((<(NrWeaponsUnionReturn-1)) + (>(NrWeaponsUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrMovementUnionReturn-1)) + (>(NrMovementUnionReturn-1)) + 1)) <> (.lobyte((<(NrInjuryUnionReturn-1)) + (>(NrInjuryUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrMovementUnionReturn-1)) + (>(NrMovementUnionReturn-1)) + 1)) <> (.lobyte((<(NrLegacyInjuryStatusUnionReturn-1)) + (>(NrLegacyInjuryStatusUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrMovementUnionReturn-1)) + (>(NrMovementUnionReturn-1)) + 1)) <> (.lobyte((<(NrDeathStartUnionReturn-1)) + (>(NrDeathStartUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrMovementUnionReturn-1)) + (>(NrMovementUnionReturn-1)) + 1)) <> (.lobyte((<(NrDeathUnionReturn-1)) + (>(NrDeathUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrMovementUnionReturn-1)) + (>(NrMovementUnionReturn-1)) + 1)) <> (.lobyte((<(NrVisibleUnionReturn-1)) + (>(NrVisibleUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrMovementUnionReturn-1)) + (>(NrMovementUnionReturn-1)) + 1)) <> (.lobyte((<(NrHeadUnionReturn-1)) + (>(NrHeadUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrMovementUnionReturn-1)) + (>(NrMovementUnionReturn-1)) + 1)) <> (.lobyte((<(NrBodyUnionReturn-1)) + (>(NrBodyUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrMovementUnionReturn-1)) + (>(NrMovementUnionReturn-1)) + 1)) <> (.lobyte((<(NrAdderUnionReturn-1)) + (>(NrAdderUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrMovementUnionReturn-1)) + (>(NrMovementUnionReturn-1)) + 1)) <> (.lobyte((<(NrBoxUnionReturn-1)) + (>(NrBoxUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrMovementUnionReturn-1)) + (>(NrMovementUnionReturn-1)) + 1)) <> (.lobyte((<(NrSideUnionReturn-1)) + (>(NrSideUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrGraphicsUnionReturn-1)) + (>(NrGraphicsUnionReturn-1)) + 1)) <> (.lobyte((<(NrDrawUnionReturn-1)) + (>(NrDrawUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrGraphicsUnionReturn-1)) + (>(NrGraphicsUnionReturn-1)) + 1)) <> (.lobyte((<(NrPortraitUnionReturn-1)) + (>(NrPortraitUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrGraphicsUnionReturn-1)) + (>(NrGraphicsUnionReturn-1)) + 1)) <> (.lobyte((<(NrWeaponsUnionReturn-1)) + (>(NrWeaponsUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrGraphicsUnionReturn-1)) + (>(NrGraphicsUnionReturn-1)) + 1)) <> (.lobyte((<(NrInjuryUnionReturn-1)) + (>(NrInjuryUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrGraphicsUnionReturn-1)) + (>(NrGraphicsUnionReturn-1)) + 1)) <> (.lobyte((<(NrLegacyInjuryStatusUnionReturn-1)) + (>(NrLegacyInjuryStatusUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrGraphicsUnionReturn-1)) + (>(NrGraphicsUnionReturn-1)) + 1)) <> (.lobyte((<(NrDeathStartUnionReturn-1)) + (>(NrDeathStartUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrGraphicsUnionReturn-1)) + (>(NrGraphicsUnionReturn-1)) + 1)) <> (.lobyte((<(NrDeathUnionReturn-1)) + (>(NrDeathUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrGraphicsUnionReturn-1)) + (>(NrGraphicsUnionReturn-1)) + 1)) <> (.lobyte((<(NrVisibleUnionReturn-1)) + (>(NrVisibleUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrGraphicsUnionReturn-1)) + (>(NrGraphicsUnionReturn-1)) + 1)) <> (.lobyte((<(NrHeadUnionReturn-1)) + (>(NrHeadUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrGraphicsUnionReturn-1)) + (>(NrGraphicsUnionReturn-1)) + 1)) <> (.lobyte((<(NrBodyUnionReturn-1)) + (>(NrBodyUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrGraphicsUnionReturn-1)) + (>(NrGraphicsUnionReturn-1)) + 1)) <> (.lobyte((<(NrAdderUnionReturn-1)) + (>(NrAdderUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrGraphicsUnionReturn-1)) + (>(NrGraphicsUnionReturn-1)) + 1)) <> (.lobyte((<(NrBoxUnionReturn-1)) + (>(NrBoxUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrGraphicsUnionReturn-1)) + (>(NrGraphicsUnionReturn-1)) + 1)) <> (.lobyte((<(NrSideUnionReturn-1)) + (>(NrSideUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrDrawUnionReturn-1)) + (>(NrDrawUnionReturn-1)) + 1)) <> (.lobyte((<(NrPortraitUnionReturn-1)) + (>(NrPortraitUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrDrawUnionReturn-1)) + (>(NrDrawUnionReturn-1)) + 1)) <> (.lobyte((<(NrWeaponsUnionReturn-1)) + (>(NrWeaponsUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrDrawUnionReturn-1)) + (>(NrDrawUnionReturn-1)) + 1)) <> (.lobyte((<(NrInjuryUnionReturn-1)) + (>(NrInjuryUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrDrawUnionReturn-1)) + (>(NrDrawUnionReturn-1)) + 1)) <> (.lobyte((<(NrLegacyInjuryStatusUnionReturn-1)) + (>(NrLegacyInjuryStatusUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrDrawUnionReturn-1)) + (>(NrDrawUnionReturn-1)) + 1)) <> (.lobyte((<(NrDeathStartUnionReturn-1)) + (>(NrDeathStartUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrDrawUnionReturn-1)) + (>(NrDrawUnionReturn-1)) + 1)) <> (.lobyte((<(NrDeathUnionReturn-1)) + (>(NrDeathUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrDrawUnionReturn-1)) + (>(NrDrawUnionReturn-1)) + 1)) <> (.lobyte((<(NrVisibleUnionReturn-1)) + (>(NrVisibleUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrDrawUnionReturn-1)) + (>(NrDrawUnionReturn-1)) + 1)) <> (.lobyte((<(NrHeadUnionReturn-1)) + (>(NrHeadUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrDrawUnionReturn-1)) + (>(NrDrawUnionReturn-1)) + 1)) <> (.lobyte((<(NrBodyUnionReturn-1)) + (>(NrBodyUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrDrawUnionReturn-1)) + (>(NrDrawUnionReturn-1)) + 1)) <> (.lobyte((<(NrAdderUnionReturn-1)) + (>(NrAdderUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrDrawUnionReturn-1)) + (>(NrDrawUnionReturn-1)) + 1)) <> (.lobyte((<(NrBoxUnionReturn-1)) + (>(NrBoxUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrDrawUnionReturn-1)) + (>(NrDrawUnionReturn-1)) + 1)) <> (.lobyte((<(NrSideUnionReturn-1)) + (>(NrSideUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrPortraitUnionReturn-1)) + (>(NrPortraitUnionReturn-1)) + 1)) <> (.lobyte((<(NrWeaponsUnionReturn-1)) + (>(NrWeaponsUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrPortraitUnionReturn-1)) + (>(NrPortraitUnionReturn-1)) + 1)) <> (.lobyte((<(NrInjuryUnionReturn-1)) + (>(NrInjuryUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrPortraitUnionReturn-1)) + (>(NrPortraitUnionReturn-1)) + 1)) <> (.lobyte((<(NrLegacyInjuryStatusUnionReturn-1)) + (>(NrLegacyInjuryStatusUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrPortraitUnionReturn-1)) + (>(NrPortraitUnionReturn-1)) + 1)) <> (.lobyte((<(NrDeathStartUnionReturn-1)) + (>(NrDeathStartUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrPortraitUnionReturn-1)) + (>(NrPortraitUnionReturn-1)) + 1)) <> (.lobyte((<(NrDeathUnionReturn-1)) + (>(NrDeathUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrPortraitUnionReturn-1)) + (>(NrPortraitUnionReturn-1)) + 1)) <> (.lobyte((<(NrVisibleUnionReturn-1)) + (>(NrVisibleUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrPortraitUnionReturn-1)) + (>(NrPortraitUnionReturn-1)) + 1)) <> (.lobyte((<(NrHeadUnionReturn-1)) + (>(NrHeadUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrPortraitUnionReturn-1)) + (>(NrPortraitUnionReturn-1)) + 1)) <> (.lobyte((<(NrBodyUnionReturn-1)) + (>(NrBodyUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrPortraitUnionReturn-1)) + (>(NrPortraitUnionReturn-1)) + 1)) <> (.lobyte((<(NrAdderUnionReturn-1)) + (>(NrAdderUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrPortraitUnionReturn-1)) + (>(NrPortraitUnionReturn-1)) + 1)) <> (.lobyte((<(NrBoxUnionReturn-1)) + (>(NrBoxUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrPortraitUnionReturn-1)) + (>(NrPortraitUnionReturn-1)) + 1)) <> (.lobyte((<(NrSideUnionReturn-1)) + (>(NrSideUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrWeaponsUnionReturn-1)) + (>(NrWeaponsUnionReturn-1)) + 1)) <> (.lobyte((<(NrInjuryUnionReturn-1)) + (>(NrInjuryUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrWeaponsUnionReturn-1)) + (>(NrWeaponsUnionReturn-1)) + 1)) <> (.lobyte((<(NrLegacyInjuryStatusUnionReturn-1)) + (>(NrLegacyInjuryStatusUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrWeaponsUnionReturn-1)) + (>(NrWeaponsUnionReturn-1)) + 1)) <> (.lobyte((<(NrDeathStartUnionReturn-1)) + (>(NrDeathStartUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrWeaponsUnionReturn-1)) + (>(NrWeaponsUnionReturn-1)) + 1)) <> (.lobyte((<(NrDeathUnionReturn-1)) + (>(NrDeathUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrWeaponsUnionReturn-1)) + (>(NrWeaponsUnionReturn-1)) + 1)) <> (.lobyte((<(NrVisibleUnionReturn-1)) + (>(NrVisibleUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrWeaponsUnionReturn-1)) + (>(NrWeaponsUnionReturn-1)) + 1)) <> (.lobyte((<(NrHeadUnionReturn-1)) + (>(NrHeadUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrWeaponsUnionReturn-1)) + (>(NrWeaponsUnionReturn-1)) + 1)) <> (.lobyte((<(NrBodyUnionReturn-1)) + (>(NrBodyUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrWeaponsUnionReturn-1)) + (>(NrWeaponsUnionReturn-1)) + 1)) <> (.lobyte((<(NrAdderUnionReturn-1)) + (>(NrAdderUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrWeaponsUnionReturn-1)) + (>(NrWeaponsUnionReturn-1)) + 1)) <> (.lobyte((<(NrBoxUnionReturn-1)) + (>(NrBoxUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrWeaponsUnionReturn-1)) + (>(NrWeaponsUnionReturn-1)) + 1)) <> (.lobyte((<(NrSideUnionReturn-1)) + (>(NrSideUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrInjuryUnionReturn-1)) + (>(NrInjuryUnionReturn-1)) + 1)) <> (.lobyte((<(NrLegacyInjuryStatusUnionReturn-1)) + (>(NrLegacyInjuryStatusUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrInjuryUnionReturn-1)) + (>(NrInjuryUnionReturn-1)) + 1)) <> (.lobyte((<(NrDeathStartUnionReturn-1)) + (>(NrDeathStartUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrInjuryUnionReturn-1)) + (>(NrInjuryUnionReturn-1)) + 1)) <> (.lobyte((<(NrDeathUnionReturn-1)) + (>(NrDeathUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrInjuryUnionReturn-1)) + (>(NrInjuryUnionReturn-1)) + 1)) <> (.lobyte((<(NrVisibleUnionReturn-1)) + (>(NrVisibleUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrInjuryUnionReturn-1)) + (>(NrInjuryUnionReturn-1)) + 1)) <> (.lobyte((<(NrHeadUnionReturn-1)) + (>(NrHeadUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrInjuryUnionReturn-1)) + (>(NrInjuryUnionReturn-1)) + 1)) <> (.lobyte((<(NrBodyUnionReturn-1)) + (>(NrBodyUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrInjuryUnionReturn-1)) + (>(NrInjuryUnionReturn-1)) + 1)) <> (.lobyte((<(NrAdderUnionReturn-1)) + (>(NrAdderUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrInjuryUnionReturn-1)) + (>(NrInjuryUnionReturn-1)) + 1)) <> (.lobyte((<(NrBoxUnionReturn-1)) + (>(NrBoxUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrInjuryUnionReturn-1)) + (>(NrInjuryUnionReturn-1)) + 1)) <> (.lobyte((<(NrSideUnionReturn-1)) + (>(NrSideUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrLegacyInjuryStatusUnionReturn-1)) + (>(NrLegacyInjuryStatusUnionReturn-1)) + 1)) <> (.lobyte((<(NrDeathStartUnionReturn-1)) + (>(NrDeathStartUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrLegacyInjuryStatusUnionReturn-1)) + (>(NrLegacyInjuryStatusUnionReturn-1)) + 1)) <> (.lobyte((<(NrDeathUnionReturn-1)) + (>(NrDeathUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrLegacyInjuryStatusUnionReturn-1)) + (>(NrLegacyInjuryStatusUnionReturn-1)) + 1)) <> (.lobyte((<(NrVisibleUnionReturn-1)) + (>(NrVisibleUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrLegacyInjuryStatusUnionReturn-1)) + (>(NrLegacyInjuryStatusUnionReturn-1)) + 1)) <> (.lobyte((<(NrHeadUnionReturn-1)) + (>(NrHeadUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrLegacyInjuryStatusUnionReturn-1)) + (>(NrLegacyInjuryStatusUnionReturn-1)) + 1)) <> (.lobyte((<(NrBodyUnionReturn-1)) + (>(NrBodyUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrLegacyInjuryStatusUnionReturn-1)) + (>(NrLegacyInjuryStatusUnionReturn-1)) + 1)) <> (.lobyte((<(NrAdderUnionReturn-1)) + (>(NrAdderUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrLegacyInjuryStatusUnionReturn-1)) + (>(NrLegacyInjuryStatusUnionReturn-1)) + 1)) <> (.lobyte((<(NrBoxUnionReturn-1)) + (>(NrBoxUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrLegacyInjuryStatusUnionReturn-1)) + (>(NrLegacyInjuryStatusUnionReturn-1)) + 1)) <> (.lobyte((<(NrSideUnionReturn-1)) + (>(NrSideUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrDeathStartUnionReturn-1)) + (>(NrDeathStartUnionReturn-1)) + 1)) <> (.lobyte((<(NrDeathUnionReturn-1)) + (>(NrDeathUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrDeathStartUnionReturn-1)) + (>(NrDeathStartUnionReturn-1)) + 1)) <> (.lobyte((<(NrVisibleUnionReturn-1)) + (>(NrVisibleUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrDeathStartUnionReturn-1)) + (>(NrDeathStartUnionReturn-1)) + 1)) <> (.lobyte((<(NrHeadUnionReturn-1)) + (>(NrHeadUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrDeathStartUnionReturn-1)) + (>(NrDeathStartUnionReturn-1)) + 1)) <> (.lobyte((<(NrBodyUnionReturn-1)) + (>(NrBodyUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrDeathStartUnionReturn-1)) + (>(NrDeathStartUnionReturn-1)) + 1)) <> (.lobyte((<(NrAdderUnionReturn-1)) + (>(NrAdderUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrDeathStartUnionReturn-1)) + (>(NrDeathStartUnionReturn-1)) + 1)) <> (.lobyte((<(NrBoxUnionReturn-1)) + (>(NrBoxUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrDeathStartUnionReturn-1)) + (>(NrDeathStartUnionReturn-1)) + 1)) <> (.lobyte((<(NrSideUnionReturn-1)) + (>(NrSideUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrDeathUnionReturn-1)) + (>(NrDeathUnionReturn-1)) + 1)) <> (.lobyte((<(NrVisibleUnionReturn-1)) + (>(NrVisibleUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrDeathUnionReturn-1)) + (>(NrDeathUnionReturn-1)) + 1)) <> (.lobyte((<(NrHeadUnionReturn-1)) + (>(NrHeadUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrDeathUnionReturn-1)) + (>(NrDeathUnionReturn-1)) + 1)) <> (.lobyte((<(NrBodyUnionReturn-1)) + (>(NrBodyUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrDeathUnionReturn-1)) + (>(NrDeathUnionReturn-1)) + 1)) <> (.lobyte((<(NrAdderUnionReturn-1)) + (>(NrAdderUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrDeathUnionReturn-1)) + (>(NrDeathUnionReturn-1)) + 1)) <> (.lobyte((<(NrBoxUnionReturn-1)) + (>(NrBoxUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrDeathUnionReturn-1)) + (>(NrDeathUnionReturn-1)) + 1)) <> (.lobyte((<(NrSideUnionReturn-1)) + (>(NrSideUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrVisibleUnionReturn-1)) + (>(NrVisibleUnionReturn-1)) + 1)) <> (.lobyte((<(NrHeadUnionReturn-1)) + (>(NrHeadUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrVisibleUnionReturn-1)) + (>(NrVisibleUnionReturn-1)) + 1)) <> (.lobyte((<(NrBodyUnionReturn-1)) + (>(NrBodyUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrVisibleUnionReturn-1)) + (>(NrVisibleUnionReturn-1)) + 1)) <> (.lobyte((<(NrAdderUnionReturn-1)) + (>(NrAdderUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrVisibleUnionReturn-1)) + (>(NrVisibleUnionReturn-1)) + 1)) <> (.lobyte((<(NrBoxUnionReturn-1)) + (>(NrBoxUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrVisibleUnionReturn-1)) + (>(NrVisibleUnionReturn-1)) + 1)) <> (.lobyte((<(NrSideUnionReturn-1)) + (>(NrSideUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrHeadUnionReturn-1)) + (>(NrHeadUnionReturn-1)) + 1)) <> (.lobyte((<(NrBodyUnionReturn-1)) + (>(NrBodyUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrHeadUnionReturn-1)) + (>(NrHeadUnionReturn-1)) + 1)) <> (.lobyte((<(NrAdderUnionReturn-1)) + (>(NrAdderUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrHeadUnionReturn-1)) + (>(NrHeadUnionReturn-1)) + 1)) <> (.lobyte((<(NrBoxUnionReturn-1)) + (>(NrBoxUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrHeadUnionReturn-1)) + (>(NrHeadUnionReturn-1)) + 1)) <> (.lobyte((<(NrSideUnionReturn-1)) + (>(NrSideUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrBodyUnionReturn-1)) + (>(NrBodyUnionReturn-1)) + 1)) <> (.lobyte((<(NrAdderUnionReturn-1)) + (>(NrAdderUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrBodyUnionReturn-1)) + (>(NrBodyUnionReturn-1)) + 1)) <> (.lobyte((<(NrBoxUnionReturn-1)) + (>(NrBoxUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrBodyUnionReturn-1)) + (>(NrBodyUnionReturn-1)) + 1)) <> (.lobyte((<(NrSideUnionReturn-1)) + (>(NrSideUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrAdderUnionReturn-1)) + (>(NrAdderUnionReturn-1)) + 1)) <> (.lobyte((<(NrBoxUnionReturn-1)) + (>(NrBoxUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrAdderUnionReturn-1)) + (>(NrAdderUnionReturn-1)) + 1)) <> (.lobyte((<(NrSideUnionReturn-1)) + (>(NrSideUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"
.assert (.lobyte((<(NrBoxUnionReturn-1)) + (>(NrBoxUnionReturn-1)) + 1)) <> (.lobyte((<(NrSideUnionReturn-1)) + (>(NrSideUnionReturn-1)) + 1)),lderror,"Rare gate caller collision"

.endscope
.endmacro
GmNrRoute NrHead,IcHead,RcHeadProbe,SunnyHead,JnHeadDispatch,GmHead,97,GmExtraNrHead,50,0

.proc NrReset
 php
 pha
 lda SelectedCharacter
 bne :+
 lda MarioVariant
 cmp #4
 beq Own
:
 lda SelectedCharacter
 cmp #CHARACTER_ICE_CLIMBERS
 beq Own
 cmp #CHARACTER_RIVER_CITY
 beq Own
 cmp #CHARACTER_SUNNY
 beq Own
 pla
 plp
 jmp GmResetGate
::HuNrRarePrefix:
 txa
 tay
 tsx
 lda $0101,x
 adc $0102,x
 jmp GmNrRare
 .res 3,$ea
Own:
 pla
 plp
 lda #0
 farcall SpecialRosterClear    ; clear shared legacy weapon/CHR overrides too
 lda SelectedCharacter
 bne :+
 farcall CmHostEnsure,jmp
:
 lda SelectedCharacter
 cmp #CHARACTER_SUNNY
 beq Sunny
 cmp #CHARACTER_ICE_CLIMBERS
 bne City
 farcall IcAreaReset,jmp
City:farcall RcReset,jmp
Sunny:farcall SunnyReset,jmp
.endproc

.macro GmExtraNrBody
.scope GmOwnedHelper18
::GmLegacyPostBG:
.scope GmLegacyPostBGBody
 farcall HuLegacyPostBG,jmp
::GmNrFinish:
 sta NextBank_SMC+1
 pla
 tay
 plp
 jmp FarCallCommon+3
::GmDeathPrepare:
 lda #$d0
 sta GmRam0090
 lda #$15
 sta GmRam0300
 rts
::GmStatusGate:
 php
 sta SafecallA_SMC+1
 tya
 pha
 ldy #15
 jmp GmOnlyCommon

.endscope
.endscope
.endmacro
GmNrRoute NrBody,GmIceBody,RcBodyContact,SunnyBody,JnBodyDispatch,GmBodyPolicy,93,GmExtraNrBody,49,0

; Terrain admission also validates the explicit ID argument supplied by SMB.
.macro GmExtraNrAdder
.scope GmOwnedHelper37
::GmOnlyLo:
 .byte <GmConstruct,<GmHostFullBox,<GmHostPortrait,<GmMenuName,<GmResetOwn,<GmPrepareOwn,<GmNativeNoop,<GmNativeNoop,<GmMatureOwn,<GmHostPickup,<GmFullPower,<GmForcePalette,<GmHostBounce,<GmHeadWithinOwn,<GmUi,<GmStatusNameTail,<BmFresh,<MaaBox,<KmPortrait,<MaaQueueName,<JnResetDispatch,<JnPrepareDispatch,<JnRiseDispatch,<JnPrivateDispatch,<JnCollisionDispatch,<JnPickupDispatch,<CheatsFullPower,<BmColors,<X5StompDispatch,<Z2HeadWithinTerrain,<VvUiDispatch,<JnStatusName

.endscope
.endmacro
GmNrRoute NrAdder,IcAdder,RcCollisionAdder,SunnyAdder,RlAdderDispatch,GmAdder,99,GmExtraNrAdder,32,1
.macro GmExtraNrBox
.scope GmOwnedHelper38
::GmOnlyHi:
 .byte >GmConstruct,>GmHostFullBox,>GmHostPortrait,>GmMenuName,>GmResetOwn,>GmPrepareOwn,>GmNativeNoop,>GmNativeNoop,>GmMatureOwn,>GmHostPickup,>GmFullPower,>GmForcePalette,>GmHostBounce,>GmHeadWithinOwn,>GmUi,>GmStatusNameTail,>BmFresh,>MaaBox,>KmPortrait,>MaaQueueName,>JnResetDispatch,>JnPrepareDispatch,>JnRiseDispatch,>JnPrivateDispatch,>JnCollisionDispatch,>JnPickupDispatch,>CheatsFullPower,>BmColors,>X5StompDispatch,>Z2HeadWithinTerrain,>VvUiDispatch,>JnStatusName

.endscope
.endmacro
GmNrRoute NrBox,IcBox,RcCollisionBox,SunnyBox,RlBoxDispatch,GmAdder,99,GmExtraNrBox,32,1

.proc NrPrepare
 php
 pha
 lda SelectedCharacter
 bne :+
 lda MarioVariant
 cmp #4
 beq Own
:
 lda SelectedCharacter
 cmp #CHARACTER_ICE_CLIMBERS
 beq Own
 cmp #CHARACTER_RIVER_CITY
 beq Own
 cmp #CHARACTER_SUNNY
 beq Own
 pla
 plp
 jmp GmPrepareGate
 .res 15,$ea
Own:
 lda SelectedCharacter
 sta InvPickupOwner,x
 lda #$fc
 sta InvPickup,x
 lda #0
 sta InvRisePhase,x
 sta InvPickupSaveLo,x
 sta InvPickupSaveHi,x
 pla
 plp
 rts
.endproc
.proc NrRise
 php
 pha
 lda SelectedCharacter
 bne :+
 lda MarioVariant
 cmp #4
 beq Native
:
 lda SelectedCharacter
 cmp #CHARACTER_ICE_CLIMBERS
 beq Native
 cmp #CHARACTER_RIVER_CITY
 beq Native
 cmp #CHARACTER_SUNNY
 beq Native
 pla
 plp
 jmp GmRiseGate
 .res 15,$ea
Native:
 pla
 plp
 clc                         ; let SMB's visible emergence move the actor
 rts
.endproc
.proc NrPrivate
 php
 pha
 lda SelectedCharacter
 bne :+
 lda MarioVariant
 cmp #4
 beq Native
:
 lda SelectedCharacter
 cmp #CHARACTER_ICE_CLIMBERS
 beq Native
 cmp #CHARACTER_RIVER_CITY
 beq Native
 cmp #CHARACTER_SUNNY
 beq Native
 pla
 plp
 jmp GmPrivateGate
 .res 15,$ea
Native:
 pla
 plp
 clc                         ; ordinary Mushroom/Flower art
 rts
.endproc
.proc NrPickupCollision
 php
 pha
 lda SelectedCharacter
 bne :+
 lda MarioVariant
 cmp #4
 beq Own
:
 lda SelectedCharacter
 cmp #CHARACTER_ICE_CLIMBERS
 beq Own
 cmp #CHARACTER_RIVER_CITY
 beq Own
 cmp #CHARACTER_SUNNY
 beq Own
 pla
 plp
 jmp GmMatureGate
 .res 15,$ea
Own:
 pla
 plp
 lda PowerUpType,x
 cmp #2
 bcs Allowed
 lda Enemy_State,x
 bmi Allowed                 ; no pickup while still inside its block
 clc
 rts
Allowed:sec
 rts
.endproc
.proc NrPickup
 NrCeleste CmHostPickup
 lda SelectedCharacter
 cmp #CHARACTER_SUNNY
 beq Sunny
 cmp #CHARACTER_ICE_CLIMBERS
 beq Ice
 cmp #CHARACTER_RIVER_CITY
 beq City
 jmp GmPickupGate
 .res 15,$ea
Ice:
 phx
 lda PowerUpType,x
 farcall IcPickup
 plx
 bcc Native
 phx
 jsr EraseEnemyObject
 plx
 lda #6
 jmp SetupFloateyNumber
City:
 farcall RcPickup
 bcs Done
Native:
 farcall MarioSourcePowerupCollision,jmp ; native Star and extra-life handling
Done:rts
Sunny:
 farcall SunnyCollectIntegrated,jmp
.endproc
.proc NrUi
 NrCeleste CmHostUi
 php
 pha
 lda SelectedCharacter
 cmp #CHARACTER_SUNNY
 beq Sunny
 cmp #CHARACTER_ICE_CLIMBERS
 beq Ice
 cmp #CHARACTER_RIVER_CITY
 beq City
 pla
 plp
 jmp GmUiGate
 .res 15,$ea
Ice:
 pla
 plp
 farcall X5NativeInventoryUiLeaf,jmp
City:
 pla
 plp
 farcall X5NativeInventoryUiLeaf
 farcall RcUi,jmp
Sunny:
 pla
 plp
 farcall SunnyUi,jmp
.endproc
.proc NrStatusName
 NrCeleste CmHostStatusName
 php
 pha
 lda SelectedCharacter
 cmp #CHARACTER_SUNNY
 beq Sunny
 cmp #CHARACTER_ICE_CLIMBERS
 beq Ice
 cmp #CHARACTER_RIVER_CITY
 beq City
 pla
 plp
 jmp GmStatusGate
 .res 15,$ea
City:
 pla
 plp
 cmp #0
 bne Done
 farcall RcStatusName,jmp
Ice:
 pla
 plp
 cmp #0
 bne Done
 phy
 ldy #6
 lda IcVariant
 beq Popo
Nana:
 lda NanaName,y
 sta VRAM_Buffer1+11,y
 dey
 bpl Nana
 jmp NameDone
Popo:
 lda PopoName,y
 sta VRAM_Buffer1+11,y
 dey
 bpl Popo
NameDone:
 ply
 lda #0
Done:rts
PopoName:.byte "POPO   "
NanaName:.byte "NANA   "
Sunny:
 pla
 plp
 farcall SunnyStatusName,jmp
.endproc
.proc NrGlobalInit
 farcall KbGlobalInit
 lda #0
 sta RcVariant
 sta MacVariant
 sta RcMarker                 ; initialize lazily, preserve selected owner's RAM
 sta CmMarker
 sta CmActive
 farcall IcGlobalInit
 farcall QwBoot,jmp
.endproc
.proc NrFreshGameInit
 farcall KbFreshGameInit
 lda IcVariant               ; chosen alternate survives pressing Start
 pha
 farcall IcGlobalInit
 pla
 sta IcVariant
 lda #0
 sta RcMarker
 farcall QwBoot
 jmp GmFreshGate
::GmStatusNameTail:
 ; Original15B setup after redundant SafecallA store, sameA124 map.
 lda #<HuGmStatusName
 sta FarcallJmpTarget_SMC+1
 lda #>HuGmStatusName
 sta FarcallJmpTarget_SMC+2
 lda #.lobyte(.bank(HuGmStatusName)|$80)
 jmp FarCallCommon
.endproc
.proc NrFullPower
 lda SelectedCharacter
 cmp #CHARACTER_SUNNY
 beq Sunny
 cmp #CHARACTER_ICE_CLIMBERS
 beq Ice
 cmp #CHARACTER_RIVER_CITY
 beq City
 jmp GmFullPowerGate
 .res 15,$ea
Ice:farcall IcFullPower,jmp
City:
 farcall RcEnsure
 ldx RcVariant
 lda #64
 sta RcHealth,x
 lda #2
 sta RcTier,x
 sta PlayerStatus
 lda #1
 sta RcHudDirty
 rts
Sunny:
 farcall SunnyFullPower,jmp
.endproc
.macro GmExtraNrSide
.endmacro
GmNrRoute NrSide,GmNativeSide,GmNativeSide,GmNativeSide,Z2SideAdmission,GmSide,42,GmExtraNrSide,0,0
.proc NrColors
 NrCeleste CmHostColors
 php
 pha
 lda SelectedCharacter
 cmp #CHARACTER_ICE_CLIMBERS
 beq Own
 cmp #CHARACTER_RIVER_CITY
 beq Own
 cmp #CHARACTER_SUNNY
 beq Own
 pla
 plp
 jmp GmColorsGate
 .res 15,$ea
Own:
 pla
 plp
 farcall QueueMegaManFacePalette
 farcall QueueGuestWeaponPalette
 farcall X5QueueAreaBackdrop
 lda SelectedCharacter
 cmp #CHARACTER_SUNNY
 beq Sunny
 cmp #CHARACTER_ICE_CLIMBERS
 bne City
 farcall IcForcePalette,jmp
City:farcall RcColors,jmp
Sunny:farcall SunnyColorsIntegrated,jmp
.endproc
.proc NrMenuToggle
 lda CrossoverMenuIndex
 bne NrOtherToggle
 lda CrossoverMenuPressed
 and #Select_Button
 beq NrOtherToggle
 jsr KmNextVariant
 jmp NrMarioPublish
 .res 7,$ea
NrToLuigi: .res 4,$ea
NrToCeleste: .res 2,$ea
NrMarioPublish:sta MarioVariant
 sec
 rts
NrOtherToggle:
 lda CrossoverMenuPressed
 and #Select_Button
 beq No
 lda SelectedCharacter
 cmp #CHARACTER_ICE_CLIMBERS
 beq Ice
 cmp #15
 beq Mac
 cmp #CHARACTER_RIVER_CITY
 bne No
 lda RcVariant
 eor #1
 sta RcVariant
 lda #0
 sta RcPalette
 sec
 rts
Mac:
 inc MacVariant
 lda MacVariant
 cmp #MAC_ROSTER_VARIANTS
 bcc MacReady
 lda #0
 sta MacVariant
MacReady:
 lda #0
 sta LmPalette
 sec
 rts
Ice:
 lda IcVariant
 eor #1
 sta IcVariant
 lda #$ff
 sta IcPaletteAck
 sec
 rts
No:clc
 rts
.endproc
.proc NrMenuCharacter
 jmp NrMenuAltTail
 nop
.endproc
.proc NrWorldPaletteIndex
 php
 pha
 lda SelectedCharacter
 cmp #CHARACTER_ICE_CLIMBERS
 beq Native
 cmp #CHARACTER_RIVER_CITY
 beq Native
 cmp #CHARACTER_SUNNY
 beq Native
 pla
 plp
 farcall HuWorldPalette,jmp
Native:
 pla
 plp
 lda AreaType
 asl
 sta R0
 asl
 clc
 adc R0
 adc #6
 tay
 rts
.endproc
.proc NrMenuNavigate
 lda CrossoverMenuPressed
 and #Left_Dir|Right_Dir|Up_Dir|Down_Dir
 beq No
 lda #$24
 jsr NrQueueCursor
 ldx CrossoverMenuIndex
 lda CrossoverMenuPressed
 and #Up_Dir
 beq Down
 lda X5MenuUp,x
 rts
Down:
 lda CrossoverMenuPressed
 and #Down_Dir
 beq Left
 lda X5MenuDown,x
 rts
Left:
 lda CrossoverMenuPressed
 and #Left_Dir
 beq Right
 lda X5MenuLeft,x
 rts
Right:
 lda X5MenuRight,x
 rts
No:lda #$ff
 rts
.endproc
.proc NrQueueCursor
 pha
 ldy CrossoverMenuIndex
 lda X5MenuCursorLo,y
 ldx VRAM_Buffer1_Offset
 sta VRAM_Buffer1+1,x
 lda X5MenuCursorHi,y
 sta VRAM_Buffer1,x
 lda #1
 sta VRAM_Buffer1+2,x
 pla
 sta VRAM_Buffer1+3,x
 txa
 clc
 adc #4
 tax
 stx VRAM_Buffer1_Offset
 lda #0
 sta VRAM_Buffer1,x
 rts
.endproc
.proc NrEnemyMovement
 lda SelectedCharacter
 cmp #CHARACTER_RIVER_CITY
 bne LegacyStop
 phx
 farcall RcEnemyControl
 plx
 bcs Done
 farcall NrNativeEnemyMovement,jmp
LegacyStop:
 farcall SamusLegacyMovementStopped
 bcc Native
Done:rts
Native:
 farcall NrNativeEnemyMovement,jmp
.endproc
.proc NrNativePowerupDispatch
 php
 pha
 lda SelectedCharacter
 cmp #CHARACTER_SUNNY
 beq Sunny
 pla
 plp
 farcall HuPowerup,jmp
Sunny:pla
 plp
 farcall SunnyPowerupUpdate,jmp
.endproc
.proc NrObjectWeaponTail
 php
 pha
 lda SelectedCharacter
 cmp #CHARACTER_SUNNY
 beq Sunny
 pla
 plp
 farcall HuWeaponTail
 farcall ProcFireball_Bubble::ProcAirBubbles,jmp
Sunny:pla
 plp
 farcall SunnyNativeWeaponTail,jmp
.endproc
.segment "NEW_ROSTER_NAMES"
.proc NrQueueSelectName
 farcall DpAdmissionMenuName,jmp
 nop
CmOtherName:
::DpAdmissionNameResume:
.if ::ENABLE_MMC5_EXPANDED
  cmp #CHARACTER_SUNNY
  bne SunnyOtherName
  lda #43
  jmp NameIndex
SunnyOtherName:
  cmp #CHARACTER_ICE_CLIMBERS
  bne NrNotIceName
  lda IcVariant
  clc
  adc #37
  jmp NameIndex
NrNotIceName:
  cmp #CHARACTER_RIVER_CITY
  bne NrNotCityName
  lda RcVariant
  clc
  adc #39
  jmp NameIndex
NrNotCityName:
  cmp #CHARACTER_BASS
  bne RlOtherName
  lda RlVariant
  beq RlOriginalName
  lda #36
  jmp NameIndex
RlOriginalName:lda #CHARACTER_BASS
RlOtherName:
  cmp #15
  bne LmOtherName
  lda MacVariant
  beq LmDefaultName
  clc
  adc #40
  jmp NameIndex
LmDefaultName:
  lda #30
  jmp NameIndex
LmOtherName:
  cmp #CHARACTER_MIKE
  bne JnOtherName
  lda #31
  jmp NameIndex
JnOtherName:
  cmp #17
  bne M3OtherName
  jmp MbMenuNameSelect
  .res 6,$ea
M3OtherName:
  cmp #18
  bne :+
  lda VvVariant
  beq PnDefaultName
  clc
  adc #32
  jmp NameIndex
PnDefaultName:
  lda #24
  jmp NameIndex
:
  cmp #CHARACTER_TMNT
  bne :+
  lda TnVariant
  clc
  adc #20
  jmp NameIndex
:
  cmp #14
  bne CdOtherName
  lda #18
  clc
  adc CdVariant
  jmp NameIndex
CdOtherName:
  cmp #CHARACTER_KIRBY
  bne :+
  lda KbVariant
  beq KirbyName
  lda #32
  jmp NameIndex
KirbyName:
  lda #17
  jmp NameIndex
:
.endif
 .if ::ENABLE_MMC5_EXPANDED
  cmp #CHARACTER_MEGAMAN
  bne ProtoOriginalName
  ldx ProtoVariant
  beq NameIndex
  lda #14
  bne NameIndex
ProtoOriginalName:
  cmp #CHARACTER_LINK
  bne Z2OriginalName
  ldx Z2Variant
  beq NameIndex
  lda #16
  bne NameIndex
Z2OriginalName:
  cmp #CHARACTER_SIMON
  bne Cv3OriginalName
  ldx Cv3Variant
  beq NameIndex
  cpx #4
  bcs Cv3OriginalName
  txa
  clc
  adc #24
  bne NameIndex
Cv3OriginalName:
  lda SelectedCharacter
  cmp #CHARACTER_SCROOGE
  bne DwOriginalName
  ldx DarkwingVariant
  beq NameIndex
  lda #15
  bne NameIndex
DwOriginalName:
 .endif
  cmp #CHARACTER_BILL
  bne NameIndex
  ldx BillVariant
  beq NameIndex
  lda #CHARACTER_COUNT
NameIndex:
.if ::ENABLE_MMC5_EXPANDED
  ; Names beyond15 require the high byte of index*16. R2/R3 are not the
  ; VRAM byte counterR0; old indices retain their exact source bytes.
  pha
  lda #<Names
  sta R2
  lda #>Names
  sta R3
  pla
NamePage:
  cmp #16
  bcc :+
  inc R3
  sec
  sbc #16
  bcs NamePage
:
.endif
  asl
  asl
  asl
  asl
  tay
  ldx VRAM_Buffer1_Offset
  lda #$23
  sta VRAM_Buffer1,x
.if ::ENABLE_MMC5_EXPANDED
  lda #<X5MenuNameAddress
.else
  lda #$08
.endif
  sta VRAM_Buffer1+1,x
  lda #16
  sta VRAM_Buffer1+2,x
  sta R0
Copy:
.if ::ENABLE_MMC5_EXPANDED
  lda (R2),y
.else
  lda Names,y
.endif
  sta VRAM_Buffer1+3,x
  inx
  iny
  dec R0
  bne Copy
  txa
  clc
  adc #3
  tax
  stx VRAM_Buffer1_Offset
  lda #0
  sta VRAM_Buffer1,x
  rts
Names:
  .byte "     MARIO      ", "    MEGA MAN    ", "   SAMUS ARAN   "
  .byte "   BILL RIZER   ", "      LINK      ", " SIMON BELMONT  "
  .byte "      PIT       ", "     RYGAR      ", "     LUIGI      "
  .byte "      BASS      ", " RYU HAYABUSA   ", "   SOPHIA III   "
  .byte "SCROOGE MCDUCK  ", "   LANCE BEAN   "
 .if ::ENABLE_MMC5_EXPANDED
  .byte "   PROTO MAN    ", " DARKWING DUCK  ", " ZELDA II LINK  ", "     KIRBY      ","     CHIP       ","     DALE       ","   LEONARDO     ","   RAPHAEL      "," MICHELANGELO   ","   DONATELLO    ","   VIC VIPER    ","     GRANT      ","     SYPHA      ","    ALUCARD     ","   SMB3 MARIO   ","   SMB3 LUIGI   ","   LITTLE MAC   ","   MIKE JONES   "
  .byte "  META KNIGHT   "
  .byte "    OCTOPUS     ","    TWINBEE     ","    PENTAROU    "
  .byte "     ROLL       "
  .byte "      POPO      ","      NANA      "
  .byte "      ALEX      ","      RYAN      "
  .byte "   DOC LOUIS    ","   MIKE TYSON   ","     SUNNY      "," CELESTE MARIO  "
 .endif
.endproc
.segment "NEW_ROSTER_GATE"
.assert * <= $ae00,lderror,"Roster dispatcher overlaps Rogue auxiliary reservation"
.popseg

.assert .bank(RlGraphicsDispatch)=.bank(RlDrawDispatch),lderror,"Thomas source bank-table alias"
.assert .bank(JnPortraitDispatch)=.bank(JnMovementDispatch),lderror,"Thomas source bank-table alias"
.assert .bank(IcGraphics)=.bank(IcDraw),lderror,"Thomas genuine graphics/draw bank alias"
.assert .bank(RcGraphics)=.bank(RcDraw),lderror,"Thomas genuine graphics/draw bank alias"
.assert .bank(SunnyGraphicsIntegrated)=.bank(SunnyDraw),lderror,"Thomas genuine graphics/draw bank alias"
.assert .bank(GmHostGraphics)=.bank(GmDraw),lderror,"Thomas genuine graphics/draw bank alias"
.assert .bank(IcPortrait)=.bank(IcMovement),lderror,"Thomas genuine portrait/movement bank alias"
.assert .bank(RcPortrait)=.bank(RcMovement),lderror,"Thomas genuine portrait/movement bank alias"
.assert .bank(SunnyPortrait)=.bank(SunnyNativeMovement),lderror,"Thomas genuine portrait/movement bank alias"
.assert .bank(GmPortraitPrepare)=.bank(GmHostMovement),lderror,"Thomas genuine portrait/movement bank alias"
