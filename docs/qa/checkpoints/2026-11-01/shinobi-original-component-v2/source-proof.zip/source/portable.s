.setcpu "6502"
.macpack longbranch
ShState=$6000
ShScratch=$00
ShExternal_8EC1=$8ec1
ShExternal_8EED=$8eed
ShExternal_94FF=$94ff
ShExternal_CADC=$cadc
ShExternal_D1BC=$d1bc
ShExternal_D213=$d213
ShExternal_D225=$d225
ShExternal_D25F=$d25f
ShExternal_D2A4=$d2a4
ShExternal_D3AD=$d3ad
ShExternal_DAF7=$daf7
ShExternal_E2DD=$e2dd
ShExternal_FAAF=$faaf
ShExternal_FB33=$fb33
ShExternal_FB3F=$fb3f
ShExternal_FBDB=$fbdb
ShExternal_FBFF=$fbff
ShExternal_FC17=$fc17
ShExternal_FFD0=$ffd0
.include "portable.inc"
