# Metal Storm host-contract component v4

Original actor6323B rebased to A3:A000/C2:C000 and foreground03/04;
323B real host step/input/240Y/delta adapters;45B cold raw35/menu-bit leaves;
1002B exact compact original-body metadata. Kernel6759B before cookie.

480 original/rebased/typed-step comparisons (1440 executions), both gravity
directions, all256 inputs,65536 signedY cases,896 resolve/start cases each,
480 duplicate/pause cases each and208 original graphics packet/order cases
pass. Current NES input is queued AFTER the source step, preserving original
one-update polling latency. Original bound07E4 is2020, not just low byte228.

No native admission. External tile/scene/platform/object/audio effects are
recorded/replayed, not implemented host callbacks. Constructor, source shots,
upgrades/health, native cache/header/ISR/SMC/Main stack, palette/OAM and stage
routes remain. The14 proposed CHR pages and extra resident ROM have NO grant.

See tools/reference/metal_storm_host_contract_1101_v4.md and proof/host-contract.json.
The original semantic source stays in the already frozen v3 packet; compiled
lab objects remain external at build/metal-storm-host-contract-1101-v4.
No complete PRG, ROM, code image, object, debug or symbol output is published.
