.import ThServiceVeneers,ThMenuResolve,ThSceneInit
.export MovePlayerVertically,VerticalForce,ThKbNativeFallback
.import BwScene,BwMenuResolve
.export FmGroups,CmHostFresh,FmQueueName,JnResetDispatch,DrawMetasprite,WriteGameText
.export AreaType,SelectedCharacter,OperMode,OperMode_Task,FamilyMainCommit,GamePauseStatus,TimerControl,FmAlts,CurrentPlayer,NumberofLives,PlayerStatus,PlayerSize,CrouchingFlag,PlayerFacingDir,Player_XSpeedAbsolute,Player_X_Scroll,Player_Y_MoveForce,Player_Rel_XPos,Player_Rel_YPos,InjuryTimer,GuestBodyStompAllowed,GuestBodyNoStomp,GuestPowerupOld,GuestPowerupDisplay,GuestPowerupTarget,GuestPowerupUpdate,MarioSourceBeginFreeze,MarioSourcePowerupCollision,Square1SoundQueue,Square2SoundQueue,NoiseSoundQueue,MmDeathFlag,KillPlayer,EraseEnemyObject,SetupFloateyNumber,NativePlayerDeath,BlockBufferColli_Head,BlockBufferColli_Side,BoundingBox_UL_Corner,BoundingBox_LR_Corner,PowerUpType,ScreenLeft_X_Pos,ScreenLeft_PageLoc,SecondaryHardMode,PseudoRandomBitReg,HandleEnemyFBallCol,MetaspriteRenderLoop,ObjectMetasprite,Player_SprAttrib,SmPosePtr,SmChrBank,CurrentCHRBank,X5ChrMode,CurrentBankC,X5SetPhysicalChr,SafecallA_SMC,FarcallJmpTarget_SMC,FarCallCommon,METASPRITE_SAMUS_BODY,BlockBufferAddr,Block_Buffer_1,MTileAttribute,StarInvincibleTimer,Player_X_Position,Player_PageLoc,Player_Y_Position,Player_Y_HighPos,Player_X_Speed,Player_Y_Speed,Player_State,SavedJoypadBits,GameEngineSubroutine,FrameCounter,Enemy_Flag,Enemy_State,Enemy_ID,Enemy_X_Position,Enemy_PageLoc,Enemy_Y_Position,Enemy_Y_HighPos,ObjectOffset,R0,R1,R2,R3,R4,R5,R6,R7
.export PlayerBGCollision
.import QwMovementGate,QwAdderGate,QwBoxProfileGate,QwHeadGate,QwMenuResolve
.export RlMovementDispatch,HotCollisionAdder,HotCollisionBox,TnFastHeadGate
.import QwBoot,QwSceneInit
.import FwNativeEnemyInit
.export RgEnemyStun,LsrFrozenPose,AvFrozen,AvFrozenHi,GuestBodyPrev,GuestBodyNow
.import FwSvcWall
.export LmWallGate
.import ArGenFoot

; Single entrypoint that includes files to make building this easier


.macpack longbranch
.macpack generic

.linecont on
.feature force_range


.include "options.s"


.include "inc/nes2header.inc"

;--------------------------------
; NES2.0 header

.if MAPPER_MMC5
nes2mapper 5 ; mmc5
.elseif MAPPER_MMC3
nes2mapper 4 ; mmc3
.endif
.if ::MAPPER_MMC5 .and ::ENABLE_MMC5_EXPANDED
 .assert ::MAPPER_MMC5 .and (.not ::MAPPER_MMC3), error, "Expanded cartridge is MMC5-only"
 .assert ::ENABLE_MMC5_EXPANDED, error, "Separate expanded build flag required"
nes2prg $100000
nes2chr $100000
.else
nes2prg $80000
nes2chr $40000
.endif
.if ::ENABLE_CROSSOVER
nes2wram $8000
.else
nes2bram $2000
.endif
nes2mirror 'V'
nes2tv 'N'
nes2end



_COMMON_DEFINE_SEGMENTS = 1
.include "inc/common.inc"

.include "inc/charmap.inc"
.include "inc/constants.inc"
.if ::ENABLE_MMC5_EXPANDED
ProtoVariant=$73dd
ProtoAudioState=$73de
.export ProtoVariant,ProtoAudioState
DarkwingVariant=$73df
DwHealth=$73ef
DwGas=$73f0
DwAdaptor=$73f1
DwMode=$73f2
DwAnim=$73f3
DwPhase=$73f4
DwAnimTick=$73f5
DwPrevious=$73f6
DwHang=$73f7
.export DarkwingVariant,DwHealth,DwGas,DwAdaptor,DwMode,DwAnim,DwPhase,DwAnimTick,DwPrevious,DwHang

.endif
.include "memory.s"
.if ::ENABLE_MMC5_EXPANDED
.include "kirby_state.inc"
.include "cv3_state.inc"
.include "little_mac_state.inc"
.include "tmnt_state.inc"
.include "ice_climbers_state.inc"
.include "sunny_state.inc"
.endif

.if MAPPER_MMC5
.include "mmc5.s"
.endif
.if MAPPER_MMC3
.include "mmc3.s"
.endif

.include "metasprite_engine.s"
.include "metasprite.s"
.if ::ENABLE_CROSSOVER
.include "guest_publish_chr.inc"
.endif

.include "common.s"
.include "collision.s"
.include "level_tiles.s"
.include "reset.s"
.include "game.s"

.include "player.s"
.if ::ENABLE_CROSSOVER
.include "characters.s"
.include "megaman_weapons.s"
.include "megaman_physics.s"
.include "megaman_environment.s"
.include "megaman_palette.s"
.include "megaman_death.s"
.include "megaman_audio.s"
.include "samus.s"
.include "samus_weapons.s"
.include "samus_audio.s"
.include "guest_powerups.s"
.include "roster.s"
.include "roster_weapons.s"
.include "roster_audio.s"
.include "guest_audio.s"
.include "water.s"
.include "character_select.s"
.include "expanded.s"
.include "pit_collision.s"
.include "guest_body_contact.s"
.include "guest_injury.s"
.include "megaman_injury.s"
.include "lsr_injury.s"
.include "ordinary_body_layout.s"
.include "luigi_native.s"
.include "expanded_weapons.s"
.include "source_motion.s"
.include "ryu_wall.s"
.include "source_weapons.s"
.include "link_fragments.s"
.include "ryu_projectile_motion.s"
.include "expanded_audio.s"
.include "bass_audio.s"
.include "inventory.s"
.include "special_weapons.s"
.include "inventory_drops.s"
.include "world_firebars.s"
.include "lance_metasprites.inc"
.if MAPPER_MMC5
.include "chr_map_mmc5.inc"
.else
.include "chr_map_mmc3.inc"
.endif
.endif
.include "object.s"
.if ::ENABLE_CROSSOVER
.include "enemy_offscreen_fast.s"
.endif
.include "screen_render.s"
.include "sprite_render.s"


.segment "AUDIO"

.include "music_drivers/audio.s"


; .segment "FIXED"

; FarcallTableLo:
; .repeat ::_FARCALL_COUNT, I
;   .byte .ident(.sprintf("_LEFT_%d_LO", I))
; .endrepeat
; FarcallTableHi:
; .repeat ::_FARCALL_COUNT, I
;   .byte .ident(.sprintf("METASPRITE_LEFT_%d_LO", I))
; .endrepeat
; FarcallTableBank:
; .repeat ::_FARCALL_COUNT, I
;   .byte .ident(.sprintf("METASPRITE_LEFT_%d_LO", I))
; .endrepeat

.if ::ENABLE_CROSSOVER
.include "player_outlines.s"
.include "scrooge.s"
.include "remaining_weapons.s"
.include "lsr_effects.s"
.include "remaining_audio.s"
.include "samus_collision_ram.s"
.endif
.segment "CHR"
CrossoverChrStart:
.if ::ENABLE_CROSSOVER
.if ::MAPPER_MMC5
.if ::ENABLE_MMC5_EXPANDED
.incbin "C:/Users/kando/Documents/ChatGPT/SMB Crossover/build/cf-cold-warm-source-v3/joint/packed.chr"
.else
.incbin "chr/characters/packed-mmc5.chr"
.endif
.else
.incbin "chr/characters/packed-mmc3.chr"
.endif
.else

; Water = 0
; Ground = 1
; UnderGround = 2
; Castle = 3

.if MAPPER_MMC5
.incbin "chr/mmc5/bg_water.chr"
.incbin "chr/mmc5/bg_ground.chr"
.incbin "chr/mmc5/bg_underground.chr"
.incbin "chr/mmc5/bg_castle.chr"

.incbin "chr/mmc5/sprites_mario.chr"
.incbin "chr/mmc5/sprites_misc.chr"
.incbin "chr/mmc5/sprites_enemies.chr"

.else

.incbin "chr/mmc5/bg_water.chr"
.incbin "chr/mmc5/bg_ground.chr"
.incbin "chr/mmc5/bg_underground.chr"
.incbin "chr/mmc5/bg_castle.chr"

.incbin "chr/mmc3/sprites_mario.chr"
.incbin "chr/mmc3/sprites_misc.chr"

.incbin "chr/mmc3/sprites_water.chr"
.incbin "chr/mmc3/sprites_overworld.chr"
.incbin "chr/mmc3/sprites_underground.chr"
.incbin "chr/mmc3/sprites_castle.chr"

.endif
.endif ; ENABLE_CROSSOVER packed CHR / original baseline layout

.pushseg
.segment "TITLE"
TitleScreenData:
.incbin "chr/raw/titlescreen.bin"
.byte $00 ; add terminator byte in case the data editor didn't
.popseg

; Append after every existing METASPRITE contributor to preserve all old addresses.
.if ::ENABLE_CROSSOVER && ::MAPPER_MMC5
.include "native_goomba_draw.s"
.endif

; Append after all existing OBJECT contributions; old native labels stay put.
.if ::ENABLE_CROSSOVER && ::MAPPER_MMC5
.include "ground_goomba_terrain.s"
.endif

; Append after all SPECIAL_ROSTER contributors; preserve every old code PC.
.if ::ENABLE_CROSSOVER
.include "ryu_grapple_adjust.s"
.endif

; Append after all old SPECIAL_ROSTER bytes; old PCs stay unchanged.
.if ::ENABLE_CROSSOVER
.include "ryu_wall_coin_filter.s"
.endif

; New resident gap tails follow every pre-existing contributor.
.if ::ENABLE_CROSSOVER
.include "samus_crouch_collision.s"
.endif

; Append after every old SRAM/code contributor; baseline remains unchanged.
.if ::ENABLE_CROSSOVER
.include "ryu_platform.s"
.endif

; Source normal-air/platform admission appends after every old ROSTER PC.
.if ::ENABLE_CROSSOVER
.include "ryu_platform_source_overlap.s"
.endif

; Append the preference after all old SRAM and the tiny resident policy leaf.
.if ::ENABLE_CROSSOVER
.include "menu_behavior.s"
.endif

; Private source-head admission/foot tail relocation, after all old ROSTER PCs.
.if ::ENABLE_CROSSOVER
.include "guest_foot_side.s"
.include "ryu_source_head.s"
.include "easy_link_head_response.s"
.include "easy_link_firebar.s"
.endif

; Easy damage lifecycle appended after all pre-existing RAM/code.
.if ::ENABLE_CROSSOVER
.include "guest_legacy_injury.s"
.endif

.if ::ENABLE_CROSSOVER
.include "guest_source_stomp.s"
.endif

.if ::ENABLE_CROSSOVER
.include "easy_lsr.s"
.include "easy_link_order.s"
.include "easy_link_rect_animation.s"
.include "easy_link_animation_l.s"
.include "easy_link_death_l.s"
.endif

.if ::ENABLE_CROSSOVER
.include "mario_source.s"
.endif

.if ::ENABLE_CROSSOVER
.include "samus_legacy_bomb.s"
.endif

.if ::ENABLE_CROSSOVER
.include "ryu_source_body.s"
.include "bill_source_body.s"
.include "union_rare.s"
.endif

.if ::ENABLE_CROSSOVER
.include "ryu_corner_head.s"
.endif

.if ::ENABLE_CROSSOVER
.include "guest_victory_control.s"
.endif

.if ::ENABLE_CROSSOVER
.include "sophia_source_body.s"
.include "sophia_source_terrain.s"
.include "sophia_land_audio.s"
.endif

.if ::ENABLE_CROSSOVER
.include "samus_ice_hit.s"
.include "samus_freeze_render.s"
.endif

; Preserve all old contribution addresses; reuse the bank11 cold tail.
.if ::ENABLE_CROSSOVER
.include "samus_head_axis.s"
.endif

.if ::ENABLE_CROSSOVER
.include "score_popup.s"
.include "cheats.s"
.include "water_shield_enemies.s"
.include "hud_tail.s"
.include "world_sprite_palette.s"
.endif

.if ::ENABLE_CROSSOVER
.include "megaman_super_arm.s"
.include "megaman_rush.s"
.include "megaman_rush_land.s"
.endif

.if ::ENABLE_CROSSOVER
.include "ryu_side_overlap.s"
.include "level_variants.s"
.include "crossover_helpers.s"
.endif

.if ::MAPPER_MMC5 .and ::ENABLE_MMC5_EXPANDED
.include "mmc5_expanded.s"
.include "protoman.s"
.include "darkwing.s"
.include "x5_profiles.s"
.include "zelda2_link_state.inc"
.include "zelda2_native_aliases.inc"
.include "zelda2_link_rpg.s"
.include "zelda2_native_motion.inc"
.include "zelda2_link_art.inc"
.include "zelda2_link_render.s"
.include "zelda2_link_motion.s"
.include "zelda2_link_rewards.s"
.include "zelda2_link_ui.s"
.include "zelda2_pause_panel.s"
.include "zelda2_inventory_glue.s"
.include "zelda2_inventory_original.inc"
.include "zelda2_link_items.inc"
.include "zelda2_link_draw_world.s"
.include "zelda2_link_combat.s"
.include "zelda2_link_projectiles.s"
.include "zelda2_link_damage.s"
.include "zelda2_link_block.s"
.include "zelda2_link_drops.s"
.include "zelda2_link_menu.s"
.include "kirby.s"
.include "chip_dale_state.inc"
.include "chip_dale_native_motion.inc"
.include "chip_dale_art.inc"
.include "chip_dale_core.s"
.include "chip_dale_motion.s"
.include "chip_dale_render.s"
.include "chip_dale_boxes.s"
.include "chip_dale_health.s"
.include "chip_dale_dispatch.s"
.pushseg
.segment "CD_CHR"
.incbin "chr/characters/chip-dale.chr"
.popseg
.include "tmnt.s"
.include "mike_jones_state.inc"
.include "mike_jones.s"
.include "x5_palette.s"
.include "vic_viper.s"
.include "gradius_audio.s"
.include "mac_native_music.s"
.include "mike_native_music.s"
.include "cv3.s"
.include "little_mac.s"
.include "smb3_mario_state.inc"
.include "smb3_native_controller.inc"
.include "smb3_mario_art.inc"
.include "smb3_mario_core.s"
.include "smb3_mario_motion.s"
.include "smb3_mario_render.s"
.include "smb3_native_projectiles.inc"
.include "smb3_mario_world_art.inc"
.include "smb3_mario_pickups.s"
.include "smb3_mario_combat.s"
.include "smb3_mario_world.s"
.include "smb3_mario_dispatch.s"
.include "x5_bounce.s"
.include "x5_menu_ui.s"
.include "roll.s"
.include "zelda2_link_terrain.s"
.include "zelda2_link_platform.s"
.pushseg
.segment "M3_CHR"
.incbin "chr/characters/smb3-mario.chr"
.popseg
.pushseg
.segment "Z2_CHR"
.incbin "chr/characters/zelda2-link-body.chr"
.incbin "chr/characters/zelda2-link-items.chr"
.popseg
.include "mac_visible_side.s"
.include "protoman_hurt_end.s"
.include "inventory_legacy_leaf.s"
.include "hot_collision_gate.s"
.include "hot_render_gate.s"
.include "z2_platform_late_render.s"

.endif

; Append after every original INVENTORY contributor: no old label moves.
.if ::ENABLE_MMC5_EXPANDED
.pushseg
.segment "INVENTORY"
; Source2.02 destroys robot attacks only when the equipped weapon changes.
; Non-robot behavior is unchanged. No additional RAM or stack frame.
.proc InventorySelectionCommit
  cpx #CHARACTER_MEGAMAN
  beq Check
  cpx #CHARACTER_BASS
  bne Commit
Check:
  cmp InvSelected,x
  beq Done
Commit:
  sta InvSelected,x
  jmp InventoryClearActive
Done:
  rts
.endproc
.popseg
.endif

.if ::ENABLE_MMC5_EXPANDED
.include "ryu_primary_gate.s"
.include "sophia_missile_capacity.s"
.endif

.if ::ENABLE_MMC5_EXPANDED
.include "smb3_projectile_damage.s"
.endif

.if ::ENABLE_MMC5_EXPANDED
.include "mac_tmnt_lifecycle.s"
.endif

.if ::ENABLE_MMC5_EXPANDED
.include "cd_contact_y_window.s"
.endif

.if ::ENABLE_MMC5_EXPANDED
.include "cv3_source_audio.s"
.endif

.if ::ENABLE_MMC5_EXPANDED
.include "cv3_dmc_injury.s"
.endif

.if ::ENABLE_MMC5_EXPANDED .and ::MAPPER_MMC5
.include "cv3_dmc_complete.s"
.endif

.if ::ENABLE_MMC5_EXPANDED .and ::MAPPER_MMC5
.include "nmi_vram_fast.s"
.endif

.if ::ENABLE_MMC5_EXPANDED .and ::MAPPER_MMC5
.include "parodius_hud_queue.s"
.endif

.if ::ENABLE_MMC5_EXPANDED .and ::MAPPER_MMC5
.include "cv3_remaining_source_fx.s"
.endif

.if ::ENABLE_MMC5_EXPANDED .and ::MAPPER_MMC5
.include "luigi_source_profile.s"
.endif

.if ::ENABLE_MMC5_EXPANDED .and ::MAPPER_MMC5
.include "sound_test.s"
.endif

.if ::ENABLE_MMC5_EXPANDED .and ::MAPPER_MMC5
.include "cheats_four.s"
.endif

.if ::ENABLE_MMC5_EXPANDED
.include "bass_corner_profile.inc"
.endif

.if ::ENABLE_MMC5_EXPANDED .and ::MAPPER_MMC5
.include "proto_palette_ack.s"
.endif

.if ::ENABLE_MMC5_EXPANDED .and ::MAPPER_MMC5
.include "proto_palette_coalesce.s"
.endif

.if ::ENABLE_MMC5_EXPANDED .and ::MAPPER_MMC5
.include "samus_fixed_hud.s"
.endif

.if ::ENABLE_MMC5_EXPANDED
.include "cv3_life_gain.s"
.endif

.if ::ENABLE_MMC5_EXPANDED .and ::MAPPER_MMC5
.include "chip_hud_queue.s"
.endif

.if ::ENABLE_MMC5_EXPANDED .and ::MAPPER_MMC5
; New profiles are linked before they are exposed by the character selector.
.include "ice_climbers.s"
.include "river_city.s"
.include "mac_roster.s"
.include "mac_roster_adapter.s"
.include "new_roster_dispatch.s"
.include "sunny.s"
.include "sunny_integration.s"
.include "celeste_mario_host_entry.s"
.include "celeste_mario_host.s"
.endif


.if ::ENABLE_MMC5_EXPANDED
.pushseg
.segment "SUNNY_ART"
.res $500-(*-SunnyArtBegin),$ff
.popseg
.include "rogue-main-interface.inc"
; Typed Prepare row owns the Rogue constructor.
.endif

.if ::ENABLE_MMC5_EXPANDED
.export AvFrozen
.export AvFrozenHi
.export BoundBoxCtrlData
.export CrossoverBehaviorVersion
.export CurrentBankC
.export CurrentCHRBank
.export DrawAllMetasprites
.export EnemyFrameTimer
.export EnemyIntervalTimer
.export Enemy_BoundBoxCtrl
.export Enemy_Flag
.export Enemy_ID
.export Enemy_PageLoc
.export Enemy_State
.export Enemy_X_Position
.export Enemy_Y_HighPos
.export Enemy_Y_Position
.export FarCallCommon
.export FarcallJmpTarget_SMC
.export GameEngineSubroutine
.export GamePauseStatus
.export LsrEffectsAfterEnemies
.export LsrEffectsBeforeEnemies
.export LsrFrameTimer
.export LsrFrozenPose
.export LsrIntervalTimer
.export MetaspriteRenderLoop
.export MmEnemyFlash
.export MmEnemyHealthHi
.export MmEnemyHealthLo
.export ObjectOffset
.export Player_State
.export Player_Y_Speed
.export R3
.export R4
.export R5
.export R6
.export R7
.export RdAction
.export RdClock
.export RdFrozenSupport
.export RdGear
.export RdJumpDistance
.export RdRadiusX
.export RdRadiusY
.export RdRoomHi
.export RdSlot
.export RdVY
.export RdVariant
.export RdVerticalFraction
.export RdVerticalPhase
.export RdX
.export RdY
.export ReloadCHRBank
.export RgEnemyStun
.export RlDropDispatch
.export SafecallA_SMC
.export SamusDrawShots
.export SamusFreezeDrawAll
.export SamusWeapons
.export ScreenLeft_PageLoc
.export ScreenLeft_X_Pos
.export SelectedCharacter
.export ShellOrBlockDefeat
.export SmBombBlocksDone
.export X5ChrMode
.export X5StompDispatch
.export X5WideChrActive
.export Z2RemainingWeaponsGate
.import RdWxActorContact
.import RdWxActorEligible
.import RdWxActorTick
.import RdWxAfterEffects
.import RdWxAuxCodeEnd
.import RdWxAuxStart
.import RdWxBeforeEffects
.import RdWxBounce
.import RdWxCell
.import RdWxDraw
.import RdWxDrawAll
.import RdWxDropGate
.import RdWxMove
.import RdWxPreStep
.import RdWxRemainingGate
.import RdWxSamusGate
.import RdWxUpdateSlot
.import RdWxViewport

.endif

.if ::ENABLE_MMC5_EXPANDED
.export Enemy_SprAttrib
.export EraseEnemyObject
.export InvPickup
.export InvPickupOwner
.export InvRisePhase
.export LmPrivateGate
.export MarioSourcePowerupCollision
.export NrPickup
.export NrPickupCollision
.export PowerUpType
.export R0
.export R1
.export SetupFloateyNumber
.export Sfx_PowerUpGrab
.export Square2SoundQueue
.import RdItCollision
.import RdItEnd
.import RdItPickup
.import RdItPrivate
.import RdItStart
.import RdWpDrawItems
.import RdWpPublish
.import RdWpRender
.endif

.if ::ENABLE_MMC5_EXPANDED
.export BowserHitPoints
.export HammerEnemyOffset
.export HandleEnemyFBallCol
.export InvDropAge
.export InvDropAgeHi
.export InvDropKind
.export InvDropPage
.export InvDropSlot
.export InvDropX
.export InvDropY
.export Misc_Collision_Flag
.export Misc_PageLoc
.export Misc_State
.export Misc_X_Position
.export Misc_Y_HighPos
.export Player_PageLoc
.export Player_X_Position
.export Player_Y_HighPos
.export PseudoRandomBitReg
.export RdMaxMissiles
.export TimerControl
.export Z2UpdateDropsGate
.import RdHzAuxEnd
.import RdHzAuxStart
.import RdHzBossDefeat
.import RdHzDrawDrops
.import RdHzHammer
.import RdHzTerminal
.import RdHzUpdateDrops
.endif

.if ::ENABLE_MMC5_EXPANDED
.export AreaParserTaskNum
.export DisableScreenFlag
.export GuestPowerupActive
.export InvDirty
.export InvHudActive
.export InvHudAmmo
.export InvHudName
.export NrQueueSelectName
.export NrStatusName
.export OperMode
.export PlayerChangeSizeFlag
.export RdHealthHi
.export RdHealthLo
.export RdMissiles
.export ResetPalStar
.export ScrollThirtyTwo
.export SmFreezePalettePending
.export StarInvincibleTimer
.export VRAM_Buffer1
.export VRAM_Buffer1_Offset
.export VRAM_Buffer2
.export VRAM_Buffer2_Offset
.export VRAM_Buffer_AddrCtrl
.export X5MenuNameAddress
.import RdUiName
.import RdUiStatus
.import RdUiLateReset
.import RdUiEarly
.import RdUiStart
.import RdUiEnd
.endif

.if ::ENABLE_MMC5_EXPANDED
.import RdsBoot,RdsMainGate,RdsNmiGate
.endif

.if ::ENABLE_MMC5_EXPANDED
.import RdBackdropQueue
.export AreaType,BackgroundColorCtrl
.endif



.include "kamikaze_mario.s"
.if ::ENABLE_MMC5_EXPANDED
.include "kamikaze_mario_render_v2.inc"
.endif

.if ::ENABLE_MMC5_EXPANDED
.import GbPitPose,GbPitMenuNavigate,GbPitQueueName
.export GbPitCommon
GbPitCommon=ExpandedPose::Pointer
.export SelectedCharacter
.export PlayerFacingDir
.export RgPose
.export SmChrBank
.export PlayerChrBank
.export CurrentCHRBank
.export X5ChrMode
.export X5WideChrActive
.export ReloadCHRBank
.export SmPosePtr
.export XgPITBanks
.export XgPITRightLo
.export XgPITRightHi
.export XgPITLeftLo
.export XgPITLeftHi
.export CrossoverMenuPressed
.export CrossoverMenuIndex
.export NrMenuNavigate
.export KmQueueName
.export VRAM_Buffer1_Offset
.export VRAM_Buffer1
.export SafecallA_SMC
.export FarcallJmpTarget_SMC
.export FarCallCommon
.endif

.include "full_roster_menu.s"
.pushseg
.segment "FULL_ROSTER_PREVIEW_CHR"
.incbin "C:/Users/kando/Documents/ChatGPT/SMB Crossover/build/cf-cold-warm-source-v3/joint/pending-previews.chr"
.popseg

.include "donkey_kong_state.inc"
.include "gimmick_link_exports.inc"
.include "timer-fast.s"
.import HuPlayerSubsAdapter

.export SelectedCharacter
.export MarioVariant
.export LmBoundingBoxGate
.export PlayerBGCollision
.export SafecallA_SMC
.export FarcallJmpTarget_SMC
.export NextBank_SMC
.export A_B_Buttons
.export AreaAddrsLOffset
.export AreaParserTaskNum
.export AreaPointer
.export AreaType
.export BillBGEmptyEnvelope
.export BillHeadConsumer
.export BillHotProject
.export BlockBufferAddr
.export BlockBufferColli_Feet
.export BlockBufferColli_Head
.export BlockBufferColli_Side
.export BlockBuffer_Y_Adder
.export Block_Buffer_1
.export BoundingBoxCore
.export BoundingBox_LR_Corner
.export BoundingBox_UL_Corner
.export BoundingBox_UL_XPos
.export BoundingBox_UL_YPos
.exportzp Bowser
.export BowserHitPoints
.exportzp CHARACTER_BILL
.exportzp CHARACTER_MEGAMAN
.exportzp CHARACTER_RYU
.exportzp CHARACTER_SAMUS
.exportzp CHARACTER_SOPHIA
.export CheatInvincible
.export CheatsFullPower
.export CheatsGameRoutinesGate
.export CmHostAfterBG
.export CmHostFresh
.export CmHostResolveCharacter
.export CrossoverBehaviorVersion
.export CrossoverContinue
.export CrossoverMenuState
.export CrossoverSourceBodyDispatch
.export CrossoverVanillaMovement
.export CrouchingFlag
.export CurrentBank
.export CurrentBankC
.export CurrentCHRBank
.export CurrentOAMOffset
.export DigitModifier
.export DigitsMathRoutine
.export DisableCollisionDet
.export DisableScreenFlag
.export DisplayDigits
.export DpAdmissionNameResume
.export EnemyIntervalTimer
.export EnemyOffscrBitsMasked
.export Enemy_BoundBoxCtrl
.export Enemy_CollisionBits
.exportzp Enemy_Flag
.exportzp Enemy_ID
.exportzp Enemy_PageLoc
.export Enemy_Rel_XPos
.export Enemy_Rel_YPos
.exportzp Enemy_State
.exportzp Enemy_X_Position
.exportzp Enemy_Y_HighPos
.exportzp Enemy_Y_Position
.export EraseEnemyObject
.export EventMusicBuffer
.export EventMusicQueue
.export FarCallCommon
.export FarcallJmpTarget_SMC
.exportzp Fireball_PageLoc
.exportzp Fireball_X_Position
.exportzp Fireball_Y_HighPos
.exportzp Fireball_Y_Position
.export ForceInjury
.exportzp FrameCounter
.exportzp GameEngineSubroutine
.export GamePauseStatus
.export GameRoutines
.export GameTimerCtrlTimer
.export GameTimerDisplay
.export GameTimerExpiredFlag
.exportzp GameTimerLastIndex
.export GetBlockBufferAddr
.export GetPlayerOffscreenBits
.export GmFullBoxGate
.export GmLagAudioReturn
.export GmLegacyGuestAudio
.export GmLegacyVanillaAudio
.export GmMatureOwn
.export GmMenuNameGate
.export GmNativeNoop
.export GmNormalAudioReturn
.export GmStompGate
.exportzp Goomba
.export GuestBodyNoStomp
.export GuestBodyStompAllowed
.export GuestClaimBlockSlot
.export GuestHurtKind
.export GuestOamRotationActive
.export GuestPowerupActive
.export GuestPowerupDisplay
.export GuestPowerupOld
.export GuestPowerupTarget
.export GuestPowerupUpdate
.export HandleClimbing
.export HandleCoinMetatile
.export HandleEnemyFBallCol
.export HandlePipeEntry
.export HpActorOwner
.export HpActorSlot
.export HpArea
.export HpCharacter
.export HpCount
.export HpCurrentArea
.export HpInSourceMargin
.export HpKey
.export HpMode
.export HpSupport
.export HpValid
.export HpXHi
.export HpXLo
.export InitEnemyObject
.export InjuryTimer
.export InvDirty
.export InvHudActive
.export InvPickup
.export InvPickupOwner
.export InvPickupSaveHi
.export InvPickupSaveLo
.export InvRisePhase
.export InventoryStompDropHook
.export JnBodyDispatch
.export JnCollisionDispatch
.export JnDeathDispatch
.export JnHeadDispatch
.export JnInjuryStartDispatch
.export JnInjuryStatusDispatch
.export JnInventoryDeathDispatch
.export JnMovementDispatch
.export JnPickupDispatch
.export JnPortraitDispatch
.export JnPrepareDispatch
.export JnPrivateDispatch
.export JnResetDispatch
.export JnRiseDispatch
.export JnStatusName
.export JnVisibleDispatch
.export JnWeaponsDispatch
.export KbWorldPaletteIndex
.export KillPlayer
.export KmPortrait
.export Left_Right_Buttons
.export LevelNumber
.export LmBoundingBoxGate
.export Local_eb
.exportzp M0
.exportzp M1
.exportzp MEGAMAN_MAX_SPRITES
.exportzp METASPRITE_SAMUS_BODY
.exportzp MTILE_CLIMB
.exportzp MTILE_SOLID
.export MTileAttribute
.export MaaOwner
.export MarioSourceBeginFreeze
.export MarioSourceCrossSmallGap
.export MarioSourceGapEligible
.export MarioSourcePowerupCollision
.export MarioVariant
.export MegaManSlideSmallGap
.export MetaspriteRenderLoop
.export Misc_Collision_Flag
.exportzp Misc_State
.export MmBlockAttack
.export MmDeathFlag
.export MmEnemyFlash
.export MmEnemyHealthHi
.export MmEnemyHealthLo
.export MmReserveVine
.export MmSliding
.export MmSolidTerrain
.export NativePlayerDeath
.export NextBank_SMC
.export NrFreshGameInit
.export NrQueueSelectName
.export NrUi
.export NrVisible
.export NumberofLives
.export ObjectMetasprite
.exportzp ObjectOffset
.export OperMode
.export OperMode_Task
.export PlatformCollisionFlag
.export PlayerBGCollision
.export PlayerChangeSizeFlag
.export PlayerFacingDir
.export PlayerHeadCollision
.export PlayerSize
.export PlayerStatus
.export Player_BoundBoxCtrl
.exportzp Player_PageLoc
.export Player_Pos_ForScroll
.export Player_Rel_XPos
.export Player_Rel_YPos
.export Player_SprAttrib
.exportzp Player_State
.export Player_XSpeedAbsolute
.exportzp Player_X_Position
.export Player_X_Scroll
.exportzp Player_X_Speed
.exportzp Player_Y_HighPos
.exportzp Player_Y_Position
.exportzp Player_Y_Speed
.exportzp PowerUpType
.export PrimaryHardMode
.export PrintStatusBarNumbers
.export QueueGuestWeaponPalette
.export QueueMegaManFacePalette
.exportzp R0
.exportzp R1
.exportzp R2
.exportzp R3
.exportzp R4
.exportzp R5
.exportzp R6
.exportzp R7
.export RelativePlayerPosition
.export ReloadCHRBank
.export ResetPalStar
.export RevivalRateData
.export RgOamPlayerStart
.export RgOamRotation
.export RlAdderDispatch
.export RlBoxDispatch
.export RlDrawDispatch
.export RlGraphicsDispatch
.export RlWeaponsDispatch
.export RunAllH
.exportzp SAMUS_MAX_SPRITES
.export SBnce
.export SafecallA_SMC
.exportzp SavedJoypadBits
.export ScreenLeft_PageLoc
.export ScreenLeft_X_Pos
.export ScrollHandler
.export ScrollThirtyTwo
.export SelectedCharacter
.export SetupFloateyNumber
.exportzp Sfx_CoinGrab
.exportzp Sfx_EnemySmack
.exportzp Sfx_PipeDown_Injury
.exportzp Sfx_PowerUpGrab
.export ShellOrBlockDefeat
.export SmChrBank
.export SmClearance
.export SmFreezePalettePending
.export SmFreezeRenderState
.export SmPosePtr
.export SpecialRosterClear
.export SprDataOffset_Ctrl
.export Sprite0HitDetectFlag
.export Sprite_Attributes
.export Sprite_Tilenumber
.export Sprite_X_Position
.export Sprite_Y_Position
.export Square1SoundQueue
.export Square2SoundQueue
.export StarInvincibleTimer
.export Start
.export StompChainCounter
.export StompTimer
.exportzp TimeRunningOutMusic
.export TimerControl
.export Up_Down_Buttons
.exportzp VINE_TILE_1
.exportzp VINE_TILE_2
.export VRAM_Buffer1
.export VRAM_Buffer1_Offset
.export VRAM_Buffer2
.export VRAM_Buffer2_Offset
.export VRAM_Buffer_AddrCtrl
.export Vine_Start_Y_Position
.export VvUiDispatch
.export WorldNumber
.export X5ChrMode
.export X5EasyFootBox
.export X5GetPlayerColors
.export X5HudChrUpper
.export X5QueueAreaBackdrop
.export X5SetPhysicalChr
.export X5StompDispatch
.export X5WideChrActive
.export Z2HeadWithinTerrain
.export Z2SideAdmission
.export Z2SourceFeetDispatch

.export GmLegacyGuestAudio
.export GmLegacyVanillaAudio := AudioUpdate::CrossoverVanillaAudio

.export HuNativeAirBubbles := ProcFireball_Bubble::ProcAirBubbles
.export HuNativeNamePage := NrQueueSelectName::NamePage

.import HuGameColdDispatch

.export CurrentBank
.export CurrentBankC
.export GuestMetroidStoreIndirectY
.export GuestNativeApu
.export GuestNativeEnable
.export GuestNativeStoreSTA00Y
.export GuestNativeStoreSTA01
.export GuestNativeStoreSTA01Y
.export GuestNativeStoreSTA02Y
.export GuestNativeStoreSTA03
.export GuestNativeStoreSTA03Y
.export GuestNativeStoreSTA05
.export GuestNativeStoreSTA07
.export GuestNativeStoreSTA0b
.export GuestNativeStoreSTA0f
.export RdGear
.export RdMissileMode
.export RdVY
.export RdVariant
.export RgAudioCpuZp
.export RgAudioRam
.export SelectedCharacter
.export RdSfx
.export RdHit
.export RdHealthLo
.export RdHealthHi
.export SafecallA_SMC
.export FarcallJmpTarget_SMC
.export FarCallCommon
.export NextBank_SMC
.export SafereturnA_SMC
.export OperMode
.export CrossoverMenuState
.export GuestAudioCharacter
.export GamePauseStatus
.export AreaType
.export WorldNumber
.export AreaMusicQueue
.export Square1SoundQueue
.export Square2SoundQueue
.export NoiseSoundQueue
.export PauseSoundQueue
.export EventMusicQueue
.export GuestWorldQueues
.export GuestMixMask
.export GuestMixPreviousMask
.export GuestCombinedEnable
.export NmiDisable
.export DisableScreenFlag
.export InvHudActive
.export X5HudChrUpper
.export InvHudPhysical
.export GuestAudioBegin
.export GuestAudioFinishTick := GuestAudioFinish::Tick
.export GuestAudioNativeFlush
.export HpPauseCold
.export CrossoverInit
.export FixedAudioRestore := HuAudioRestore
.export FixedGuestRemainder := GmLegacyGuestAudio
.export FixedVanillaRemainder := AudioUpdate::CrossoverVanillaAudio


.import HuDrawAll
.import HuSamusShots
.import HuBeforeEffects
.import HuAfterEffects
.import HuUpdateDrops
.import HuRemainingWeapons
.export DrawAllMetasprites
.export LsrEffectsAfterEnemies
.export LsrEffectsBeforeEnemies
.export SamusDrawShots
.export SamusFreezeDrawAll
.export Z2RemainingWeaponsGate
.export Z2UpdateDropsGate

.export InventoryUpdateDrops,RemainingWeapons,Z2Variant

; Genuine exports for private FF separate objects.
.exportzp A_Button
.export AreaAddrsLOffset
.export AreaMusicQueue
.export AreaType
.exportzp B_Button
.export BlockBufferAddr
.export BlockBufferColli_Head
.export BlockBufferColli_Side
.export Block_Buffer_1
.export BoundBoxCtrlData
.export BoundingBox_LR_Corner
.export BoundingBox_UL_Corner
.exportzp Bowser
.export BowserHitPoints
.exportzp BulletBill_CannonVar
.exportzp BulletBill_FrenzyVar
.exportzp BuzzyBeetle
.export CrossoverBehaviorVersion
.export CrouchingFlag
.export CurrentBank
.export CurrentBankC
.export CurrentCHRBank
.export CurrentOAMOffset
.export DisableScreenFlag
.exportzp Down_Dir
.export Enemy_BoundBoxCtrl
.exportzp Enemy_Flag
.exportzp Enemy_ID
.exportzp Enemy_PageLoc
.exportzp Enemy_State
.exportzp Enemy_X_Position
.exportzp Enemy_Y_HighPos
.exportzp Enemy_Y_Position
.export EraseEnemyObject
.export FarCallCommon
.export FarcallJmpTarget_SMC
.export FireballThrowingTimer
.export FloateyNum_Control
.exportzp GameEngineSubroutine
.export GamePauseStatus
.exportzp Goomba
.export GuestBodyNoStomp
.export GuestBodyStompAllowed
.export GuestLegacyHurt
.export GuestOamRotationActive
.export GuestPowerupActive
.export GuestPowerupAge
.export GuestPowerupDisplay
.export GuestPowerupOld
.export GuestPowerupPose
.export GuestPowerupTarget
.export HandleEnemyFBallCol
.export HorizontalScroll
.export InjuryTimer
.export IrqNewScroll
.export IrqPPUCTRL
.export IrqScrollSplit
.export KillPlayer
.export Local_eb
.exportzp METASPRITE_SAMUS_BODY
.exportzp MTILE_CLIMB
.exportzp MTILE_SOLID
.export MTileAttribute
.export MegaManShotPose
.export MetaspriteRenderLoop
.export Mirror_PPUCTRL
.export Mirror_PPUMASK
.export MmDeathAge
.export MmDeathFlag
.export MmEnemyFlash
.export MmEnemyHealthHi
.export MmEnemyHealthLo
.export MmFrictionYActive
.export MmLastPalette
.export MmOldX
.export MmOnVine
.export MmSliding
.export MmUnderwater
.export MmVX
.export MmVY
.export MmXFraction
.export MmYFraction
.export MoveAllSpritesOffscreen
.export NextBank_SMC
.export NmiDisable
.export NumberofLives
.export ObjectMetasprite
.exportzp ObjectOffset
.export OperMode
.export PlayerChangeSizeFlag
.export PlayerFacingDir
.export PlayerOutlinesOff
.export PlayerSize
.export PlayerStatus
.export Player_CollisionBits
.exportzp Player_PageLoc
.export Player_Pos_ForScroll
.export Player_Rel_XPos
.export Player_SprAttrib
.exportzp Player_State
.export Player_XSpeedAbsolute
.exportzp Player_X_Position
.export Player_X_Scroll
.exportzp Player_X_Speed
.exportzp Player_Y_HighPos
.exportzp Player_Y_Position
.exportzp Player_Y_Speed
.exportzp Podoboo
.exportzp PowerUpObject
.exportzp PowerUpType
.exportzp R0
.exportzp R1
.exportzp R2
.exportzp R3
.exportzp R4
.exportzp R5
.exportzp R6
.exportzp R7
.export ReloadCHRBank
.export RgCrouch
.export RgOamRotation
.export SafecallA_SMC
.export SafereturnA_SMC
.exportzp SavedJoypadBits
.export ScreenLeft_PageLoc
.export ScreenLeft_X_Pos
.export SelectedCharacter
.export SetupFloateyNumber
.exportzp Sfx_BigJump
.exportzp Sfx_EnemySmack
.exportzp Sfx_Fireball
.exportzp Sfx_PipeDown_Injury
.exportzp Sfx_PowerUpGrab
.export ShellOrBlockDefeat
.export SideCollisionTimer
.export SmBall
.export SmChrBank
.export SmPosePtr
.export SpecialRosterClear
.export Square1SoundQueue
.export Square2SoundQueue
.export StarInvincibleTimer
.exportzp StarPowerMusic
.export SwimmingFlag
.export TimerControl
.exportzp Up_Dir
.export VerticalScroll
.export WorldNumber
.export X5ChrMode
.export X5PublishChr
.export X5SetPhysicalChr
.export X5WideChrActive

.export SelectedCharacter
.export GamePauseStatus
.export TimerControl
.export MmDeathFlag
.exportzp GameEngineSubroutine
.exportzp Enemy_Flag
.exportzp Enemy_ID
.exportzp Enemy_State
.exportzp PowerUpType
.exportzp PowerUpObject
.export FarCallCommon
.export SafecallA_SMC
.export FarcallJmpTarget_SMC
.export BlockBufferColli_Head
.export BlockBufferColli_Side
.export Z2HeadWithinTerrain
.export JnBodyDispatch
.export RlAdderDispatch
.export RlBoxDispatch
.export LmBoundingBoxGate
.export MegaManClimbing
.export X5StompDispatch
.export X5SpringDispatch

.export AreaAddrsLOffset
.export AreaNumber
.export AreaType
.export BlockBufferAddr
.export Block_Buffer_1
.export BoundingBox_LR_Corner
.export BoundingBox_UL_Corner
.export CmHostFresh
.export CrossoverContinue
.export CurrentBank
.export CurrentBankC
.export CurrentCHRBank
.export CurrentOAMOffset
.export CurrentPlayer
.export DisableScreenFlag
.exportzp Enemy_Flag
.exportzp Enemy_ID
.exportzp Enemy_PageLoc
.exportzp Enemy_State
.exportzp Enemy_X_Position
.exportzp Enemy_Y_Position
.export EraseEnemyObject
.export FarCallCommon
.export FarcallJmpTarget_SMC
.export FmNativePrepare
.exportzp GameEngineSubroutine
.export GamePauseStatus
.export GetBlockBufferAddr
.export GuestBodyNoStomp
.export GuestBodyStompAllowed
.export GuestOamRotationActive
.export HandleEnemyFBallCol
.export InvDirty
.export InvHudActive
.export InvPickup
.export InvPickupOwner
.export InvPickupSaveHi
.export InvPickupSaveLo
.export InvRisePhase
.export KillPlayer
.exportzp METASPRITE_SAMUS_BODY
.export MTileAttribute
.export MarioSourcePowerupCollision
.export Mirror_PPUCTRL
.export Mirror_PPUMASK
.export NativePlayerDeath
.export NextBank_SMC
.export NmiDisable
.export NumberofLives
.export ObjectMetasprite
.export OffScr_NumberofLives
.export OperMode
.export PlayerFacingDir
.export PlayerSize
.export PlayerStatus
.export Player_CollisionBits
.exportzp Player_PageLoc
.exportzp Player_State
.export Player_XSpeedAbsolute
.exportzp Player_X_Position
.export Player_X_Scroll
.exportzp Player_X_Speed
.exportzp Player_Y_HighPos
.exportzp Player_Y_Position
.exportzp Player_Y_Speed
.export PnHudCommitAfterVram
.exportzp PowerUpType
.export R0
.export R1
.exportzp R2
.exportzp R3
.exportzp R4
.exportzp R5
.exportzp R6
.exportzp R7
.export ReloadCHRBank
.export RgOamRotation
.export SafecallA_SMC
.export SafereturnA_SMC
.export SamusFreezeDrawAll
.exportzp SavedJoypad1Bits
.export ScreenLeft_PageLoc
.export ScreenLeft_X_Pos
.export SelectedCharacter
.export SetupFloateyNumber
.export SmChrBank
.export SmFreezePaletteControl
.export SmPosePtr
.export SpecialRosterClear
.export Sprite_Attributes
.export Sprite_Tilenumber
.export Sprite_X_Position
.export Sprite_Y_Position
.export Square2SoundQueue
.export TimerControl
.export VRAM_Buffer1
.export VRAM_Buffer_AddrCtrl
.export WorldNumber
.export X5ChrMode
.export X5PublishChr
.export X5QueueAreaBackdrop
.export X5SetPhysicalChr
.export X5WideChrActive
.import ArPalPoseIndex,ArHostEnsure
.exportzp ARTHUR_ART_PHASE_BANK,ARTHUR_NATIVE_PHASE_BANK
ARTHUR_ART_PHASE_BANK=.lobyte(.bank(ArPalPoseIndex)|$80)
ARTHUR_NATIVE_PHASE_BANK=.lobyte(.bank(ArHostEnsure)|$80)

.exportzp FfNativeRendererBank
FfNativeRendererBank=.lobyte(.bank(MetaspriteRenderLoop)|$80)

.export SelectedCharacter
.export CurrentOAMOffset
.export CurrentBankC
.export RgDrawFirst
.export RgDrawRemaining
.export SmPosePtr
.export PlayerFacingDir
.export GuestPowerupActive
.export GuestPowerupDisplay
.export MmDeathFlag
.export PlayerOutlinesOff
.export ObjectMetasprite
.export ScreenLeft_X_Pos
.export ScreenLeft_PageLoc
.export SmChrBank
.export SafecallA_SMC
.export FarcallJmpTarget_SMC
.export FarCallCommon
.export MetaspriteRenderLoop
.exportzp Player_X_Position
.exportzp Player_PageLoc
.exportzp Player_Y_Position
.exportzp Player_Y_HighPos
.exportzp R0
.exportzp R1
.exportzp R2
.exportzp R3
.exportzp R4
.exportzp R5
.exportzp R6
.exportzp R7

.include "quick-parent-exports.inc"

.export BeginEnemyLoop
.export BlockBufferAddr
.export Block_Buffer_1
.export BoundingBox_LR_Corner
.export BoundingBox_UL_Corner
.export CrouchingFlag
.export CurrentBank
.export CurrentBankC
.export CurrentOAMOffset
.exportzp Enemy_Flag
.exportzp Enemy_PageLoc
.exportzp Enemy_State
.exportzp Enemy_X_Position
.exportzp Enemy_Y_HighPos
.exportzp Enemy_Y_Position
.export EraseEnemyObject
.export FarCallCommon
.export FarcallJmpTarget_SMC
.exportzp FrameCounter
.exportzp GameEngineSubroutine
.export GetBlockBufferAddr
.export GuestHurtKind
.export GuestHurtTicks
.export InjuryTimer
.export InvDirty
.export InvHudActive
.export InvPickup
.export InvPickupOwner
.export InvPickupSaveHi
.export InvPickupSaveLo
.export InvRisePhase
.export KillPlayer
.export MTileAttribute
.export MarioSourcePowerupCollision
.export MegaManDeathStart
.export MegaManDeathUpdate
.export MegaManDrawDeath
.export MmBulletType
.export MmDeathFlag
.export MmEnemyFlash
.export MmEnemySlot
.export MmSlot
.exportzp ObjectOffset
.export PlayerChangeSizeFlag
.export PlayerFacingDir
.export PlayerSize
.export PlayerStatus
.exportzp Player_PageLoc
.export Player_Pos_ForScroll
.export Player_Rel_XPos
.exportzp Player_State
.export Player_XSpeedAbsolute
.exportzp Player_X_Position
.export Player_X_Scroll
.exportzp Player_X_Speed
.exportzp Player_Y_HighPos
.exportzp Player_Y_Position
.exportzp Player_Y_Speed
.exportzp PowerUpType
.exportzp R0
.exportzp R1
.exportzp R2
.exportzp R3
.exportzp R4
.exportzp R5
.exportzp R6
.exportzp R7
.export SafecallA_SMC
.exportzp SavedJoypadBits
.export ScreenLeft_PageLoc
.export ScreenLeft_X_Pos
.export SetupFloateyNumber
.export SideCollisionTimer
.export SmBombHits
.export SmSlot
.export Square1SoundQueue
.export Square2SoundQueue
.export TimerControl
.export VRAM_Buffer1
.export VRAM_Buffer1_Offset
.export VRAM_Buffer_AddrCtrl
.export X5SetPhysicalChr
.export _CurrentPlayer
.export MoveAllSpritesOffscreen
.export SunnyGlobalInit
.export Mirror_PPUMASK
.export Mirror_PPUCTRL
.export NmiDisable
.export DisableScreenFlag
.export ReloadCHRBank
.export CurrentCHRBank
.export ChrPhysicalMap
.export HorizontalScroll
.export VerticalScroll
.exportzp HostBank_BeginEnemyLoop := .lobyte(.bank(BeginEnemyLoop)|$80)
.exportzp HostBank_GmPublishEmpty := .lobyte(.bank(GmPublishEmpty)|$80)
.exportzp HostBank_MarioSourcePowerupCollision := .lobyte(.bank(MarioSourcePowerupCollision)|$80)
.exportzp HostBank_MegaManDeathUpdate := .lobyte(.bank(MegaManDeathUpdate)|$80)
.exportzp HostBank_MegaManDrawDeath := .lobyte(.bank(MegaManDrawDeath)|$80)
.exportzp HostBank_X5SetPhysicalChr := .lobyte(.bank(X5SetPhysicalChr)|$80)

.export X5QueueAreaBackdrop
.exportzp HostBank_X5QueueAreaBackdrop := .lobyte(.bank(X5QueueAreaBackdrop)|$80)

.export RlLegacyDrawDispatch,ObjectMetasprite,SmPosePtr

.export SamusFreezeRenderFinish

.import S2BoundaryGame,S2BoundaryImmunity,S2BoundaryPlatform,S2BoundaryPointers,S2BoundaryStarEnd,S2BoundaryBody,S2MainGrow,S2MainCarryPrelude,S2MainErase,S2MainSpawn
.export HuGameRoutinesDirect,GuestBodyContact

.export BassAudioLastDeath
.export BassAudioLastGround
.export BassAudioPreviousMask
.export BassAudioSfxApu
.export CheckForCoinMTiles
.export ChkPUSte
.export CrossoverGraphicsBank
.export CrossoverLevelEnemyInit
.export Cv3DmcResetOwner
.export CyclePlayerPalettePreload
.export EnemyGraphicsEngine
.export Enemy_MovingDir
.exportzp Enemy_X_Speed
.export GetEnemyBoundBox
.export GetEnemyBoundBoxOfs
.export GetEnemyOffscreenBits
.export GuestApuLast
.export GuestBodyContact
.export GuestExpansionFlush
.export GuestFxApu
.export GuestFxDirty
.export GuestMixChanged
.export GuestNativeDirty
.export GuestSweepControl
.export GuestSweepDivider
.export GuestSweepReload
.export HpPrepareNativePointers
.export HuGameRoutinesDirect
.export IcGlobalInit
.export LmRiseGate
.export MarioSourceBodyImmunity
.export NoiseSoundBuffer
.export NormalEnemyBoundBox
.export NormalEnemyOffscreenBits
.export PauseSoundBuffer
.export RelativeEnemyPosition
.export RgAudioCharacter
.export RunPUSubs
.export RyPlatformCancel
.export RyPlatformSlot
.export SprObjectCollisionCore
.export Square1SoundBuffer
.export Square2SoundBuffer
.export VvScrollBridge
.export XgJumpUsed
.export XgWall
.export S2WorldSfxEngine := GuestSharedSfx::SFXSoundEngine
.export S2WorldMixedBody := GuestAudioFinish::MixedChannels

.import S2MenuResolve,S2InitScreenPrepare

.export SmFreezePalettePacket

.export SmFreezeTurn

.export SmFreezeLastBlue

.export UpdateScreen

.export PnHudPreUpdateScreen

.export SmFreezeNativeFlashEnemy

.export RgOamUsed

.export DrawMetasprite

.exportzp NmiR0

.exportzp NmiR1

.export BmFresh

.export BmColors

.include "smb3plus_body_host.s"

.include "smb3plus_kick_host.s"

.include "smb3plus_float_state.inc"

.include "smb3plus_float_data.s"

.include "smb3plus_menu_name.s"

.export BackgroundColorCtrl,RlSupportedDispatch

.export ImposeGravitySprObj,VerticalForceDown,PlayerPhysicsSub,Sprite_Data,SprObject_SprAttrib,PlayerHeadWithinTerrain,BlankPalette
.import WfScene,WfMenuRetire

.import WfAudioProbe
.export WfAtomicRti:=IrqScrollSplit+67
.export GuestAudioBegin,GuestAudioFinish,GuestNativeApu,GuestNativeDirty,GuestNativeEnable

.export CurrentPlayer,NumberofLives,WorldNumber,AreaAddrsLOffset,FrameCounter,OperMode,GamePauseStatus,PlayerFacingDir,PlayerSize,CrouchingFlag,Player_X_Scroll,Player_XSpeedAbsolute,Player_Pos_ForScroll,ScreenLeft_X_Pos,ScreenLeft_PageLoc,Player_Rel_XPos,Player_Rel_YPos,BoundingBox_UL_Corner,BoundingBox_LR_Corner,Block_Buffer_1,Block_Buffer_2,AreaType,CrossoverBehaviorVersion,GuestBodyStompAllowed,GuestBodyNoStomp
