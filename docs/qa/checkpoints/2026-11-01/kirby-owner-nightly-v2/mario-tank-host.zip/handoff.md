Mario the Tank: source component, not playable admission

908B source code (403host+505terrain), physicalRAM2offset1600/A2B600.12conditional context bytes use A2A880, never literal C880 while C remains nativeROM12. Existing FarCallCommon rawbank2 transports and restores the worker/native callbacks. Cold loading, complete owner headers and realROM deny-before-load gates are still required.

CPU:70foreign host comparisons;84contact cases;4inactive blooper controls;8injury;12pickup;16growth;128native movement;512tile classification;120world side/page boundaries plus120one-cell limits;6pressure/protection gates;32head effects;11head protected/coin controls;280foreign head/side comparisons. Native admittedMario0 Start/parser ran167GameLoops/normalNMIs, then explicit Tank7 fixture ran13GameLoops and destroyed a real question-cell from below. Minimum arenaSP164 is not an outerMain/ISR reserve claim.

Graphics: native4096B body equals donor exactly;0body growth.19shoe-only masks (608B) plus original64B boots pickup remain unallocated.56pose/facing pixel reconstructions pass, maximum2extraOAM sprites. Overlay is a user-requested adaptation absent from original worn-body code. Review PNG highlights selected source shoe pixels; it does not certify runtime publication.

The original donor uses four debris slots. This proposal uses the two native host slots and protects bouncing blocks with GuestClaimBlockSlot. Busy host queues defer destruction. No player geometry proxy, remote item release or NMI scratch alias is used.

Do not apply the direct in-memory compiled substitutions to a delivered ROM: they assume RAM2 code is already loaded. RealROM gates must admit exact Mario0/variant7 and complete header before entry, retaining foreign old callbacks. Source leases, loader, retirement, sprite window, menu/lives names/admission, actual outerMain/ISR and native visuals remain. Shared root/O/Downloads/Git untouched.
