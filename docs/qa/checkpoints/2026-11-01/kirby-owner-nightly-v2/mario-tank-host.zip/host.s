.setcpu "6502"
.macpack longbranch
AddToScore=$b815
AreaType=$0753
BlockBounceTimer=$0781
BlockBufferColli_Head=$9587
BlockBufferColli_Side=$958b
BlockMetasprite=$06ea
Block_BBuf_Low=$05b6
Block_Metatile=$05b8
Block_OffscreenBits=$05a4
Block_Orig_YPos=$05b4
Block_PageLoc=$0065
Block_PageLoc2=$05ba
Block_RepFlag=$05bc
Block_State=$0027
Block_X_Position=$007e
Block_Y_HighPos=$00ad
Block_Y_Position=$00c6
BmMarioMovement=$b902
CheckTopOfBlock=$8e66
ChkToStunEnemies=$9d95
CmHostMarioInjury=$bd8d
CrossoverVanillaMovement=$a6c1
DestroyBlockMetatile=$b8d8
DigitModifier=$0131
DonePlayerTask=$a508
Enemy_Flag=$0010
Enemy_ID=$0017
Enemy_State=$001f
Enemy_Y_HighPos=$00a5
EraseEnemyObject=$8d2f
FarCallCommon=$015a
FarcallJmpTarget_SMC=$016b
GameEngineSubroutine=$000f
GetPlayerColors=$b4ac
GuestClaimBlockSlot=$bdc4
InitChangeSize=$a487
InjuryTimer=$079b
MaaHead=$b6f1
MarioSourceBeginPowerup=$bd79
MarioSourcePowerupUpdate=$bdce
MarioVariant=$730a
MmSideDispatchPrefix=$e4a7
NoiseSoundQueue=$0103
ObjectOffset=$000d
PlayerScoreLastIndex=$0005
PlayerSize=$0759
PlayerStatus=$075b
Player_PageLoc=$005c
Player_State=$001e
Player_X_Position=$0075
Player_Y_Speed=$008e
PowerUpType=$0034
R0=$0003
R1=$0004
R2=$0005
R3=$0006
R4=$0007
R5=$0008
R6=$0009
R7=$000a
RemoveCoin_Axe=$b8c4
S2BoundaryImmunity=$ad52
SafecallA_SMC=$0169
SelectedCharacter=$6002
SetPRout=$97c6
SetupFloateyNumber=$98b5
SpawnBrickChunks=$8e97
SprDataOffset_Ctrl=$05be
Square1SoundQueue=$0105
Square2SoundQueue=$0104
StarInvincibleTimer=$079c
TimerControl=$074a
VRAM_Buffer_AddrCtrl=$0774
MtTerrainSave=$a880
MtTerrainY=$a888
MtTerrainA=$a889
MtRemovedTile=$a88a
MtTerrainHeadMode=$a88b
AddToScore_BANK=$83
BmMarioMovement_BANK=$be
CmHostMarioInjury_BANK=$d1
CrossoverVanillaMovement_BANK=$81
DestroyBlockMetatile_BANK=$83
DonePlayerTask_BANK=$81
GetPlayerColors_BANK=$83
GuestClaimBlockSlot_BANK=$88
InitChangeSize_BANK=$81
MaaHead_BANK=$c2
MarioSourceBeginPowerup_BANK=$bb
MarioSourcePowerupUpdate_BANK=$bb
RemoveCoin_Axe_BANK=$83
S2BoundaryImmunity_BANK=$bf
.macro MtHostFar Target
 sta SafecallA_SMC+1
 lda #<Target
 sta FarcallJmpTarget_SMC+1
 lda #>Target
 sta FarcallJmpTarget_SMC+2
 lda #.ident(.concat(.string(Target),"_BANK"))
 jsr FarCallCommon
.endmacro
; Tank Mario host proposal. MarioVariant7 remains NOT menu-admitted here.
; Conditional RAM2 worker, assembled at its A-window alias B600. Existing
; FarCallCommon rawbank2 owns mapping/restoration around native callbacks.
; No RAM/code/CHR lease or global identity admission is allocated here.
.export MtHostSelected,MtHostBooted,MtHostContact,MtHostInjury
.export MtHostMovement,MtHostBeginPowerup,MtHostGrowthUpdate,MtHostEnd
.segment "MT_HOST"

; Identity and powered predicate. A/flags consumed, X/Y preserved.
MtHostSelected:
 lda SelectedCharacter
 bne MtHostNo
 lda MarioVariant
 cmp #7
 beq MtHostYes
MtHostNo:clc
 rts
MtHostYes:sec
 rts
MtHostBooted:
 jsr MtHostSelected
 bcc MtHostNo
 lda PlayerStatus
 cmp #2
 beq MtHostYes
 clc
 rts

; Replacement for the existing EColl farcall S2BoundaryImmunity. All native
; collision eligibility/offscreen/overlap checks still precede this boundary.
; Source original Tank defeat uses1000points and erases piranha after effects.
; No ordinary host ShellOrBlockDefeat's100/200point substitution is allowed.
MtHostContact:
 php
 pha
 jsr MtHostSelected
 bcc MtHostContactLegacy
 lda PlayerStatus
 cmp #2
 beq MtHostContactPowered
 pla
 plp
 clc                         ; Tank never inherits Flash Mario's blooper quirk
 rts
MtHostContactPowered:
 pla
 plp
 lda Enemy_ID,x
 pha
 jsr ChkToStunEnemies
 lda Enemy_State,x
 and #$1f
 ora #$20
 sta Enemy_State,x
 lda #6
 jsr SetupFloateyNumber
 lda #$08                   ; actual donor/host Sfx_EnemySmack; binding asserts it
 sta Square1SoundQueue
 pla
 cmp #$0d                   ; actual donor/host PiranhaPlant; binding asserts it
 bne MtHostContactDone
 lda #2
 sta Enemy_Y_HighPos,x
 lda #0
 sta Enemy_Flag,x
MtHostContactDone:sec
 rts
MtHostContactLegacy:
 pla
 plp
 MtHostFar S2BoundaryImmunity
 rts

; Existing ForceInjury already checks GuestInjuryStatus and kills smallMario.
; Replace its Mario-only CmHostMarioInjury farcall, keeping its native exit.
MtHostInjury:
 php
 pha
 jsr MtHostSelected
 bcc MtHostInjuryLegacy
 lda PlayerStatus
 cmp #2
 beq MtHostImmune
 pla
 plp
 lda #0
 sta PlayerStatus
 lda #8
 sta InjuryTimer
 asl
 sta Square1SoundQueue
 MtHostFar GetPlayerColors
 lda #$0a
 ldy #1
 jmp SetPRout
MtHostImmune:
 pla
 plp
 rts
MtHostInjuryLegacy:
 pla
 plp
 MtHostFar CmHostMarioInjury
 rts

; Current default Mario uses Flash movement. Tank uses the original native
; donor physics, via the already present genuine native SMB route.
MtHostMovement:
 php
 pha
 jsr MtHostSelected
 bcc MtHostMovementLegacy
 lda #0
 sta MtRemovedTile            ; actual once-per-update owner, before BG probes
 pla
 plp
 MtHostFar CrossoverVanillaMovement
 rts
MtHostMovementLegacy:
 pla
 plp
 MtHostFar BmMarioMovement
 rts

; Native outer pickup owner retains erasure,1000points and pickupSFX. Hook
; only its existing MarioSourceBeginPowerup call, after all item admission.
MtHostBeginPowerup:
 php
 pha
 jsr MtHostSelected
 bcc MtHostPowerupLegacy
 pla
 plp
 lda PlayerStatus
 beq MtHostGrow
 cmp #1
 bne MtHostUpgradeDone
 ldx ObjectOffset
 lda #2
 sta PlayerStatus
 MtHostFar GetPlayerColors
 ldx ObjectOffset
 lda #$0c                   ; original donor does not SetPRout for boots
MtHostUpgradeDone:rts
MtHostGrow:
 lda #1
 sta PlayerStatus
 lda #9
 ldy #0
 jmp SetPRout
MtHostPowerupLegacy:
 pla
 plp
 MtHostFar MarioSourceBeginPowerup
 rts

; Current PlayerChangeSize routes Mario to Flash's source updater, which
; would stall a native SetPRout9 growth. Hook that existing farcall too.
MtHostGrowthUpdate:
 php
 pha
 jsr MtHostSelected
 bcc MtHostGrowthLegacy
 pla
 plp
 lda TimerControl
 cmp #$f8
 bne MtHostGrowthEnd
 MtHostFar InitChangeSize
 rts
MtHostGrowthEnd:
 cmp #$c4
 bne MtHostGrowthDone
 MtHostFar DonePlayerTask
MtHostGrowthDone:rts
MtHostGrowthLegacy:
 pla
 plp
 MtHostFar MarioSourcePowerupUpdate
 rts
MtHostEnd:
; Original Tank terrain semantics, adapted to returning native host callbacks.
; No donor TXS, actor coordinate proxy, head-item dispatch or borrowed NMI ZP.
; The conditional RAM2 A-window fixture aliases are NOT a RAM/ROM lease.
.export MtTerrainStart,MtTerrainHeadProbe,MtTerrainSideProbe
.export MtTerrainDestroyCell,MtTerrainTileChecks,MtTerrainEnd
.segment "MT_TERRAIN"

MtTerrainStart:
; The actual MtHostMovement hook resets the cell budget before native BG.
; RdNativeBGGate's MaaAfterBG call is Maaa-only and is deliberately untouched.

; Replace BillBGHeadConsumer's existing farcall MaaHead,jmp target. The native
; head query remains the geometry owner. A0 makes its existing caller proceed
; to feet, so source boots neither bounce nor enter item/question dispatch.
MtTerrainHeadProbe:
 php
 pha
 jsr MtHostBooted
 bcc MtTerrainHeadLegacy
 pla
 plp
 jsr BlockBufferColli_Head
 beq MtTerrainHeadDone
 cmp #$c2                    ; coins retain the actual native pickup owner
 beq MtTerrainHeadDone
 cmp #$c3
 beq MtTerrainHeadDone
 ldx Player_Y_Speed
 bpl MtTerrainHeadDone
 jsr MtTerrainTileChecks
 bcc MtTerrainHeadDestroy
 cmp #$26                    ; original protected head response
 beq MtTerrainHeadStop
 lda #2
 sta Square1SoundQueue
MtTerrainHeadStop:
 lda #1
 sta Player_Y_Speed
 lda #0
 rts
MtTerrainHeadDestroy:
 lda #1
 sta MtTerrainHeadMode
 lda R3
 jsr MtTerrainDestroyCell
 bcs MtTerrainHeadDone
 ; A busy host VRAM queue/two bouncing slots must never turn this into an
; ordinary item release. Defer destruction and hold the upward body here.
 lda #1
 sta Player_Y_Speed
 lda #0
MtTerrainHeadDone:
 rts
MtTerrainHeadLegacy:
 pla
 plp
 MtHostFar MaaHead
 rts

; Replace only the27B MmNativeSideShortcut body with an18B farcall plus9B
; padding, retaining MmSideDispatchTail and all subsequent public addresses.
; Other identities reproduce the actual shortcut's A/P and tail ownership.
MtTerrainSideProbe:
 php
 pha
 jsr MtHostSelected
 bcc MtTerrainOtherSide
 pla
 plp
 jsr BlockBufferColli_Side
 beq MtTerrainSideDone
 pha
 lda #0
 sta MtTerrainHeadMode
 pla
 jsr MtTerrainDestroyCell
MtTerrainSideDone:
 rts
MtTerrainOtherSide:
 pla
 plp
 php
 pha
 lda SelectedCharacter
 cmp #4
 beq MtTerrainGuestSide
 cmp #14
 beq MtTerrainGuestSide
 cmp #11
 bcs MtTerrainGuestSide
 pla
 plp
 jmp BlockBufferColli_Side
MtTerrainGuestSide:
 pla
 plp
 jmp MmSideDispatchPrefix

; A=the actual native nonzero head/side cell, R2/R5/R6/R7=that query's cell.
; C1,A0 means destroyed or this update's one-cell source budget already used.
; C0,A=original means native/inactive/protected/busy. Never call for feet.
; Restores all R0..R7 and query Y around actual score/VRAM/debris owners.
; No player coordinate, size, velocity or collision box is ever proxied.
MtTerrainDestroyCell:
 pha
 jsr MtTerrainTileChecks
 jcs MtTerrainCellNative
 lda GameEngineSubroutine
 cmp #8
 jne MtTerrainCellNative
 lda PlayerStatus
 cmp #2
 jne MtTerrainCellNative
 lda MtRemovedTile
 jne MtTerrainCellSpent
 lda VRAM_Buffer_AddrCtrl
 jne MtTerrainCellNative
 pla
 sta MtTerrainA
 sty MtTerrainY
 ldx #7
MtTerrainSaveProbe:
 lda R0,x
 sta MtTerrainSave,x
 dex
 bpl MtTerrainSaveProbe
 MtHostFar GuestClaimBlockSlot
 jcc MtTerrainCellBusy
 inc MtRemovedTile
 ldx SprDataOffset_Ctrl
 lda #$12
 sta Block_State,x
 lda #0
 sta Block_Metatile,x
 sta Block_RepFlag,x
 sta BlockMetasprite,x
 sta Block_OffscreenBits,x
 ldy MtTerrainSave+2
 sta (R6),y
 tya
 sta Block_Orig_YPos,x
 clc
 adc #$20
 sta Block_Y_Position,x
 lda MtTerrainSave+6
 sta Block_BBuf_Low,x
 lda MtTerrainSave+5
 and #$f0
 sta Block_X_Position,x
 lda MtTerrainSave+5
 cmp Player_X_Position
 lda Player_PageLoc
 bcs MtTerrainPageReady
 clc
 adc #1
MtTerrainPageReady:
 sta Block_PageLoc,x
 sta Block_PageLoc2,x
 lda #1
 sta Block_Y_HighPos,x
 ; Authentic source DoBlockRemove uses these owners directly. Calling the
; ordinary head core/BrickShatter would additionally release an item, bump
; the player, and possibly collect the coin above a side-destroyed block.
 lda MtTerrainHeadMode
 beq MtTerrainEraseSide
 lda #1
 sta Block_RepFlag,x
 lda #$10
 sta BlockBounceTimer
 lda AreaType
 beq MtTerrainHeadCoinAbove
 MtHostFar DestroyBlockMetatile
MtTerrainHeadCoinAbove:
 jsr CheckTopOfBlock
 jmp MtTerrainEmitChunks
MtTerrainEraseSide:
 MtHostFar RemoveCoin_Axe
MtTerrainEmitChunks:
 ldx SprDataOffset_Ctrl
 jsr SpawnBrickChunks
 lda #1
 sta NoiseSoundQueue
 lda #5
 sta DigitModifier+PlayerScoreLastIndex
 MtHostFar AddToScore
 lda SprDataOffset_Ctrl
 eor #1
 sta SprDataOffset_Ctrl
 jsr MtTerrainRestoreProbe
 lda #0
 sec
 rts
MtTerrainCellBusy:
 jsr MtTerrainRestoreProbe
 lda MtTerrainA
 clc
 rts
MtTerrainCellSpent:
 pla
 lda #0
 sec
 rts
MtTerrainCellNative:
 pla
 clc
 rts
MtTerrainRestoreProbe:
 ldx #7
MtTerrainRestoreLoop:
 lda MtTerrainSave,x
 sta R0,x
 dex
 bpl MtTerrainRestoreLoop
 ldy MtTerrainY
 ldx #0
 rts

; Original49B TileChecks/ForceSolidBlocks with its original climb predicate.
; Host MTileAttribute is deliberately not substituted for donor thresholds.
MtTerrainTileChecks:
 jsr MtTerrainCheckClimb
 bcs MtTerrainProtected
 cmp #$c2
 beq MtTerrainProtected
 cmp #$c3
 beq MtTerrainProtected
 cmp #$6d
 beq MtTerrainProtected
 cmp #$67
 beq MtTerrainProtected
 cmp #$68
 beq MtTerrainProtected
 cmp #$c5
 beq MtTerrainProtected
 cmp #$1c
 beq MtTerrainProtected
 cmp #$1f
 beq MtTerrainProtected
 cmp #$6b
 beq MtTerrainProtected
 cmp #$6c
 beq MtTerrainProtected
 clc
 rts
MtTerrainProtected:
 sec
 rts
MtTerrainCheckClimb:
 pha
 and #$c0
 asl
 rol
 rol
 tax
 pla
 cmp MtTerrainClimbUpper,x
 rts
MtTerrainClimbUpper:
 .byte $24,$6e,$8a,$c6       ; BRIDGE_METATILE=$89 in authenticated source
MtTerrainEnd:
