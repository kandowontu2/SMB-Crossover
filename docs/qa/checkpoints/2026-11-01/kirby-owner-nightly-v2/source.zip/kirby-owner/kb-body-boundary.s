; Own A74 remainder after frozen native audio host, no new lease.
.pushseg
.segment "KIRBY_ABILITIES"
.export S2BoundaryA74Start,S2BoundaryA74End,S2BoundaryPointers
S2BoundaryA74Start:
.assert *=S2HostAudioEnd,lderror,"Actual owned A74 append only"
S2BoundaryGate S2BoundaryPlatform,S2MainPlatform,RdBodyPositionPlatform
S2BoundaryGate S2BoundaryStarEnd,S2MainEndStar,CyclePlayerPalettePreload
.import KbBodyDispatch
.export S2BoundaryBody
.proc S2BoundaryBody
 php
 pha
 lda SelectedCharacter
 cmp #25
 beq Own
 pla
 plp
 ; Already in A74: the existing guard admits Kirby/Meta, and its foreign
 ; tail enters the same GuestBodyContact legacy owner as before.
 jmp KbBodyDispatch
 .res 15,$ea
Own:pla
 plp
 farcall S2MainBody,jmp
 .assert *-S2BoundaryBody=49,lderror,"Exact own49B owner boundary"
.endproc
.proc S2BoundaryPointers
 farcall HpPrepareNativePointers
 lda SelectedCharacter
 cmp #25
 beq Own
 jmp CrossoverGraphicsBank
Own:
 farcall S2GraphicsBank
 farcall S2PublishBody
 rts
.endproc
S2BoundaryA74End:
.assert *<=$c000,lderror,"Owned A74 lease only"
.popseg
