.macpack longbranch
.macpack generic
.feature force_range
.include "inc/common.inc"
.include "inc/charmap.inc"
.macro BankPRGA bank
  _BANK_INNER bank, MMC5_PRG_BANK_A
.endmacro
.macro BankPRGC bank
.if ::ENABLE_CROSSOVER
  .if .match(bank, a)
    sta CurrentBankC
  .elseif .match(bank, x)
    stx CurrentBankC
  .elseif .match(bank, y)
    sty CurrentBankC
  .else
    .if (.match (.left (1, {bank}), #))
      lda #.right (.tcount ({bank})-1, {bank}) | MMC5_PRG_ROM
    .else
      lda bank
    .endif
    sta CurrentBankC
  .endif
.endif
  _BANK_INNER bank, MMC5_PRG_BANK_C
.endmacro
.macro _BANK_INNER bank, ADDRESS
.scope
  .if .match(bank, a)
    sta ADDRESS
  .elseif .match(bank, x)
    stx ADDRESS
  .elseif .match(bank, y)
    sty ADDRESS
  .else
    .if (.match (.left (1, {bank}), #))
      lda #.right (.tcount ({bank})-1, {bank}) | MMC5_PRG_ROM ; todo handle ram banking
    .else
      lda bank
    .endif
    sta ADDRESS
  .endif
.endscope
.endmacro
.macro farcall Target,Mode
 sta SafecallA_SMC+1
 lda #<Target
 sta FarcallJmpTarget_SMC+1
 lda #>Target
 sta FarcallJmpTarget_SMC+2
 lda #.lobyte(.bank(Target)|$80)
 .ifblank Mode
 jsr FarCallCommon
 .else
 jmp FarCallCommon
 .endif
.endmacro
.importzp Enemy_Flag
.importzp Enemy_ID
.importzp Enemy_PageLoc
.importzp Enemy_State
.importzp Enemy_X_Position
.importzp Enemy_X_Speed
.importzp Enemy_Y_HighPos
.importzp Enemy_Y_Position
.importzp FrameCounter
.importzp GameEngineSubroutine
.importzp Goomba
.importzp METASPRITE_SAMUS_BODY
.importzp MTILE_BUMP
.importzp MTILE_CLIMB
.importzp MTILE_SOLID
.importzp Player_PageLoc
.importzp Player_State
.importzp Player_X_Position
.importzp Player_X_Speed
.importzp Player_Y_HighPos
.importzp Player_Y_Position
.importzp Player_Y_Speed
.importzp Podoboo
.importzp PowerUpType
.importzp R0
.importzp R1
.importzp R2
.importzp R3
.importzp R4
.importzp R5
.importzp R6
.importzp R7
.importzp SavedJoypadBits
.importzp Select_Button
.importzp Sfx_PowerUpGrab
.include "smb2_roster.s"
.include "smb2_roster_palette_v2.s"
.include "smb2_roster_audio.s"
.include "smb2_roster_main_v2.s"
.include "smb2_roster_host_v5.s"
.include "smb2_roster_hud_v5.s"
.include "smb2_roster_audio_effects_v6.s"
.include "smb2_roster_palette_lifecycle_v7.s"
.include "smb2_roster_audio_host_v8.s"

.include "kb-body-boundary.s"

.export S2Ready
.include "smb2_world_sfx.s"

.import DrawMetasprite,FmQueueName

.include "doki_current_draw.s"
