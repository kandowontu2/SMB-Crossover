.setcpu "6502"
.macpack longbranch
.import InvPickupOwner,InvPickup,InvRisePhase,InvPickupSaveLo,InvPickupSaveHi,PowerUpType,Enemy_State,Enemy_ID,Enemy_Flag,EraseEnemyObject,SetupFloateyNumber,Square2SoundQueue,VRAM_Buffer1,VRAM_Buffer1_Offset,FarCallCommon,FarcallJmpTarget_SMC,SafecallA_SMC,MarioSourcePowerupCollision
Sfx_PowerUpGrab=$20
PowerUpObject=$2e
.include "kr-pickup-rom-context-v3.inc"
.segment "ALIGN"
.include "kr-pickup-rom-align-v3.inc"
.segment "WORKER"
.include "kr-pickup-rom-tail-v3.inc"
