.setcpu "6502"
.macpack longbranch
KrState=$c000
.export KrState
KrReady=$c810
.export KrReady
KrSoundEvent=$c801
.export KrSoundEvent
KrSaved0=$c7fe
KrSaved1=$c7ff
KrPointer=$03
.exportzp KrPointer
.segment "RAM"
.include "kr-pickup-kernel-v3.inc"
