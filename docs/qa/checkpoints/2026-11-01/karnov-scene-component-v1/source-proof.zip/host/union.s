.import KrServiceVeneers
.import ThServiceVeneers,ThArExtended
.import S2ServiceVeneers,S2BoundaryLateUI
.import BtServiceVeneers
.import QwFullBox,QwAfterTerrain
.import QwService,ArenaGateBank,FmAlts
.import FwGenAfterTerrain
.export HuNativeWorldPalette
.import CurrentBankC
.import ArGenCheckForeground,ArGenResolve,ArGenAfterTerrain,ArGenDrawAll
.import FwServiceVeneers,ArOwnServices
.macpack longbranch
.feature force_range
.include "inc/common.inc"
.include "inc/charmap.inc"
.include "union_imports.inc"
.macro farcall Target,Mode
 sta SafecallA_SMC+1
 lda #<Target
 sta FarcallJmpTarget_SMC+1
 lda #>Target
 sta FarcallJmpTarget_SMC+2
 lda #.lobyte(.bank(Target)|$80)
 .if .xmatch({Mode},{jmp})
 jmp FarCallCommon
 .else
 jsr FarCallCommon
 .endif
.endmacro
.segment "CHARACTER_HOST_UNION"
HuStart:
.assert HuStart=$b5e0,lderror,"Approved union lease start"
; Existing owned20B alignment pad: actual source Z2IsActive predicate.
; This entry receives SelectedCharacter in A; all original checks/flags
; follow the genuine body after its first LDA, including false C clear.
.proc HuZ2FromSelected
 cmp #4
 bne No
 lda Z2Variant
 cmp #1
 beq Yes
No:clc
 rts
Yes:sec
 rts
.endproc
HuQuickAltTest:
 lda FmAlts
 and #32
 rts
HuQuickAlt:
 lda FmAlts
 and #32
 beq HuQuickNative
 jmp HuQuickSet
.res $20-(*-HuStart),$ff
.export HuEntryBase
HuEntryBase:
.assert .lobyte(HuEntryBase)=0,lderror,"Rare entry page alignment"
.export HuMovement
.proc HuMovement
 sta SafecallA_SMC+1
 php
 tya
 pha
 ldy #0
 jmp HuCommon
::HuQClass:
 cmp #25
 jmp HuS2Decide
 .assert *-HuMovement=16,lderror,"Rare fixed entry stride"
.endproc
.export HuGraphics
.proc HuGraphics
 sta SafecallA_SMC+1
 php
 tya
 pha
 ldy #1
 jmp HuCommon
::HuQDecide:
 beq HuQuickAlt
 jmp HuCommonAfterSelected
 .assert *-HuGraphics=16,lderror,"Rare fixed entry stride"
.endproc
.export HuDraw
.proc HuDraw
 sta SafecallA_SMC+1
 php
 tya
 pha
 ldy #2
 jmp HuCommon
::HuQuickNative:
 lda #9
 jmp HuCommonAfterSelected
 .assert *-HuDraw=16,lderror,"Rare fixed entry stride"
.endproc
.export HuPortrait
.proc HuPortrait
 sta SafecallA_SMC+1
 php
 tya
 pha
 ldy #3
 jmp HuCommon
::HuQuickSet:
 sty ArenaGateBank
 bne HuQLow
 .assert *-HuPortrait=16,lderror,"Rare fixed entry stride"
.endproc
.export HuWeapons
.proc HuWeapons
 sta SafecallA_SMC+1
 php
 tya
 pha
 ldy #4
 jmp HuCommon
::HuQLow:
 lda #<QwService
 jmp HuQStoreLo
 .assert *-HuWeapons=16,lderror,"Rare fixed entry stride"
.endproc
.export HuInjury
.proc HuInjury
 sta SafecallA_SMC+1
 php
 tya
 pha
 ldy #5
 jmp HuCommon
::HuQStoreLo:
 sta FarcallJmpTarget_SMC+1
 bne HuQHigh
 .assert *-HuInjury=16,lderror,"Rare fixed entry stride"
.endproc
.export HuInjuryStatus
.proc HuInjuryStatus
 sta SafecallA_SMC+1
 php
 tya
 pha
 ldy #6
 jmp HuCommon
::HuQHigh:
 lda #>QwService
 jmp HuQStoreHi
 .assert *-HuInjuryStatus=16,lderror,"Rare fixed entry stride"
.endproc
.export HuDeathStart
.proc HuDeathStart
 sta SafecallA_SMC+1
 php
 tya
 pha
 ldy #7
 jmp HuCommon
::HuQStoreHi:
 sta FarcallJmpTarget_SMC+2
 bne HuQBank
 .assert *-HuDeathStart=16,lderror,"Rare fixed entry stride"
.endproc
.export HuDeath
.proc HuDeath
 sta SafecallA_SMC+1
 php
 tya
 pha
 ldy #8
 jmp HuCommon
::HuQBank:
 lda #.lobyte(.bank(QwService)|$80)
 jmp HuQStoreBank
 .assert *-HuDeath=16,lderror,"Rare fixed entry stride"
.endproc
.export HuVisible
.proc HuVisible
 sta SafecallA_SMC+1
 php
 tya
 pha
 ldy #9
 jmp HuCommon
::HuQStoreBank:
 sta NextBank_SMC+1
 bne HuQRestore
 .assert *-HuVisible=16,lderror,"Rare fixed entry stride"
.endproc
.export HuHead
.proc HuHead
 sta SafecallA_SMC+1
 php
 tya
 pha
 ldy #10
 jmp HuCommon
::HuQRestore:
 jmp HuCommonRestore
 .res 2,$ff
 .assert *-HuHead=16,lderror,"Rare fixed entry stride"
.endproc
.export HuBody
.proc HuBody
 sta SafecallA_SMC+1
 php
 tya
 pha
 ldy #11
 jmp HuCommon
::HuQuickBodyCompare:
 cmp #9
 jmp HuQuickBodyDecide
 .assert *-HuBody=16,lderror,"Rare fixed entry stride"
.endproc
.export HuAdder
.proc HuAdder
 sta SafecallA_SMC+1
 php
 tya
 pha
 ldy #12
 jmp HuCommon
::HuQuickBodyDecide:
 beq HuQuickBodyAlt
 jmp HuQuickBodyOriginal
 .assert *-HuAdder=16,lderror,"Rare fixed entry stride"
.endproc
.export HuBox
.proc HuBox
 sta SafecallA_SMC+1
 php
 tya
 pha
 ldy #13
 jmp HuCommon
::HuQuickBodyAlt:
 jsr HuQuickAltTest
 bpl HuQuickBodyAltDecide
 .assert *-HuBox=16,lderror,"Rare fixed entry stride"
.endproc
.export HuSide
.proc HuSide
 sta SafecallA_SMC+1
 php
 tya
 pha
 ldy #14
 jmp HuCommon
::HuQuickBodyAltDecide:
 beq HuQuickBodyNative
 jmp HuQuickBodyOwn
 .assert *-HuSide=16,lderror,"Rare fixed entry stride"
.endproc
.export HuFresh
.proc HuFresh
 sta SafecallA_SMC+1
 php
 tya
 pha
 ldy #15
 jmp HuCommon
::HuQuickBodyNative:
 lda #9
 jmp HuQuickBodyOriginal
 .assert *-HuFresh=16,lderror,"Rare fixed entry stride"
.endproc
.export HuFullBox
.proc HuFullBox
 sta SafecallA_SMC+1
 php
 tya
 pha
 ldy #16
 jmp HuCommon
::HuQuickBodyOwn:
 lda #<QwFullBox
 jmp HuQuickCallbackLo
 .assert *-HuFullBox=16,lderror,"Rare fixed entry stride"
.endproc
.export HuMenuPortrait
.proc HuMenuPortrait
 sta SafecallA_SMC+1
 php
 tya
 pha
 ldy #17
 jmp HuCommon
::HuQuickAfterCompare:
 cmp #9
 jmp HuQuickAfterDecide
 .assert *-HuMenuPortrait=16,lderror,"Rare fixed entry stride"
.endproc
.export HuMenuName
.proc HuMenuName
 sta SafecallA_SMC+1
 php
 tya
 pha
 ldy #18
 jmp HuCommon
::HuQuickAfterDecide:
 beq HuQuickAfterAlt
 jmp HuQuickAfterOriginal
 .assert *-HuMenuName=16,lderror,"Rare fixed entry stride"
.endproc
.export HuReset
.proc HuReset
 sta SafecallA_SMC+1
 php
 tya
 pha
 ldy #19
 jmp HuCommon
::HuQuickAfterAlt:
 jsr HuQuickAltTest
 bpl HuQuickAfterAltDecide
 .assert *-HuReset=16,lderror,"Rare fixed entry stride"
.endproc
.export HuPrepare
.proc HuPrepare
 sta SafecallA_SMC+1
 php
 tya
 pha
 ldy #20
 jmp HuCommon
::HuQuickAfterAltDecide:
 beq HuQuickAfterNative
 jmp HuQuickAfterOwn
 .assert *-HuPrepare=16,lderror,"Rare fixed entry stride"
.endproc
.export HuRise
.proc HuRise
 sta SafecallA_SMC+1
 php
 tya
 pha
 ldy #21
 jmp HuCommon
::HuQuickAfterNative:
 lda #9
 jmp HuQuickAfterOriginal
 .assert *-HuRise=16,lderror,"Rare fixed entry stride"
.endproc
.export HuPrivate
.proc HuPrivate
 sta SafecallA_SMC+1
 php
 tya
 pha
 ldy #22
 jmp HuCommon
::HuQuickAfterOwn:
 lda #<QwAfterTerrain
 jmp HuQuickCallbackLo
 .assert *-HuPrivate=16,lderror,"Rare fixed entry stride"
.endproc
.export HuMature
.proc HuMature
 sta SafecallA_SMC+1
 php
 tya
 pha
 ldy #23
 jmp HuCommon
::HuQuickCallbackLo:
 sta FarcallJmpTarget_SMC+1
 bne HuQuickCallbackHigh
 .assert *-HuMature=16,lderror,"Rare fixed entry stride"
.endproc
.export HuPickup
.proc HuPickup
 sta SafecallA_SMC+1
 php
 tya
 pha
 ldy #24
 jmp HuCommon
::HuQuickCallbackHigh:
 lda #>QwFullBox
 jmp HuQuickCallbackHi
 .assert *-HuPickup=16,lderror,"Rare fixed entry stride"
.endproc
.export HuFullPower
.proc HuFullPower
 sta SafecallA_SMC+1
 php
 tya
 pha
 ldy #25
 jmp HuCommon
::HuQuickCallbackHi:
 sta FarcallJmpTarget_SMC+2
 bne HuQuickCallbackBank
 .assert *-HuFullPower=16,lderror,"Rare fixed entry stride"
.endproc
.export HuColors
.proc HuColors
 sta SafecallA_SMC+1
 php
 tya
 pha
 ldy #26
 jmp HuCommon
::HuQuickCallbackBank:
 lda #.lobyte(.bank(QwFullBox)|$80)
 jmp HuQuickCallbackSetBank
 .assert *-HuColors=16,lderror,"Rare fixed entry stride"
.endproc
.export HuBounceOnly
.proc HuBounceOnly
 sta SafecallA_SMC+1
 php
 tya
 pha
 ldy #27
 jmp HuCommon
::HuQuickCallbackSetBank:
 sta NextBank_SMC+1
 bne HuQuickCallbackRestore
 .assert *-HuBounceOnly=16,lderror,"Rare fixed entry stride"
.endproc
.export HuHeadWithinOnly
.proc HuHeadWithinOnly
 sta SafecallA_SMC+1
 php
 tya
 pha
 ldy #28
 jmp HuCommon
::HuQuickCallbackRestore:
 pla
 plp
 jmp HuQuickCallbackCall
 .assert *-HuHeadWithinOnly=16,lderror,"Rare fixed entry stride"
.endproc
.export HuUi
.proc HuUi
 sta SafecallA_SMC+1
 php
 tya
 pha
 ldy #29
 jmp HuCommon
::HuQuickCallbackCall:
 jmp FarCallCommon+3
 .res 2,$ff
 .assert *-HuUi=16,lderror,"Rare fixed entry stride"
.endproc
.export HuStatus
.proc HuStatus
 sta SafecallA_SMC+1
 php
 tya
 pha
 ldy #30
 jmp HuCommon
::HuS2Decide:
 beq HuS2High
 jmp HuS2Foreign
 .assert *-HuStatus=16,lderror,"Rare fixed entry stride"
.endproc
.export HuBounce
.proc HuBounce
 sta SafecallA_SMC+1
 php
 tya
 pha
 ldy #31
 jmp HuCommon
::HuS2Foreign:
 cmp #9
 jmp HuQDecide
 .assert *-HuBounce=16,lderror,"Rare fixed entry stride"
.endproc
.export HuWorldPalette
.proc HuWorldPalette
 sta SafecallA_SMC+1
 php
 tya
 pha
 ldy #32
 jmp HuCommon
::HuS2High:
 lda #>S2ServiceVeneers
 bne HuS2StoreHigh
 nop
 .assert *-HuWorldPalette=16,lderror,"Rare fixed entry stride"
.endproc
.export HuPowerup
.proc HuPowerup
 sta SafecallA_SMC+1
 php
 tya
 pha
 ldy #33
 jmp HuCommon
::HuS2StoreHigh:
 sta FarcallJmpTarget_SMC+2
 bne HuS2Bank
 .assert *-HuPowerup=16,lderror,"Rare fixed entry stride"
.endproc
.export HuWeaponTail
.proc HuWeaponTail
 sta SafecallA_SMC+1
 php
 tya
 pha
 ldy #34
 jmp HuCommon
::HuS2Bank:
 lda #.lobyte(.bank(S2ServiceVeneers)|$80)
 jmp HuExtendedSet
 .assert *-HuWeaponTail=16,lderror,"Rare fixed entry stride"
.endproc
.export HuVine
.proc HuVine
 sta SafecallA_SMC+1
 php
 tya
 pha
 ldy #35
 jmp HuCommon
::KrUnionBank:
 lda #.lobyte(.bank(KrServiceVeneers)|$80)
 jmp ThFFBankReady
 .assert *-HuVine=16,lderror,"Rare fixed entry stride"
.endproc
.proc HuCommon
::HuGenericIndex:
 lda SelectedCharacter
 cmp #34
 beq KrUnionBank
 cmp #10
 bne ThForeign
 lda FmAlts
 and #$44
 cmp #$40
 bne ThForeign
 lda #.lobyte(.bank(ThServiceVeneers)|$80)
 jmp ThFFBankReady
ThForeign:
 jmp HuQClass
::HuCommonAfterSelected:
 cmp #22
 jeq HuExtendedFF
 cmp #32
 jeq HuExtendedArthur
 cmp #27
 bcc HuExtendedNotShared
 cmp #34
 bcs HuExtendedNotShared
 cmp #28
 beq DK
 cmp #30
 beq Fetch
 bne HuExtendedBT
HuExtendedNotShared:
 cmp #2
 bne Other
 lda RdVariant
 cmp #1
 bne Fetch
 tya
 clc
 adc #108
 tay
 bne Fetch
Other:
 cmp #24
 bne Fetch
 tya
 clc
 adc #36
 tay
DK:tya
 clc
 adc #36
 tay
Fetch:
 lda HuLo,y
 sta FarcallJmpTarget_SMC+1
 lda HuPairIndex,y
 tay
 lda HuPairHi,y
 sta FarcallJmpTarget_SMC+2
 lda HuPairBank,y
 sta NextBank_SMC+1
::HuCommonRestore:
Restore:
 pla
 tay
 plp
 jmp FarCallCommon+3
.endproc

HuExtendedBT:
 lda #>BtServiceVeneers
 sta FarcallJmpTarget_SMC+2
 lda #.lobyte(.bank(BtServiceVeneers)|$80)
 sta NextBank_SMC+1
 cpy #36
 bcc Valid
 ldy #36
Valid:
 tya
 sta FarcallJmpTarget_SMC+1
 asl
 adc FarcallJmpTarget_SMC+1
 adc #<BtServiceVeneers
 sta FarcallJmpTarget_SMC+1
 jmp HuCommon::Restore
.assert .lobyte(BtServiceVeneers)+108<256,lderror,"BT full row remains on one page"
HuLo:
 .byte <JnMovementDispatch,<RlGraphicsDispatch,<RlDrawDispatch,<JnPortraitDispatch,<JnWeaponsDispatch,<JnInjuryStartDispatch,<JnInjuryStatusDispatch,<JnInventoryDeathDispatch,<JnDeathDispatch,<JnVisibleDispatch,<JnHeadDispatch,<JnBodyDispatch,<RlAdderDispatch,<RlBoxDispatch,<Z2SideAdmission,<BmFresh,<GmFullBoxGate,<KmPortrait,<GmMenuNameGate,<JnResetDispatch,<JnPrepareDispatch,<JnRiseDispatch,<JnPrivateDispatch,<JnCollisionDispatch,<JnPickupDispatch,<CheatsFullPower,<BmColors,<X5StompDispatch,<Z2HeadWithinTerrain,<VvUiDispatch,<JnStatusName,<GmStompGate,<KbWorldPaletteIndex,<GuestPowerupUpdate,<RlWeaponsDispatch,<MmReserveVine,<DkMovement,<DkHostGraphics,<DkHostDraw,<DkHostPortrait,<DkHostWeapons,<DkHostInjury,<DkHostInjuryStatus,<DkHostDeathStart,<DkHostDeath,<DkHostVisible,<DkHostHead,<DkHostBody,<DkHostAdder,<DkHostBoxProfile,<DkHostSide,<DkHostFresh,<DkHostBoxGate,<KmPortrait,<DkHostMenuName,<DkHostReset,<HuDkPrepare,<GmNativeNoop,<GmNativeNoop,<GmMatureOwn,<DkHostCollect,<DkFullPower,<DkHostColors,<X5StompDispatch,<Z2HeadWithinTerrain,<DkHostUi,<DkHostName,<GmStompGate,<HuNativeWorldPalette,<DkHostPowerup,<DkHostWeapons,<DkHostVine,<JnMovementDispatch,<DpGameLate,<DpGameDraw,<DpAdmissionPortrait,<DpPlatformWeapons,<DpGameInjury,<DpGameStatus,<DpGameDeathStart,<JnDeathDispatch,<DpHostVisible,<JnHeadDispatch,<DpGameBody,<RlAdderDispatch,<RlBoxDispatch,<Z2SideAdmission,<DpAdmissionFresh,<MaaBox,<KmPortrait,<DpAdmissionMenuName,<DpAdmissionReset,<DpGamePrepare,<DpGameRise,<DpGamePrivate,<DpGameCollision,<DpGamePickup,<CheatsFullPower,<DpAdmissionColors,<DpGameBounce,<Z2HeadWithinTerrain,<DpAdmissionEarly,<DpAdmissionStatusName,<DpGameBounce,<KbWorldPaletteIndex,<GuestPowerupUpdate,<RlWeaponsDispatch,<DpGameVine,<RdLifeMovement,<RdLifeGraphics,<RlDrawDispatch,<RdUiPortrait,<RdWxSamusGate,<RdHzInjury,<RdLifeStatus,<RdLifeDeathStart,<RdLifeDeathTick,<RdLifeVisible,<JnHeadDispatch,<RdLifeBody,<RlAdderDispatch,<RlBoxDispatch,<Z2SideAdmission,<RdLifeFresh,<RdBodyBox,<KmPortrait,<RdUiName,<JnResetDispatch,<RdItPrepare,<JnRiseDispatch,<RdItPrivate,<RdItCollision,<RdItPickup,<CheatsFullPower,<RdBodyColors,<RdWxBounce,<Z2HeadWithinTerrain,<RdUiEarly,<RdUiStatus,<RdWxBounce,<KbWorldPaletteIndex,<GuestPowerupUpdate,<RdWxRemainingGate,<MmReserveVine
HuPairIndex:
 .byte 0,1,2,0,0,0,0,3,0,4,3,3,1,1,5,6,7,6,7,8,8,8,8,8,3,9,10,11,12,13,4,14,15,16,2,17,18,19,19,19,20,21,21,21,21,21,22,21,20,20,22,19,20,6,19,19,23,7,7,7,21,18,19,11,12,21,21,14,23,24,20,25,0,26,26,27,28,26,26,26,0,29,3,26,1,1,5,30,31,6,30,30,26,26,32,32,32,9,30,32,12,30,30,32,15,16,2,32,33,34,2,35,36,37,33,38,38,33,3,38,1,1,5,39,40,6,41,8,37,8,42,42,42,9,43,44,12,45,41,44,15,16,36,17
HuPairHi:
 .byte >JnMovementDispatch,>RlGraphicsDispatch,>RlDrawDispatch,>JnInventoryDeathDispatch,>JnVisibleDispatch,>Z2SideAdmission,>BmFresh,>GmFullBoxGate,>JnResetDispatch,>CheatsFullPower,>BmColors,>X5StompDispatch,>Z2HeadWithinTerrain,>VvUiDispatch,>GmStompGate,>KbWorldPaletteIndex,>GuestPowerupUpdate,>MmReserveVine,>DkMovement,>DkHostGraphics,>DkHostWeapons,>DkHostInjury,>DkHostHead,>HuDkPrepare,>DkHostPowerup,>DkHostVine,>DpGameLate,>DpAdmissionPortrait,>DpPlatformWeapons,>DpHostVisible,>DpAdmissionFresh,>MaaBox,>DpGamePrivate,>RdLifeMovement,>RdLifeGraphics,>RdUiPortrait,>RdWxSamusGate,>RdHzInjury,>RdLifeDeathStart,>RdLifeFresh,>RdBodyBox,>RdUiName,>RdItPrivate,>RdBodyColors,>RdWxBounce,>RdUiEarly
HuPairBank:
 .byte .lobyte(.bank(JnMovementDispatch)|$80),.lobyte(.bank(RlGraphicsDispatch)|$80),.lobyte(.bank(RlDrawDispatch)|$80),.lobyte(.bank(JnInventoryDeathDispatch)|$80),.lobyte(.bank(JnVisibleDispatch)|$80),.lobyte(.bank(Z2SideAdmission)|$80),.lobyte(.bank(BmFresh)|$80),.lobyte(.bank(GmFullBoxGate)|$80),.lobyte(.bank(JnResetDispatch)|$80),.lobyte(.bank(CheatsFullPower)|$80),.lobyte(.bank(BmColors)|$80),.lobyte(.bank(X5StompDispatch)|$80),.lobyte(.bank(Z2HeadWithinTerrain)|$80),.lobyte(.bank(VvUiDispatch)|$80),.lobyte(.bank(GmStompGate)|$80),.lobyte(.bank(KbWorldPaletteIndex)|$80),.lobyte(.bank(GuestPowerupUpdate)|$80),.lobyte(.bank(MmReserveVine)|$80),.lobyte(.bank(DkMovement)|$80),.lobyte(.bank(DkHostGraphics)|$80),.lobyte(.bank(DkHostWeapons)|$80),.lobyte(.bank(DkHostInjury)|$80),.lobyte(.bank(DkHostHead)|$80),.lobyte(.bank(HuDkPrepare)|$80),.lobyte(.bank(DkHostPowerup)|$80),.lobyte(.bank(DkHostVine)|$80),.lobyte(.bank(DpGameLate)|$80),.lobyte(.bank(DpAdmissionPortrait)|$80),.lobyte(.bank(DpPlatformWeapons)|$80),.lobyte(.bank(DpHostVisible)|$80),.lobyte(.bank(DpAdmissionFresh)|$80),.lobyte(.bank(MaaBox)|$80),.lobyte(.bank(DpGamePrivate)|$80),.lobyte(.bank(RdLifeMovement)|$80),.lobyte(.bank(RdLifeGraphics)|$80),.lobyte(.bank(RdUiPortrait)|$80),.lobyte(.bank(RdWxSamusGate)|$80),.lobyte(.bank(RdHzInjury)|$80),.lobyte(.bank(RdLifeDeathStart)|$80),.lobyte(.bank(RdLifeFresh)|$80),.lobyte(.bank(RdBodyBox)|$80),.lobyte(.bank(RdUiName)|$80),.lobyte(.bank(RdItPrivate)|$80),.lobyte(.bank(RdBodyColors)|$80),.lobyte(.bank(RdWxBounce)|$80),.lobyte(.bank(RdUiEarly)|$80)
.assert >JnMovementDispatch=>JnMovementDispatch,lderror,"Actual64 pair high0"
.assert .bank(JnMovementDispatch)=.bank(JnMovementDispatch),lderror,"Actual64 pair bank0"
.assert >RlGraphicsDispatch=>RlGraphicsDispatch,lderror,"Actual64 pair high1"
.assert .bank(RlGraphicsDispatch)=.bank(RlGraphicsDispatch),lderror,"Actual64 pair bank1"
.assert >RlDrawDispatch=>RlDrawDispatch,lderror,"Actual64 pair high2"
.assert .bank(RlDrawDispatch)=.bank(RlDrawDispatch),lderror,"Actual64 pair bank2"
.assert >JnPortraitDispatch=>JnMovementDispatch,lderror,"Actual64 pair high3"
.assert .bank(JnPortraitDispatch)=.bank(JnMovementDispatch),lderror,"Actual64 pair bank3"
.assert >JnWeaponsDispatch=>JnMovementDispatch,lderror,"Actual64 pair high4"
.assert .bank(JnWeaponsDispatch)=.bank(JnMovementDispatch),lderror,"Actual64 pair bank4"
.assert >JnInjuryStartDispatch=>JnMovementDispatch,lderror,"Actual64 pair high5"
.assert .bank(JnInjuryStartDispatch)=.bank(JnMovementDispatch),lderror,"Actual64 pair bank5"
.assert >JnInjuryStatusDispatch=>JnMovementDispatch,lderror,"Actual64 pair high6"
.assert .bank(JnInjuryStatusDispatch)=.bank(JnMovementDispatch),lderror,"Actual64 pair bank6"
.assert >JnInventoryDeathDispatch=>JnInventoryDeathDispatch,lderror,"Actual64 pair high7"
.assert .bank(JnInventoryDeathDispatch)=.bank(JnInventoryDeathDispatch),lderror,"Actual64 pair bank7"
.assert >JnDeathDispatch=>JnMovementDispatch,lderror,"Actual64 pair high8"
.assert .bank(JnDeathDispatch)=.bank(JnMovementDispatch),lderror,"Actual64 pair bank8"
.assert >JnVisibleDispatch=>JnVisibleDispatch,lderror,"Actual64 pair high9"
.assert .bank(JnVisibleDispatch)=.bank(JnVisibleDispatch),lderror,"Actual64 pair bank9"
.assert >JnHeadDispatch=>JnInventoryDeathDispatch,lderror,"Actual64 pair high10"
.assert .bank(JnHeadDispatch)=.bank(JnInventoryDeathDispatch),lderror,"Actual64 pair bank10"
.assert >JnBodyDispatch=>JnInventoryDeathDispatch,lderror,"Actual64 pair high11"
.assert .bank(JnBodyDispatch)=.bank(JnInventoryDeathDispatch),lderror,"Actual64 pair bank11"
.assert >RlAdderDispatch=>RlGraphicsDispatch,lderror,"Actual64 pair high12"
.assert .bank(RlAdderDispatch)=.bank(RlGraphicsDispatch),lderror,"Actual64 pair bank12"
.assert >RlBoxDispatch=>RlGraphicsDispatch,lderror,"Actual64 pair high13"
.assert .bank(RlBoxDispatch)=.bank(RlGraphicsDispatch),lderror,"Actual64 pair bank13"
.assert >Z2SideAdmission=>Z2SideAdmission,lderror,"Actual64 pair high14"
.assert .bank(Z2SideAdmission)=.bank(Z2SideAdmission),lderror,"Actual64 pair bank14"
.assert >BmFresh=>BmFresh,lderror,"Actual64 pair high15"
.assert .bank(BmFresh)=.bank(BmFresh),lderror,"Actual64 pair bank15"
.assert >GmFullBoxGate=>GmFullBoxGate,lderror,"Actual64 pair high16"
.assert .bank(GmFullBoxGate)=.bank(GmFullBoxGate),lderror,"Actual64 pair bank16"
.assert >KmPortrait=>BmFresh,lderror,"Actual64 pair high17"
.assert .bank(KmPortrait)=.bank(BmFresh),lderror,"Actual64 pair bank17"
.assert >GmMenuNameGate=>GmFullBoxGate,lderror,"Actual64 pair high18"
.assert .bank(GmMenuNameGate)=.bank(GmFullBoxGate),lderror,"Actual64 pair bank18"
.assert >JnResetDispatch=>JnResetDispatch,lderror,"Actual64 pair high19"
.assert .bank(JnResetDispatch)=.bank(JnResetDispatch),lderror,"Actual64 pair bank19"
.assert >JnPrepareDispatch=>JnResetDispatch,lderror,"Actual64 pair high20"
.assert .bank(JnPrepareDispatch)=.bank(JnResetDispatch),lderror,"Actual64 pair bank20"
.assert >JnRiseDispatch=>JnResetDispatch,lderror,"Actual64 pair high21"
.assert .bank(JnRiseDispatch)=.bank(JnResetDispatch),lderror,"Actual64 pair bank21"
.assert >JnPrivateDispatch=>JnResetDispatch,lderror,"Actual64 pair high22"
.assert .bank(JnPrivateDispatch)=.bank(JnResetDispatch),lderror,"Actual64 pair bank22"
.assert >JnCollisionDispatch=>JnResetDispatch,lderror,"Actual64 pair high23"
.assert .bank(JnCollisionDispatch)=.bank(JnResetDispatch),lderror,"Actual64 pair bank23"
.assert >JnPickupDispatch=>JnInventoryDeathDispatch,lderror,"Actual64 pair high24"
.assert .bank(JnPickupDispatch)=.bank(JnInventoryDeathDispatch),lderror,"Actual64 pair bank24"
.assert >CheatsFullPower=>CheatsFullPower,lderror,"Actual64 pair high25"
.assert .bank(CheatsFullPower)=.bank(CheatsFullPower),lderror,"Actual64 pair bank25"
.assert >BmColors=>BmColors,lderror,"Actual64 pair high26"
.assert .bank(BmColors)=.bank(BmColors),lderror,"Actual64 pair bank26"
.assert >X5StompDispatch=>X5StompDispatch,lderror,"Actual64 pair high27"
.assert .bank(X5StompDispatch)=.bank(X5StompDispatch),lderror,"Actual64 pair bank27"
.assert >Z2HeadWithinTerrain=>Z2HeadWithinTerrain,lderror,"Actual64 pair high28"
.assert .bank(Z2HeadWithinTerrain)=.bank(Z2HeadWithinTerrain),lderror,"Actual64 pair bank28"
.assert >VvUiDispatch=>VvUiDispatch,lderror,"Actual64 pair high29"
.assert .bank(VvUiDispatch)=.bank(VvUiDispatch),lderror,"Actual64 pair bank29"
.assert >JnStatusName=>JnVisibleDispatch,lderror,"Actual64 pair high30"
.assert .bank(JnStatusName)=.bank(JnVisibleDispatch),lderror,"Actual64 pair bank30"
.assert >GmStompGate=>GmStompGate,lderror,"Actual64 pair high31"
.assert .bank(GmStompGate)=.bank(GmStompGate),lderror,"Actual64 pair bank31"
.assert >KbWorldPaletteIndex=>KbWorldPaletteIndex,lderror,"Actual64 pair high32"
.assert .bank(KbWorldPaletteIndex)=.bank(KbWorldPaletteIndex),lderror,"Actual64 pair bank32"
.assert >GuestPowerupUpdate=>GuestPowerupUpdate,lderror,"Actual64 pair high33"
.assert .bank(GuestPowerupUpdate)=.bank(GuestPowerupUpdate),lderror,"Actual64 pair bank33"
.assert >RlWeaponsDispatch=>RlDrawDispatch,lderror,"Actual64 pair high34"
.assert .bank(RlWeaponsDispatch)=.bank(RlDrawDispatch),lderror,"Actual64 pair bank34"
.assert >MmReserveVine=>MmReserveVine,lderror,"Actual64 pair high35"
.assert .bank(MmReserveVine)=.bank(MmReserveVine),lderror,"Actual64 pair bank35"
.assert >DkMovement=>DkMovement,lderror,"Actual64 pair high36"
.assert .bank(DkMovement)=.bank(DkMovement),lderror,"Actual64 pair bank36"
.assert >DkHostGraphics=>DkHostGraphics,lderror,"Actual64 pair high37"
.assert .bank(DkHostGraphics)=.bank(DkHostGraphics),lderror,"Actual64 pair bank37"
.assert >DkHostDraw=>DkHostGraphics,lderror,"Actual64 pair high38"
.assert .bank(DkHostDraw)=.bank(DkHostGraphics),lderror,"Actual64 pair bank38"
.assert >DkHostPortrait=>DkHostGraphics,lderror,"Actual64 pair high39"
.assert .bank(DkHostPortrait)=.bank(DkHostGraphics),lderror,"Actual64 pair bank39"
.assert >DkHostWeapons=>DkHostWeapons,lderror,"Actual64 pair high40"
.assert .bank(DkHostWeapons)=.bank(DkHostWeapons),lderror,"Actual64 pair bank40"
.assert >DkHostInjury=>DkHostInjury,lderror,"Actual64 pair high41"
.assert .bank(DkHostInjury)=.bank(DkHostInjury),lderror,"Actual64 pair bank41"
.assert >DkHostInjuryStatus=>DkHostInjury,lderror,"Actual64 pair high42"
.assert .bank(DkHostInjuryStatus)=.bank(DkHostInjury),lderror,"Actual64 pair bank42"
.assert >DkHostDeathStart=>DkHostInjury,lderror,"Actual64 pair high43"
.assert .bank(DkHostDeathStart)=.bank(DkHostInjury),lderror,"Actual64 pair bank43"
.assert >DkHostDeath=>DkHostInjury,lderror,"Actual64 pair high44"
.assert .bank(DkHostDeath)=.bank(DkHostInjury),lderror,"Actual64 pair bank44"
.assert >DkHostVisible=>DkHostInjury,lderror,"Actual64 pair high45"
.assert .bank(DkHostVisible)=.bank(DkHostInjury),lderror,"Actual64 pair bank45"
.assert >DkHostHead=>DkHostHead,lderror,"Actual64 pair high46"
.assert .bank(DkHostHead)=.bank(DkHostHead),lderror,"Actual64 pair bank46"
.assert >DkHostBody=>DkHostInjury,lderror,"Actual64 pair high47"
.assert .bank(DkHostBody)=.bank(DkHostInjury),lderror,"Actual64 pair bank47"
.assert >DkHostAdder=>DkHostWeapons,lderror,"Actual64 pair high48"
.assert .bank(DkHostAdder)=.bank(DkHostWeapons),lderror,"Actual64 pair bank48"
.assert >DkHostBoxProfile=>DkHostWeapons,lderror,"Actual64 pair high49"
.assert .bank(DkHostBoxProfile)=.bank(DkHostWeapons),lderror,"Actual64 pair bank49"
.assert >DkHostSide=>DkHostHead,lderror,"Actual64 pair high50"
.assert .bank(DkHostSide)=.bank(DkHostHead),lderror,"Actual64 pair bank50"
.assert >DkHostFresh=>DkHostGraphics,lderror,"Actual64 pair high51"
.assert .bank(DkHostFresh)=.bank(DkHostGraphics),lderror,"Actual64 pair bank51"
.assert >DkHostBoxGate=>DkHostWeapons,lderror,"Actual64 pair high52"
.assert .bank(DkHostBoxGate)=.bank(DkHostWeapons),lderror,"Actual64 pair bank52"
.assert >KmPortrait=>BmFresh,lderror,"Actual64 pair high53"
.assert .bank(KmPortrait)=.bank(BmFresh),lderror,"Actual64 pair bank53"
.assert >DkHostMenuName=>DkHostGraphics,lderror,"Actual64 pair high54"
.assert .bank(DkHostMenuName)=.bank(DkHostGraphics),lderror,"Actual64 pair bank54"
.assert >DkHostReset=>DkHostGraphics,lderror,"Actual64 pair high55"
.assert .bank(DkHostReset)=.bank(DkHostGraphics),lderror,"Actual64 pair bank55"
.assert >HuDkPrepare=>HuDkPrepare,lderror,"Actual64 pair high56"
.assert .bank(HuDkPrepare)=.bank(HuDkPrepare),lderror,"Actual64 pair bank56"
.assert >GmNativeNoop=>GmFullBoxGate,lderror,"Actual64 pair high57"
.assert .bank(GmNativeNoop)=.bank(GmFullBoxGate),lderror,"Actual64 pair bank57"
.assert >GmNativeNoop=>GmFullBoxGate,lderror,"Actual64 pair high58"
.assert .bank(GmNativeNoop)=.bank(GmFullBoxGate),lderror,"Actual64 pair bank58"
.assert >GmMatureOwn=>GmFullBoxGate,lderror,"Actual64 pair high59"
.assert .bank(GmMatureOwn)=.bank(GmFullBoxGate),lderror,"Actual64 pair bank59"
.assert >DkHostCollect=>DkHostInjury,lderror,"Actual64 pair high60"
.assert .bank(DkHostCollect)=.bank(DkHostInjury),lderror,"Actual64 pair bank60"
.assert >DkFullPower=>DkMovement,lderror,"Actual64 pair high61"
.assert .bank(DkFullPower)=.bank(DkMovement),lderror,"Actual64 pair bank61"
.assert >DkHostColors=>DkHostGraphics,lderror,"Actual64 pair high62"
.assert .bank(DkHostColors)=.bank(DkHostGraphics),lderror,"Actual64 pair bank62"
.assert >X5StompDispatch=>X5StompDispatch,lderror,"Actual64 pair high63"
.assert .bank(X5StompDispatch)=.bank(X5StompDispatch),lderror,"Actual64 pair bank63"
.assert >Z2HeadWithinTerrain=>Z2HeadWithinTerrain,lderror,"Actual64 pair high64"
.assert .bank(Z2HeadWithinTerrain)=.bank(Z2HeadWithinTerrain),lderror,"Actual64 pair bank64"
.assert >DkHostUi=>DkHostInjury,lderror,"Actual64 pair high65"
.assert .bank(DkHostUi)=.bank(DkHostInjury),lderror,"Actual64 pair bank65"
.assert >DkHostName=>DkHostInjury,lderror,"Actual64 pair high66"
.assert .bank(DkHostName)=.bank(DkHostInjury),lderror,"Actual64 pair bank66"
.assert >GmStompGate=>GmStompGate,lderror,"Actual64 pair high67"
.assert .bank(GmStompGate)=.bank(GmStompGate),lderror,"Actual64 pair bank67"
.assert >HuNativeWorldPalette=>HuDkPrepare,lderror,"Actual64 pair high68"
.assert .bank(HuNativeWorldPalette)=.bank(HuDkPrepare),lderror,"Actual64 pair bank68"
.assert >DkHostPowerup=>DkHostPowerup,lderror,"Actual64 pair high69"
.assert .bank(DkHostPowerup)=.bank(DkHostPowerup),lderror,"Actual64 pair bank69"
.assert >DkHostWeapons=>DkHostWeapons,lderror,"Actual64 pair high70"
.assert .bank(DkHostWeapons)=.bank(DkHostWeapons),lderror,"Actual64 pair bank70"
.assert >DkHostVine=>DkHostVine,lderror,"Actual64 pair high71"
.assert .bank(DkHostVine)=.bank(DkHostVine),lderror,"Actual64 pair bank71"
.assert >JnMovementDispatch=>JnMovementDispatch,lderror,"Actual64 pair high72"
.assert .bank(JnMovementDispatch)=.bank(JnMovementDispatch),lderror,"Actual64 pair bank72"
.assert >DpGameLate=>DpGameLate,lderror,"Actual64 pair high73"
.assert .bank(DpGameLate)=.bank(DpGameLate),lderror,"Actual64 pair bank73"
.assert >DpGameDraw=>DpGameLate,lderror,"Actual64 pair high74"
.assert .bank(DpGameDraw)=.bank(DpGameLate),lderror,"Actual64 pair bank74"
.assert >DpAdmissionPortrait=>DpAdmissionPortrait,lderror,"Actual64 pair high75"
.assert .bank(DpAdmissionPortrait)=.bank(DpAdmissionPortrait),lderror,"Actual64 pair bank75"
.assert >DpPlatformWeapons=>DpPlatformWeapons,lderror,"Actual64 pair high76"
.assert .bank(DpPlatformWeapons)=.bank(DpPlatformWeapons),lderror,"Actual64 pair bank76"
.assert >DpGameInjury=>DpGameLate,lderror,"Actual64 pair high77"
.assert .bank(DpGameInjury)=.bank(DpGameLate),lderror,"Actual64 pair bank77"
.assert >DpGameStatus=>DpGameLate,lderror,"Actual64 pair high78"
.assert .bank(DpGameStatus)=.bank(DpGameLate),lderror,"Actual64 pair bank78"
.assert >DpGameDeathStart=>DpGameLate,lderror,"Actual64 pair high79"
.assert .bank(DpGameDeathStart)=.bank(DpGameLate),lderror,"Actual64 pair bank79"
.assert >JnDeathDispatch=>JnMovementDispatch,lderror,"Actual64 pair high80"
.assert .bank(JnDeathDispatch)=.bank(JnMovementDispatch),lderror,"Actual64 pair bank80"
.assert >DpHostVisible=>DpHostVisible,lderror,"Actual64 pair high81"
.assert .bank(DpHostVisible)=.bank(DpHostVisible),lderror,"Actual64 pair bank81"
.assert >JnHeadDispatch=>JnInventoryDeathDispatch,lderror,"Actual64 pair high82"
.assert .bank(JnHeadDispatch)=.bank(JnInventoryDeathDispatch),lderror,"Actual64 pair bank82"
.assert >DpGameBody=>DpGameLate,lderror,"Actual64 pair high83"
.assert .bank(DpGameBody)=.bank(DpGameLate),lderror,"Actual64 pair bank83"
.assert >RlAdderDispatch=>RlGraphicsDispatch,lderror,"Actual64 pair high84"
.assert .bank(RlAdderDispatch)=.bank(RlGraphicsDispatch),lderror,"Actual64 pair bank84"
.assert >RlBoxDispatch=>RlGraphicsDispatch,lderror,"Actual64 pair high85"
.assert .bank(RlBoxDispatch)=.bank(RlGraphicsDispatch),lderror,"Actual64 pair bank85"
.assert >Z2SideAdmission=>Z2SideAdmission,lderror,"Actual64 pair high86"
.assert .bank(Z2SideAdmission)=.bank(Z2SideAdmission),lderror,"Actual64 pair bank86"
.assert >DpAdmissionFresh=>DpAdmissionFresh,lderror,"Actual64 pair high87"
.assert .bank(DpAdmissionFresh)=.bank(DpAdmissionFresh),lderror,"Actual64 pair bank87"
.assert >MaaBox=>MaaBox,lderror,"Actual64 pair high88"
.assert .bank(MaaBox)=.bank(MaaBox),lderror,"Actual64 pair bank88"
.assert >KmPortrait=>BmFresh,lderror,"Actual64 pair high89"
.assert .bank(KmPortrait)=.bank(BmFresh),lderror,"Actual64 pair bank89"
.assert >DpAdmissionMenuName=>DpAdmissionFresh,lderror,"Actual64 pair high90"
.assert .bank(DpAdmissionMenuName)=.bank(DpAdmissionFresh),lderror,"Actual64 pair bank90"
.assert >DpAdmissionReset=>DpAdmissionFresh,lderror,"Actual64 pair high91"
.assert .bank(DpAdmissionReset)=.bank(DpAdmissionFresh),lderror,"Actual64 pair bank91"
.assert >DpGamePrepare=>DpGameLate,lderror,"Actual64 pair high92"
.assert .bank(DpGamePrepare)=.bank(DpGameLate),lderror,"Actual64 pair bank92"
.assert >DpGameRise=>DpGameLate,lderror,"Actual64 pair high93"
.assert .bank(DpGameRise)=.bank(DpGameLate),lderror,"Actual64 pair bank93"
.assert >DpGamePrivate=>DpGamePrivate,lderror,"Actual64 pair high94"
.assert .bank(DpGamePrivate)=.bank(DpGamePrivate),lderror,"Actual64 pair bank94"
.assert >DpGameCollision=>DpGamePrivate,lderror,"Actual64 pair high95"
.assert .bank(DpGameCollision)=.bank(DpGamePrivate),lderror,"Actual64 pair bank95"
.assert >DpGamePickup=>DpGamePrivate,lderror,"Actual64 pair high96"
.assert .bank(DpGamePickup)=.bank(DpGamePrivate),lderror,"Actual64 pair bank96"
.assert >CheatsFullPower=>CheatsFullPower,lderror,"Actual64 pair high97"
.assert .bank(CheatsFullPower)=.bank(CheatsFullPower),lderror,"Actual64 pair bank97"
.assert >DpAdmissionColors=>DpAdmissionFresh,lderror,"Actual64 pair high98"
.assert .bank(DpAdmissionColors)=.bank(DpAdmissionFresh),lderror,"Actual64 pair bank98"
.assert >DpGameBounce=>DpGamePrivate,lderror,"Actual64 pair high99"
.assert .bank(DpGameBounce)=.bank(DpGamePrivate),lderror,"Actual64 pair bank99"
.assert >Z2HeadWithinTerrain=>Z2HeadWithinTerrain,lderror,"Actual64 pair high100"
.assert .bank(Z2HeadWithinTerrain)=.bank(Z2HeadWithinTerrain),lderror,"Actual64 pair bank100"
.assert >DpAdmissionEarly=>DpAdmissionFresh,lderror,"Actual64 pair high101"
.assert .bank(DpAdmissionEarly)=.bank(DpAdmissionFresh),lderror,"Actual64 pair bank101"
.assert >DpAdmissionStatusName=>DpAdmissionFresh,lderror,"Actual64 pair high102"
.assert .bank(DpAdmissionStatusName)=.bank(DpAdmissionFresh),lderror,"Actual64 pair bank102"
.assert >DpGameBounce=>DpGamePrivate,lderror,"Actual64 pair high103"
.assert .bank(DpGameBounce)=.bank(DpGamePrivate),lderror,"Actual64 pair bank103"
.assert >KbWorldPaletteIndex=>KbWorldPaletteIndex,lderror,"Actual64 pair high104"
.assert .bank(KbWorldPaletteIndex)=.bank(KbWorldPaletteIndex),lderror,"Actual64 pair bank104"
.assert >GuestPowerupUpdate=>GuestPowerupUpdate,lderror,"Actual64 pair high105"
.assert .bank(GuestPowerupUpdate)=.bank(GuestPowerupUpdate),lderror,"Actual64 pair bank105"
.assert >RlWeaponsDispatch=>RlDrawDispatch,lderror,"Actual64 pair high106"
.assert .bank(RlWeaponsDispatch)=.bank(RlDrawDispatch),lderror,"Actual64 pair bank106"
.assert >DpGameVine=>DpGamePrivate,lderror,"Actual64 pair high107"
.assert .bank(DpGameVine)=.bank(DpGamePrivate),lderror,"Actual64 pair bank107"
.assert >RdLifeMovement=>RdLifeMovement,lderror,"Actual64 pair high108"
.assert .bank(RdLifeMovement)=.bank(RdLifeMovement),lderror,"Actual64 pair bank108"
.assert >RdLifeGraphics=>RdLifeGraphics,lderror,"Actual64 pair high109"
.assert .bank(RdLifeGraphics)=.bank(RdLifeGraphics),lderror,"Actual64 pair bank109"
.assert >RlDrawDispatch=>RlDrawDispatch,lderror,"Actual64 pair high110"
.assert .bank(RlDrawDispatch)=.bank(RlDrawDispatch),lderror,"Actual64 pair bank110"
.assert >RdUiPortrait=>RdUiPortrait,lderror,"Actual64 pair high111"
.assert .bank(RdUiPortrait)=.bank(RdUiPortrait),lderror,"Actual64 pair bank111"
.assert >RdWxSamusGate=>RdWxSamusGate,lderror,"Actual64 pair high112"
.assert .bank(RdWxSamusGate)=.bank(RdWxSamusGate),lderror,"Actual64 pair bank112"
.assert >RdHzInjury=>RdHzInjury,lderror,"Actual64 pair high113"
.assert .bank(RdHzInjury)=.bank(RdHzInjury),lderror,"Actual64 pair bank113"
.assert >RdLifeStatus=>RdLifeMovement,lderror,"Actual64 pair high114"
.assert .bank(RdLifeStatus)=.bank(RdLifeMovement),lderror,"Actual64 pair bank114"
.assert >RdLifeDeathStart=>RdLifeDeathStart,lderror,"Actual64 pair high115"
.assert .bank(RdLifeDeathStart)=.bank(RdLifeDeathStart),lderror,"Actual64 pair bank115"
.assert >RdLifeDeathTick=>RdLifeDeathStart,lderror,"Actual64 pair high116"
.assert .bank(RdLifeDeathTick)=.bank(RdLifeDeathStart),lderror,"Actual64 pair bank116"
.assert >RdLifeVisible=>RdLifeMovement,lderror,"Actual64 pair high117"
.assert .bank(RdLifeVisible)=.bank(RdLifeMovement),lderror,"Actual64 pair bank117"
.assert >JnHeadDispatch=>JnInventoryDeathDispatch,lderror,"Actual64 pair high118"
.assert .bank(JnHeadDispatch)=.bank(JnInventoryDeathDispatch),lderror,"Actual64 pair bank118"
.assert >RdLifeBody=>RdLifeDeathStart,lderror,"Actual64 pair high119"
.assert .bank(RdLifeBody)=.bank(RdLifeDeathStart),lderror,"Actual64 pair bank119"
.assert >RlAdderDispatch=>RlGraphicsDispatch,lderror,"Actual64 pair high120"
.assert .bank(RlAdderDispatch)=.bank(RlGraphicsDispatch),lderror,"Actual64 pair bank120"
.assert >RlBoxDispatch=>RlGraphicsDispatch,lderror,"Actual64 pair high121"
.assert .bank(RlBoxDispatch)=.bank(RlGraphicsDispatch),lderror,"Actual64 pair bank121"
.assert >Z2SideAdmission=>Z2SideAdmission,lderror,"Actual64 pair high122"
.assert .bank(Z2SideAdmission)=.bank(Z2SideAdmission),lderror,"Actual64 pair bank122"
.assert >RdLifeFresh=>RdLifeFresh,lderror,"Actual64 pair high123"
.assert .bank(RdLifeFresh)=.bank(RdLifeFresh),lderror,"Actual64 pair bank123"
.assert >RdBodyBox=>RdBodyBox,lderror,"Actual64 pair high124"
.assert .bank(RdBodyBox)=.bank(RdBodyBox),lderror,"Actual64 pair bank124"
.assert >KmPortrait=>BmFresh,lderror,"Actual64 pair high125"
.assert .bank(KmPortrait)=.bank(BmFresh),lderror,"Actual64 pair bank125"
.assert >RdUiName=>RdUiName,lderror,"Actual64 pair high126"
.assert .bank(RdUiName)=.bank(RdUiName),lderror,"Actual64 pair bank126"
.assert >JnResetDispatch=>JnResetDispatch,lderror,"Actual64 pair high127"
.assert .bank(JnResetDispatch)=.bank(JnResetDispatch),lderror,"Actual64 pair bank127"
.assert >RdItPrepare=>RdHzInjury,lderror,"Actual64 pair high128"
.assert .bank(RdItPrepare)=.bank(RdHzInjury),lderror,"Actual64 pair bank128"
.assert >JnRiseDispatch=>JnResetDispatch,lderror,"Actual64 pair high129"
.assert .bank(JnRiseDispatch)=.bank(JnResetDispatch),lderror,"Actual64 pair bank129"
.assert >RdItPrivate=>RdItPrivate,lderror,"Actual64 pair high130"
.assert .bank(RdItPrivate)=.bank(RdItPrivate),lderror,"Actual64 pair bank130"
.assert >RdItCollision=>RdItPrivate,lderror,"Actual64 pair high131"
.assert .bank(RdItCollision)=.bank(RdItPrivate),lderror,"Actual64 pair bank131"
.assert >RdItPickup=>RdItPrivate,lderror,"Actual64 pair high132"
.assert .bank(RdItPickup)=.bank(RdItPrivate),lderror,"Actual64 pair bank132"
.assert >CheatsFullPower=>CheatsFullPower,lderror,"Actual64 pair high133"
.assert .bank(CheatsFullPower)=.bank(CheatsFullPower),lderror,"Actual64 pair bank133"
.assert >RdBodyColors=>RdBodyColors,lderror,"Actual64 pair high134"
.assert .bank(RdBodyColors)=.bank(RdBodyColors),lderror,"Actual64 pair bank134"
.assert >RdWxBounce=>RdWxBounce,lderror,"Actual64 pair high135"
.assert .bank(RdWxBounce)=.bank(RdWxBounce),lderror,"Actual64 pair bank135"
.assert >Z2HeadWithinTerrain=>Z2HeadWithinTerrain,lderror,"Actual64 pair high136"
.assert .bank(Z2HeadWithinTerrain)=.bank(Z2HeadWithinTerrain),lderror,"Actual64 pair bank136"
.assert >RdUiEarly=>RdUiEarly,lderror,"Actual64 pair high137"
.assert .bank(RdUiEarly)=.bank(RdUiEarly),lderror,"Actual64 pair bank137"
.assert >RdUiStatus=>RdUiName,lderror,"Actual64 pair high138"
.assert .bank(RdUiStatus)=.bank(RdUiName),lderror,"Actual64 pair bank138"
.assert >RdWxBounce=>RdWxBounce,lderror,"Actual64 pair high139"
.assert .bank(RdWxBounce)=.bank(RdWxBounce),lderror,"Actual64 pair bank139"
.assert >KbWorldPaletteIndex=>KbWorldPaletteIndex,lderror,"Actual64 pair high140"
.assert .bank(KbWorldPaletteIndex)=.bank(KbWorldPaletteIndex),lderror,"Actual64 pair bank140"
.assert >GuestPowerupUpdate=>GuestPowerupUpdate,lderror,"Actual64 pair high141"
.assert .bank(GuestPowerupUpdate)=.bank(GuestPowerupUpdate),lderror,"Actual64 pair bank141"
.assert >RdWxRemainingGate=>RdWxSamusGate,lderror,"Actual64 pair high142"
.assert .bank(RdWxRemainingGate)=.bank(RdWxSamusGate),lderror,"Actual64 pair bank142"
.assert >MmReserveVine=>MmReserveVine,lderror,"Actual64 pair high143"
.assert .bank(MmReserveVine)=.bank(MmReserveVine),lderror,"Actual64 pair bank143"
.assert *<=$ba54,lderror,"Private table compaction must fund BT without shifting public suffix"
.res $0474-(*-HuStart),$ea
.export HuResolve
.proc HuResolve
 php
 pha
 lda SelectedCharacter
 pha
 tsx
 lda $0102,x
 farcall CmHostResolveCharacter
 cmp #26
 beq Gimmick
 cmp #28
 beq DK
 pla
 jmp Done
Gimmick:
 pla
 cmp #26
 beq Done
 farcall GmConstruct
 jmp Done
DK:
 pla
 cmp #28
 bne Construct
 lda CrossoverContinue
 beq Construct
 farcall DkEnsure
 jmp Done
Construct:
 farcall DkConstruct
Done:pla
 plp
 lda SelectedCharacter
 rts
.endproc
.proc HuDkPrepare
 php
 pha
 lda #28
 sta InvPickupOwner,x
 lda #$fc
 sta InvPickup,x
 lda #0
 sta InvRisePhase,x
 sta InvPickupSaveLo,x
 sta InvPickupSaveHi,x
 pla
 plp
 rts
.endproc
.proc HuNativeWorldPalette
 lda AreaType
 asl
 sta R0
 asl
 clc
 adc R0
 adc #6
 tay
 rts
.endproc
.assert .bank(BillHotProject)=126,lderror,"Near Bill projection requires permanent bank126"
.assert BillHotProject >= $8000 .and BillHotProject < $a000,lderror,"Near Bill projection requires permanent low window"
.export HuLegacyPostBG
.proc HuLegacyPostBG
 ; The original resident bridge ran with PLAYER's A bank mapped. Its old
 ; relocated Gimmick copy used near calls while A124 was mapped. These
 ; imports are actual linked functions, including their genuine bank fields.
 jsr HuSlideSmallGap
 jmp :+
ArAfterLo:
 cmp #22
 bne ArLow
 lda #<FwGenAfterTerrain
 bne SetLow
ArLow:
 lda #<ArGenAfterTerrain
SetLow:
 sta FarcallJmpTarget_SMC+1
 pla
 plp
 jmp HuLegacyPostBG::ArAfterHi
 .assert .lobyte(FwGenAfterTerrain)<>0,lderror,"Real FF low-byte shared installer"
 .assert .hibyte(FwGenAfterTerrain)=.hibyte(ArGenAfterTerrain),lderror,"Real common postBG page"
:
 php
 pha
 lda SelectedCharacter
 cmp #CHARACTER_SOPHIA
 beq Project
 cmp #CHARACTER_RYU
 bne Bill
Project:
 farcall CrossoverSourceBodyDispatch
 jmp Done
Bill:
 cmp #CHARACTER_BILL
 bne Done
 lda #2
 jsr BillHotProject
 jmp :+
ArAfterHi:
 lda #>ArGenAfterTerrain
 sta FarcallJmpTarget_SMC+2
 lda #.lobyte(.bank(ArGenAfterTerrain)|$80)
 jmp FarCallCommon
 .res 2,$ea
:
Done:
 pla
 plp
 rts
.endproc

.export HuGmMenuName,HuGmStatusName
.proc HuGmMenuName
 ldx VRAM_Buffer1_Offset
 lda #$23
 sta VRAM_Buffer1,x
 lda #$28
 sta VRAM_Buffer1+1,x
 lda #16
 sta VRAM_Buffer1+2,x
 ldy #0
Copy:lda HuGmName,y
 sta VRAM_Buffer1+3,x
 inx
 iny
 cpy #16
 bne Copy
 txa
 clc
 adc #3
 sta VRAM_Buffer1_Offset
 tax
 lda #0
 sta VRAM_Buffer1,x
 rts
.endproc
.proc HuGmStatusName
 cmp #0
 bne Done
 tya
 pha
 ldy #6
Copy:lda HuGmName+4,y
 sta VRAM_Buffer1+11,y
 dey
 bpl Copy
 pla
 tay
 lda #0
Done:rts
.endproc
HuGmName:.byte "    GIMMICK     "

.export HuAfterTerrainGate
.proc HuAfterTerrainGate
 php
 pha
 jmp HuQuickAfterProbe
::HuQuickAfterOriginal:
 cmp #22
 beq ExtendedPostBG
 cmp #32
 bne OtherPostBG
ExtendedPostBG:
 jmp HuLegacyPostBG::ArAfterLo
OtherPostBG:
 cmp #26
 beq Own
 pla
 plp
 jmp HuLegacyPostBG
Own:
 pla
 plp
 farcall GmAfterTerrain
 farcall GmSyncForm,jmp
.endproc

.export HuPlayerSubs
.proc HuPlayerSubs
 ; This actual36B resident caller formerly paid four nested family farcalls
 ; even for an old owner. Keep classification outside their source kernels.
 php
 pha
 jmp HuQuickBodyProbe
::HuQuickBodyOriginal:
 cmp #26
 beq Gimmick
 cmp #28
 beq DK
 cmp #2
 bne NotRogue
 lda RdVariant
 cmp #1
 beq Rogue
NotRogue:
 jsr MaaOwner
 beq Maaa
 pla
 plp
 farcall LmBoundingBoxGate
 jmp PlayerBGCollision
Gimmick:
 pla
 plp
 farcall GmHostFullBox
 jmp PlayerBGCollision
DK:
 pla
 plp
 farcall DkHostBoxGate
 jmp PlayerBGCollision
Maaa:
 pla
 plp
 farcall MaaBox
 farcall MaaAfterBG,jmp
Rogue:
 pla
 plp
 farcall RdBoxOrExit,jmp
.endproc

.macro HuTailFar Target
 ; Farcall-only private ABI: collapse this worker's synthetic JSR return.
 ; Keep the original saved A-bank and original resident caller return.
 sta SafecallA_SMC+1
 lda #<Target
 sta FarcallJmpTarget_SMC+1
 lda #>Target
 sta FarcallJmpTarget_SMC+2
 lda #.lobyte(.bank(Target)|$80)
 sta NextBank_SMC+1
 pla
 pla
 jmp NextBank_SMC
.endmacro
.export HuUiDirect
.proc HuUiDirect
 ; The only source caller is LmGate's genuine farcall in LmUiGate.
 php
 pha
 lda SelectedCharacter
 cmp #20
 bcs Original
 cmp #2
 beq RogueCheck
 cmp #0
 bne Legacy
 lda MarioVariant
 cmp #4
 beq Original
Legacy:
 pla
 plp
 HuTailFar VvUiDispatch
Original:
 pla
 plp
 HuTailFar NrUi
RogueCheck:
 lda RdVariant
 cmp #1
 bne Legacy
 pla
 plp
 HuTailFar RdUiEarly

.endproc

.include "slide-source.inc"
.export HuVisibleDirect
.proc HuVisibleDirect
 ; Only LmVisibleGate's original genuine farcall admits this private ABI.
 php
 pha
 lda SelectedCharacter
 cmp #20
 bcs Original
 cmp #2
 beq RogueCheck
Legacy:
 pla
 plp
 HuTailFar JnVisibleDispatch
Original:
 pla
 plp
 HuTailFar NrVisible
RogueCheck:
 lda RdVariant
 cmp #1
 bne Legacy
 pla
 plp
 HuTailFar RdLifeVisible

.endproc
.export HuLateUiDirect
.proc HuLateUiDirect
 ; Sole genuine source: ClrPlrPal after LDA StarInvincibleTimer / BEQ.
 ; A=0, live CVDI/X/Y retained; original ResetPalStar kills incoming A/NZ.
 lda SelectedCharacter
 eor #24
 beq Goku
 eor #26
 beq RogueCheck
Legacy:
 lda #0
 HuTailFar S2BoundaryLateUI
Goku:
 HuTailFar DpAdmissionUi
RogueCheck:
 lda RdVariant
 eor #1
 bne Legacy
 HuTailFar RdUiLateReset

.endproc

.export HuGameColdDispatch
.proc HuGameColdDispatch
 php
 pha
 lda SelectedCharacter
 cmp #24
 beq Goku
 cmp #2
 bne Foreign
 lda RdVariant
 cmp #1
 bne Foreign
 pla
 plp
 farcall RdLifeGameRoutines,jmp
Goku:
 pla
 plp
 farcall DpHostCheatGate,jmp
Foreign:
 pla
 plp
 farcall CheatsGameRoutinesGate,jmp
.endproc

; Genuine typed callbacks: immediate linked targets, original one saved bank frame.
.export HuDrawAll
.proc HuDrawAll
 sta SafecallA_SMC+1
 php
 lda SelectedCharacter
 cmp #32
 beq Arthur
 cmp #2
 bne Legacy
 lda RdVariant
 cmp #1
 beq Own
Legacy:
 lda #<SamusFreezeDrawAll
 sta FarcallJmpTarget_SMC+1
 lda #>SamusFreezeDrawAll
 sta FarcallJmpTarget_SMC+2
 lda #.lobyte(.bank(SamusFreezeDrawAll)|$80)
 jmp HuSourceCallbackTail
::HuQuickBodyProbe:
 lda SelectedCharacter
 jmp HuQuickBodyCompare
Own:
 lda #<DrawAllMetasprites
 sta FarcallJmpTarget_SMC+1
 lda #>DrawAllMetasprites
 sta FarcallJmpTarget_SMC+2
 lda #.lobyte(.bank(DrawAllMetasprites)|$80)
 jmp HuSourceCallbackTail
Arthur:
 lda #<ArGenDrawAll
 sta FarcallJmpTarget_SMC+1
 lda #>ArGenDrawAll
 sta FarcallJmpTarget_SMC+2
 lda #.lobyte(.bank(ArGenDrawAll)|$80)
 jmp HuSourceCallbackTail
.endproc
.export HuSamusShots
.proc HuSamusShots
 ; Exact original SamusDrawShots foreign prefix/return, after a preserved probe.
 php
 pha
 lda SelectedCharacter
 cmp #2
 beq Slow
 pla
 plp
 lda SelectedCharacter
 cmp #2
 rts
Slow:
 pla
 plp
 sta SafecallA_SMC+1
 php
 lda SelectedCharacter
 cmp #2
 bne Legacy
 lda RdVariant
 cmp #1
 beq Own
Legacy:
 lda #<SamusDrawShots
 sta FarcallJmpTarget_SMC+1
 lda #>SamusDrawShots
 sta FarcallJmpTarget_SMC+2
 lda #.lobyte(.bank(SamusDrawShots)|$80)
::HuSourceCallbackTail:
 sta NextBank_SMC+1
 plp
 pla
 pla
 jmp NextBank_SMC
Own:
 lda #<RdWxDraw
 sta FarcallJmpTarget_SMC+1
 lda #>RdWxDraw
 sta FarcallJmpTarget_SMC+2
 lda #.lobyte(.bank(RdWxDraw)|$80)
 jmp HuSourceCallbackTail
.endproc
.export HuBeforeEffects
.proc HuBeforeEffects
 sta SafecallA_SMC+1
 php
 lda SelectedCharacter
 cmp #2
 bne Legacy
 lda RdVariant
 cmp #1
 beq Own
Legacy:
 lda #<LsrEffectsBeforeEnemies
 sta FarcallJmpTarget_SMC+1
 lda #>LsrEffectsBeforeEnemies
 sta FarcallJmpTarget_SMC+2
 lda #.lobyte(.bank(LsrEffectsBeforeEnemies)|$80)
 jmp HuSourceCallbackTail
::HuQuickAfterProbe:
 lda SelectedCharacter
 jmp HuQuickAfterCompare
Own:
 lda #<RdWxBeforeEffects
 sta FarcallJmpTarget_SMC+1
 lda #>RdWxBeforeEffects
 sta FarcallJmpTarget_SMC+2
 lda #.lobyte(.bank(RdWxBeforeEffects)|$80)
 jmp HuSourceCallbackTail
.endproc
.export HuAfterEffects
.proc HuAfterEffects
 sta SafecallA_SMC+1
 php
 lda SelectedCharacter
 cmp #2
 bne Legacy
 lda RdVariant
 cmp #1
 beq Own
Legacy:
 lda #<LsrEffectsAfterEnemies
 sta FarcallJmpTarget_SMC+1
 lda #>LsrEffectsAfterEnemies
 sta FarcallJmpTarget_SMC+2
 lda #.lobyte(.bank(LsrEffectsAfterEnemies)|$80)
 jmp HuSourceCallbackTail
Own:
 lda #<RdWxAfterEffects
 sta FarcallJmpTarget_SMC+1
 lda #>RdWxAfterEffects
 sta FarcallJmpTarget_SMC+2
 lda #.lobyte(.bank(RdWxAfterEffects)|$80)
 jmp HuSourceCallbackTail
.endproc
.export HuUpdateDrops
.proc HuUpdateDrops
 sta SafecallA_SMC+1
 php
 lda SelectedCharacter
 cmp #2
 bne Legacy
 lda RdVariant
 cmp #1
 beq Own
 lda #2
Legacy:
 ; Replay the real Z2 predicate. Native worker firstLDA kills A/NZ;
 ; retain its genuine C/VDI flags while collapsing the redundant wrapper.
 plp
 jsr HuZ2FromSelected
 php
 bcs ActiveZ2
 lda #<InventoryUpdateDrops
 sta FarcallJmpTarget_SMC+1
 lda #>InventoryUpdateDrops
 sta FarcallJmpTarget_SMC+2
 lda #.lobyte(.bank(InventoryUpdateDrops)|$80)
 jmp HuSourceCallbackTail
ActiveZ2:
 lda #<Z2UpdateDropsGate
 sta FarcallJmpTarget_SMC+1
 lda #>Z2UpdateDropsGate
 sta FarcallJmpTarget_SMC+2
 lda #.lobyte(.bank(Z2UpdateDropsGate)|$80)
 jmp HuSourceCallbackTail
Own:
 lda #<RdHzUpdateDrops
 sta FarcallJmpTarget_SMC+1
 lda #>RdHzUpdateDrops
 sta FarcallJmpTarget_SMC+2
 lda #.lobyte(.bank(RdHzUpdateDrops)|$80)
 jmp HuSourceCallbackTail
.endproc
.export HuRemainingWeapons
.proc HuRemainingWeapons
 sta SafecallA_SMC+1
 php
 lda SelectedCharacter
 cmp #2
 bne Legacy
 lda RdVariant
 cmp #1
 beq Own
 lda #2
Legacy:
 ; Replay the real Z2 predicate. Native worker firstLDA kills A/NZ;
 ; retain its genuine C/VDI flags while collapsing the redundant wrapper.
 plp
 jsr HuZ2FromSelected
 php
 bcs ActiveZ2
 lda #<RemainingWeapons
 sta FarcallJmpTarget_SMC+1
 lda #>RemainingWeapons
 sta FarcallJmpTarget_SMC+2
 lda #.lobyte(.bank(RemainingWeapons)|$80)
 jmp HuSourceCallbackTail
ActiveZ2:
 lda #<Z2RemainingWeaponsGate
 sta FarcallJmpTarget_SMC+1
 lda #>Z2RemainingWeaponsGate
 sta FarcallJmpTarget_SMC+2
 lda #.lobyte(.bank(Z2RemainingWeaponsGate)|$80)
 jmp HuSourceCallbackTail
Own:
 lda #<RdWxRemainingGate
 sta FarcallJmpTarget_SMC+1
 lda #>RdWxRemainingGate
 sta FarcallJmpTarget_SMC+2
 lda #.lobyte(.bank(RdWxRemainingGate)|$80)
 jmp HuSourceCallbackTail
.endproc

; Coordinated55B total: actual long-JEQ14B above +41B here.
; Every operand is a genuine imported source symbol, no raw03->ROM83 error.
; Original A lives in SafecallA; originalY/P remain on the real CPU stack.
HuExtendedFF:
 lda #.lobyte(.bank(FwServiceVeneers)|$80)
ThFFBankReady:
 pha
 lda #>FwServiceVeneers
 sta FarcallJmpTarget_SMC+2
 pla
 bne HuExtendedSet
HuExtendedArthur:
 lda #<ThArExtended
 sta FarcallJmpTarget_SMC+1
 lda #>ThArExtended
 sta FarcallJmpTarget_SMC+2
 lda #.lobyte(.bank(ThArExtended)|$80)
 jsr FarCallCommon
 bne HuExtendedSet
HuExtendedSet:
 sta NextBank_SMC+1
 cpy #36
 bcc HuExtendedValid
 ldy #36
HuExtendedValid:
 tya
 sta FarcallJmpTarget_SMC+1
 asl
 adc FarcallJmpTarget_SMC+1
 sta FarcallJmpTarget_SMC+1
 jmp HuCommon::Restore

HuEnd:
.assert HuEnd<=$c000,lderror,"Union exceeds approved A79 B5E0 tail"

.assert .lobyte(QwService)<>0,lderror,"Quick selector low-byte branch"
.assert .hibyte(QwService)<>0,lderror,"Quick selector high-byte branch"

.assert .lobyte(QwFullBox)<>0 .and .lobyte(QwAfterTerrain)<>0,lderror,"Known-nonzero low-byte branch"
.assert .hibyte(QwFullBox)<>0,lderror,"Known-nonzero high-byte branch"

.assert .hibyte(S2ServiceVeneers)<>0,lderror,"S2 genuine page-high branch"

.assert >ThServiceVeneers=>FwServiceVeneers,lderror,"Actual page-high shared Thomas/FF transport"
.assert .lobyte(ThServiceVeneers)=0,lderror,"Thomas table low-byte0"

.assert <KrServiceVeneers=0,lderror,"Shared zero-low service transport"
.assert >KrServiceVeneers=>FwServiceVeneers,lderror,"Shared real B400 high transport"
