.segment "KR_KERNEL_IMAGE"
.incbin "kr-kernel.bin"
.segment "KR_BODY_CHR"
.incbin "kr-body.chr"
