local HUDChecks,HUDMaps,WorldMaps=0,0,0
L["InvHudActive"]=32158
L["InvHudPhysical"]=32159
L["X5HudChrUpper"]=29677
L["X5WideChrActive"]=29678
local equipmentOption=0
local fixtureAt,activatedAt,firedAt,returnedAt=nil,nil,nil,nil
local optionStock=nil
local equipmentBase,equipmentPeak,flightUp,flightDown=nil,nil,nil,nil
local equipmentDone=false
local function kwrite(off,v)emu.write(2*8192+off,v,emu.memType.nesWorkRam)end
KARNOV_ARGS={["sha256"]="99bf88c8d971f1305f965a21833703c7a11aafa6a24febd9f3bfb7c87ba4bbda",["main_return"]=33621,["background"]={34,34,15,15,15,34,15,15},["chr"]={255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,0,0,0,0,3,7,15,15,0,0,0,0,3,4,8,8,15,11,7,1,0,0,0,0,8,12,7,1,0,0,0,0,0,0,0,0,192,249,62,223,0,0,0,0,192,57,199,230,222,186,122,255,235,115,39,34,101,247,205,136,156,126,57,61,0,0,0,112,168,244,198,191,0,0,0,112,216,12,62,71,108,94,127,223,255,247,119,239,255,183,255,239,59,9,153,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,248,124,124,184,224,0,0,0,248,196,148,216,224,0,0,0,19,18,46,91,86,106,82,97,28,29,61,127,127,127,127,127,64,32,68,67,65,103,63,15,127,63,127,127,127,127,57,0,118,244,216,252,246,170,2,148,138,12,40,44,254,254,254,252,164,196,196,152,200,240,248,248,252,252,252,248,248,240,80,64,0,3,4,11,31,54,63,39,0,3,7,12,16,41,33,56,29,11,7,7,3,1,0,0,23,14,4,4,2,1,0,0,0,0,1,2,7,11,14,27,0,0,1,3,4,12,9,21,251,107,247,63,191,231,95,231,244,157,11,192,64,24,184,254,0,0,192,160,208,16,240,184,0,0,192,96,48,240,16,248,104,252,118,239,157,221,255,255,216,252,186,245,103,35,3,39,165,249,177,190,85,145,35,32,187,246,126,127,223,159,63,63,32,20,56,40,108,118,127,60,63,31,63,63,63,31,15,0,222,250,255,255,173,121,86,228,254,6,3,3,215,255,254,252,72,104,144,10,10,14,124,248,248,248,240,248,248,248,242,196,1,2,3,5,11,11,15,26,1,3,2,6,12,12,8,21,19,15,6,5,3,3,1,0,28,9,7,7,2,2,1,0,0,1,2,7,11,14,27,123,0,1,3,4,12,9,21,116,235,247,255,47,103,223,151,113,157,11,0,208,152,56,126,255,0,192,160,208,16,240,184,104,0,192,96,48,240,16,248,216,254,117,235,205,237,255,255,238,254,191,247,51,19,3,23,254,84,137,222,251,209,208,48,228,219,142,95,255,63,63,255,255,24,17,40,32,32,31,15,7,31,31,63,63,63,31,12,0,250,254,235,165,127,84,140,84,6,2,23,223,255,252,252,252,36,40,240,80,96,192,160,224,252,248,240,240,224,192,128,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,1,2,3,3,7,7,0,0,1,3,2,2,6,4,0,0,1,2,7,11,14,27,0,0,1,3,4,12,9,21,59,203,119,255,239,151,237,243,52,253,139,0,16,104,30,127,0,0,192,160,208,16,240,190,0,0,192,96,48,240,16,254,109,255,119,237,231,247,253,123,219,253,187,243,25,9,3,143,5,7,2,1,0,0,0,0,6,4,3,1,0,0,0,0,0,0,0,0,1,1,1,0,0,0,0,0,0,0,0,0,250,254,251,183,255,140,135,225,157,13,15,220,252,255,255,255,65,225,129,135,130,204,248,240,127,255,255,255,254,252,112,0,246,122,250,118,124,198,18,34,254,134,134,206,252,254,254,254,230,206,130,130,230,126,125,63,254,254,254,254,254,126,100,0,0,3,4,11,15,22,26,31,0,3,7,12,8,25,21,16,11,7,2,1,1,0,0,0,12,5,3,1,1,0,0,0,0,1,2,7,11,14,27,123,0,1,3,4,12,9,21,116,235,247,255,63,231,223,167,237,157,11,0,192,24,56,254,243,0,192,160,208,16,240,184,104,0,192,96,48,240,16,248,216,252,116,230,158,218,254,254,218,252,188,250,102,38,2,38,254,235,87,253,251,214,234,82,97,244,216,190,31,63,255,127,127,64,32,68,67,65,103,62,12,127,63,127,127,127,126,57,3,251,255,251,255,247,170,2,148,7,3,7,13,255,254,254,252,164,196,200,152,208,224,64,128,252,252,248,248,112,96,192,128,252,252,252,252,252,248,224,224,168,200,200,200,224,224,192,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,159,159,147,225,96,64,192,192,111,103,239,223,223,191,255,63,128,0,16,16,240,109,61,15,127,255,239,239,255,250,202,248,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,0,3,4,11,15,22,26,31,0,3,7,12,8,25,21,16,11,7,2,1,1,0,0,0,12,5,3,1,1,0,0,0,0,1,2,7,11,14,27,123,0,1,3,4,12,9,21,116,235,247,255,63,231,223,167,237,157,11,0,192,24,56,254,243,0,192,160,208,16,240,184,104,0,192,96,48,240,16,248,216,252,118,231,159,219,254,254,218,252,186,249,101,39,2,38,254,235,87,253,251,214,234,82,97,244,216,190,31,63,255,127,127,64,32,68,67,65,103,63,15,127,63,127,127,127,127,57,0,251,255,251,254,247,170,2,148,7,3,6,13,255,254,254,252,164,196,196,152,200,240,248,248,252,252,252,248,248,240,80,64,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3,5,15,29,0,0,0,0,3,6,8,18,0,0,0,0,0,0,0,1,0,0,0,0,0,0,0,1,3,5,63,205,109,245,157,223,2,6,60,250,154,14,99,32,0,0,0,0,0,0,224,80,0,0,0,0,0,0,224,176,232,136,120,220,182,255,187,115,24,120,136,252,110,255,223,255,55,47,31,21,11,7,7,3,41,49,19,31,14,4,4,2,1,0,0,0,3,3,15,31,1,0,0,0,1,5,1,3,223,47,207,87,255,242,172,32,48,248,248,108,239,63,127,255,195,66,67,230,191,157,227,255,255,127,127,255,255,255,254,255,219,255,219,231,29,11,143,11,39,3,39,255,255,253,249,253,79,23,7,5,137,126,232,248,253,253,253,255,255,254,128,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,7,57,78,191,243,221,126,0,7,63,113,192,156,166,67,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,113,138,119,250,122,254,158,255,113,251,142,5,133,3,97,224,0,0,0,0,0,0,112,168,0,0,0,0,0,0,112,216,244,196,188,236,218,255,221,185,12,60,68,124,54,127,239,127,119,42,63,29,27,14,0,0,95,62,49,19,21,14,0,0,0,0,0,0,3,3,15,31,0,0,0,0,1,5,1,3,223,95,47,38,31,28,40,49,240,112,56,63,19,31,63,63,67,66,67,230,191,157,227,255,127,127,127,255,255,255,254,255,218,254,218,230,28,8,136,8,38,2,38,254,252,248,248,248,76,20,4,4,136,112,232,248,252,252,252,252,248,240,128,0,0,0,0,0,1,6,11,31,0,0,0,0,1,7,12,16,95,125,94,46,31,15,7,5,96,66,97,49,19,13,6,6,0,3,4,8,240,196,228,244,0,3,7,15,255,59,27,15,210,189,62,254,251,199,204,207,47,67,225,241,252,62,51,48,224,240,232,40,116,244,124,210,224,16,24,216,140,12,252,62,123,236,250,123,94,221,254,68,253,255,253,196,229,103,254,188,2,1,0,0,0,0,0,3,3,1,0,0,0,0,3,5,7,3,3,7,2,0,0,0,1,5,5,1,0,0,0,0,35,248,223,142,208,96,249,127,253,255,255,255,255,127,255,255,31,17,195,62,0,0,0,0,255,255,255,62,0,0,0,0,72,48,224,18,11,12,12,236,184,240,224,240,252,251,251,251,252,139,128,0,0,0,0,0,251,141,128,0,0,0,0,0,0,0,0,3,12,23,46,64,0,0,0,3,15,24,49,127,191,159,135,71,57,4,14,15,199,229,255,127,62,7,15,15,14,21,110,128,23,47,39,237,14,27,113,255,232,208,223,243,223,190,47,43,207,187,55,179,55,127,255,244,244,127,200,204,0,0,0,128,96,120,228,98,0,0,0,128,224,216,220,222,234,194,100,184,64,192,64,64,222,254,252,120,192,192,192,192,15,13,5,6,3,1,3,7,15,15,7,7,3,1,3,7,7,3,2,3,1,0,0,0,7,5,5,4,2,1,0,0,255,147,2,7,195,211,134,14,255,255,255,255,255,255,255,255,60,198,131,130,195,1,0,0,255,199,135,69,4,130,0,0,128,64,32,32,16,144,16,32,128,192,224,224,240,240,240,224,64,128,128,128,128,0,0,0,192,192,64,64,64,128,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,0,3,12,54,95,251,233,232,0,3,15,57,96,132,30,31,148,79,62,13,3,7,15,15,239,127,63,14,4,4,15,15,53,206,32,87,111,39,13,31,59,241,255,232,208,223,243,247,62,47,171,207,253,252,249,255,255,255,244,114,127,195,247,255,0,0,128,96,88,244,106,253,0,0,128,224,248,204,214,227,237,49,190,64,128,128,128,192,243,239,126,192,128,128,128,192,15,14,14,7,7,3,2,3,15,15,15,7,7,3,3,3,3,3,3,3,3,1,0,0,3,3,1,0,0,2,1,0,115,18,6,15,15,138,82,19,255,255,255,255,255,251,243,243,19,161,224,192,128,192,192,128,241,226,227,225,96,32,32,64,32,16,16,16,144,32,32,64,224,240,240,240,240,224,224,192,192,128,192,128,0,0,0,0,192,64,32,64,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,28,50,124,92,74,148,56,0,28,46,68,100,118,236,200,22,38,39,45,45,45,36,33,25,57,57,50,50,51,59,62,35,19,17,8,13,9,4,3,60,28,30,15,14,14,7,3,68,186,125,253,127,124,187,204,124,198,131,2,128,131,198,127,195,239,255,254,61,255,238,32,60,16,0,1,194,0,17,255,0,0,0,0,224,144,252,2,0,0,0,0,224,112,252,254,185,241,226,60,160,64,64,128,71,15,62,252,224,192,192,128,31,63,63,97,96,112,121,119,31,63,63,127,127,127,127,127,35,49,49,49,27,30,127,62,63,63,63,63,31,30,132,65,25,242,246,206,141,205,250,124,255,255,255,255,255,255,254,124,46,12,0,0,0,0,0,0,49,50,0,0,0,0,0,0,0,0,0,0,0,62,89,156,0,0,0,0,0,62,103,227,137,137,72,72,36,20,12,7,254,254,127,127,63,31,15,7,0,0,0,60,90,157,204,51,0,0,0,60,102,227,243,255,140,225,119,54,0,0,254,255,127,30,136,201,255,255,255,255,0,0,0,0,0,120,180,90,0,0,0,0,0,120,204,230,90,34,34,44,72,80,96,192,230,254,254,252,248,240,224,192,3,2,4,4,4,6,7,2,3,3,7,7,7,7,7,3,3,3,3,1,1,7,3,0,3,3,3,1,1,8,4,0,16,0,0,0,0,57,247,54,255,255,255,255,255,255,247,247,20,19,16,176,224,240,224,0,247,243,240,240,224,64,16,0,144,40,104,80,208,160,192,224,240,248,248,240,240,224,192,16,192,0,0,0,0,0,0,0,32,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,14,29,58,42,81,66,148,0,14,19,38,54,111,126,236,10,10,18,23,20,23,19,18,13,13,29,25,27,24,28,29,11,9,9,4,4,2,2,3,12,14,14,7,7,3,3,3,68,73,80,233,73,35,163,177,199,206,223,246,247,252,124,94,125,211,212,171,169,168,215,24,143,46,47,92,94,95,47,231,64,224,80,80,240,80,240,176,192,32,176,176,240,240,240,240,200,196,28,118,118,106,252,128,248,60,252,234,234,246,252,128,31,63,63,97,96,112,121,119,31,63,63,127,127,127,127,127,35,49,49,49,27,30,127,62,63,63,63,63,31,30,132,65,25,242,246,206,141,205,250,124,255,255,255,255,255,255,254,124,46,12,0,0,0,0,0,0,49,50,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,56,76,62,58,82,41,28,0,56,116,34,38,110,55,19,0,0,0,0,7,9,63,64,0,0,0,0,7,14,63,127,157,143,71,60,5,2,2,1,226,240,124,63,7,3,3,1,34,93,190,191,254,62,221,51,62,99,193,64,1,193,99,254,195,247,255,127,188,255,119,4,60,8,0,128,67,0,136,255,104,100,228,180,180,180,36,132,152,156,156,76,76,204,220,124,196,200,136,16,176,144,32,192,60,56,120,240,112,112,224,192,152,79,111,115,177,179,95,62,255,255,255,255,255,255,127,62,116,48,0,0,0,0,0,0,140,76,0,0,0,0,0,0,248,252,252,134,6,14,158,238,248,252,252,254,254,254,254,254,196,140,140,140,216,120,254,124,252,252,252,252,248,120,33,130,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,24,36,90,90,36,24,0,0,0,24,36,36,24,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,6,57,100,187,185,129,67,63,6,63,95,199,199,255,127,63,0,0,0,0,0,15,48,79,0,0,0,0,0,15,63,112,151,51,144,76,243,71,136,255,232,204,255,191,15,184,255,255,0,0,0,0,0,0,128,120,0,0,0,0,0,0,128,248,166,49,62,57,252,231,199,255,126,255,255,255,207,223,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,60,158,126,154,6,12,254,252,16,136,232,252,252,254,254,252,0,0,0,0,14,31,63,63,0,0,0,0,14,17,32,34,39,31,31,14,5,3,1,0,57,17,17,11,7,3,1,0,0,0,0,0,0,129,194,231,0,0,0,0,0,129,67,36,123,238,251,251,251,243,94,239,252,153,149,244,157,31,177,240,0,0,0,0,96,208,168,216,0,0,0,0,96,240,120,56,24,248,92,172,254,122,228,154,248,24,188,252,250,190,252,102,63,31,19,17,10,6,9,16,40,28,30,31,13,7,15,31,17,16,8,4,2,1,0,0,31,31,15,7,3,1,0,0,222,254,254,221,127,254,255,120,34,2,38,251,129,3,135,255,136,0,8,7,28,224,0,0,255,255,255,255,252,224,0,0,0,0,0,4,254,102,220,236,0,0,0,2,253,253,187,219,207,204,240,0,0,0,0,0,184,188,128,0,0,0,0,0,124,158,237,183,78,89,187,125,124,226,27,253,253,238,214,151,189,222,119,47,29,5,2,1,235,235,90,55,30,6,3,1,12,50,221,106,179,111,249,239,12,62,227,189,220,247,63,30,255,173,222,242,255,239,215,249,190,243,225,61,30,49,57,255,0,0,56,212,250,98,222,119,0,0,56,236,134,158,34,191,109,127,109,223,247,255,255,255,155,191,247,61,11,1,1,203,0,7,251,244,77,59,30,7,0,7,252,175,123,38,25,7,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,14,18,17,32,33,16,28,56,15,31,31,63,63,31,31,15,60,14,8,24,56,63,56,48,7,15,15,15,15,7,0,0,118,246,124,252,116,212,52,28,254,10,132,140,252,252,252,252,24,16,224,96,64,128,0,0,248,240,224,224,192,128,0,0,0,0,0,48,124,239,214,247,0,0,0,48,76,147,57,94,177,42,239,69,246,153,7,1,223,245,185,186,253,159,7,1,0,24,60,126,237,187,223,187,0,24,36,66,155,117,255,118,247,188,127,255,183,251,106,255,15,219,224,192,200,7,159,135,0,0,56,212,250,98,222,119,0,0,56,236,134,158,34,191,109,255,109,95,243,255,255,253,155,191,247,189,13,1,1,199,0,0,0,0,0,0,1,3,0,0,0,0,0,0,1,2,6,15,14,27,20,59,110,24,5,9,11,22,27,47,118,24,87,61,31,55,47,32,16,16,127,59,17,57,63,63,31,31,120,228,224,16,25,46,48,0,31,63,63,31,63,30,0,0,122,58,122,252,60,140,76,52,254,198,134,196,252,252,252,252,40,216,240,192,128,0,0,0,248,248,240,192,128,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,52,66,18,72,66,44,0,60,74,189,237,183,189,82,60,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,36,0,129,0,0,129,0,36,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,8,2,3,0,0,1,2,8,24,4,2,3,7,14,28,112,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,6,3,0,1,2,36,0,8,68,130,131,198,124,24,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,10,80,32,0,0,0,32,8,20,112,224,192,192,192,64,48,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,12,2,33,192,1,66,16,0,112,252,194,193,192,96,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,7,31,63,255,255,254,252,0,0,6,10,26,64,152,152,1,1,1,1,1,1,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,255,255,255,255,255,255,255,255,237,237,239,254,254,239,247,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,255,0,0,0,1,1,15,51,65,0,0,0,1,1,14,62,127,185,124,115,175,155,37,226,229,199,131,140,92,124,254,255,251,56,84,186,2,29,61,31,53,56,108,198,254,227,195,255,207,47,123,187,247,255,255,27,239,223,255,127,9,1,9,255,255,0,3,4,11,63,255,126,111,0,3,7,12,60,214,159,159,208,33,1,1,15,25,16,16,248,241,241,241,239,127,31,31,231,147,13,3,0,8,135,2,248,252,255,255,255,255,255,255,6,14,12,248,241,70,248,0,255,255,255,255,255,254,248,0,188,136,152,240,160,32,32,96,108,248,248,240,224,224,224,224,64,64,128,128,128,0,0,0,192,192,128,128,128,0,0,0,8,8,14,7,3,3,3,1,15,15,15,7,15,63,127,249,0,0,0,0,0,0,0,0,248,240,224,224,192,0,0,0,0,3,4,11,63,255,126,111,0,3,7,12,60,214,159,159,208,33,1,1,1,1,1,1,240,33,1,1,1,1,1,1,231,147,13,3,0,8,135,3,248,252,255,255,255,255,255,255,195,3,6,14,57,227,78,248,255,255,255,255,255,255,254,248,188,136,152,240,160,96,160,32,108,248,248,240,224,224,224,224,32,32,96,64,192,128,0,0,224,224,224,192,192,128,0,0,1,2,4,4,2,3,1,0,1,3,7,15,27,51,49,112,0,0,0,0,0,0,0,0,112,112,112,120,112,112,96,64,1,2,5,8,8,121,216,201,1,3,6,15,15,118,247,190,209,233,127,255,159,207,220,255,62,30,241,200,232,248,255,255,192,160,208,16,232,232,248,164,192,96,48,240,24,24,248,124,124,216,216,184,248,250,223,123,252,248,248,72,8,74,253,253,13,19,36,95,95,46,17,15,14,28,63,99,96,49,31,15,3,1,1,1,3,2,2,3,3,1,1,1,3,3,3,3,102,186,141,7,17,12,2,1,249,253,255,255,255,255,255,255,0,136,240,98,65,65,99,38,255,255,255,127,127,127,127,126,179,118,248,64,192,192,224,176,221,190,56,192,192,192,224,240,208,80,80,240,224,128,0,0,240,240,240,240,224,128,0,0,30,0,0,0,0,0,0,0,126,96,112,57,63,31,14,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,7,0,15,31,31,31,14,12,7,24,16,16,48,44,48,50,32,31,31,31,63,63,63,63,63,0,0,0,0,0,0,96,144,56,60,184,176,0,0,96,240,144,168,216,200,101,251,49,1,240,248,248,248,253,255,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,128,64,96,32,0,0,0,0,128,192,160,224,32,17,19,58,78,126,94,61,63,31,31,63,127,79,111,55,31,18,9,4,3,1,0,0,25,29,14,7,3,1,0,0,251,142,37,120,241,110,15,229,255,255,222,135,15,145,241,251,83,251,157,125,188,153,195,62,190,6,99,195,195,231,255,62,144,144,200,120,84,186,2,29,240,240,248,248,236,198,254,227,61,31,53,47,123,187,204,112,195,255,207,223,255,127,252,112,0,0,0,0,0,0,0,3,0,31,15,7,7,3,3,3,12,8,24,48,44,48,50,32,15,15,31,63,63,63,63,63,0,0,0,0,0,0,0,128,0,0,128,128,128,128,0,128,64,64,192,248,109,227,49,1,192,192,192,248,253,255,255,255,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,128,64,96,32,0,0,0,0,128,192,160,224,0,0,0,0,0,0,0,0,128,192,224,224,240,112,56,24,56,36,66,130,130,134,137,192,56,60,126,254,254,254,255,255,0,0,0,0,0,120,68,196,0,7,31,63,56,120,124,252,136,152,136,136,228,130,5,1,248,248,248,248,252,254,255,255,0,0,0,0,0,0,0,0,192,128,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,64,49,19,14,6,2,3,3,127,63,31,15,7,3,3,3,5,11,10,9,5,3,1,0,6,12,13,15,7,3,1,0,127,253,241,110,15,165,195,59,255,199,15,145,241,251,254,198,189,185,88,253,223,206,226,252,67,199,255,231,99,242,254,252,192,120,84,186,2,29,61,31,192,248,236,198,254,227,195,255,53,47,123,187,206,115,31,14,207,223,255,127,254,125,25,14}}
L["R0"]=3
L["R1"]=4
L["KrColdPose"]=47792
L["KrMovement"]=45352
L["KrSourceWeapons"]=45027
L["FmAlts"]=24549
L["MetaspriteRenderLoop"]=42426
L["BackgroundColorCtrl"]=1863
local function kr(off)return emu.read(2*8192+off,emu.memType.nesWorkRam)end
-- Cold input only. Four selected PNGs; aggregate actual OAM/CHR/PPU/ISR data.
local P=assert(KARNOV_ARGS)
local frame,age,step,updates,shots=0,0,1,0,0
local phase,done='title',false
local plan={'left','select'}
local pad,body,pages,isrs={},{},{},{}
local upper,lastMain=0,nil
local shown,checks,poses={},{},{}
local startX,startY,lives,minY,maxX,maxCamera
local jumped,landed=false,false
local vectors,sourceTicks,damage,defeats,apu,weaponTicks,maxShots,minimumSP,backgroundChecks=0,0,0,0,0,0,0,255,0
local function r(n,i)return emu.read(assert(L[n],n)+(i or 0),emu.memType.nesDebug)end
local function peek(a)return emu.read(a,emu.memType.nesDebug)end
local function raw(pc)if pc>=0xa000 and pc<0xc000 then return r('CurrentBank')elseif pc>=0xc000 and pc<0xe000 then return r('CurrentBankC')end;return pc<0xa000 and 254 or 255 end
local function active()return phase=='game'and r('OperMode')==1 and r('OperMode_Task')==3 and r('GameEngineSubroutine')==8 end
local function json(v)
 if type(v)=='table'then local t={};if#v>0 then for _,x in ipairs(v)do t[#t+1]=json(x)end;return'['..table.concat(t,',')..']'end
 for k,x in pairs(v)do t[#t+1]=string.format('%q',tostring(k))..':'..json(x)end;table.sort(t);return'{'..table.concat(t,',')..'}'
 elseif type(v)=='string'then return string.format('%q',v)else return tostring(v)end
end
local function shot(n)shots=shots+1;assert(shots<=4);local f=assert(io.open(OUTPUT..n..'.png','wb'));f:write(emu.takeScreenshot());f:close()end
local function finish(ok,why)
 if done then return end;done=true;shot('endpoint')
 local f=assert(io.open(OUTPUT..'result.json','w'));f:write(json({passed=ok,reason=why,ROM_sha256=P.sha256,frames=frame,Main=updates,jumped=jumped,landed=landed,minimum_Y=minY,maximum_X=maxX,maximum_camera=maxCamera,ISR_returns=vectors,source_movement=sourceTicks,source_weapons=weaponTicks,HUD_checks=HUDChecks,HUD_font_maps=HUDMaps,world_font_maps=WorldMaps,equipment_option=equipmentOption,fixture_update=fixtureAt,activated_update=activatedAt,option_stock=optionStock,boomerang_fired=firedAt,boomerang_returned=returnedAt,equipment_base=equipmentBase,equipment_peak=equipmentPeak,flight_up=flightUp,flight_down=flightDown,maximum_projectiles=maxShots,minimum_observed_SP=minimumSP,background_checks=backgroundChecks,damage=damage,defeats=defeats,APU_writes=apu,graphics_checks=checks,display=shown,poses=poses,phase=phase,scope='Cold real Select/Start, original body CHR/palette/OAM, idle/jump/landing and opening camera crossing, source shots and native ISR returns. Controller only. Combat, health, earned gear, source audio and complete1-1 remain unimplemented or unqualified; not nightly admission.'})..'\n');f:close();print('KARNOV_NATIVE '..tostring(ok)..' '..why);emu.stop(ok and 0 or 1)
end
emu.addMemoryCallback(function(_,v)upper=(v&3)*256 end,emu.callbackType.write,0x5130)
for i=0,7 do emu.addMemoryCallback(function(_,v)pages[i]=upper+v end,emu.callbackType.write,0x5120+i)end
emu.addMemoryCallback(function()apu=apu+1 end,emu.callbackType.write,0x4000,0x4017)
emu.addMemoryCallback(function(_,v)
 if active()then
  if upper+v==1023 then HUDMaps=HUDMaps+1 elseif upper+v==0 then WorldMaps=WorldMaps+1 end
 end
end,emu.callbackType.write,0x5128)

local function capture()
 if r('SelectedCharacter')~=34 then return end
 local ptr=r('R0')+256*r('R1');local bank=r('CurrentBankC')
 if not(bank==2 and ptr>=0xd100 and ptr<0xd541 or bank==157 and ptr==L.KrColdPose+8192)then return end
 local n=peek(ptr);if n==0 then return end
 assert(n%4==0 and n<=40,'Original body packet length')
 body={};for i=1,n,4 do body[#body+1]={peek(ptr+i),peek(ptr+i+1),peek(ptr+i+2),peek(ptr+i+3)}end
 if bank==2 then poses[tostring(peek(0xc062)&31)]=true end
end
emu.addMemoryCallback(capture,emu.callbackType.exec,L.MetaspriteRenderLoop)
local function sample(page,stage)
 if#body==0 then return end
 local cells,anchor={},nil
 for _,z in ipairs(body)do
  local found
  for at=0,252,4 do
   local a=page*256+at;local y,t,attr,x=peek(a),peek(a+1),peek(a+2),peek(a+3)
   if y<240 and t==z[1]and attr&195==z[2]&195 and(not anchor or(x-z[4])%256==anchor[1]and(y-z[3])%256==anchor[2])then found={x=x,y=y,t=t,attr=attr,offset=at};anchor={(x-z[4])%256,(y-z[3])%256};break end
  end
  if not found then return end;cells[#cells+1]=found
 end
 -- Hardware priority follows actual DMA order, including USA eye overlays.
 table.sort(cells,function(a,b)return a.offset<b.offset end)
 local expected={};local count=0
 for _,z in ipairs(cells)do
  local base=(z.t&1)*4096+(z.t&254)*16;local physical=assert(pages[base//1024],'CHR latch for window '..base//1024)
  assert(physical>=407 and physical<=411,'Owned original art page')
  for y=0,15 do
   local yy=z.attr&128~=0 and 15-y or y
   local off=(base&1023)+(yy//8)*16+yy%8
   local lo=emu.read(physical*1024+off,emu.memType.nesChrRom);local hi=emu.read(physical*1024+off+8,emu.memType.nesChrRom)
   assert(lo==P.chr[(physical-407)*1024+off+1]and hi==P.chr[(physical-407)*1024+off+9],'Exact original CHR bytes')
   for x=0,7 do
    local bit=z.attr&64~=0 and x or 7-x;local v=((lo>>bit)&1)|(((hi>>bit)&1)<<1);local px,py=z.x+x,z.y+y+1
    if v>0 and px<256 and py<240 then local at=py*256+px;if not expected[at]then expected[at]=emu.read(0x3f10+4*(z.attr&3)+v,emu.memType.nesPpuDebug);count=count+1 end end
   end
  end
 end
 checks[stage]=(checks[stage]or 0)+1
 if count>=70 then shown[stage]={frame=frame,opaque=count,cells=#cells,expected=expected,visible=shown[stage]and shown[stage].visible or false,shot=shown[stage]and shown[stage].shot or false}end
end
local function visible(stage)
 local q=shown[stage];if not q or frame-q.frame<1 or frame-q.frame>4 then return false end
 local screen=emu.getScreenBuffer();local colors={}
 for at,nes in pairs(q.expected)do local rgb=screen[at+1]&0xffffff;if colors[nes]and colors[nes]~=rgb then return false end;colors[nes]=rgb end
 local n=0;for _ in pairs(colors)do n=n+1 end
 if n>=2 and r('DisableScreenFlag')==0 and r('Mirror_PPUMASK')&24==24 then q.visible=true;return true end;return false
end
emu.addMemoryCallback(function(_,p)
 if r('SelectedCharacter')~=34 then return end
 if phase=='browse'and step>#plan then sample(p,'selected')elseif phase=='launch'and r('ScreenRoutineTask')==7 then sample(p,'lives')elseif active()then sample(p,'game')end
end,emu.callbackType.write,0x4014)
for _,kind in ipairs({'NMI','IRQ'})do
 local entry=kind=='NMI'and L.NonMaskableInterrupt or L.IrqScrollSplit;local leave=kind=='NMI'and L.NonMaskableInterrupt_RTI or L.IrqScrollSplit_RTI
 emu.addMemoryCallback(function()
  local s=emu.getState();local q=isrs[#isrs];if q and q.kind==kind and q.sp==s['cpu.sp']then return end
  local smc={}for i=0x15a,0x17a do smc[#smc+1]=peek(i)end
  isrs[#isrs+1]={kind=kind,sp=s['cpu.sp'],a=s['cpu.a'],x=s['cpu.x'],y=s['cpu.y'],smc=table.concat(smc,',')}
 end,emu.callbackType.exec,entry)
 emu.addMemoryCallback(function()
  local s=emu.getState();local q=isrs[#isrs]
  if q and q.kind==kind and q.sp==s['cpu.sp']then
   table.remove(isrs);local smc={}for i=0x15a,0x17a do smc[#smc+1]=peek(i)end
   assert(q.a==s['cpu.a']and q.x==s['cpu.x']and q.y==s['cpu.y']and q.smc==table.concat(smc,','),'ISR registers/SMC restored');vectors=vectors+1
  end
 end,emu.callbackType.exec,leave)
end
emu.addMemoryCallback(function()if active()and raw(L.KrMovement)==3 then sourceTicks=sourceTicks+1;minimumSP=math.min(minimumSP,emu.getState()['cpu.sp'])end end,emu.callbackType.exec,L.KrMovement)
emu.addMemoryCallback(function()if active()and raw(L.KrSourceWeapons)==3 then weaponTicks=weaponTicks+1 end end,emu.callbackType.exec,L.KrSourceWeapons)
emu.addMemoryCallback(function()if active()and raw(L.ShellOrBlockDefeat)==254 then defeats=defeats+1 end end,emu.callbackType.exec,L.ShellOrBlockDefeat)
local function route()
 local x=r('Player_X_Position')+256*r('Player_PageLoc');local y=r('Player_Y_Position');local camera=r('ScreenLeft_X_Pos')+256*r('ScreenLeft_PageLoc')
 minY=math.min(minY,y);maxX=math.max(maxX,x);maxCamera=math.max(maxCamera,camera)
 if y<startY-20 then jumped=true end;if jumped and r('Player_State')==0 then landed=true end
 local n=0;for i=0,8 do if kr(0x6e+3*i)&128~=0 then n=n+1 end end;maxShots=math.max(maxShots,n)

 if updates==20 then
  -- Deliberate earned-equipment fixture. Collection has a separate test.
  for off,v in pairs({[0x65]=2,[0x8e]=255,[0x8f]=137,[0xbd]=2,[0xbe]=2,[0xbf]=2})do kwrite(off,v)end
  fixtureAt=updates;equipmentBase=y;equipmentPeak=y
 end
 if not fixtureAt then pad={};return end
 local n=updates-fixtureAt
 local presses=equipmentOption==0 and 1 or equipmentOption==3 and 2 or 3
 if n<presses*8 then pad=n%8<4 and{select=true}or{};return end
 n=n-presses*8
 if n<4 then pad={down=true,b=true};return end
 if not activatedAt then
  assert(kr(0x8e)==equipmentOption,'Fresh Select chose the requested source option')
  assert(equipmentOption~=0 or kr(0x65)&128~=0,'Original boots activation')
  assert(equipmentOption~=3 or kr(0x65)&15==8,'Original boomerang activation')
  assert(equipmentOption~=7 or kr(0x62)&31==15 or equipmentOption==7 and kr(0x62)&31==16,'Original wings activation')
  optionStock=kr(equipmentOption==0 and 0xbd or equipmentOption==3 and 0xbe or 0xbf)
  assert(optionStock==1,'Original stock consumed once');activatedAt=updates
 end
 local use=updates-activatedAt
 if equipmentOption==0 then
  equipmentPeak=math.min(equipmentPeak,y);pad=use>=4 and use<26 and{a=true}or{}
  if use>85 then equipmentDone=equipmentBase-equipmentPeak==88 and r('Player_State')==0 end
 elseif equipmentOption==3 then
  pad=use%24<4 and{b=true}or{}
  if kr(0x6e)&128~=0 and not firedAt then firedAt=updates end
  if firedAt and kr(0x65)&15==2 then returnedAt=updates;equipmentDone=true end
 else
  if use<4 then pad={}
  elseif use<24 then pad={up=true}
  elseif use<28 then flightUp=y;pad={}
  elseif use<48 then pad={down=true}
  else flightDown=y;pad={};equipmentDone=flightUp<equipmentBase and flightDown>flightUp end
 end
 if updates%20==0 then print('KARNOV_PROGRESS '..updates..' x='..x..' camera='..camera..' y='..y)end
end
emu.addMemoryCallback(function()if active()and raw(L.GameLoop)==254 then assert(not lastMain,'Recursive Main: previousSP='..tostring(lastMain)..' currentSP='..emu.getState()['cpu.sp']..' frame='..frame..' returnPC='..P.main_return);lastMain=emu.getState()['cpu.sp']end end,emu.callbackType.exec,L.GameLoop)
emu.addMemoryCallback(function()if lastMain and raw(P.main_return)==254 and emu.getState()['cpu.sp']==lastMain then updates=updates+1;lastMain=nil;route()end end,emu.callbackType.exec,P.main_return)
emu.addEventCallback(function()
 local b={};if phase=='open'and age<6 or phase=='launch'and age<4 then b.start=true elseif phase=='browse'and age<4 and plan[step]then b[plan[step]]=true elseif phase=='game'then b=pad end;emu.setInput(b,0)
end,emu.eventType.inputPolled)
emu.addEventCallback(function()
 if done then return end;frame=frame+1;age=age+1
 for _,stage in ipairs({'selected','lives','game'})do visible(stage)end
 if active()and activatedAt and updates>=activatedAt+10 then
  local ppu=emu.memType.nesPpuDebug
  local function chr(c)return c==' 'and 36 or string.byte(c)-55 end
  local name=equipmentOption==0 and'BOOTS    'or equipmentOption==3 and'BOOMERANG'or'WINGS    '
  assert(r('InvHudActive')==233 and r('InvHudPhysical')==255 and r('X5HudChrUpper')==3 and r('X5WideChrActive')==1,'Exclusive wide HUD font lease')
  for i=1,9 do assert(emu.read(0x2022+i,ppu)==chr(name:sub(i,i)),'Equipment HUD name')end
  assert(emu.read(0x202d,ppu)==0 and emu.read(0x202e,ppu)==1,'Remaining original BCD stock01')
  local tile=equipmentOption==0 and 0x30 or equipmentOption==3 and 0x34 or 0x38
  for i,a in ipairs({0x2037,0x2038,0x2057,0x2058})do assert(emu.read(a,ppu)==tile+i-1,'Original equipment icon layout')end
  HUDChecks=HUDChecks+1
 end
 if active()and updates>15 then
  local ctrl=r('BackgroundColorCtrl');local ix=ctrl~=0 and ctrl or r('AreaType')
  assert(emu.read(0x3f00,emu.memType.nesPpuDebug)==P.background[ix+1],'Native gameplay backdrop restored after lives');backgroundChecks=backgroundChecks+1
 end
 if phase=='title'and frame>=100 then assert(r('OperMode')==0);phase='open';age=0
 elseif phase=='open'and age>=36 then assert(r('CrossoverMenuState')==2);phase='browse';age=0
 elseif phase=='browse'and age>=24 then
  if step<=#plan then step=step+1;age=0 elseif shown.selected and shown.selected.visible then assert(r('CrossoverMenuIndex')==7 and r('SelectedCharacter')==34 and r('FmAlts')&1~=0);shot('selected');phase='launch';age=0 end
 elseif phase=='launch'then
  if shown.lives and shown.lives.visible and not shown.lives.shot then shot('lives');shown.lives.shot=true end
  if r('OperMode')==1 and r('OperMode_Task')==3 and r('GameEngineSubroutine')==8 then
   assert(shown.lives and shown.lives.visible,'Actual visible lives sprite');phase='game';age=0;startX=r('Player_X_Position')+256*r('Player_PageLoc');startY=r('Player_Y_Position');lives=r('NumberofLives');minY=startY;maxX=startX;maxCamera=0
  end
 elseif phase=='game'then
  if r('NumberofLives')~=lives or r('GameEngineSubroutine')==11 then finish(false,'Natural death');return end
  if activatedAt and updates>=activatedAt+15 and shown.game and not shown.game.shot and shown.game.visible then shot('gameplay');shown.game.shot=true end
  if equipmentDone and shown.game and shown.game.visible and not lastMain then finish(vectors>100 and sourceTicks>50 and HUDChecks>5 and HUDMaps>5 and WorldMaps>5,'Original equipment controls, visible HUD name/stock/icon and wide/NMI/world font publication; declared stock fixture');return end
  if updates>=260 and not lastMain then finish(false,'260 Main equipment bound');return end
 end
 if frame>=2600 then finish(false,'2600 physical frame bound')end
end,emu.eventType.endFrame)
