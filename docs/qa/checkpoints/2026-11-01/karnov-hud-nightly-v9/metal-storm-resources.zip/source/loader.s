.setcpu "6502"
.macpack longbranch
.include "metal_storm_resource_host_1101_v8.inc"
