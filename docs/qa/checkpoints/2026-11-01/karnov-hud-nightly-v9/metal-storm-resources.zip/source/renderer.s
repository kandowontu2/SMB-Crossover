.setcpu "6502"
.macpack longbranch
.import MsState,MsLifeUnsupported
.include "renderer-adapted.inc"
