.setcpu "6502"
.include "mario_tank_rules_1101_v1.inc"
