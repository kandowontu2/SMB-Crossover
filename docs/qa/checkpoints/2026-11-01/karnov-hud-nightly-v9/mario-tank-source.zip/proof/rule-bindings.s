.export PlayerStatus
PlayerStatus=$755
.exportzp GameEngineSubroutine
GameEngineSubroutine=$12
.export RemovedTile
RemovedTile=$79a
.export StarInvincibleTimer
StarInvincibleTimer=$796
.exportzp FrameCounter
FrameCounter=$f
.exportzp ObjectOffset
ObjectOffset=$e
.exportzp PowerUpType
PowerUpType=$51
.export Enemy_SprAttrib
Enemy_SprAttrib=$582
.exportzp R2
R2=$2
.export MtCheckClimb
MtCheckClimb=$9839
.export MtGetPlayerColors
MtGetPlayerColors=$e2d2
.export MtSetPRout
MtSetPRout=$91fd
