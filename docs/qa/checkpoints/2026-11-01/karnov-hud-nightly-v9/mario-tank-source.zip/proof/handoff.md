# Mario the Tank source component

The original release is reproduced byte-for-byte. The independently assembled197-byte rules module is ready for host integration review; Tank is not added to the roster by this work.

Donor SHA256: `3396476ef485407414484f038b1e9f4e3a3bac2c1ce45f64f31d119b6e7a3c4e` (131088bytes, mapper4). The donor was reconstructed from the author IPS and an existing local SMB World ROM, normalizing only its16-byte header to the author-required base. No donor ROM download was used.

## Verified original behavior

- AleFunky Mario the Tank1.0.2a, released2024-08-19; original disassembly doppelganger, ca65 port threecreepio, base changes jroweboy, inspiration Doogtoons.
- The author IPS replaces the Fire Flower icon with Lightning Boots. Native statuses remain small0, big1, boots2; the stale memory.inc comment suggesting status3 is incorrect.
- Small->big still uses native growth. A subsequent mushroom/flower pickup changes big1->boots2. Pickup erasure,1000points and pickup SFX are outer native owners.
- The boots pickup alternates four palette numbers every2frames. The recovered source contains no separate worn-boot-only flashing routine.
- Boots contact routes the ordinary enemy defeat effect after native collision prechecks, with the donor1000point award. ForceInjury ignores boots2; native death, exits and transitions still need their own host ownership.
- Boots head and side collisions destroy nonprotected cells, using native clearing/debris/50point/brick-shatter SFX. One RemovedTile budget per completed game update prevents multiple destructive writes; this is not a global frame or NMI flag.
- Destruction is not restricted to ordinary brick metatiles. The donor can also erase question/item blocks, without ordinary item release once boots are active. Preserve the authenticated protected-tile classification; never run destruction on support/foot probes.
- The donor still allows native B fireballs at status2. Boots do not replace jump/run/swim physics:1664 actual PlayerPhysicsSub cases produce identical AXYP/RAM for native big1 versus boots2.

## Deliberate adaptations

- MtCellAction replaces the donor selector's caller-frame-discarding TXS with a returning action ABI. Never transplant that TXS across a host farcall.
- MtContactPolicy returns the original contact branch decision in carry. Native enemy defeat/score/SFX remain explicit host effect owners.
- MtWearBootsFlash applies the donor pickup palette cadence to a separately masked worn-boot OAM part, as requested by the user. Actual masked boot art, facing/pose mapping, palette and sprite budget remain integration work.

## Remaining integration gates

- No roster admission, host code/RAM/CHR lease, Main dispatch, options behavior or installed nightly changes are made by this component.
- Admit Tank identity before these helpers. Other roster characters can also use native PlayerStatus2 and must not acquire Tank immunity/destruction.
- Bind terrain probes, protected metatile attributes, native effect/score/SFX/VRAM queues and one-per-update RemovedTile state to actual host ownership. Do not transplant donor79A, four-brick arrays or R8 blindly.
- Every callback must honor host scratch and stack contracts. Observed standalone peak is9stack bytes including entryJSR for MtCellAction; this is not a host Main/ISR reserve proof.
- Real native opening, head/side/block/powerup/contact hazards, scrolling, underwater, pause/death/flag/lives scenes and both difficulty settings remain to qualify after integration.
- The linked user YouTube short was identified by primary references but its frames were not visually reviewed. Flashing cadence here is proven from reproduced original source/CPU, not a claimed video review.

The strongest receipts are `author-reproduction.json` and `rules-CPU-controls.json`; `original-hooks.json` preserves exact source coordinates. Runtime input paths and Git blob hashes in `source-inputs.json` allow the declared compiler graph to be recovered without checking out unrelated tools.
