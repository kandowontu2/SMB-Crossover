.setcpu "6502"
.macpack longbranch
MsState=$6000
MsPointer=$00
MsSaved0=MsState+$7fe
MsSaved1=MsState+$7ff
.segment "CODE"
MsExternal_8874=$5000
MsExternal_8BCF=$5003
MsExternal_9ED7=$5006
MsExternal_FF18=$5009
MsExternal_FF1E=$500c
MsExternal_FF27=$500f
MsExternal_FF33=$5012
MsExternal_FF36=$5015
MsExternal_FF39=$5018
MsExternal_FF3F=$501b
MsAlias_FF69: jmp Ms_E324
MsAlias_FF6C: jmp Ms_EA4E
.include "portable-actor.inc"
Ms_DA09: .byte $00
Ms_DA0A: .byte $fa
Ms_DA0B: .byte $fa
Ms_DA0C: .byte $fa
Ms_DA0D: .byte $fb
Ms_DA0E: .byte $fb
Ms_DA0F: .byte $fb
Ms_DA10: .byte $fc
Ms_DA11: .byte $fc
Ms_DA12: .byte $fc
Ms_DA13: .byte $fd
Ms_DA14: .byte $fc
Ms_DA15: .byte $fd
Ms_DA16: .byte $fe
Ms_DA17: .byte $fd
Ms_DA18: .byte $fe
Ms_DA19: .byte $fe
Ms_DA1A: .byte $fe
Ms_DA1B: .byte $ff
Ms_DA1C: .byte $fe
Ms_DA1D: .byte $ff
Ms_DA1E: .byte $ff
Ms_DA1F: .byte $00
Ms_DA20: .byte $ff
Ms_DA21: .byte $00
Ms_DA22: .byte $00
Ms_DA23: .byte $01
Ms_DA24: .byte $00
Ms_DA25: .byte $00
Ms_DA26: .byte $01
Ms_DA27: .byte $00
Ms_DA28: .byte $01
Ms_DA29: .byte $01
Ms_DA2A: .byte $02
Ms_DA2B: .byte $01
Ms_DA2C: .byte $02
Ms_DA2D: .byte $02
Ms_DA2E: .byte $02
Ms_DA2F: .byte $03
Ms_DA30: .byte $02
Ms_DA31: .byte $03
Ms_DA32: .byte $04
Ms_DA33: .byte $03
Ms_DA34: .byte $04
Ms_DA35: .byte $04
Ms_DA36: .byte $04
Ms_DA37: .byte $05
Ms_DA38: .byte $05
Ms_DA39: .byte $05
Ms_DA3A: .byte $06
Ms_DA3B: .byte $06
Ms_DA3C: .byte $06
Ms_DA3D: .byte $00
Ms_DA3E: .byte $06
Ms_DA3F: .byte $06
Ms_DA40: .byte $06
Ms_DA41: .byte $05
Ms_DA42: .byte $05
Ms_DA43: .byte $05
Ms_DA44: .byte $04
Ms_DA45: .byte $04
Ms_DA46: .byte $04
Ms_DA47: .byte $03
Ms_DA48: .byte $04
Ms_DA49: .byte $03
Ms_DA4A: .byte $02
Ms_DA4B: .byte $03
Ms_DA4C: .byte $02
Ms_DA4D: .byte $02
Ms_DA4E: .byte $02
Ms_DA4F: .byte $01
Ms_DA50: .byte $02
Ms_DA51: .byte $01
Ms_DA52: .byte $01
Ms_DA53: .byte $00
Ms_DA54: .byte $01
Ms_DA55: .byte $00
Ms_DA56: .byte $00
Ms_DA57: .byte $ff
Ms_DA58: .byte $00
Ms_DA59: .byte $00
Ms_DA5A: .byte $ff
Ms_DA5B: .byte $00
Ms_DA5C: .byte $ff
Ms_DA5D: .byte $ff
Ms_DA5E: .byte $fe
Ms_DA5F: .byte $ff
Ms_DA60: .byte $fe
Ms_DA61: .byte $fe
Ms_DA62: .byte $fe
Ms_DA63: .byte $fd
Ms_DA64: .byte $fe
Ms_DA65: .byte $fd
Ms_DA66: .byte $fc
Ms_DA67: .byte $fd
Ms_DA68: .byte $fc
Ms_DA69: .byte $fc
Ms_DA6A: .byte $fc
Ms_DA6B: .byte $fb
Ms_DA6C: .byte $fb
Ms_DA6D: .byte $fb
Ms_DA6E: .byte $fa
Ms_DA6F: .byte $fa
Ms_DA70: .byte $fa
Ms_FEC8: .byte $04
Ms_FEC9: .byte $04
Ms_FECA: .byte $00
Ms_FECB: .byte $1f
Ms_FECC: .byte $1b
Ms_FECD: .byte $1b
Ms_FECE: .byte $1f
Ms_FECF: .byte $00
Ms_FED0: .byte $00
Ms_FED1: .byte $08
Ms_FED2: .byte $10
Ms_FED3: .byte $18
Ms_FED4: .byte $20
Ms_FED5: .byte $28
Ms_FED6: .byte $30
Ms_FED7: .byte $38
Ms_FED8: .byte $40
Ms_FED9: .byte $48
Ms_FEDA: .byte $50
Ms_FEDB: .byte $58
Ms_FEDC: .byte $60
Ms_FEDD: .byte $68
Ms_FEDE: .byte $70
Ms_FEDF: .byte $78
Ms_FEE0: .byte $80
Ms_FEE1: .byte $88
Ms_FEE2: .byte $90
Ms_FEE3: .byte $98
Ms_FEE4: .byte $a0
Ms_FEE5: .byte $a8
Ms_FEE6: .byte $b0
Ms_FEE7: .byte $b8
Ms_FEE8: .byte $c0
Ms_FEE9: .byte $c8
Ms_FEEA: .byte $d0
Ms_FEEB: .byte $d8
Ms_FEEC: .byte $e0
Ms_FEED: .byte $e8
Ms_FEEE: .byte $f0
Ms_FEEF: .byte $f8
Ms_FEF0: .byte $00
Ms_FEF1: .byte $10
Ms_FEF2: .byte $20
Ms_FEF3: .byte $30
Ms_FEF4: .byte $40
Ms_FEF5: .byte $50
Ms_FEF6: .byte $60
Ms_FEF7: .byte $70
Ms_FEF8: .byte $80
Ms_FEF9: .byte $90
Ms_FEFA: .byte $a0
Ms_FEFB: .byte $b0
Ms_FEFC: .byte $c0
Ms_FEFD: .byte $d0
Ms_FEFE: .byte $e0
Ms_FEFF: .byte $f0
.export MsFrame
MsFrame:
 lda MsPointer
 sta MsSaved0
 lda MsPointer+1
 sta MsSaved1
 jsr Ms_AD8C
MsFrameResult:
 php
 pha
 lda MsSaved0
 sta MsPointer
 lda MsSaved1
 sta MsPointer+1
 pla
 plp
 rts
.export MsHorizontal
MsHorizontal:
 lda MsPointer
 sta MsSaved0
 lda MsPointer+1
 sta MsSaved1
 jsr Ms_AC2F
MsHorizontalResult:
 php
 pha
 lda MsSaved0
 sta MsPointer
 lda MsSaved1
 sta MsPointer+1
 pla
 plp
 rts
.export MsGravity
MsGravity:
 lda MsPointer
 sta MsSaved0
 lda MsPointer+1
 sta MsSaved1
 jsr Ms_E324
MsGravityResult:
 php
 pha
 lda MsSaved0
 sta MsPointer
 lda MsSaved1
 sta MsPointer+1
 pla
 plp
 rts
.export MsJumpClock
MsJumpClock:
 lda MsPointer
 sta MsSaved0
 lda MsPointer+1
 sta MsSaved1
 jsr Ms_EA4E
MsJumpClockResult:
 php
 pha
 lda MsSaved0
 sta MsPointer
 lda MsSaved1
 sta MsPointer+1
 pla
 plp
 rts
.export MsIntegrateY
MsIntegrateY:
 lda MsPointer
 sta MsSaved0
 lda MsPointer+1
 sta MsSaved1
 jsr Ms_AC84
MsIntegrateYResult:
 php
 pha
 lda MsSaved0
 sta MsPointer
 lda MsSaved1
 sta MsPointer+1
 pla
 plp
 rts
.export MsWalls
MsWalls:
 lda MsPointer
 sta MsSaved0
 lda MsPointer+1
 sta MsSaved1
 jsr Ms_BB08
MsWallsResult:
 php
 pha
 lda MsSaved0
 sta MsPointer
 lda MsSaved1
 sta MsPointer+1
 pla
 plp
 rts
.export MsSupport
MsSupport:
 lda MsPointer
 sta MsSaved0
 lda MsPointer+1
 sta MsSaved1
 jsr Ms_B744
MsSupportResult:
 php
 pha
 lda MsSaved0
 sta MsPointer
 lda MsSaved1
 sta MsPointer+1
 pla
 plp
 rts
MsEnd:
.export MsEnd,MsState,MsPointer
