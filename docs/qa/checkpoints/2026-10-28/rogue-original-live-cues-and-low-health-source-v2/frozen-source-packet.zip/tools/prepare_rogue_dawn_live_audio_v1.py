"""Private live five-cue/source06C4 successor; no Main/NMI scheduling hooks."""
from pathlib import Path
import difflib,json,re,subprocess,sys
R=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(R/'tools'),str(R/'tools/audit')]
import rogue_dawn_map_v1 as ref
from prepare_cv3_dmc_mirror import prepare
from prepare_rogue_dawn_audio_driver_v4 import labels
from prepare_rogue_dawn_host_body_handoff_v1 import dependencies
from link_pit_rygar_sophia_audit_cpu import scoped_load
from check_tmnt_render_oa import address
P=R/'build/rogue-dawn-host-ui-v1'
D=R/'build/rogue-dawn-audio-driver-v4'
O=R/'build/rogue-dawn-live-audio-v1'

def once(s,a,b):
 assert s.count(a)==1,(a,s.count(a))
 return s.replace(a,b)

def main():
 assert not(O/'controls.json').exists(),'Preserve completed private unit'
 if (O/'build.json').exists():
  assert (O/'first-controls-negative.json').exists(),'Only a recorded private preparation negative may be corrected'
  prior=json.loads((O/'build.json').read_text())
  history=O/'preparation-negative-v1.json'
  if not history.exists():
   z=labels(O/'candidate.lbl');image=(O/'candidate.nes').read_bytes()
   lo=16+62*8192+(z['RdaLowHealth']&8191);hi=lo+z['RdaLowHealthEnd']-z['RdaLowHealth']
   history.write_text(json.dumps(dict(classification='UNQUALIFIED_PRIVATE_HELPER_SOURCE_DIFFERENTIAL_FALSE_NOT_GAME_DEFECT',candidate_at_failure=prior['ROM'],helper_PC=hex(z['RdaLowHealth']),helper_compiled_bytes=image[lo:hi].hex(),negative=ref.binding(O/'first-controls-negative.json'),actual_original_CBF3='LDA08/LDX03/BNECBE8: queue3, notqueue1',wrong_source=(R/'src/rogue_dawn_audio_live_v1.s').read_text(),old_build_metadata=prior),indent=2)+'\n')
 for folder,file in [(P,'build.json'),(D,'build-proof.json')]:
  for q in json.loads((folder/file).read_text())['bindings']:
   assert ref.binding(q['path'])==q,q['path']
 assert ref.digest((P/'candidate.nes').read_bytes())=='8904098e33df98b3a35795ba78c154dd7b78c892948411570b9af7d6d1446bff'
 assert ref.digest((D/'candidate.nes').read_bytes())=='c159cf3c68066d5d72a7ba50f836b33125b8d368431e249a6c7a241a072bfb5b'
 O.mkdir(exist_ok=True)
 # Actual generated instruction lines, not raw data, are projected. The full
 # original49 byte view and all direct-data copies remain unmodified.
 native=(R/'src/rogue_dawn_audio_native_v4.inc').read_text()
 graph=json.loads((R/'docs/qa/rogue-dawn-audio-source-closure-2026-10-28.json').read_text())['graph']
 sites=[]
 for q in graph['instructions']:
  b=bytes.fromhex(q['bytes'])
  if len(b)==3 and 0x680<=int.from_bytes(b[1:],'little')<=0x685:
   at=int.from_bytes(b[1:],'little');pc=q['pc']
   assert q['mode']=='abs' and q['instruction'].split()[0]in['LDA','STA'],q
   if at==0x682:
    assert pc==0xb3de and q['instruction'].split()[0]=='STA'
    sites.append(dict(source_PC=hex(pc),source_operand=hex(at),host='NMI-private RdaState+$82'))
    continue
   suffix=f' ;49:{pc:04X} {b.hex()}'
   matching=[line for line in native.splitlines()if line.endswith(suffix)]
   assert len(matching)==1,hex(pc)
   old=matching[0];new=once(old,f'RdaState+${at-0x600:02x}',f'RdSfx+{at-0x680}')
   native=once(native,old,new)
   sites.append(dict(source_PC=hex(pc),source_operand=hex(at),host=hex(0x5c20+at-0x680)))
 assert len(sites)==15
 (R/'src/rogue_dawn_audio_live_native_v1.inc').write_text(native,newline='\n')
 text=(R/'src/rogue_dawn_audio_driver_v4.s').read_text()
 text=once(text,'.include "driver-imports.inc"','.include "live-driver-imports.inc"')
 text=once(text,'.include "rogue_dawn_audio_native_v4.inc"','.include "rogue_dawn_audio_live_native_v1.inc"')
 text=once(text,' sta RdaState+$80           ; original silence/init request, consumed by Tick',
  ' sta RdSfx                  ; exact live source silence/init priority')
 # Init is NMI-owner-only and may zero the source low-health counter. Normal
 # ticks must NEVER clear it through source queue2's old private location.
 text=once(text,' lda #3\n sta RdaZpState',
  ' ldx #5\nLiveClear:\n sta RdSfx,x\n dex\n bpl LiveClear\n lda #3\n sta RdaZpState')
 text=once(text,' cpx #6\n bcs Done\n lda $0103,y\n sta RdaState+$80,x         ; actual assignment to0680..0685',
  ' cpx #6\n bcs Done\n cpx #2\n beq Done                 ; unproduced sourceQ2 is NOT the live06C4 counter\n lda $0103,y\n sta RdSfx,x                ; diagnostic API; consumer/NMI owner only')
 text=once(text,' sta RdaState+$85',' sta RdSfx+5')
 helper='''
; Actual source3:B189/B199 foreground counter semantics. The C94 source
; bridge supplies real service7 (health) /8 (low). No audio-private RAM/ZP
; is accessed by this foreground routine. Public return preserves AXYP.
.export RdaLowHealth,RdaLowHealthEnd,RdLowHpCounter
RdLowHpCounter=RdSfx+2
.proc RdaLowHealth
 RdaPublic
 lda RdHostService
 cmp #8
 beq Low
 cmp #7
 bne Done
 tsx
 lda $0103,x
 sta RdHit                  ; genuine original Health callback inputA0
 lda RdHealthHi
 beq Done
 cmp #2
 bcs Reset
 lda RdHealthLo
 cmp #$70
 bcc Done
Reset:
 lda #0
 sta RdLowHpCounter
 jmp Done
Low:
 lda RdLowHpCounter
 and #$3c
 cmp #$3c
 bcc Decrement
 lda #8
 ora RdSfx+3                ; literal sourceCBF3 X3 OR/STA interruption semantics
 sta RdSfx+3
Decrement:
 dec RdLowHpCounter
Done:
 jmp RdaPublicReturn
.endproc
RdaLowHealthEnd:
'''
 text=once(text,'RdaAdapterEnd:',helper+'RdaAdapterEnd:')
 text='; PRIVATE live cue / source06C4 successor. No scheduler hooks.\n'+text
 leaf=R/'src/rogue_dawn_audio_live_v1.s';leaf.write_text(text,newline='\n')
 # One shared callback farcall. Service8 retains the old leaf's C-clear;
 # service7 preserves incoming flags. FarCallCommon otherwise changes NZ.
 gate=R/'src/rogue_dawn_live_cue_gate_v1.s'
 gate.write_text('''; Exact-owner RdHostDispatch gates BEFORE either public target.
.pushseg
.segment "ROGUE_DAWN_HOST"
.import RdaLowHealth
.export RdCueLowHealthGate,RdCueHealthGate,RdCueGateEnd
RdCueLowHealthGate:
 clc
RdCueHealthGate:
 php
 farcall RdaLowHealth
 plp
 rts
RdCueGateEnd:
.assert RdCueGateEnd<=$bf00,lderror,"Live cue gate overlaps death descriptors"
.popseg
''',newline='\n')
 entry=(P/'entrypoint.s').read_text()
 entry=once(entry,'.include "rogue_dawn_host_deferred.s"','.include "live-deferred.s"')
 entry=once(entry,'.include "rogue_dawn_host_ui_gate_v1.s"','.include "rogue_dawn_host_ui_gate_v1.s"\n.include "rogue_dawn_live_cue_gate_v1.s"')
 (O/'entrypoint.s').write_text(entry,newline='\n')
 defer=(R/'src/rogue_dawn_host_deferred.s').read_text()
 defer=once(defer,' jmp RdHsHealth',' jmp RdCueHealthGate')
 defer=once(defer,' jmp RdHsLowHealth',' jmp RdCueLowHealthGate')
 (O/'live-deferred.s').write_text(defer,newline='\n')
 (O/'main.c').write_bytes((P/'main.c').read_bytes())
 imports=(D/'src/driver-imports.inc').read_text();bundle=scoped_load(P/'candidate.nes')
 for name in ['RdSfx','RdHostService','RdHit','RdHealthLo','RdHealthHi']:
  imports+=f'{name}=${address(bundle,name):04x}\n'
 (O/'live-driver-imports.inc').write_text(imports,newline='\n')
 cfg=(P/'private.cfg').read_text();dcfg=(D/'smb1base-mmc5-expanded.cfg').read_text()
 names=['CV3_COMBAT','CV3_GFX_85','CD_GFX','M3_GFX','M3_NATIVE','X5_MENU_UI']
 for n in names:
  pattern=r'(?m)^(\s*'+n+r':[^\n;]+);'
  assert len(re.findall(pattern,cfg))==1,n
  cfg=re.sub(pattern,lambda m:m[1]+',define=yes;',cfg)
 rows=[l for l in dcfg.splitlines()if re.match(r'\s+ROGUE_AUDIO_\w+:',l)]
 assert len(rows)==20,len(rows)
 cfg=once(cfg,'}\nSYMBOLS {','\n'.join(rows)+'\n}\nSYMBOLS {')
 (O/'private.cfg').write_text(cfg,newline='\n')
 ca=str(R/'tools/Windows/cc65/bin/ca65.exe')
 sources=[leaf,R/'src/rogue_dawn_audio_pages_v3.s',R/'src/rogue_dawn_audio_upper_raw_v4.s']
 cmds=[];objects=[]
 for i,p in enumerate(sources):
  obj=O/f'audio{i}.o';objects.append(str(obj))
  cmd=[ca,'--cpu','6502x','-g','-I',str(O),'-I',str(R/'src'),'--create-full-dep',str(O/f'audio{i}.dep'),str(p),'-o',str(obj)]
  cmds.append(cmd)
 build=json.loads((P/'build.json').read_text());cmd=build['commands'][1][:]
 # Only the genuine main/config/output locations move. All pinned sparse
 # callers and the exact old separate weapon object remain consumed in place.
 cmd=[v.replace(str(P/'candidate'),str(O/'candidate')).replace(str(P/'private.cfg'),str(O/'private.cfg')).replace(str(P/'assembler-full.dep'),str(O/'assembler-full.dep')).replace(str(P/'entrypoint.s'),str(O/'entrypoint.s')).replace(str(P/'main.c'),str(O/'main.c'))for v in cmd]
 index=cmd.index('--asm-include-dir');cmd[index:index]=['--asm-include-dir',str(O)]
 cmd+=objects;cmds.append(cmd)
 for i,cmd in enumerate(cmds):
  z=subprocess.run(cmd,cwd=R,capture_output=True,text=True)
  (O/f'build{i}.log').write_text(z.stdout+z.stderr)
  assert z.returncode==0,(i,(z.stdout+z.stderr)[-8000:])
 prepare(R,O/'candidate.nes')
 syms=labels(O/'candidate.lbl');new=(O/'candidate.nes').read_bytes();old=(P/'candidate.nes').read_bytes()
 assert syms['RdCueLowHealthGate']==0xbee0 and syms['RdCueGateEnd']<=0xbf00
 assert syms['RdaAdapterEnd']<=0xc000
 assert new[16+1048576:]==old[16+1048576:],'CHR changed'
 # Authenticated depot and original raw-bank views are byte-for-byte equal.
 audio=(D/'candidate.nes').read_bytes()
 audio_bundle=scoped_load(D/'candidate.nes')
 for seg in audio_bundle['segs'].values():
  name=seg['name'].strip('"')
  if not(name.startswith('ROGUE_AUDIO_PAGES_')or name.startswith('ROGUE_AUDIO_UPPER_RAW_')or name=='ROGUE_AUDIO_PAGE_MAP'):continue
  start=int(seg['ooffs'],0);size=int(seg['size'],0)
  assert new[start:start+size]==audio[start:start+size],seg['name']
 deps=dependencies(O/'assembler-full.dep')
 for i in range(3):deps+=dependencies(O/f'audio{i}.dep')
 deps=list(dict.fromkeys(deps))
 differences={}
 for i,(a,b)in enumerate(zip(old,new)):
  if a!=b: differences[str((i-16)//8192)]=differences.get(str((i-16)//8192),0)+1
 changed=[(R/'src/rogue_dawn_audio_driver_v4.s',leaf),(R/'src/rogue_dawn_audio_native_v4.inc',R/'src/rogue_dawn_audio_live_native_v1.inc'),(R/'src/rogue_dawn_host_deferred.s',O/'live-deferred.s'),(P/'entrypoint.s',O/'entrypoint.s')]
 patch=O/'source.patch';patch.write_text(''.join(''.join(difflib.unified_diff(a.read_text().splitlines(True),b.read_text().splitlines(True),fromfile=str(a),tofile=str(b)))for a,b in changed),newline='\n')
 report=dict(status='PRIVATE_COMPILED_NOT_YET_CONTROL_QUALIFIED',native_run=False,common_hooks_changed=False,ROM=ref.binding(O/'candidate.nes'),UI_parent=ref.binding(P/'candidate.nes'),driver_parent=ref.binding(D/'candidate.nes'),commands=cmds,source_cue_sites=sites,actual_ASM_inputs=len(deps),adapter_bytes=syms['RdaAdapterEnd']-syms['RdaAdapterStart'],adapter_spare=0xc000-syms['RdaAdapterEnd'],A95_gate_bytes=syms['RdCueGateEnd']-syms['RdCueLowHealthGate'],A95_spare_before_death=0xbf00-syms['RdCueGateEnd'],per_bank_differences_vs_UI890=differences,bindings=[ref.binding(p)for p in dict.fromkeys(deps+[Path(__file__),P/'build.json',D/'build-proof.json',P/'weapon-object.o',O/'private.cfg',O/'live-driver-imports.inc',patch,*[O/('candidate'+s)for s in['.nes','.dbg','.lbl','.map']]])],open=['No actual common NMI/audio hook or mixer','RNG still consumer diagnostic Tick cadence; completedMain protocol not implemented','All old area3 phase1 unsupported-script failures retained','No native/deadline/full-audio claim'])
 (O/'build.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({k:report[k]for k in['ROM','adapter_bytes','adapter_spare','A95_gate_bytes','A95_spare_before_death','actual_ASM_inputs']}))

if __name__=='__main__':main()
