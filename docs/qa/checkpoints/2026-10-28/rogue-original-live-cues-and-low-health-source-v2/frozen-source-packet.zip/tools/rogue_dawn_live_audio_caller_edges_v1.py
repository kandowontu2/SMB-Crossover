"""Supplemental real ControlStep192/foreign callers; no audio scheduler."""
from pathlib import Path
import itertools,json,sys,traceback
R=Path(__file__).resolve().parents[1];sys.path[:0]=[str(R/'tools'),str(R/'tools/audit')]
import rogue_dawn_live_audio_controls_v1 as c
from sunny_integrated_controls_v1 import registers,app
from check_tmnt_render_oa import address,location
from link_pit_rygar_sophia_audit_cpu import scoped_load
O=c.O;w=c.w;put,get=c.put,c.get;ref=c.ref

def main():
 assert not(O/'caller-edges.json').exists()
 b=scoped_load(O/'candidate.nes');old=scoped_load(c.ui.O/'candidate.nes')
 proof=dict(passed=False,source_CPU_only=True,native_run=False);checks={};minimum=255
 try:
  rows=[]
  for action,keys,health in itertools.product([0,1,2,3,4,6,7,8,255],[0,128],[(0x69,1),(0x70,1)]):
   m=w.life.make(b);put(m,RdAction=action,RdHealthLo=health[0],RdHealthHi=health[1],RdClock=0,RdHeld=keys,RdFresh=keys)
   m[0x5c22]=60;m[0x5c23]=0
   cpu,low,tr=w.call(m,'RdControlStep',sp=192);minimum=min(minimum,low)
   assert low>=128
   actual=[pc for pc,bank in tr if pc==address(b,'RdaLowHealth')and bank==62]
   assert len(actual)<=2
   assert m[0x5c22] in[59,60]if health[0]==0x69 else m[0x5c22]in[0,60]
   rows.append(dict(action=action,pad=keys,source_health=list(health),actual_counter_callbacks=len(actual),counter_after=m[0x5c22],minimum_SP=low,CPU=cpu.processorCycles))
  checks['real_ControlStep_public_SP192']=rows
  rows=[]
  for kind in['IRQ','lagNMI']:
   for name,bank in[('RdCueHealthGate',95),('RdaLowHealth',62)]:
    m=w.life.make(b);put(m,RdAction=0,RdClock=0,RdHealthLo=0x69,RdHealthHi=1);m[0x5c22]=60
    cpu,low,tr=w.call(m,'RdControlStep',sp=192,seam=(address(b,name),bank,kind));minimum=min(minimum,low)
    assert low>=128 and m[0x5c22]==59
    rows.append(dict(public_entry_SP=192,interrupt=kind,PC=hex(address(b,name)),physical_bank=bank,minimum_SP=low))
  checks['actual_IRQ_lagNMI_inside_ControlStep192']=rows
  # Exact old public source PCs and CORE/AUX/C94 bridge, no redirection there.
  unchanged=[]
  for name in['RdControlStep','RdControlDispatch','RdControlPhysics','RdHostBridgeStart','RdKernelEnd','RdWeaponsEnd']:
   assert address(b,name)==address(old,name)and location(b,name)==location(old,name),name
  for name,size in[('RdHostBridgeStart',175),('RdControlDispatch',508),('RdStartJump',2293)]:
   p,q=location(b,name),location(old,name)
   assert b['raw'][p:p+size]==old['raw'][q:q+size],name
   unchanged.append(dict(symbol=name,bytes=size,CPU=hex(address(b,name))))
  checks['immutable_source_and_callback_bridge_spans']=unchanged
  foreign=[]
  for char,mode in itertools.product([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,23],[0,1]):
   pair=[]
   for bundle in[old,b]:
    m=w.life.make(bundle,mode);put(m,SelectedCharacter=char,RdVariant=0,SavedJoypadBits=1)
    cpu,row=w.life.mainstep(m,first=True);minimum=min(minimum,row['minimum_SP'])
    class Q:pass
    q=Q();q.b=bundle;q.m=m
    pair.append((registers(cpu),app(q),tuple(m.banks),cpu.processorCycles,row['actual_Main_calls']))
   assert pair[0]==pair[1],('foreign full Main',char,mode)
   foreign.append(dict(raw_character=char,mode=mode,CPU_delta=0))
  checks['all_23_supported_foreign_complete_Main_modes']=foreign
  # Real scene/newlife resets intentionally clear counter, while initializing
  # source health through existing approved lifecycle arithmetic.
  init=[]
  for name in['RdHsEnterScene','RdHsNewLife','RdHsNewSession']:
   m=w.life.make(b);m[0x5c22]=0x7d
   cpu,low,tr=w.call(m,name,sp=224);minimum=min(minimum,low)
   assert m[0x5c22]==0
   init.append(dict(entry=name,counter_after=0,minimum_SP=low))
  checks['genuine_lifecycle_counter_zero']=init
  proof.update(passed=True,checks=checks,minimum_SP=minimum,bindings=[ref.binding(p)for p in[Path(__file__),O/'candidate.nes',O/'candidate.dbg',O/'candidate.lbl',O/'controls.json',c.ui.O/'candidate.nes']],limits=['Genuine initialized existing legacy NMI/IRQ is used; authentic new driver remains unhooked.','No real whole-NMI deadline/mixer/context/RNG schedule or native claim.'])
 except Exception as e:
  proof.update(error=repr(e),traceback=traceback.format_exc(),checks=checks)
  target=O/'caller-edges-negative.json'
  assert not target.exists(),'Preserve first edge negative'
  target.write_text(json.dumps(proof,indent=2)+'\n');raise
 (O/'caller-edges.json').write_text(json.dumps(proof,indent=2)+'\n')
 print(json.dumps(dict(passed=True,ControlStep192=len(checks['real_ControlStep_public_SP192']),IRQ_lagNMI=4,foreign_fullMain=len(foreign),minimum_SP=minimum)))

if __name__=='__main__':main()
