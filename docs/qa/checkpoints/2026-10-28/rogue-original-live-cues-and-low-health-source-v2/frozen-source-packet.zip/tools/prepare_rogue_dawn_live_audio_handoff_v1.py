"""Freeze this bounded source/caller unit, excluding common audio admission."""
from pathlib import Path
import json,re,sys
R=Path(__file__).resolve().parents[1];sys.path[:0]=[str(R/'tools'),str(R/'tools/audit')]
import rogue_dawn_live_audio_controls_v1 as ctl
from link_pit_rygar_sophia_audit_cpu import scoped_load
from check_tmnt_render_oa import address,location
from prepare_rogue_dawn_audio_driver_v4 import labels
from prepare_rogue_dawn_host_body_handoff_v1 import dependencies
O=ctl.O;P=ctl.ui.O;D=R/'build/rogue-dawn-audio-driver-v4';ref=ctl.ref;w=ctl.w
REPORT=R/'docs/qa/rogue-dawn-live-audio-source-2026-10-29.json'

def main():
 assert not(O/'handoff.json').exists(),'Frozen unit'
 build=json.loads((O/'build.json').read_text());control=json.loads((O/'controls.json').read_text());edges=json.loads((O/'caller-edges.json').read_text())
 assert control['passed']and edges['passed']
 for data in[build,control,edges]:
  for q in data['bindings']:assert ref.binding(q['path'])==q,q['path']
 old=scoped_load(P/'candidate.nes');b=scoped_load(O/'candidate.nes');audio=scoped_load(D/'candidate.nes')
 # Full assembled union, allowing exactly the true emitted audio segments,
 # two old callback JMP targets, and the22B added foreground farcall gate.
 spans=[]
 for seg in b['segs'].values():
  name=seg['name'].strip('"')
  if name.startswith('ROGUE_AUDIO_'):
   spans.append((int(seg['ooffs'],0),int(seg['ooffs'],0)+int(seg['size'],0),name))
 gate=location(b,'RdCueLowHealthGate');end=location(b,'RdCueGateEnd')
 spans.append((gate,end,'single A95 callback gate'))
 # Callback JMPs retain instruction length, old control/bridge remain literal.
 p=location(b,'RdHostDispatch');q=location(old,'RdHostDispatch')
 assert p==q
 size=int(b['syms']['RdHostDispatch']['size'],0)
 for i,(a,z)in enumerate(zip(old['raw'][q:q+size],b['raw'][p:p+size])):
  if a!=z:spans.append((p+i,p+i+1,'two original callback JMP target operands'))
 assert sum(1 for a,z in zip(old['raw'][q:q+size],b['raw'][p:p+size])if a!=z)<=4
 changed=[]
 for i,(a,z)in enumerate(zip(old['raw'],b['raw'])):
  if a!=z:
   assert any(lo<=i<hi for lo,hi,n in spans),('Unowned ROM difference',i)
   changed.append(i)
 assert old['raw'][:16]==b['raw'][:16]and old['raw'][16+1048576:]==b['raw'][16+1048576:]
 def public_exports(path):
  text=path.read_text().split('Exports list by name:',1)[1].split('Exports list by value:',1)[0]
  return {n:int(v,16)for n,v in re.findall(r'(\w+)\s+([0-9A-F]{6})\s+[A-Z]{2}',text)}
 oldlabels=public_exports(P/'candidate.map');newlabels=labels(O/'candidate.lbl');newexports=public_exports(O/'candidate.map')
 assert all(newexports.get(n)==v for n,v in oldlabels.items()),[(n,v,newexports.get(n))for n,v in oldlabels.items()if newexports.get(n)!=v][:20]
 # Existing APU-helper/driver entry PCs remain genuine compiler labels. All
 # original raw ROM data and depot map spans compare to the frozen c159 view.
 raw_spans=[]
 for seg in audio['segs'].values():
  name=seg['name'].strip('"')
  if name.startswith('ROGUE_AUDIO_PAGES_')or name.startswith('ROGUE_AUDIO_UPPER_RAW_')or name=='ROGUE_AUDIO_PAGE_MAP':
   start=int(seg['ooffs'],0);size=int(seg['size'],0)
   assert b['raw'][start:start+size]==audio['raw'][start:start+size],name
   raw_spans.append(dict(name=name,file_offset=start,bytes=size,sha256=ref.digest(b['raw'][start:start+size])))
 costs=[]
 for service in[7,8]:
  for counter in[0,60]:
   for health in[(0x69,1),(0x70,1)]:
    pair=[]
    for bundle in[old,b]:
     m=w.life.make(bundle);ctl.put(m,RdHostService=service,RdHealthLo=health[0],RdHealthHi=health[1]);m[0x5c22]=counter
     cpu,low,tr=w.call(m,'RdHostDispatch',a=0,x=13,y=87,p=0x71,sp=224)
     pair.append(dict(CPU=cpu.processorCycles,minimum_SP=low))
    costs.append(dict(service=service,counter=counter,source_BCD_health=list(health),old_stub=pair[0],new_real_callback=pair[1],CPU_delta=pair[1]['CPU']-pair[0]['CPU']))
 maincost=[]
 for mode,keys in[(0,0),(1,0),(0,1),(1,1)]:
  for health in[(0x69,1),(0x70,1)]:
   pair=[]
   for bundle in[old,b]:
    m=w.life.make(bundle,mode);ctl.put(m,RdHealthLo=health[0],RdHealthHi=health[1],RdClock=0,SavedJoypadBits=keys);m[0x5c22]=60
    cpu,row=w.life.mainstep(m,first=True);pair.append(dict(CPU=cpu.processorCycles,minimum_SP=row['minimum_SP'],actual_Main_calls=row['actual_Main_calls']))
   assert pair[0]['actual_Main_calls']==pair[1]['actual_Main_calls']==1
   maincost.append(dict(mode=mode,pad=keys,source_BCD_health=list(health),old=pair[0],new=pair[1],CPU_delta=pair[1]['CPU']-pair[0]['CPU']))
 report=dict(status='PRIVATE_SOURCE_LIVE_CUES_AND_ACTUAL_LOW_HEALTH_COUNTER_QUALIFIED',native_run=False,playable_admission=False,common_audio_hook=False,
  ROM=ref.binding(O/'candidate.nes'),UI_parent=ref.binding(P/'candidate.nes'),audio_parent=ref.binding(D/'candidate.nes'),
  precise_deltas=dict(source0680='live5C20',source0681='live5C21',source0682='NMI-privateRdaState82; no Main producer/read',source0683='live5C23',source0684='live5C24',source0685='live5C25',source06C4='identity-exclusive5C22',source0686='unchanged5C26 morph/Screw state; not six-cue clear',source061F='unchanged5C7A persistent BeamSfx selector'),
  source_semantics=dict(low_health='Actual3:B189 AND3C/CMP3C; CBF3 LDA08/LDX03/OR queue3, then DEC06C4. Genuine Control CE66..CE83 calls only each sourceClock low-nibble0 below rawBCD0170.',health_callback='Actual3:B199 resets06C4 only if health>=0170, preserving low counter otherwise. Original source-room B133 hazard is not fabricated.',direct_cues='Original Main OR/STA non-atomic resurrection retained. No event ring, cue busy bit, epoch, snapshot/writeback or unconditional Main-counter clear.',normal_pause='Actual normal phase0/init clear live five cues plus privateQ2; mode5 retains allsix. Driver-internal B192 queue1 producer also directly aliases live5C21.',lifecycle='Genuine source enter-scene/life/session and private owner-init may zero counter; no ordinary NMI clear touches5C22.'),
  layout=dict(A95_gate='BEE0..BEF5',A95_gate_bytes=22,A95_free_before_death=10,A62_adapter_start='BD27',A62_adapter_bytes=build['adapter_bytes'],A62_adapter_end=hex(newlabels['RdaAdapterEnd']),A62_free=build['adapter_spare'],no_new_RAM=True,new_counter_is_previously_unproduced_Q2_only=True,all_old_exported_labels_exact=len(oldlabels)),
  verified=dict(original_callback_comparisons=2560,complete_foreground_Mains=576,actual_audio_ticks=120,phase0_normal_pause_init_cases=30,known_indexed_compiled_producers=11,exact_driver_queue_instructions=15,ControlStep192_cases=36,IRQ_lagNMI_seams=12,foreign_full_Main_modes=46,foreign_dispatch_cases=39,actual_minimum_SP=min(control['minimum_SP'],edges['minimum_SP']),guard_floor=128,raw_ROM_views=raw_spans,header_CHR_exact_UI890=True),
  costs=dict(callbacks=costs,complete_Rogue_Main=maincost,foreign_complete_Main_added_CPU=0,comparison='Old UI890 had explicit low-health stub and health-byte store, so positive owned cost closes actual missing source behavior; not a speedup or zero-lag claim.'),
  actual_source_closure=dict(actual_new_ca65_ASM_inputs=build['actual_ASM_inputs'],cached_weapon_object=ref.binding(P/'weapon-object.o'),cached_object_source_receipt=ref.binding(P/'build.json'),cached_object_source_inputs=[ref.binding(p)for p in dependencies(P/'weapon-object.dep')],no_full_source_runtime_copies=True),
  retained_negatives=dict(private_wrong_queue1_helper=ref.binding(O/'preparation-negative-v1.json'),original_phase1='Original typed area3+phase1 invalid RAM-note pointers remain unsupported scripted-context behavior; no broad driver-transition pass.',prior_real_Main_stack='Original unsafe immediate transaction SP192 negative and all lifecycle/body packets remain immutable; current callback ControlStep192 minimum144 is separately qualified.'),
  integration_open=['Root common BEGIN/COMMIT/NMI context owner and5FB6 completedMain RNG rhythm; no counter hook yet.','Current diagnostic RdaAudioTick still advances original RNG per diagnostic call, not the proposed completedMain source schedule.','NMI-only initialization/retirement, context/theme/pause acquisition and mixer/DMC/hardware APU closure.','Actual complete authentic-audio NMI stack/deadline and source-host visibility/audio native testing.','A62 has59B free; diagnostic SetQueue/SetArea/SetMode total147B may be reclaimed only in a separately reviewed successor.'],
  exact_allowed_ROM_spans=[dict(file_offset=a,bytes=z-a,purpose=n)for a,z,n in spans],
  no_original_color_pixel_or_native_claim=True)
 REPORT.write_text(json.dumps(report,indent=2)+'\n')
 paths=[Path(q['path'])for q in build['bindings']]
 paths+=[Path(q['path'])for q in json.loads((P/'build.json').read_text())['bindings']]
 paths+=[Path(q['path'])for q in json.loads((D/'build-proof.json').read_text())['bindings']]
 paths += [Path(__file__),REPORT,O/'build.json',O/'controls.json',O/'caller-edges.json',O/'first-controls-negative.json',O/'preparation-negative-v1.json',R/'tools/rogue_dawn_live_audio_controls_v1.py',R/'tools/rogue_dawn_live_audio_caller_edges_v1.py',R/'docs/qa/rogue-dawn-live-cue-semantics-2026-10-29.json']
 owned=[R/'tools/prepare_rogue_dawn_live_audio_v1.py',R/'tools/rogue_dawn_live_audio_controls_v1.py',R/'tools/rogue_dawn_live_audio_caller_edges_v1.py',Path(__file__),R/'src/rogue_dawn_audio_live_v1.s',R/'src/rogue_dawn_audio_live_native_v1.inc',R/'src/rogue_dawn_live_cue_gate_v1.s',REPORT]
 owned += [O/n for n in['entrypoint.s','live-deferred.s','main.c','live-driver-imports.inc','private.cfg','source.patch','build.json','controls.json','caller-edges.json','preparation-negative-v1.json','first-controls-negative.json','assembler-full.dep','audio0.dep','audio1.dep','audio2.dep']]
 packet=dict(passed=True,source_only=True,native_run=False,shared_hooks=False,ROM_sha256=build['ROM']['sha256'],report=ref.binding(REPORT),bindings=[ref.binding(p)for p in dict.fromkeys(paths)],owned_publication_files=[ref.binding(p)for p in owned],runtime_artifacts_no_public_copy=[ref.binding(O/('candidate'+s))for s in['.nes','.dbg','.lbl','.map']],open=report['integration_open'])
 (O/'handoff.json').write_text(json.dumps(packet,indent=2)+'\n')
 print(json.dumps(dict(ROM=packet['ROM_sha256'],handoff=ref.binding(O/'handoff.json'),report=ref.binding(REPORT),bindings=len(packet['bindings']),owned=len(owned),owned_Main_added_CPU=sorted(set(x['CPU_delta']for x in maincost)))))

if __name__=='__main__':main()
