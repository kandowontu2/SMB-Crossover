"""Read-only original kick + real linked Main pipe arena; no ROM/native edits."""
from pathlib import Path
import argparse,json,sys
R=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(R/'tools'),str(R/'tools/audit')]
import dragon_power_map_v1 as D
import dragon_power_reference_v1 as O
import dragon_power_gameplay_controls_v1 as C
import dragon_power_flagpole_controls_v2 as T
from sunny_integrated_controls_v1 import scoped_load,run,address,sha

ROM=R/'build/dragon-power-flagpole-v3/candidate.nes'

def original(kick):
 m=O.arena();rows=[]
 for age in range(90):
  fresh=(1 if age==0 else 0)|(2 if age==kick else 0)
  O.step(m,128|fresh,fresh)
  rows.append([age+1,m.ram[0xf7],m.ram[0xf8],m.ram[0x2d],m.ram[0x34],m.ram[0x448]])
  if age>3 and m.ram[0x2d]==1:break
 high=[z for z in rows if z[2]<=144]
 return dict(kick_update=None if kick is None else kick+1,
  max_horizontal_at_least16_above_start=max([z[1]-80 for z in high],default=-1),
  min_Y=min(z[2]for z in rows),trail=rows)

def arena(b,x,mode):
 q=C.setup(b);q.put(CrossoverBehaviorVersion=mode,AreaPointer=37,WorldNumber=0,Hidden1UpFlag=1)
 run(q,'GetAreaDataAddrs')
 for j in range(3):q.set('AreaObjectLength',255,j)
 cols=[]
 for _ in range(64):
  run(q,'AreaParserCore');cols.append([q.get('MetatileBuffer',y)for y in range(13)])
  run(q,'IncrementColumnPos')
 assert cols[38][8]==0x12 and cols[46][7]==0x12,('authentic pipe caps',cols[38],cols[46])
 for xx,col in enumerate(cols):
  for yy,t in enumerate(col):q.m[address(b,'Block_Buffer_1')+((xx//16)%2)*208+yy*16+xx%16]=t
 cam=x-96
 q.put(Player_PageLoc=x//256,Player_X_Position=x%256,Player_Y_Position=128,Player_Rel_XPos=96,
  ScreenLeft_PageLoc=cam//256,ScreenLeft_X_Pos=cam%256,ScreenRight_PageLoc=(cam+255)//256,
  ScreenRight_X_Pos=(cam+255)%256,Player_Pos_ForScroll=96)
 # Disclosed geometry/position setup only. No source action/velocity/contact,
 # enemy/outcome, HP/resource or progression writes after authentic initialization.
 for _ in range(4):T.tick(q,0)
 return q

def host(b,x,mode,kick):
 q=arena(b,x,mode);start={n:q.get(n)for n in ['DpAction','DpVertical','DpHP','DpPole','DpWaves','DpPower']}
 rows=[];seen=set();costs=[];mn=255
 for age in range(100):
  keys=1|(128 if age==0 else 0)|(64 if age==kick else 0)
  c,tr,sp,cy,ni=T.tick(q,keys);seen.update(tr);costs.append([cy,ni]);mn=min(mn,sp)
  rows.append([age+1,q.get('Player_PageLoc')*256+q.get('Player_X_Position'),q.get('Player_Y_Position'),
   q.get('DpAction'),q.get('DpVertical'),q.get('DpPlatform',2),q.get('DpContacts'),q.get('DpContacts',1)])
  if age>4 and q.get('DpAction')==1:break
 high=[z for z in rows if z[2]<=112]
 return dict(mode=mode,takeoff_x=x,kick_update=None if kick is None else kick+1,start=start,
  min_Y=min(z[2]for z in rows),max_X_at_required_anchor112=max([z[1]for z in high],default=-1),
  landed_on_third=any(z[1]>=722 and z[2]==112 and z[3]==1 for z in rows),
  kick_entry_reached=(86,address(b,'DpNEA0C'))in seen,minimum_SP=mn,
  Main_CPU=[min(v[0]for v in costs),max(v[0]for v in costs)],
  normal_NMI_CPU=[min(v[1]for v in costs),max(v[1]for v in costs)],trail=rows)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);a=ap.parse_args()
 assert not a.output.exists();assert sha(ROM)=='7c5a0f1ee9d924f76857d97d8b194472cb01bf7f2a49a60daf7a32ede4268cd4'
 b=scoped_load(ROM);orig=[original(k)for k in[None]+list(range(1,50))]
 hosts=[host(b,x,mode,k)for mode in range(2)for x in[635,637]for k in[None,25,36,40]]
 edges=[]
 for x in range(635,646):
  q=arena(b,x,1);edges.append([x,q.get('Player_PageLoc')*256+q.get('Player_X_Position'),q.get('Player_Y_Position'),q.get('DpAction'),q.get('DpVertical')])
 assert max(z['max_horizontal_at_least16_above_start']for z in orig)==68
 assert not any(z['landed_on_third']for z in hosts)
 files=[Path(__file__),Path(D.__file__),Path(O.__file__),Path(C.__file__),Path(C.M.__file__),Path(T.__file__),
  R/'tools/audit/sunny_integrated_controls_v1.py',ROM,ROM.with_suffix('.dbg'),ROM.with_suffix('.lbl'),D.ROM]
 result=dict(passed=True,scope='Finite CPU instruction arenas, no native/PPU timing or new source/ROM',
  fields_original=['update','sourceX','sourceY','action','verticalPhase','platform448'],
  fields_host=['update','worldX','PlayerY','action','verticalPhase','platform2','foot0','foot1'],
  original_cases=orig,host_cases=hosts,settled_pipe_edge_cases=edges,
  original_disassembly={f'3:{p:04X}':D.disassembly(3,p,n)for p,n in [(0xe9b3,111),(0xeae1,81),(0xe8c3,33)]},
  bindings={str(p.resolve()):sha(p)for p in files})
 a.output.write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(dict(passed=True,original_cases=len(orig),host_cases=len(hosts),edge_cases=edges,
  max_original_high_displacement=68,best_host=max(z['max_X_at_required_anchor112']for z in hosts),
  host_landing_count=sum(z['landed_on_third']for z in hosts),output=str(a.output),sha256=sha(a.output))))
if __name__=='__main__':main()
