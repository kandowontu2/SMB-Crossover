"""Bounded native25 reciprocal-manager and actual Main/NMI CPU controls."""
from pathlib import Path
import argparse,itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import dragon_power_gameplay_controls_v1 as C
import dragon_power_flagpole_controls_v2 as T
import dragon_power_platform_controls_v1 as H
import dragon_power_gameplay_render_v3 as D
from sunny_integrated_controls_v1 import *
P=R/'build/dragon-power-flagpole-v3';O=R/'build/dragon-power-two-platforms-v1'

def fresh(b,mode=1,center=704,camera=None):
 if camera is None:camera=center-96
 q=H.fresh(b,mode,camera)
 q.put(Player_PageLoc=center//256,Player_X_Position=center%256,Player_Y_Position=176,
  Player_Rel_XPos=center-camera,Player_Pos_ForScroll=center-camera)
 return q

def approach(b,mode,center,wait):
 q=fresh(b,mode,center);q.put(Hidden1UpFlag=1)
 for j in range(3):q.set('AreaObjectLength',255,j)
 cols=[]
 for _ in range(64):
  run(q,'AreaParserCore');cols.append([q.get('MetatileBuffer',y)for y in range(13)])
  run(q,'IncrementColumnPos')
 for xx,col in enumerate(cols):
  for y,t in enumerate(col):q.m[address(b,'Block_Buffer_1')+((xx//16)%2)*208+y*16+xx%16]=t
 rows=[];jump=None;contacts=0;seen=set();minsp=255
 target=752 if center==704 else 928
 for age in range(300):
  slot=q.get('HpActorSlot')-1
  support=slot>=0 and q.get('PlatformCollisionFlag',slot)<128
  x=q.get('Player_PageLoc')*256+q.get('Player_X_Position');y=q.get('Player_Y_Position')
  if support and y<=144 and age>=wait and jump is None:jump=age
  keys=(1 if jump is not None and x<target else 0)|(128 if jump is not None and age-jump<8 else 0)
  c,tr,mn,cy,ni=T.tick(q,keys);seen.update(tr);minsp=min(minsp,mn)
  slot=q.get('HpActorSlot')-1;support=slot>=0 and q.get('PlatformCollisionFlag',slot)<128
  contacts+=support
  xx=q.get('Player_PageLoc')*256+q.get('Player_X_Position');yy=q.get('Player_Y_Position')
  rows.append([age,keys,xx,yy,q.get('DpAction'),slot,q.get('Enemy_Y_Position',slot)if slot>=0 else-1,support,q.get('DpPlatform'),cy,ni,mn])
  if xx>=target and yy==112 and q.get('DpAction')==1:break
 assert rows[-1][2]>=target and rows[-1][3]==112 and q.get('DpAction')==1 and contacts,('actual Main pipe landing',mode,center,wait,rows[-1])
 assert ((location(b,'YMovingPlatform')-16)//8192,address(b,'YMovingPlatform'))in seen
 assert (26,address(b,'HpSine'))not in seen and(26,address(b,'HpMoveNativeHelper'))not in seen
 assert q.get('DpPower')==q.get('DpPole')==q.get('DpWaves')==0
 return dict(mode=mode,center=center,wait=wait,updates=len(rows),first_fresh_A=jump,
  support_updates=contacts,minimum_SP=minsp,rows=rows,typed_position_map_only=True)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();assert not a.output.exists()
 old,b=[scoped_load(p/'candidate.nes')for p in[P,O]]
 proof=dict(passed=False,source_CPU_only=True,native_run=False,checks={});ck=proof['checks']
 try:
  rows=[]
  for center,mode,flags,warm in itertools.product([704,888],range(2),[f for f in range(256)if f&0x30==0x30],range(2)):
   pair=[]
   for v in[old,b]:
    q=fresh(v,mode,center)
    if warm:run(q,'NrWeapons')
    c,tr,mn=C.M.runtrace(q,'NrWeapons',a=91,x=177,y=66,p=flags)
    pair.append((registers(c),bytes(q.m[:8]),q.get('ObjectOffset'),tuple(q.m.banks),c.processorCycles,mn))
   assert pair[0][:4]==pair[1][:4],('real full weapon return ABI',center,mode,flags,warm,pair)
   rows.append([center,mode,flags,warm,pair[1][-2]-pair[0][-2],pair[1][-1]])
  ck['actual_NrWeapons_full_return']=dict(cases=len(rows),rows=rows,AXYP_SP_R0_R7_ObjectOffset_banks_exact=True)
  rows=[]
  for center,mode,used in itertools.product([704,888],range(2),range(7)):
   q=fresh(b,mode,center)
   for i in range(used):C.actor(q,i,6,100+i*16,176)
   before=[[q.get(n,i)for n in['Enemy_Flag','Enemy_ID','Enemy_State','Enemy_X_Position']]for i in range(used)]
   run(q,'NrWeapons');aa=H.owned(q);assert len(aa)==int(used<6)
   assert before==[[q.get(n,i)for n in['Enemy_Flag','Enemy_ID','Enemy_State','Enemy_X_Position']]for i in range(used)]
   if aa:assert aa[0][1:]==(center-16,208)and q.get('Enemy_BoundBoxCtrl',aa[0][0])==5
   assert q.get('HpCount')==0;rows.append([center,mode,used,aa])
  ck['native_capacity']=dict(rows=rows,at_most_one_owned_actor=True,all_busy_no_steal=True)
  rows=[]
  for center,mode in itertools.product([704,888],range(2)):
   q=fresh(b,mode,center);run(q,'NrWeapons');slot=H.owned(q)[0][0]
   # Authentic native carry flag is the native consumer's exact slot index.
   q.set('PlatformCollisionFlag',slot,slot)
   q.put(Player_PageLoc=3 if center==704 else 2,Player_X_Position=48 if center==704 else 248)
   before=H.owned(q);run(q,'NrWeapons');assert H.owned(q)==before and q.get('HpXLo')+256*q.get('HpXHi')==center
   # Real mature physical grant, never an acquired-resource seed.
   item=next(i for i in range(6)if not q.get('Enemy_Flag',i))
   C.actor(q,item,46,96,176);q.set('Enemy_State',128,item);q.set('PowerUpType',0,item)
   run(q,'NrPickup',x=item);assert q.get('DpPower')==1 and q.get('DpPole')==1
   run(q,'NrWeapons');assert H.owned(q)==before
   q.set('PlatformCollisionFlag',255,slot);run(q,'NrWeapons')
   other=888 if center==704 else 704
   if center==888:
    # Desired704 is88px left of the old camera792: correct native margin
    # retirement, then a real camera loopback makes that position eligible.
    assert not H.owned(q),('outside left margin must not spawn',mode,H.owned(q))
    q.put(ScreenLeft_PageLoc=2,ScreenLeft_X_Pos=96)
    run(q,'NrWeapons')
   assert len(H.owned(q))==1 and H.owned(q)[0][1:]==(other-16,208),('released center switch',mode,center,H.owned(q))
   assert q.get('HpXLo')+256*q.get('HpXHi')==other
   q.put(AreaPointer=194);run(q,'NrWeapons');assert len(H.owned(q))==1
   q.put(ScreenLeft_PageLoc=5,ScreenLeft_X_Pos=0);run(q,'NrWeapons');assert not H.owned(q)
   run(q,'InitializeArea');assert not any(q.get('Enemy_Flag',i)for i in range(6))and q.get('HpSupport')==0
   rows.append([center,mode,slot,other])
  ck['passenger_threshold_pickup_retirement_scene']=dict(rows=rows,real_mature_pickup_retains=True,future_AreaPointer_ignored=True)
  for center,change in itertools.product([704,888],['owner','ID','flag','state','pointer']):
   q=fresh(b,1,center);run(q,'NrWeapons');slot=H.owned(q)[0][0]
   if change=='owner':q.set('HpActorOwner',2,slot)
   elif change=='ID':q.set('Enemy_ID',6,slot)
   elif change=='flag':q.set('Enemy_Flag',2,slot)
   elif change=='state':q.set('Enemy_State',0,slot)
   else:q.put(HpActorSlot=7)
   before=[q.get(n,slot)for n in['Enemy_Flag','Enemy_ID','Enemy_State']]
   run(q,'DpPlatformRelease');assert before==[q.get(n,slot)for n in['Enemy_Flag','Enemy_ID','Enemy_State']]
  ck['ten_stale_wrong_owner_no_erase']=True
  rows=[]
  for name,val in [('SelectedCharacter',23),('WorldNumber',1),('LevelNumber',1),('AreaType',2),('AreaAddrsLOffset',6),('HpValid',0),('HpCount',1),('HpArea',0x26),('HpKey',1),('HpCharacter',23),('HpMode',0),('GamePauseStatus',1),('TimerControl',1),('GameEngineSubroutine',7)]:
   q=fresh(b);q.set(name,val)
   before=bytes(q.m[address(b,'HpRamStart'):address(b,'HpRamEnd')])
   run(q,'DpPlatformTick');assert not H.owned(q)
   assert before==bytes(q.m[address(b,'HpRamStart'):address(b,'HpRamEnd')]),('negative cache changed',name)
   rows.append([name,val])
  ck['raw_scene_cache_pause_negative_admission']=rows
  rows=[]
  for center,mode in itertools.product([704,888],range(2)):
   q=fresh(b,mode,center);T.tick(q,0)
   c,events,mn,tr=D.draw(q)
   girder=[e for e in events if e['ptr']==address(b,'MetaspritePlatformGirderSmall')]
   assert len(girder)==1 and girder[0]['header']==16 and girder[0]['accepted']
   rows.append([center,mode,girder[0]['before'],girder[0]['after'],girder[0]['rotation']])
  ck['actual_native_girder_DrawAll']=dict(rows=rows,native_A4_four_parts_only=True)
  ck['actual_complete_Main_normal_NMI_approaches']=[approach(b,m,c,w)for m,c,w in itertools.product(range(2),[704,888],[0,64,120])]
  rows=[]
  for ch,mode,keys in itertools.product([i for i in range(29)if i!=24],range(2),[0,129]):
   pair=[]
   for v in[old,b]:
    q=C.setup(v,ch);q.put(CrossoverBehaviorVersion=mode,SavedJoypadBits=keys)
    c,tr,mn=C.M.runtrace(q,'GameLoop',p=0x71)
    pair.append((registers(c),C.M.fastapp(q),tuple(q.m.banks),bytes(q.m[z]for z in smc_at(v)),bytes(q.m[0x100:0x200]),list(q.m.writes),c.processorCycles))
   assert pair[0]==pair[1],('foreign complete Main',ch,mode,keys);rows.append([ch,mode,keys])
  ck['foreign_full_Main']=dict(cases=len(rows),AXYP_SP_entire_stack_application_OAM_CHR_5SMC_ordered_writes_CPU_exact=True)
  rows=[]
  for center,mode,scene in itertools.product([704,888],range(2),['spawn','warm','switch']):
   pair=[]
   for v in[old,b]:
    q=fresh(v,mode,center)
    if scene!='spawn':run(q,'NrWeapons')
    if scene=='switch':q.put(Player_PageLoc=3 if center==704 else 2,Player_X_Position=48 if center==704 else 248)
    c,tr,mn=C.M.runtrace(q,'GameLoop',p=0x71)
    pair.append((registers(c),tuple(q.m.banks),bytes(q.m[z]for z in smc_at(v)),c.processorCycles,mn))
   assert pair[0][:3]==pair[1][:3],('owned Main return',center,mode,scene,pair)
   rows.append([center,mode,scene,pair[0][-2],pair[1][-2],pair[1][-2]-pair[0][-2],pair[1][-1]])
  ck['owned_complete_Main_CPU']=dict(rows=rows,AXYP_SP_final_banks_5SMC_exact=True,actor_cache_OAM_intentionally_differ=True)
  events=[]
  for center,kind,scene in itertools.product([704,888],['IRQ','NMI'],['spawn','warm','switch','outside']):
   q=fresh(b,1,center)
   if scene!='spawn':run(q,'NrWeapons')
   if scene=='switch':q.put(Player_PageLoc=3 if center==704 else 2,Player_X_Position=48 if center==704 else 248)
   if scene=='outside':q.put(ScreenLeft_PageLoc=5)
   rows,mn=H.irq(q,kind);assert rows
   events.append(dict(center=center,kind=kind,scene=scene,seams=len(rows),minimum_SP=mn))
  ck['actual_reached_IRQ_lagNMI']=events
  proof['passed']=True
 except Exception as e:proof.update(failure=repr(e),traceback=traceback.format_exc())
 files=[Path(__file__),Path(C.__file__),Path(C.M.__file__),Path(T.__file__),Path(H.__file__),Path(D.__file__),
  O/'candidate.nes',O/'candidate.dbg',O/'candidate.lbl',O/'platform.inc',R/'tools/prepare_dragon_power_two_platforms_v1.py',P/'candidate.nes',P/'candidate.dbg',P/'handoff.json']
 proof['bindings']={str(p.resolve()):sha(p)for p in files};a.output.write_text(json.dumps(proof,indent=2)+'\n')
 print(json.dumps(dict(passed=proof['passed'],failure=proof.get('failure'),checks=list(ck))));assert proof['passed']
if __name__=='__main__':main()
