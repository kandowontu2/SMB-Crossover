"""Full assembled normal-NMI/DMA budgets and real Main-to-NMI HUD progress."""
from pathlib import Path
import argparse,itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import current3cee_postdma_mask_cpu_v4 as N
import dragon_power_hud_budget_controls_v1 as H
from sunny_integrated_controls_v1 import *
O=H.O;C=H.C
def nmi(q,parity=0,lag=False):
 b=q.b;q.set('NmiDisable',255 if lag else 0)
 m=N.Bus(b,bytes(q.m[:0x8000]));m.page(1,q.get('CurrentBank')&127);m.page(2,q.get('CurrentBankC')&127)
 c=NesMPU(memory=m,pc=0x5b00);c.a,c.x,c.y,c.p,c.sp=91,177,66,0x71,253;m.cpu=c;c.processorCycles=parity;c.nmi()
 start=c.processorCycles;enable=None;dmabytes=[]
 for _ in range(100000):
  if c.pc==0x5b00 and c.sp==253:break
  c.step()
  if m.pending_dma:
   page=m[0x4014]*256;dmabytes=bytes(m[page:page+256]);c.processorCycles+=513+(c.processorCycles&1);m.pending_dma=False
  if enable is None and m.stamps and m.stamps[-1][1:]==(0x2001,30):enable=c.processorCycles-start
 else:raise AssertionError(('full NMI timeout',hex(c.pc)))
 assert [c.a,c.x,c.y,c.sp]==[91,177,66,253]
 if not lag:assert enable is not None and len(dmabytes)==256 and m.serial==[8,8]
 else:assert enable is None and not dmabytes
 q.m=m
 return dict(enable_CPU_from_first_NMI_instruction=enable,total_CPU=c.processorCycles-start,dmabytes=dmabytes,writes=m.stamps)
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();assert not a.output.exists()
 b=scoped_load(O/'candidate.nes');proof=dict(passed=False,source_CPU_only=True,native_run=False,checks={});ck=proof['checks']
 try:
  # Actual sole HUD source writer, all12 direct/legacy publication branches.
  # Superset state scan measures budget; it does not claim every mask reachable.
  rows=[]
  for mask in range(4096):
   q=H.setup(b);q.put(Mirror_PPUMASK=30,Mirror_PPUCTRL=168,Sprite0HitDetectFlag=1,X5WideChrActive=1,SsChrActive=0,X5HudChrUpper=0)
   for i in range(12):q.set('X5ChrMode',0x83 if mask>>i&1 else 0,i);q.set('CurrentCHRBank',255,i)
   q.set('ReloadCHRBank',1);run(q,'DpBudgetLate');assert q.get('VRAM_Buffer1_Offset')==15
   z=nmi(q,mask&1);rows.append([mask,z['enable_CPU_from_first_NMI_instruction']])
  assert max(z[1]for z in rows)<2200,('sole HUD normal NMI budget',max(z[1]for z in rows))
  ck['all12_CHR_direct_legacy_masks_full_normal_NMI']=dict(cases=len(rows),both_DMA_parities_across_masks=True,conservative_source_superset_not_reachable_state_claim=True,render_enable_CPU=[min(z[1]for z in rows),max(z[1]for z in rows)],all256_DMA_exact_source_bytes=True)
  rows=[]
  for parity,reload,special,upper,wide,flag in itertools.product(range(2),range(2),range(2),[0,3,127],range(2),range(2)):
   q=H.setup(b);q.put(Mirror_PPUMASK=30,Mirror_PPUCTRL=168,Sprite0HitDetectFlag=flag,X5WideChrActive=wide,SsChrActive=special,X5HudChrUpper=upper,ReloadCHRBank=reload)
   run(q,'DpBudgetLate');assert q.get('VRAM_Buffer1_Offset')==15
   before=bytes(q.m[0x200:0x300]);z=nmi(q,parity);assert z['dmabytes']==before
   assert z['enable_CPU_from_first_NMI_instruction']<2200
   rows.append([parity,reload,special,upper,wide,flag,z['enable_CPU_from_first_NMI_instruction']])
  ck['reload_special_HUD_override_DMA_parity']=dict(cases=len(rows),render_enable_CPU=[min(z[-1]for z in rows),max(z[-1]for z in rows)],DMA256_source_exact=True)
  q=H.setup(b);q.set('X5HudChrUpper',128);before=H.packet(q);run(q,'DpBudgetLate');assert H.packet(q)==before and q.get('VRAM_Buffer1_Offset')==0
  # Actual complete source/Main updates produce CHR reload, consume queues,
  # run normal and lag NMI. No queue/reload/clock seeds between these updates.
  rows=[]
  for walk,mode,phase in itertools.product([0,1],range(2),range(2)):
   q=H.setup(b);q.put(Mirror_PPUMASK=30,Mirror_PPUCTRL=168,Sprite0HitDetectFlag=1,X5WideChrActive=1)
   publications=[];lags=[];reloads=[]
   for age in range(80):
    q.put(SavedJoypadBits=walk,NmiDisable=255,CrossoverBehaviorVersion=mode)
    c,tr,mn=C.M.runtrace(q,'GameLoop');reloads.append(q.get('ReloadCHRBank'))
    size=q.get('VRAM_Buffer1_Offset');lag=age%9 in[phase,phase+1]
    if size==15 and H.packet(q)[:3]==bytes([32,35,12]):
     if not lag:publications.append(age)
    z=nmi(q,age&1,lag);lags.append(int(lag))
   assert publications,('no eventual real HUD publication',walk,mode,phase,reloads)
   assert all(reloads),('test did not actually produce unconditional CHR reload',reloads)
   rows.append(dict(walk=walk,mode=mode,lag_phase=phase,normal_consumed_HUD_ages=publications,actual_reload_each_Main=True,lag_NMIs=sum(lags)))
  ck['real_consecutive_Main_normal_and_lag_NMI_eventual_HUD']=dict(updates=640,rows=rows,no_interupdate_queue_reload_clock_or_resource_seeds=True)
  proof['passed']=True
 except Exception as e:proof.update(failure=repr(e),traceback=traceback.format_exc())
 files=[Path(__file__),Path(N.__file__),Path(H.__file__),Path(C.__file__),O/'candidate.nes',O/'candidate.dbg',O/'core.inc',O/'cold.inc']
 proof['bindings']={str(p.resolve()):sha(p)for p in files};a.output.write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(dict(passed=proof['passed'],failure=proof.get('failure'),checks=ck)));assert proof['passed']
if __name__=='__main__':main()
