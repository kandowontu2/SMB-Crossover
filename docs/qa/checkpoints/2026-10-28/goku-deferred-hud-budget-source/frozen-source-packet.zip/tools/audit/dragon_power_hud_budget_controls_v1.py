"""Actual late HUD/lag retry/foreign Main/ISR controls; no native certification."""
from pathlib import Path
import argparse,itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import dragon_power_gameplay_controls_v1 as C
import dragon_power_gameplay_isr_v1 as I
from sunny_integrated_controls_v1 import *
P=R/'build/dragon-power-admission-v1';O=R/'build/dragon-power-hud-budget-v1'
FLAGS=[f for f in range(256)if f&0x30==0x30]
def setup(b,ch=24):
 q=C.setup(b,ch);run(q,'DpEnsure')if ch==24 else None
 q.put(OperMode=1,DisableScreenFlag=0,AreaParserTaskNum=0,ScrollThirtyTwo=0,DpPaletteAck=0,ReloadCHRBank=0,DpClock=0)
 return q
def packet(q,n=1):
 a=address(q.b,'VRAM_Buffer'+str(n));return bytes(q.m[a:a+(84 if n==1 else 34)])
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();assert not a.output.exists()
 old,b=[scoped_load(p/'candidate.nes')for p in[P,O]];proof=dict(passed=False,source_CPU_only=True,native_run=False,checks={});ck=proof['checks']
 try:
  # Real ResetPalStar plus its returned AXYP, even when optional HUD executes.
  rows=[]
  for ch,flags,attrib in itertools.product([0,15,20,21,23,24,25,28],FLAGS,[0,3,0xa7]):
   pair=[]
   for v,name in[(old,'ResetPalStar'),(b,'DpAdmissionUi')]:
    q=setup(v,ch);q.put(Player_SprAttrib=attrib)
    c,tr,mn=C.M.runtrace(q,name,a=91,x=177,y=66,p=flags)
    pair.append((registers(c),q.get('Player_SprAttrib'),c.processorCycles,mn,tr,q))
   assert pair[0][:2]==pair[1][:2],('real ResetPalStar AXYP',ch,flags,attrib,pair[0][0],pair[1][0])
   assert pair[1][4].count(((location(b,'ResetPalStar')-16)//8192,address(b,'ResetPalStar')))==1
   if ch==24:assert pair[1][5].get('VRAM_Buffer1_Offset')==15
   else:assert pair[1][5].get('VRAM_Buffer1_Offset')==0
   rows.append([ch,flags,attrib,pair[1][2]-pair[0][2],pair[1][3]])
  ck['real_Reset_once_whole_AXYP']=dict(cases=len(rows),CPU_wrapper_vs_bare_leaf=[min(z[3]for z in rows),max(z[3]for z in rows)],min_SP=min(z[4]for z in rows))
  # Every busy condition declines without touching either queue/resources.
  fields='DisableScreenFlag TimerControl VRAM_Buffer_AddrCtrl VRAM_Buffer1_Offset VRAM_Buffer2_Offset VRAM_Buffer1 VRAM_Buffer2 DpPaletteAck StarInvincibleTimer GuestPowerupActive PlayerChangeSizeFlag SmFreezePalettePending SmFreezeRenderState AreaParserTaskNum'.split()
  n=0
  for name,val in [(n,v)for n in fields for v in[1,32,255]]+[('ScrollThirtyTwo',32),('ScrollThirtyTwo',255),('GameEngineSubroutine',7),('GamePauseStatus',1),('OperMode',0)]:
   q=setup(b);q.set(name,val);before=(packet(q),packet(q,2),q.get('VRAM_Buffer1_Offset'),q.get('VRAM_Buffer2_Offset'),q.get('DpHP'),q.get('DpPole'),q.get('DpWaves'),q.get('DpClock'))
   run(q,'DpBudgetLate');after=(packet(q),packet(q,2),q.get('VRAM_Buffer1_Offset'),q.get('VRAM_Buffer2_Offset'),q.get('DpHP'),q.get('DpPole'),q.get('DpWaves'),q.get('DpClock'))
   assert before==after,('busy final packet mutation',name,val);n+=1
  ck['strict_late_admission_declines']=dict(cases=n,queues_and_resources_and_clock_exact=True)
  # All source digits/phase values retain existing writer bytes; empty-only.
  n=0;cost=[]
  for hp,clock in itertools.product([0,9,10,29,30,76,99,100,149,150],range(16)):
   q=setup(b);q.put(DpHP=hp,DpPole=1,DpWaves=3,DpClock=clock)
   c,tr,mn=C.M.runtrace(q,'DpBudgetLate')
   if clock&6:assert q.get('VRAM_Buffer1_Offset')==0
   else:
    expected=bytes([32,35,12,17,25,hp//100,(hp//10)%10,hp%10,36,25,1,36,32,0,3,0])
    assert packet(q)[:16]==expected and q.get('VRAM_Buffer1_Offset')==15
   assert [q.get(n)for n in['DpHP','DpPole','DpWaves','DpClock']]==[hp,1,3,clock]
   cost.append(c.processorCycles);n+=1
  ck['source_digits_and_deferred_clock']=dict(cases=n,CPU=[min(cost),max(cost)],no_new_cache_or_timer=True)
  # Retained optional-only queue is removed before next native producers.
  q=setup(b);run(q,'DpBudgetLate');kept=packet(q);assert q.get('VRAM_Buffer1_Offset')==15
  for _ in range(3):
   q.put(NmiDisable=255);c,_,mn,_,hit=I.interrupt_actual(q,'DpBudgetEarly',inject=(85,address(b,'DpBudgetEarly')),kind='NMI',a=4);assert hit
   assert q.get('VRAM_Buffer1_Offset')==0 and packet(q)[0]==0
   run(q,'DpBudgetLate');assert q.get('VRAM_Buffer1_Offset')==15 and packet(q)==kept
  n=0
  for at in[0,1,2,3,4,8,9,11,12,15]:
   q=setup(b);run(q,'DpBudgetLate');q.m[address(b,'VRAM_Buffer1')+at]^=1;before=packet(q);run(q,'DpBudgetEarly')
   assert packet(q)==before and q.get('VRAM_Buffer1_Offset')==15,('non-own signature retracted',at);n+=1
  for off in[0,14,16,30,45,59,83]:
   q=setup(b);run(q,'DpBudgetLate');q.set('VRAM_Buffer1_Offset',off);before=packet(q);run(q,'DpBudgetEarly')
   assert packet(q)==before and q.get('VRAM_Buffer1_Offset')==off;n+=1
  ck['lag_retention_and_strict_structural_retraction']=dict(real_lag_NMI_cycles=3,wrong_signature_or_offset_declines=n,no_arbitrary_queue_truncation=True)
  # Reconstruct ACTUAL captured normal2654 queue, no estimates as native.
  diag=R/'build/verification/dragon-power-admission-nmi-diagnostic-v1/nmi-queues.jsonl'
  records=[json.loads(z)for z in diag.read_text().splitlines()]
  captured=next(z['data']for z in records if z['kind']=='NMI-entry'and z['stamp']['ppu_frame']==2654)
  original=bytes.fromhex(captured['Buffer1'])[:60];assert captured['VRAM_Buffer1_Offset']==59
  chunks=[];at=0
  while original[at]:
   size=(original[at+2]&63)+3;chunks.append(original[at:at+size]);at+=size
  assert [len(v)-3 for v in chunks]==[2,2,2,6,3,12,2,6]
  omitted=b''.join(v for v in chunks if v[:3]!=bytes([32,35,12]))+bytes([0]);assert len(omitted)==45
  cycles=[]
  for data in[original,omitted]:
   q=setup(b);base=address(b,'VRAM_Buffer1');q.m[base:base+len(data)]=data;q.put(NmiR0=base&255,NmiR1=base>>8)
   fastbank=(location(b,'FastNmiVramCopy')-16)//8192;q.m.page(2,fastbank);q.set('CurrentBankC',fastbank|128)
   c,tr,mn=C.M.runtrace(q,'UpdateScreen');cycles.append(c.processorCycles)
  assert cycles[0]-cycles[1]==272,('real parser savings',cycles)
  q=setup(b);q.m[address(b,'VRAM_Buffer1'):address(b,'VRAM_Buffer1')+60]=original;q.set('VRAM_Buffer1_Offset',59);run(q,'DpBudgetLate');assert packet(q)[:60]==original and q.get('VRAM_Buffer1_Offset')==59
  ck['actual_captured_2654_parser_reconstruction']=dict(native_diagnostic_SHA=sha(diag),captured_lengths=[2,2,2,6,3,12,2,6],real_CPU_UpdateScreen=cycles,source_omission_saves=272,native_corrected_deadline_unrun=True,baseline_remaining44B_packet_unchanged=True)
  # Full genuine foreign Main, retaining caller live stack and ALL final SMC.
  rows=[]
  for ch,mode in itertools.product([0,1,2,3,5,6,8,13,15,19,20,21,22,23,25,26,27,28],range(2)):
   pair=[]
   for v in[old,b]:
    q=setup(v,ch);q.put(CrossoverBehaviorVersion=mode,SavedJoypadBits=1)
    c,tr,mn=C.M.runtrace(q,'GameLoop',p=0x71)
    state=(registers(c),C.M.fastapp(q),bytes(q.m[0x100:0x17b]),tuple(q.m.banks))
    pair.append((state,c.processorCycles,mn,q,tr))
   assert pair[0][0]==pair[1][0],('foreign complete Main',ch,mode,pair[0][0][0],pair[1][0][0])
   rows.append([ch,mode,pair[1][1]-pair[0][1],pair[1][2]])
  ck['foreign_complete_Main']=dict(cases=len(rows),whole_AXYP_SP_app_live_page1_final_SMC_banks_exact=True,CPU_delta=[min(z[2]for z in rows),max(z[2]for z in rows)],min_SP=min(z[3]for z in rows),rows=rows)
  # Full owned Main, actual source clocks and pointer/CHR/body remain stable.
  rows=[]
  for mode,face in itertools.product(range(2),[1,2]):
   q=setup(b);q.put(CrossoverBehaviorVersion=mode,PlayerFacingDir=face)
   for age in range(24):
    q.put(SavedJoypadBits=(1 if face==1 else 2)|(128 if 2<=age<8 else 0),NmiDisable=255)
    c,tr,mn=C.M.runtrace(q,'GameLoop');assert tr.count((86,address(b,'DpSourceFrame')))==1
    assert q.get('DpHP')==100 and q.get('DpClock')==age+1
    if q.get('VRAM_Buffer1_Offset')==15:assert packet(q)[:3]==bytes([32,35,12])
   rows.append([mode,face,c.processorCycles,mn,q.get('VRAM_Buffer1_Offset')])
  ck['owned_complete_Main_repeated_lag_construction']=dict(updates=96,rows=rows,no_health_stock_or_source_clock_change=True)
  # All newly reached source boundaries, physical IRQ and literal NMI gap rule.
  events=[];minimum=255
  for name in['DpAdmissionEarly','DpAdmissionUi']:
   q=setup(b);c,tr,mn=C.M.runtrace(q,name,a=4)
   points=sorted(set((bk,pc)for bk,pc in tr if bk==86 and address(b,'DpAdmissionStart')<=pc<0xc000 or bk==85 and address(b,'DpAdmissionColdStart')<=pc<address(b,'DpAdmissionColdEnd')))
   for kind,point in itertools.product(['IRQ','NMI'],points):
    q=setup(b);c,_,mn,_,hit=I.interrupt_actual(q,name,flags=0x30,inject=point,kind=kind,a=4);assert hit
    minimum=min(minimum,mn);events.append([name,kind,*point])
  ck['actual_IRQ_lagNMI_new_service_boundaries']=dict(cases=len(events),min_SP=minimum,exact_physical_IRQ=True,literal_shadow_windows=I.SHADOW_WINDOWS)
  proof['passed']=True
 except Exception as e:proof.update(failure=repr(e),traceback=traceback.format_exc())
 files=[Path(__file__),Path(C.__file__),Path(I.__file__),O/'candidate.nes',O/'candidate.dbg',O/'candidate.lbl',O/'core.inc',O/'cold.inc',P/'handoff.json',P/'candidate.nes',P/'candidate.dbg',R/'tools/prepare_dragon_power_hud_budget_v1.py']
 proof['bindings']={str(p.resolve()):sha(p)for p in files};a.output.write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(dict(passed=proof['passed'],failure=proof.get('failure'),checks=list(ck))));assert proof['passed']
if __name__=='__main__':main()
