"""Private fb28 late optional-HUD successor; sparse leaves, no native/shared writes."""
from pathlib import Path
import difflib,json,re,subprocess,sys
R=Path(__file__).resolve().parents[1];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
from sunny_integrated_controls_v1 import scoped_load,address,location,sha
P=R/'build/dragon-power-admission-v1';O=R/'build/dragon-power-hud-budget-v1'
FIELDS='ResetPalStar VRAM_Buffer2 VRAM_Buffer2_Offset VRAM_Buffer_AddrCtrl ReloadCHRBank SmFreezePalettePending SmFreezeRenderState AreaParserTaskNum ScrollThirtyTwo DisableScreenFlag PlayerChangeSizeFlag GamePauseStatus X5HudChrUpper'.split()
def main():
 assert sha(P/'handoff.json')=='8ec0cc6a11fff8e4ea3f6b766f3456aba675791cd669a9aef7ba4067ba1d76e7'
 assert not(O/'handoff.json').exists();O.mkdir(exist_ok=True);(O/'src').mkdir(exist_ok=True)
 b=scoped_load(P/'candidate.nes');raw=(P/'candidate.nes').read_bytes()
 assert raw[16+85*8192+0x1291:16+85*8192+0x1900]==bytes([255])*1647
 assert raw[16+86*8192+0x1ff0:16+87*8192]==bytes([255])*16
 core=(R/'build/dragon_power_admission_core_v1.inc').read_text()
 old='''.proc DpAdmissionUi
 DpGameOwner VvUiDispatch
 lda #4
 jmp DpAdmissionC
.endproc'''
 new='''.proc DpAdmissionUi
 ; Genuine late ResetPalStar return is the live ABI; retain it in full.
 DpHostCall ResetPalStar,.bank(ResetPalStar)
 php
 pha
 lda SelectedCharacter
 cmp #24
 bne Done
 lda #8
 jsr DpAdmissionC
Done:pla
 plp
 rts
 .res 1,$ff
 .assert *-DpAdmissionUi=36,lderror,"Original Ui slot span"
.endproc'''
 assert core.count(old)==1;core=core.replace(old,new)
 core=core.replace('DpAdmissionEnd:', '''.proc DpAdmissionEarly
 lda #4
 jmp DpAdmissionC
.endproc
.export DpAdmissionEarly
DpAdmissionEnd:''')
 (O/'core.inc').write_text(core)
 c=(R/'build/dragon_power_admission_c_v1.inc').read_text()
 # Native ColorRotation owns phase0; allow the adjacent phase1 retry too.
 assert c.count(' lda DpClock\n and #7')==1
 c=c.replace(' lda DpClock\n and #7',' lda DpClock\n and #6')
 c=c.replace(' jmp DpAdmissionName\nUi:jmp DpAdmissionHud',' jmp DpBudgetDispatch\nUi:jmp DpBudgetEarly',1)
 tail='''
; Only the new tail consumes formerly FF bytes. All old C entry PCs stay.
.proc DpBudgetDispatch
 cmp #8
 beq Late
 jmp DpAdmissionName
Late:jmp DpBudgetLate
.endproc
.proc DpBudgetEarly
 jsr DpEnsure
 ; A skipped DMA can retain last Main's optional packet. Only retract the
 ; sole, structurally exact own HUD before ANY native gameplay producers.
 lda VRAM_Buffer1_Offset
 cmp #15
 bne Native
 ldx #15
Check:
 lda VRAM_Buffer1,x
 eor Signature,x
 and Mask,x
 bne Native
 dex
 bpl Check
 lda #0
 sta VRAM_Buffer1_Offset
 sta VRAM_Buffer1
Native:
 lda #0
 sta InvHudActive
 sta InvDirty
 lda DpPaletteAck
 cmp #$ff
 bne Done
 jmp DpAdmissionPalette
Done:rts
Signature:.byte $20,$23,12,17,25,0,0,0,36,25,0,36,32,0,0,0
Mask:.byte 255,255,255,255,255,0,0,0,255,255,0,255,255,0,0,255
.endproc
.proc DpBudgetLate
 lda X5HudChrUpper
 bmi Done
 lda OperMode
 cmp #1
 bne Done
 lda GamePauseStatus
 and #1
 bne Done
 lda DisableScreenFlag
 ora TimerControl
 ora VRAM_Buffer_AddrCtrl
 ora VRAM_Buffer1_Offset
 ora VRAM_Buffer2_Offset
 ora VRAM_Buffer1
 ora VRAM_Buffer2
 ora DpPaletteAck
 ora StarInvincibleTimer
 ora GuestPowerupActive
 ora PlayerChangeSizeFlag
 ora SmFreezePalettePending
 ora SmFreezeRenderState
 ora AreaParserTaskNum
 bne Done
 lda ScrollThirtyTwo
 cmp #32
 bcs Done
 ; Existing clock/engine/digits writer remains exact. No cache acknowledgement
 ; is inferred from a queued packet, and no timer advances on deferral.
 jmp DpAdmissionHud
Done:rts
.endproc
'''
 c=c.replace('DpAdmissionColdEnd:',tail+'DpAdmissionColdEnd:')
 (O/'cold.inc').write_text(c)
 # Same-span raw24 target only. Every other table entry and cold code exact.
 gate=(P/'src/new_roster_dispatch.s').read_text().replace('.import DpAdmissionPortrait,','.import DpAdmissionEarly,DpAdmissionPortrait,')
 for prefix in ['<','>','.bank(']:
  old=prefix+'DpAdmissionUi';new=prefix+'DpAdmissionEarly'
  assert gate.count(old)==1,(old,gate.count(old));gate=gate.replace(old,new)
 (O/'src/new_roster_dispatch.s').write_text(gate)
 game=(R/'src/game.s').read_text();needle='farcall ResetPalStar           '
 assert game.count(needle)==1
 game=game.replace('  '+needle+';do sub to clear player\'s palette bits in attributes', '''.if ::ENABLE_MMC5_EXPANDED && ::MAPPER_MMC5
  farcall DpAdmissionUi          ; late optional HUD after real ResetPalStar
.else
  farcall ResetPalStar           ; original ordinary target unchanged
.endif''')
 assert 'farcall DpAdmissionUi' in game
 (O/'src/game.s').write_text(game)
 for p in (P/'src').iterdir():
  if p.name!='new_roster_dispatch.s' and p.is_file():(O/'src'/p.name).write_bytes(p.read_bytes())
 for name in ['main.c','smb1base-mmc5-expanded.cfg']:(O/name).write_bytes((P/name).read_bytes())
 entry=(P/'entrypoint.s').read_text()+'.import DpAdmissionUi\n'+''.join('.export '+n+'\n'for n in FIELDS)
 (O/'entrypoint.s').write_text(entry)
 comp=(P/'component.s').read_text().replace('build/dragon_power_admission_core_v1.inc', 'build/dragon-power-hud-budget-v1/core.inc').replace('build/dragon_power_admission_c_v1.inc','build/dragon-power-hud-budget-v1/cold.inc')
 for n in FIELDS:
  if not re.search(r'^\.import(?:zp)? '+n+r'$',comp,re.M):comp=('.importzp 'if address(b,n)<256 else'.import ')+n+'\n'+comp
 (O/'component.s').write_text(comp)
 cmd=[v.replace(str(P),str(O))for v in json.loads((P/'build-proof.json').read_text())['command']]
 z=subprocess.run(cmd,cwd=R,capture_output=True,text=True);(O/'build.log').write_text(z.stdout+z.stderr);assert z.returncode==0,z.stderr
 from prepare_cv3_dmc_mirror import prepare
 prepare(R,O/'candidate.nes')
 now=scoped_load(O/'candidate.nes');out=(O/'candidate.nes').read_bytes()
 banks={k:sum(x!=y for x,y in zip(raw[16+k*8192:16+(k+1)*8192],out[16+k*8192:16+(k+1)*8192]))for k in range(128)};banks={k:v for k,v in banks.items()if v}
 assert set(banks)=={85,86,124,126},banks
 assert out[1048592:]==raw[1048592:]
 for n in b['syms']:
  if n.startswith('Dp')and'::'not in n and n in now['syms']and n not in ['DpAdmissionEnd','DpAdmissionColdEnd']:assert address(now,n)==address(b,n),(n,'old entry moved')
 assert address(now,'DpAdmissionEnd')<=0xc000 and address(now,'DpAdmissionColdEnd')<=0xd900
 patch=''
 for p,q,label in [(R/'build/dragon_power_admission_core_v1.inc',O/'core.inc','core.inc'),(R/'build/dragon_power_admission_c_v1.inc',O/'cold.inc','cold.inc'),(P/'src/new_roster_dispatch.s',O/'src/new_roster_dispatch.s','src/new_roster_dispatch.s'),(R/'src/game.s',O/'src/game.s','src/game.s')]:
  patch+=''.join(difflib.unified_diff(p.read_text().splitlines(True),q.read_text().splitlines(True),fromfile='a/'+label,tofile='b/'+label))
 (O/'source.patch').write_text(patch)
 proof=dict(passed=True,source_CPU_only=True,native_run=False,parent=sha(P/'candidate.nes'),candidate=sha(O/'candidate.nes'),DBG=sha(O/'candidate.dbg'),LBL=sha(O/'candidate.lbl'),command=cmd,changed_PRG_bytes=banks,CHR_exact=True,old_Goku_public_PCs_exact=True,CORE_end=hex(address(now,'DpAdmissionEnd')),C_end=hex(address(now,'DpAdmissionColdEnd')),no_new_RAM_segment_or_reservation=True)
 (O/'build-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
if __name__=='__main__':main()
