"""Freeze actual sparse HUD source, independent assembly closure and finite proofs."""
from pathlib import Path
import json,re,subprocess,sys
R=Path(__file__).resolve().parents[1];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import dragon_power_hud_budget_controls_v1 as H
from sunny_integrated_controls_v1 import *
P=H.P;O=H.O
def main():
 assert not(O/'handoff.json').exists()
 checks={};deps={};commands=[]
 for n in['controls-final.json','nmi-release.json']:
  d=json.loads((O/n).read_text());assert d['passed']
  for p,h in d['bindings'].items():assert sha(p)==h,(n,p)
 assert sha(O/'candidate.nes')=='1b97a99f1056808b99ac978aded95fe132d0e84209156a4ed909f80513f717e4'
 for prior in json.loads((P/'final-controls.json').read_text())['checks']['independent_actual_ASM_link']['commands']:
  cmd=[v.replace(str(P),str(O))for v in prior]
  z=subprocess.run(cmd,cwd=R,capture_output=True,text=True);assert z.returncode==0,z.stderr;commands.append(cmd)
 from prepare_cv3_dmc_mirror import prepare
 prepare(R,O/'independent.nes');assert sha(O/'independent.nes')==sha(O/'candidate.nes')
 for p in[O/'main-final.d',O/'component-final.d']:
  for word in re.split(r'(?<!\\)\s+',p.read_text().split(':\t',1)[1].strip().removesuffix(':')):
   f=Path(word.replace('\\ ',' '));f=(f if f.is_absolute()else R/f).resolve();assert f.is_file();deps[str(f)]=sha(f)
 for name,expected in [('mmc3','d444cac88e13fa02b29ad16100b8f08fa565ba90f8cedde192de43fb2dc8f3eb'),('mmc5','f4ffd2483c51daa4d60bb575da2da8c4d817692cda407611c243031f67520833')]:assert sha(O/('ordinary-'+name+'.nes'))==expected
 b=scoped_load(O/'candidate.nes');old=scoped_load(P/'candidate.nes');rows=[]
 # Remaining ordered app/I/O writes exact; only the explicit extra A farcall
 # publication/SMC stores and dead call stack writes are routing differences.
 for ch,mode in [(c,m)for c in[0,1,2,3,5,6,8,13,15,19,20,21,22,23,25,26,27,28]for m in[0,1]]:
  out=[]
  for v in[old,b]:
   q=H.setup(v,ch);q.put(CrossoverBehaviorVersion=mode,SavedJoypadBits=1)
   c,tr,mn=H.C.M.runtrace(q,'GameLoop',p=0x71)
   excluded=set(smc_at(v))|{address(v,'CurrentBank')}
   out.append([(i,z)for i,z in q.m.writes if not 0x100<=i<0x200 and i not in excluded and not 0x5114<=i<=0x5117])
  assert out[0]==out[1],('remaining ordered foreign writes',ch,mode)
  rows.append([ch,mode])
 checks['foreign_remaining_ordered_writes']=dict(cases=len(rows),exact=True,explicit_extra_A_farcall_mapper_shadow_SMC_and_dead_stack_only=True)
 checks['actual_ASM_dependency_closure']=dict(files=len(deps),commands=commands,independent_link_ROM_exact=True,final125_regenerated_from127=True)
 checks['fresh_ordinary']=dict(mmc3=sha(O/'ordinary-mmc3.nes'),mmc5=sha(O/'ordinary-mmc5.nes'))
 # Every parent public instruction remains at its old PC. New tail entries
 # and internal end markers are genuine additions, not aliases.
 for name in old['syms']:
  if name.startswith('Dp')and'::'not in name and name in b['syms']and name not in['DpAdmissionEnd','DpAdmissionColdEnd']:assert address(old,name)==address(b,name)
 raw=(P/'candidate.nes').read_bytes();now=(O/'candidate.nes').read_bytes()
 assert raw[:16]==now[:16]and raw[1048592:]==now[1048592:]
 for bank in[125,127]:assert raw[16+bank*8192:16+(bank+1)*8192]==now[16+bank*8192:16+(bank+1)*8192]
 assert raw[16+124*8192+0xda4:16+124*8192+0xdce]==now[16+124*8192+0xda4:16+124*8192+0xdce]
 checks['old_public_PCs_fixed_clones_CHR_and_Rogue_reservation_exact']=True
 (O/'closure.json').write_text(json.dumps(dict(passed=True,source_CPU_only=True,native_run=False,checks=checks),indent=2)+'\n')
 report=R/'docs/qa/dragon-power-hud-budget-2026-10-29.txt'
 report.write_text('''PRIVATE GOKU HUD BUDGET SUCCESSOR; NO NATIVE PASS OR CHARACTER RELEASE.
Parent fb28a741 remains immutable and retains the real frame2654 unsafe rendering deadline and visible HUD jump. Diagnostic nmi-queues.jsonl recorded two lag NMIs, native30B, optional15B HUD, then native14B:59B/eight commands. Actual parser command interval1368CPU; optional12cell HUD272CPU. CHR429CPU, full DMA and remaining work made actual entry-to-render2548CPU, line1 dot167. This successor does not relabel that failure.
EARLY/LATE OWNERSHIP: early raw24 UI is emission-free for HUD. It retains genuine Ensure, inventory-HUD suppression and pending normal palette restoration. Before native gameplay producers, a structurally exact sole Goku command (offset15,2023/length12, its fixed label/space signature and terminator) is retracted after a skipped transfer. Variable digits are deliberately not a cache or arbitrary queue credit. Wrong header/offset/terminator and every non-sole packet remain byte-exact. No native queue compaction, timer advance or resource change.
Actual GameCoreRoutine ResetPalStar18B descriptor now targets the existing36B A86 Ui slot. That35B wrapper executes genuine ResetPalStar exactly once, saves its actual returned A/P, invokes raw24-only C85 service and restores A/P. X/Y/SP are retained. Early table's raw24 target uses a new5B selector in the old16B CORE tail; every foreign early target is unchanged. The late writer admits only actual engine8/OperMode1, unpaused, screen enabled, TimerControl0, both queue offsets AND payload headers0, ctrl0, no pending palette/Star/transform/freeze or negative pending HUD font request, AreaParserTaskNum0 and ScrollThirtyTwo<32. The real source continuation proves no later native area-parser producer can append. No NMI/IRQ implementation changes.
LAG CLOSURE: late-empty alone is insufficient if a packet survives a skipped transfer. Early exact sole-packet retraction prevents next Main's score/block/time producers from accumulating behind an old optional HUD. Every new service instruction boundary is qualified with actual IRQ and lag NMI, including partial writes. Normal NMI cannot run during these writes because genuine Main has NmiDisableFF. Paused Main emits no native gameplay packet. This is source ownership, not a claim every queue in the game meets a universal timing budget.
PHASE NEGATIVE: first late-only draft retained old clock&7==0, and real consecutive Main/NMI controls proved ColorRotation always owns a7B packet on that phase, so no HUD progress. Preserve nmi-first.json and phase-lock-negative.inc; that draft was not accepted. The sole HUD eligibility operand now uses clock&6==0: two adjacent opportunities per8source ticks. ColorRotation phase0 defers; phase1 can publish. No new state/cache/global flag, no counter invention, no power/physics/audio changes.
CHR/BUDGET: DpPublish really requests ReloadCHRBank every draw. Blocking reload would starve the UI. Reload remains allowed; existing publisher is untouched.4096 actual compiled full normal-NMI direct/legacy CHR-mask superset cases reach render in1363..1470 modeled CPU cycles including full256byte DMA, plus96 explicit override/reload/IRQflag/parity cases1029..1458. This is source CPU modeling, not native PPU stamps. All palette/Star/transform/freeze/pending-font paths are excluded or owner-qualified. Parodius palette capture is source-gated raw18 and cannot run for24.640 consecutive real Main/NMI idle/walking updates in both modes and two lag phases actually publish HUD, with real Reload nonzero every Main and no interupdate queue/reload/clock/resource seeds. No publisher cache was added.
FUNCTIONAL:1536 actual ResetPalStar wholeAXYP cases;47 busy-decline cases;160 source HP/Pole/Waves digit/phase cases;3 repeated lag-retraction cycles and17 non-own declines. Captured2654 packet reconstructed on real native C116 fast-parser lease: full return costs1395 vs1123CPU (the observed1368 command interval plus27terminal-return CPU), exact272 omission.96 repeated owned Main updates preserve source HP/clock.36 foreign completeMain calls preserve wholeAXYP/SP/application/live page1/all finalSMC/banks; remaining app/I/O writes exact apart from explicitly added routing publication/dead-stack stores. Foreign Main +106CPU is real common foreground overhead; no zero-cost/lag/FPS claim.358 actual new IRQ/lagNMI seams minSP217; physical IRQ mappings exact and only previously qualified literal C-shadow/store normalization for lag NMI.
LAYOUT: exact candidate1b97a99f1056808b99ac978aded95fe132d0e84209156a4ed909f80513f717e4. Byte delta vsfb28:85=162,86=41,124=1,126=3. Header/allCHR/fixed125+127 and protectedSamus flush/futureRogueADA4 reservation exact. Every old public Goku entry PC remains; only genuine end markers grow. CORE endsBFF5 (11B spare), C service endsD33A (1478B free before approvedD900). Same existing segments, no RAM/CHR/state allocation. Separate real main/component ca65 dependency closure and independent link exactly reproduce candidate; fresh ordinaryMMC3d444/MMC5f4ffd exact through the conditional old ResetPalStar route.
COMPOSITION: Rogue and SMB2 privately rebind the SAME original ResetPalStar18B descriptor. Final union needs ONE explicit dispatcher preserving native ResetPalStar once and each owner's actual late service; never overlay one unit's stale descriptor on another. This standalone candidate composes neither sibling.
LIMITS: corrected deadline/traversal/wholepixel review remain native-unrun. Audio scheduler/atomic cues, source earned-drop implementation and final Goku fidelity remain open. No Mesen/native/Git/shared/canonical/Downloads/settings writes by this unit. ROOT owns the next strict cold Easy route under unchanged dragon_power_11_v3 adaptive policy, not the old2653poll replay because foreground timing changed. Previous nativev1/v2/v3 controller negatives, fb28v4 product failure, first macro/ROM-bank-marker and parser-C-lease oracle negatives remain historical.
''')
 files={Path(p)for p in deps}|{Path(__file__),Path(H.__file__),R/'tools/audit/dragon_power_hud_budget_nmi_v1.py',R/'tools/prepare_dragon_power_hud_budget_v1.py',O/'candidate.nes',O/'candidate.dbg',O/'candidate.lbl',O/'candidate.map',O/'source.patch',O/'core.inc',O/'cold.inc',O/'closure.json',O/'build-proof.json',O/'controls-final.json',O/'nmi-release.json',O/'nmi-first.json',O/'controls-first.json',O/'phase-lock-negative.inc',O/'build-macro-negative.log',O/'ordinary-mmc3.nes',O/'ordinary-mmc5.nes',P/'handoff.json',P/'candidate.nes',P/'candidate.dbg',report,R/'build/verification/dragon-power-admission-nmi-diagnostic-v1/nmi-queues.jsonl'}
 for n in['controls-final.json','nmi-release.json']:
  files.update(Path(p)for p in json.loads((O/n).read_text())['bindings'])
 for mod in list(sys.modules.values()):
  p=getattr(mod,'__file__',None)
  if p and Path(p).resolve().is_relative_to(R)and Path(p).suffix=='.py':files.add(Path(p).resolve())
 hand=dict(status='FROZEN_PRIVATE_OPTIONAL_HUD_BUDGET_SOURCE_CPU_ONLY_NATIVE_UNRUN',candidate=dict(path=str(O/'candidate.nes'),sha256=sha(O/'candidate.nes')),DBG=dict(path=str(O/'candidate.dbg'),sha256=sha(O/'candidate.dbg')),LBL=dict(path=str(O/'candidate.lbl'),sha256=sha(O/'candidate.lbl')),report=dict(path=str(report),sha256=sha(report)),actual_ASM_dependencies=deps,bindings={str(p.resolve()):sha(p)for p in sorted(files)},source_controls=[str(O/'controls-final.json'),str(O/'nmi-release.json'),str(O/'closure.json')],owned_tools=[str(R/n)for n in['tools/prepare_dragon_power_hud_budget_v1.py','tools/prepare_dragon_power_hud_budget_handoff_v1.py','tools/audit/dragon_power_hud_budget_controls_v1.py','tools/audit/dragon_power_hud_budget_nmi_v1.py']],limits=report.read_text())
 for p,h in hand['bindings'].items():assert sha(p)==h
 (O/'handoff.json').write_text(json.dumps(hand,indent=2)+'\n');print(json.dumps(dict(handoff=sha(O/'handoff.json'),candidate=sha(O/'candidate.nes'),DBG=sha(O/'candidate.dbg'),LBL=sha(O/'candidate.lbl'),bindings=len(hand['bindings']),ASM_dependencies=len(deps),report=sha(report))))
if __name__=='__main__':main()
