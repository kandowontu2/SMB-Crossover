"""Sparse private b95c successor; actual compiled hazard/drop consumers only."""
from pathlib import Path
import difflib,json,re,subprocess,sys
R=Path(__file__).resolve().parents[1];sys.path[:0]=[str(R/'tools'),str(R/'tools/audit')]
import rogue_dawn_map_v1 as ref
import prepare_rogue_dawn_host_body_handoff_v1 as closure
from link_pit_rygar_sophia_audit_cpu import scoped_load
from check_tmnt_render_oa import address
from prepare_cv3_dmc_mirror import prepare
P=R/'build/rogue-dawn-host-items-worldcoords-v3';O=R/'build/rogue-dawn-host-hazards-v1'
def once(s,a,z):assert s.count(a)==1,(a,s.count(a));return s.replace(a,z)
def main():
 assert not(O/'handoff.json').exists(),'Frozen successor'
 parent=json.loads((P/'handoff.json').read_text())
 for q in parent['bindings']:assert ref.binding(q['path'])==q,q['path']
 art=R/'build/rogue-dawn-host-drop-source-v1/proof.json';asset=json.loads(art.read_text());assert asset['passed']
 for q in asset['bindings']+asset['outputs']:assert ref.binding(q['path'])==q,q['path']
 O.mkdir(exist_ok=True);b=scoped_load(P/'candidate.nes');changes={}
 for p in P.iterdir():
  if p.suffix in['.s','.inc','.c','.cfg']:
   (O/p.name).write_text(p.read_text().replace(str(P),str(O)),newline='\n')
 def edit(name,fn):
  p=O/name;a=p.read_text();z=fn(a);assert a!=z,name;p.write_text(z,newline='\n');changes[name]=(a,z)
 edit('entrypoint.s',lambda s:once(once(s,'.include "rogue_dawn_death_art.inc"','.include "rogue_dawn_host_hazards_gate_v1.s"\n.include "rogue_dawn_death_art.inc"'),'.incbin "chr/characters/rogue-dawn-items.chr"','.incbin "chr/characters/rogue-dawn-items-drops.chr"'))
 edit('collision.s',lambda s:once(s,'farcall RdLifeInjury','farcall RdHzInjury'))
 edit('object.s',lambda s:once(once(s,'farcall Z2UpdateDropsGate','farcall RdHzUpdateDrops'),'lda #5\n         farcall InventoryHas','lda #5\n.if ::ENABLE_MMC5_EXPANDED\n         farcall RdHzFirebar\n.else\n         farcall InventoryHas\n.endif'))
 def weapons(s):
  s=once(s,'jsr ShellOrBlockDefeat       ; real terminal owner only after actual HP zero','jsr RdHzTerminal             ; actual paid terminal -> approved typed source drop')
  s=once(s,'Types:.byte $06,$00,$03,$0e,$0f,$10,$0d,$12,$05,$11','Types:.byte $06,$00,$03,$0e,$0f,$10,$0d,$12,$05,$11,$2d')
  s=once(s,'HP: .byte 2,4,4,4,4,4,4,4,8,8','HP: .byte 2,4,4,4,4,4,4,4,8,8,32')
  s=once(s,' cmp #$81\n jeq Defeat',' cmp #$81\n bne NotScrew\n lda Enemy_ID,x\n cmp #$2d\n jne Defeat\n lda #1\n sta Rh6\n jmp Damage\nNotScrew:lda Rh6')
  s=once(s,' cmp #3\n bne Damage\n lda AvFrozen,x',' cmp #3\n bne Damage\n lda Enemy_ID,x\n cmp #$2d\n beq Damage\n lda AvFrozen,x')
  s=once(s,'Debit:\n lda MmEnemyHealthLo,x','Debit:\n lda Enemy_ID,x\n cmp #$2d\n bne DebitHP\n lda Rh6\n cmp #11\n bne DebitHP\n lda #4\n sta Rh7\nDebitHP:\n lda MmEnemyHealthLo,x')
  s=once(s,' lda #6                     ; real ordinary source hurt timer040F',' lda Enemy_ID,x\n cmp #$2d\n lda #6\n bne HurtReady\n lda #3\nHurtReady:                  ; genuine ordinary6 / miniboss3 source hurt timer')
  # CMP's Z is destroyed by LDA#6, so the actual source branch must precede it.
  s=once(s,' cmp #$2d\n lda #6\n bne HurtReady\n lda #3',' cmp #$2d\n beq BossHurt\n lda #6\n bne HurtReady\nBossHurt:lda #3')
  return s
 edit('weapon-source.s',weapons)
 edit('world-source-v3.s',lambda s:once(s,' sta $5116\n rts\nForeign:pla',' sta $5116\n jmp RdHzDrawDrops\nForeign:pla'))
 edit('weapon-object.s',lambda s:once(s,'.include "rogue_dawn_weapon_world_art_palette0_v2.inc"','.include "rogue_dawn_host_hazards_drops_v1.s"\n.include "rogue_dawn_weapon_world_art_palette0_v2.inc"').replace('rogue_dawn_item_art_palette0_v2.inc','rogue_dawn_item_drop_art_v1.inc'))
 main=R/'src/rogue_dawn_host_hazards_gate_v1.s';aux=R/'src/rogue_dawn_host_hazards_drops_v1.s'
 code='\n'.join(line.split(';',1)[0]for line in aux.read_text().splitlines());code=re.sub(r'"[^"\n]*"','',code)
 imports=set(re.findall(r'\.import(?:zp)?\s+(\w+)',(O/'weapon-imports.inc').read_text()+(O/'item-imports.inc').read_text()))
 # Names genuinely local to this single auxiliary object must never be fake
 # imported aliases, including its new public functions.
 text='\n'.join(p.read_text()for p in[O/'weapon-source.s',R/'src/rogue_dawn_host_items.s',O/'world-source-v3.s',aux])
 local=set(re.findall(r'^\s*(\w+)\s*:',text,re.M))|set(re.findall(r'\.proc\s+(\w+)',text))
 newmain=['RdHzFirebar','RdHzInjury','RdHzGrant']
 ext=sorted((set(re.findall(r'\b[A-Za-z_]\w*\b',code))&set(b['syms']))-local-imports-{'RD_ITEM_LO_C','RD_ITEM_HI_C'})
 (O/'hazard-imports.inc').write_text('\n'.join(['.import '+n for n in newmain]+[('.importzp 'if b['syms'][n]['addrsize']=='zeropage'else'.import ')+n for n in ext])+'\n',newline='\n')
 publics=sorted(set(n.strip()for line in re.findall(r'\.export ([^\n]+)',aux.read_text())for n in line.split(',')))
 e=O/'entrypoint.s';e.write_text(e.read_text()+'\n.if ::ENABLE_MMC5_EXPANDED\n'+''.join('.export '+n+'\n'for n in ext+newmain)+''.join('.import '+n+'\n'for n in publics)+'.endif\n',newline='\n')
 build=json.loads((P/'build.json').read_text());cmds=[[v.replace(str(P),str(O))for v in cmd]for cmd in build['commands']]
 for cmd,log in zip(cmds,['weapon-object.log','build.log']):
  z=subprocess.run(cmd,cwd=R,capture_output=True,text=True);(O/log).write_text(z.stdout+z.stderr);assert z.returncode==0,(z.stdout+z.stderr)[-6000:]
 prepare(R,O/'candidate.nes');n=scoped_load(O/'candidate.nes')
 deps=list(dict.fromkeys(closure.dependencies(O/'assembler-full.dep')+closure.dependencies(O/'weapon-object.dep')))
 patch=O/'source.patch';patch.write_text(''.join(''.join(difflib.unified_diff(a.splitlines(True),z.splitlines(True),fromfile='b95c/'+name,tofile='private/'+name))for name,(a,z)in changes.items()),newline='\n')
 output=dict(passed=True,source_build_only=True,native_run=False,qualified=False,playable_admission=False,ROM=ref.binding(O/'candidate.nes'),parent=ref.binding(P/'candidate.nes'),commands=cmds,actual_ASM_inputs=len(deps),A95_end=hex(address(n,'RdHzGateEnd')),A121_end=hex(address(n,'RdWpArtEnd')),item_end=hex(address(n,'RdItemArtEnd')),bindings=[ref.binding(p)for p in dict.fromkeys(deps+[Path(__file__),P/'handoff.json',art,main,aux,O/'candidate.nes',O/'candidate.dbg',O/'candidate.lbl',O/'candidate.map',O/'private.cfg',O/'hazard-imports.inc',patch])],open=['No native/menu/audio admission. New complete caller, source, pixels, stack, IRQ and ordinary closure unqualified.'])
 (O/'build.json').write_text(json.dumps(output,indent=2)+'\n');print(json.dumps({k:output[k]for k in['ROM','actual_ASM_inputs','A95_end','A121_end','item_end']}))
if __name__=='__main__':main()
