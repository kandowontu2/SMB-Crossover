"""Compiled closure, foreign true callers and combined world/CHR source tests."""
from pathlib import Path
import itertools,json,re,sys,traceback
R=Path(__file__).resolve().parents[1];sys.path[:0]=[str(R/'tools'),str(R/'tools/audit')]
import rogue_dawn_host_weapons_controls_v1 as w
import rogue_dawn_host_items_render_controls_v3 as rend
import prepare_rogue_dawn_item_art_v1 as art
from check_tmnt_render_oa import address,location
from check_tmnt_audio_fallback_oc import qualified
from sunny_integrated_controls_v1 import run,registers,app,cleanwrites
O=R/'build/rogue-dawn-host-hazards-v1';P=R/'build/rogue-dawn-host-items-worldcoords-v3'
get,put,call=w.get,w.put,w.call
def main():
 b=w.life.d.old.scoped_load(O/'candidate.nes');old=w.life.d.old.scoped_load(P/'candidate.nes');checks={};minimum=255
 proof=dict(passed=False,source_CPU_only=True,native_run=False,ROM=w.ref.binding(O/'candidate.nes'),checks=checks)
 try:
  # Genuine compiled delta allowlist, not hand-adjusted DBG data.
  spans=[];allowed=set()
  # Locate the three original macro targets in actual caller assembly; exact
  # other-bank bytes are checked by diff allowlist below, not a broad waiver.
  diff=[i for i,(a,z)in enumerate(zip(old['raw'],b['raw']))if a!=z];perbank={}
  for i in diff:perbank[(i-16)//8192 if i<16+1048576 else 'CHR']=perbank.get((i-16)//8192 if i<16+1048576 else 'CHR',0)+1
  for bank,lo,hi in [(95,0xbd0f,0xbf00),(121,0xad60,0xc000)]:allowed.update(range(16+bank*8192+(lo&8191),16+bank*8192+(hi&8191 or 8192)))
  targets={'RdLifeInjury':'RdHzInjury','Z2UpdateDropsGate':'RdHzUpdateDrops','InventoryHas':'RdHzFirebar'}
  for n in old['syms']:
   if re.match(r'^Rd(?:Wx|It)[A-Z]',n)and 'seg'in old['syms'][n]and(location(old,n)-16)//8192==121:targets[n]=n
  outside=[i for i in diff if i<16+1048576 and (i-16)//8192 not in[95,121]]
  found=set()
  for i in outside:
   for k in range(max(16,i-12),i+1):
    for oldname,newname in targets.items():
     oldtarget,newtarget=address(old,oldname),address(b,newname)
     if old['raw'][k:k+10]!=bytes([169,oldtarget&255,141,108,1,169,oldtarget>>8,141,109,1]):continue
     at=k-3;a=old['raw'][at:at+18];z=b['raw'][at:at+18]
     expect=bytearray(a);expect[4]=newtarget&255;expect[9]=newtarget>>8;expect[14]=128|((location(b,newname)-16)//8192)
     assert z==expect,(oldname,newname,a.hex(),z.hex(),expect.hex())
     if at not in found:spans.append(dict(old_target=oldname,new_target=newname,file_offset=at,bytes=18,before=a.hex(),after=z.hex()));found.add(at)
     allowed.update([at+4,at+9,at+14])
  allowed.update(range(16+1048576+694*1024+896,16+1048576+695*1024))
  assert all(i in allowed for i in diff),[(i,(i-16)//8192)for i in diff if i not in allowed][:20]
  report=json.loads((R/'docs/qa/rogue-dawn-host-items-world-safe-source-2026-10-28.json').read_text());frozen=[]
  for q in report['literal_frozen_spans']:
   at=16+q['bank']*8192+(int(q['PC'],16)&8191)
   assert w.ref.digest(b['raw'][at:at+q['bytes']])==q['sha256'];frozen.append(q)
  assert old['raw'][16+121*8192:16+121*8192+0xd60]==b['raw'][16+121*8192:16+121*8192+0xd60]
  checks['actual_ROM_sparse_delta_and_frozen_spans']=dict(changed_bytes=len(diff),perbank=perbank,actual_old_targets=spans,literal=frozen,Roll_prefix_bytes=0xd60)
  before,after=qualified(P/'candidate.nes'),qualified(O/'candidate.nes');moved=[]
  for name,value in before.items():
   if after.get(name)==value:continue
   s='::'.join(name)
   own=s.startswith(('RdWp','RdItem','RdWx','RdIt','WxEnabled','ItEnabled','ItTyped','RD_ITEM_'))
   metadata=s in ['farcall_count','_FARCALL_COUNT','__ROGUE_DAWN_HOST_SIZE__','__ROGUE_DAWN_HOST_AUX_SIZE__']
   assert own or metadata,(s,value,after.get(name))
   moved.append(dict(name=s,before=value,after=after.get(name)))
  checks['all_old_qualified_PC_RAM_other_than_owned_aux']=dict(old=len(before),relocated_owned=moved)
  # True legacy Samus InventoryHas5 still preserves every observed output.
  rows=[]
  for mode,owned,flags in itertools.product([0,1],[0,32],w.life.body.FLAGS):
   pair=[]
   for bundle,entry in [(old,'FirebarCollision'),(b,'FirebarCollision')]:
    q=w.edges.foreign(bundle,2,'RdVariant',0,mode);q.m[address(bundle,'InvOwnedLo')+2]=owned
    q.put(PlayerStatus=1,PlayerSize=1,Player_Rel_XPos=120,Player_Y_Position=176,Player_Y_HighPos=1,R6=124,R7=200,TimerControl=0,StarInvincibleTimer=0,ObjectOffset=0)
    c,wr,_=run(q,entry,a=5,x=0,y=0,p=flags)
    pair.append((registers(c),app(q),tuple(q.m.banks),cleanwrites(q,wr),c.processorCycles))
   assert pair[0][:4]==pair[1][:4],('legacySamus InventoryHas',mode,owned,flags)
   rows.append(dict(mode=mode,owned=owned,P=flags,CPU_delta=pair[1][4]-pair[0][4]))
  checks['actual_legacy_Samus_InventoryHas5_full_ABI_application_writes_banks']=rows
  # The old40 descriptor geometries are byte-identical through new genuine
  # first readers, despite the phase dedup and changed high-pointer-tablePC.
  rows=[]
  for kind,phase,offset in itertools.product(range(10),range(4),[0,244]):
   m=w.life.make(b);at=address(b,'Sprite_Data');m[at:at+256]=bytes([248,0,0,0])*64
   for n,v in [('Enemy_Flag',1),('Enemy_ID',46),('Enemy_State',128),('InvPickupOwner',2),('InvPickup',208+kind),('Enemy_X_Position',120),('Enemy_PageLoc',0),('Enemy_Y_Position',120),('Enemy_Y_HighPos',1),('Enemy_SprAttrib',0)]:w.field(m,n,v,5)
   put(m,RdClock=phase*2,CurrentOAMOffset=offset,ObjectOffset=3);cbank=m.banks[2]
   c,l,tr=call(m,'RdWpDrawItems');minimum=min(minimum,l);assert m.banks[2]==cbank and get(m,'ObjectOffset')==3
   for bundle in [old,b]:
    lo=location(bundle,'RdItemLoA');hi=location(bundle,'RdItemHiA');ptr=bundle['raw'][lo+kind*4+phase]+256*bundle['raw'][hi+kind*4+phase]
    rec=rend.record(bundle,ptr)
    if bundle is old:oldrec=rec
    else:assert rec==oldrec
   count=get(m,'CurrentOAMOffset')-offset
   assert count==(rec[0]if rec[0]+offset<256 else 0)
   if offset==0:
    parts=[list(m[at+i:at+i+4])for i in range(0,count,4)];_,expected,_=art.source(w.ref.ROM.read_bytes(),kind,phase,2)
    assert rend.pixels(b['raw'],parts,694)=={xy:(v,a&32)for xy,(v,a)in expected.items()}
   rows.append([kind,phase,offset,count,l])
  checks['old40_records_literal_and_real_OAM_source_masks_after_dedup']=dict(cases=len(rows),SHA256=w.ref.digest(json.dumps(rows).encode()))
  rows=[]
  for special in[0,1]:
   m=w.life.make(b);call(m,'X5ColdInit');m[0x5fee]=1
   w.target(m,6,wx=168,y=176);w.shot(m,wx=100,y=120)
   for n,v in [('InvDropKind',129),('InvDropX',200),('InvDropPage',0),('InvDropY',128),('InvDropAge',96),('InvDropAgeHi',0)]:w.field(m,n,v,3)
   put(m,SsChrActive=special,SsChrPhysical=200,X5SpecialChrUpper=2)
   c,row=w.life.mainstep(m,first=True);minimum=min(minimum,row['minimum_SP'])
   assert get(m,'InvDropKind',3)==129 and get(m,'SsChrActive')==special and get(m,'X5SpecialChrUpper')==2
   m.writes.clear();call(m,'X5PublishChr');upper=0;physical={}
   for at,v in m.writes:
    if at==0x5130:upper=v&3
    elif 0x5120<=at<0x5128:physical[at-0x5120]=v+256*upper
   assert physical[6]==694 and physical[7]==687 and physical[4]==(712 if special else b['raw'][location(b,'ChrPhysicalMap')+23])
   for win,native in [(1,20),(2,21),(3,22),(5,24)]:assert physical[win]==b['raw'][location(b,'ChrPhysicalMap')+native]
   rows.append(dict(existing_special=special,physical_publisher=physical,minimum_SP=row['minimum_SP']))
  checks['complete_cold_Main_body_world_weapon_drop_and_true_ordered_CHR_publisher']=rows
  # Constructor origin/parent is actually emitted by native SpawnHammerObj;
  # manual fixtures in the other campaign do not stand in for this owner.
  rows=[]
  for rng in [1,4,8]:
   m=w.life.make(b);w.target(m,5,wx=160,y=176);m[address(b,'PseudoRandomBitReg')+1]=rng
   for i in range(9):w.field(m,'Misc_State',0,i)
   for i in range(1,5):w.field(m,'Enemy_Flag',0,i)
   c,l,tr=call(m,'SpawnHammerObj',x=0);minimum=min(minimum,l)
   slot=rng&7 if rng&7 else rng&8
   assert c.p&1 and get(m,'HammerEnemyOffset',slot)==0 and get(m,'Misc_State',slot)==144 and get(m,'Misc_BoundBoxCtrl',slot)==7
   put(m,ObjectOffset=slot)
   w.field(m,'Enemy_MovingDir',1,0)
   for tick in range(15):call(m,'ProcHammerObj',x=slot)
   assert get(m,'Misc_State',slot)==129 and get(m,'Misc_X_Speed',slot)==16
   assert get(m,'Misc_X_Position',slot)==162 and get(m,'Misc_Y_HighPos',slot)==1
   rows.append(dict(RNG=rng,actual_Misc_slot=slot,parent=get(m,'HammerEnemyOffset',slot),actual_state=get(m,'Misc_State',slot),native_X=get(m,'Misc_X_Position',slot)))
  checks['native_hammer_spawn_parent_delayed_release_constructor']=rows
  rows=[]
  for death in [0,1]:
   m=w.life.make(b);put(m,MmDeathFlag=death,AreaType=1,AreaAddrsLOffset=5)
   for i in range(4):w.field(m,'InvDropKind',129,i)
   c,l,tr=call(m,'InitializeArea',sp=240);minimum=min(minimum,l)
   assert all(get(m,'InvDropKind',i)==0 for i in range(4))
   rows.append(dict(death=death,actual_native_clear=True,minimum_SP=l))
  checks['real_InitializeArea_life_scene_drop_clear']=rows
  proof.update(passed=True,minimum_SP=minimum,limits=['CPU/source-only. No actual native DMA/PPU timing, first8/OAM visibility, audio or menu admission.','Standalone NrFreshGameInit does not clear old InvDrop records; actual following InitializeArea does. Variant/menu transition ownership still requires next admission unit.','Finite listed campaigns only; unlisted armor/flying/water weapon consumers and world rooms are not certified.'])
 except BaseException as e:proof.update(error=str(e),traceback=traceback.format_exc());raise
 finally:
  proof['bindings']=[w.ref.binding(p)for p in[Path(__file__),O/'build.json',O/'candidate.nes',O/'candidate.dbg',P/'handoff.json',R/'tools/rogue_dawn_host_hazards_controls_v1.py']]
  (O/'edge-controls.json').write_text(json.dumps(proof,indent=2)+'\n')
 print(json.dumps(dict(passed=True,minimum_SP=minimum,checks={k:len(v)if isinstance(v,list)else v.get('cases',v.get('old'))for k,v in checks.items()})))
if __name__=='__main__':main()
