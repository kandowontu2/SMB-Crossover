"""Finite actual compiled hazards/drops; source CPU, never native evidence."""
from pathlib import Path
import itertools,json,sys,traceback
R=Path(__file__).resolve().parents[1];sys.path[:0]=[str(R/'tools'),str(R/'tools/audit')]
import rogue_dawn_host_weapons_controls_v1 as w
import rogue_dawn_host_items_render_controls_v3 as render
import prepare_rogue_dawn_host_drop_art_v1 as src
from check_tmnt_render_oa import address,location
from verify_native_relocation import NesMPU
from sunny_integrated_controls_v1 import run,app,registers,cleanwrites
O=R/'build/rogue-dawn-host-hazards-v1';P=src.P
get,put,call=w.get,w.put,w.call

def no_drops(m):
 for i in range(4):w.field(m,'InvDropKind',0,i)
def drop(m,kind=128,slot=3,x=128,y=128,age=96,birth=0):
 for n,v in [('InvDropKind',kind),('InvDropX',x&255),('InvDropPage',x>>8),('InvDropY',y),('InvDropAge',age),('InvDropAgeHi',birth)]:w.field(m,n,v,slot)
def hammer(m,slot=0,parent=4):
 put(m,ObjectOffset=slot,FrameCounter=1,TimerControl=0,Misc_OffscreenBits=0,StarInvincibleTimer=0)
 for n,v in [('Misc_State',129),('Misc_Collision_Flag',0),('Misc_X_Speed',16),('HammerEnemyOffset',parent),('Misc_Y_HighPos',1),('Misc_X_Position',128),('Misc_PageLoc',0),('Misc_Y_Position',176)]:w.field(m,n,v,slot)
 for n,v in [('Enemy_Flag',1),('Enemy_ID',5),('Enemy_State',0),('Enemy_Y_HighPos',1)]:w.field(m,n,v,parent)
 for i in [0,36+4*slot]:m[address(m.bundle,'BoundingBox_UL_XPos')+i:address(m.bundle,'BoundingBox_UL_XPos')+i+4]=bytes([120,160,136,184])

def main():
 b=w.life.d.old.scoped_load(O/'candidate.nes');old=w.life.d.old.scoped_load(P/'candidate.nes');raw=w.ref.ROM.read_bytes()
 checks={};minimum=255;proof=dict(passed=False,source_CPU_only=True,native_run=False,ROM=w.ref.binding(O/'candidate.nes'),checks=checks)
 try:
  table={6:2,0:4,3:4,14:4,15:4,16:4,13:4,18:4,5:8,17:8,45:32};rows=[]
  for ident in range(256):
   m=w.life.make(b);w.target(m,ident);c,l,tr=call(m,'RdWxActorEligible',x=0)
   assert bool(c.p&1)==(ident in table)
   if c.p&1:assert c.a==table[ident]
   rows.append([ident,bool(c.p&1),c.a])
  checks['all256_IDs_exact_HP_table_no_other_default']=dict(cases=len(rows),table=table)
  rows=[]
  for weapon,gear,hp in itertools.product([1,2,3,10,11,129],[0,64,128,192],[1,2,3,4,8,32]):
   m=w.life.make(b);w.target(m,45);no_drops(m);w.field(m,'MmEnemyHealthLo',hp);put(m,RdGear=gear,DuplicateObj_Offset=1)
   w.field(m,'Enemy_Flag',128,1);w.field(m,'EnemyMetasprite',12,1)
   n=w.art.Memory(w.ref.cpu_image(raw,lower_bank=2,a_bank=3));n[0x40e]=weapon;n[0x6878]=gear;n[0x0a]=64;n[0x40b]=hp
   w.original.prefix(n,0xda92,0xf60f)
   c,l,tr=call(m,'RdWxActorContact',a=weapon,x=0);minimum=min(minimum,l)
   assert get(m,'MmEnemyHealthLo')==n[0x40b],(weapon,gear,hp,get(m,'MmEnemyHealthLo'),n[0x40b])
   assert get(m,'AvFrozen')==0 and not any(get(m,'InvDropKind',i)for i in range(4))
   if n[0x40b]:assert get(m,'MmEnemyFlash')==get(m,'RgEnemyStun')==3 and get(m,'Enemy_ID')==45
   else:
    assert get(m,'Enemy_State')&32 and get(m,'EnemyMetasprite',1)==0 and get(m,'BowserHitPoints')==0
    assert any(pc==address(b,'HandleEnemyFBallCol')for pc,bank in tr)
   rows.append([weapon,gear,hp,n[0x40b],l])
  checks['actual_source_miniboss_DA92_and_true_native_Bowser_terminal']=dict(cases=len(rows),SHA256=w.ref.digest(json.dumps(rows).encode()),mapping='Authored native Bowser -> source default-area type8 HP32 (F863/962B[8]); explicit mini-boss40, no species/Hard/bit80 equivalence; actual F5E3..F5EB hurt3.',minimum_SP=min(r[-1]for r in rows))
  rows=[]
  for weapon in [1,2,3,10,11,129]:
   n=w.art.Memory(w.ref.cpu_image(raw,lower_bank=2,a_bank=3))
   for a,v in {0x6b02:8,0x40f:64,0x404:32,0x40e:weapon,0x4b:0,0x6af4:2,0x6878:128}.items():n[a]=v
   w.art.call(n,0xf85a);assert n[0x40b]==32
   c,tr=w.original.prefix(n,0xf536,0xf60f)
   assert n[0x6af4]==6 and n[0x40f]==3 and n[0x40b]==32-({1:1,2:2,3:4,10:1,11:4,129:1}[weapon])
   assert 0xf515 not in tr and 0xf5de in tr and 0xda92 in tr
   rows.append(dict(weapon=weapon,actual_HP_after=n[0x40b],hurt_timer=n[0x40f],first_Ice_freeze_skipped=True,source_PC_chain=['F85A','F536','F579','F5DE','DA92','F60F']))
  checks['complete_original_constructor_damage_admission_miniboss_skip_freeze_hurt3']=rows
  rows=[]
  for ident,rng,maxmiss in itertools.product([6,0,5],range(256),[0,5]):
   m=w.life.make(b);no_drops(m);w.target(m,ident,wx=255,y=176);w.field(m,'MmEnemyHealthLo',1);put(m,RdMaxMissiles=maxmiss)
   m[address(b,'PseudoRandomBitReg')+1]=rng
   c,l,tr=call(m,'RdWxActorContact',a=1,x=0);minimum=min(minimum,l)
   want=[128,129,137,128,129,137,129,137][rng&7]if rng>=16 else 0
   if(want==128 and not maxmiss)or(want==137 and ident==6):want=0
   assert get(m,'InvDropKind',3)==want,(ident,rng,maxmiss,want,[get(m,'InvDropKind',i)for i in range(4)])
   assert get(m,'Enemy_State')&32
   if want:
    assert get(m,'InvDropX',3)==7 and get(m,'InvDropPage',3)==1 and get(m,'InvDropY',3)==184
    assert get(m,'InvDropAge',3)==96 and get(m,'InvDropAgeHi',3)==1
    assert any(pc==address(b,'ShellOrBlockDefeat')for pc,bank in tr)
   rows.append([ident,rng,maxmiss,want,l])
  checks['actual_paid_terminal_rng_birth_full_page_original_origin']=dict(cases=len(rows),SHA256=w.ref.digest(json.dumps(rows).encode()),minimum_SP=min(r[-1]for r in rows),RNG='PseudoRandomBitReg+1',large_gate='Goomba->sourceHP2/type4 lowbit0; listed HP4/8 actors ->source type2/0/1 lowbit1; no armor30 or boss drops')
  rows=[]
  for kind,initial in itertools.product([128,129,137],range(4)):
   m=w.life.make(b);no_drops(m);drop(m,kind,x=300,y=160,birth=1);put(m,RdX=16,RdY=64,RdRoomHi=0,RdRadiusX=4,RdRadiusY=15,RdClock=initial)
   # New installed owner is a complete typed update; first publication is not collectible.
   call(m,'RdHzUpdateDrops');assert get(m,'InvDropAgeHi',3)==0 and get(m,'InvDropAge',3)==96
   for tick in range(1,385):
    put(m,RdClock=(initial+tick)&255);call(m,'RdHzUpdateDrops')
    if not get(m,'InvDropKind',3):break
   assert tick==384-initial,(kind,initial,tick)
   rows.append([kind,initial,tick])
  checks['actual_stationary_drop_lifetime96_four_clock_decrements']=rows
  rows=[]
  for kind,px,dx,dy in itertools.product([128,129,137],[128,255,256],[-10,-8,-7,0,7,8,10],[-25,-23,-20,0,20,23,25]):
   m=w.life.make(b);no_drops(m);drop(m,kind,x=px+dx,y=128+dy)
   put(m,RdX=px&255,RdRoomHi=px>>8,RdY=128,RdRadiusX=4,RdRadiusY=15,RdClock=1,RdMissiles=0,RdMaxMissiles=20,RdHealthLo=0,RdHealthHi=1)
   before=list(m[0x5fb4:0x5fb6]);c,l,tr=call(m,'RdHzUpdateDrops');minimum=min(minimum,l)
   want=abs(dx)<=8 and abs(dy)<=15+(8 if kind==128 else 4)
   assert (get(m,'InvDropKind',3)==0)==want,(kind,px,dx,dy,want,get(m,'InvDropKind',3))
   if want:
    if kind==128:assert get(m,'RdMissiles')==5 and list(m[0x5fb4:0x5fb6])==before
    else:assert list(m[0x5fb4:0x5fb6])==([80,1]if kind==129 else[0,3])
    after=bytes(m[0x5fb0:0x5fb6]);call(m,'RdHzUpdateDrops');assert bytes(m[0x5fb0:0x5fb6])==after
   rows.append([kind,px,dx,dy,want])
  checks['actual_mature_source_radius_page_geometry_grant_and_once_only']=dict(cases=len(rows),SHA256=w.ref.digest(json.dumps(rows).encode()))
  rows=[]
  for clock,suit,screw in itertools.product(range(8),[0,32],[False,True]):
   m=w.life.make(b);put(m,RdClock=clock,RdGear=suit|(8 if screw else 0),RdAction=1 if screw else 0,RdAnimReset=14 if screw else 7,RdAnimIndex=15 if screw else 7,RdAnimFrame=23 if screw else 8)
   before=list(m[0x5fb4:0x5fb6]);c,l,tr=call(m,'RdHzFirebar',a=5);minimum=min(minimum,l)
   n=w.art.Memory(w.ref.cpu_image(raw,lower_bank=2,a_bank=3));n[0x2d]=clock;n[0x6878]=suit;n[0x106]=153;n[0x107]=9;n[0x300]=0
   # Actual cadence/protection PC prefix stops before source gravity owner.
   src.prefix(n,0xe28d,0xe2a4)
   assert list(m[0x5fb4:0x5fb6])==list(n[0x106:0x108]),(clock,suit,screw,list(m[0x5fb4:0x5fb6]),list(n[0x106:0x108]))
   assert c.p&1 and get(m,'RdHit')==0
   rows.append([clock,suit,screw,list(m[0x5fb4:0x5fb6]),l])
  checks['real_E28D_heat_raw07_cadence_Suit_no_Screw_immunity']=dict(cases=len(rows),raw_BCD07='0.7 displayed energy; true source Suit halves/cadence; never7 whole HP',SHA256=w.ref.digest(json.dumps(rows).encode()))
  rows=[]
  for slot,suit,screw,badparent in itertools.product([0,4,8],[0,32],[False,True],[False,True]):
   m=w.life.make(b);hammer(m,slot);put(m,RdGear=suit|(8 if screw else 0),RdAction=1 if screw else 0,RdAnimReset=14 if screw else 7,RdAnimIndex=15 if screw else 7,RdAnimFrame=23 if screw else 8)
   if badparent:w.field(m,'Enemy_ID',6,4)
   before=list(m[0x5fb4:0x5fb6]);entries=[];oldstep=NesMPU.step
   def step(cpu):
    if cpu.pc==address(b,'RdHzInjury')and m.banks[1]==95:
     entries.append(dict(SP=cpu.sp,return_PC=m[0x106+cpu.sp]+256*m[0x107+cpu.sp]+1,original_bytes=list(m[0x101+cpu.sp:0x108+cpu.sp])))
    oldstep(cpu)
   NesMPU.step=step
   try:c,l,tr=call(m,'RunAllH',x=slot)
   finally:NesMPU.step=oldstep
   minimum=min(minimum,l);assert len(entries)==1 and entries[0]['return_PC']==address(b,'RunHSubs'),(slot,suit,screw,badparent,entries,get(m,'Misc_Collision_Flag',slot),get(m,'Misc_X_Speed',slot))
   assert get(m,'Misc_X_Speed',slot)==240 and get(m,'Misc_Collision_Flag',slot)==1
   expected=before if screw or badparent else([0x59,9]if suit else[0x19,9])
   assert list(m[0x5fb4:0x5fb6])==expected,(slot,suit,screw,badparent,list(m[0x5fb4:0x5fb6]),expected)
   rows.append(dict(slot=slot,suit=suit,Screw=screw,wrong_parent=badparent,actual_entry=entries[0],health_after=expected,minimum_SP=l))
  checks['genuine_ProcHammerObj_collision_return_SP_Misc_parent_native_reflection']=rows
  rows=[]
  for ident,suit,screw,mode in itertools.product([6,7,8,12,15,45],[0,32],[False,True],[0,1]):
   m=w.life.make(b,mode);w.target(m,ident,wx=128,y=176)
   put(m,RdGear=suit|(8 if screw else 0),RdAction=1 if screw else 0,RdAnimReset=14 if screw else 7,RdAnimIndex=15 if screw else 7,RdClock=0)
   c,l,tr=call(m,'InjurePlayer');minimum=min(minimum,l)
   expected=([153,9]if suit else[146,9])if ident==12 else([153,9]if screw else[89,9]if suit else[25,9])
   assert list(m[0x5fb4:0x5fb6])==expected,(ident,suit,screw,mode,list(m[0x5fb4:0x5fb6]),expected)
   rows.append([ident,suit,screw,mode,expected,l])
  checks['genuine_native_injury_Podoboo_flame_Bowser_and_armored_ordinary_Screw_protection']=rows
  rows=[]
  for kind in ['IRQ','lagNMI']:
   m=w.life.make(b);hammer(m);c,l,tr=call(m,'RunAllH',x=0,seam=(address(b,'RdHzHammer'),121,kind));minimum=min(minimum,l)
   assert list(m[0x5fb4:0x5fb6])==[25,9] and get(m,'Misc_X_Speed')==240
   rows.append(dict(interrupt=kind,minimum_SP=l,real_hammer_caller=True))
  checks['actual_hammer_caller_IRQ_lagNMI_live_stack_flags_SMC']=rows
  rows=[]
  for wrongparent in [False,True]:
   m=w.life.make(b);hammer(m);w.target(m,6,wx=112,y=176);w.field(m,'Misc_X_Position',140)
   if wrongparent:w.field(m,'Enemy_ID',6,4)
   c,l,tr=call(m,'InjurePlayer');minimum=min(minimum,l)
   assert list(m[0x5fb4:0x5fb6])==[25,9] and get(m,'RdHit')==40
   assert not any(pc==address(b,'RdHzHammer')and bank==121 for pc,bank in tr)
   rows.append(dict(unrelated_active_Misc=True,wrongparent=wrongparent,ordinary_recoil=40))
  checks['wrong_actual_return_does_not_leak_Misc_scope']=rows
  rows=[]
  for ident,size,suit,owned in itertools.product(range(27,35),[0,1],[0,32],[0,32]):
   m=w.life.make(b);w.target(m,ident,wx=128,y=176)
   put(m,PlayerSize=size,Player_Rel_XPos=120,R6=124,R7=(200 if size else 176),RdClock=0,RdGear=suit,TimerControl=0,StarInvincibleTimer=0,CurrentOAMOffset=0)
   m[address(b,'InvOwnedLo')+2]=owned
   c,l,tr=call(m,'FirebarCollision',x=0,y=0);minimum=min(minimum,l)
   assert list(m[0x5fb4:0x5fb6])==([153,9]if suit else[146,9])
   assert any(pc==address(b,'RdHzFirebar')and bank==95 for pc,bank in tr)
   rows.append([ident,size,suit,owned,l])
  checks['actual_eight_Firebar_IDs_geometry_to_exact_target_ignores_foreign_InvOwned5']=rows
  rows=[]
  for kind,(x,camera),y,off,rot in itertools.product([128,129,137],[(128,0),(256,128)],[128,220],[0,244],[0,128]):
   m=w.life.make(b);no_drops(m);drop(m,kind,x=x,y=y);put(m,CurrentOAMOffset=off,GuestOamRotationActive=int(bool(rot)),RgOamRotation=rot,ScreenLeft_X_Pos=camera&255,ScreenLeft_PageLoc=camera>>8)
   at=address(b,'Sprite_Data');m[at:at+256]=bytes([248,0,0,0])*64
   beforeC=m.banks[2];c,l,tr=call(m,'RdHzDrawDrops');minimum=min(minimum,l)
   assert m.banks[2]==beforeC and get(m,'CurrentCHRBank',6)==182 and get(m,'X5ChrMode',6)==130
   assert all(get(m,'CurrentCHRBank',i)==0 for i in range(1,6))
   count=get(m,'CurrentOAMOffset')-off
   assert count==4
   oam=[list(m[at+((off+rot+j)&255):at+((off+rot+j)&255)+4])for j in range(0,count,4)]
   _,expected,_=src.original_art(raw,kind,0)
   assert render.pixels(b['raw'],oam,694,origin=(x-camera,y))=={xy:(v,a&32)for xy,(v,a)in expected.items()},(kind,x,camera,y,off,rot,oam)
   rows.append([kind,x,camera,y,off,rot,l])
  checks['actual_drop_first_reader_OAM_source_pixels_CHR_Crestore']=dict(cases=len(rows),SHA256=w.ref.digest(json.dumps(rows).encode()),source_pairs=2,parts=1,window6=694,palette='Approved existing body0; authentic indices/geometry/priority, original hues not claimed')
  rows=[]
  for name,kind in itertools.product(['RdHzTerminal','RdHzUpdateDrops','RdHzDrawDrops'],['IRQ','lagNMI']):
   m=w.life.make(b);call(m,'X5ColdInit');m[0x5fee]=1;no_drops(m)
   if name=='RdHzTerminal':
    w.target(m,6,wx=164,y=176);w.shot(m,action=2,wx=168,y=196,frame=75);put(m,RdGear=64);m[address(b,'PseudoRandomBitReg')+1]=17
   else:drop(m,129,x=128,y=192);put(m,RdHealthLo=0,RdHealthHi=1)
   bank=(location(b,name)-16)//8192;actual=[];oldstep=NesMPU.step
   def step(cpu):
    if cpu.pc==address(b,'RdHzTerminal')and m.banks[1]==121:
     rng=get(m,'PseudoRandomBitReg',1);want=[128,129,137,128,129,137,129,137][rng&7]if rng>=16 else 0
     if want==128 and get(m,'RdMaxMissiles')==0 or want==137:want=0 # actual target Goomba
     actual.append(dict(RNG=rng,expected=want,SP=cpu.sp))
    oldstep(cpu)
   NesMPU.step=step
   try:c,row=w.life.mainstep(m,first=True,seam=(address(b,name),bank,kind))
   finally:NesMPU.step=oldstep
   minimum=min(minimum,row['minimum_SP'])
   if name=='RdHzTerminal':assert get(m,'Enemy_State')&32 and actual and get(m,'InvDropKind',3)==actual[0]['expected'],(name,kind,actual,[get(m,'InvDropKind',i)for i in range(4)],row)
   else:assert list(m[0x5fb4:0x5fb6])==[80,1]
   rows.append(dict(owner=name,interrupt=kind,minimum_SP=row['minimum_SP'],actual_Main=row,actual_native_rng=actual))
  checks['genuine_Main_terminal_drop_contact_render_actual_IRQ_lagNMI']=rows
  rows=[]
  for (char,key,var),mode in itertools.product(w.edges.PROFILES,[0,1]):
   pair=[]
   for bundle in[old,b]:
    q=w.edges.foreign(bundle,char,key,var,mode);c,wr,_=run(q,'GameLoop',p=113)
    pair.append((registers(c),app(q),tuple(q.m.banks),cleanwrites(q,wr),c.processorCycles))
   assert pair[0][:4]==pair[1][:4],('foreign fullMain',char,key,var,mode)
   rows.append(dict(raw=char,key=key,variant=var,mode=mode,CPU_delta=pair[1][4]-pair[0][4]))
  checks['all_foreign_complete_Main_regs_application_orderedwrites_banks']=rows
  proof.update(passed=True,minimum_SP=minimum,limits=['Source CPU/typed scenes only; not native acquisition, physical DMA/PPU timing/visibility/audio or playable admission.','Original quota-counter conclusion is normal room initialization/reset scope; special13/scripted bit6 reward branch excluded.','All other unlisted ordinary classes/armored/flying/water contacts remain old explicit lifecycle policy; no weapon HP/default drops assigned.','Menu/lives/UI reachability and exact-owner foreign routing cost remain next unit.'])
 except BaseException as e:proof.update(error=str(e),traceback=traceback.format_exc());raise
 finally:
  proof['bindings']=[w.ref.binding(p)for p in[Path(__file__),O/'build.json',O/'candidate.nes',O/'candidate.dbg',P/'handoff.json',R/'src/rogue_dawn_host_hazards_drops_v1.s',R/'src/rogue_dawn_host_hazards_gate_v1.s',src.O/'proof.json',w.ref.ROM]]
  (O/'controls.json').write_text(json.dumps(proof,indent=2)+'\n')
 print(json.dumps(dict(passed=True,minimum_SP=minimum,checks={k:len(v)if isinstance(v,list)else v.get('cases')for k,v in checks.items()})))
if __name__=='__main__':main()
