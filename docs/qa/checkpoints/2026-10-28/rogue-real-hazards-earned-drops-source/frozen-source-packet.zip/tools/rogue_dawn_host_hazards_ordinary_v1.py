"""Actual flag-off rebuilds of the sparse hazard/drop source successor."""
from pathlib import Path
import sys
R=Path(__file__).resolve().parents[1];sys.path[:0]=[str(R/'tools')]
import rogue_dawn_host_weapons_ordinary_v1 as old
old.O=R/'build/rogue-dawn-host-hazards-v1'
if __name__=='__main__':old.main()
