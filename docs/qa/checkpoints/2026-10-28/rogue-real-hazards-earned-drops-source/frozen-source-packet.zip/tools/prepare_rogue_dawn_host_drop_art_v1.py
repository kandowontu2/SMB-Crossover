"""Original Rogue ordinary-drop producer, counters, amounts and literal art.

Finite original-CPU evidence. The SMB RNG/actor mapping is explicitly separate;
no original room-state bytes are manufactured inside the host.
"""
from pathlib import Path
import itertools,json,sys
R=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(R/'tools'),str(R/'tools/audit')]
import rogue_dawn_map_v1 as ref
import prepare_rogue_dawn_art_v1 as art
import prepare_rogue_dawn_item_art_v1 as items
from check_tmnt_render_oa import location
from link_pit_rygar_sophia_audit_cpu import scoped_load
from py65.devices.mpu6502 import MPU

O=R/'build/rogue-dawn-host-drop-source-v1'
P=R/'build/rogue-dawn-host-items-worldcoords-v3'
INC=R/'src/rogue_dawn_item_drop_art_v1.inc'
CHR=R/'chr/characters/rogue-dawn-items-drops.chr'

def prefix(m,start,stop,**kw):
 c=MPU(memory=m,pc=start);c.sp=253
 for k,v in kw.items():setattr(c,k,v)
 pcs=[]
 for _ in range(20000):
  if c.pc==stop:return c,pcs
  pcs.append(c.pc);assert m[c.pc]!=0,hex(c.pc);c.step()
 raise AssertionError(('prefix',hex(c.pc),hex(stop)))

def original_drop(raw,rng,typ=2,maxmiss=5,caps=(255,254),counts=(0,0),mode=3):
 m=art.Memory(ref.cpu_image(raw,lower_bank=2,a_bank=3))
 for a,v in {0x4b:0,0x74:mode,0x6b02:typ,0x40c:0,0x2e:rng,
             0x687a:maxmiss,0x93:caps[0],0x94:caps[1],0x95:counts[0],0x96:counts[1]}.items():m[a]=v
 art.call(m,0xdcfc)
 return m

def original_art(raw,frame,phase,area=2):
 m=art.Memory(ref.cpu_image(raw,lower_bank=area,a_bank=area+1))
 art.call(m,0xc8b0) # genuine current-area sprite decoder pointer initialization
 for a,v in {0x4b:0,0x400:128,0x401:128,0x6af4:5,0x6af7:frame,
             0x49:2,0x6b:0xa0|phase,0x6afb:0}.items():m[a]=v
 c=art.call(m,0xdd8b)
 parts=[list(m[i:i+4])for i in range(512,512+m[0x5b],4)]
 return parts,art.source_pixels(raw,parts),c.processorCycles

def main():
 assert not(O/'proof.json').exists(),'Preserve frozen source evidence'
 raw=ref.ROM.read_bytes();assert ref.digest(raw)==ref.EXPECTED
 b=scoped_load(P/'candidate.nes');assert ref.digest(b['raw'])=='b95c0362cb9120b505385e76258d7ffe4212279e3458de23b403d64e5627d657'
 O.mkdir(exist_ok=True)
 checks={};rows=[]
 # Execute the genuine initialization writer, including its C76A branch.
 for mode,special in itertools.product([0,1,3,0x13],[0,1]):
  m=art.Memory(ref.cpu_image(raw,lower_bank=2,a_bank=3));m[0x74]=mode;m[0x7812]=special
  c,pcs=prefix(m,0xc8f2,0xc90e,x=255)
  assert m[0x93]==m[0x94]==(39 if (mode&15)==0 and special==0 else 47)
  rows.append(dict(mode=mode,special=special,cap_missile=m[0x93],cap_energy=m[0x94],writer_PCs=['C90A','C90C']))
 checks['actual_init_caps']=rows
 rows=[]
 for area,rng in itertools.product([2,4,6,8,10],[0,16,255]):
  m=art.Memory(ref.cpu_image(raw,lower_bank=area,a_bank=area+1));m[0x56]=0;m[0x58]=1;m[0x2e]=rng
  m[0x95]=m[0x96]=99;c,pcs=prefix(m,0x8b13,0x8b2a)
  assert list(m[0x93:0x97])==[255,254,0,0]
  rows.append(dict(area=area,RNG=rng,actual_caps_counts=list(m[0x93:0x97]),writer_PCs=['8B1B','8B1D','8B23','8B28']))
 checks['actual_room_transition_reset_writer']=rows
 assert raw[16+62*8192+0x1d48:16+62*8192+0x1d4a]==b'\xea\xea'
 assert raw[16+62*8192+0x1d51:16+62*8192+0x1d53]==b'\xea\xea'
 table=bytes(ref.cpu_image(raw,lower_bank=2,a_bank=3)[0xbfe7:0xbfef]);assert table==bytes.fromhex('80 81 89 80 81 89 81 89')
 rows=[]
 for typ,rng in itertools.product([0,1,2,4,5],range(256)):
  m=original_drop(raw,rng,typ)
  eligible=bool(ref.cpu_image(raw,lower_bank=2,a_bank=3)[0x968b+typ]&1)
  want=table[rng&7] if rng>=16 else None
  if want==0x89 and not eligible:want=None
  assert m[0x6af4]==(5 if want is not None else 0),(typ,rng,want,m[0x6af4])
  if want is not None:assert m[0x6af7]==want and m[0x40d]==96
  assert list(m[0x93:0x97])==[255,254,0,0]
  rows.append([typ,rng,want])
 checks['real_producer_threshold_table_large_gate']=dict(cases=len(rows),sha256=ref.digest(json.dumps(rows).encode()),source_table=list(table))
 rows=[]
 for rng,maxmiss,eqmiss,eqenergy in itertools.product([16,17,18],[0,5],[False,True],[False,True]):
  caps=(0 if eqmiss else 255,0 if eqenergy else 254)
  m=original_drop(raw,rng,maxmiss=maxmiss,caps=caps)
  selected=table[rng&7]
  allowed=not((selected==128 and (eqmiss or maxmiss==0))or(selected!=128 and eqenergy))
  assert m[0x6af4]==(5 if allowed else 0)
  rows.append([rng,maxmiss,eqmiss,eqenergy,allowed])
 checks['all_original_quota_and_missile_capacity_gates']=rows
 checks['counter_meaning']=dict(source_comparison='Stock DD48 INC95 / DD51 INC96; Rogue replaces both with NOP NOP.',
  meaning='Per-room emitted-drop counters and caps, not current health/missile fullness.',
  host_adaptation='No source room bytes are introduced. Normal admitted source init/reset leaves caps unequal to zero counts, and Rogue never increments these counters; host therefore retains the consequent open normal-room quota. Source special mode13 and bit6 scripted boss/reward branch are excluded.',
  scope='Executed genuine writer ranges and complete ordinary producer; not an all-original-ROM arbitrary-indirect-writer proof.')
 rows=[]
 for frame,small in [(128,False),(129,True),(137,False)]:
  m=art.Memory(ref.cpu_image(raw,lower_bank=2,a_bank=3))
  for a,v in {0x4b:0,0x404:4,0x6af4:5,0x6af7:frame,0x6b02:0,0x6879:0,0x687a:30,0x106:0,0x107:0}.items():m[a]=v
  stop=0xf4d1 if frame==128 else 0xf4b4
  c,pcs=prefix(m,0xf483,stop,x=0)
  assert m[0x6af4]==0 and 0xfa18 in pcs # actual erase precedes grant
  if frame==128:assert m[0x6879]==5;amount=5
  else:
   assert m[0x106]==(0x50 if small else 0) and m[0x107]==(0 if small else 2)
   amount=5 if small else 20
  rows.append(dict(frame=frame,amount=amount,erase_before_grant=True,grant_boundary=hex(stop)))
 checks['actual_mature_contact_amounts']=rows
 rows=[]
 # Stop before actual draw; exact96 timer, one decrement per four clocks.
 for initial in range(4):
  m=art.Memory(ref.cpu_image(raw,lower_bank=2,a_bank=3));m[0x6af4]=5;m[0x40d]=96
  ticks=[]
  for tick in range(1,385):
   m[0x2d]=(initial+tick)&255;c,pcs=prefix(m,0xf4d4,0xf4eb,x=0)
   if 0xf4da in pcs:ticks.append(tick)
   if not m[0x6af4]:break
  assert len(ticks)==96 and tick==384-initial
  rows.append(dict(initial_clock=initial,updates=tick,decrements=96))
 checks['source_drop_lifetime']=rows
 # Version descriptors only; unchanged existing40 pixel masks, deduplicate
 # now-identical palette0 phases to fit the new authentic drop descriptors.
 records=[]
 for i in range(40):
  base=location(b,'RdItemLoA');hi=location(b,'RdItemHiA')
  ptr=b['raw'][base+i]+256*b['raw'][hi+i]-0x2000
  at=16+121*8192+ptr-0xa000;n=b['raw'][at]
  records.append(bytes(b['raw'][at:at+n+1]))
 oldchr=(R/'chr/characters/rogue-dawn-items.chr').read_bytes()
 assert not any(oldchr[896:])
 pairs=[oldchr[i:i+32]for i in range(0,896,32)];facts=[]
 for frame in [128,129,137]:
  parts,pixels,cycles=original_art(raw,frame,0)
  # Reuse root authenticated native8x8 -> host8x16 encoder and top-left+8 API.
  record=items.pack(pixels,pairs)
  record=bytearray(record)
  for i in range(2,len(record),4):record[i]&=0xfc
  records.append(bytes(record))
  for area,phase in itertools.product([2,4,6,8,10],[0,1]):
   other,p,cy=original_art(raw,frame,phase,area)
   assert {(x,y):(v,a&~3)for(x,y),(v,a)in p.items()}=={(x,y):(v,a&~3)for(x,y),(v,a)in pixels.items()}
  facts.append(dict(frame=frame,source_OAM=parts,opaque=len(pixels),parts=(len(record)-1)//4,source_cycles=cycles))
 assert len(pairs)<=32,(len(pairs),'Only four free native window6 pairs permitted')
 data=b''.join(pairs)+bytes(2048-32*len(pairs));unique=list(dict.fromkeys(records))
 used=86+sum(map(len,unique));assert used<=512,used
 lines=['; Approved SMB adaptation: source drop frame80/81/89, original indices/masks/priority, palette0.',
 '.pushseg','.segment "ROGUE_DAWN_HOST_AUX"',
 '.assert (*-RdWxAuxStart)<=$10a0,error,"Protect item descriptor tail"',
 '.res $10a0-(*-RdWxAuxStart),$ff','RD_ITEM_LO_C=$de00','RD_ITEM_HI_C=$de2b',
 '.export RdItemLoA,RdItemHiA,RD_ITEM_LO_C,RD_ITEM_HI_C','RdItemLoA:',
 '.byte '+','.join('<(RdItemDropRecord%d+$2000)'%unique.index(r)for r in records),'RdItemHiA:',
 '.byte '+','.join('>(RdItemDropRecord%d+$2000)'%unique.index(r)for r in records)]
 for i,r in enumerate(unique):lines+=['RdItemDropRecord%d:'%i,'.byte '+','.join('$%02x'%v for v in r)]
 lines+=['RdItemArtEnd:', '.assert *<=$c000,error,"Item/drop descriptor512B cap"','.popseg','']
 CHR.write_bytes(data);INC.write_text('\n'.join(lines),newline='\n')
 proof=dict(passed=True,source_CPU_only=True,native_run=False,checks=checks,art=facts,
  unique_pairs=len(pairs),added_pairs=len(pairs)-28,descriptor_bytes=used,old40_records_literal_equal=True,
  approved_host_rng='PseudoRandomBitReg+1 (actual native SMB generator byte); no source RNG byte/room state is fabricated.',
  pending=['Typed verified terminal defeat -> native actor birth/mature collision/render/lifetime host consumer not yet implemented.',
           'Original source palette roles are adapted to existing body-owned palette0; no original hue claim.',
           'Full consumer palette/CHR/OAM/capacity and actual native visibility remain unqualified.'],
  outputs=[ref.binding(INC),ref.binding(CHR)],bindings=[ref.binding(p)for p in [Path(__file__),ref.ROM,ref.BASE,
   R/'tools/prepare_rogue_dawn_art_v1.py',R/'tools/prepare_rogue_dawn_item_art_v1.py',P/'handoff.json',P/'candidate.nes',P/'candidate.dbg',R/'chr/characters/rogue-dawn-items.chr']])
 (O/'proof.json').write_text(json.dumps(proof,indent=2)+'\n')
 print(json.dumps(dict(passed=True,producer_cases=1280,pairs=len(pairs),added_pairs=len(pairs)-28,descriptor_bytes=used)))
if __name__=='__main__':main()
