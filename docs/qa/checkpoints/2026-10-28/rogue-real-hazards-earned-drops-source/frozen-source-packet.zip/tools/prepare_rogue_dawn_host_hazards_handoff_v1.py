"""Freeze source-qualified hazards/drops; no native/menu/audio admission."""
from pathlib import Path
import json,subprocess,sys
R=Path(__file__).resolve().parents[1];sys.path[:0]=[str(R/'tools'),str(R/'tools/audit')]
import rogue_dawn_map_v1 as ref
import prepare_rogue_dawn_host_body_handoff_v1 as closure
from link_pit_rygar_sophia_audit_cpu import scoped_load
from check_tmnt_render_oa import address
O=R/'build/rogue-dawn-host-hazards-v1';P=R/'build/rogue-dawn-host-items-worldcoords-v3'
REPORT=R/'docs/qa/rogue-dawn-host-hazards-drops-source-2026-10-29.json'
def main():
 assert not(O/'handoff.json').exists(),'Preserve immutable successor'
 build=json.loads((O/'build.json').read_text());checks={n:json.loads((O/n).read_text())for n in['controls.json','edge-controls.json','progression-controls.json','ordinary-controls.json']}
 source=R/'build/rogue-dawn-host-drop-source-v1/proof.json';original=json.loads(source.read_text())
 for d in[build,original,*checks.values()]:
  assert d['passed']
  for q in d['bindings']+d.get('outputs',[]):assert ref.binding(q['path'])==q,q['path']
  if 'ROM'in d:assert d['ROM']['sha256']==build['ROM']['sha256']
 b=scoped_load(O/'candidate.nes')
 cmd=[str(R/'tools/Windows/cc65/bin/cc65.exe'),'--cpu','6502x','-t','nes','-g','-Oisr','-T','-I',str(R),'--create-full-dep',str(O/'c-full.dep'),'-o',str(O/'c-closure.s')]
 for i,v in enumerate(build['commands'][1]):
  if v=='-D':cmd+=['-D',build['commands'][1][i+1]]
 cmd+=[str(O/'main.c')];z=subprocess.run(cmd,cwd=R,capture_output=True,text=True);(O/'c-closure.log').write_text(z.stdout+z.stderr);assert z.returncode==0,z.stdout+z.stderr
 adeps=list(dict.fromkeys(closure.dependencies(O/'assembler-full.dep')+closure.dependencies(O/'weapon-object.dep')));cdeps=closure.dependencies(O/'c-full.dep')
 assert len(adeps)==build['actual_ASM_inputs']==509 and len(cdeps)==10
 c=checks['controls.json']['checks'];e=checks['edge-controls.json']['checks'];progress=checks['progression-controls.json']
 actual={n:dict(PC=hex(address(b,n)),bank=(next((int(b['segs'][b['syms'][n]['seg']]['ooffs'],0)-16)//8192 for _ in[0])if 'seg'in b['syms'][n]else None))for n in['RdHzInjury','RdHzFirebar','RdHzGrant','RdHzTerminal','RdHzBossDefeat','RdHzHammer','RdHzUpdateDrops','RdHzDrawDrops']}
 summary=dict(status='PRIVATE bounded source-qualified hazard/drop successor; no playable/native admission',native_run=False,ROM=build['ROM'],parent=ref.binding(P/'candidate.nes'),preserved_b95c=ref.binding(P/'handoff.json'),source_ROM=ref.binding(ref.ROM),
  layout=dict(A95_end=build['A95_end'],A95_free_to_BF00=0xbf00-address(b,'RdHzGateEnd'),A121_code_and_weapon_art_end=build['A121_end'],A121_code_free_to_BE00=0xbe00-address(b,'RdWpArtEnd'),item_tail_used=254,item_tail_limit=512,item_tail_end=build['item_end'],new_RAM=0,drop_storage='Four existing native InvDrop slots, typed80/81/89; stationary original96 counter. No new global flag/room bytes.',CHR='Page694 now30/32 authenticated pairs;2 new pairs occupy originalzero prefix896..959. Page695 and all other CHR exact b95c.'),
  actual_entries=actual,original_source=original,
  source_vs_adaptation=dict(
   heat='Explicit native Firebar IDs1B..22 / Podoboo0C -> original E28D..E2A1 rawBCD07 damage (0.7 displayed energy), exact Clock cadence and Suit cadence/halving. Screw does not protect environmental heat. No invented source room state.',
   projectile='Native BowserFlame15 and actual Misc hammers -> source hostile-projectile8.0 contact/Screw protection. Native PlayerHammerCollision physically reverses speed before damage even without Screw, preserved exactly; no synthetic source enemy erase/reflection state.',
   boss='Authored SMB Bowser2D -> source default-area type8 HP32 (F85A/F863,962B[8]=20hex), source mini-boss40 admission (F536/F54B), no first Ice freeze, beam/bomb/Screw1,Wave2,Ice4 withgear,missile4; source hurt3. Native HandleEnemyFBallCol remains sole terminal score/rear-clear/fall owner. No boss/scripted drops or Hard/bit80 HP multiplier. Source has no Bowser species claim.',
   drops='Explicit ordinary SMB adaptation. Only verified paid Rogue source-weapon/Screw terminal path rolls actual PseudoRandomBitReg+1 against original default-area2 BFE7 table and threshold10hex. Existing legacy drop hook remains suppressed for native Star/shell/stomp-only kills in this unit. GoombaHP2 ->source4/5 suppresslarge89; approvedHP4/8 actors ->source2/0/1 permitlarge. No unknown type default.',
   quotas='Original93/94 caps and95/96 emitted counts, not health/ammo. Actual source normal init/reset keeps them unequal, Rogue removes stock increments. Host retains that open normal-room consequence without fabricating source room bytes. True missile max0 suppression retained. Special mode13/scripted bit6 reward paths excluded.',
   collection='Birth uses original actor origin before ShellOrBlockDefeat demotion/-2Y. One source-style birth epoch before collection; actual player world-page/radius overlap and authentic drop radiusY8/4, radiusX4. Original amounts5/20energy and5missiles use genuine source BCD/caps/requests. Source-original contact/erase prefix and host once-only typed removal separately established.',
   art='Actual original DD8B enemy decoder / true initialized pointer tables, never substituted player decoder. Exact source pixel indices/order/geometry/behindBG priority; approved body-palette0 adaptation retains world palettes1..3. No original hue cycling/color fidelity claim. One native8x16 part per drop; transparent half affects first8/clipping/capacity.'),
  native_hammer_owner='Original RunAllH JSR return RunHSubs plus saved actual physicalA bank identify the real Misc caller before reading its slot. Require state80,collision1,Yhigh1,parent0..4 activeFlag1/ID05/notdead. Wrong return/unrelated Misc never leaks into ordinary injury.',
  closure=e['actual_ROM_sparse_delta_and_frozen_spans'],old_PC_RAM=e['all_old_qualified_PC_RAM_other_than_owned_aux'],checks=c,edge_checks=e,
  source_progression_recheck=dict(actual_mature_chains=len(progress['checks']['complete_native_constructor_emergence_physical_contact_next_constructor']),minimum_SP=progress['minimum_SP'],scope='Same22 real constructor/rise/contact/next-constructor CPU cases on this actual new auxiliary schedule/descriptor table; no resource/maturity/outcome seeds. Not native/natural acquisition.'),
  minimum_SP=min(d.get('minimum_SP',255)for d in checks.values()),stack_contract='Source-only genuine caller/IRQ/lagNMI; protected128. Literal frozen ControlStepSP192 remains unchanged. Older standalone deferred flushSP192 negative remains distinct and preserved, not waived.',
  costs=dict(foreign_full_Main_added_CPU_vs_b95c=sorted(set(r['CPU_delta']for r in c['all_foreign_complete_Main_regs_application_orderedwrites_banks'])),legacy_Samus_full_firebar_added_CPU=sorted(set(r['CPU_delta']for r in e['actual_legacy_Samus_InventoryHas5_full_ABI_application_writes_banks'])),prior_costs='Prior b95c/56ee/lifecycle wrappers have separately measured cost. This is not a zero-cost/performance/native-lag claim. Final shared exact-identity routing remains required.'),
  ordinary=[dict(mapper=r['mapper'],ROM=r['ROM'])for r in checks['ordinary-controls.json']['rows']],
  unlisted_classes=dict(native_HPs='Only0/3/E/F/10 Koopa4,D Piranha4,12 Spiny4,6Goomba2,5Hammer8,11Lakitu8,2DBowser32. Buzzy2,otherground1/4/9,Bloober7,Bullet8/33,CheepA/B/14 have no inventedweapon HP/drop mapping.',contacts='Existing listed ordinary contact8.0 remains; actual source Screw protection precedes real ordinary IDs0..14 except heat0C. Fireworks16/frenzy17/18,NoRun19/1A/23,platform24..2C,powerup2E,vine2F,flags30/31,spring32,warp34,retainer35 are not generalized hazards or drops.',hazards='Source environmental heat adaptation only for0C and1B..22; arbitrary SMB terrain/lava/timer pits/boss bridge remain genuine native owners, not invented Rogue room hazards.'),
  actual_ASM_incbin_inputs=len(adeps),actual_C_inputs=len(cdeps),actual_C_command=cmd,
  preserved_preparation_negatives=['Initial new source test incorrectly used source action2/frame23 alone as Screw; true CD9C requires action1 plus actual animationReset/Index admission. Corrected fixture only, no core edit.','Initial manual hammer call omitted incomingX=actualMiscSlot; real ProcHammerObj provides it. Constructor/complete caller now qualified.','Direct comparison of different mapped helper entries is not a bank-preserving caller test. Genuine whole FirebarCollision old/new verifies full ABI/ordered application writes.'],
  next=['Menu/Samus alternate selection, lives/status/health/missile UI and exact transition cleanup admission. Standalone NrFreshGameInit leaves old drop records; complete following InitializeArea clears all4.',
        'Authentic original Rogue audio driver bridge remains ROOT-owned/open; no stockSamus equivalence.',
        'Native physical256DMA/CHR/fetch/PPUMASK timing/fullPPU/first8/actual acquisition/whole-world validation remains open. No menu/native exposure or release from this source unit.'])
 REPORT.write_text(json.dumps(summary,indent=2)+'\n')
 own=[Path(__file__),REPORT,source,R/'src/rogue_dawn_host_hazards_gate_v1.s',R/'src/rogue_dawn_host_hazards_drops_v1.s',R/'src/rogue_dawn_item_drop_art_v1.inc',R/'chr/characters/rogue-dawn-items-drops.chr']+[R/'tools'/n for n in['prepare_rogue_dawn_host_drop_art_v1.py','prepare_rogue_dawn_host_hazards_v1.py','rogue_dawn_host_hazards_controls_v1.py','rogue_dawn_host_hazards_edges_v1.py','rogue_dawn_host_hazards_ordinary_v1.py']]
 own += [p for p in O.iterdir()if p.suffix in['.s','.inc','.c','.cfg','.dep','.patch','.json']and p.name not in['handoff.json','owned-files.json']]
 paths=adeps+cdeps+own+[Path(q['path'])for d in[build,original,*checks.values()]for q in d['bindings']+d.get('outputs',[])]+[O/'candidate.nes',O/'candidate.dbg',O/'candidate.lbl',O/'candidate.map',O/'weapon-object.o',R/'tools/Windows/cc65/bin/cc65.exe',R/'tools/Windows/cc65/lib/nes.lib',R/'build/rogue-dawn-host-deferred-v1/control-SP192-deferred-negative.json']
 packet=dict(passed=True,source_only=True,native_run=False,playable_admission=False,ROM_sha256=build['ROM']['sha256'],report=ref.binding(REPORT),bindings=[ref.binding(p)for p in dict.fromkeys(paths)],owned_publication_files=[ref.binding(p)for p in dict.fromkeys(own)])
 h=O/'handoff.json';h.write_text(json.dumps(packet,indent=2)+'\n')
 m=dict(frozen=True,source_only=True,native_run=False,files=packet['owned_publication_files']+[ref.binding(h)])
 (O/'owned-files.json').write_text(json.dumps(m,indent=2)+'\n')
 print(json.dumps(dict(ROM=build['ROM']['sha256'],handoff=ref.digest(h.read_bytes()),report=ref.digest(REPORT.read_bytes()),bindings=len(packet['bindings']),owned=len(m['files']))))
if __name__=='__main__':main()
