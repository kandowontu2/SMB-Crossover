"""Read-only fb28 native gap negative and finite actual Main takeoff controls."""
from pathlib import Path
import csv,json,sys
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import dragon_power_gameplay_controls_v1 as C
from sunny_integrated_controls_v1 import scoped_load,run,address,location,sha
O=R/'build/dragon-power-admission-v1';N=R/'build/verification/dragon-power-admission-native-easy-v2'

def main():
 out=R/'build/dragon_power_native_gap_diagnosis_v1.json';assert not out.exists()
 b=scoped_load(O/'candidate.nes');assert sha(O/'candidate.nes')=='fb28a741937ad5fb18d7f76f272874118c291dc0a575f69e15a2573436df500e'
 result=json.loads((N/'result.json').read_text())
 assert result['passed']is False and result['frames']==2216 and result['lives']['decreased']==1
 rs=list(csv.DictReader((N/'trace.csv').open()))
 native=[{k:int(r[k])for k in['frame','loops','x','y','state','vy','mask','camera','engine']}for r in rs if 2148<=int(r['frame'])<=2216]
 take=next(r for r in native if r['state']==1)
 assert take['x']==1344 and take['y']==176 and min(r['y']for r in native)==116
 p=C.setup(b);p.put(AreaPointer=37,WorldNumber=0,Hidden1UpFlag=1);run(p,'GetAreaDataAddrs')
 for j in range(3):p.set('AreaObjectLength',255,j)
 cols=[]
 for x in range(96):
  run(p,'AreaParserCore');cols.append([p.get('MetatileBuffer',y)for y in range(13)]);run(p,'IncrementColumnPos')
 assert [cols[i][11]for i in range(85,90)]==[0x54,0,0,0,0x54]
 cases=[]
 for mode in[0,1]:
  for threshold in[1344,1360,1368,1374]:
   q=C.setup(b);q.put(CrossoverBehaviorVersion=mode)
   C.actor(q,0,0x2e,96,176);q.set('PowerUpType',0,0);q.set('Enemy_State',128,0)
   for age in range(65):
    q.put(SavedJoypadBits=0,NmiDisable=255,VRAM_Buffer1_Offset=0,FrameCounter=age);C.M.runtrace(q,'GameLoop')
   assert q.get('DpPole')==1 and q.get('DpPower')==1 and q.get('PlayerStatus')==1
   for x,col in enumerate(cols):
    for y,t in enumerate(col):q.m[address(b,'Block_Buffer_1')+((x//16)%2)*208+y*16+x%16]=t
   q.put(Player_PageLoc=5,Player_X_Position=48,Player_Y_Position=176,Player_Rel_XPos=112,
    ScreenLeft_PageLoc=4,ScreenLeft_X_Pos=192,ScreenRight_PageLoc=5,ScreenRight_X_Pos=191,Player_Pos_ForScroll=112)
   rows=[];launch=None;land=None;minimum=255
   for age in range(110):
    xx=q.get('Player_PageLoc')*256+q.get('Player_X_Position');keys=1|(128 if xx>=threshold else 0)
    q.put(SavedJoypadBits=keys,NmiDisable=255,VRAM_Buffer1_Offset=0,FrameCounter=age+65)
    cpu,tr,sp=C.M.runtrace(q,'GameLoop');minimum=min(minimum,sp)
    x=q.get('Player_PageLoc')*256+q.get('Player_X_Position');y=q.get('Player_Y_Position')
    r=[age,keys,x,y,q.get('DpAction'),q.get('DpVertical'),list(q.m[address(b,'DpContacts'):address(b,'DpContacts')+7])];rows.append(r)
    if r[4]==2 and launch is None:launch=r
    if launch and y==176 and x>=1424 and q.get('Player_State')==0 and land is None:land=r
    if q.get('Player_Y_HighPos')!=1 or y>=212:break
   assert launch is not None
   if threshold in[1360,1368]:assert launch[5]==231 and land is not None and min(r[3]for r in rows)==116
   elif threshold==1344:assert launch[5]==231 and land is None and rows[-1][3]>=212 and rows[-1][2]<1424
   else:assert launch[5]==0 and launch[6][:2]==[0,0]and land is None
   cases.append(dict(mode=mode,takeoff_threshold=threshold,launch=launch,landing=land,minimum_Y=min(r[3]for r in rows),
    actual_Main_updates=len(rows),minimum_SP=minimum,rows=rows,fields=['update','mask','worldX','playerY','action','vertical','contacts0..6']))
 report=R/'docs/qa/dragon-power-native-gap-diagnosis-2026-10-29.txt'
 text='''FB28 V2 GAP NEGATIVE: SOURCE FOOT-ANCHOR/TAKEOFF DIAGNOSIS ONLY.
Original same-ROM native-v2 remains FALSE at2216 on actual life decrease,1891completeDMAs/1971IRQ+NMI checks/2113fullPPU. It cleared the first pipe. Actual trace shows source-height jump beginning1344/Y176 at2157, apexY116 around1374, returnY176 at1404, then fallY212 around1408 before the far ground1424. Actual DpAction/sourcevertical/contacts were not logged; native source-action or exact lethal writer is not invented here.
Original translated EDC9 foot probes are anchorX+2 andX+14 at sourcecenterY+16, i.e. nativePlayerY+32. The original jump admission E906..E933 requires at least one real foot contact or native platform support before storingE7. Generic policy tests support atX+32, causing this observed jump32px before a48px gap. Native parser96columns confirms actual gap1376..1424; source nominal speed1.25px/update and60px rise need a later takeoff. At1374 both real foot probes are over the gap, so waiting that late loses the genuine jump.
Eight actual complete-Main CPU arenas (bothmodes, fourtakeoffthresholds) use real mature Mushroom collection before a disclosed typed1328/Y176 boundary, exact current native parser terrain, no B/physics/resource/outcome seeds and no enemies. Threshold1344 reproduces the early full-height failure;1360 lands1424/Y176 and1368 lands1429/Y176;1374 initializes sourceVertical0 with both footcontacts0 and falls. Real source state/contacts are recorded only in these CPU arenas. Actual camera/native consumers run; sourceclock/FrameCounter and NmiDisable are CPU boundary inputs. No natural enemy/whole-route/PPU/deadline/FPS proof follows.
Narrow controller proposal: use a Goku gap lookahead16 rather than32, so the actual1376 edge triggers around1360, require real grounded/readback and freshA, and never B on initiation/ascent. Keep generic obstacle handling separate from gap lookahead. Do not change source jump/gravity/speed or invent coyote/support. Later gaps/stairs/hostile encounters still require actual native completion under unchanged strict guards. Root owns native launches; no game/shared/readiness mutation in this diagnostic.
'''
 report.write_text(text)
 files=[Path(__file__),Path(C.__file__),Path(C.M.__file__),O/'candidate.nes',O/'candidate.dbg',O/'candidate.lbl',O/'handoff.json',N/'trace.csv',N/'inputs.csv',N/'result.json',N/'ready.json',N/'run.lua',R/'tools/playthroughs/dragon_power_11_v1.lua',report]
 proof=dict(passed=True,diagnosis_only=True,native_v2_passed=False,new_native=False,native_trace_window=native,
  exact_native_parser_ground_columns={str(i*16):cols[i][11]for i in range(82,91)},source_CPU_cases=cases,
  actual_foot_probe_metadata=[dict(name=n,PC=f'{address(b,n):04X}',physical_bank=(location(b,n)-16)//8192,bytes=b['raw'][location(b,n):location(b,n)+8].hex())for n in['DpNEDC9','DpNEDD6','DpNE906','DpNE931','DpNE933']],
  bindings={str(p.resolve()):sha(p)for p in files},limits=text)
 out.write_text(json.dumps(proof,indent=2)+'\n')
 print(json.dumps(dict(output=str(out),sha256=sha(out),report_sha256=sha(report),tool_sha256=sha(__file__))))

if __name__=='__main__':main()
