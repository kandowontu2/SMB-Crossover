"""Original-ROM reward decoding/physical collection addendum, never host code."""
from pathlib import Path
from collections import Counter
import hashlib,json,sys
R=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(R/'tools'),str(R/'tools/audit')]
import dragon_power_drop_policy_v1 as T
O,D=T.O,T.D
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()

def main():
 out=R/'build/dragon_power_drop_consumers_v1.json';assert not out.exists()
 mem=D.memory(0);table=mem[0x8d9f:0x8dbf];checks={};chains=[]
 assert mem[0x9538:0x9560]==bytes.fromhex('bd4606c9fff022298f9d2806bd000638e914b005e90fde0a069d0006bd46064a4a4a4a29039d3206')
 for kind in sorted(set(table)):
  seed=next(s for s in range(256)if table[((s*5+17)&255)>>3]==kind)
  m=T.initial(seed=seed);m.ram[0xf7]=80;m.ram[0xf8]=64
  O.call(m,0x8e35,x=0)
  assert m[0x628+9]==0x80 and m[0x646+9]==kind
  rows=[];old=None
  for age in range(190):
   m.ram[0x26]=age&255;O.call(m,0x8edd)
   v=[m[0x628+9],m[0x632+9],m[0x63c+9],m[0x646+9],m[0x2e],m[0xd9],m[0x32],m[0x3b],m[0x1f],m[0x20],m[0xdd]]
   semantic=v[:2]+v[4:]
   if semantic!=old:rows.append([age]+v);old=semantic
   if age==120:
    assert v[:2]==[kind&0x8f,(kind>>4)&3]
    assert v[4:8]==[100,0,0,0],('no grant before actual collection',kind,v)
   if age==121:
    if kind==0x83:assert m[0x2e]==120 and m[0x628+9]==0
    elif kind==0x93:assert m[0x2e]==150 and m[0x628+9]==0
    elif kind==0xa3:
     assert m[0x2e]==100 and m[0xdd]==((5*((5*seed+17)&255)+17)&255)
     reward=(m[0xdd]&3)+1
     assert m[0x628+9]==0x80 and m[0x632+9]==reward and m[0x646+9]==0
     assert (m[0x1f],m[0x20])==((10+mem[0x9152+reward])&255,mem[0x915c+reward])
    elif kind==0x84:assert m[0xd9]==0x10 and m[0x36]==16 and m[0x2e]==100
    elif kind==0x85:assert m[0x32]&1 and m[0x2e]==100
    elif kind==0x86:assert m[0x3b]==3 and m[0x2e]==100
  assert not any(m.ram[0x628:0x632])
  chains.append(dict(encoded_kind=f'{kind:02X}',initial_RNG_seed=seed,actual_actor_kind=f'{kind&0x8f:02X}',
   subtype=(kind>>4)&3,updates=190,rows=rows,fields=['age','actor','subtype','timer','pending_reward','HP','D9','pole','wave_stock','score1F','score20','DD'],
   typed_initial_source_scene=[80,0,80,0,0],typed_player_center=[80,64],outcome_or_timer_seed=False,
   limitation='Source CPU actor arena; sourceclock is supplied per update, no native PPU/NMI/terrain or natural acquisition claim.'))
 checks['six_actual_original_reveal_to_collect_pipelines']=dict(chains=chains,actual_actor_updates=1140,
  all_reveal_at_age120_then_actual_collection121=True,each_retired_by190=True)
 scores=Counter();score_rows=[]
 for seed in range(256):
  m=T.initial(seed=seed);m.ram[0xf7]=80;m.ram[0xf8]=80
  m.ram[0x628]=0x83;m.ram[0x632]=2;m.ram[0x600]=80;m.ram[0x614]=80
  O.call(m,0x8eeb,x=0)
  state=(((5*seed+17)&255)&3)+1
  assert m[0xdd]==(5*seed+17)&255 and m[0x2e]==100 and m[0x628]==0x80 and m[0x632]==state and m[0x646]==0
  assert (m[0x1f],m[0x20])==(mem[0x9152+state],mem[0x915c+state])
  scores[state]+=1
  if state not in[p['score_index']for p in score_rows]:score_rows.append(dict(score_index=state,source_score_delta_1F_20=[m[0x1f],m[0x20]]))
 assert scores==Counter({1:64,2:64,3:64,4:64})
 checks['A3_real_collector_random_score_not_HP']=dict(cases=256,score_index_counts=dict(scores),score_table_rows=score_rows,
  exact_original_collector='0:8EEB ->919D ->91D2 ->97E8/97FC ->99DF ->9145',typed_mature_actor_boundary=True)
 callers=[]
 for pc,opcode in[(0xa8cc,0x4c),(0xa8cf,0x20),(0xa950,0x4c),(0xa958,0x20),(0xa971,0x20),(0xa9df,0x4c),(0xa9e9,0x20)]:
  assert mem[pc:pc+3]==bytes([opcode,0x35,0x8e])
  callers.append(dict(source_bank=0,PC=f'{pc:04X}',opcode='JSR'if opcode==0x20 else'JMP',target='8E35',bytes=mem[pc:pc+3].hex()))
 checks['actual_target_reward_callers']=dict(callers=callers,
  wave_source_A7F1_health_table_dispatch_A820=True,punch_source_A8DA_health_table_dispatch_A906=True,
  scope='Exact source call/table control-flow evidence, not an executed full natural enemy campaign; all source actor types/rooms are not enumerated.')
 report=R/'docs/qa/dragon-power-drop-consumers-2026-10-29.txt'
 text='''ORIGINAL REWARD CONSUMERS: ADDITIVE CORRECTION TO DROP-POLICY V1; NO HOST IMPLEMENTATION/NATIVE PASS.
Source0:9538..955D unpacks an encoded reward: actor=(kind&$8F), subtype=(kind>>4)&3. Therefore93 and A3 are not independent unknown actors.93 becomes83/sub1 and the genuine source collector adds100HP (cap150 without the story cap upgrade);83/sub0 adds20HP. A3 becomes83/sub2: its real contact-or-attack collector advances the original RNG, chooses score index1..4 uniformly over the256seed boundary, and converts to a native80score popup through9145, with no HP grant. Existing V1 factual uncertainty is historical; this additive proof resolves these two consumers without rewriting it.
All six actual selector outcomes now execute genuine8E35 spawn,190 real8EDD actor updates and physical97FC contact. With disclosed original typed scene record[80,0,80,0,0] and player center[80,64], source score-popup80 becomes8Acontainer atage87, the container presents the decoded reward at120, and its real collector runs at121. No reward/timer/HP outcome is seeded. The six pipelines cover1140actor updates, plus256mature A3collector RNG boundaries. These are original-CPU arenas, not native natural acquisition, movement/PPU/NMI or all-room evidence.
Conditional32-bin distribution after the earlier terrain/script/room-clock gates:15smallfood20HP;2largefood100HP;6random-score items;5source timed-speed items(D9bit10/seconds16);2three-plain-wave items;2ordinary-pole items. Do not claim15/32all-food (actual food is17/32), a25%SMB kill chance, or renormalize away unsupported outcomes. Source speed-state collection is proved; the full authentic speed/protection/timed-expiry integration into the current side-view host remains unimplemented, as are source item sprites.
Exact source calls to8E35 occur in the target-hit/defeat control flow at A8CC/A8CF/A950/A958/A971/A9DF/A9E9. Source A7F1 wave and A8DA punch health/dispatch chains establish this is also an original target-reward transaction; it is not exclusively a scenery event. Complete original actor-type/room threshold mapping and natural drop frequency are still unproved. Original8EA0 uses F9/D0/scriptD1/tile property and compares sourceclock26 with room threshold, so there is no source-backed universal per-SMB-defeat rate.
Small next host unit proposal: use an explicit approved SMB reward-event/room-threshold mapping, retain original selector and encoded subtype distribution, then exact typed visible source-item spawn/reveal/collection. Reuse native drop storage only after its slot/draw/credit lifecycle is audited. For unavailable timed-speed integration, preserve an explicit unsupported outcome or defer admission; never silently substitute food/ownership/ammo. No new RAM/RNG, host policy, enemy score or resource grant is implemented here. fb28 remains the frozen menu/lives/UI/palette/Hammer candidate; raw24 legacy drop hook still declines. Authentic audio scheduler and atomic cue publication remain open.
'''
 report.write_text(text)
 files=[Path(__file__),D.ROM,Path(O.__file__),Path(D.__file__),Path(T.__file__),R/'build/dragon_power_drop_policy_v1.json',R/'build/dragon-power-admission-v1/handoff.json',report]
 proof=dict(passed=True,original_ROM_CPU_only=True,native_run=False,host_implementation=False,checks=checks,
  source_decode_bytes=mem[0x9538:0x9560].hex(),actual_collector_span_sha256=hashlib.sha256(mem[0x919d:0x9201]).hexdigest(),
  bindings={str(p.resolve()):sha(p)for p in files},limits=text)
 out.write_text(json.dumps(proof,indent=2)+'\n')
 print(json.dumps(dict(output=str(out),sha256=sha(out),report_sha256=sha(report),tool_sha256=sha(__file__))))

if __name__=='__main__':main()
