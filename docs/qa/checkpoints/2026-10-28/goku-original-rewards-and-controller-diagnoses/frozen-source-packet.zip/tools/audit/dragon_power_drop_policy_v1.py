"""Read-only original drop/reveal policy facts; no host code or native run."""
from pathlib import Path
from collections import Counter
import hashlib,json,sys
R=Path(__file__).resolve().parents[2];sys.path.insert(0,str(R/'tools'))
import dragon_power_reference_v1 as O
import dragon_power_map_v1 as D
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def initial(mode=1,seed=0,clock=0):
 m=O.Memory(0);m.ram[0xf9]=mode;m.ram[0xd0]=0;m.ram[0xd1]=0;m.ram[0x26]=clock;m.ram[0xdd]=seed;m.ram[0x75]=0
 m.ram[0x200:0x205]=bytes([80,0,80,0,0]);m.ram[0xf7]=200;m.ram[0xf8]=200;m.ram[0x2e]=100;m.ram[0x2d]=1
 return m
def main():
 output=R/'build/dragon_power_drop_policy_v1.json';assert not output.exists()
 assert sha(D.ROM)=='e52cc421c726181a35f0cc9e8969a8aad50abd17bdc7eea59dc065990a576147'
 mem=D.memory(0);table=mem[0x8d9f:0x8dbf];expected=Counter(table);checks={};rows=[]
 for mode in[1,2]:
  counts=Counter()
  for seed in range(256):
   m=initial(mode,seed);r=O.call(m,0x8ea0,x=0)
   value=(5*seed+17)&255
   assert m[0xdd]==value and m[7]==table[value>>3]
   assert m[0x2e]==100 and not any(m.ram[0x628:0x632])
   counts[m[7]]+=1
  assert counts==Counter({k:v*8 for k,v in expected.items()})
  rows.append(dict(source_F9=mode,seed_boundary_cases=256,kind_counts={f'{k:02X}':v for k,v in counts.items()}))
 checks['actual_selector_RNG']=dict(cases=512,LCG='DD=(5*DD+17)&255; index=DD>>3',conditional32entry_table=table.hex(),rows=rows,no_collection_or_spawn_by_selector=True)
 count=0
 for mode in[1,2]:
  for tile in range(128):
   for busy in[0,128]:
    for clock in[0,100,101,255]:
     m=initial(mode,0,clock);m.ram[0xd1]=busy;m.ram[0x204]=tile
     eligible=not(mem[0xa70f+tile]&16)and not busy and clock<=100
     r=O.call(m,0x8ea0,x=0)
     assert (m[0xdd]==17)==eligible
     assert m[7]==(table[2] if eligible else 0)
     count+=1
 checks['actual_terrain_script_clock_admission']=dict(cases=count,mode_pointer_8D86_or_8D94=True,both_first_thresholds_100=True,
  terrain_A70F_bit10_blocks=True,D1_negative_blocks=True,threshold_compares_source_clock_not_host_kill_chance=True)
 # Typed original scene record, real allocator and actual actor dispatcher.
 # There is no direct HP grant: selected reward remains in0646 behind the
 # genuine score popup/container path until a later physical source action.
 m=initial();O.call(m,0x8e35,x=0)
 assert m[0x628+9]==0x80 and m[0x646+9]==0x83 and m[0x632+9]>=10
 phases=[]
 for age in range(90):
  m.ram[0x26]=age&255;O.call(m,0x8edd)
  assert m[0x2e]==100
  if age in[0,23,24,86,87,89]:phases.append([age,m[0x628+9],m[0x632+9],m[0x63c+9],m[0x646+9]])
 assert m[0x628+9]==0x8a and m[0x646+9]==0x83
 checks['real_original_spawn_then_90_actor_updates']=dict(typed_map_record=[80,0,80,0,0],actual_allocated_slot=9,rows=phases,
  source_reward_kind_83_pending_not_collected=True,HP100_unchanged=True,not_enemy_defeat_or_native_campaign=True)
 # Real CPY #1 / BCS loop tests slot1 too: the initial eight-slot
 # assumption is preserved in the separate negative before correction.
 m=initial()
 for slot in range(2,10):m.ram[0x628+slot]=0x81
 O.call(m,0x8e35,x=0)
 assert m[0x628+1]==0x80 and m[0x646+1]==0x83 and m[0x2e]==100
 checks['actual_ninth_source_slot_fallback']=dict(occupied_slots=list(range(2,10)),actual_fallback_slot=1,reward_83_pending=True)
 m=initial()
 for slot in range(1,10):m.ram[0x628+slot]=0x81
 before=bytes(m.ram[0x600:0x650]);O.call(m,0x8e35,x=0)
 assert before==bytes(m.ram[0x600:0x650])
 checks['actual_full_source_actor_pool_declines']=dict(real_allocator_slots=list(range(1,10)),no_spawn_or_resource_credit=True)
 spans=[]
 for a,n,name in[(0x8ea0,0x3d,'terrain/script/clock eligibility and kind selection'),(0x99df,15,'original LCG'),(0x8d9f,32,'conditional reward kinds'),(0x8e35,0x6b,'real scene reveal/spawn'),(0x9103,0x50,'score popup timer/reward receipt'),(0x919d,0x35,'physical food collector and20/100 table')]:
  spans.append(dict(bank=0,address=f'{a:04X}',bytes=n,sha256=hashlib.sha256(mem[a:a+n]).hexdigest(),role=name))
 report=R/'docs/qa/dragon-power-drop-policy-2026-10-29.txt'
 report.write_text('''ORIGINAL SOURCE POLICY FACTS, NOT A HOST DROP IMPLEMENTATION OR NATIVE PASS.
The authenticated USA source does not support importing the existing SMB25% kill-drop rule as "DragonPower drop rate". Actual0:8EA0 admission depends on metatile property A70F bit10, sourceD1 sign, a F9-selected room threshold indexed by D0>>1, and sourceclock26. Only then original0:99DF advances DD=(5*DD+17)&255 and selects8D9F[DD>>3]. Exact 32-bin table has83x15,84x5,A3x6,93x2,86x2,85x2. Thus15/32 is only the conditional small-food-kind ratio after admission, not a per-SMB-enemy or uniform-time probability.512seed boundaries and2048terrain/script/clock boundaries execute actual original code, with F9=1/2 table-pointer boundary inputs; no claim these exhaust legal original rooms.
Original mature83sub0 gives20HP andsub1 gives100HP, cap150 absent explicit story upgrade. Existing authenticated source food controls already prove real collector/erase/cap; they do not establish all natural spawn rates.84is timed speed/protection,85pole variants,86wave kinds;93/A3 meanings and their complete source consumers are not yet established for a SMB side-view reward policy. Do not collapse them into food or renormalize supported outcomes silently.
Actual0:8E35 scene reveal carries selected kind in source0646, allocates one of source slots9..1, begins80score-popup, then actual90-update actor dispatcher reaches8Acontainer with83stillpending. HP remains100 throughout with player away; this is not immediate credit on an enemy defeat. Native physical contact/punch/reveal and later mature collection are distinct owners. Full nine-slot source pool declines without resource credit. The first eight-slot-pool assumption failed because actual CPY#1/BCS tests slot1; that negative is retained separately, and actual fallback-to1 plus fully occupied1..9 controls pass. No source item lifecycle or outcome was fabricated; original typed scene/player boundary inputs are explicit CPU-only fixtures.
Host proposal still needs approval/source closure: choose an explicit SMB event analogue for the source scene reveal, decide legal source room/script threshold mapping and RNG ownership, preserve unknown93/A3 outcomes until authenticated, provide real visible source food/other item records and exact native typed spawn/collision/refill ownership. Existing native4-slot drop arrays could be reused only after their entire draw/collector/owner lifecycle is audited. No new RAM/RNG byte, generic kill reward, health debit, physics or game edit is proposed as already valid. Until that policy closes, fb28 admission retains the measured raw24 no-drop result and the already-qualified genuine Mushroom food/pole and Flower wave mappings. Audio remains separate.
''')
 files=[Path(__file__),D.ROM,Path(O.__file__),Path(D.__file__),R/'build/dragon-power-source-v1/handoff.json',R/'build/dragon-power-component-v1/handoff.json',R/'build/dragon_power_drop_policy_fullpool_negative_v1.json',report]
 proof=dict(passed=True,source_original_CPU_only=True,native_run=False,host_drop_implementation=False,checks=checks,actual_source_spans=spans,bindings={str(p.resolve()):sha(p)for p in files},limits=report.read_text())
 output.write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(dict(output=str(output),sha256=sha(output),checks=list(checks))))
if __name__=='__main__':main()
