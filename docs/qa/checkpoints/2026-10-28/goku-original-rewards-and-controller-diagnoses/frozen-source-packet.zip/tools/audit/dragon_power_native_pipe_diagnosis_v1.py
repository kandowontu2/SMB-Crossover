"""Finite read-only native first-pipe diagnosis plus actual compiled Main arenas."""
from pathlib import Path
import csv,hashlib,json,sys
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import dragon_power_gameplay_controls_v1 as C
from sunny_integrated_controls_v1 import scoped_load,run,address,location,sha
O=R/'build/dragon-power-admission-v1'
N=R/'build/verification/dragon-power-admission-native-easy-v1'

def main():
 out=R/'build/dragon_power_native_pipe_diagnosis_v1.json';assert not out.exists()
 b=scoped_load(O/'candidate.nes');assert sha(O/'candidate.nes')=='fb28a741937ad5fb18d7f76f272874118c291dc0a575f69e15a2573436df500e'
 native=json.loads((N/'result.json').read_text())
 assert native['passed']is False and native['reason']=='finite frame bound'and native['frames']==7000 and native['zero_deaths']
 trace=list(csv.DictReader((N/'trace.csv').open()))
 window=[{k:int(r[k])for k in['frame','poll','loops','x','y','state','vy','mask']}for r in trace if 1729<=int(r['frame'])<=1780]
 key={r['frame']:r for r in window}
 assert [key[f]['y']for f in range(1730,1737)]==[172,168,164,160,156,152,148]
 assert key[1736]['mask']==129 and key[1736]['vy']==252
 assert key[1737]['mask']==193 and key[1737]['vy']==1 and key[1737]['y']==149
 assert key[1760]['y']==172 and key[1760]['vy']==252 and key[1761]['mask']==193 and key[1761]['y']==173 and key[1761]['vy']==1
 # Decode the actual compiled native1-1 columns. No hand-painted pipe or
 # approximation of tile solidity: actual parser supplies all13 rows.
 q=C.setup(b);q.put(AreaPointer=37,WorldNumber=0,Hidden1UpFlag=1);run(q,'GetAreaDataAddrs')
 for j in range(3):q.set('AreaObjectLength',255,j)
 cols=[]
 for col in range(32):
  run(q,'AreaParserCore');cols.append([q.get('MetatileBuffer',row)for row in range(13)]);run(q,'IncrementColumnPos')
 assert cols[28][9:11]==[0x12,0x14]and cols[29][9:11]==[0x13,0x15]
 arenas=[]
 for mode in[0,1]:
  for pulse in[False,True]:
   q=C.setup(b);q.put(CrossoverBehaviorVersion=mode)
   # Genuine mature actor collection before the typed pipe-boundary start;
   # no pole/tier/resource or tested outcome is seeded.
   C.actor(q,0,0x2e,96,176);q.set('PowerUpType',0,0);q.set('Enemy_State',128,0)
   pickup=False
   for age in range(65):
    q.put(SavedJoypadBits=0,NmiDisable=255,VRAM_Buffer1_Offset=0,FrameCounter=age)
    _,tr,_=C.M.runtrace(q,'GameLoop');pickup|=any(pc==address(b,'HandlePowerUpCollision')for bank,pc in tr)
   assert pickup and q.get('DpPole')==1 and q.get('DpPower')==1 and q.get('PlayerStatus')==1
   for x,col in enumerate(cols):
    for y,t in enumerate(col):q.m[address(b,'Block_Buffer_1')+(x//16)*208+y*16+x%16]=t
   q.put(Player_PageLoc=1,Player_X_Position=164,Player_Y_Position=176,Player_Rel_XPos=100,
    ScreenLeft_PageLoc=1,ScreenLeft_X_Pos=64,ScreenRight_PageLoc=2,ScreenRight_X_Pos=63,Player_Pos_ForScroll=100)
   rows=[];visited=set();costs=[];minimum=255
   for age in range(80):
    # Initiate the same accepted jump before introducing fresh airborne B.
    # A B pulse at0 instead starts a genuine ground attack and consumes the
    # later A attempt; that distinct oracle counterexample is retained.
    keys=1|(128 if age>=1 else 0)|(64 if pulse and age>=8 and age%8<2 else 0)
    q.put(SavedJoypadBits=keys,NmiDisable=255,VRAM_Buffer1_Offset=0,FrameCounter=age+65)
    cpu,tr,sp=C.M.runtrace(q,'GameLoop');visited.update(tr);costs.append(cpu.processorCycles);minimum=min(minimum,sp)
    rows.append([age,keys,q.get('Player_PageLoc')*256+q.get('Player_X_Position'),q.get('Player_Y_Position'),q.get('DpAction'),q.get('DpVertical'),list(q.m[address(b,'DpContacts'):address(b,'DpContacts')+7])])
   if pulse:
    assert min(r[3]for r in rows)==152 and max(r[2]for r in rows)<=433
    assert rows[7][3:6]==[152,3,237]and rows[8][3:6]==[153,10,0]
    assert (86,address(b,'DpNEA14'))in visited and any(r[6][3]or r[6][5]for r in rows)
   else:
    assert min(r[3]for r in rows)==116 and max(r[2]for r in rows)>=480
    assert (86,address(b,'DpNEA14'))not in visited and not any(r[6][6]for r in rows[:26])
    assert any(448<=r[2]<=479 and r[3]<=144 for r in rows)
   arenas.append(dict(mode=mode,policy='Right+A, first B at8 then B8pulse'if pulse else'Right then freshA, noB',
    real_mature_mushroom_before_boundary=True,typed_pipe_start=[420,176],actual_Main_updates=80,rows=rows,
    fields=['update','mask','worldX','playerY','DpAction','DpVertical','contacts0..6'],
    minimum_Y=min(r[3]for r in rows),maximum_X=max(r[2]for r in rows),CPU=[min(costs),max(costs)],min_SP=minimum))
 owned=[]
 for n in['DpNE9D6','DpNE9DA','DpNEA0C','DpNEA14','DpNEA16','DpNEA18','DpNEA1A','DpHostTileQuery','DpMovement','GameLoop']:
  at=location(b,n);owned.append(dict(symbol=n,PC=f'{address(b,n):04X}',physical_bank=(at-16)//8192,bytes=b['raw'][at:at+8].hex()))
 report=R/'docs/qa/dragon-power-native-pipe-diagnosis-2026-10-29.txt'
 text='''FB28 FIRST-PIPE NATIVE NEGATIVE: INPUT/SOURCE DIAGNOSIS, NO PRODUCT PATCH/NATIVE RETRY.
Original discovery remains FALSE finite7000-frame bound, no deaths; actual6938completeDMAs/6755IRQ+NMI checks,6897fullPPU,6972completed Main. Generic full_roster_policy_og is not a source-qualified Goku controller. Real mature Mushroom/power1 at1602 was logged. No DpAction/vertical-source-phase/head-contact values were captured natively, so source branch executions below must not be presented as native writer telemetry.
Native1730..1736 rises four pixels each update, Y172..148, vy252, mask129(Right+A). The first freshB pulse1737(mask193) coincides with vy1/Y149. The later tiny hop1760Y172/vy252 is followed by1761mask193/Y173/vy1; eight-poll pulses repeat. Actual original source E9D6 tests freshB during ascent, takes EA0C, stores Vertical0 atEA16 and action10 atEA1A, i.e. the intended air attack cancels ascent. This strongly trace-correlated source mechanism explains the borrowed controller failure; it does not certify every unlogged native contact or writer.
Four genuine fb28 complete-Main CPU arenas execute both modes, each with an actual mature Mushroom collection followed by65 Main updates and then a disclosed typed pipe-boundary start420/Y176. Native AreaParserCore supplies32 exact1-1 columns, including pipe12/13 at448..479/top176 and stems14/15. No painted terrain, motion/equipment/outcome seed, alternate physics, game edit or new allocation.80 Main updates per arena, actual original kernel/native camera/collision/render consumers. Right/freshA with noB reaches minimumY116 and crosses the pipe. Same accepted jump with first B at8 then every8updates reaches onlyY152, executes genuine EA14/EA16/action10 at8, and stalls atX431..433 with right-side contacts3/5. NoB ascent has headcontact6 zero. Initial expectation copied from the exploratory cold/no-pole arena failed when B was also introduced on ground0 after real earned-pole warmup: it starts ground attack4/5 before the later A attempt, so no jump occurs. That original tool/negative is retained; the final paired test explicitly introduces B only after the same real accepted jump. This is finite local source evidence, not a cold native traversal, exact native replay, all-obstacle safety, or an FPS claim.
Smallest next test is an input-only Goku controller: never B on jump initiation or during ascent; choose ground-only nearby-target attacks so freshB cannot truncate a necessary jump. Keep real source movement/release/air-attack mechanics unchanged, preserve all original death/frame/camera/hardware/capture guards and the original failed run. Root owns any new native launch. Source full-route hazards, source damage/hunger, drops, item/audio/render fidelity and final admission remain separately scoped.
'''
 report.write_text(text)
 files=[Path(__file__),Path(C.__file__),Path(C.M.__file__),R/'build/dragon_power_native_pipe_diagnosis_oracle_negative_v1.json',R/'tools/playthroughs/full_roster_policy_og.lua',R/'tools/audit/roster_expansion_cold_capture_v3.lua',O/'handoff.json',O/'candidate.nes',O/'candidate.dbg',O/'candidate.lbl',N/'result.json',N/'trace.csv',N/'inputs.csv',N/'events.jsonl',N/'run.lua',N/'ready.json',report]
 proof=dict(passed=True,diagnosis_not_route_qualification=True,original_native_passed=False,no_new_native=True,
  native_window=window,real_native_parser_columns=cols,source_CPU_arenas=arenas,genuine_instruction_metadata=owned,
  bindings={str(p.resolve()):sha(p)for p in files},limits=text)
 out.write_text(json.dumps(proof,indent=2)+'\n')
 print(json.dumps(dict(output=str(out),sha256=sha(out),report_sha256=sha(report),tool_sha256=sha(__file__))))

if __name__=='__main__':main()
