; PRIVATE new world-safe pattern lease, appended to the separate A121 object.
; Frozen core/art/functions remain unchanged; actual world1..5 stay native.
.include "world-imports.inc"
.export RdWpPublish,RdWpRender,RdWpDrawItems
.proc RdWpPublish
 lda CurrentCHRBank+7
 cmp #175                       ; compact authenticated physical687
 bne Changed
 lda X5ChrMode+7
 cmp #$82
 beq Active
Changed:lda #175
 sta CurrentCHRBank+7
 lda #$82
 sta X5ChrMode+7
 lda #1
 sta ReloadCHRBank
Active:lda #1
 sta X5WideChrActive
 rts
.endproc

; Genuine frozen renderer still owns admission/radii and returns recordX.
; The versioned one-page record has original8x8 part order/flags/pixels.
.proc RdWpRender
 WxFar RdRenderWeapon
 bcc Done
 cpx #54
 bcc No
 cpx #81
 bcs No
 txa
 sec
 sbc #54
 tax
 lda RdWpRecordLo,x
 sta R0
 lda RdWpRecordHi,x
 sta R1
 lda #<(.bank(RdWxAuxStart)|$80)
 sta CurrentBankC
 sta $5116                      ; real C121 data before the FIRST header read
 ldy #0
 lda (R0),y
 beq No
 sec
Done:rts
No:clc
 rts
.endproc

; Actual typed world objects are drawn at the completed DrawAll owner, not
; in update/NMI. Constructor and contact hooks remain separate transactions.
; Original512B root descriptors already use only first28pairs of page694.
.proc RdWpDrawItems
 php
 pha
 jsr WxEnabled
 jcc Foreign
 pla
 plp
 lda CurrentBankC
 pha
 lda ObjectOffset
 pha
 ldx #5
Loop:stx ObjectOffset
 lda Enemy_Flag,x
 cmp #1
 jne Next
 lda Enemy_ID,x
 cmp #$2e
 jne Next
 lda Enemy_State,x
 jeq Next
 lda InvPickupOwner,x
 cmp #2
 jne Next
 lda InvPickup,x
 sec
 sbc #$d0
 cmp #10
 jcs Next
 asl
 asl
 sta R0
 lda RdClock
 lsr
 and #3
 ora R0
 tay
 lda #<(.bank(RdWxAuxStart)|$80)
 sta CurrentBankC
 sta $5116
 lda RD_ITEM_LO_C,y
 sta R0
 lda RD_ITEM_HI_C,y
 sta R1
 lda CurrentCHRBank+6
 cmp #182                       ; authenticated physical694, one real page
 bne Publish
 lda X5ChrMode+6
 cmp #$82
 beq Published
Publish:lda #182
 sta CurrentCHRBank+6
 lda #$82
 sta X5ChrMode+6
 lda #1
 sta ReloadCHRBank
 sta X5WideChrActive
Published:
 lda Enemy_X_Position,x
 clc
 adc #8
 sta R4
 lda Enemy_PageLoc,x
 adc #0
 sta R5
 lda R4
 sec
 sbc ScreenLeft_X_Pos
 sta R4
 lda R5
 sbc ScreenLeft_PageLoc
 sta R5
 lda Enemy_Y_Position,x
 clc
 adc #8
 sta R6
 lda Enemy_Y_HighPos,x
 adc #0
 sta R7
 lda Enemy_SprAttrib,x
 and #$20                       ; actual emergence behind solid background
 sta R3
 WxFar MetaspriteRenderLoop
Next:ldx ObjectOffset
 dex
 jpl Loop
 pla
 sta ObjectOffset
 pla
 sta CurrentBankC
 sta $5116
 rts
Foreign:pla
 plp
 rts
.endproc
