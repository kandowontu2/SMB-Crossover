"""Explicit SMB palette-role adaptation; authentic masks/indices unchanged."""
from pathlib import Path
import json,re,sys
R=Path(__file__).resolve().parents[1];sys.path[:0]=[str(R/'tools'),str(R/'tools/audit')]
import rogue_dawn_map_v1 as ref
import prepare_rogue_dawn_weapon_world_art_v1 as compact
O=R/'build/rogue-dawn-palette0-art-v2'

def adapt(path,prefix):
 text=path.read_text();rows=[]
 def change(m):
  name=m[1];record=bytes(int(v.strip()[1:],16)for v in m[2].split(','));new=bytearray(record)
  assert record[0]==len(record)-1 and record[0]%4==0
  for i in range(2,len(record),4):new[i]&=252
  assert all(a==z for i,(a,z)in enumerate(zip(record,new))if i%4!=2)
  assert all((a&252)==z for i,(a,z)in enumerate(zip(record,new))if i%4==2)
  rows.append(dict(name=name,source_roles=list(record[2::4]),adapted_roles=list(new[2::4]),record_before=record.hex(),record_after=new.hex()))
  return name+':\n .byte '+','.join('$%02x'%v for v in new)
 text,n=re.subn(r'('+prefix+r'\d+):\n\s*\.byte ([^\n]+)',change,text)
 assert n==(27 if prefix=='RdWpRecord'else 40),(prefix,n)
 text='; SMB palette adaptation: ALL parts use body-owned palette0.\n; Authentic indices/geometry/order/flips/priority remain exact; source hues\n; and item hue cycling are NOT reproduced. Native palettes1..3 stay untouched.\n'+text
 return text,rows

def main():
 assert not(O/'handoff.json').exists(),'Frozen palette adaptation'
 p=R/'build/rogue-dawn-weapon-world-art-v1/proof.json';d=json.loads(p.read_text());assert d['passed']
 for z in d['bindings']+d['outputs']:assert ref.binding(z['path'])==z,z['path']
 O.mkdir(exist_ok=True);rows=[];outputs=[]
 for name,prefix in[('rogue_dawn_weapon_world_art','RdWpRecord'),('rogue_dawn_item_art','RdItemRecord')]:
  source=R/'src'/(name+'.inc');target=R/'src'/(name+'_palette0_v2.inc');text,records=adapt(source,prefix)
  if target.exists():assert target.read_text()==text
  else:target.write_text(text,newline='\n')
  rows+=records;outputs.append(ref.binding(target))
 # Complete mask semantics for all27 compact records. Only palette role
 # changes: color indices and actual priority mask are conserved.
 chrdata=(R/'chr/characters/rogue-dawn-weapon-world.chr').read_bytes()
 for row in rows[:27]:
  a=compact.decode(chrdata,bytes.fromhex(row['record_before']));z=compact.decode(chrdata,bytes.fromhex(row['record_after']))
  assert z=={xy:(v,attr&32)for xy,(v,attr)in a.items()}
 proof=dict(passed=True,source_only=True,native_run=False,scope='Approved explicit SMB palette-role adaptation; not original color fidelity',records=rows,weapon_records=27,item_records=40,CHR_changed=False,body_palette0_unchanged=True,world_palettes1_3_unchanged=True,item_source_flash_hue_cycling=False,bindings=[ref.binding(p)for p in[Path(__file__),p,R/'src/rogue_dawn_weapon_world_art.inc',R/'src/rogue_dawn_item_art.inc',R/'chr/characters/rogue-dawn-weapon-world.chr',R/'chr/characters/rogue-dawn-items.chr']],outputs=outputs)
 (O/'proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(dict(passed=True,weapon_records=27,item_records=40,outputs=outputs)))
if __name__=='__main__':main()
