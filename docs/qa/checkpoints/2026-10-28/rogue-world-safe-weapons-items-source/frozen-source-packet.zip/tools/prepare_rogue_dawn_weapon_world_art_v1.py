"""Authentic one-page Rogue weapons preserving native world CHR windows."""
from pathlib import Path
import json,sys
R=Path(__file__).resolve().parents[1];sys.path[:0]=[str(R/'tools'),str(R/'tools/audit')]
import prepare_rogue_dawn_art_v1 as art
import rogue_dawn_map_v1 as ref
from link_pit_rygar_sophia_audit_cpu import scoped_load
from check_tmnt_render_oa import location
O=R/'build/rogue-dawn-weapon-world-art-v1';OLD=R/'build/rogue-dawn-host-weapons-v1/candidate.nes'
INC=R/'src/rogue_dawn_weapon_world_art.inc';CHR=R/'chr/characters/rogue-dawn-weapon-world.chr'
def decode(data,record):
 pixels={}
 for i in reversed(range(1,len(record),4)):
  tile,attr,y,x=record[i:i+4];pair=(tile-193)//2;sy0=y-256 if y&128 else y;sx0=x-256 if x&128 else x
  assert tile&1 and 193<=tile<=255
  for yy in range(16):
   sy=15-yy if attr&128 else yy
   for xx in range(8):
    sx=7-xx if attr&64 else xx;at=pair*32+(sy//8)*16+sy%8
    v=((data[at]>>(7-sx))&1)|(((data[at+8]>>(7-sx))&1)<<1)
    if v:pixels[sx0+xx,sy0+1+yy]=(v,attr&35)
 return pixels
def main():
 assert not(O/'handoff.json').exists(),'Frozen recipe'
 raw=ref.ROM.read_bytes();assert ref.digest(raw)==ref.EXPECTED
 b=scoped_load(OLD);assert ref.digest(Path(OLD).read_bytes())=='56ee97b4cf86638b7f98049c5412521b153befc86a01e7eb591b42b8030e45fc'
 patterns=[];records={};rows=[]
 # The original native object decoder owns order, each8x8 tile and attributes.
 # One transparent lower tile preserves exact pixels with a declared 8x16
 # hardware scanline/admission difference; vertical flip shifts Y by minus8.
 for bank in[2,4,6,8,10]:
  for frame in art.WEAPON:
   for color in[0,129]:
    parts,*_=art.native_render(raw,frame,0,True,color,lower_bank=bank);rec=[]
    for y,t,a,x in parts:
     p=raw[16+524288+8*1024+t*16:16+524288+8*1024+(t+1)*16]+bytes(16)
     if p not in patterns:patterns.append(p)
     rec += [193+patterns.index(p)*2,a,(y-128-(8 if a&128 else 0))&255,(x-128)&255]
    record=bytes([len(rec)]+rec);assert len(patterns)<=32
    pixels=art.source_pixels(raw,parts);assert decode(b''.join(patterns)+bytes(1024-32*len(patterns)),record)==pixels,(bank,frame,color)
    key=(frame,color)
    if key in records:assert records[key]==record
    records[key]=record
    rows.append(dict(area=bank,frame=frame,color=color,original_parts=len(parts),new_host_parts=len(rec)//4,opaque_pixels=len(pixels),source_OAM=parts))
 data=b''.join(patterns)+bytes(1024-32*len(patterns));assert len(patterns)==15 and len(data)==1024
 # Reuse the actual original renderer's returned record index54..80 after
 # it has committed authentic radii; no inferred OAM cursor or fake alias.
 mapped={};lo,hi=[location(b,n)for n in['RdWeaponIndex0','RdWeaponIndex1']]
 for(frame,color),record in records.items():
  idx=b['raw'][(hi if color else lo)+frame];assert 54<=idx<=80
  if idx in mapped:assert mapped[idx]==record
  mapped[idx]=record
 assert set(mapped)==set(range(54,81))
 lines=['; Generated from pinned Rogue1.21 actual8x8 decoder; no invented art.','; Only host weapon descriptor topology/window changes; source radius/math stay frozen.','.pushseg','.segment "ROGUE_DAWN_HOST_AUX"','RdWpRecordLo:','.byte '+','.join('<(RdWpRecord'+str(i)+'+$2000)'for i in range(54,81)),'RdWpRecordHi:','.byte '+','.join('>(RdWpRecord'+str(i)+'+$2000)'for i in range(54,81))]
 for i,record in mapped.items():lines+=['RdWpRecord'+str(i)+':','.byte '+','.join('$%02x'%v for v in record)]
 lines+=['RdWpArtEnd:','.popseg']
 text='\n'.join(lines)+'\n'
 O.mkdir(exist_ok=True)
 if CHR.exists():assert CHR.read_bytes()==data
 else:CHR.write_bytes(data)
 if INC.exists():assert INC.read_text()==text
 else:INC.write_text(text,newline='\n')
 item=(R/'chr/characters/rogue-dawn-items.chr').read_bytes();assert len(item)==2048 and not any(item[1024:])and sum(any(item[i:i+32])for i in range(0,1024,32))==28
 proof=dict(passed=True,source_only=True,native_run=False,patterns=15,CHR_bytes=1024,weapon_window=7,weapon_physical_page=687,item_page=694,item_window=6,item_28_pairs_first1KB=True,item_second_page695_blank=True,source_cases=rows,record_bytes=sum(len(r)for r in mapped.values())+54,changes='Authentic source8x8 parts become one8x16 top+transparent each; Vflip partY minus8. Exact original complete pixel/priority/palette-index mask, actual OAM capacity/scanline/clipping still requires genuine host consumer controls.',outputs=[ref.binding(CHR),ref.binding(INC)],bindings=[ref.binding(p)for p in[Path(__file__),ref.ROM,OLD,OLD.with_suffix('.dbg'),R/'tools/prepare_rogue_dawn_art_v1.py',R/'chr/characters/rogue-dawn-items.chr',R/'build/rogue-dawn-item-art-v1/handoff.json']])
 (O/'proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(dict(passed=True,patterns=15,source_cases=len(rows),descriptor_bytes=proof['record_bytes'],CHR=ref.binding(CHR))))
if __name__=='__main__':main()
