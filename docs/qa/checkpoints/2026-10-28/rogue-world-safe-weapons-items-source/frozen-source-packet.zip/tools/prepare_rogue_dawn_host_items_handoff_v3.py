"""Freeze compact geometry/progression unit with genuine compile closure."""
from pathlib import Path
import argparse,json,subprocess,sys
R=Path(__file__).resolve().parents[1];sys.path[:0]=[str(R/'tools'),str(R/'tools/audit')]
import rogue_dawn_host_weapons_controls_v1 as w
import prepare_rogue_dawn_host_body_handoff_v1 as closure
from check_tmnt_render_oa import address,location
from check_tmnt_audio_fallback_oc import qualified
O=R/'build/rogue-dawn-host-items-worldcoords-v3';P=w.O

def main():
 parser=argparse.ArgumentParser();parser.add_argument('--palette0',action='store_true');args=parser.parse_args()
 global O
 if args.palette0:O=R/'build/rogue-dawn-host-items-worldcoords-v3'
 assert not(O/'handoff.json').exists(),'Frozen unit'
 build=json.loads((O/'build.json').read_text());checks={n:json.loads((O/n).read_text())for n in['controls.json','render-controls.json','progression-controls.json','item-edge-controls.json','world-controls.json','ordinary-controls.json','palette0-coordinate-controls.json']}
 for data in[build,*checks.values()]:
  assert data['passed']
  if 'ROM'in data:assert data['ROM']['sha256']==build['ROM']['sha256']
  for z in data['bindings']:assert w.ref.binding(z['path'])==z,z['path']
 b=w.life.d.old.scoped_load(O/'candidate.nes');old=w.life.d.old.scoped_load(P/'candidate.nes');a,z=old['raw'],b['raw'];allowed=set();hook=[]
 spans=[(0x1810,18,'actual PowerUpObjHandler collision target'),(location(old,'DrawPowerUp')+2,18,'actual DrawPowerUp private-art target'),(location(old,'HandlePowerUpCollision'),18,'actual native pickup contact target'),(location(old,'RdNrPrepare')+18,18,'actual constructor target')]
 spans += [(location(old,n)+3,3,n+' lifecycle delivery-sync target')for n in['RdBodyNewSession','RdBodyNewLife','RdBodyEnterScene']]
 for at,size,name in spans:
  allowed.update(range(at,at+size));hook.append(dict(name=name,file_offset=at,bytes=size,before=a[at:at+size].hex(),after=z[at:at+size].hex()))
 for bank,lo,hi in[(95,0xbcbf,0xbf00),(121,0xad60,0xbe00 if not args.palette0 else 0xc000)]:allowed.update(range(16+bank*8192+(lo&8191),16+bank*8192+(hi&8191 or 8192)))
 allowed.update(range(16+1048576+687*1024,16+1048576+688*1024))
 diff=[i for i,(x,y)in enumerate(zip(a,z))if x!=y];assert len(a)==len(z)and all(i in allowed for i in diff),[(i,(i-16)//8192)for i in diff if i not in allowed][:10]
 frozen=json.loads((P/'build.json').read_text())['literal_frozen_spans'];literal=[]
 for q in frozen:
  at=16+q['bank']*8192+(int(q['PC'],16)&8191);data=z[at:at+q['bytes']]
  assert w.ref.digest(data)==q['sha256'];literal.append(q)
 assert z[16+121*8192:16+121*8192+0xd60]==a[16+121*8192:16+121*8192+0xd60]
 before,after=qualified(P/'candidate.nes'),qualified(O/'candidate.nes');moved={k:(v,after.get(k))for k,v in before.items()if after.get(k)!=v};permitted=[]
 for key,values in moved.items():
  name='::'.join(key)
  # Newly owned weapon A121 APIs are genuinely relinked. All frozen original
  # control/body/bridge/public foreign PCs and RAM remain fixed.
  s=old['syms'].get(name);is_aux=bool(s and 'seg'in s and int(old['segs'][s['seg']]['bank'],0)==121)if s and 'seg'in s and 'bank'in old['segs'][s['seg']]else False
  if not is_aux and s and 'seg'in s:is_aux=(location(old,name)-16)//8192==121
  assert is_aux or name in['farcall_count','__ROGUE_DAWN_HOST_AUX_SIZE__'],(name,values)
  permitted.append(dict(name=name,before=values[0],after=values[1]))
 cmd=[str(R/'tools/Windows/cc65/bin/cc65.exe'),'--cpu','6502x','-t','nes','-g','-Oisr','-T','-I',str(R),'--create-full-dep',str(O/'c-full.dep'),'-o',str(O/'c-closure.s')]
 for i,v in enumerate(build['commands'][1]):
  if v=='-D':cmd+=['-D',build['commands'][1][i+1]]
 cmd+=[str(O/'main.c')];p=subprocess.run(cmd,cwd=R,capture_output=True,text=True);(O/'c-closure.log').write_text(p.stdout+p.stderr);assert p.returncode==0,p.stdout+p.stderr
 adeps=list(dict.fromkeys(closure.dependencies(O/'assembler-full.dep')+closure.dependencies(O/'weapon-object.dep')));cdeps=closure.dependencies(O/'c-full.dep');assert len(adeps)==build['actual_ASM_inputs']and len(cdeps)==10
 perbank={}
 for i in diff:
  key='CHR687'if i>=16+1048576 else'PRG'+str((i-16)//8192);perbank[key]=perbank.get(key,0)+1
 edge=checks['item-edge-controls.json']['checks'];render=checks['render-controls.json']['checks'];source=checks['controls.json']['checks'];progress=checks['progression-controls.json']['checks']
 report=R/'docs/qa'/('rogue-dawn-host-items-world-safe-source-2026-10-28.json'if args.palette0 else'rogue-dawn-host-items-precolor-source-2026-10-28.json')
 summary=dict(status='PRIVATE source-qualified geometry/ownership/progression component; NOT native/playable admission',native_run=False,ROM=build['ROM'],parent=build['parent'],preserved_HOLD56ee=w.ref.binding(P/'handoff.json'),source_ROM=w.ref.binding(w.ref.ROM),layout=dict(body_window0='680..686 source poses;689 authentic death',world_windows1_5='Native shadow/modes and actual X5PublishChr routes preserved, including SsChrActive/upper override',weapon_window7='Authentic15 source8x8 patterns; page687,1024B; top+transparent pairs/VflipYminus8',item_window6='Authenticated28pairs page694;page695 remains zero',A95_end=build['A95_new_end'],A95_free_to_death=0xbf00-int(build['A95_new_end'],16),A121_code_art_end=build['A121_code_and_art_end'],A121_free_to_items=0xbe00-int(build['A121_code_and_art_end'],16),item_tail='Root authenticated512B geometry/table BE00..BFFF, approved palette-role0 adaptation',new_RAM=0),
  authentic_shape='All source indices/geometry/order/flips/priority retained; actual full-visible pixel masks checked before hardware8-sprite clipping',palette=('Approved NES adaptation: all item/Ice/normal weapon parts use existing body-owned palette0; no new body colors. Original source roles and hue cycling are not color-fidelity claims.'if args.palette0 else'OPEN: exact source palette roles0..3 preserved in this precolor unit; NOT safe final colors. Publishing source1..3 would recolor native world actors; packet held from playable admission.'),
  progression='Explicit approved SMB adaptation. Native raw0 becomes tank; first raw1 missileTank, next8 authentic missing gear, then missile refill. Actor carries actual saved rawtype and stationary Flower physics. Real native state1->128 emergence precedes physical contact; only that owner grants, erases once, scores1000/SFX. PlayerStatus0/1 derives earned resources solely for next block delivery, never HP/geometry. Fresh clears; life/scene derives after actual source reset. Star/1Up keep genuine native consumer.',
  actual_emergence=dict(reward_cases=len(progress['complete_native_constructor_emergence_physical_contact_next_constructor']),modes=[0,1],timeline='Full native IdleLoop/Main/NMI calls; no source resources/maturity/collection outcome seeds. Staged legal scene and actual native constructor boundary; not a natural bump/native acquisition claim.'),
  render_checks=render,edge_checks=edge,weapon_source_checks=source,world_checks=checks['world-controls.json'],minimum_SP=min(d.get('minimum_SP',255)for d in checks.values()),
  costs=dict(foreign_empty_Main_added_CPU_vs56ee=sorted(set(r['CPU_delta']for r in edge['all_foreign_complete_Main_AXYP_application_ordered_writes_banks'])),foreign_active_pickup_handler_added_CPU_vs56ee=sorted(set(r['CPU_delta']for r in edge['all_foreign_actual_mature_powerup_draw_collision_caller'])),prior='Frozen56ee adds230..490 foreign fullMain vs lifecycle, prior lifecycle separately342..519 vs body; not an aggregate measured union. Final exact-owner routing/performance still required.'),
  hardware_limits='New topology intentionally changes part counts0/1/2/4/6/12 and admission versus held2KB packing. Whole-record offset+header>=256 rejects. Transparent8x16 halves consume scanline slots. No universal visibility, completed native DMA/PPU/deadline/audio/FPS claim.',literal_frozen_spans=literal,actual_old_hook_preimages=hook,relocated_owned_A121_symbols=permitted,per_bank_changed_bytes=perbank,actual_ASM_incbin_inputs=len(adeps),actual_C_inputs=len(cdeps),actual_C_command=cmd,
  ordinary=[dict(mapper=q['mapper'],ROM=q['ROM'])for q in checks['ordinary-controls.json']['rows']],retained_negatives=['Held56ee actual source Main Goomba OAM tileA2/A4 routes through overwritten window2 weapon687 instead of native enemy physical17; no native run/product image claim','Earlier source fixture head-only invisible60 used as standing support corrected to real usedblockC4 at source-aligned X128; actual 68-update rise/contact now retained','Native1Up is paid by real popup timer48->43 path, not pickup entry; controls preserve that source timing'],
  remaining=['Native/menu admission plus actual physical all256DMA/PPUMASK/CHR/fullPPU visual/audio proof','Typed drop birth/collection and hazards/boss/unlisted actor classes','Final exact-owner wrapper composition/routing cost/stack review','Authentic audio driver bridge, world item announcements and reachable native earned gear testing'])
 summary['approved_palette_and_coordinate_delta']=checks['palette0-coordinate-controls.json']
 summary['source_alignment']='Root packed item offsets already encode center=ActorTopLeft+8; actual caller uses ActorTopLeft as reference. Two ADC operands8->0 preserve every publicPC and exactly align all40 original masks across240 page/camera/Y cases.'
 summary['precolor_and_color_only_negatives']=[w.ref.binding(R/'build/rogue-dawn-host-items-v1/handoff.json'),w.ref.binding(R/'build/rogue-dawn-host-items-palette0-v2/color-only-freeze.json')]
 topology=[]
 for frame in w.art.WEAPON:
  for color in[0,129]:
   row=dict(frame=frame,color=color)
   for label,bundle,entry in[('held56ee',old,'RdRenderWeapon'),('new',b,'RdWpRender')]:
    m=w.life.make(bundle);w.shot(m,frame=frame,wx=128,y=128);put=w.put;put(m,RdWeaponColor=color)
    c,_,_=w.call(m,entry);ptr=w.get(m,'R0')+256*w.get(m,'R1');header=m[ptr]if c.p&1 else 0
    row[label+'_parts']=header//4
    for off in[220,244]:
     m=w.life.make(bundle);w.shot(m,frame=frame,wx=128,y=128);w.field(m,'SmBombBlocksDone',color);put(m,CurrentOAMOffset=off)
     w.call(m,'RdWxDraw');row[label+'_cursor_from_'+str(off)]=w.get(m,'CurrentOAMOffset')
   topology.append(row)
 summary['actual_controlled_old_new_OAM_topology_and_admission']=topology
 summary['capacity_negative']='Exact source8x8 top+transparent conversion can cost more OAM than held2KB repacking: frame77 explosion12 vs old4 parts; atcursor220 new whole record rejects while held admits. This is explicit capacity/flicker scope, not a claim all effect pixels remain visible.'
 report.write_text(json.dumps(summary,indent=2)+'\n')
 generated=[p for p in O.iterdir()if p.suffix in['.s','.c','.inc','.cfg','.dep','.patch','.json']and p.name not in['handoff.json']]
 own=[R/'src'/n for n in['rogue_dawn_host_items.s','rogue_dawn_host_items_gate.s','rogue_dawn_host_weapon_world.s']]+[R/'tools'/n for n in['prepare_rogue_dawn_host_items_v1.py','rogue_dawn_host_items_render_controls_v1.py','rogue_dawn_host_items_progression_controls_v1.py','rogue_dawn_host_items_edges_v1.py','prepare_rogue_dawn_host_items_handoff_v1.py','prepare_rogue_dawn_host_items_v2.py','prepare_rogue_dawn_host_items_v3.py','prepare_rogue_dawn_host_items_handoff_v3.py','prepare_rogue_dawn_palette0_art_v2.py','prepare_rogue_dawn_weapon_world_art_v1.py','rogue_dawn_host_items_render_controls_v2.py','rogue_dawn_host_items_render_controls_v3.py','rogue_dawn_host_items_palette0_controls_v2.py','rogue_dawn_host_items_palette0_coordinate_controls_v3.py']]+[report]+generated
 own += [R/'src/rogue_dawn_weapon_world_art.inc',R/'src/rogue_dawn_weapon_world_art_palette0_v2.inc',R/'src/rogue_dawn_item_art_palette0_v2.inc',R/'chr/characters/rogue-dawn-weapon-world.chr',R/'build/rogue-dawn-weapon-world-art-v1/proof.json',R/'build/rogue-dawn-palette0-art-v2/proof.json',R/'build/rogue-dawn-host-items-palette0-v2/color-only-freeze.json']
 paths=adeps+cdeps+own+[Path(q['path'])for data in[build,*checks.values()]for q in data['bindings']]+[O/'candidate.nes',O/'candidate.dbg',O/'candidate.lbl',O/'candidate.map',O/'weapon-object.o',R/'tools/Windows/cc65/bin/cc65.exe',R/'tools/Windows/cc65/lib/nes.lib']
 packet=dict(passed=True,source_only=True,native_run=False,playable_admission=False,ROM_sha256=build['ROM']['sha256'],report=w.ref.binding(report),bindings=[w.ref.binding(p)for p in dict.fromkeys(paths)],owned_publication_files=[w.ref.binding(p)for p in dict.fromkeys(own)])
 (O/'handoff.json').write_text(json.dumps(packet,indent=2)+'\n');print(json.dumps(dict(ROM=build['ROM']['sha256'],report=w.ref.digest(report.read_bytes()),handoff=w.ref.digest((O/'handoff.json').read_bytes()),bindings=len(packet['bindings']),owned=len(packet['owned_publication_files']))))
if __name__=='__main__':main()
