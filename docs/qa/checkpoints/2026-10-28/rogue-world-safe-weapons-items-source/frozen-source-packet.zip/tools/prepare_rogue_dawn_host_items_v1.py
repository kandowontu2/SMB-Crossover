"""Private world-safe weapon patterns plus real typed pickup transactions."""
from pathlib import Path
import difflib,json,re,subprocess,sys
R=Path(__file__).resolve().parents[1];sys.path[:0]=[str(R/'tools'),str(R/'tools/audit')]
import rogue_dawn_map_v1 as ref
import prepare_rogue_dawn_host_body_handoff_v1 as closure
from link_pit_rygar_sophia_audit_cpu import scoped_load
from check_tmnt_render_oa import address,location
from prepare_cv3_dmc_mirror import prepare
P=R/'build/rogue-dawn-host-weapons-v1';O=R/'build/rogue-dawn-host-items-v1'
def once(s,a,z):assert s.count(a)==1,(a,s.count(a));return s.replace(a,z)
def main():
 assert not(O/'handoff.json').exists(),'Frozen item successor'
 parent=json.loads((P/'handoff.json').read_text())
 for z in parent['bindings']:assert ref.binding(z['path'])==z,z['path']
 asset=R/'build/rogue-dawn-weapon-world-art-v1/proof.json';d=json.loads(asset.read_text());assert d['passed']
 for z in d['bindings']+d['outputs']:assert ref.binding(z['path'])==z,z['path']
 O.mkdir(exist_ok=True)
 build=json.loads((P/'build.json').read_text());b=scoped_load(P/'candidate.nes');changes={}
 for z in parent['owned_publication_files']:
  p=Path(z['path'])
  if p.parent==P and p.suffix in['.s','.c','.cfg','.inc']:(O/p.name).write_bytes(p.read_bytes())
 for n in['sprite_render.s']:(O/n).write_bytes((R/'src'/n).read_bytes())
 for own,staged in[('rogue_dawn_host_body.s','body-source.s'),('rogue_dawn_host_integration.s','integration-source.s'),('rogue_dawn_host_weapons.s','weapon-source.s')]:
  (O/staged).write_bytes((R/'src'/own).read_bytes())
 def edit(n,f):
  p=O/n;a=p.read_text();z=f(a);assert a!=z,n;p.write_text(z,newline='\n');changes[n]=(changes[n][0]if n in changes else a,z)
 edit('body-source.s',lambda s:s.replace('jmp RdBodyLifecycleDirty','jmp RdItSyncLifecycle')if s.count('jmp RdBodyLifecycleDirty')==3 else once(s,'invalid','invalid'))
 edit('integration-source.s',lambda s:once(s,'farcall RdTxPrepareActor,jmp','farcall RdItPrepare,jmp'))
 def weapon(s):
  start=s.index(' ; Source7/8 fixed weapon atlas');end=s.index('Published:\n',start)+len('Published:\n')
  s=s[:start]+' jsr RdWpPublish\n'+s[end:]
  return once(s,'WxFar RdRenderWeapon','jsr RdWpRender')
 edit('weapon-source.s',weapon)
 def gate(s,old,new):
  assert s.count('farcall '+old)==1,(old,s.count('farcall '+old))
  return re.sub('farcall '+old+r'(,\s*jmp)?',lambda m:'.if ::ENABLE_MMC5_EXPANDED\n farcall '+new+(m[1]or'')+'\n.else\n farcall '+old+(m[1]or'')+'\n.endif',s)
 edit('collision.s',lambda s:gate(s,'NrPickup','RdItPickup'))
 edit('object.s',lambda s:gate(s,'NrPickupCollision','RdItCollision'))
 edit('sprite_render.s',lambda s:gate(s,'LmPrivateGate','RdItPrivate'))
 # Retain original DrawAll owner then append actual typed world-item draw.
 # Both targets are in the same real separate A121 object, so no extra banktrip.
 edit('weapon-source.s',lambda s:once(s,' sta $5116\n rts\nForeign:pla',' sta $5116\n jmp RdWpDrawItems\nForeign:pla'))
 def entry(s):
  s=s.replace(str(P),str(O))
  s=once(s,'.include "rogue_dawn_host_body.s"','.include "body-source.s"')
  s=once(s,'.include "rogue_dawn_host_integration.s"','.include "integration-source.s"')
  s=once(s,'.include "rogue_dawn_host_weapons_gate.s"','.include "rogue_dawn_host_weapons_gate.s"\n.include "rogue_dawn_host_items_gate.s"')
  s=once(s,'.incbin "chr/characters/rogue-dawn.chr",0,9*1024','.incbin "chr/characters/rogue-dawn.chr",0,7*1024\n.incbin "chr/characters/rogue-dawn-weapon-world.chr"\n.incbin "chr/characters/rogue-dawn.chr",8*1024,1024')
  return s
 edit('entrypoint.s',entry)
 sources=['rogue_dawn_host_items.s','rogue_dawn_host_weapon_world.s'];text='\n'.join((R/'src'/n).read_text()for n in sources)
 code='\n'.join(line.split(';',1)[0]for line in text.splitlines());code=re.sub(r'"[^"\n]*"','',code)
 # Every include below is assembled in ONE genuine object. Names defined by
 # preceding weapon code or later asset tables are local definitions, never
 # imports from the main object (even when the parent DBG exports the name).
 object_text='\n'.join((p.read_text())for p in [O/'weapon-source.s',*[R/'src'/n for n in sources],R/'src/rogue_dawn_weapon_world_art.inc',R/'src/rogue_dawn_item_art.inc'])
 object_code='\n'.join(line.split(';',1)[0]for line in object_text.splitlines())
 local=set(re.findall(r'(?m)^\s*(\w+)\s*:',object_code))|set(re.findall(r'\.proc\s+(\w+)',object_code))|set(re.findall(r'(?m)^\s*(\w+)\s*=',object_code))
 imports=set(re.findall(r'\.import(?:zp)?\s+(\w+)',(O/'weapon-imports.inc').read_text()))
 external=sorted((set(re.findall(r'\b[A-Za-z_]\w*\b',code))&set(b['syms']))-local-imports-{'RdWxAuxStart'})
 new_main=['RdItSyncStatus'];header=['.import '+n for n in new_main]
 for n in external:header.append(('.importzp 'if b['syms'][n]['addrsize']=='zeropage'else'.import ')+n)
 (O/'item-imports.inc').write_text('\n'.join(header)+'\n',newline='\n');(O/'world-imports.inc').write_text('; Imports already declared by preceding weapon/item headers.\n',newline='\n')
 publics=sorted(set(n.strip()for line in re.findall(r'\.export ([^\n]+)',text)for n in line.split(',')))
 e=O/'entrypoint.s';e.write_text(e.read_text()+'\n.if ::ENABLE_MMC5_EXPANDED\n'+''.join('.export '+n+'\n'for n in external+new_main)+''.join('.import '+n+'\n'for n in publics)+'.endif\n',newline='\n')
 aux=O/'weapon-object.s';aux.write_text('.include "weapon-source.s"\n.include "rogue_dawn_host_items.s"\n.include "rogue_dawn_host_weapon_world.s"\n.include "rogue_dawn_weapon_world_art.inc"\n.include "rogue_dawn_item_art.inc"\n',newline='\n')
 cmds=[[v.replace(str(P),str(O))for v in cmd]for cmd in build['commands']]
 for cmd,log in zip(cmds,['weapon-object.log','build.log']):
  z=subprocess.run(cmd,cwd=R,capture_output=True,text=True);(O/log).write_text(z.stdout+z.stderr);assert z.returncode==0,(z.stdout+z.stderr)[-4000:]
 prepare(R,O/'candidate.nes');n=scoped_load(O/'candidate.nes')
 assert address(n,'RdItGateEnd')<=0xbf00 and address(n,'RdWpArtEnd')<=0xbe00
 deps=list(dict.fromkeys(closure.dependencies(O/'assembler-full.dep')+closure.dependencies(O/'weapon-object.dep')))
 patch=O/'source.patch';patch.write_text(''.join(''.join(difflib.unified_diff(a.splitlines(True),z.splitlines(True),fromfile='56ee/'+name,tofile='private/'+name))for name,(a,z)in changes.items()),newline='\n')
 extras=[Path(__file__),P/'handoff.json',asset,O/'private.cfg',O/'weapon-imports.inc',O/'item-imports.inc',O/'world-imports.inc',aux,patch,O/'candidate.nes',O/'candidate.dbg',O/'candidate.lbl',O/'candidate.map',R/'src/rogue_dawn_host_items_gate.s',*[R/'src'/s for s in sources]]
 result=dict(passed=True,source_build_only=True,native_run=False,qualified=False,playable_admission=False,ROM=ref.binding(O/'candidate.nes'),parent=ref.binding(P/'candidate.nes'),commands=cmds,actual_ASM_inputs=len(deps),A95_new_end=hex(address(n,'RdItGateEnd')),A121_code_and_art_end=hex(address(n,'RdWpArtEnd')),bindings=[ref.binding(p)for p in dict.fromkeys(deps+extras)],open=['Unqualified private build until actual owner/source/pixel/capacity/lifecycle/IRQ/ordinary controls complete','Ice palette and all-part item palette lease','Typed drop/hazard/boss/audio/menu/native admission'])
 (O/'build.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:result[k]for k in['ROM','actual_ASM_inputs','A95_new_end','A121_code_and_art_end']}))
if __name__=='__main__':main()
