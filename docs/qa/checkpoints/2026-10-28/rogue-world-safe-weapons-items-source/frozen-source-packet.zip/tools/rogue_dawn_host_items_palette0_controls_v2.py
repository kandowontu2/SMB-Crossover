"""Exact descriptor-only role delta and actual combined Main equivalence."""
from pathlib import Path
import itertools,json,sys,traceback
R=Path(__file__).resolve().parents[1];sys.path[:0]=[str(R/'tools'),str(R/'tools/audit')]
import rogue_dawn_host_weapons_controls_v1 as w
from check_tmnt_render_oa import address,location
from check_tmnt_audio_fallback_oc import qualified
from verify_native_relocation import NesMPU
from sunny_integrated_controls_v1 import app,registers,cleanwrites
P=R/'build/rogue-dawn-host-items-v1';O=R/'build/rogue-dawn-host-items-palette0-v2';get,put,call=w.get,w.put,w.call

def main():
 old=w.life.d.old.scoped_load(P/'candidate.nes');b=w.life.d.old.scoped_load(O/'candidate.nes');asset=json.loads((R/'build/rogue-dawn-palette0-art-v2/proof.json').read_text());checks={};low=255
 proof=dict(passed=False,source_CPU_only=True,native_run=False,ROM=w.ref.binding(O/'candidate.nes'),checks=checks)
 try:
  allowed=set()
  for row in asset['records']:
   at=location(b,row['name']);before=bytes.fromhex(row['record_before']);after=bytes.fromhex(row['record_after'])
   assert old['raw'][at:at+len(before)]==before and b['raw'][at:at+len(after)]==after
   allowed.update(at+i for i in range(2,len(after),4))
  changed=[i for i,(a,z)in enumerate(zip(old['raw'],b['raw']))if a!=z]
  assert changed and set(changed)<=allowed and all((old['raw'][i]&252)==b['raw'][i]for i in changed)
  assert qualified(P/'candidate.nes')==qualified(O/'candidate.nes')
  checks['exact_compiled_descriptor_palette_bits_only']=dict(changed_bytes=len(changed),physical_bank=121,records=67,CHR_all_bytes_exact=True,all_compiled_PC_RAM_symbols_exact=True,no_runtime_instruction_change=True)
  rows=[]
  for kind,phase,gear,face in itertools.product(range(10),range(4),[0,128],[0,1]):
   pair=[]
   for bundle in[old,b]:
    m=w.life.make(bundle);call(m,'X5ColdInit');m[0x5fee]=1
    put(m,RdGear=gear,RdFacing=face,RdClock=phase*2)
    w.target(m,6,wx=168,y=176);w.shot(m,action=3 if gear else 1,frame=105 if gear else 40,wx=100,y=120)
    for n,v in [('Enemy_Flag',1),('Enemy_ID',46),('Enemy_State',128),('InvPickupOwner',2),('InvPickup',208+kind),('PowerUpType',1),('Enemy_X_Position',200),('Enemy_PageLoc',0),('Enemy_Y_Position',128),('Enemy_Y_HighPos',1)]:w.field(m,n,v,5)
    permitted=set();oldstep=NesMPU.step
    def step(c):
     bank=m.banks[(c.pc-32768)//8192]if c.pc>=32768 else-1
     if c.pc==address(bundle,'MetaspriteRenderLoop')and bank==(location(bundle,'MetaspriteRenderLoop')-16)//8192 and m.banks[2]==121:
      ptr=get(m,'R0')+256*get(m,'R1');count=m[ptr];off=get(m,'CurrentOAMOffset');rotation=get(m,'RgOamRotation')if get(m,'GuestOamRotationActive')else 0
      if count and count+off<256:permitted.update(address(bundle,'Sprite_Data')+((off+rotation+j+2)&255)for j in range(0,count,4))
     oldstep(c)
    NesMPU.step=step
    try:c,row=w.life.mainstep(m,first=True)
    finally:NesMPU.step=oldstep
    low=min(low,row['minimum_SP'])
    class Q:pass
    q=Q();q.m=m;q.b=bundle
    pair.append((q,c,permitted,list(m.writes),row))
   a,z=pair;assert a[2]==z[2]and a[2]
   assert registers(a[1])==registers(z[1])and a[0].m.banks==z[0].m.banks and a[1].processorCycles==z[1].processorCycles
   assert app(a[0],skip=a[2])==app(z[0],skip=z[2])
   wa,wz=cleanwrites(a[0],a[3]),cleanwrites(z[0],z[3]);assert len(wa)==len(wz)
   delta=[]
   for (at,v),(zt,zv)in zip(wa,wz):
    assert at==zt
    if v!=zv:
     assert at in a[2]and(v&252)==zv,(kind,phase,gear,face,hex(at),v,zv)
     delta.append(at)
   rows.append(dict(item=kind,phase=phase,gear=gear,face=face,actual_qualified_Rogue_attr_addresses=sorted(a[2]),changed_attribute_writes=len(delta),CPU_delta=0,minimum_SP=min(a[4]['minimum_SP'],z[4]['minimum_SP'])))
  checks['actual_combined_Main_body_world_items_weapons_only_Rogue_palette_role_delta']=dict(cases=len(rows),case_SHA256=w.ref.digest(json.dumps(rows).encode()),CPU_delta=0,minimum_SP=low,actual_attribute_write_differences=sum(z['changed_attribute_writes']for z in rows),world_PPU_palette_writes_unchanged=True)
  proof.update(passed=True,minimum_SP=low,limits=['CPU source projection and ordered bus writes only; no native hardware fetch, completed DMA, PPU display, deadline/FPS/audio claim.','All parts use existing dynamic body palette0. Original source color indices/masks remain; original hues and item hue cycling are intentionally adapted.','Actual8-sprite scanline/8x16 empty-half and total OAM capacity limits remain, as do late epoch/native art review obligations.'])
 except BaseException as e:proof.update(error=str(e),traceback=traceback.format_exc());raise
 finally:
  proof['bindings']=[w.ref.binding(p)for p in[Path(__file__),O/'build.json',O/'candidate.nes',O/'candidate.dbg',P/'handoff.json',R/'build/rogue-dawn-palette0-art-v2/proof.json']]
  (O/'palette0-controls.json').write_text(json.dumps(proof,indent=2)+'\n')
 print(json.dumps(dict(passed=True,changed_bytes=len(changed),actual_Main_cases=len(rows),minimum_SP=low)))
if __name__=='__main__':main()
