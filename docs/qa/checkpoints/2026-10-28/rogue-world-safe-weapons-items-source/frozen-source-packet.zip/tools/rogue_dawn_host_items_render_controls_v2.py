"""Actual private renderer/CHR contracts. CPU evidence, never native PPU."""
from pathlib import Path
import itertools,json,sys,traceback
R=Path(__file__).resolve().parents[1];sys.path[:0]=[str(R/'tools'),str(R/'tools/audit')]
import rogue_dawn_host_weapons_controls_v1 as w
import prepare_rogue_dawn_art_v1 as art
from check_tmnt_render_oa import address,location
from verify_native_relocation import NesMPU
O=R/'build/rogue-dawn-host-items-palette0-v2';get,put,call=w.get,w.put,w.call

def record(b,ptr):
 at=16+121*8192+ptr-0xc000
 return b['raw'][at:at+1+b['raw'][at]]

def pixels(raw,oam,physical,origin=(128,128),clipped=False):
 out={};base=16+1048576+physical*1024
 for y,t,a,x in reversed(oam):
  if y>=240:continue
  for yy in range(16):
   sy=15-yy if a&128 else yy
   for xx in range(8):
    sx=7-xx if a&64 else xx;z=base+(t&62)*16+sy//8*16+sy%8
    v=((raw[z]>>(7-sx))&1)|(((raw[z+8]>>(7-sx))&1)<<1)
    if v and (not clipped or x+xx<256 and y+1+yy<240):out[x+xx-origin[0],y+1+yy-origin[1]]=(v,a&35)
 return out

def main():
 b=w.life.d.old.scoped_load(O/'candidate.nes');old=w.life.d.old.scoped_load(w.O/'candidate.nes');checks={};low=255
 proof=dict(passed=False,source_CPU_only=True,native_run=False,ROM=w.ref.binding(O/'candidate.nes'),checks=checks)
 try:
  rows=[];raw=w.ref.ROM.read_bytes()
  for frame,color,offset,rot,center in itertools.product(art.WEAPON,[0,129],[0,220,244],[0,128],[(128,128),(-8,24),(263,239),(0,24),(255,239)]):
   m=w.life.make(b);w.shot(m,frame=frame,wx=center[0]&65535,y=center[1]);w.field(m,'SmBombBlocksDone',color)
   put(m,CurrentOAMOffset=offset,GuestOamRotationActive=int(bool(rot)),RgOamRotation=rot)
   start=address(b,'Sprite_Data');m[start:start+256]=bytes([248,0x55,0x23,0x66])*64
   beforeC=m.banks[2];before=bytes(m[0x5c40:0x5c70]);c,l,tr=call(m,'RdWxDraw');low=min(low,l)
   assert m.banks[2]==beforeC and get(m,'CurrentBankC')==beforeC|128
   assert [get(m,'CurrentCHRBank',i)for i in range(1,6)]==[0]*5
   assert get(m,'CurrentCHRBank',7)==175 and get(m,'X5ChrMode',7)==130
   assert get(m,'SsChrActive')==get(m,'X5SpecialChrUpper')==0
   after=bytes(m[0x5c40:0x5c70]);assert all(a==z for i,(a,z)in enumerate(zip(before,after))if i not in[1,2])
   idx=b['raw'][location(b,'RdWeaponIndex1'if color else'RdWeaponIndex0')+frame]
   ptr=address(b,'RdWpRecord'+str(idx))+0x2000;rec=record(b,ptr)
   assert len(rec)==1+rec[0] and rec[0]%4==0
   admit=bool(rec[0]) and rec[0]+offset<256
   assert get(m,'CurrentOAMOffset')==(offset+rec[0]if admit else offset)
   expected=bytearray(bytes([248,0x55,0x23,0x66])*64);parts=[]
   if admit:
    for j in range(rec[0]//4):
     tile,attr,dy,dx=rec[len(rec)-4*(j+1):len(rec)-4*j];dx=dx-256 if dx&128 else dx;dy=dy-256 if dy&128 else dy
     x=center[0]+dx;y=center[1]+dy;at=(offset+rot+4*j)&255
     # Genuine renderer stores X low BEFORE its high-byte rejection. It
     # similarly stores Y low before rejecting Y's high byte.
     expected[at+3]=x&255
     if 0<=x<=255:expected[at]=y&255
     if 0<=x<=255 and 0<=y<=255:part=bytes([y,tile,attr&243,x]);expected[at:at+4]=part;parts.append(list(part))
     else:expected[at]=248
   actual=bytes(m[start:start+256]);assert actual==expected,('actual OAM',frame,color,offset,rot,center,rec.hex(),actual.hex(),expected.hex())
   if offset==rot==0 and center==(128,128):
    sourceparts,*_=art.native_render(raw,frame,0,True,color,lower_bank=2)
    assert pixels(b['raw'],parts,687)=={xy:(v,attr&32)for xy,(v,attr)in art.source_pixels(raw,sourceparts).items()},(frame,color)
   rows.append(dict(frame=frame,color=color,offset=offset,rotation=rot,center=center,parts=rec[0]//4,admitted=admit,CPU=c.processorCycles,minimum_SP=l))
  checks['real_frozen_renderer_to_new_first_reader_OAM_pixels_capacity_clipping']=dict(cases=len(rows),rows_sha256=w.ref.digest(json.dumps(rows).encode()),complete_source_pixel_cases=30,capacity_rule='Whole record rejects when offset+length>=256; no partial success. Hardware8x16 transparent half still counts toward scanline8 and OAM allocation.',minimum_SP=min(z['minimum_SP']for z in rows),part_counts=sorted(set(z['parts']for z in rows)))
  # Cold real CHR initialization, original actor producer and whole Main.
  # This is source CPU ownership, not actual physical hardware/PPU readback.
  rows=[]
  for ident,frame,mode in itertools.product([6,13,12,0x2d],[40,77],[0,1]):
   pair=[]
   for bundle in[old,b]:
    m=w.life.make(bundle,mode);call(m,'X5ColdInit');m[0x5fee]=1
    w.target(m,ident,wx=168,y=176);w.shot(m,frame=frame,wx=100,y=120)
    _,r=w.life.mainstep(m,first=True);low=min(low,r['minimum_SP'])
    pair.append((m,[get(m,'CurrentCHRBank',i)for i in range(8)],[get(m,'X5ChrMode',i)for i in range(8)],r))
   a,z=pair
   assert z[1][1:6]==[20,21,22,23,24] and z[2][1:6]==[0]*5,(ident,frame,mode,z[1],z[2])
   assert z[1][7]==175 and z[2][7]==130
   # Preserve the native foreground actor OAM source while fixing its lease.
   rows.append(dict(actor=ident,frame=frame,mode=mode,old_CHR=a[1],new_CHR=z[1],new_modes=z[2],minimum_SP=z[3]['minimum_SP']))
  checks['actual_cold_init_Main_preserves_all_native_world_windows']=rows
  # Exact actual40 source item records fit only the already-authenticated6.
  rows=[]
  for kind,phase,offset in itertools.product(range(10),range(4),[0,244]):
   m=w.life.make(b);start=address(b,'Sprite_Data');m[start:start+256]=bytes([248,0x55,0x23,0x66])*64
   slot=5
   for n,v in [('Enemy_Flag',1),('Enemy_ID',46),('Enemy_State',128),('InvPickupOwner',2),('InvPickup',208+kind),('Enemy_X_Position',120),('Enemy_PageLoc',0),('Enemy_Y_Position',120),('Enemy_Y_HighPos',1),('Enemy_SprAttrib',32)]:w.field(m,n,v,slot)
   put(m,RdClock=phase*2,ObjectOffset=3,CurrentOAMOffset=offset)
   beforeC=m.banks[2];c,l,tr=call(m,'RdWpDrawItems');low=min(low,l)
   assert m.banks[2]==beforeC and get(m,'ObjectOffset')==3
   assert get(m,'CurrentCHRBank',6)==182 and get(m,'X5ChrMode',6)==130
   assert all(get(m,'CurrentCHRBank',i)==0 for i in range(6))
   ptr=b['raw'][16+121*8192+0x1e00+kind*4+phase]+256*b['raw'][16+121*8192+0x1e28+kind*4+phase]
   rec=record(b,ptr);assert all(129<=rec[i]<=183 and rec[i]&1 for i in range(1,len(rec),4))
   admitted=rec[0]+offset<256;assert get(m,'CurrentOAMOffset')==(offset+rec[0]if admitted else offset)
   if admitted:
    for j in range(rec[0]//4):
     t,a,y,x=rec[len(rec)-4*(j+1):len(rec)-4*j];y=y-256 if y&128 else y;x=x-256 if x&128 else x
     assert bytes(m[start+offset+4*j:start+offset+4*j+4])==bytes([128+y,t,(a|32)&243,128+x])
   rows.append([kind,phase,offset,rec.hex(),admitted])
  checks['actual40_item_record_lookup_first_C121_reader_bank6_behind_BG_and_capacity']=dict(cases=len(rows),case_SHA256=w.ref.digest(json.dumps(rows).encode()),physical694=True,physical695_remains_zero=not any(b['raw'][16+1048576+695*1024:16+1048576+696*1024]))
  rows=[]
  for special in[0,1]:
   m=w.life.make(b);call(m,'X5ColdInit');m[0x5fee]=1
   w.target(m,6,wx=168,y=176);w.shot(m,wx=100,y=120)
   for n,v in [('Enemy_Flag',1),('Enemy_ID',46),('Enemy_State',128),('InvPickupOwner',2),('InvPickup',208),('PowerUpType',1),('Enemy_X_Position',200),('Enemy_PageLoc',0),('Enemy_Y_Position',128),('Enemy_Y_HighPos',1)]:w.field(m,n,v,5)
   put(m,SsChrActive=special,SsChrPhysical=200,X5SpecialChrUpper=2)
   entries=[];oldstep=NesMPU.step
   def step(c):
    bank=m.banks[(c.pc-32768)//8192]if c.pc>=32768 else-1
    if c.pc==address(b,'MetaspriteRenderLoop')and bank==(location(b,'MetaspriteRenderLoop')-16)//8192:
     ptr=get(m,'R0')+256*get(m,'R1');entries.append(dict(C=m.banks[2],pointer=ptr,record=list(m[ptr:ptr+1+m[ptr]]),SP=c.sp,center=[get(m,'R4'),get(m,'R5'),get(m,'R6'),get(m,'R7')]))
    oldstep(c)
   NesMPU.step=step
   try:c,row=w.life.mainstep(m,first=True)
   finally:NesMPU.step=oldstep
   low=min(low,row['minimum_SP']);assert get(m,'SsChrActive')==special and get(m,'X5SpecialChrUpper')==2
   typed_records=[e for e in entries if e['C']==121]
   assert len(typed_records)>=2 and any(e['pointer']>=0xde50 for e in typed_records),entries
   assert all(e['record'][0]%4==0 and all((t&193)==193 for t in e['record'][1::4])if e['pointer']<0xde00 else all(129<=t<=183 for t in e['record'][1::4])for e in typed_records)
   # Execute the genuine current publisher and track the upper latch in
   # ordered bus writes. This proves compiled routing, not hardware fetches.
   m.writes.clear();call(m,'X5PublishChr');upper=0;physical={}
   for at,v in m.writes:
    if at==0x5130:upper=v&3
    elif 0x5120<=at<0x512c:physical[at-0x5120]=v+256*upper
   assert physical[6]==694 and physical[7]==687 and physical[4]==(712 if special else b['raw'][location(b,'ChrPhysicalMap')+23])
   assert physical[1]==b['raw'][location(b,'ChrPhysicalMap')+20]and physical[2]==b['raw'][location(b,'ChrPhysicalMap')+21]and physical[3]==b['raw'][location(b,'ChrPhysicalMap')+22]and physical[5]==b['raw'][location(b,'ChrPhysicalMap')+24]
   rows.append(dict(existing_special_lease=special,actual_all_Main_renderer_entries=entries,ordered_publisher_physical_pages=physical,minimum_SP=row['minimum_SP']))
  checks['combined_real_Main_body_enemy_weapon_item_firstreader_and_actual_CHR_publisher']=rows
  proof.update(passed=True,minimum_SP=low,limits=['Actual CPU OAM/source palette-index masks only. No hardware DMA, PPU, final palette colors, audio, deadline/FPS or native acquisition claim.','8x16 transparent halves affect scanline admission; compact source parts may use more or fewer OAM entries than held56ee.','Palette0 is an approved NES color-role adaptation. No original hue cycling or native displayed-color proof.'])
 except BaseException as e:proof.update(error=str(e),traceback=traceback.format_exc());raise
 finally:
  proof['bindings']=[w.ref.binding(p)for p in[Path(__file__),O/'build.json',O/'candidate.nes',O/'candidate.dbg',R/'build/rogue-dawn-weapon-world-art-v1/proof.json',R/'src/rogue_dawn_host_weapon_world.s',R/'tools/rogue_dawn_host_weapons_controls_v1.py']]
  (O/'render-controls.json').write_text(json.dumps(proof,indent=2)+'\n')
 print(json.dumps(dict(passed=True,checks={k:len(v)if isinstance(v,list)else v.get('cases')for k,v in checks.items()},minimum_SP=low)))
if __name__=='__main__':main()
