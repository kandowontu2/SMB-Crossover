"""Private typed-item owner/ABI/lifecycle/full-caller controls; no native."""
from pathlib import Path
import itertools,json,sys,traceback
R=Path(__file__).resolve().parents[1];sys.path[:0]=[str(R/'tools'),str(R/'tools/audit')]
import rogue_dawn_host_weapons_controls_v1 as w
from check_tmnt_render_oa import address,location
from sunny_integrated_controls_v1 import run,app,registers,cleanwrites
O=R/'build/rogue-dawn-host-items-v1';get,put,call=w.get,w.put,w.call

def typed(m,slot=5,state=128,owner=2,tag=216,flag=1,ident=46):
 for n,v in [('Enemy_Flag',flag),('Enemy_ID',ident),('Enemy_State',state),('InvPickupOwner',owner),('InvPickup',tag),('PowerUpType',1)]:w.field(m,n,v,slot)
 put(m,ObjectOffset=slot)

def main():
 b=w.life.d.old.scoped_load(O/'candidate.nes');old=w.life.d.old.scoped_load(w.O/'candidate.nes');checks={};low=255
 proof=dict(passed=False,source_CPU_only=True,native_run=False,ROM=w.ref.binding(O/'candidate.nes'),checks=checks)
 try:
  rows=[]
  for (char,key,var),mode in itertools.product(w.edges.PROFILES,[0,1]):
   pair=[]
   for bundle in[old,b]:
    q=w.edges.foreign(bundle,char,key,var,mode);c,wr,_=run(q,'GameLoop',p=0x71)
    pair.append((registers(c),app(q),tuple(q.m.banks),cleanwrites(q,wr),c.processorCycles))
   assert pair[0][:4]==pair[1][:4],('foreign fullMain',char,key,var,mode)
   rows.append(dict(raw=char,key=key,variant=var,mode=mode,CPU_delta=pair[1][4]-pair[0][4]))
  checks['all_foreign_complete_Main_AXYP_application_ordered_writes_banks']=rows
  rows=[]
  for (char,key,var),raw in itertools.product(w.edges.PROFILES,[0,1,2,3]):
   pair=[]
   for bundle in[old,b]:
    q=w.edges.foreign(bundle,char,key,var);m=q.m
    for n,v in [('Enemy_Flag',1),('Enemy_ID',46),('Enemy_State',128),('PowerUpType',raw),('Enemy_X_Position',200),('Enemy_PageLoc',0),('Enemy_Y_Position',128),('Enemy_Y_HighPos',1),('Enemy_BoundBoxCtrl',3)]:w.field(m,n,v,5)
    put(m,ObjectOffset=5)
    c,wr,_=run(q,'PowerUpObjHandler',x=5,p=0x71)
    pair.append((registers(c),app(q),tuple(m.banks),cleanwrites(q,wr),c.processorCycles))
   assert pair[0][:4]==pair[1][:4],('foreign real powerup actor',char,key,var,raw)
   rows.append(dict(raw=char,key=key,variant=var,actor_type=raw,CPU_delta=pair[1][4]-pair[0][4]))
  checks['all_foreign_actual_mature_powerup_draw_collision_caller']=rows
  rows=[]
  for slot,raw,p in itertools.product(range(6),range(4),w.life.body.FLAGS):
   m=w.life.make(b);typed(m,slot,tag=252);w.field(m,'PowerUpType',raw,slot)
   # All OTHER slots deliberately disagree. Real selected slot must own raw.
   for other in range(6):
    if other!=slot:w.field(m,'PowerUpType',3-raw,other)
   before=bytes(m[0x5fb0:0x5fb6]);c,l,tr=call(m,'RlPrepareDispatch',a=91,x=slot,y=7,p=p);low=min(low,l)
   assert bytes(m[0x5fb0:0x5fb6])==before
   if raw<2:
    assert get(m,'InvPickup',slot)==(216 if raw==0 else 217)and get(m,'InvPickupSaveLo',slot)==raw and get(m,'PowerUpType',slot)==1
   else:assert get(m,'PowerUpType',slot)==raw and get(m,'InvPickup',slot)==252
   assert c.x==slot
   rows.append(dict(slot=slot,raw=raw,P=p,minimum_SP=l))
  checks['actual6slot_prepare_real_input_and_otheractor_disagreement']=rows
  rows=[]
  for slot,state,owner,tag,flag,ident in itertools.product(range(6),[1,17,127,128],[1,2],[207,216,217,218],[0,1,128],[6,46]):
   m=w.life.make(b);typed(m,slot,state,owner,tag,flag,ident);before=bytes(m[0x5fb0:0x5fb6]);call(m,'RdItCollision',x=slot)
   # The real contact leaf is deliberately called here only to verify its
   # defensive classification. This is not a physical acquisition claim.
   c,l,tr=call(m,'RdItPickup',x=slot);low=min(low,l)
   admits=state>=128 and owner==2 and 208<=tag<218 and flag==1 and ident==46
   assert (bytes(m[0x5fb0:0x5fb6])!=before)==admits,(slot,state,owner,tag,flag,ident)
   if admits:
    assert get(m,'Enemy_Flag',slot)==get(m,'InvPickup',slot)==0
    after=bytes(m[0x5fb0:0x5fb6]);call(m,'RdItPickup',x=slot);assert bytes(m[0x5fb0:0x5fb6])==after
   rows.append(admits)
  checks['typed_contact_defensive_maturity_owner_flag_ID_tag_and_once_only']=dict(cases=len(rows),admitted=sum(rows))
  rows=[]
  for raw,slot,mode in itertools.product([2,3],range(6),[0,1]):
   m=w.life.make(b,mode);typed(m,slot,tag=252);w.field(m,'PowerUpType',raw,slot);before=bytes(m[0x5fb0:0x5fb6]);lives=get(m,'NumberofLives')
   c,l,tr=call(m,'HandlePowerUpCollision',x=slot);low=min(low,l)
   assert bytes(m[0x5fb0:0x5fb6])==before and get(m,'Enemy_Flag',slot)==0
   if raw==2:assert get(m,'StarInvincibleTimer')==0x23 and get(m,'NumberofLives')==lives
   else:
    assert get(m,'FloateyNum_Control',slot)==11 and get(m,'NumberofLives')==lives
    for tick in range(6):call(m,'FloateyNumbersCore',x=slot)
    assert get(m,'NumberofLives')==(lives+1)&255 and bytes(m[0x5fb0:0x5fb6])==before
   rows.append(dict(raw=raw,slot=slot,mode=mode,minimum_SP=l))
  checks['real_native_Star_1Up_consumer_source_resources_unchanged']=rows
  rows=[]
  for resources,api,mode in itertools.product([(0,0,0,0,153,9),(255,7,15,3,18,25)],['NrFreshGameInit','RdLifeArea'],[0,1]):
   m=w.life.make(b,mode);m[0x5fb0:0x5fb6]=bytes(resources);put(m,PlayerStatus=7,AreaType=1,AreaAddrsLOffset=5,MmDeathFlag=1)
   c,l,tr=call(m,api);low=min(low,l)
   expect=api!='NrFreshGameInit'and any(resources[:4]);assert get(m,'PlayerStatus')==int(expect)
   if api=='NrFreshGameInit':assert bytes(m[0x5fb0:0x5fb6])==bytes([0,0,0,0,153,9])
   else:assert bytes(m[0x5fb0:0x5fb4])==bytes(resources[:4])
   rows.append(dict(before=resources,API=api,mode=mode,after=list(m[0x5fb0:0x5fb6]),status=get(m,'PlayerStatus'),minimum_SP=l))
  checks['genuine_fresh_life_scene_delivery_marker_from_earned_resources']=rows
  seams=[]
  for name in['RdItPrepare','RdItCollision','RdItPickup','RdWpDrawItems']:
   for kind in['IRQ','lagNMI']:
    m=w.life.make(b);typed(m,5,state=128);put(m,Player_X_Position=128,Player_Y_Position=128)
    w.field(m,'Enemy_X_Position',128,5);w.field(m,'Enemy_Y_Position',135,5);w.field(m,'Enemy_Y_HighPos',1,5)
    if name=='RdItPrepare':
     # Source bomb legitimately constructs actual item through the real
     # native world consumer, preserving the deep IRQ/NMI constructor case.
     w.shot(m,action=10,wx=128,y=160,frame=60);w.field(m,'RdWAge',0,208);w.field(m,'RdWAnim',130,208);w.field(m,'RdWReset',130,208)
     w.life.body.pipe.d.old.tile(m,128,160,0x60);w.field(m,'Enemy_Flag',0,5)
    bank=(location(b,name)-16)//8192;c,row=w.life.mainstep(m,first=True,seam=(address(b,name),bank,kind));low=min(low,row['minimum_SP']);seams.append(dict(name=name,kind=kind,minimum_SP=row['minimum_SP']))
  checks['genuine_Main_item_constructor_contact_render_IRQ_lagNMI_seams']=seams
  proof.update(passed=True,minimum_SP=low,limits=['CPU source/caller controls only; no hardware, PPU, timing or native acquisition claim.','Direct defensive cases explicitly seed typed input actor fields; only progression-controls uses genuine constructor→rise→contact without outcome seeds.','Inherited cleanwrites/app comparator retains its documented dead-stack/SMC scope; live IRQ/lag-NMI stack is compared by the actual caller harness.'])
 except BaseException as e:proof.update(error=str(e),traceback=traceback.format_exc());raise
 finally:
  proof['bindings']=[w.ref.binding(p)for p in[Path(__file__),O/'build.json',O/'candidate.nes',O/'candidate.dbg',R/'src/rogue_dawn_host_items.s',R/'src/rogue_dawn_host_items_gate.s',R/'tools/rogue_dawn_host_weapons_controls_v1.py']]
  (O/'item-edge-controls.json').write_text(json.dumps(proof,indent=2)+'\n')
 print(json.dumps(dict(passed=True,minimum_SP=low,checks={k:len(v)if isinstance(v,list)else v.get('cases')for k,v in checks.items()})))
if __name__=='__main__':main()
