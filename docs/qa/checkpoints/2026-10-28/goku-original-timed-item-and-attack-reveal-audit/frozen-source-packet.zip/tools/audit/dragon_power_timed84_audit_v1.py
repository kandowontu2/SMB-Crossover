"""Read-only original-ROM timed84/caller/reveal audit. No host or native edits."""
from pathlib import Path
import collections, hashlib, json, sys
ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT / 'tools'))
import dragon_power_map_v1 as D
import dragon_power_reference_v1 as O
from py65.devices.mpu6502 import MPU

OUT = ROOT / 'build/dragon_power_timed84_audit_v1.json'
WATCH = {(3, p) for p in [0x9861, 0x9867, 0xE1AA, 0xE1D9, 0xE29D, 0xE399]}
WATCH |= {(0, p) for p in [0x8EA0, 0xA49B]}

class Memory(O.Memory):
    def __init__(self):
        super().__init__(0)
        self.owner = None
        self.reads = collections.Counter()
    def __getitem__(self, a):
        if isinstance(a, int) and a in (0xD9, 0x36) and self.owner:
            self.reads[(self.owner[0], self.owner[1], a)] += 1
        return super().__getitem__(a)

def arena(fa=7, f9=3, typ=0x84, sub=0, dx=0, action=1, pole=0):
    m = Memory()
    for p, v in [(0xF9, f9), (0xFA, fa), (0xF2, 0), (0x2D, action),
                 (0x2E, 100), (0xF7, 80), (0xF8, 160), (0x412, 255),
                 (0x628, typ), (0x632, sub), (0x600, 160),
                 (0x614, 80 + dx), (0x32, 0x80 | pole)]:
        m.ram[p] = v
    m.ram[0x3B0:0x400] = bytes([0x75]) * 80
    for p in range(0x688, 0x700, 20):
        m.ram[p] = 255
    return m

def cpu(m):
    c = MPU(memory=m, pc=0x600)
    c.sp = 253
    return c

def nmi(m, c, visits):
    start = c.processorCycles
    c.nmi()
    for i in range(30000):
        if c.pc == 0x600:
            assert c.sp == 253 and m.bank == 0
            m.owner = None
            return c.processorCycles - start
        m.owner = (m.bank, c.pc)
        if m.owner in WATCH:
            visits[m.owner] += 1
        c.step()
    raise AssertionError(('original NMI failed to return', m.bank, hex(c.pc)))

def label_counts(c):
    return {':'.join(f'{v:X}' for v in k): n for k, n in sorted(c.items())}

def state(m):
    return {f'{p:02X}': m.ram[p] for p in [0xD9, 0x36, 0x26, 0x27, 0x28, 0x2D, 0x2E, 0xF9, 0xFA]}

def main():
    assert not OUT.exists(), 'Preserve the frozen first result; use a new version for changes.'
    rom = [D.memory(k) for k in range(4)]
    m = arena()
    pickup = O.call(m, 0x8EEB, x=0)
    assert m.ram[0xD9] == 16 and m.ram[0x36] == 16 and m.ram[0x21] == 1
    control = Memory()
    control.ram[:] = m.ram
    control.ram[0xD9] &= ~16  # Explicit bit-off counterfactual, not an earned game campaign.
    a, b = cpu(m), cpu(control)
    va, vb = collections.Counter(), collections.Counter()
    costs, samples = [], []
    for tick in range(1, 1025):
        ca, cb = nmi(m, a, va), nmi(control, b, vb)
        assert ca == cb
        assert bytes(m.ram[:0xD9]) + bytes(m.ram[0xDA:]) == bytes(control.ram[:0xD9]) + bytes(control.ram[0xDA:])
        assert (a.a, a.x, a.y, a.p, a.sp, m.bank, m.chr) == (b.a, b.x, b.y, b.p, b.sp, control.bank, control.chr)
        assert m.ram[0xD9] == 16 and m.ram[0x36] == 16 and m.ram[0xFA] == 7 and m.ram[0xF9] == 3
        costs.append(ca)
        if tick in [1, 60, 120, 480, 960, 1024]:
            samples.append(dict(tick=tick, state=state(m)))
    side = dict(actual_mature_collector=pickup, ticks=1024, samples=samples,
                visits=label_counts(va), reads=label_counts(m.reads),
                cpu_min=min(costs), cpu_max=max(costs), cpu_sum=sum(costs),
                bit_off_counterfactual='All other 32KB RAM, returned CPU registers/flags/SP, banks/CHR and per-NMI CPU exact at every return.',
                exception='Only D9 bit10 differs; this comparison is an explicit CPU boundary control, not a naturally acquired control item.')
    overhead = []
    for fa, f9 in [(1, 1), (3, 2)]:
        q = arena(fa, f9)
        O.call(q, 0x8EEB, x=0)
        c, visits, sample = cpu(q), collections.Counter(), []
        for tick in range(1, 1025):
            nmi(q, c, visits)
            if tick in [1, 60, 960, 1024]:
                sample.append(dict(tick=tick, state=state(q)))
        assert q.ram[0xD9] & 16 == 0 and q.ram[0x36] == 0
        assert visits[(3, 0xE1AA)] == visits[(3, 0xE1D9)] == 1024
        assert visits[(3, 0xE399)] > 0
        overhead.append(dict(FA=fa, F9=f9, samples=sample, visits=label_counts(visits), reads=label_counts(q.reads)))
    attacks = []
    for action, pole, dx, accepted in [(1, 0, 20, False), (5, 0, 20, True),
                                       (5, 0, 30, False), (5, 1, 30, True)]:
        q = arena(typ=0x8A, dx=dx, action=action, pole=pole)
        q.ram[0x646] = 0x84
        O.call(q, 0x8EEB, x=0)
        assert (q.ram[0x63C] == 32) == accepted
        row = dict(action=action, pole=pole, dx=dx, accepted=accepted,
                   timer=q.ram[0x63C], actor=q.ram[0x628], acquired=q.ram[0x21])
        if accepted:
            for _ in range(32):
                O.call(q, 0x8EEB, x=0)
            assert q.ram[0x628] == 0x84 and q.ram[0x600] == 140 and q.ram[0x21] == 0
            row['after32'] = dict(actor=q.ram[0x628], y=q.ram[0x600], acquired=q.ram[0x21])
        attacks.append(row)
    mature = []
    for typ, sub, accepted in [(0x83, 2, True), (0x84, 0, False)]:
        q = arena(typ=typ, sub=sub, dx=20, action=5)
        O.call(q, 0x8EEB, x=0)
        assert (q.ram[0x628] != typ) == accepted
        assert q.ram[0xD9] == 0
        mature.append(dict(type=typ, subtype=sub, action=5, dx=20,
                           accepted=accepted, after_actor=q.ram[0x628], timer=q.ram[0x63C]))
    # Literal caller census is evidence, not a proof against all indirect/script routes.
    literal = []
    for bank, image in enumerate(rom):
        for p in range(0x8000, 0xFFFC):
            if bytes(image[p:p+5]) == bytes.fromhex('A01A208B98'):
                literal.append(f'{bank}:{p:04X}')
    assert literal == ['0:8C4C']
    pointers = [rom[0][0x8D80+i*2] + 256*rom[0][0x8D81+i*2] for i in range(4)]
    assert pointers == [0, 0x8D86, 0x8D94, 0x6464]
    tables = []
    for i in range(5):
        p = rom[3][0xF036+i] + 256*rom[3][0xF03B+i]
        data = bytes(rom[3][p:p+32])
        assert 0x84 in data
        tables.append(dict(index=i, pointer=f'3:{p:04X}', bytes=data.hex(), count84=data.count(0x84)))
    spans = [(0,0x800B,0x8097),(0,0x80DD,0x8136),(0,0x81B2,0x81F2),
             (0,0x8C27,0x8C7F),(0,0x8CA6,0x8CD5),(0,0x8EA0,0x8EDD),
             (0,0x91D2,0x91E7),(0,0x9235,0x9257),(0,0x94A8,0x9561),
             (0,0x97A7,0x9830),(0,0xB895,0xB93B),(3,0x9861,0x9876),
             (3,0xE1AA,0xE2A6),(3,0xE399,0xE3E1),(3,0xF57C,0xF69F)]
    result = dict(status='READ_ONLY_ORIGINAL_SOURCE_CPU; NOT_HOST_OR_NATIVE',
                  scope='Typed original-RAM CPU arenas, actual 800B NMI/RTI and bank switching. No simulated PPU/DMA timing, real controller schedule, natural drop acquisition or host implementation.',
                  bindings=[D.binding(D.ROM),D.binding(D.__file__),D.binding(O.__file__),D.binding(__file__)],
                  original_source_spans=[dict(bank=b,start=f'{p:04X}',end_exclusive=f'{e:04X}',
                      sha256=hashlib.sha256(rom[b][p:e]).hexdigest()) for b,p,e in spans],
                  side_view=side, overhead=overhead, reveal=attacks, mature_attack=mature,
                  container_random_tables=tables, literal_Y1A_callers=literal,
                  paid_drop_mode_pointers=[f'{p:04X}' for p in pointers],
                  conclusion='Original overhead caller owns D9bit10 movement/expiry. No side-view reachable84 producer established; bounded side-view NMI witness leaves timer/bit inert. Do not add a guessed speed effect to the held host drop port.',
                  remaining='No exhaustive authenticated side-view script/spawn reachability proof; container attack and matureA3 attack need deliberate source-side-view mapping. Held host generic84 bob differs from original collector; no original native palette/visible behavior claim.')
    OUT.write_text(json.dumps(result, indent=2)+'\n', encoding='utf-8')
    print(json.dumps(D.binding(OUT)))

if __name__ == '__main__':
    main()
