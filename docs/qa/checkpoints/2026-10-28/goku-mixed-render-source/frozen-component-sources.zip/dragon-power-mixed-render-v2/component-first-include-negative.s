SelectedCharacter=$6002
NumberofLives=$075f
AreaAddrsLOffset=$0754
AreaType=$0753
WorldNumber=$0764
SavedJoypadBits=$00dc
GamePauseStatus=$0777
GameEngineSubroutine=$000f
TimerControl=$074a
Player_Rel_XPos=$0571
Player_Y_Position=$00bd
Player_Y_HighPos=$00a4
ScreenLeft_X_Pos=$071f
ScreenLeft_PageLoc=$071d
GetBlockBufferAddr=$95dc
MmSolidTerrain=$66d1
Block_Buffer_1=$0300
MTileAttribute=$ef36
R0=$0003
R1=$0004
R2=$0005
R3=$0006
R4=$0007
R5=$0008
R6=$0009
R7=$000a
Player_X_Position=$0075
Player_X_Scroll=$0701
Player_PageLoc=$005c
Player_Y_Speed=$008e
Player_X_Speed=$0046
Player_XSpeedAbsolute=$0702
PlayerFacingDir=$053e
Player_State=$001e
PlayerSize=$0759
PlayerStatus=$075b
CrouchingFlag=$0717
CrossoverBehaviorVersion=$7fe1
CurrentBankC=$7da1
Player_SprAttrib=$0587
Player_Pos_ForScroll=$075a
SmPosePtr=$6b06
SmChrBank=$6b08
ObjectMetasprite=$06e1
SafecallA_SMC=$0169
FarcallJmpTarget_SMC=$016b
FarCallCommon=$015a
X5SetPhysicalChr=$a275
MetaspriteRenderLoop=$a5ba
MTILE_SOLID=$0001
METASPRITE_SAMUS_BODY=$00e9
.macpack longbranch
DP_CHR_PUBLISH_BANK=62
DP_RENDER_BANK=4
.include "C:/Users/kando/Documents/ChatGPT/SMB Crossover/src/dragon_power_state.inc"
.include "C:/Users/kando/Documents/ChatGPT/SMB Crossover/src/dragon_power_native.inc"
.include "C:/Users/kando/Documents/ChatGPT/SMB Crossover/src/dragon_power_host.s"
.include "C:/Users/kando/Documents/ChatGPT/SMB Crossover/build/dragon-power-mixed-render-v2/dragon_power_render_mixed.s"
.include "C:/Users/kando/Documents/ChatGPT/SMB Crossover/src/dragon_power_contact.s"
.include "C:/Users/kando/Documents/ChatGPT/SMB Crossover/build/dragon-power-mixed-render-v2/dragon_power_art_mixed.inc"
