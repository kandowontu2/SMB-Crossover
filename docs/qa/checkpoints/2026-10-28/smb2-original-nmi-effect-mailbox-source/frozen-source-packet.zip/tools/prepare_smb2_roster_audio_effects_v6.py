"""Sparse frozen-v5 successor: one append-only effect leaf, no shared hook."""
from pathlib import Path
import hashlib,json,subprocess
import prepare_smb2_roster_hud_v5 as P
R=P.ROOT;OLD=P.OUT;OUT=R/'build/smb2-roster-audio-effects-v6';bind=P.bind
PARENT='abbb13e0ede68ef61b1099079949d5877e35104c7fe719748cb2a371114d7ff0'

def main():
 assert bind(OLD/'handoff.json')['sha256']==PARENT
 h=json.loads((OLD/'handoff.json').read_text())
 for k in['owned_files','input_bindings','output_bindings']:
  for row in h[k]:assert bind(row['path'])==row
 a=(OLD/'candidate.nes').read_bytes();start=16+74*8192+0x1c81
 assert a[start:16+75*8192]==bytes([255])*895
 OUT.mkdir(exist_ok=True);obj=OUT/'objects';obj.mkdir(exist_ok=True)
 source=(OLD/'objects/entrypoint.s').read_text()+'\n.if ::ENABLE_MMC5_EXPANDED .and ::MAPPER_MMC5\n.include "smb2_roster_audio_effects_v6.s"\n.endif\n'
 (obj/'entrypoint.s').write_text(source,newline='\n')
 cmd=json.loads((OLD/'build-proof.json').read_text())['command']
 cmd=[v.replace(str(OLD/'objects/entrypoint.s'),str(obj/'entrypoint.s')).replace(str(OLD/'candidate.'),str(OUT/'candidate.'))for v in cmd]
 p=subprocess.run(cmd,cwd=R,capture_output=True,text=True);(OUT/'launcher.txt').write_text(p.stdout+p.stderr);assert not p.returncode,p.stderr[-3000:]
 from prepare_cv3_dmc_mirror import prepare
 prepare(R,OUT/'candidate.nes');raw=bytearray((OUT/'candidate.nes').read_bytes());fixed=raw[16+127*8192:16+128*8192]
 plan=json.loads((R/'build/smb2-roster-audio-plan-v1.json').read_text());original=P.M.F.P.A.S.ROM.read_bytes()
 for clone in plan['samples']:
  copy=bytearray(fixed)
  for row in clone['entries']:
   at=int(row['target'],16)-0xe000;p=int(row['source'],16);n=row['bytes'];blob=original[16+114688+p-0xc000:16+114688+p-0xc000+n]
   assert hashlib.sha256(blob).hexdigest()==row['sha256'];copy[at:at+n]=blob
  raw[16+clone['bank']*8192:16+(clone['bank']+1)*8192]=copy
 (OUT/'candidate.nes').write_bytes(raw)
 changed=[i for i,(x,y)in enumerate(zip(a,raw))if x!=y];assert changed and all(start<=i<16+75*8192 for i in changed)
 d=dict(status='PRIVATE_ISOLATED_EFFECT_MAILBOX_UNQUALIFIED_NO_COMMON_HOOK_NO_NATIVE',parent=bind(OLD/'candidate.nes'),parent_handoff=bind(OLD/'handoff.json'),candidate=bind(OUT/'candidate.nes'),command=cmd,actual_changed_bytes=len(changed),
  owned_source=bind(R/'src/smb2_roster_audio_effects_v6.s'),tool=bind(__file__),all_prior_bytes_outside_append_exact=True)
 (OUT/'build-proof.json').write_text(json.dumps(d,indent=2)+'\n');print(json.dumps(dict(candidate=d['candidate'],changed_bytes=len(changed),build=bind(OUT/'build-proof.json'))))

if __name__=='__main__':main()
