"""Freeze the isolated54B mailbox, genuine sparse link and finite controls."""
from pathlib import Path
import collections,difflib,json,re,subprocess,sys
import prepare_smb2_roster_audio_effects_v6 as B
import smb2_roster_audio_effect_controls_v6 as T
R,O,bind=B.R,B.OUT,B.bind

def main():
 assert not(O/'handoff.json').exists(),'frozen packet must not be overwritten'
 h=json.loads((B.OLD/'handoff.json').read_text())
 for k in ['owned_files','input_bindings','output_bindings']:
  for row in h[k]:assert bind(row['path'])==row
 build=json.loads((O/'build-proof.json').read_text());tests=json.loads((O/'effect-controls.json').read_text())
 assert tests['passed']and tests['candidate']==build['candidate']==bind(O/'candidate.nes')
 assert build['tool']==bind(B.__file__)and tests['tool']==bind(T.__file__)
 old=json.loads((B.OLD/'source-closure.json').read_text());cmd=old['command'].copy()
 cmd[cmd.index('--create-full-dep')+1]=str(O/'source-closure.d');cmd[cmd.index('-o')+1]=str(O/'source-closure.o');cmd[-1]=str(O/'objects/entrypoint.s')
 p=subprocess.run(cmd,cwd=R,capture_output=True,text=True);(O/'source-closure-launcher.txt').write_text(p.stdout+p.stderr);assert not p.returncode,p.stderr
 line=(O/'source-closure.d').read_text().splitlines()[0].split(':\t',1)[1]
 deps={Path(x.replace('\\ ',' ')).resolve()for x in re.split(r'(?<!\\)\s+',line.strip())}
 assert R/'src/smb2_roster_audio_effects_v6.s'in deps
 # This genuine entry includes the append only inside the expanded-MMC5
 # condition. The ordinary source builds below consume it with that guard off.
 ov=O/'overlay/src';ov.mkdir(parents=True,exist_ok=True)
 (ov/'entrypoint.s').write_bytes((O/'objects/entrypoint.s').read_bytes())
 ordinary=[]
 for mode in ['mmc3','mmc5']:
  dest=O/('flagoff-'+mode+'.nes')
  command=[sys.executable,str(R/'tools/build_mmc5_expanded.py'),'--source-overlay',str(O/'overlay'),'--output',str(dest),'--flag-off',mode]
  if not dest.exists():
   p=subprocess.run(command,cwd=R,capture_output=True,text=True);(O/('flagoff-'+mode+'-launcher.txt')).write_text(p.stdout+p.stderr);assert not p.returncode,p.stderr[-2000:]
  ref=B.OLD/('flagoff-'+mode+'.nes');assert dest.read_bytes()==ref.read_bytes()
  ordinary.append(dict(mapper=mode,actual=bind(dest),reference=bind(ref),command=command))
 def identities(path):
  result=collections.Counter();scopes={};rows=[]
  for line in path.open():
   d=dict(re.findall(r'(\w+)=("[^"]*"|[^,\r\n]+)',line))
   if line.startswith('scope\t'):scopes[d['id']]=d
   elif line.startswith('sym\t')and'val'in d:rows.append(d)
  def context(i):
   if i is None:return None
   d=scopes[i]
   return(context(d.get('parent')),d.get('mod'),d['name'])
  for d in rows:result[(context(d.get('scope')),)+tuple(d.get(k)for k in ['name','seg','type','addrsize','val'])]+=1
  return result
 prior=identities(B.OLD/'candidate.dbg');current=identities(O/'candidate.dbg');missing=prior-current
 assert not missing,('genuine qualified old symbols changed',list(missing.items())[:5])
 b=T.A.scoped_load(O/'candidate.nes');a=(B.OLD/'candidate.nes').read_bytes()
 lo=16+74*8192+0x1c81;hi=16+74*8192+0x1cb7
 diff=[i for i,(x,y)in enumerate(zip(a,b['raw']))if x!=y]
 assert len(diff)==54 and all(lo<=i<hi for i in diff)
 assert b['raw'][16+74*8192+0x1cb7:16+75*8192]==bytes([255])*841
 assert a[:16]==b['raw'][:16]and a[16+1048576:]==b['raw'][16+1048576:]
 patch=''.join(difflib.unified_diff([], (R/'src/smb2_roster_audio_effects_v6.s').read_text().splitlines(True),fromfile='/dev/null',tofile='b/src/smb2_roster_audio_effects_v6.s'))
 patch+=''.join(difflib.unified_diff((B.OLD/'objects/entrypoint.s').read_text().splitlines(True),(O/'objects/entrypoint.s').read_text().splitlines(True),fromfile='6173/entrypoint.s',tofile='effect-v6/entrypoint.s'))
 (O/'implementation.patch').write_text(patch,newline='\n')
 note=R/'docs/qa/smb2-roster-audio-effects-source-2026-10-29.txt'
 note.write_text('''PRIVATE SMB2 THREE-STA EFFECT MAILBOX — ISOLATED SOURCE PASS

Candidate204bf57a appends exactly54B at physical74 BC81..BCB6;841B remain.
All prior ROM/header/CHR bytes and qualified source symbols remain exact. No
new RAM, common bridge, source producer change, FIFO/generation/dirty byte,
Main clock or live scheduler. Complete current127-derived119/120/125 callable
bytes and source sample payloads are inherited byte-exact from6173.

Actual Main STA fields:5C6F DPCM→original0601,5C70 SFX1→0602,5C71 SFX2→0604.
S2AudioEffectTick saves callerAXYP, raw25-admits before private reads, ensures
retired-owner initialization, copiesP to those threeQ fields, calls exactly
one authenticated original driver callback, then clears only those threeP.
Main cannot run inside this nonreentrant NMI callback; a Main producer after
return naturally survives for the next callback. Multiple Main stores before
callback preserve original last-assignment/driver-bit-priority semantics.
Q0 music/Q3 event/Q5 SFX3 are NMI-context-consumer-only, not extra Main queues.

2084 literal original/direct/new source comparisons; all256request values per
field, actual producer lifetimes, source41pause/resume, first-owner preexisting
request consumption, overwrite and new-identical-request seams, all256flags,
255foreignraw guards.29new reached instruction/driver-boundary actualIRQ
contexts;12genuine farcalls with currentE119/120/127. Exact ordered APU images,
hardware4010/12/13/15/17 intents and complete samplepayloads, source52RAM+12ZP,
allnonstackRAM/banks and33SMC, callerAXYP/SP, foregroundBB..C6 andheld4011 DAC.
Six producer-before/after callback cases execute actual pair0 hero STA bytes
and genuine translated118producerSTAs; full Main callers remain frozen prior
source evidence, not a new hardware scheduler claim.

Measured additional118CPU per warm callback over the direct compiled driver.
First-owner acquisition adds827CPU relative to already-initialized direct
oracle (includes actual69B init). Selected finite original222..1495CPU,
mailbox858..2375CPU. AmbientSP192 minimum168 in these calls; genuine farcall
plusIRQ minimum169 in declared contexts. These are not a final wholeNMI stack
or timing bound. Actual new cold/driver/mixer/NMI call depth still required.
Foreign direct guard53CPU; final common dispatch must reject before a mapper
trip, preserving bounded foreign cost.

Retained negatives: first-init write-accounting omitted genuine private69B
clear although full final state already matched; corrected only under captured
non25 preowner. Producer-reference bank initially used audio pair2 instead of
actual hero pair0; asserted/executed original pair0 bytes now. No source/game
patch resulted from either test setup failure.

OPEN: true real-NMI S2NmiClock including lag/pause; stable Main scene/session
context publication; oldowner retirement even after selection changes;
original music/world/pause mapping, status/DMC completion/4011-preserving mixer;
composed current127/119/120/125 regeneration and wholecallerIRQ/NMI stack,
actual native audio/PPU/cadence.6173 remains diagnosticvisual/controller scope.
''',encoding='utf-8',newline='\n')
 inputs=deps|{Path(row['path'])for row in h['input_bindings']}
 inputs|={R/'tools/prepare_cv3_dmc_mirror.py',R/'build/smb2-roster-audio-plan-v1.json',T.A.S.ROM,Path(sys.executable)}
 for mod in list(sys.modules.values()):
  f=getattr(mod,'__file__',None)
  if f:
   p=Path(f).resolve()
   if p.suffix=='.py'and(p.is_relative_to(R)or'py65'in p.parts):inputs.add(p)
 source=dict(passed=True,source_CPU_only=True,native=False,candidate=build['candidate'],parent=build['parent'],actual_ASM_dependencies=len(deps),command=cmd,
  changed_bytes=54,only_physical_bank=74,span=['BC81','BCB6'],remaining_A74=841,all_prior_qualified_symbol_records=sum(prior.values()),all_prior_ROM_bytes_outside_append_exact=True,
  ordinary=ordinary,input_bindings=[bind(p)for p in sorted(inputs)],tool=bind(__file__))
 (O/'source-closure.json').write_text(json.dumps(source,indent=2)+'\n')
 owned=[R/'src/smb2_roster_audio_effects_v6.s',Path(B.__file__),Path(T.__file__),Path(__file__),note,O/'implementation.patch',ov/'entrypoint.s']
 outputs=[p for p in O.rglob('*')if p.is_file()and p.name!='handoff.json']
 handoff=dict(status='PRIVATE_54B_EFFECT_MAILBOX_SOURCE_CPU_IRQ_PASS_NO_COMMON_HOOK_NO_NATIVE',candidate=build['candidate'],parent=build['parent'],parent_handoff=bind(B.OLD/'handoff.json'),source=bind(O/'source-closure.json'),controls=bind(O/'effect-controls.json'),
  scope_note=bind(note),owned_files=[bind(p)for p in owned],input_bindings=source['input_bindings'],output_bindings=[bind(p)for p in sorted(outputs)],
  limits='No trueNmiClock/host audio scheduler/context/mixer/DMC-owner/native admission; source and ABI scope only.')
 (O/'handoff.json').write_text(json.dumps(handoff,indent=2)+'\n')
 print(json.dumps(dict(handoff=bind(O/'handoff.json'),inputs=len(inputs),ASMdeps=len(deps),owned=len(owned),outputs=len(outputs),ordinary=ordinary),indent=2))

if __name__=='__main__':main()
