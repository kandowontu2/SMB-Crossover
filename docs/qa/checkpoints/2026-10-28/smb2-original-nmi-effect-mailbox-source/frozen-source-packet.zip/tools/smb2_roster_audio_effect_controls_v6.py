"""Finite original/direct-driver/mailbox comparison; no host NMI admission.

The authentic original callback and the already-qualified compiled direct driver
are the oracles. Only the three Main STA request bytes use the new mailbox.
"""
from pathlib import Path
import collections,hashlib,json
import smb2_roster_audio_controls_v1 as A
import smb2_roster_audio_leases_v1 as L

R=A.ROOT;O=R/'build/smb2-roster-audio-effects-v6';bind=A.bind
NAMES={1:'S2DpcmRequest',2:'S2Sfx1',4:'S2Sfx2'}

class Pair:
 def __init__(self,b,cold=False):
  self.b=b;self.ref=A.Campaign(b);self.actual=A.Campaign(b);self.rows=[];self.targets={}
  self.pending={i:A.address(b,n)for i,n in NAMES.items()}
  if cold:
   m=self.actual.new;state=self.ref.state
   list.__setitem__(m,slice(state,state+69),bytes([0x63])*69)
   m[A.address(b,'RgAudioCharacter')]=9
 def queue(self,i,v):
  self.ref.queue(i,v)
  if i in self.pending:self.actual.new[self.pending[i]]=v
  else:self.actual.queue(i,v) # NMI context-consumer only, never a Main API.
 def pause(self,v):self.ref.pause(v);self.actual.pause(v)
 def tick(self,p=0x30,sp=0xc0,collect=False):
  n=self.actual.new
  # The baseline method also checks literal original RAM/ZP, source inner
  # registers, ordered APU stores and complete sample fetch payloads.
  old,direct=self.ref.tick(flags=p,sp=sp)
  list.__setitem__(n,slice(0xbb,0xc7),bytes(self.ref.new[0xbb:0xc7]))
  initial=L.snapshot(n)
  c=A.call(n,A.address(self.b,'S2AudioEffectTick'),a=0x55,x=3,y=7,p=p,sp=sp)
  assert(c.a,c.x,c.y,c.p&0xcf,c.sp)==(0x55,3,7,p&0xcf,sp),'mailbox full AXYP/SP'
  assert n.events==self.ref.new.events and n.fetches==self.ref.new.fetches,'literal ordered source APU/fetches'
  assert n.native_return[:4]==self.ref.new.native_return[:4] and n.native_return[4]==self.ref.new.native_return[4]-6,'native inner return including real extra call depth'
  assert L.live(n)==L.live(self.ref.new),'all non-stack RAM and all actual banks equal direct source driver'
  assert bytes(n[0x15a:0x17b])==bytes(self.ref.new[0x15a:0x17b]),'all33 SMC bytes'
  assert all(n[v]==0 for v in self.pending.values()),'all three requests cleared this real callback'
  assert n[0x4011]==0x49,'DAC held, no invented reset'
  allowed={*self.pending.values()}
  # First acquisition genuinely clears the complete69B source/audio record;
  # the paired direct oracle was initialized before queue assignment.
  if initial[0][A.address(self.b,'RgAudioCharacter')]!=25:
   allowed.update(range(self.ref.state,self.ref.state+69));allowed.add(A.address(self.b,'RgAudioCharacter'))
  direct_writes={p for p,v in self.ref.new.writes}
  for at,v in n.writes:assert at in allowed or at in direct_writes or 0x17b<=at<=0x100+sp,('new undeclared write',hex(at))
  if collect:
   begin=A.address(self.b,'S2AudioEffectTick');end=A.address(self.b,'S2AudioEffectEnd')
   seams={A.address(self.b,x)for x in ['S2AudioEnsure','S2AudioInitialize','S2AudioTick','S2AudioBorrow','S2AudioNativeEntry','S2AudioRelease','S2AudioReturn']}
   for site in n.execs:
    if site[1]==74 and(begin<=site[0]<end or site[0]in seams):self.targets.setdefault(site,(initial,L.snapshot(n),n.events.copy(),n.fetches.copy(),c.processorCycles))
  row=dict(original=old.processorCycles,direct=direct.processorCycles,mailbox=c.processorCycles,additional=c.processorCycles-direct.processorCycles,min_SP=c.minimum_SP)
  self.rows.append(row);return row

def actual_sta_seams(b):
 """Execute genuine old/new STA opcodes immediately either side of callback.

 These are actual emitted producer instructions, not substitute callback PCs.
 Complete source movement/collection/action callers remain in the frozen Main
 campaigns; this layer isolates the new transport's interrupt ordering.
 """
 rows=[]
 for label,source_pc,index,value in [('S2N8A9A',0x8a9a,1,8),('S2N8C3A',0x8c3a,4,1),('S2N8E52',0x8e52,2,8)]:
  pc=A.address(b,label);at=A.location(b,label);dest=A.address(b,NAMES[index])
  assert b['raw'][at:at+3]==bytes([0x8d,dest&255,dest>>8])
  original=A.S.original(0);assert original[source_pc:source_pc+3]==bytes([0x8d,(0x600+index)&255,6])
  for order in ['STA-then-NMI','NMI-then-STA']:
   q=Pair(b);pending=q.actual.new
   if order.startswith('NMI'):q.tick()
   pending.page(1,118)
   c=A.NesMPU(memory=pending,pc=pc);c.a=value;c.step()
   assert c.pc==pc+3 and pending[dest]==value
   pending.page(1,74);q.ref.old.ram[0x600+index]=value
   A.call(q.ref.new,A.address(b,'S2AudioSetQueue'),a=value,x=index)
   # Original producer instruction is executed too, independent of the
   # callback's source oracle queue assignment above.
   z=A.NesMPU(memory=original,pc=source_pc);z.a=value;z.step();assert original[0x600+index]==value
   q.tick();assert pending[dest]==0
   rows.append(dict(label=label,actual_PC=hex(pc),physical_bank=118,original_PC=hex(source_pc),request=value,order=order,source_equal=True))
 return rows

def main():
 build=json.loads((O/'build-proof.json').read_text());assert bind(O/'candidate.nes')==build['candidate']
 b=A.scoped_load(O/'candidate.nes');allrows=[];targets={};campaigns=[]
 def save(q,name):
  allrows.extend(q.rows);targets.update(q.targets)
  campaigns.append(dict(name=name,calls=len(q.rows),additional_min=min(x['additional']for x in q.rows),additional_max=max(x['additional']for x in q.rows)))
 # Changed addressing accepts every possible byte without inventing enum
 # restrictions or separate events. Driver priority remains original.
 for index in NAMES:
  for value in range(256):
   q=Pair(b);q.queue(index,value);q.tick(collect=True);save(q,f'byte-{index}-{value}')
 # Actual hero producer values plus useful full-lifecycle context/pause.
 for index,value in [(1,4),(1,8),(1,128),(2,8),(4,1),(4,8),(4,32)]:
  q=Pair(b);q.queue(0,1);q.queue(index,value)
  for t in range(128):q.tick(p=[0x30,0x79,0xff][t%3],collect=True)
  save(q,f'actual-Main-{index}-{value}')
 q=Pair(b)
 for t in range(160):
  if t==0:q.queue(0,1)
  if t==20:q.pause(0x41)
  if t==132:q.pause(0)
  if 20<=t<132:
   for i,v in [(1,8),(2,8),(4,1),(3,8),(5,2)]:q.queue(i,v)
  q.tick(collect=True)
 save(q,'source-pause41-clears-all-Q-and-P-resumes-without-stale-effects')
 q=Pair(b,cold=True)
 q.queue(1,8);q.queue(2,8);q.queue(4,1)
 q.tick(collect=True);save(q,'first-owner-init-retains-real-Main-pending-cues')
 # Repeated stores overwrite, not FIFO/OR; same byte after callback survives
 # to the next callback, while never republishing a consumed old value.
 q=Pair(b)
 for i,values in [(1,[4,8]),(2,[1,8]),(4,[8,1])]:
  for v in values:q.queue(i,v)
 q.tick();q.tick();q.queue(4,1);q.tick();save(q,'last-assignment-idle-and-new-identical-value')
 # Every public flag value and all foreign owner bytes.
 for flags in range(256):
  q=Pair(b);q.tick(p=flags);save(q,f'flags-{flags}')
 base=L.snapshot(A.Campaign(b).new);private=set(range(A.address(b,'S2AudioState'),A.address(b,'S2AudioState')+69))|set(range(0x5c00,0x5c80))|{A.address(b,'RgAudioCharacter')}
 foreign=[]
 for raw in range(256):
  if raw==25:continue
  m=L.restore(b,base);m[A.address(b,'SelectedCharacter')]=raw;before=L.live(m);m.reads=[]
  c=L.invoke(m,b,'S2AudioEffectTick',a=0x41,x=5,y=0x72,p=0x79,sp=0xc0)
  assert L.live(m)==before and not private.intersection(m.reads),'foreign admission before private overlay'
  foreign.append(c.processorCycles)
 # Actual IRQ at every newly reached mailbox instruction and real driver
 # boundary. No broad mask: only the handler's three genuine PPU/CHR writes.
 irqs=[]
 for site,(snap,want,events,fetches,cycles)in sorted(targets.items()):
  m=L.restore(b,snap);c=L.invoke(m,b,'S2AudioEffectTick',a=0x55,x=3,y=7,p=0x30,sp=0xc0,inject=site)
  assert m.events==events and m.fetches==fetches and m.banks==want[1]
  for at,(x,y)in enumerate(zip(want[0][:0x8000],bytes(m)[:0x8000])):
   assert x==y or 0x100<=at<0x200 or at in[0x2005,0x2006,0x5128],('IRQ live state',site,hex(at),x,y)
  assert min(c.minimum_SP,m.observed_SP)>=0x7b
  irqs.append(dict(PC=hex(site[0]),bank=site[1],delta=c.processorCycles-cycles,min_SP=min(c.minimum_SP,m.observed_SP)))
 far=[]
 for request in [0,1,8]:
  q=Pair(b)
  if request:q.queue(1,request);q.tick()
  initial=L.snapshot(q.actual.new);ebank=q.actual.new.banks[3]
  for ba,bc in [(4,4),(62,80),(99,93),(118,117)]:
   m=L.restore(b,initial);m.page(1,ba);m.page(2,bc);m[A.address(b,'CurrentBank')]=ba|128;m[A.address(b,'CurrentBankC')]=bc|128
   m[A.address(b,'SafecallA_SMC')+1]=0x55
   pc=A.address(b,'S2AudioEffectTick');m[A.address(b,'FarcallJmpTarget_SMC')+1]=pc&255;m[A.address(b,'FarcallJmpTarget_SMC')+2]=pc>>8
   c=A.call(m,A.address(b,'FarCallCommon'),a=202,x=3,y=7,p=0x30,sp=0xc0,inject=(A.address(b,'S2AudioBorrow'),74))
   assert(c.a,c.x,c.y,c.p&0xcf,c.sp)==(0x55,3,7,0,0xc0)
   assert m.banks==[126,ba,bc,ebank] and m[A.address(b,'CurrentBank')]==ba|128 and m[A.address(b,'CurrentBankC')]==bc|128
   assert min(c.minimum_SP,m.observed_SP)>=0x7b
   far.append(dict(E=ebank,A=ba,C=bc,cycles=c.processorCycles,min_SP=min(c.minimum_SP,m.observed_SP)))
 seams=actual_sta_seams(b)
 result=dict(passed=True,source_CPU_only=True,native=False,candidate=bind(O/'candidate.nes'),build=bind(O/'build-proof.json'),tool=bind(__file__),
  unchanged_original_driver_controls=bind(A.OUT/'differential-controls.json'),unchanged_original_lease_controls=bind(A.OUT/'lease-controls.json'),
  literal_original_comparison_calls=len(allrows),campaigns=campaigns,mailbox_incremental_cycles=sorted(set(x['additional']for x in allrows)),
  total_original_cycles=[min(x['original']for x in allrows),max(x['original']for x in allrows)],total_mailbox_cycles=[min(x['mailbox']for x in allrows),max(x['mailbox']for x in allrows)],
  min_SP=min(x['min_SP']for x in allrows),foreign_owners=255,foreign_cycles=sorted(set(foreign)),new_reached_IRQ_sites=irqs,genuine_farcall_alias_IRQ=far,actual_compiled_STA_seams=seams,
  contract='P1/P2/P4 are exact authentic Main STA requests; NMI copy->one original callback->clearP, no Main can run inside that callback. Q0/Q3/Q5 are NMI context-consumer-only. All52sourceRAM+12ZP, orderedAPU/fullDMCpayload, publicAXYP/SP, all nonstackRAM/banks and33SMC match direct original-source-qualified driver.',
  limits='Isolated source/CPU only. No actual NMI clock/audio dispatch, host mixer/pause/lifecycle or native DMC/PPU/steal timing approval. Foreign owner must already be retired before first init. IRQ tested through actual current vectors; no manually simulated Main is native evidence.')
 (O/'effect-controls.json').write_text(json.dumps(result,indent=2)+'\n')
 print(json.dumps(dict(passed=True,calls=len(allrows),IRQ=len(irqs),proof=bind(O/'effect-controls.json'))))

if __name__=='__main__':main()
