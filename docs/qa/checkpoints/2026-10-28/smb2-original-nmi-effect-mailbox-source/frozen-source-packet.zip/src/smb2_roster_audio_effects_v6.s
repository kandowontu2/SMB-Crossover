; PRIVATE NMI-only source-effect mailbox. Main's authentic STA sites stay put.
; Caller has genuinely initialized raw25 gameplay and retired any former audio
; owner. Q0/music,Q3/event,Q5/SFX3 are exclusively the NMI context consumer's.
; This is one nonreentrant audio callback, NOT a Main or shared-resident hook.
.pushseg
.segment "KIRBY_ABILITIES"
.export S2AudioEffectTick,S2AudioEffectStart,S2AudioEffectEnd
S2AudioEffectStart:
.assert *=S2AudioCodeEnd,lderror,"Effect mailbox must append to real SMB2 audio"
.proc S2AudioEffectTick
 S2ASave
 jsr S2AudioEnsure
 lda S2DpcmRequest
 sta S2AudioState+21
 lda S2Sfx1
 sta S2AudioState+22
 lda S2Sfx2
 sta S2AudioState+24
 jsr S2AudioTick               ; exactly one authenticated callback.
 lda #0
 sta S2DpcmRequest
 sta S2Sfx1
 sta S2Sfx2                    ; Main cannot run until this NMI returns.
 jmp S2AudioReturn
.endproc
S2AudioEffectEnd:
.assert *<=$c000,lderror,"Effect mailbox exceeds owned A74 audio lease"
.popseg
