"""One private Goku movement union; immutable component/router inputs, no native."""
from pathlib import Path
import configparser,difflib,hashlib,json,re,subprocess,sys
R=Path(__file__).resolve().parents[1];O=R/'build/dragon-power-movement-v1';M=R/'build/dragon-power-mixed-render-v3'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 if O.exists():
  assert ('--resume-unfrozen-source-negative' in sys.argv and (O/'provisional-pre-foundation-v1.zip').is_file()) or ('--resume-unfrozen-build-negative' in sys.argv and not json.loads((O/'build-proof.json').read_text())['passed'])
  oldproof=O/'first-build-negative.json'
  if not oldproof.exists():oldproof.write_bytes((O/'build-proof.json').read_bytes())
  n=len(list(O.glob('build-negative-*.log')))+1
  if (O/'build.log').exists():(O/f'build-negative-{n}.log').write_bytes((O/'build.log').read_bytes())
 else:(O/'src').mkdir(parents=True)
 P=R/'build/celeste-small-chr-v2.nes';assert sha(P)=='f56a0e154c86c2bcc3577bd99e48dfab71ee61282defa6d16963a2c73e4487c9'
 sys.path[:0]=[str(R/'tools'),str(R/'tools/audit')]
 from dragon_power_component_v1 import labels,NAMES
 from sunny_integrated_controls_v1 import scoped_load,address,location
 b=scoped_load(P);s=labels(P.with_suffix('.lbl'))
 oldgate=(R/'build/nr-router-compact-v1-overlay/src/new_roster_dispatch.s').read_text();gate=oldgate
 # Only owned late-position publication and deliberate hidden/no-weapon state.
 gate='.import DpHostLateGraphics,DpHostVisible,DpHostNoWeapons\n'+gate
 for name,target in [('NrGraphics','DpHostLateGraphics'),('NrVisible','DpHostVisible'),('NrDraw','DpHostNoWeapons'),('NrWeapons','DpHostNoWeapons')]:
  start=gate.index('NrGate '+name+',');end=gate.index('\n',start)
  # Macro gets an explicit fifth target; old public97B slot and cold finish fixed.
  gate=gate[:end]+','+target+gate[end:]
 gate=gate.replace('.macro NrGate Name,Ice,City,Sunny,Legacy','.macro NrGate Name,Ice,City,Sunny,Legacy,Goku')
 gate=gate.replace('TargetLo:.byte <Ice,<City,<Legacy,<Sunny,<Legacy,','TargetLo:.byte <Ice,<City,<Legacy,<Sunny,<Goku,')
 gate=gate.replace('TargetHi:.byte >Ice,>City,>Legacy,>Sunny,>Legacy,','TargetHi:.byte >Ice,>City,>Legacy,>Sunny,>Goku,')
 gate=gate.replace(' .byte .bank(Legacy)|$80,.bank(Legacy)|$80,.bank(Legacy)|$80,.bank(Legacy)|$80,.bank(Legacy)|$80',' .byte .bank(Goku)|$80,.bank(Legacy)|$80,.bank(Legacy)|$80,.bank(Legacy)|$80,.bank(Legacy)|$80')
 # Explicit legacy operand on all other gates, not a runtime/global flag.
 gate=re.sub(r'^NrGate ([^\n]+)$',lambda m:'NrGate '+m[1]+(','+m[1].split(',')[-1] if len(m[1].split(','))==5 else ''),gate,flags=re.M)
 (O/'src/new_roster_dispatch.s').write_text(gate)
 hurt=(R/'src/guest_injury.s').read_text();newhurt=hurt.replace('farcall CheatsGameRoutinesGate,jmp','farcall DpHostCheatGate,jmp',1).replace('farcall GameRoutines,jmp','farcall DpHostGameGate,jmp',1)
 (O/'src/guest_injury.s').write_text('.if ::ENABLE_MMC5_EXPANDED .and ::MAPPER_MMC5\n.import DpHostCheatGate,DpHostGameGate\n.endif\n'+newhurt)
 # Authentic EF77 instruction boundary; only its pending representation changes.
 native=(R/'src/dragon_power_native.inc').read_text();native=native.replace(' sta DpContacts+7,x ;3:EF77 9d0704',' jsr DpHostCommitBlock ;same3B source publication, exact world-cell host record')
 assert native!=(R/'src/dragon_power_native.inc').read_text();(O/'dragon_power_native_host.inc').write_text(native)
 host=(R/'src/dragon_power_host.s').read_text()
 # Real native question/coin-brick table, not arbitrary solidity. Blank hidden
 # blocks remain the frozen source's pass-through until a separately owned rule.
 marker=' lda (R6),y\n beq Empty\n';assert host.count(marker)==1
 host=host.replace(marker,' jsr DpHostTileRead          ; same4B span; legal question class adapter\n nop\n')
 (O/'dragon_power_host_terrain.inc').write_text(host)
 extras='''GameRoutines CheatsGameRoutinesGate GuestHurtKind CheatInvincible A_B_Buttons Left_Right_Buttons Up_Down_Buttons
Player_BoundBoxCtrl BoundingBoxCore BoundingBox_UL_XPos BoundingBox_UL_YPos BoundingBox_LR_Corner Player_Rel_YPos
RelativePlayerPosition GetPlayerOffscreenBits ScrollHandler Enemy_Flag Enemy_ID Enemy_Y_HighPos Enemy_Y_Position
Enemy_State PlatformCollisionFlag GuestClaimBlockSlot SprDataOffset_Ctrl MmBlockAttack PlayerHeadCollision AreaPointer
BlockBufferColli_Head BlockBufferColli_Feet BlockBufferColli_Side HandlePipeEntry HandleClimbing HandleCoinMetatile'''.split()
 names=list(dict.fromkeys(NAMES+extras+['MTILE_SOLID','MTILE_CLIMB','METASPRITE_SAMUS_BODY']))
 for n in names:
  if n not in s:
   z=re.search(r'^sym[^\n]*name="'+n+r'"[^\n]*val=0x([0-9A-Fa-f]+)',P.with_suffix('.dbg').read_text(),re.M);assert z,n;s[n]=int(z[1],16)
 # Genuine cross-object imports. Do not shadow the full link's real symbols
 # with absolute preimage aliases in its DBG.
 pre='\n'.join(('.importzp ' if s[n]<256 else '.import ')+n for n in names)+'\n.macpack longbranch\n.include "inc/common.inc"\nDP_CHR_PUBLISH_BANK=62\nDP_RENDER_BANK=4\n'
 incs=[R/'src/dragon_power_state.inc',O/'dragon_power_native_host.inc',O/'dragon_power_host_terrain.inc',M/'dragon_power_render_mixed.s',R/'src/dragon_power_contact.s',M/'dragon_power_mixed_tail.inc',R/'build/dragon_power_movement_host_v1.inc',M/'dragon_power_art_mixed.inc']
 (O/'component.s').write_text(pre+''.join('.include "'+p.resolve().relative_to(R).as_posix()+'"\n'for p in incs))
 cfg=(R/'smb1base-mmc5-expanded.cfg').read_text();anchor='    CELESTE_MARIO_CORE: load='
 at=cfg.index(anchor);cfg=cfg[:at]+'''    DRAGON_POWER_CORE: load=X5_NEW_56,type=ro,start=$a800,optional=yes;
    DRAGON_POWER_ART: load=X5_NEW_55,type=ro,start=$c900,optional=yes;
    DRAGON_POWER_CHR: load=TMNT_CHR_TAIL,type=ro,start=$c5000,optional=yes;
'''+cfg[at:];(O/'smb1base-mmc5-expanded.cfg').write_text(cfg)
 conf=configparser.ConfigParser();conf.optionxform=str;conf.read(R/'build_options.ini');defs={k:v for sec in conf.values()for k,v in sec.items()};defs.update(MAPPER_MMC3='0',MAPPER_MMC5='1',ENABLE_CROSSOVER='1',ENABLE_MMC5_EXPANDED='1')
 cc=R/'tools/Windows/cc65/bin';out=O/'candidate.nes'
 cmd=[str(cc/'cl65.exe'),'--cpu','6502x','-t','nes','-g','-Oisr','-vm','-T','-C',str(O/'smb1base-mmc5-expanded.cfg'),'--ld-args','--dbgfile,'+str(out.with_suffix('.dbg')),'--include-dir',str(R),'--asm-include-dir',str(O/'src'),'--asm-include-dir',str(R/'src'),'--asm-include-dir',str(R),'--bin-include-dir',str(R),'-m',str(out.with_suffix('.map')),'-Ln',str(out.with_suffix('.lbl')),'-o',str(out)]
 for k,v in defs.items():cmd+=['--asm-define',k+'='+v,'-D',k+'='+v]
 # Flat staged entrypoint / actual assembler source; no source or runtime clone.
 (O/'entrypoint.s').write_text((R/'src/entrypoint.s').read_text()+'\n'+''.join('.export '+n+'\n'for n in names));(O/'main.c').write_bytes((R/'src/main.c').read_bytes())
 cmd += [str(O/'main.c'),str(O/'entrypoint.s'),str(O/'component.s')]
 q=subprocess.run(cmd,cwd=R,capture_output=True,text=True);(O/'build.log').write_text(q.stdout+q.stderr)
 proof=dict(passed=False,native_run=False,command=cmd,exit=q.returncode,parent_sha256=sha(P),frozen_component_sha256=sha(M/'handoff.json'),router_sha256=sha(R/'build/nr_router_compact_handoff_v1.json'),inputs={str(p.resolve()):sha(p)for p in incs})
 (O/'build-proof.json').write_text(json.dumps(proof,indent=2)+'\n');assert q.returncode==0,q.stderr
 from prepare_cv3_dmc_mirror import prepare
 prepare(R,out)
 proof.update(passed=True,candidate_sha256=sha(out),DBG_sha256=sha(out.with_suffix('.dbg')),LBL_sha256=sha(out.with_suffix('.lbl')))
 (O/'build-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
if __name__=='__main__':main()
