"""Freeze one source-only movement unit; no emulator, install or Git actions."""
from pathlib import Path
import collections,configparser,difflib,hashlib,json,re,subprocess,sys
R=Path(__file__).resolve().parents[1];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import dragon_power_movement_controls_v2 as C
from sunny_integrated_controls_v1 import *
O=C.O
def binding(p):p=Path(p).resolve();return dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))
def main():
 assert not (O/'handoff.json').exists()
 p=O/'candidate.nes';b=scoped_load(p);parent=R/'build/celeste-small-chr-v2.nes';old=scoped_load(C.OLD)
 receipts={n:json.loads((O/n).read_text())for n in['controls-release.json','consumers-release.json','original-release.json']}
 for n,q in receipts.items():
  assert q['passed'];assert q['bindings'][str(p.resolve())]==sha(p),(n,'wrong candidate')
 assert sha(O/'ordinary-mmc3.nes')=='d444cac88e13fa02b29ad16100b8f08fa565ba90f8cedde192de43fb2dc8f3eb'
 assert sha(O/'ordinary-mmc5.nes')=='f4ffd2483c51daa4d60bb575da2da8c4d817692cda407611c243031f67520833'
 raw=p.read_bytes();ref=C.OLD.read_bytes();pr=parent.read_bytes();checks={}
 ds={k:sum(a!=z for a,z in zip(ref[16+k*8192:16+(k+1)*8192],raw[16+k*8192:16+(k+1)*8192]))for k in range(128)};ds={k:v for k,v in ds.items()if v}
 assert set(ds)=={85,86,124,125,127}and ds[124]==12 and ds[125]==ds[127]==6,ds
 coreline=next(z for z in p.with_suffix('.map').read_text().splitlines()if z.startswith('DRAGON_POWER_CORE '));end=int(coreline.split()[2],16)+1;size=end-0xa800
 assert size<=6144 and pr[16+86*8192+0x800:16+87*8192]==bytes([255])*6144
 assert raw[16+85*8192+0x900:16+85*8192+0x900+1263]==(R/'build/dragon-power-mixed-render-v3/art.bin').read_bytes()
 assert raw[1048592+788*1024:1048592+796*1024]==(R/'build/dragon-power-mixed-render-v3/mixed.chr').read_bytes()
 assert raw[1048592:1048592+788*1024]==pr[1048592:1048592+788*1024]and raw[1048592+796*1024:]==pr[1048592+796*1024:]
 at=16+127*8192+0x58;assert raw[at:at+14]==pr[at:at+14]==bytes.fromhex('900ba9e08500a90785014c828060')
 assert address(b,'FIXED')==0xe066 and address(b,'SamusFreezeFlushPalette')==0xe058
 assert raw[16+124*8192+0xda4:16+124*8192+0xdce]==bytes([255])*42
 checks['layout']=dict(core_start='86:A800',core_end_exclusive=hex(end),core_bytes=size,remaining_CORE=6144-size,diff_vs_pinned_router=ds,
 protected_Samus_E058_14B_exact=True,VOID_7B_fill_proposal_preserved=True,public_FIXED_E066=True,Rogue_future_ADA4_ADCE_42B_FF=True,only_original_approved_Goku_segments=True,header_and_all_other_CHR_exact=True)
 # Qualified/scoped symbols and unique genuine names, not ambiguous debugger
 # aliases such as Done/Next that can name many unrelated source instructions.
 dbg=C.OLD.with_suffix('.dbg').read_text();scopes={};symrows=[]
 for line in dbg.splitlines():
  if line.startswith(('scope\t','sym\t')):
   d=dict(re.findall(r'(\w+)=("[^"]*"|[^,\r\n]+)',line.split('\t',1)[1]))
   if line.startswith('scope\t'):scopes[d['id']]=d
   elif 'val'in d:symrows.append(d)
 def scope_name(i):
  d=scopes.get(i,{})
  return '::'.join(z for z in[scope_name(d.get('parent'))if'parent'in d else'',d.get('name','').strip('"')]if z)
 roots={d['name'].strip('"')for d in symrows if not scope_name(d.get('scope'))};verified=[];aliases=[]
 for n in old['syms']:
  if n=='_FARCALL_COUNT'or n.startswith(('@','__')):continue
  if '::'not in n and n not in roots:
   if n in b['syms']and address(old,n)!=address(b,n):aliases.append(n)
   continue
  assert n in b['syms']and address(old,n)==address(b,n),('genuine old symbol',n)
  verified.append(n)
 checks['real_symbols']=dict(verified=len(verified),all_scoped_or_unique_old_PC_RAM_values_exact=True,ambiguous_unqualified_debug_aliases_not_public_movement=aliases)
 # Explicitly restore page1's actual classification:100..159 SHORTRAM and
 #15A..17A SMCCODE are LIVE, not dead stack. Earlier generic snapshots omitted
 #them; final5SMC was separately compared. This is the complete live-page proof.
 short=[];cpu=[]
 for ch,cheat in[(ch,0)for ch in range(24)]+[(ch,flag)for ch in[0,3,20,21,23]for flag in[1,2,4,8,16,31]]:
  pair=[]
  for bundle in[old,b]:
   q=C.setup(bundle,ch);q.put(CheatInvincible=cheat,SavedJoypadBits=129)
   c,tr,mn=C.runtrace(q,'GameLoop',p=0x71)
   live=bytes(q.m[0x100:0x17b]);exclude=set(smc_at(bundle))|{address(bundle,'CurrentBank')}
   writes=[(i,v)for i,v in q.m.writes if not 0x17b<=i<0x200 and i not in exclude and not 0x5114<=i<=0x5117]
   pair.append((C.snap(q,c),live,writes,c.processorCycles,mn))
  assert pair[0][:3]==pair[1][:3],('full SHORTRAM/SMCCODE/foreign consumer',ch,cheat)
  short.append([ch,cheat,pair[1][3]-pair[0][3],pair[1][4]]);cpu.append(pair[1][3]-pair[0][3])
 checks['live_page1_foreign_Main']=dict(cases=len(short),entire_SHORTRAM_and_all33SMCCODE_bytes_final_exact=True,all_remaining_ordered_writes_exact=True,
 explicit_added_mapper_CurrentBank_5SMC_call_publication=True,CPU_delta=[min(cpu),max(cpu)],min_SP=min(z[-1]for z in short),rows=short,
 erratum='Earlier generic app()/stack filter omits live100..17A. The separate final5SMC checks were valid; this additional full live-page proof supplies missing SHORTRAM/all-SMC coverage. Extra nested call publications are intentional, not claimed byte-exact ordered5SMC.')
 # Practical complete native platform consumers, not just typed receipt cells.
 carry=[]
 for kind,mode,face in[(k,m,f)for k in[0x25,0x26,0x27,0x28,0x2a]for m in[0,1]for f in[1,2]]:
  q=C.setup(b);q.put(CrossoverBehaviorVersion=mode,PlayerFacingDir=face,ObjectOffset=0)
  q.set('Enemy_ID',kind,0);q.set('Enemy_Flag',1,0);run(q,'InitEnemyObject',x=0)
  for n,v in [('Enemy_ID',kind),('Enemy_Flag',1),('Enemy_X_Position',88),('Enemy_PageLoc',0),('Enemy_Y_Position',208),('Enemy_Y_HighPos',1),('Enemy_BoundBoxCtrl',5),('Enemy_State',0)]:q.set(n,v,0)
  for age in range(4):
   q.put(NmiDisable=255,SavedJoypadBits=0,VRAM_Buffer1_Offset=0);c,tr,mn=C.runtrace(q,'GameLoop')
   assert q.get('DpY')==(q.get('Player_Y_Position')+16)&255 and q.get('DpX')==(q.get('Player_X_Position')-q.get('ScreenLeft_X_Pos'))&255
   carry.append([kind,mode,face,age,q.get('Player_X_Position'),q.get('Player_Y_Position'),q.get('Enemy_Y_Position'),q.get('DpPlatform'),mn])
 checks['actual_native_platform_Main_carry']=dict(updates=len(carry),real_InitEnemyObject_and_native_movement_collision_called=True,no_double_source_horizontal_carry=True,late_source_coordinate_commit_exact=True,rows=carry)
 q=C.setup(b);q.put(Player_X_Position=103,Player_Rel_XPos=103);bb=address(b,'Block_Buffer_1');q.m[bb+0xb0+6]=0x10;q.m[bb+0xb0+7]=0x11
 C.runtrace(q,'GameLoop');q.put(SavedJoypadBits=4,NmiDisable=255,VRAM_Buffer1_Offset=0);c,tr,mn=C.runtrace(q,'GameLoop');assert q.get('GameEngineSubroutine')==3 and q.get('ChangeAreaTimer')==48
 checks['real_native_down_pipe_consumer']=dict(source_standing_or_crouch_only=True,actual_native_Feet_Y0_Y1_before_INY=True,real_complete_Main_engine=3,timer=48,min_SP=mn)
 q=C.setup(b);run(q,'DpEnsure');q.put(DpProbeX=160,DpProbePage=0,DpProbeY=0x50);run(q,'DpHostCommitBlock',a=128);at=bb+0x50+10;q.m[at]=0x52;q.m[address(b,'MmSolidTerrain')+0x50+10]=1
 c,tr,mn=C.runtrace(q,'DpHostBlocks');assert q.m[at]==0x52 and q.m[address(b,'DpContacts')+7]==0 and(126,address(b,'PlayerHeadCollision'))not in tr
 checks['foundation_revalidation']=dict(native52_foundation_untouched=True,stale_pending_ACK_without_native_block_mutation=True,negative_preserved='foundation-revalidation-negative-v1.json')
 # Actual complete main ca65 dependencies, plus independently rebuilt Goku
 # object. The canonical/frozen sources are read, never cloned or modified.
 conf=configparser.ConfigParser();conf.optionxform=str;conf.read(R/'build_options.ini');defs={k:v for sec in conf.values()for k,v in sec.items()};defs.update(MAPPER_MMC3='0',MAPPER_MMC5='1',ENABLE_CROSSOVER='1',ENABLE_MMC5_EXPANDED='1')
 cc=R/'tools/Windows/cc65/bin';deps={};commands=[]
 for name,source in[('main',O/'entrypoint.s'),('component',O/'component.s')]:
  dep=O/(name+'-final.d');obj=O/(name+'-final.o');cmd=[str(cc/'ca65.exe'),'--cpu','6502x','-g','-I',str(O/'src'),'-I',str(R/'src'),'-I',str(R),'--bin-include-dir',str(R),'--create-full-dep',str(dep),'-o',str(obj)]
  for k,v in defs.items():cmd+=['-D',k+'='+v]
  cmd+=[str(source)];q=subprocess.run(cmd,cwd=R,capture_output=True,text=True);assert q.returncode==0,q.stderr;commands.append(cmd)
  for word in re.split(r'(?<!\\)\s+',dep.read_text().split(':\t',1)[1].strip().removesuffix(':')):
   f=Path(word.replace('\\ ',' '));f=(f if f.is_absolute()else R/f).resolve();assert f.is_file();deps[str(f)]=sha(f)
 # Same real final assembly objects must relink the exact candidate.
 cmd=[str(cc/'cl65.exe'),'--cpu','6502x','-t','nes','-g','-Oisr','-c','--include-dir',str(R),'-o',str(O/'c-final.o')]
 for k,v in defs.items():cmd+=['-D',k+'='+v]
 cmd+=[str(O/'main.c')];q=subprocess.run(cmd,cwd=R,capture_output=True,text=True);assert q.returncode==0,q.stderr;commands.append(cmd)
 out=O/'independent.nes';cmd=[str(cc/'cl65.exe'),'--cpu','6502x','-t','nes','-C',str(O/'smb1base-mmc5-expanded.cfg'),'-Ln',str(out.with_suffix('.lbl')),'--ld-args','--dbgfile,'+str(out.with_suffix('.dbg')),'-o',str(out),str(O/'c-final.o'),str(O/'main-final.o'),str(O/'component-final.o')]
 q=subprocess.run(cmd,cwd=R,capture_output=True,text=True);assert q.returncode==0,q.stderr;commands.append(cmd)
 from prepare_cv3_dmc_mirror import prepare
 prepare(R,out);assert sha(out)==sha(p),'independent full source relink differs'
 checks['genuine_ASM_closure']=dict(dependencies=len(deps),commands=commands,independent_relink_ROM_exact=True,regenerated_CV3_125_from_final127=True,future_E119_E120_clones_must_regenerate_from_same_final127=True)
 (O/'final-controls.json').write_text(json.dumps(dict(passed=True,candidate_sha256=sha(p),checks=checks),indent=2)+'\n')
 (O/'source.patch').write_text(''.join(''.join(difflib.unified_diff((R/orig).read_text().splitlines(True),target.read_text().splitlines(True),fromfile='a/'+orig,tofile='b/'+orig))for orig,target in [('src/guest_injury.s',O/'src/guest_injury.s'),('src/new_roster_dispatch.s',O/'src/new_roster_dispatch.s'),('smb1base-mmc5-expanded.cfg',O/'smb1base-mmc5-expanded.cfg')]))
 summary=R/'docs/qa/dragon-power-movement-host-2026-10-28.txt'
 summary.write_text(f'''PRIVATE SOURCE/CPU UNIT; NO PLAYABLE/MENU/AUDIO/ENEMY-COMBAT ADMISSION OR NATIVE RUN.
Candidate {sha(p)}. Parent f56a plus separately bound current-semantics router and frozen lossless mixed render. Real cross-object imports/link/DBG; no fake whole-ROM symbols.
CORE86 A800..{end-1:04X}: {size}B, remaining {6144-size}B. Existing approved ART85/CHR788..795 unchanged from mixed component. No RAM or added service flag. Old public PC/qualified state values fixed. Rogue future ADA4..<ADCE protected. E058..E065 is SamusFreezeFlushPalette, NOT FF: original allocation proposal void and no bytes used.
Only 7 bytes of frozen4155B Goku prefix change: original EF77 STA becomes ABI-preserving JSR to commit existing pending cells as exact world low/page/row; original4B query read becomes JSR/NOP for native question classification. Every original Goku PC fixed. Actual source kernel movements/clocks/AXYP/application output remain exact in256 no-block updates; measured added kernel CPU0..249, native query7..31. Native question classes are authored SMB adapters, not an original DragonPower room claim.
GuestGameRoutinesBridge stays45B with only two literal18B target operands rebound. Exactraw24 wrappers own one source movement/solid resolver; all others tail genuine legacy targets with an extra A-bank trip. Foreign full Main final state/OAM/CHR/registers/banks is exact; +96CPU in168 ordinary cases. Full live100..159 SHORTRAM/all33SMCCODE bytes are separately checked (generic inherited stack filter omitted them); extra fiveSMC/CurrentBank/mapper call publications are intentional, never claimed ordered-byte-identical. This is not lag or FPS qualification.
Actual native coin/pipe/climb/block consumers remain distinct from source solid resolution. Busy block slots retain commands; native transaction restores player origin/size/crouch/velocity/block-attack byte, then ACKs. Pending foundation provenance is revalidated. Retained synthetic pending-remap counterexample is not a native observed failure. Feet adder/crouch pipe admission negative preserved; corrected real Down pipe reaches engine3/timer48. True large-platform native Main carry and late source coordinate commit are exercised; native typed balance/small support records are separately scoped.
Source phases: DpMovement once per admitted activeMain; ordinary ScrollHandler; native interaction consumers; late DpX/Y after source camera and after native actor/platform carry. No second PlayerBGCollision. Main catchups remain Main-clock updates, not physical-frame equivalence. Scene key uses loader AreaType/AreaAddrsLOffset, never future AreaPointer; life gains preserve, loss resets. DpHostReset is an explicit future menu API; no menu was exposed. Non8 modes delegate actual GameRoutines.
To keep this movement-only unit unplayable, raw24 graphics is deliberately hidden and its draw/host-weapon routes no-op; original art/attack kernel remains lossless and separate. Existing UI/audio/HP/injury/death/real pickup/native block-emergence/combat eligibility and source hunger scene classification are NOT qualified here. Inherited component health policy is unchanged. No full campaign or ability claim. Raw25 and26+ retain legacy routes.
The earlier provisional a2e packet, foundation/Feet negatives and failed source-fixture/oracle attempts remain in this directory/one compact provisional archive. The zero-timer fixture legitimately died and was corrected to legal timer4; initial heldA was corrected to a real neutral/fresh-A edge. Original-query oracle corrections (realR6, unique read site, hex95 class) are retained. Release proof filenames alone bind this final hash; earlier files are historical.
Both freshly built ordinary hashes d444/f4ffd remain exact. Independent real ca65 full dependency closure and same-ROM relink required before this handoff. Future union must chain Rogue lifecycle foreign targets explicitly and regenerate everyE clone from final127, never overlay staleE data.
''')
 files=set(Path(z)for z in deps)|{p,p.with_suffix('.dbg'),p.with_suffix('.lbl'),O/'smb1base-mmc5-expanded.cfg',O/'source.patch',O/'final-controls.json',summary,Path(__file__),R/'tools/prepare_dragon_power_movement_v1.py',R/'build/dragon_power_movement_host_v1.inc',R/'tools/prepare_cv3_dmc_mirror.py',R/'tools/build_mmc5_expanded.py',R/'build/nr_router_compact_handoff_v1.json',R/'build/dragon-power-mixed-render-v3/handoff.json',parent,parent.with_suffix('.dbg'),parent.with_suffix('.lbl')}
 files.update(O/n for n in receipts);files.update(O.glob('*negative*.json'));files.update(O.glob('original-v*.json'));files.update(O.glob('controls-v*.json'));files.update(O.glob('consumers-v*.json'));files.add(O/'provisional-pre-foundation-v1.zip')
 files.update(R/'tools/audit'/n for n in['dragon_power_movement_controls_v1.py','dragon_power_movement_controls_v2.py','dragon_power_movement_consumers_v1.py','dragon_power_movement_consumers_v2.py','dragon_power_movement_original_v1.py','dragon_power_movement_original_v2.py','dragon_power_movement_original_v3.py','dragon_power_movement_original_v4.py'])
 for n in['mmc3','mmc5']:files.add(O/('ordinary-'+n+'.nes'))
 hand=dict(status='FROZEN_PRIVATE_SOURCE_CPU_MOVEMENT_ONLY_NOT_PLAYABLE_OR_NATIVE',candidate=binding(p),DBG=binding(p.with_suffix('.dbg')),LBL=binding(p.with_suffix('.lbl')),source_CPU_receipts=[binding(O/n)for n in receipts]+[binding(O/'final-controls.json')],actual_ASM_dependencies=deps,bindings={str(q.resolve()):sha(q)for q in sorted(files)},limits=summary.read_text(),owned_new_tools=[str(z.resolve())for z in files if str(z).startswith(str(R/'tools'))and 'dragon_power_movement'in z.name])
 for f,h in hand['bindings'].items():assert sha(f)==h
 (O/'handoff.json').write_text(json.dumps(hand,indent=2)+'\n');print(json.dumps(dict(handoff=binding(O/'handoff.json'),candidate=sha(p),bindings=len(files),ASM_dependencies=len(deps),core_bytes=size,remaining_CORE=6144-size)))
if __name__=='__main__':main()
