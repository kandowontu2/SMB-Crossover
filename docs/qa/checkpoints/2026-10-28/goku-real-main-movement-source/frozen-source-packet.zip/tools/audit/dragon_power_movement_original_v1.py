"""Frozen original component vs actual linked kernel/query; no native claims."""
from pathlib import Path
import argparse,hashlib,itertools,json,re,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools'),str(R/'tools/audit')]
import dragon_power_mixed_render_controls_v3 as T
from sunny_integrated_controls_v1 import scoped_load,address,location,sha
O=R/'build/dragon-power-movement-v1';M=R/'build/dragon-power-mixed-render-v3'
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();assert not a.output.exists()
 b=scoped_load(O/'candidate.nes');base=T.bundle(M);raw=b['raw'];line=next(x for x in (O/'candidate.map').read_text().splitlines()if x.startswith('DRAGON_POWER_CORE '));n=int(line.split()[3],16)
 cur=dict(base,code=raw[16+86*8192+0x800:16+86*8192+0x800+n]);proof=dict(passed=False,source_CPU_only=True,native_run=False,checks={});ck=proof['checks']
 try:
  for name,v in base['s'].items():
   if name.startswith('Dp')and name in b['syms']:assert address(b,name)==v,('old genuine Goku PC/state moved',name,hex(v),hex(address(b,name)))
  oldcode=base['code'];newcode=cur['code'];changed=[i for i,(x,y)in enumerate(zip(oldcode,newcode))if x!=y]
  allowed=set(range(base['s']['DpNEF77']-0xa800,base['s']['DpNEF77']-0xa800+3))
  query=base['s']['DpHostTileQuery']-0xa800
  # Original literal LDA(R6),Y / BEQ Empty occupies four real bytes.
  match=[i for i in range(query,query+220)if oldcode[i:i+2]==bytes.fromhex('b10a')]
  assert len(match)==1,match;allowed.update(range(match[0],match[0]+4));assert set(changed)<=allowed,(changed,sorted(allowed))
  ck['frozen_original_kernel_and_PC']=dict(original_core_prefix_bytes=len(oldcode),changed_offsets=changed,only_EF77_commit_and_four_byte_native_query_hook=True,all_original_Dp_addresses_exact=True)
  count=0;cost=[];intended=[]
  for tile,foundation in itertools.product(range(256),range(2)):
   outputs=[]
   for v in[base,cur]:
    m=T.Memory(v);s=m.s;m.ram[s['ScreenLeft_X_Pos']]=0
    m.ram[s['Block_Buffer_1']+0xb0+6]=tile;m.ram[s['MmSolidTerrain']+0xb0+6]=foundation
    c,tr,_=T.execute(m,s['DpHostTileQuery'],a=208,y=96,x=71,p=0x71)
    outputs.append((T.regs(c),m,c.processorCycles))
   old,now=outputs;expected=95 if tile in[0xc0,0xc1]or 0x55<=tile<0x5f else old[0][0]
   expectedP=(old[0][3]&0x7d)|(0x80 if expected&128 else 0)|(2 if expected==0 else 0)
   assert now[0]==(expected,old[0][1],old[0][2],expectedP,old[0][4]),('query AXYP/SP',tile,foundation,old[0],now[0],expected)
   expectedRAM=bytearray(old[1].ram);expectedRAM[base['s']['DpTileResult']]=expected
   assert expectedRAM[:256]==now[1].ram[:256]and expectedRAM[0x200:]==now[1].ram[0x200:],('query application RAM',tile,foundation)
   assert old[1].bank==now[1].bank
   cost.append(now[2]-old[2]);count+=1
   if expected!=old[0][0]:intended.append([tile,foundation,old[0][0],expected])
  ck['all_native_tiles_query_ABI']=dict(cases=count,all_application_RAM_except_precisely_changed_DpTileResult_exact=True,AXYP_SP_and_banks_exact_except_declared_source_class=True,source_class_changes=intended,CPU_delta=[min(cost),max(cost)])
  count=0;cost=[]
  for facing in[0,128]:
   pair=[T.Memory(v)for v in[base,cur]]
   for m in pair:
    T.put(m,Player_Y_Position=176,Player_X_Position=96,Player_Rel_XPos=96,Player_PageLoc=0,DpHorizontal=facing)
    for x in range(16):m.ram[m.s['Block_Buffer_1']+0xb0+x]=0x61
   for age in range(128):
    keys=(1 if facing==0 else 2)|(128 if 8<=age<15 or 64<=age<71 else 0)|(64 if 32<=age<35 or 90<=age<93 else 0)
    out=[]
    for m in pair:
     T.put(m,SavedJoypadBits=keys);c,_,_=T.execute(m,m.s['DpMovement']);out.append((T.regs(c),bytes(m.ram[:256])+bytes(m.ram[0x200:]),tuple(m.bank),c.processorCycles))
    assert out[0][:3]==out[1][:3],('complete source frame physics/clock/input',facing,age,out[0][0],out[1][0]);cost.append(out[1][3]-out[0][3]);count+=1
  ck['original_complete_movement_kernel']=dict(updates=count,full_AXYP_SP_application_banks_exact=True,genuine_original_jump_release_and_melee_source_clock=True,CPU_delta=[min(cost),max(cost)])
  proof['passed']=True
 except Exception as e:proof.update(failure=repr(e),traceback=traceback.format_exc())
 proof['bindings']={str(p.resolve()):sha(p)for p in[Path(__file__),Path(T.__file__),M/'handoff.json',M/'component.bin',M/'component.dbg',O/'candidate.nes',O/'candidate.dbg',O/'candidate.map']}
 a.output.write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(dict(passed=proof['passed'],failure=proof.get('failure'),checks=list(ck))));assert proof['passed']
if __name__=='__main__':main()
