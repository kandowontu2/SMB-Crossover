; PRIVATE additive menu/lives endpoints; source gameplay/audio are unchanged.
; A118 and C80 occupy only the previously measured remainder of their leases.
.pushseg
.segment "PARODIUS_BELLS"
.export S2MenuResolve,S2MenuName,S2MenuStatus,S2MenuPortrait,S2MenuToggle
S2MenuCodeBegin:
.proc S2MenuResolve
 ; Preserve the actual former owner on the stack, not a global overlay flag.
 ; CmHostResolve defines X itself. Recover its genuine incoming A unchanged.
 pha
 lda SelectedCharacter
 pha
 tsx
 lda $0102,x
 farcall CmHostResolveCharacter
 php
 pha
 cmp #25
 bne Done
 phx
 phy
 tsx
 lda $0105,x                    ; actual previous SelectedCharacter, before resolve.
 cmp #25
 bne Cold
 jsr S2Ensure                   ; same owner/variant may preserve Continue rewards.
 jmp Restored
Cold:jsr S2ColdInit              ; new selection precedes EVERY Ready read.
Restored:
 ply
 plx
Done:pla
 plp
 pla
 pla
 lda SelectedCharacter          ; exact original resolver's returned A/N/Z.
 rts
.endproc
.proc S2MenuName
 php
 pha
 lda SelectedCharacter
 cmp #25
 beq Own
 pla
 plp
 farcall NrQueueSelectName,jmp
Own:
 pla
 plp
 jsr S2GraphicsBank
 jmp S2MenuNameC
.endproc
.proc S2MenuToggle
 php
 pha
 lda SelectedCharacter
 cmp #25
 beq Own
 pla
 plp
 farcall NrMenuToggle,jmp
Own:pla
 plp
 lda CrossoverMenuPressed
 and #Select_Button
 beq No
 inc S2Variant
 lda S2Variant
 and #3
 sta S2Variant
 sec
 rts
No:clc
 rts
.endproc
.proc S2MenuStatus
 php
 pha
 lda SelectedCharacter
 cmp #25
 beq Own
 pla
 plp
 farcall JnStatusName,jmp
Own:pla
 bne Done
 phx
 phy
 jsr S2GraphicsBank
 ldx #11
 lda #7
 sta R0
 jsr S2MenuCopyC
 ply
 plx
 lda #0
Done:plp
 rts
.endproc
.proc S2MenuPortrait
 jsr S2Ensure
 jsr S2GraphicsBank
 lda S2NativeCharacter
 asl
 ora S2Size
 .repeat 5
 asl
 .endrepeat
 ora #1                        ; authentic standing, unheld, source-facing1.
 tax
 lda S2BodyRecord,x
 jsr S2Graphics::SetBody         ; genuine shared descriptor/CHR tail, no copy.
 jsr S2PublishBody              ; actual X5PortraitRender consumes this record.
 lda #$ff
 sta S2PaletteAck
 jmp S2MainPalette
.endproc
S2MenuCodeEnd:
.assert *<=$c000,lderror,"SMB2 menu exceeds remaining CORE118 lease"
.segment "KIRBY_ABILITIES"
S2MenuGlobalBegin:
.proc S2MenuGlobal
 lda #0
 sta S2Variant                 ; dedicated selector, never overlay Ready.
 farcall IcGlobalInit,jmp
.endproc
S2MenuGlobalEnd:
.assert *<=$c000,lderror,"SMB2 menu exceeds remaining A74 lease"
.segment "CD_GFX"
S2MenuArtBegin:
.proc S2MenuNameC
 ldx VRAM_Buffer1_Offset
 cpx #65                       ; 19-byte command plus terminator within84B.
 bcs Done
 stx R1
 lda #$23
 sta VRAM_Buffer1,x
 lda #<X5MenuNameAddress
 sta VRAM_Buffer1+1,x
 lda #16
 sta VRAM_Buffer1+2,x
 lda #$24
 ldy #15
Blank:sta VRAM_Buffer1+3,x
 inx
 dey
 bpl Blank
 ldx R1
 txa
 clc
 adc #7
 tax
 lda #8
 sta R0
 jsr S2MenuCopyC
 txa
 clc
 adc #4
 tax
 stx VRAM_Buffer1_Offset
 lda #0
 sta VRAM_Buffer1,x
Done:rts
.endproc
.proc S2MenuCopyC
 ; Genuine A118 caller explicitly leases C80 before this direct JSR.
 lda S2Variant
 and #3
 asl
 asl
 asl
 tay
Loop:lda Names,y
 sta VRAM_Buffer1,x
 inx
 iny
 dec R0
 bne Loop
 rts
Names:.byte "MARIO   ","LUIGI   ","TOAD    ","PEACH   "
.endproc
S2MenuArtEnd:
.assert *<=$d600,lderror,"SMB2 menu exceeds remaining C80 lease"
.popseg
