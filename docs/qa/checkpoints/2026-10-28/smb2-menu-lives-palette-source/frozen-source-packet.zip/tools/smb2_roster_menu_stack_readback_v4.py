"""Additive exact stack readback/erratum; never changes frozen menu packet."""
import json
import smb2_roster_menu_controls_v4 as V
B=V.B;O=V.O

def main():
 handoff=B.bind(O/'handoff.json');b=V.C.scoped_load(O/'candidate.nes');rows=[]
 for mode in[0,1]:
  q=V.menu(b);q.put(CrossoverBehaviorVersion=mode);V.run(q,'NrGlobalInit')
  for key in[4,4,4,1,32,32,32,32,64]:
   for mask in[0,key]:
    q.put(VRAM_Buffer1_Offset=0,VRAM_Buffer2_Offset=0,SavedJoypad1Bits=mask,SavedJoypad2Bits=0)
    c,t,low=V.run(q,'CrossoverMenuInput')
    rows.append(dict(context='actual menu input',mode=mode,mask=mask,slot=q.get('CrossoverMenuIndex'),SP_min=low,SP_return=c.sp))
 for variant in range(4):
  for entry in['DrawSelectionPreview','DisplayIntermediate']:
   q=V.menu(b);q.put(CrossoverMenuIndex=24,S2Variant=variant);V.run(q,'MenuResolveCharacter')
   q.put(OperMode=0 if entry=='DrawSelectionPreview'else 1,DisableIntermediate=0,AltEntranceControl=0,CurrentOAMOffset=0)
   c,t,low=V.run(q,entry,a=91,x=17,y=23,p=0x71)
   rows.append(dict(context=entry,variant=variant,SP_min=low,SP_return=c.sp))
 d=dict(passed=True,source_CPU_only=True,native=False,original_handoff=handoff,original_controls=B.bind(O/'menu-controls.json'),
  correction='The original controls top-level minimum_SP253 records the post-return SP, not the minimum during complete calls. It is not a stack-depth claim. This additive readback supplies the actual complete-call minimum. The original323 IRQ snapshots/minimum224 are unchanged.',
  actual_complete_call_minimum_SP=min(x['SP_min']for x in rows),rows=rows,
  retained_additional_link_negative=dict(actual_console_first_error="src/smb2_roster_menu_v4.s:113: Error: Symbol 'SetBody' is undefined",cause='ca65 nested includes resolved from ROOT/src/smb2_roster.s before sparse renderer/art descendants; fixed by new sparse include-owner. Actual source closure now binds489 consumed dependencies. No failed-link candidate or later old-image control was accepted as the successor.'),
  bindings=[B.bind(p)for p in[__file__,V.__file__,O/'candidate.nes',O/'candidate.dbg',O/'handoff.json']])
 dest=O/'stack-and-negative-addendum.json';assert not dest.exists();dest.write_text(json.dumps(d,indent=2)+'\n')
 print(json.dumps(dict(addendum=B.bind(dest),actual_complete_call_minimum_SP=d['actual_complete_call_minimum_SP'])))
if __name__=='__main__':main()
