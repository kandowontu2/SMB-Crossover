"""Freeze the small private SMB2 menu/lives/area-role component."""
from pathlib import Path
import collections,difflib,json,re,subprocess,sys
import prepare_smb2_roster_menu_v4 as B
import smb2_roster_menu_controls_v4
R=B.ROOT;O=B.OUT;bind=B.bind

def main():
 build=json.loads((O/'build-proof.json').read_text());tests=json.loads((O/'menu-controls.json').read_text())
 assert build['candidate']==bind(O/'candidate.nes')==tests['candidate'] and tests['passed']
 assert build['tool']==bind(B.__file__)
 for row in build['new_owned_sources']:assert bind(row['path'])==row
 old=json.loads((B.OLD/'source-closure.json').read_text());cmd=old['command'].copy()
 cmd[cmd.index('--create-full-dep')+1]=str(O/'source-closure.d');cmd[cmd.index('-o')+1]=str(O/'source-closure.o');cmd[-1]=str(O/'objects/entrypoint.s')
 cmd[4:4]=['-I',str(O/'overlay/src')]
 p=subprocess.run(cmd,cwd=R,capture_output=True,text=True);(O/'source-closure-launcher.txt').write_text(p.stdout+p.stderr);assert not p.returncode,p.stderr
 line=(O/'source-closure.d').read_text().splitlines()[0].split(':\t',1)[1]
 deps={Path(x.replace('\\ ',' ')).resolve()for x in re.split(r'(?<!\\)\s+',line.strip())}
 for row in build['new_owned_sources']:assert Path(row['path']).resolve()in deps,('not consumed',row['path'])
 assert O/'menu-label.bin'in deps
 inputs=deps|{Path(sys.executable),O/'objects/asset.s',O/'smb2-roster-native-area.chr',B.OLD/'overlay/smb1base-mmc5-expanded.cfg',Path(__file__),Path(B.__file__),R/'tools/smb2_roster_menu_controls_v4.py'}
 for row in old['input_bindings']:
  p=Path(row['path'])
  if p.suffix.lower()in['.exe','.dll','.ini','.cfg','.lib']:assert bind(p)==row;inputs.add(p)
 for m in sys.modules.values():
  p=getattr(m,'__file__',None)
  if p:
   p=Path(p).resolve()
   if p.suffix=='.py'and(p.is_relative_to(R)or'py65'in p.parts):inputs.add(p)
 # Ordinary output does not consume expanded descendants. Freshly compile
 # both flag-off configurations with the new sparse shared overlay nonetheless.
 ordinary=[]
 for mode in['mmc3','mmc5']:
  out=O/('flagoff-'+mode+'.nes')
  c=[sys.executable,str(R/'tools/build_mmc5_expanded.py'),'--source-overlay',str(O/'overlay'),'--output',str(out),'--flag-off',mode]
  p=subprocess.run(c,cwd=R,capture_output=True,text=True);(O/('flagoff-'+mode+'-launcher.txt')).write_text(p.stdout+p.stderr);assert not p.returncode,p.stderr[-2000:]
  ref=B.OLD/('flagoff-'+mode+'.nes');assert out.read_bytes()==ref.read_bytes()
  ordinary.append(dict(mapper=mode,actual=bind(out),reference=bind(ref)))
 patch=''
 for p in sorted((O/'overlay/src').glob('*')):
  q=B.OLD/'overlay/src'/p.name
  if not q.exists():q=R/'src'/p.name
  patch+=''.join(difflib.unified_diff(q.read_text().splitlines(True),p.read_text().splitlines(True),fromfile='cd83/src/'+p.name,tofile='menu-v4/src/'+p.name))
 leaf=R/'src/smb2_roster_menu_v4.s';patch+=''.join(difflib.unified_diff([],leaf.read_text().splitlines(True),fromfile='/dev/null',tofile='menu-v4/src/'+leaf.name))
 (O/'implementation.patch').write_text(patch,newline='\n')
 a=Path(build['parent']['path']).read_bytes();z=(O/'candidate.nes').read_bytes();by=collections.Counter((i-16)//8192 for i,(x,y)in enumerate(zip(a,z))if x!=y and i<16+1048576)
 for bank,lo,hi in[(124,0xd9b,0x2000),(127,0,8192),(126,0,8192),(74,0x1180,0x1fe3),(118,0,0x1f06)]:
  off=16+bank*8192;assert a[off+lo:off+hi]==z[off+lo:off+hi],('protected',bank,lo,hi)
 source=dict(passed=True,source_CPU_only=True,native=False,candidate=build['candidate'],parent=build['parent'],command=cmd,actual_ASM_dependencies=len(deps),actual_changed_PRG_bytes=dict(by),ordinary=ordinary,
  all_prior_symbol_locations_exact=tests['checks']['old_compiled_symbols'],protected_root_Rogue_Goku_resident_audio_Main_bytes_exact=True,
  input_bindings=[bind(p)for p in sorted(inputs)],tool=bind(__file__))
 (O/'source-closure.json').write_text(json.dumps(source,indent=2)+'\n')
 owned=[Path(B.__file__),Path(__file__),R/'tools/smb2_roster_menu_controls_v4.py',leaf,R/'docs/qa/smb2-roster-menu-source-2026-10-29.txt',O/'implementation.patch']+list((O/'overlay/src').glob('*'))
 outputs=[p for p in O.iterdir()if p.is_file()and p.name!='handoff.json']+list((O/'objects').glob('*'))
 h=dict(status='PRIVATE_MENU_LIVES_AREA_PALETTE_SOURCE_CPU_IRQ_PASS_NO_NATIVE_NO_ADMISSION',candidate=build['candidate'],parent=build['parent'],parent_handoff=build['parent_handoff'],source=bind(O/'source-closure.json'),controls=bind(O/'menu-controls.json'),
  owned_files=[bind(p)for p in sorted(owned)],input_bindings=source['input_bindings'],output_bindings=[bind(p)for p in sorted(outputs)],
  scope_note=bind(R/'docs/qa/smb2-roster-menu-source-2026-10-29.txt'),open=['Main-play health/vegetable-reserve HUD; CORE118 now full','Actual native held-enemy room transfer; cheats admission','Native NmiClock/atomic cues/mixer/DMC ownership and all native qualification','Final Root dispatch/menu/capsule union with Rogue/Goku/Kamikaze'])
 (O/'handoff.json').write_text(json.dumps(h,indent=2)+'\n');print(json.dumps(dict(handoff=bind(O/'handoff.json'),ASMdeps=len(deps),inputs=len(inputs),PRGdiff=dict(by)),indent=2))
if __name__=='__main__':main()
