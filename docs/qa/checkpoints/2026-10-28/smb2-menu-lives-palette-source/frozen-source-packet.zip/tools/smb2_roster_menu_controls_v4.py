"""Finite assembled SMB2 menu/lives/area-role controls; never native proof."""
from pathlib import Path
import collections,itertools,json,sys,traceback
import prepare_smb2_roster_menu_v4 as B
import smb2_roster_main_controls_v2 as T
import smb2_roster_main_callers_v2 as C
from sunny_integrated_controls_v1 import registers,app,cleanwrites
R=B.ROOT;O=B.OUT

def run(q,name,a=0,x=0,y=0,p=0x30,probe=None):
 pc,bank=C.key(q.b,name);window=(pc-0x8000)//8192;q.m.page(window,bank)
 if window in[1,2]:q.set('CurrentBank'if window==1 else'CurrentBankC',bank|128)
 c=T.NesMPU(memory=q.m,pc=pc);c.a,c.x,c.y,c.p,c.sp=a,x,y,p,253;c.stPushWord(0x5aff)
 q.m.writes=[];trace=[];low=c.sp
 for _ in range(300000):
  if c.pc==0x5b00:assert c.sp==253;return c,trace,low
  if probe:probe(c,q)
  pc=c.pc;bk=q.m.banks[(pc-0x8000)//8192]if pc>=0x8000 else-1;at=len(q.m.writes)
  c.step();low=min(low,c.sp)
  trace.extend(dict(pc=pc,bank=bk,address=adr,value=v)for adr,v in q.m.writes[at:])
 raise AssertionError(('CPU timeout',name,hex(c.pc)))

def encoded(s):return bytes(36 if x==' ' else '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'.index(x)for x in s)
NAMES=['MARIO   ','LUIGI   ','TOAD    ','PEACH   ']
def getbytes(q,name,n):return bytes(q.m[C.address(q.b,name):C.address(q.b,name)+n])
def menu(b,raw=0):
 q=C.make(b,raw)
 q.put(OperMode=0,OperMode_Task=1,CrossoverMenuState=2,CrossoverMenuIndex=0,
  CrossoverMenuButtons=0,VRAM_Buffer1_Offset=0,VRAM_Buffer2_Offset=0,
  Mirror_PPUMASK=0,NmiDisable=255,AreaType=1,Player_PageLoc=0,ScreenLeft_PageLoc=0)
 return q
def poll(q,mask):
 # Explicit source service boundary: previous queue has been consumed.
 # No native PPU/cadence claim is attached to this controlled CPU campaign.
 q.put(VRAM_Buffer1_Offset=0,VRAM_Buffer2_Offset=0,SavedJoypad1Bits=mask,SavedJoypad2Bits=0)
 return run(q,'CrossoverMenuInput')
def click(q,mask):poll(q,0);return poll(q,mask)

def main():
 build=json.loads((O/'build-proof.json').read_text())
 assert B.bind(O/'candidate.nes')==build['candidate'] and B.bind(B.__file__)==build['tool']
 for row in build['new_owned_sources']:assert B.bind(row['path'])==row
 b=C.scoped_load(O/'candidate.nes');old=C.scoped_load(B.OLD/'candidate.nes')
 ck={};proof=dict(passed=False,source_CPU_only=True,native=False,candidate=B.bind(O/'candidate.nes'),checks=ck);minimum=255
 try:
  # Complete old symbol addresses/physical locations, not just exported names.
  stable=0
  for n,s in old['syms'].items():
   if 'seg' not in s or n not in b['syms']:continue
   if 'ooffs'not in old['segs'][s['seg']]:
    assert C.address(old,n)==C.address(b,n),('old RAM symbol moved',n);continue
   assert C.key(old,n)==C.key(b,n),('old linked symbol moved',n);stable+=1
  ck['old_compiled_symbols']=stable
  raw0=old['raw'];raw1=b['raw'];diff=[i for i,(a,z)in enumerate(zip(raw0,raw1))if a!=z]
  assert raw0[:16]==raw1[:16]
  assert {((i-16)//8192)for i in diff if i<16+1048576} == {66,74,80,118,124}
  assert raw0[16+127*8192:16+128*8192]==raw1[16+127*8192:16+128*8192]
  ck['ROM_delta']=dict(bytes=len(diff),PRG_banks=sorted({(i-16)//8192 for i in diff if i<16+1048576}),CHR_pages=sorted({(i-16-1048576)//1024 for i in diff if i>=16+1048576}))
  # Assert actual linked art records and every CHR pixel class, not merely the
  # generated source text. Native area palette roles remain owned by SMB.
  original=(R/'chr/characters/smb2-roster.chr').read_bytes();adapted=(O/'smb2-roster-native-area.chr').read_bytes();pixels=0
  chr_at=16+1048576+796*1024;assert bytes(raw1[chr_at:chr_at+12288])==adapted
  for off in range(0,len(original),16):
   for y in range(8):
    for x in range(8):
     bit=7-x;a=(original[off+y]>>bit&1)|((original[off+y+8]>>bit&1)<<1)
     z=(adapted[off+y]>>bit&1)|((adapted[off+y+8]>>bit&1)<<1)
     expect=a
     if off//1024<8 and off%1024 in[896,912]:
      assert a in[0,1];expect=[0,2][a]
     elif 8192<=off<8288:expect=[0,2,3,1][a]
     assert z==expect and bool(a)==bool(z),(off,y,x,a,z,expect);pixels+=1
  for n in range(73):
   at=C.location(old,'S2Art'+str(n));size=old['raw'][at]+1
   before=bytes(old['raw'][at:at+size]);after=bytes(b['raw'][at:at+size]);want=bytearray(before)
   if n>=70:
    for j in range(2,len(want),4):assert want[j]&3==1;want[j]=(want[j]&252)|3
   assert after==want,('actual linked record',n)
  ck['exact_pixel_class_mask_and_linked_records']=dict(pixels=pixels,records=73,body_records_byteexact=70,vegetable_records_only_palette_bits_changed=3,new_OAM_parts=0,palette_writes_added=0)
  # Actual same-caller foreign outputs, nonstack RAM, banks and allSMC strict.
  rows=[]
  for raw,flag,entry,a in itertools.product([0,1,2,3,4,5,8,9,14,15,16,17,18,19,20,21,23,24],[0x30,0x71],['QueueSelectName','MenuResolveCharacter','NrStatusName','CrossoverMenuInput'],[0,1]):
   oldentry=entry
   qs=[menu(z,raw)for z in[old,b]]
   for q in qs:q.put(CrossoverMenuIndex=0,CrossoverMenuPressed=32,MarioVariant=0,SavedJoypad1Bits=32,SavedJoypad2Bits=0)
   cs=[];ts=[]
   for i,q in enumerate(qs):
    c,w,_=run(q,oldentry if i==0 else entry,a=a,x=3,y=6,p=flag);cs.append(c);ts.append(w)
   # The source endpoint may be direct in this leaf case; same incoming
   # mapping is established by the real entry's physical owner.
   C.same_live(qs,cs,('foreign menu',raw,flag,entry,a),ts)
   rows.append(dict(raw=raw,P=flag,entry=entry,A=a,CPU_delta=cs[1].processorCycles-cs[0].processorCycles))
  ck['foreign_same_caller']=dict(cases=len(rows),CPU_delta=[min(x['CPU_delta']for x in rows),max(x['CPU_delta']for x in rows)])
  # Real menu input, resolver and portrait path. All overlaid state is dirty
  # before selecting raw25; marker is deliberately a stale matching byte.
  menus=[]
  for mode in[0,1]:
   q=menu(b);q.put(CrossoverBehaviorVersion=mode)
   run(q,'NrGlobalInit');assert q.get('S2Variant')==0
   q.m[0x5c00:0x5c80]=bytes([0xa5])*128;q.m[0x5f98:0x5fa0]=bytes([0xb2])*8
   for key in[4,4,4,1]:click(q,key)
   assert q.get('CrossoverMenuIndex')==24 and q.get('SelectedCharacter')==25
   assert q.get('S2Ready')==0xb2 and q.get('S2Health')==31 and q.get('S2MaxHealth')==q.get('S2Vegetables')==0
   for variant in range(4):
    assert q.get('S2Variant')==variant and q.get('S2NativeCharacter')==[0,3,2,1][variant]
    p=getbytes(q,'VRAM_Buffer1',q.get('VRAM_Buffer1_Offset')+1)
    assert encoded('    '+NAMES[variant]+'    ')in p,('actual name',variant,list(p))
    assert q.get('ObjectMetasprite')==C.address(b,'METASPRITE_SAMUS_BODY')
    assert q.get('CurrentOAMOffset')>0 and q.m.banks[2]==80
    menus.append(dict(mode=mode,variant=variant,native=q.get('S2NativeCharacter'),OAMbytes=q.get('CurrentOAMOffset'),queue=list(p)))
    c,w,_=click(q,32);minimum=min(minimum,c.sp)
   assert q.get('S2Variant')==0
   # Genuine B exits to title, then reentry retains the valid selector.
   click(q,64);assert q.get('CrossoverMenuState')==0
   q.put(CrossoverTitleDrawn=1,CrossoverOptionsFocus=0);click(q,16)
   assert q.get('CrossoverMenuState')==1
  ck['actual_input_resolve_Select_portrait_B_return']=menus
  # Actual reward writers, then a same-owner Options/Continue resolve. A
  # changed variant and genuine FreshGame still initialize the proper owner.
  lifecycle=[]
  for variant in range(4):
   q=menu(b);q.put(CrossoverMenuIndex=24,S2Variant=variant)
   run(q,'MenuResolveCharacter');run(q,'S2GiveItem',a=0);run(q,'S2GiveItem',a=1)
   resource=getbytes(q,'S2Health',3);assert resource==bytes([47,1,3])
   q.put(CrossoverContinue=1);run(q,'MenuResolveCharacter')
   assert getbytes(q,'S2Health',3)==resource
   run(q,'NrFreshGameInit');assert getbytes(q,'S2Health',3)==bytes([31,0,0])
   assert q.get('S2Variant')==variant and q.get('S2NativeCharacter')==[0,3,2,1][variant]
   lifecycle.append(dict(variant=variant,actual_Mushroom_Flower=[47,1,3],same_owner_continue_retained=True,fresh_game=[31,0,0]))
  ck['actual_reward_same_owner_continue_fresh_lifecycle']=lifecycle
  # Every present node is reachable and all navigation targets are present.
  a={n:list(b['raw'][C.location(b,n):C.location(b,n)+28])for n in['X5MenuPresent','X5MenuLeft','X5MenuRight','X5MenuUp','X5MenuDown']}
  seen={0};todo=[0]
  while todo:
   n=todo.pop()
   for key in list(a)[1:]:
    j=a[key][n];assert a['X5MenuPresent'][j],(n,key,j)
    if j not in seen:seen.add(j);todo.append(j)
  assert seen=={i for i,v in enumerate(a['X5MenuPresent'])if v};ck['actual_table_BFS']=sorted(seen)
  # Seven-cell name patch must preserve following WORLD/lives fields andAXYP.
  n=0
  for variant,a,flag in itertools.product(range(4),[0,1,2,3,255],[0x30,0x31,0x70,0x71]):
   q=menu(b,25);q.put(S2Variant=variant);at=C.address(b,'VRAM_Buffer1');q.m[at:at+84]=bytes([0x59])*84
   c,w,_=run(q,'NrStatusName',a=a,x=17,y=23,p=flag)
   expected=bytearray([0x59]*84)
   if a==0:expected[11:18]=encoded(NAMES[variant][:7])
   assert getbytes(q,'VRAM_Buffer1',84)==expected
   # Genuine outer farcall restores A with LDA, defining native N/Z.
   expected_P=(flag&0x4d)|(a&0x80)|(2 if a==0 else 0)
   assert (c.a,c.x,c.y,c.p&0xcf)==(a,17,23,expected_P),(variant,a,flag,registers(c))
   n+=1
  ck['status_name_canaries_AXYP']=n
  # A full native menu/lives renderer prepares original standing record and
  # actual physical high3 body publication. No direct OAM painter is used.
  rows=[]
  for variant,entry in itertools.product(range(4),['DrawSelectionPreview','DisplayIntermediate']):
   q=menu(b,25);q.put(S2Variant=variant);run(q,'S2ColdInit')
   resource=getbytes(q,'S2Health',8);q.put(OperMode=0 if entry=='DrawSelectionPreview'else 1,DisableIntermediate=0,AltEntranceControl=0,CurrentOAMOffset=0)
   c,w,_=run(q,entry,a=91,x=17,y=23,p=0x71)
   assert getbytes(q,'S2Health',7)==resource[:7] # PaletteAck legitimately changes.
   assert q.get('CurrentOAMOffset')>=16 and q.m.banks[2]==80
   assert q.get('SmChrBank')==([0,3,2,1][variant]*2+28)&255
   assert q.get('X5ChrMode',0)==131 and q.get('CurrentCHRBank',0)==q.get('SmChrBank')
   rows.append(dict(variant=variant,caller=entry,OAMbytes=q.get('CurrentOAMOffset'),CHR=q.get('SmChrBank'),cycles=c.processorCycles))
  ck['actual_full_menu_lives_render']=rows
  # Queue capacity decline preserves packet+offset; no acknowledged false name.
  for off in[64,65,83,255]:
   q=menu(b,25);q.put(S2Variant=3,VRAM_Buffer1_Offset=off);at=C.address(b,'VRAM_Buffer1');q.m[at:at+256]=bytes([0x59])*256
   before=bytes(q.m[at:at+256]);run(q,'QueueSelectName')
   if off>=65:assert bytes(q.m[at:at+256])==before and q.get('VRAM_Buffer1_Offset')==off
   else:assert q.get('VRAM_Buffer1_Offset')==83 and q.m[at+83]==0
  ck['name_capacity']=dict(accepted_max=64,rejected=[65,83,255])
  # Finite unchanged complete Main execution; the private menu wrappers are
  # cold endpoints, not a new per-enemy or per-frame gate.
  rows=[]
  for variant,mode in itertools.product(range(4),[0,1]):
   qs=[T.arena(z,variant,mode)for z in[old,b]]
   for tick,mask in enumerate([0,1,1,129,129,129,1,1,0,0,64,0]):
    cs=[];ts=[]
    for q in qs:c,t=T.frame(q,mask);cs.append(c);ts.append(t)
    C.same_live(qs,cs,('owned completeMain',variant,mode,tick),ts)
    assert cs[0].processorCycles==cs[1].processorCycles
    rows.append(cs[1].processorCycles)
  ck['unchanged_owned_whole_Main']=dict(calls=len(rows),CPU_delta=0,cycles=[min(rows),max(rows)])
  # Genuine IRQ at reached new endpoint + shared SMC boundaries. Every IRQ
  # runs in an independent exact CPU/RAM/mapper snapshot of the actual call.
  irqs=[];visited=set()
  def probe(c,q):
   if c.p&4:return
   bank=q.m.banks[(c.pc-0x8000)//8192]if c.pc>=0x8000 else-1
   wanted=(bank==118 and C.address(b,'S2MenuCodeBegin')<=c.pc<C.address(b,'S2MenuCodeEnd'))or(bank==80 and C.address(b,'S2MenuArtBegin')<=c.pc<C.address(b,'S2MenuArtEnd'))or 0x15a<=c.pc<0x17b
   key=(c.pc,bank,c.sp)
   if not wanted or key in visited:return
   visited.add(key);fork=T.Arena(b,25);list.__setitem__(fork.m,slice(None),bytes(q.m));fork.m.banks=q.m.banks.copy()
   fc=T.NesMPU(memory=fork.m,pc=c.pc);fc.a,fc.x,fc.y,fc.p,fc.sp=c.a,c.x,c.y,c.p,c.sp
   low=C.interrupt(fc,fork);irqs.append(dict(PC=c.pc,bank=bank,SP=c.sp,minimum_SP=low))
  for variant in range(4):
   q=menu(b);q.put(CrossoverMenuIndex=24,S2Variant=variant)
   for entry in['MenuResolveCharacter','QueueSelectName','NrStatusName','DrawSelectionPreview','DisplayIntermediate']:
    if entry=='DisplayIntermediate':q.put(OperMode=1,DisableIntermediate=0,AltEntranceControl=0)
    run(q,entry,probe=probe)
  ck['actual_IRQ_endpoint_and_farcall_seams']=dict(contexts=len(irqs),minimum_SP=min(x['minimum_SP']for x in irqs),rows=irqs)
  proof.update(passed=True,minimum_SP=minimum,limits=['Source CPU/menu arenas only, prior queue consumption explicitly supplied between polls; no native menu/NMI/PPU/cadence evidence.','No raw25 source NMI/audio scheduler/mixer/cue publication admission.','Native P1/P3 area-shading adaptation, not all-area original RGB equality.'])
 except BaseException as e:
  proof.update(error=repr(e),traceback=traceback.format_exc())
  with(O/'control-negatives.jsonl').open('a')as f:f.write(json.dumps(dict(candidate=proof['candidate'],error=repr(e),traceback=traceback.format_exc()))+'\n')
  raise
 finally:(O/'menu-controls.json').write_text(json.dumps(proof,indent=2)+'\n')
 print(json.dumps(dict(passed=True,sections=len(ck),proof=B.bind(O/'menu-controls.json'))))
if __name__=='__main__':main()
