"""Small private menu/lives/P1 successor of frozen cd83; no native launch."""
from pathlib import Path
import json,re,subprocess,sys,hashlib
import prepare_smb2_roster_main_fast_v3 as F
ROOT=F.ROOT;OLD=F.OUT;OUT=ROOT/'build/smb2-roster-menu-v4';bind=F.bind
PARENT='483e2184fe9cd2c90f648474983dfff7587f7a33d5878b56ef95dda6914ff206'

def replace(t,a,b,n=1):
 assert t.count(a)>=n,(a,t.count(a));return t.replace(a,b,n)

def assets():
 old=ROOT/'chr/characters/smb2-roster.chr';b=bytearray(old.read_bytes());changes=[]
 def remap(at,table,tag):
  before=bytes(b[at:at+32]);after=bytearray(32)
  for half in [0,16]:
   for y in range(8):
    for x in range(8):
     bit=7-x;c=(before[half+y]>>bit&1)|((before[half+y+8]>>bit&1)<<1)
     c=table[c];after[half+y]|=(c&1)<<bit;after[half+y+8]|=(c>>1)<<bit
  assert all(bool(before[h+y]&(1<<x) or before[h+y+8]&(1<<x))==bool(after[h+y]&(1<<x) or after[h+y+8]&(1<<x)) for h in [0,16]for y in range(8)for x in range(8))
  b[at:at+32]=after
  changes.append(dict(kind=tag,offset=at,old=hashlib.sha256(before).hexdigest(),new=hashlib.sha256(after).hexdigest()))
 for page in range(8):remap(page*1024+56*16,[0,2,2,3],'eye-source-white-to-native-P1-highlight')
 for pair in range(3):remap(8192+pair*32,[0,2,3,1],'vegetable-native-P3-highlight-accent-shadow')
 dest=OUT/'smb2-roster-native-area.chr';dest.write_bytes(b)
 art=(ROOT/'src/smb2_roster_art.inc').read_text()
 for n in [70,71,72]:
  pattern=rf'(S2Art{n}: \.byte )([^\n]+)';m=re.search(pattern,art);v=list(map(int,m[2].split(',')))
  for p in range(2,len(v),4):assert v[p]&3==1;v[p]=(v[p]&0xfc)|3
  art=art[:m.start()]+m[1]+','.join(map(str,v))+art[m.end():]
 (OUT/'overlay/src/smb2_roster_art.inc').write_text(art,newline='\n')
 return dict(original=bind(old),adapted=bind(dest),pattern_transforms=changes,
  class_contract='Original opaque masks/positions/records unchanged; eye index2 uses native P1 white/highlight, vegetables use native P3 area highlight/accent/shadow. Not original RGB equality across areas.')

def main():
 assert bind(OLD/'handoff.json')['sha256']==PARENT
 h=json.loads((OLD/'handoff.json').read_text())
 for k in ['owned_files','input_bindings','output_bindings']:
  for r in h[k]:assert bind(r['path'])==r,r['path']
 OUT.mkdir(exist_ok=True);ov=OUT/'overlay';(ov/'src').mkdir(parents=True,exist_ok=True)
 nr=(OLD/'overlay/src/new_roster_dispatch.s').read_text()
 nr=replace(nr,'NrPortrait,IcPortrait,RcPortrait,SunnyPortrait,JnPortraitDispatch,JnPortraitDispatch,97',
                'NrPortrait,IcPortrait,RcPortrait,SunnyPortrait,JnPortraitDispatch,S2MenuPortrait,97')
 nr=replace(nr,'farcall JnStatusName,jmp','farcall S2MenuStatus,jmp')
 nr=replace(nr,'farcall IcGlobalInit\n farcall SunnyGlobalInit,jmp','farcall S2MenuGlobal\n farcall SunnyGlobalInit,jmp')
 (ov/'src/new_roster_dispatch.s').write_text(nr,newline='\n')
 render=(ROOT/'src/smb2_roster_render.s').read_text()
 render=replace(render,' lda S2BodyRecord,x\n jsr S2SetRecord',' lda S2BodyRecord,x\nSetBody:\n jsr S2SetRecord')
 (ov/'src/smb2_roster_render.s').write_text(render,newline='\n')
 # ca65 resolves nested includes relative to their actual containing source.
 # This sparse include owner ensures the two owned descendants are consumed.
 (ov/'src/smb2_roster.s').write_bytes((ROOT/'src/smb2_roster.s').read_bytes())
 # Actual character select/lives machinery stays in place; only genuine calls
 # to cold resolve/name producers receive an owner-gated private endpoint.
 cs=(ROOT/'src/character_select.s').read_text()
 cs=replace(cs,'farcall CmHostResolveCharacter,jmp','farcall S2MenuResolve,jmp')
 cs=replace(cs,'farcall NrQueueSelectName,jmp','farcall S2MenuName,jmp')
 cs=replace(cs,'farcall NrMenuToggle','farcall S2MenuToggle')
 cs=replace(cs,'.incbin "chr/raw/roster-expansion-menu.bin"','.incbin "build/smb2-roster-menu-v4/menu-label.bin"')
 (ov/'src/character_select.s').write_text(cs,newline='\n')
 # A clear native-font label occupies the existing vacant two-by-two cell.
 # The large standing preview is actual original SMB2 art, not this label.
 grid=bytearray((ROOT/'chr/raw/roster-expansion-menu.bin').read_bytes())
 for y,x,letter in [(17,15,'S'),(17,16,'M'),(18,15,'B'),(18,16,'2')]:
  assert grid[y*32+x]==36;grid[y*32+x]='0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'.index(letter)
 (OUT/'menu-label.bin').write_bytes(grid)
 menu=(ROOT/'src/roster_expansion_menu.inc').read_text()
 arrays={}
 for m in re.finditer(r'(X5Menu\w+):\n \.byte ([^\n]+)',menu):arrays[m[1]]=list(map(int,m[2].split(',')))
 for key,index,value in [('X5MenuCharacters',24,25),('X5MenuPresent',24,1),
  ('X5MenuLeft',22,24),('X5MenuRight',22,24),('X5MenuLeft',24,22),('X5MenuRight',24,22),
  ('X5MenuUp',24,17),('X5MenuDown',17,24),('X5MenuDown',24,3),('X5MenuUp',3,24)]:arrays[key][index]=value
 for key,v in arrays.items():menu=re.sub(r'('+key+r':\n \.byte )[^\n]+',lambda m:m[1]+','.join(map(str,v)),menu)
 (ov/'src/roster_expansion_menu.inc').write_text(menu,newline='\n')
 art=assets()
 objects=OUT/'objects';objects.mkdir(exist_ok=True)
 entry=(OLD/'objects/entrypoint.s').read_text()+'''\n.if ::ENABLE_MMC5_EXPANDED .and ::MAPPER_MMC5
.include "smb2_roster_menu_v4.s"
.endif
'''
 (objects/'entrypoint.s').write_text(entry,newline='\n')
 (objects/'asset.s').write_text('.segment "SMB2_ROSTER_CHR"\n.incbin "build/smb2-roster-menu-v4/smb2-roster-native-area.chr"\n')
 command=json.loads((OLD/'build-proof.json').read_text())['command']
 cmd=[v.replace(str(OLD/'objects/entrypoint.s'),str(objects/'entrypoint.s')).replace(str(OLD/'objects/asset.s'),str(objects/'asset.s')) for v in command]
 for i,v in enumerate(cmd):
  if v==str(OLD/'candidate.nes'):cmd[i]=str(OUT/'candidate.nes')
  elif str(OLD/'candidate.') in v:cmd[i]=v.replace(str(OLD/'candidate.'),str(OUT/'candidate.'))
 at=cmd.index('--asm-include-dir');cmd[at:at]=['--asm-include-dir',str(ov/'src')]
 r=subprocess.run(cmd,cwd=ROOT,capture_output=True,text=True);(OUT/'launcher.txt').write_text(r.stdout+r.stderr)
 if r.returncode:
  p=OUT/'first-link-negative.txt'
  if not p.exists():p.write_text(r.stdout+r.stderr)
  raise AssertionError(r.stderr[-3000:])
 # Fixed/E sample clones from this SAME final127, no stale E code import.
 from prepare_cv3_dmc_mirror import prepare
 dest=OUT/'candidate.nes';prepare(ROOT,dest);raw=bytearray(dest.read_bytes());fixed=raw[16+127*8192:16+128*8192]
 source=F.P.A.S.ROM.read_bytes();plan=json.loads((ROOT/'build/smb2-roster-audio-plan-v1.json').read_text())
 for clone in plan['samples']:
  copy=bytearray(fixed)
  for e in clone['entries']:
   at=int(e['target'],16)-0xe000;p=int(e['source'],16);n=e['bytes'];blob=source[16+114688+p-0xc000:16+114688+p-0xc000+n]
   assert hashlib.sha256(blob).hexdigest()==e['sha256'];copy[at:at+n]=blob
  raw[16+clone['bank']*8192:16+(clone['bank']+1)*8192]=copy
 dest.write_bytes(raw)
 proof=dict(status='PRIVATE_MENU_DRAFT_NOT_QUALIFIED_NO_NATIVE_NO_ADMISSION',candidate=bind(dest),parent=bind(OLD/'candidate.nes'),parent_handoff=bind(OLD/'handoff.json'),command=cmd,assets=art,
  new_owned_sources=[bind(ROOT/'src/smb2_roster_menu_v4.s')]+[bind(p)for p in sorted((ov/'src').glob('*'))],
  limits=['No native or shared menu admission','Native NmiClock/audio/mixer/cue owner remain open','Area palette shading is authored adaptation, no P1/P3 ownership stolen'],tool=bind(__file__))
 (OUT/'build-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
 print(json.dumps(dict(candidate=bind(dest),proof=bind(OUT/'build-proof.json')),indent=2))

if __name__=='__main__':main()
