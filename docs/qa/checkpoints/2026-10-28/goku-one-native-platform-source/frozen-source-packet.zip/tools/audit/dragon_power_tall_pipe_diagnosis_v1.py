"""Finite current/old full-Main tall-pipe arenas and actual native boundary facts."""
from pathlib import Path
import csv,json,sys
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import dragon_power_gameplay_controls_v1 as C
from sunny_integrated_controls_v1 import *
def main():
 out=R/'build/dragon_power_tall_pipe_diagnosis_v1.json';assert not out.exists()
 paths=[R/'build/dragon-power-admission-v1',R/'build/dragon-power-hud-budget-v1'];bs=[scoped_load(p/'candidate.nes')for p in paths]
 p=C.setup(bs[0]);p.put(AreaPointer=37,WorldNumber=0,Hidden1UpFlag=1);run(p,'GetAreaDataAddrs')
 for j in range(3):p.set('AreaObjectLength',255,j)
 cols=[]
 for i in range(64):
  run(p,'AreaParserCore');cols.append([p.get('MetatileBuffer',y)for y in range(13)]);run(p,'IncrementColumnPos')
 assert cols[57][7]==0x10 and cols[58][7]==0x11
 native=[]
 for name in['dragon-power-admission-native-easy-v4','dragon-power-hud-budget-native-easy-v1']:
  folder=R/'build/verification'/name
  rs=[{k:int(r[k])for k in['frame','poll','loops','x','y','vy','mask','state','camera']}for r in csv.DictReader((folder/'trace.csv').open())if int(r['engine'])==8]
  cross=next((r for r in rs if r['x']>=898),None)
  window=[r for r in rs if (cross['frame']-24<=r['frame']<=cross['frame']+8)if cross]if cross else[r for r in rs if 1398<=r['frame']<=1410]
  native.append(dict(name=name,cross898=cross,window=window,source_action_or_contact_writer_not_logged=True))
 cases=[]
 for mode in[0,1]:
  for threshold in[870,895]:
   for hold in[1,35]:
    pair=[]
    for b in bs:
     q=C.setup(b);q.set('CrossoverBehaviorVersion',mode);C.actor(q,0,0x2e,96,176);q.set('PowerUpType',0,0);q.set('Enemy_State',128,0)
     for age in range(65):
      q.put(SavedJoypadBits=0,NmiDisable=255,VRAM_Buffer1_Offset=0,FrameCounter=age);C.M.runtrace(q,'GameLoop')
     assert q.get('DpPole')==1 and q.get('DpPower')==1
     for x,col in enumerate(cols):
      for y,t in enumerate(col):q.m[address(b,'Block_Buffer_1')+((x//16)%2)*208+y*16+x%16]=t
     q.put(Player_PageLoc=3,Player_X_Position=88,Player_Y_Position=176,Player_Rel_XPos=112,ScreenLeft_PageLoc=3,ScreenLeft_X_Pos=0,ScreenRight_PageLoc=3,ScreenRight_X_Pos=255,Player_Pos_ForScroll=112)
     rows=[];started=None
     for age in range(100):
      x=q.get('Player_PageLoc')*256+q.get('Player_X_Position')
      if started is None and x>=threshold:started=age
      keys=1|(128 if started is not None and age-started<hold else 0)
      q.put(SavedJoypadBits=keys,NmiDisable=255,VRAM_Buffer1_Offset=0,FrameCounter=age+65)
      c,tr,mn=C.M.runtrace(q,'GameLoop')
      rows.append([age,keys,q.get('Player_PageLoc')*256+q.get('Player_X_Position'),q.get('Player_Y_Position'),q.get('DpAction'),q.get('DpVertical'),list(q.m[address(b,'DpContacts'):address(b,'DpContacts')+7])])
     pair.append(rows)
    assert pair[0]==pair[1],('HUD successor changed actual movement',mode,threshold,hold)
    cases.append(dict(mode=mode,takeoff=threshold,A_held_updates=hold,typed_start=[856,176],minimumY=min(r[3]for r in pair[0]),maximumX=max(r[2]for r in pair[0]),same_old_new_full_Main_movement=True,rows=pair[1]))
 report=R/'docs/qa/dragon-power-tall-pipe-diagnosis-2026-10-29.txt'
 summary=[{k:v for k,v in r.items()if k!='rows'}for r in cases]
 report.write_text('''TALL-PIPE DIAGNOSIS ONLY; NO NEW NATIVE OR PHYSICS/LEVEL CHANGE.
Current1b97 native remains FALSE7000/no-death and no strict hardware/deadline failure, stalled895/896. The earlierfb28v4 route passed898 only at1775 after hundreds of similar failed jumps. Its actual trace at1753Y164/vy4 becomes1754Y168/vy252 with mask1 (no A), and the resulting apex108 is8px higher than an ordinary floor jump's116. The current ordinary jump apex is116. Therefore prior passage did not prove an ordinary floor jump cleared the obstacle; an extra real bounce/changed boundary is visible, but the precise DpAction/contact/defeat writer was not logged. Do not label an unlogged enemy kill or exact causal writer as observed.
Compiled genuine DpGameBounce is an admitted Easy native stomp continuation: it sets originalVerticalE7, Action2/Pose4 and nativeYSpeedFC without freshA. This is a concrete source explanation consistent with the trace's no-A rebound, not native proof it occurred there. Full-Main CPU arenas below compare BOTH immutablefb28 and1b97, real earned Mushroom, exact64-column native parser, typed856/Y176 and no enemies/B. No game-state/physics patch or native replay is made. Both modes, two takeoff points and A-hold1/35 are actual source controls, not all controller timings or terrain heights.
'''+json.dumps(summary,indent=2)+'\nNative pipe source: world912..943, cap top144, exact10/11 cells (the first mistaken12/13 assertion copied a non-enterable pipe; actual native parser distinguishes it). Current small HUD successor and parent produce identical source motion/contacts for every supplied arena input; source jump/terrain code is unchanged. Whole-route source movement/gameplay qualification does not follow. The actual native earlier extra rise should not be used to justify a physics buff or to call this merely a controller failure. A deterministic no-enemy clearance or explicit authentic platform accommodation needs proof before further routing/adoption. Root owns all native.\n')
 files=[Path(__file__),Path(C.__file__),Path(C.M.__file__),report]
 for p in paths:files.extend([p/'candidate.nes',p/'candidate.dbg',p/'candidate.lbl',p/'handoff.json'])
 for name in['dragon-power-admission-native-easy-v4','dragon-power-hud-budget-native-easy-v1']:files.extend([R/'build/verification'/name/'trace.csv',R/'build/verification'/name/'inputs.csv',R/'build/verification'/name/'result.json'])
 proof=dict(passed=True,diagnosis_only=True,native_route_pass=False,new_native=False,native=native,source_CPU_cases=cases,pipe_columns=cols[57:59],bindings={str(p.resolve()):sha(p)for p in files})
 out.write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(dict(output=str(out),sha256=sha(out),report_SHA=sha(report),cases=summary)))
if __name__=='__main__':main()
