"""Finite real native25 manager/carry/full-Main/IRQ controls, no emulator."""
from pathlib import Path
import argparse,itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import dragon_power_gameplay_controls_v1 as C
import dragon_power_gameplay_render_v3 as D
from sunny_integrated_controls_v1 import *
P=R/'build/dragon-power-hud-budget-v1';O=R/'build/dragon-power-platform-v1'

def fresh(b,mode=1,camera=768):
 q=C.setup(b);q.put(CrossoverBehaviorVersion=mode,AreaPointer=37,WorldNumber=0,LevelNumber=0)
 run(q,'HpLoadArea')
 q.put(GameEngineSubroutine=8,TimerControl=0,GamePauseStatus=0,ScreenLeft_PageLoc=camera>>8,ScreenLeft_X_Pos=camera&255,ScreenRight_PageLoc=(camera+255)>>8,ScreenRight_X_Pos=(camera+255)&255)
 return q

def owned(q):
 return[(i,q.get('Enemy_PageLoc',i)*256+q.get('Enemy_X_Position',i),q.get('Enemy_Y_Position',i))for i in range(6)if q.get('HpActorOwner',i)==0x83 and q.get('Enemy_Flag',i)==1 and q.get('Enemy_ID',i)==0x25 and q.get('Enemy_State',i)==0x40]

def irq(q,kind):
 original=NesMPU.step;b=q.b;events=[];seen=set();minimum=255
 assert q.get('NmiDisable')==255
 def step(c):
  nonlocal minimum
  bank=q.m.banks[(c.pc-0x8000)//8192]if c.pc>=0x8000 else-1
  key=(bank,c.pc);minimum=min(minimum,c.sp)
  if bank==26 and address(b,'DpPlatformStart')<=c.pc<address(b,'DpPlatformEnd')and key not in seen:
   seen.add(key)
   def state():return(c.pc,c.a,c.x,c.y,c.p&0xcf,c.sp,tuple(q.m.banks),q.get('CurrentBank'),q.get('CurrentBankC'),bytes(q.m[z]for z in smc_at(b)),bytes(q.m[:8]),bytes(q.m[0x101+c.sp:0x200]),bytes(q.m[address(b,'HpRamStart'):address(b,'HpRamEnd')]),bytes(q.m[0x5c00:0x6000]))
   before=state()
   if kind=='IRQ':assert not c.p&4;q.m[0x5204]=128;c.irq()
   else:c.nmi()
   for _ in range(60000):
    original(c);minimum=min(minimum,c.sp)
    if c.pc==before[0]and c.sp==before[5]:break
   else:raise AssertionError(('ISR timeout',kind,key))
   assert state()==before,('actual ISR context',kind,key)
   events.append(key)
  original(c)
 NesMPU.step=step
 try:C.M.runtrace(q,'NrWeapons',p=0x30)
 finally:NesMPU.step=original
 return events,minimum

def approach(b,mode,wait):
 q=fresh(b,mode);q.put(Hidden1UpFlag=1)
 for j in range(3):q.set('AreaObjectLength',255,j)
 columns=[]
 for _ in range(64):
  run(q,'AreaParserCore');columns.append([q.get('MetatileBuffer',y)for y in range(13)]);run(q,'IncrementColumnPos')
 assert columns[57][7]==0x10 and columns[58][7]==0x11
 for x,col in enumerate(columns):
  for y,tile in enumerate(col):q.m[address(b,'Block_Buffer_1')+((x//16)%2)*208+y*16+x%16]=tile
 q.put(Player_PageLoc=3,Player_X_Position=88,Player_Y_Position=176,Player_Rel_XPos=88,ScreenLeft_PageLoc=3,ScreenLeft_X_Pos=0,ScreenRight_PageLoc=3,ScreenRight_X_Pos=255,Player_Pos_ForScroll=88)
 rows=[];jump=None;contacts=0;genuine=set()
 for age in range(260):
  slot=q.get('HpActorSlot')-1;support=slot>=0 and q.get('PlatformCollisionFlag',slot)<128
  x=q.get('Player_PageLoc')*256+q.get('Player_X_Position');y=q.get('Player_Y_Position')
  if support and y<=144 and age>=wait and jump is None:jump=age
  keys=(1 if jump is not None or x<887 else 0)|(128 if jump is not None and age-jump<8 else 0)
  q.put(SavedJoypadBits=keys,NmiDisable=255,VRAM_Buffer1_Offset=0,FrameCounter=age)
  c,tr,mn=C.M.runtrace(q,'GameLoop');genuine.update(tr)
  slot=q.get('HpActorSlot')-1;support=slot>=0 and q.get('PlatformCollisionFlag',slot)<128;contacts+=support
  xx=q.get('Player_PageLoc')*256+q.get('Player_X_Position');yy=q.get('Player_Y_Position')
  rows.append([age,keys,xx,yy,q.get('DpAction'),slot,q.get('Enemy_Y_Position',slot)if slot>=0 else-1,support,q.get('DpPlatform'),c.processorCycles,mn])
  if xx>=928 and yy<=112:break
 assert rows[-1][2]>=928 and rows[-1][3]<=112 and contacts,('actual Goku platform clearance',mode,wait,rows[-1])
 assert ((location(b,'YMovingPlatform')-16)//8192,address(b,'YMovingPlatform'))in genuine
 assert not any(pc in[address(b,'HpSine'),address(b,'HpMoveNativeHelper')]and bank==26 for bank,pc in genuine)
 assert q.get('DpPower')==0 and q.get('DpPole')==0 and q.get('DpWaves')==0
 return dict(mode=mode,wait=wait,updates=len(rows),first_fresh_A=jump,real_support_updates=contacts,rows=rows,no_mushroom_or_resources_earned_or_seeded=True,typed_position_map_only=True)

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();assert not a.output.exists()
 old,b=[scoped_load(p/'candidate.nes')for p in[P,O]];p=dict(passed=False,source_CPU_only=True,native_run=False,checks={});ck=p['checks']
 try:
  qualified_ids={s.get('id')for n,s in old['syms'].items()if'::'in n}
  for n,s in old['syms'].items():
   if n=='_FARCALL_COUNT':continue
   if'::'not in n and s.get('id')in qualified_ids:continue # reader's ambiguous convenience alias, not a linked public label
   assert n in b['syms']and address(old,n)==address(b,n),('old genuine symbol moved/missing',n)
  assert address(b,'DpPlatformStart')==0xb140 and address(b,'DpPlatformEnd')<=0xb600
  ck['layout']=dict(old_symbols_RAM_CHR_publicPCs_exact=True,only_existing26_tail_and_three124_target_bytes=True,approved_placement=dict(raw=24,scene=37,center=888,left=872,Y=208,width=32,type=37))
  rows=[]
  for mode,flags,scene in itertools.product(range(2),[f for f in range(256)if f&0x30==0x30],['distant','spawn','warm']):
   pair=[]
   for bundle in[old,b]:
    q=fresh(bundle,mode,0 if scene=='distant'else 768)
    if scene=='warm':run(q,'NrWeapons')
    c,tr,mn=C.M.runtrace(q,'NrWeapons',a=91,x=177,y=66,p=flags)
    pair.append((registers(c),bytes(q.m[:8]),q.get('ObjectOffset'),tuple(q.m.banks),c.processorCycles,mn))
   assert pair[0][:4]==pair[1][:4],('real weapon return ABI',mode,flags,scene,pair)
   rows.append([mode,flags,scene,pair[1][-2]-pair[0][-2],pair[1][-1]])
  ck['actual_NrWeapons_full_return_ABI']=dict(cases=len(rows),AXYP_SP_R0_R7_ObjectOffset_final_banks=True,CPU_extra={s:[min(r[3]for r in rows if r[2]==s),max(r[3]for r in rows if r[2]==s)]for s in['distant','spawn','warm']},minimum_SP=min(r[-1]for r in rows))
  rows=[]
  for mode,used in itertools.product(range(2),range(7)):
   q=fresh(b,mode)
   for i in range(used):C.actor(q,i,6,100+i*16,176)
   before=[[q.get(n,i)for n in['Enemy_Flag','Enemy_ID','Enemy_State','Enemy_X_Position']]for i in range(used)]
   run(q,'NrWeapons');aa=owned(q);assert len(aa)==int(used<6)
   assert before==[[q.get(n,i)for n in['Enemy_Flag','Enemy_ID','Enemy_State','Enemy_X_Position']]for i in range(used)]
   if aa:assert aa[0][1:]==(872,208)and q.get('Enemy_BoundBoxCtrl',aa[0][0])==5
   assert q.get('HpCount')==0;rows.append([mode,used,aa])
  for change in['owner','ID','flag','state','pointer']:
   q=fresh(b);run(q,'NrWeapons');slot=owned(q)[0][0]
   if change=='owner':q.set('HpActorOwner',2,slot)
   elif change=='ID':q.set('Enemy_ID',6,slot)
   elif change=='flag':q.set('Enemy_Flag',2,slot)
   elif change=='state':q.set('Enemy_State',0,slot)
   else:q.put(HpActorSlot=7)
   before=[q.get(n,slot)for n in['Enemy_Flag','Enemy_ID','Enemy_State']]
   run(q,'DpPlatformRelease');assert before==[q.get(n,slot)for n in['Enemy_Flag','Enemy_ID','Enemy_State']],('stale actor erased',change)
  ck['capacity_stale_reciprocal_owner']=dict(rows=rows,five_wrong_owner_ID_flag_state_pointer_declines=True,native_actors_never_overwritten=True)
  rows=[]
  for mode in range(2):
   q=fresh(b,mode);run(q,'NrWeapons');slot=owned(q)[0][0];ys=[];costs=[];seen=set()
   for age in range(384):
    q.put(FrameCounter=age&255,ObjectOffset=slot);c,tr,mn=C.M.runtrace(q,'HpNativePlatformDispatch',x=slot);seen.update(tr);ys.append(q.get('Enemy_Y_Position',slot));costs.append(c.processorCycles)
   assert [min(ys),max(ys)]==[76,213]
   assert ((location(b,'YMovingPlatform')-16)//8192,address(b,'YMovingPlatform'))in seen
   assert (26,address(b,'HpSine'))not in seen and(26,address(b,'HpMoveNativeHelper'))not in seen
   q.set('PlatformCollisionFlag',slot,slot);q.put(Player_Y_Speed=4,Player_State=2,ObjectOffset=slot);run(q,'HpNativePlatformDispatch',x=slot)
   assert q.get('Player_Y_Position')==(q.get('Enemy_Y_Position',slot)-32)&255 and q.get('Player_Y_Speed')==0
   # Actual native source pickup changes progression, never removes support.
   item=next(i for i in range(6)if not q.get('Enemy_Flag',i));C.actor(q,item,46,96,176);q.set('Enemy_State',128,item);q.set('PowerUpType',0,item)
   run(q,'NrPickup',x=item);assert q.get('DpPower')==1 and q.get('DpPole')==1
   run(q,'NrWeapons');assert owned(q)and q.get('HpActorSlot')==slot+1
   q.put(AreaPointer=194);run(q,'NrWeapons');assert owned(q)
   q.set('PlatformCollisionFlag',255,slot);q.put(ScreenLeft_PageLoc=5);run(q,'NrWeapons');assert not owned(q)
   q.put(ScreenLeft_PageLoc=3);run(q,'NrWeapons');assert owned(q)and owned(q)[0][2]==208
   run(q,'InitializeArea');assert not any(q.get('Enemy_Flag',i)for i in range(6))and q.get('HpSupport')==0
   rows.append([mode,min(ys),max(ys),min(costs),max(costs)])
  ck['native_motion_carry_pickup_scene_loopback']=dict(rows=rows,actual_updates=768,only_real_YMovingPlatform=True,real_source_pickup_retains=True,future_AreaPointer_not_scene=True,actual_InitializeArea_clears_actors_and_cache=True)
  rows=[]
  for mode in range(2):
   q=fresh(b,mode);q.put(Player_PageLoc=3,Player_X_Position=88,Player_Rel_XPos=88,GameTimerDisplay=4)
   c,tr,mn=C.M.runtrace(q,'GameLoop');assert (26,address(b,'HpSpawnAndTrack'))not in tr
   c,events,mn,tr=D.draw(q)
   girder=[e for e in events if e['ptr']==address(b,'MetaspritePlatformGirderSmall')]
   assert len(girder)==1 and girder[0]['header']==16 and girder[0]['accepted']
   assert q.get('HpCount')==0 and owned(q)
   # A4 native descriptor is genuine even while the body keeps C85 leased.
   rows.append([mode,girder[0]['ptr'],girder[0]['header'],girder[0]['before'],girder[0]['after'],girder[0]['rotation']])
   q.set('CrossoverBehaviorVersion',1-mode);run(q,'NrWeapons');assert not owned(q)and q.get('HpSupport')==0
  ck['real_native_girder_and_count_zero_owner']=dict(rows=rows,native_A4_32px_four_parts=True,original_34record_updater_not_entered=True,mode_change_retires_only_own_actor=True)
  cases=[]
  for mode,wait in itertools.product(range(2),[0,64,120]):cases.append(approach(b,mode,wait))
  ck['actual_complete_Main_source_parser_platform_clearance']=dict(cases=cases,whole_route_or_native_claim=False,no_B_no_extra_bounce_no_physics_change=True)
  rows=[]
  for name,val in [('SelectedCharacter',23),('WorldNumber',1),('LevelNumber',1),('AreaType',2),('AreaAddrsLOffset',6),('HpValid',0),('HpCount',1),('HpArea',0x26),('HpKey',1),('HpCharacter',23),('HpMode',0),('GamePauseStatus',1),('TimerControl',1),('GameEngineSubroutine',7)]:
   q=fresh(b);q.set(name,val);before=bytes(q.m[address(b,'HpRamStart'):address(b,'HpRamEnd')]);run(q,'DpPlatformTick');assert not owned(q)
   assert before==bytes(q.m[address(b,'HpRamStart'):address(b,'HpRamEnd')]),('negative cache changed',name)
   rows.append([name,val])
  ck['raw_scene_mode_zero_count_negative_admission']=dict(rows=rows,all_34_original_records_and_masks_byte_exact=True)
  rows=[]
  for ch,mode,keys in itertools.product([i for i in range(29)if i!=24],range(2),[0,129]):
   pair=[]
   for v in[old,b]:
    q=C.setup(v,ch);q.put(CrossoverBehaviorVersion=mode,SavedJoypadBits=keys);c,tr,mn=C.M.runtrace(q,'GameLoop',p=0x71)
    pair.append((registers(c),C.M.fastapp(q),tuple(q.m.banks),bytes(q.m[z]for z in smc_at(v)),bytes(q.m[0x100:0x200]),list(q.m.writes),c.processorCycles))
   assert pair[0]==pair[1],('foreign whole Main',ch,mode,keys)
   rows.append([ch,mode,keys])
  ck['foreign_complete_Main']=dict(cases=len(rows),wholeAXYP_SP_stack_application_banks_ordered_writes_5SMC_CPU_exact=True,no_foreign_A_bank_roundtrip_added=True)
  rows=[]
  for mode,scene in itertools.product(range(2),['distant','spawn','warm']):
   pair=[]
   for v in[old,b]:
    q=fresh(v,mode,0 if scene=='distant'else 768)
    if scene=='warm':run(q,'NrWeapons')
    q.put(GameTimerDisplay=4,NmiDisable=255,VRAM_Buffer1_Offset=0,SavedJoypadBits=0)
    c,tr,mn=C.M.runtrace(q,'GameLoop');pair.append((registers(c),tuple(q.m.banks),bytes(q.m[z]for z in smc_at(v)),c.processorCycles,mn))
   assert pair[0][:3]==pair[1][:3],('owned whole Main return ABI/banks/5SMC',mode,scene,pair)
   rows.append([mode,scene,pair[0][-2],pair[1][-2],pair[1][-2]-pair[0][-2],pair[1][-1]])
  ck['actual_complete_owned_Main_return_and_cost']=dict(rows=rows,AXYP_SP_final_banks_5SMC_exact=True,intentional_helper_actor_bbox_OAM_cache_not_masked_as_equivalent=True,source_benchmark_not_native_FPS=True)
  events=[];minsp=255
  for kind,scene in itertools.product(['IRQ','NMI'],['spawn','warm','outside']):
   q=fresh(b)
   if scene!='spawn':run(q,'NrWeapons')
   if scene=='outside':q.put(ScreenLeft_PageLoc=5)
   rows,minimum=irq(q,kind);assert rows;events.extend([kind,scene,*x]for x in rows);minsp=min(minsp,minimum)
  ck['actual_reached_IRQ_lagNMI']=dict(cases=len(events),minimum_SP=minsp,rows=events,all_live_registers_stack_scratch_banks_5SMC_helper91B_and_Goku_state_exact=True,normal_NMI_not_admitted_during_Main=True)
  p['passed']=True
 except Exception as e:p.update(failure=repr(e),traceback=traceback.format_exc())
 files=[Path(__file__),Path(C.__file__),Path(C.M.__file__),O/'candidate.nes',O/'candidate.dbg',O/'candidate.lbl',O/'platform.inc',R/'tools/prepare_dragon_power_platform_v1.py',P/'candidate.nes',P/'candidate.dbg',P/'handoff.json']
 p['bindings']={str(f.resolve()):sha(f)for f in files};a.output.write_text(json.dumps(p,indent=2)+'\n');print(json.dumps(dict(passed=p['passed'],failure=p.get('failure'),checks=list(ck))));assert p['passed']
if __name__=='__main__':main()
