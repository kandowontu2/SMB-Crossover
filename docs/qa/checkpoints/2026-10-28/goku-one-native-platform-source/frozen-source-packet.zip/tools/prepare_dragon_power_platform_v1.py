"""One approved raw24 native elevator; independent immutable1b97 parent."""
from pathlib import Path
import difflib,json,re,subprocess,sys
R=Path(__file__).resolve().parents[1];sys.path[:0]=[str(R/'tools'),str(R/'tools/audit')]
from sunny_integrated_controls_v1 import scoped_load,address,location,sha
P=R/'build/dragon-power-hud-budget-v1';O=R/'build/dragon-power-platform-v1'
ASM='''; PRIVATE one-placement list cbe66b; actual native25, not helper sine.
.pushseg
.segment "CROSSOVER_HELPERS"
.assert *=$b134,lderror,"Original helper end must remain B134"
.res 12,$ff
DpPlatformStart:
.proc DpPlatformWeapons
 DpHostCall DpGameWeapons,86
 ; Preserve the real weapon return, native scratch and object cursor.
 php
 pha
 phx
 phy
 .repeat 8,I
  lda R0+I
  pha
 .endrepeat
 lda ObjectOffset
 pha
 jsr DpPlatformTick
 pla
 sta ObjectOffset
 .repeat 8,I
  pla
  sta R7-I
 .endrepeat
 ply
 plx
 pla
 plp
 rts
.endproc
.proc DpPlatformTick
 lda SelectedCharacter
 cmp #24
 jne Done
 lda GameEngineSubroutine
 cmp #8
 jne Done
 lda GamePauseStatus
 and #1
 ora TimerControl
 jne Done
 lda WorldNumber
 ora LevelNumber
 jne Outside
 jsr HpCurrentArea
 cmp #$25
 jne Outside
 lda HpValid
 jeq Outside
 lda HpCount
 jne Outside                  ; no authored helper cell is borrowed
 lda HpArea
 cmp #$25
 jne Outside
 lda HpKey
 jne Outside
 lda HpCharacter
 cmp #24
 jne Outside
 lda HpMode
 cmp CrossoverBehaviorVersion
 jne Outside
 lda #$d8
 sta HpSupport                ; exclusive while raw24 scene25 cache is valid
 lda #<888
 sta HpXLo
 lda #>888
 sta HpXHi
 ldx #0
 jsr DpPlatformFind
 bcc Missing
 lda PlatformCollisionFlag,y
 bpl Done                     ; retain genuine support through any pickup
 jsr HpInSourceMargin
 bne Done
 jmp DpPlatformRelease
Missing:
 jsr DpPlatformRelease         ; forget stale reciprocal tags, no stale erase
 ldx #0
 jsr HpInSourceMargin
 beq Done
 jmp DpPlatformSpawn
Outside:
 lda HpSupport
 cmp #$d8
 bne Done
 jsr DpPlatformRelease
Done:rts
.endproc
.proc DpPlatformFind
 lda HpActorSlot
 beq No
 cmp #7
 bcs No
 tay
 dey
 lda HpActorOwner,y
 cmp #$83
 bne No
 lda Enemy_Flag,y
 cmp #1
 bne No
 lda Enemy_ID,y
 cmp #$25
 bne No
 lda Enemy_State,y
 cmp #$40
 bne No
 sec
 rts
No:clc
 rts
.endproc
.proc DpPlatformRelease
 jsr DpPlatformFind
 bcc Forget
 tya
 tax
 jsr EraseEnemyObject          ; actual native contact/lifetime teardown
Forget:
 lda HpActorSlot
 beq Clear
 cmp #7
 bcs Clear
 tay
 dey
 lda HpActorOwner,y
 cmp #$83
 bne Clear
 lda #0
 sta HpActorOwner,y
Clear:
 lda #0
 sta HpActorSlot
 sta HpSupport
 rts
.endproc
.proc DpPlatformSpawn
 ldy #5
Free:
 lda Enemy_Flag,y
 beq Found
 dey
 bpl Free
 rts                           ; all original native actors keep priority
Found:
 tya
 tax
 stx ObjectOffset
 lda #$83
 sta HpActorOwner,x
 txa
 clc
 adc #1
 sta HpActorSlot
 lda #$25
 sta Enemy_ID,x
 lda #1
 sta Enemy_Flag,x
 sta Enemy_Y_HighPos,x
 lda #0
 sta Enemy_State,x
 lda #<872                     ; source center888, actual32px native girder
 sta Enemy_X_Position,x
 lda #>872
 sta Enemy_PageLoc,x
 lda #208
 sta Enemy_Y_Position,x
 DpHostCall InitEnemyObject,.bank(InitEnemyObject)
 ldx ObjectOffset
 lda #5
 sta Enemy_BoundBoxCtrl,x
 lda #$40
 sta Enemy_State,x
 lda #$ff
 sta PlatformCollisionFlag,x
 lda #$d8
 sta HpSupport
 rts
.endproc
DpPlatformEnd:
.assert *<=$b600,lderror,"Approved helper26:B140..<B600 only"
.export DpPlatformStart,DpPlatformEnd,DpPlatformWeapons,DpPlatformTick,DpPlatformFind,DpPlatformRelease,DpPlatformSpawn
.popseg
'''

def main():
 assert not(O/'handoff.json').exists()
 assert sha(P/'candidate.nes')=='1b97a99f1056808b99ac978aded95fe132d0e84209156a4ed909f80513f717e4'
 b=scoped_load(P/'candidate.nes')
 assert b['raw'][16+26*8192+0x1140:16+26*8192+0x1600]==bytes([255])*1216
 (O/'src').mkdir(parents=True,exist_ok=True)
 for p in(P/'src').iterdir():
  if p.is_file():(O/'src'/p.name).write_bytes(p.read_bytes())
 for name in['main.c','smb1base-mmc5-expanded.cfg','entrypoint.s','component.s']:(O/name).write_bytes((P/name).read_bytes())
 gate=(O/'src/new_roster_dispatch.s').read_text()
 line='NrGate NrWeapons,IcWeapons,RcWeapons,SunnyWeapons,JnWeaponsDispatch,DpGameWeapons'
 assert gate.count(line)==1
 gate='.import DpPlatformWeapons\n'+gate.replace(line,line.removesuffix('DpGameWeapons')+'DpPlatformWeapons')
 (O/'src/new_roster_dispatch.s').write_text(gate)
 (O/'platform.inc').write_text(ASM)
 names='HpCurrentArea HpValid HpCount HpArea HpKey HpCharacter HpMode HpSupport HpXLo HpXHi HpInSourceMargin HpActorSlot HpActorOwner InitEnemyObject Enemy_BoundBoxCtrl LevelNumber'.split()
 entry=(O/'entrypoint.s').read_text();comp=(O/'component.s').read_text()
 for name in names:
  if not re.search(r'^\.import(?:zp)? '+name+r'$',comp,re.M):comp=('.importzp 'if address(b,name)<256 else'.import ')+name+'\n'+comp
  entry+='\n.export '+name
 comp+='\n.include "build/dragon-power-platform-v1/platform.inc"\n'
 (O/'entrypoint.s').write_text(entry+'\n');(O/'component.s').write_text(comp)
 cmd=[v.replace(str(P),str(O))for v in json.loads((P/'build-proof.json').read_text())['command']]
 z=subprocess.run(cmd,cwd=R,capture_output=True,text=True);(O/'build.log').write_text(z.stdout+z.stderr)
 assert not z.returncode,z.stderr
 from prepare_cv3_dmc_mirror import prepare
 prepare(R,O/'candidate.nes');new=scoped_load(O/'candidate.nes')
 diff={k:sum(a!=v for a,v in zip(b['raw'][16+k*8192:16+(k+1)*8192],new['raw'][16+k*8192:16+(k+1)*8192]))for k in range(128)};diff={k:v for k,v in diff.items()if v}
 assert set(diff)=={26,124}and diff[124]==3,diff
 assert new['raw'][1048592:]==b['raw'][1048592:]
 proof=dict(assembled=True,qualified=False,native_run=False,parent=sha(P/'candidate.nes'),candidate=sha(O/'candidate.nes'),DBG=sha(O/'candidate.dbg'),LBL=sha(O/'candidate.lbl'),command=cmd,changed_banks=diff,start=address(new,'DpPlatformStart'),end=address(new,'DpPlatformEnd'),bytes=address(new,'DpPlatformEnd')-address(new,'DpPlatformStart'),original34records_unchanged=True,independent_of_held_drops=True)
 (O/'build-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps({k:v for k,v in proof.items()if k!='command'}))
def freeze():
 assert not(O/'handoff.json').exists()
 receipt=json.loads((O/'controls-final.json').read_text());assert receipt['passed']
 for path,h in receipt['bindings'].items():assert sha(path)==h,path
 deps={};commands=[]
 for cmd in json.loads((P/'closure.json').read_text())['checks']['actual_ASM_dependency_closure']['commands']:
  cmd=[s.replace(str(P),str(O))for s in cmd]
  z=subprocess.run(cmd,cwd=R,capture_output=True,text=True);assert not z.returncode,z.stderr;commands.append(cmd)
 from prepare_cv3_dmc_mirror import prepare
 prepare(R,O/'independent.nes');assert sha(O/'independent.nes')==sha(O/'candidate.nes')
 for file in[O/'main-final.d',O/'component-final.d']:
  for word in re.split(r'(?<!\\)\s+',file.read_text().split(':\t',1)[1].strip().removesuffix(':')):
   path=Path(word.replace('\\ ',' '));path=(path if path.is_absolute()else R/path).resolve();assert path.is_file();deps[str(path)]=sha(path)
 # Ordinary targets consume neither the expanded router nor this standalone
 # optional component. Build their unchanged real source without generators.
 ordinary={};base=json.loads((P/'build-proof.json').read_text())['command'];cc=base[0]
 for mapper,expected in [('mmc3','d444cac88e13fa02b29ad16100b8f08fa565ba90f8cedde192de43fb2dc8f3eb'),('mmc5','f4ffd2483c51daa4d60bb575da2da8c4d817692cda407611c243031f67520833')]:
  name=O/('ordinary-'+mapper)
  cfile=name.with_suffix('.c');entry=O/('ordinary-'+mapper+'-entry.s')
  cfile.write_bytes((R/'src/main.c').read_bytes());entry.write_bytes((R/'src/entrypoint.s').read_bytes())
  defs=[]
  for i,s in enumerate(base):
   if s=='--asm-define':
    key,value=base[i+1].split('=',1)
    value={'ENABLE_MMC5_EXPANDED':'0','MAPPER_MMC3':str(int(mapper=='mmc3')),'MAPPER_MMC5':str(int(mapper=='mmc5'))}.get(key,value)
    defs+=['--asm-define',key+'='+value,'-D',key+'='+value]
  cmd=[cc,'--cpu','6502x','-t','nes','-g','-Oisr','-vm','-T','-C',str(R/'smb1base.cfg'),'--ld-args','--dbgfile,'+str(name.with_suffix('.dbg')),'--include-dir',str(R),'--asm-include-dir',str(O/'src'),'--asm-include-dir',str(R/'src'),'--asm-include-dir',str(R),'--bin-include-dir',str(R),'-Ln',str(name.with_suffix('.lbl')),'-o',str(name.with_suffix('.nes'))]+defs+[str(cfile),str(entry)]
  z=subprocess.run(cmd,cwd=R,capture_output=True,text=True);(O/('ordinary-'+mapper+'.log')).write_text(z.stdout+z.stderr)
  assert not z.returncode,z.stderr
  assert sha(name.with_suffix('.nes'))==expected,(mapper,sha(name.with_suffix('.nes')))
  ordinary[mapper]=dict(sha256=expected,command=cmd)
 # Existing helper state is a scene/owner cache, never globally persistent.
 ownership={}
 for name in ['HpSupport','HpActorSlot','HpActorOwner']:
  hits=[]
  for path in (R/'src').glob('*'):
   if path.suffix not in['.s','.inc']:continue
   for i,line in enumerate(path.read_text(encoding='utf-8',errors='replace').splitlines(),1):
    if re.search(r'\b'+name+r'\b',line)and not line.lstrip().startswith(';'):hits.append([str(path.relative_to(R)),i,line.strip()])
  ownership[name]=hits
 assert len(ownership['HpSupport'])==1,ownership['HpSupport']
 closure=dict(passed=True,actual_ASM_dependencies=deps,commands=commands,independent_link_exact=True,fresh_ordinary=ordinary,state_consumers=ownership,parent_34_records_and_masks_unchanged=True,old_Celeste_and_drops_not_composed=True)
 (O/'closure.json').write_text(json.dumps(closure,indent=2)+'\n')
 patch=''.join(difflib.unified_diff((P/'src/new_roster_dispatch.s').read_text().splitlines(True),(O/'src/new_roster_dispatch.s').read_text().splitlines(True),fromfile='parent/src/new_roster_dispatch.s',tofile='platform/src/new_roster_dispatch.s'))
 patch+=''.join(difflib.unified_diff([],ASM.splitlines(True),fromfile='/dev/null',tofile='platform/platform.inc'))
 (O/'source.patch').write_text(patch)
 report=R/'docs/qa/dragon-power-one-platform-source-2026-10-29.txt'
 report.write_text('''PRIVATE GOKU ONE-PLATFORM SOURCE COMPONENT; NO NATIVE/CAMPAIGN APPROVAL.
Approved concrete list cbe66b: raw24 only, current loaded1-1 scene25, one original native25 elevator at center888/left872/top208,32px native girder/bbox5/state40. Both modes and all upgrade states; no source movement/jump constants, map, other34records or global character-mask bits change. Parent is immutable1b97; held earned-drop8c0000 is NOT composed. Original Celeste21f19/81cdc and their sibling managers stay immutable/uncomposed.
The actual NrWeapons raw24 target changes to a26 wrapper. It executes genuine DpGameWeapons once, preserves actual returnedAXYP/SP,R0..R7,ObjectOffset and bank leases, then manages one existing helper cache cell only when HpValid1/HpCount0/key0/area25/character24/modeexact and active unpaused unfrozen gameplay. Stable loadedarea uses AreaType/AddrsLOffset, never future AreaPointer. HpSupportD8 plus reciprocal cache-slot/native-owner83 distinguish this private owner from original1..3/Celeste81..82. No new state allocation. Existing area initialization clears actors then91Bcache; zero-count bypasses the authored helper updater.
Real constructor InitEnemyObject initializes a free native actor only; all6 occupied slots win. Real RunLargePlatform runs bbox/collision and actual HpNativePlatformDispatch->YMovingPlatform; owner83 bypasses HpMoveNativeHelper/HpSine. Native carry commits player coordinates once, and existing DpHostSupport imports that real support without double horizontal carry. Actual native A4 girder record emits fourparts/32px under both modes. Original body/window0 and world/effect CHR ownership remain unchanged.
Capacity/stale ownership: reciprocal slot1..6, tag83, flag1, ID25 and exactstate40 are revalidated before any erase. Wrong tag/ID/duplicate/dead state/out-of-range pointer never licenses actor removal. Genuine supporting PlatformCollisionFlag retains the actor through pickup and offscreen retirement checks. Mushroom and later Flower do not fix the source jump height, so this accommodation has no power-tier retirement. Once not supported and beyond the original mode-specific source margin, real EraseEnemyObject retires it; camera loopback respawns through the real constructor. Mode mismatch retires only its own actor and waits for real scene configuration. No claimed persistence across arbitrary character switches; actual new-game/area lifecycle owns cache reset.
EXECUTABLE CONTROLS:384 actual NrWeapons returns/all64flag combinations/both modes/distant-spawn-warm preserveAXYP/SP/R0..R7/ObjectOffset/finalbanks.14 capacity cases plus5 stale-release cases;768 actual native motion updates coverY76..213 and real native player carry. Real source pickup, future-pointer, offscreen retirement, loopback and actual InitializeArea resets pass.14 raw/scene/mode/zero-count/freeze negatives.112 foreign completeMain controls preserve wholeAXYP/SP/application/entirestack/orderedwrites/finalbanks/5SMC andCPU exactly, with no additional foreign A trip.840 reached new-helper IRQ/lagNMI boundaries preserve live state/helper91B/source state/5SMC, minSP210; Main has NmiDisableFF and no normal-NMI write publication is invented.
TRAVERSAL EVIDENCE: six complete real GameLoop arenas use64 exact native parser columns (pipe10/11 at912/top144), typed start856/Y176, no enemies/B/health/upgrade/resource/outcome seed. Both modes with waits0/64/120 physically board and ride the genuine native elevator, then freshA clears928 withY<=112 in93/98/154 updates. Real support58/65/121 updates; source original jump/collision/carry retained. These are typed local CPU arenas, not native cold traversal, natural placement acquisition, all controller timings or whole-route proof.
COST: exact wrapper addition +522CPU distant,+1174spawn,+509warm. Measured complete typed Main22967->23489 distant(+522);23209->27620spawn(+4411),23209->26991warm(+3782), equal in both modes; includes actual native actor collision/movement/OAM. Full Main minSP197 at spawn. These are material source costs, not FPS/lag improvement or a universal deadline guarantee. Normal NMI/IRQ implementation and optional-HUD budget logic are byte-exact1b97; native ROOT must check actual cumulative cadence/deadlines/fullpixels.
LAYOUT: d232e4c1a3957ad467138956e8d71a693901eb7776d2a5326ba275425d67ac3d,433B26:B140..<B2F1, within approved1216B..<B600.432 changed26bytes plus exactly3 actual raw24 target bytes124; all old qualified symbols/publicPCs,header,allCHR,all other PRG/fixed mirrors and future leases exact. The first debug-reader unqualifiedFound alias rejection is preserved; real qualified symbols are reconciled instead of inventing aliases. Actual ca65 dependency closure/independent link reproduce the triple; fresh ordinaryMMC3d444/MMC5f4ffd exact. No shared/canonical/Downloads/settings/native/Git edits. ROOT owns subsequent native preparation/launch and any adoption.
''')
 files={Path(p)for p in deps}|set(O.glob('*negative*'))|{Path(__file__),R/'tools/audit/dragon_power_platform_controls_v1.py',O/'candidate.nes',O/'candidate.dbg',O/'candidate.lbl',O/'candidate.map',O/'platform.inc',O/'source.patch',O/'build-proof.json',O/'closure.json',O/'controls-first.json',O/'controls-second.json',O/'controls-final.json',O/'ordinary-mmc3.nes',O/'ordinary-mmc5.nes',P/'handoff.json',P/'candidate.nes',P/'candidate.dbg',report,R/'docs/qa/dragon-power-one-platform-proposal-2026-10-29.txt'}
 files.update(Path(p)for p in receipt['bindings'])
 hand=dict(status='FROZEN_PRIVATE_ONE_NATIVE25_PLATFORM_SOURCE_CPU_NATIVE_UNRUN',parent=sha(P/'candidate.nes'),candidate=sha(O/'candidate.nes'),DBG=sha(O/'candidate.dbg'),LBL=sha(O/'candidate.lbl'),native_run=False,report=str(report),actual_ASM_dependencies=deps,bindings={str(p.resolve()):sha(p)for p in sorted(files)if p.is_file()},limits=report.read_text())
 for p,h in hand['bindings'].items():assert sha(p)==h,p
 (O/'handoff.json').write_text(json.dumps(hand,indent=2)+'\n');print(json.dumps(dict(handoff=sha(O/'handoff.json'),candidate=hand['candidate'],DBG=hand['DBG'],LBL=hand['LBL'],bindings=len(hand['bindings']),ASM_dependencies=len(deps),report=sha(report))))

if __name__=='__main__':freeze()if'--freeze'in sys.argv else main()
