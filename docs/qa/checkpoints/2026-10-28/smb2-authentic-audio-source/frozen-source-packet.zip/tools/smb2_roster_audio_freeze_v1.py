"""Compact complete-source/link/ordinary closure for private SMB2 audio unit."""
from pathlib import Path
import collections,difflib,hashlib,json,re,subprocess,sys
import prepare_smb2_roster_audio_v1 as B
import smb2_roster_audio_controls_v1 as D
import smb2_roster_audio_leases_v1 as L
import smb2_roster_audio_plan_v1 as P

ROOT=B.ROOT;OUT=B.OUT;bind=B.bind
NOTE=ROOT/'docs/qa/smb2-roster-audio-source-2026-10-28.txt'

def fields(path):
    syms={};segs={};scopes={}
    for line in path.open():
        if line.startswith('sym\t'):
            d=P.fields(line)
            if 'val'in d:syms[int(d['id'])]=d
        elif line.startswith('seg\t'):
            d=P.fields(line);segs[int(d['id'])]=d
        elif line.startswith('scope\t'):
            d=P.fields(line);scopes[int(d['id'])]=d
    return list(syms.values()),segs,scopes

def source_authority():
    todo=[B.S.REF/'src/prg-4-5.asm',B.S.REF/'src/ram.asm',B.S.REF/'src/defs.asm'];seen=set()
    while todo:
        p=todo.pop().resolve()
        if p in seen:continue
        assert p.is_file(),str(p);seen.add(p)
        if p.suffix.lower()not in['.asm','.inc']:continue
        for name in re.findall(r'^\s*\.(?:include|incbin)\s+"([^"]+)"',p.read_text(),re.M):
            q=B.S.REF/name
            if not q.exists():q=p.parent/name
            assert q.is_file(),(p,name)
            todo.append(q)
    seen|=set((B.S.REF/'bin').glob('native.nes.*.nl'))
    seen.add(B.S.REF/'bin/native.nes');seen.add(B.S.ROM)
    return sorted(seen)

def main():
    source,j=B.Rel.check_parent();build=json.loads((OUT/'build-proof.json').read_text())
    assert bind(B.PARENT)==build['parent'] and bind(OUT/'candidate.nes')==build['candidate']
    for name in['differential-controls.json','lease-controls.json']:
        q=json.loads((OUT/name).read_text());assert q['passed']and q['candidate'if'candidate'in q else'actual_ROM']==build['candidate']
        assert bind(q['tool']['path'])==q['tool'],('changed control',q['tool'])
    # Actual ca65 full-dependency pass over the SAME expanded entrypoint that
    # cl65 consumed. The .d includes real binary incbins, not a directory scan.
    command=j['command'].copy();command[command.index('--create-full-dep')+1]=str(OUT/'source-closure.d')
    command[command.index('-o')+1]=str(OUT/'source-closure.o')
    command[-1]=str(OUT/'candidate-objects/entrypoint.s')
    command[4:4]=['-I',str(OUT/'overlay/src')]
    r=subprocess.run(command,cwd=ROOT,capture_output=True,text=True)
    (OUT/'source-closure-launcher.txt').write_text(r.stdout+r.stderr)
    assert r.returncode==0,r.stdout[-2000:]+r.stderr[-2000:]
    line=(OUT/'source-closure.d').read_text().splitlines()[0].split(':\t',1)[1]
    deps={Path(v.replace('\\ ',' ')).resolve()for v in re.split(r'(?<!\\)\s+',line.strip())}
    assert all(p.is_file()for p in deps)
    assert all(ROOT/f'src/smb2_roster_audio{suffix}'in deps for suffix in['.s','_native.inc','_writers.inc','_data.inc'])
    # Old symbol IDs/names/scopes remain genuine compiler products. Source
    # append adds only new symbols, never relabels an old caller.
    old,og,os=fields(B.PARENT.with_suffix('.dbg'));new,ng,ns=fields((OUT/'candidate.dbg'))
    for key,s in os.items():
        assert(s['name'],s.get('parent'),s.get('mod'))==(ns[key]['name'],ns[key].get('parent'),ns[key].get('mod'))
    # ca65 debug IDs are renumbered when appended globals are present. Full
    # qualified metadata is a MULTISET: exported/import duplicates are real,
    # not silently collapsed by an unqualified name dictionary.
    def identities(rows):
        return collections.Counter(tuple(s.get(k)for k in['name','scope','seg','type','addrsize','val'])for s in rows)
    absent=identities(old)-identities(new)
    assert not absent,('old qualified symbol moved/disappeared',list(absent.items())[:5])
    b=D.scoped_load(OUT/'candidate.nes');raw=b['raw'];parent=B.PARENT.read_bytes()
    startA,endA=D.address(b,'S2AudioNativeEntry'),D.address(b,'S2AudioCodeEnd')
    startC,endC=D.address(b,'S2AudioMusicData'),D.address(b,'S2AudioDataEnd')
    assert(startA,startC)==(0xb180,0xca00)and endA<=0xc000 and endC<=0xe000
    allowed=set(range(16+74*8192+0x1180,16+74*8192+endA-0xa000))
    allowed|=set(range(16+117*8192+0xa00,16+117*8192+endC-0xc000))
    allowed|=set(range(16+119*8192,16+121*8192))
    delta=collections.Counter()
    for p,(x,y)in enumerate(zip(parent,raw)):
        if x!=y:
            assert p in allowed,('outside declared sparse spans',p,x,y)
            delta[(p-16)//8192]+=1
    assert all(x==255 for x in parent[16+74*8192+0x1180:16+74*8192+endA-0xa000])
    assert all(x==255 for x in parent[16+117*8192+0xa00:16+117*8192+endC-0xc000])
    # Distinct complete fetches are independent original-ROM payloads. Both
    # sample clones are rebuilt from SAME final127, as is existing125.
    fixed=raw[16+127*8192:16+128*8192];plan=json.loads((ROOT/'build/smb2-roster-audio-plan-v1.json').read_text())
    original=B.S.ROM.read_bytes();payloads=[]
    for c in plan['samples']:
        expected=bytearray(fixed)
        for e in c['entries']:
            p=int(e['source'],16);n=e['bytes'];data=original[16+114688+p-0xc000:16+114688+p-0xc000+n]
            assert B.digest(data)==e['sha256'];at=int(e['target'],16)-0xe000
            assert n==e['length']*16+1 if 'length'in e else True
            expected[at:at+n]=data;payloads.append(e)
        actual=raw[16+c['bank']*8192:16+(c['bank']+1)*8192]
        assert actual==expected,'independent complete current-E clone expectation'
        assert actual[:0x1140]==fixed[:0x1140]and actual[0x1e11:]==fixed[0x1e11:]
    # Fresh ordinary controls consume the private include guarded off.
    ordinary=[]
    for mapper in['mmc3','mmc5']:
        dest=OUT/('flagoff-'+mapper+'.nes')
        cmd=[sys.executable,str(ROOT/'tools/build_mmc5_expanded.py'),'--source-overlay',str(OUT/'overlay'),
            '--output',str(dest),'--flag-off',mapper]
        q=subprocess.run(cmd,cwd=ROOT,capture_output=True,text=True)
        (OUT/('flagoff-'+mapper+'-launcher.txt')).write_text(q.stdout+q.stderr)
        assert q.returncode==0,q.stdout[-1000:]+q.stderr[-1000:]
        ref=ROOT/('build/celeste-small-chr-'+mapper+'.nes')
        assert dest.read_bytes()==ref.read_bytes(),('ordinary drift',mapper)
        ordinary.append(dict(mapper=mapper,candidate=bind(dest),reference=bind(ref),command=cmd))
    original_src=ROOT/'src/entrypoint.s';staged=OUT/'overlay/src/entrypoint.s'
    cfg=OUT/'overlay/smb1base-mmc5-expanded.cfg'
    # Patch is source integration only. Roll CFG prerequisite stays separately
    # explicit, and sample-clone producer is in the owned Python tool.
    patch=''.join(difflib.unified_diff(original_src.read_text().splitlines(True),staged.read_text().splitlines(True),
        fromfile='a/src/entrypoint.s',tofile='b/src/entrypoint.s'))
    for suffix in['.s','_native.inc','_writers.inc','_data.inc']:
        p=ROOT/f'src/smb2_roster_audio{suffix}'
        patch+=''.join(difflib.unified_diff([],p.read_text().splitlines(True),fromfile='/dev/null',tofile='b/'+p.relative_to(ROOT).as_posix()))
    (OUT/'implementation.patch').write_text(patch,newline='\n')
    consumed=deps|set(source_authority())|{cfg,ROOT/'build_options.ini',ROOT/'src/main.c',ROOT/'tools/build_mmc5_expanded.py',
        ROOT/'tools/prepare_cv3_dmc_mirror.py',source,ROOT/'build/smb2-roster-audio-plan-v1.json'}
    for p in j['bindings']:
        if Path(p).suffix.lower()in['.exe','.cfg','.ini']:consumed.add(Path(p))
    # Bind actual project/py65 modules loaded by these exact controls, plus
    # runtime executable. Standard library is covered by interpreter version.
    imported=set()
    for mod in list(sys.modules.values()):
        f=getattr(mod,'__file__',None)
        if f:
            p=Path(f).resolve()
            if p.suffix=='.py'and(p.is_relative_to(ROOT)or 'py65'in p.parts):imported.add(p)
    consumed|=imported|{Path(sys.executable)}
    for p in Path(sys.executable).parent.glob('python3*.dll'):consumed.add(p)
    owned=[ROOT/f'src/smb2_roster_audio{suffix}'for suffix in['.s','_native.inc','_writers.inc','_data.inc']]
    owned += [ROOT/'tools'/n for n in['prepare_smb2_roster_audio_v1.py','smb2_roster_audio_controls_v1.py',
        'smb2_roster_audio_leases_v1.py','smb2_roster_audio_freeze_v1.py']]+[NOTE,cfg,staged,OUT/'implementation.patch']
    outputs=[p for p in OUT.iterdir()if p.is_file()and p.name!='handoff.json']
    # Keep actual compiler/link objects and their source copies bound without
    # copying any tree. These are existing few files from the normal builder.
    outputs += [p for directory in OUT.glob('*-objects')for p in directory.iterdir()if p.is_file()]
    extents=dict(A74=[hex(startA),hex(endA-1),endA-startA,3712-(endA-startA)],
        C117=[hex(startC),hex(endC-1),endC-startC,5632-(endC-startC)])
    closure=dict(passed=True,source_CPU_only=True,native_run=False,actual_ASM_dependencies=len(deps),
        command=command,parent=bind(B.PARENT),candidate=bind(OUT/'candidate.nes'),extents=extents,
        all_old_symbols_values_names_scopes_exact=len(old),only_changed_banks=dict(delta),
        adjacent_owners_header_CHR_RAM_other_PRG_exact=True,complete_original_fetch_payloads=payloads,
        existing125_final127_unchanged=True,ordinary=ordinary,actual_consumed_inputs=[bind(p)for p in sorted(consumed)],
        original_reference_source_commit='b73415e1953d7fdffd4957d5fb43fa7a13844c1c',runtime=sys.version,
        tool=bind(__file__))
    path=OUT/'source-closure.json';path.write_text(json.dumps(closure,indent=2)+'\n')
    outputs.append(path)
    frozen_prior=[ROOT/'build/smb2-roll-relocation-v1/handoff.json',ROOT/'build/smb2-roster-audio-plan-v1-handoff.json',
        ROOT/'build/smb2-roster-component-v1/handoff.json',ROOT/'build/smb2-roster-palette-v2/handoff.json']
    handoff=dict(status='PASS_PRIVATE_AUTHENTIC_SMB2_AUDIO_SOURCE_LINK_CPU_IRQ_NO_HOST_ADMISSION_NO_NATIVE',
        parent=bind(B.PARENT),candidate=bind(OUT/'candidate.nes'),source_closure=bind(path),
        differential=bind(OUT/'differential-controls.json'),lease_IRQ=bind(OUT/'lease-controls.json'),
        extents=extents,prior_packets_unchanged=[bind(p)for p in frozen_prior],
        owned_files=[bind(p)for p in owned],input_bindings=[bind(p)for p in sorted(consumed)],
        output_bindings=[bind(p)for p in sorted(set(outputs))],
        limits='No liveMain cue publication,NMI scheduler,mixer/channel arbitration,DMC host-owner gate,menu or native qualification. Source stores4000..0F are ordered images;4010/12/13/15/17 are actual source hardware intents. No analog/length-counter/DMC-steal/PPU proof.')
    dest=OUT/'handoff.json';dest.write_text(json.dumps(handoff,indent=2)+'\n')
    print(json.dumps(dict(handoff=bind(dest),ASMdeps=len(deps),inputs=len(consumed),owned=len(owned),outputs=len(set(outputs)),extents=extents),indent=2))

if __name__=='__main__':main()
