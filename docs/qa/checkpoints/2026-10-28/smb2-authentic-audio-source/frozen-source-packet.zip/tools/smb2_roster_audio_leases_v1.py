"""Finite compiled public API, current-E sample and actual IRQ lease controls.

No native scheduler/mixer or emulated APU length-counter claims.
"""
from pathlib import Path
import collections,hashlib,json,sys
import smb2_roster_audio_controls_v1 as D
from check_tmnt_render_oa import address,location

ROOT=D.ROOT;OUT=D.OUT
APIS=['S2AudioInit','S2AudioTick','S2AudioSetQueue','S2AudioSetPause',
      'S2AudioPollDmc','S2AudioCancelDmc','S2AudioLeave']
bind=D.bind

class TrackedPort(D.Port):
    def __init__(self,b):self.observed_SP=255;super().__init__(b)
    def __getitem__(self,p):
        if self.cpu:self.observed_SP=min(self.observed_SP,self.cpu.sp)
        return super().__getitem__(p)

def snapshot(m):return(bytes(m),m.banks.copy(),getattr(m,'native_return_pc',None))
def restore(b,snap):
    m=TrackedPort(b);list.__setitem__(m,slice(None),snap[0]);m.banks=snap[1].copy()
    m.native_return_pc=snap[2];m.writes=[];m.events=[];m.fetches=[];m.reads=[]
    return m
def live(m):return(bytes(m[:0x100]),bytes(m[0x200:0x8000]),m.banks.copy())
def invoke(m,b,name,**kw):
    p=kw.get('p',0x30);sp=kw.get('sp',0xfd)
    expected=(kw.get('a',0),kw.get('x',0),kw.get('y',0),p&0xcf,sp)
    c=D.call(m,address(b,name),**kw)
    assert(c.a,c.x,c.y,c.p&0xcf,c.sp)==expected,('API AXYP/SP',name,expected,(c.a,c.x,c.y,c.p&0xcf,c.sp))
    return c

def deepest_call(m,pc,inject=None):
    """One genuine deepest-call replay, IRQ only at actual Nth PC occurrence."""
    c=D.NesMPU(memory=m,pc=pc);c.a,c.x,c.y,c.p,c.sp=(202 if pc==address(m.bundle,'FarCallCommon')else 0x55),3,7,0x30,0xc0
    m.cpu=c;c.stPushWord(0x5aff);counts=collections.Counter();lowest=255;site=None;fired=False
    for _ in range(30000):
        if c.pc==0x5b00:
            assert c.sp==0xc0 and(inject is None or fired)
            return c,site,min(lowest,m.observed_SP)
        bank=m.banks[(c.pc-0x8000)//8192]if c.pc>=0x8000 else-1
        key=(c.pc,bank);counts[key]+=1
        if c.sp<lowest:lowest=c.sp;site=(c.pc,bank,counts[key])
        if inject==(c.pc,bank,counts[key]):
            before=(c.pc,c.a,c.x,c.y,c.p&0xcf,c.sp,m.banks.copy())
            smc=bytes(m[0x15a:0x17b]);zp=bytes(m[0xbb:0xc7]);c.irq();assert c.pc!=before[0]
            for _ in range(2000):
                c.step()
                if c.pc==before[0]and c.sp==before[5]:break
            else:raise AssertionError('deep original IRQ return')
            assert(c.pc,c.a,c.x,c.y,c.p&0xcf,c.sp,m.banks)==before
            assert bytes(m[0x15a:0x17b])==smc and bytes(m[0xbb:0xc7])==zp
            fired=True
        assert m[c.pc]!=0;c.step()
    raise AssertionError('deep call bound')

def main():
    build=json.loads((OUT/'build-proof.json').read_text());assert D.sha(D.ROM)==build['candidate']['sha256']
    b=D.scoped_load(D.ROM);c=D.Campaign(b);base=snapshot(c.new)
    state=address(b,'S2AudioState');owner=address(b,'RgAudioCharacter');cpuZp=address(b,'RgAudioCpuZp')
    forbidden_audio_ZP=set(range(address(b,'RgAudioZp'),cpuZp))
    flags=[];foreign=0;queue=0;pause=0;far=[];life=[];irqs=[]
    # All public guards reject every foreign raw byte BEFORE private overlay,
    # ownership or borrowed-ZP reads, preserving all non-stack RAM/maps.
    private=set(range(state,state+69))|set(range(cpuZp,cpuZp+12))|{owner}
    for raw in range(256):
        if raw==25:continue
        for name in APIS:
            m=restore(b,base);m[address(b,'SelectedCharacter')]=raw
            old=live(m);m.reads=[]
            invoke(m,b,name,a=0x41,x=5,y=0x72,p=[0x30,0x79,0xff][raw%3])
            assert live(m)==old,('foreign writes',raw,name)
            assert not private.intersection(m.reads),('foreign private read',raw,name)
            foreign+=1
    # Exact all-byte P interface on declared, initialized source state.
    for p in range(256):
        for name in APIS:
            m=restore(b,base);r=invoke(m,b,name,a=0x41,x=5,y=0x91,p=p,sp=0xc0)
            flags.append(min(r.minimum_SP,m.observed_SP))
    for x in range(256):
        m=restore(b,base);before=bytes(m[state:state+69]);invoke(m,b,'S2AudioSetQueue',a=0x93,x=x,y=0x44)
        want=bytearray(before)
        if x<6:want[20+x]=0x93
        assert bytes(m[state:state+69])==want,('queue X',x)
        queue+=1
    for x in range(6):
        for a in range(256):
            m=restore(b,base);invoke(m,b,'S2AudioSetQueue',a=a,x=x,y=0x66)
            assert m[state+20+x]==a
            queue+=1
    for a in range(256):
        m=restore(b,base);invoke(m,b,'S2AudioSetPause',a=a)
        assert m[address(b,'S2AudioPause')]==(a if a in[0,0x41]else 0)
        pause+=1
    # Genuine FarCallCommon A-window lease, with real writable5SMC target.
    # Its final LDA recomputes N/Z from returned A; remaining P flags survive.
    for name in APIS:
        for ba in[4,62,99,118]:
            for bc in[4,80,93,117]:
                m=restore(b,base);m.page(1,ba);m[address(b,'CurrentBank')]=ba|128
                m.page(2,bc);m[address(b,'CurrentBankC')]=bc|128
                m[address(b,'SafecallA_SMC')+1]=0x41
                target=address(b,name);m[address(b,'FarcallJmpTarget_SMC')+1]=target&255
                m[address(b,'FarcallJmpTarget_SMC')+2]=target>>8
                r=D.call(m,address(b,'FarCallCommon'),a=202,x=5,y=0x7b,p=0x79,sp=0xc0)
                assert(r.a,r.x,r.y,r.sp)==(0x41,5,0x7b,0xc0)
                assert r.p&0xcf==0x49,('genuine farcall NZ contract',name,hex(r.p))
                assert m.banks[1:3]==[ba,bc]
                assert m[address(b,'CurrentBank')]==ba|128 and m[address(b,'CurrentBankC')]==bc|128
                far.append(dict(api=name,A=ba,C=bc,cycles=r.processorCycles,minimum_SP=min(r.minimum_SP,m.observed_SP)))
    # Hardware completion is an explicit modeled external input, not an
    # invented source tick. Poll does not change source RAM/timers/DAC.
    for request in[1,2,4,8,16,32,64,128]:
        q=D.Campaign(b);q.queue(1,request);q.tick();m=q.new
        active=m[address(b,'S2AudioActiveBank')];assert active in[119,120]
        assert m.banks[3]==active and m[0x4015]&16
        before=bytes(m[state:state+65]);invoke(m,b,'S2AudioPollDmc',a=0x7f)
        assert m.banks[3]==active and bytes(m[state:state+65])==before
        assert not m.events,'busy poll must not retrigger or stop'
        list.__setitem__(m,0x4015,m[0x4015]&15)
        invoke(m,b,'S2AudioPollDmc',a=0x80)
        assert m.banks[3]==127 and m[address(b,'S2AudioActiveBank')]==0
        assert bytes(m[state:state+65])==before and not m.events and m[0x4011]==0x49
        life.append(dict(request=request,actual_source_start_bank=active,busy_then_complete=True))
        for name in['S2AudioCancelDmc','S2AudioInit','S2AudioLeave']:
            q=D.Campaign(b);q.queue(1,request);q.tick();m=q.new
            invoke(m,b,name,a=0x91,x=0x37,y=0x62,p=0x79)
            assert m.banks[3]==127 and m[address(b,'S2AudioActiveBank')]==0
            assert m.events==[(0x4015,15)] and m[0x4011]==0x49,('source cancel/order',name,m.events)
            assert m[owner]==(255 if name=='S2AudioLeave'else 25)
    # Uninitialized raw25 obtains ownership only after clearing69B. A prior
    # foreign DMC is deliberately not stolen: host handoff is a prerequisite.
    m=restore(b,base);m[owner]=9;list.__setitem__(m,slice(state,state+69),bytes([0x63])*69)
    m.page(3,125);list.__setitem__(m,0x4015,31)
    invoke(m,b,'S2AudioInit');assert m[owner]==25 and bytes(m[state:state+69])==bytes(69)
    assert m.banks[3]==125 and not m.events,'no stealing foreign DMC owner'
    # Reached actual instruction IRQ controls, using actual initialized song/
    # cue states. One authentic pre-call snapshot per site, never fake PCs.
    targets={};deep=None;deep_low=255
    for family,index,bits,count in [('song',0,range(8),512),('event',3,range(8),256),
            ('effect1',2,range(8),128),('effect2',4,range(6),128),('effect3',5,range(3),160),('DPCM',1,range(8),176)]:
        for bit in bits:
            q=D.Campaign(b);q.queue(index,1<<bit)
            for tick in range(count):
                snap=snapshot(q.new);r=invoke(q.new,b,'S2AudioTick',a=0x55,x=3,y=7,p=0x30,sp=0xc0)
                assert not forbidden_audio_ZP.intersection(q.new.reads),'RgAudioZp is never a SMB2 owner'
                q.new.reads=[]
                expected=snapshot(q.new)
                if r.minimum_SP<deep_low:deep_low=r.minimum_SP;deep=snap
                for site in q.new.execs:
                    if site not in targets:targets[site]=(snap,expected,r.processorCycles)
    irq_changes=collections.Counter();irq_cycles=[];irq_min=255
    for site,(snap,expected,baseline_cycles)in sorted(targets.items()):
        m=restore(b,snap);r=invoke(m,b,'S2AudioTick',a=0x55,x=3,y=7,p=0x30,sp=0xc0,inject=tuple(site))
        # IRQ handler's PPU latch/ack effects are genuine hardware writes;
        # every application/private RAM byte, bank and foregroundZP is exact.
        wrong=[]
        for p,(x,y)in enumerate(zip(expected[0][:0x8000],bytes(m)[:0x8000])):
            if x==y or 0x100<=p<0x200:continue
            irq_changes[p]+=1
            if p not in[0x2005,0x2006,0x5128]:wrong.append((hex(p),x,y))
        assert not wrong,('actual IRQ nonhardware state',site,wrong[:12])
        assert m.banks==expected[1] and m[0x4011]==0x49
        irq_min=min(irq_min,r.minimum_SP,m.observed_SP);irq_cycles.append(r.processorCycles-baseline_cycles);irqs.append([hex(site[0]),site[1]])
    # Real farcall + actual IRQ with EACH current-E alias active. No fake
    # return PC or alternate NMI body: vectors and full handler are fetched
    # through the actually selected119/120/127 window.
    alias_irq=[]
    for request in[0,1,8]:
        q=D.Campaign(b)
        if request:q.queue(1,request);q.tick()
        snap=snapshot(q.new);ebank=q.new.banks[3]
        assert ebank=={0:127,1:120,8:119}[request]
        for seam in['S2AudioNativeEntry','S2AudioBorrow','S2AudioRelease']:
            m=restore(b,snap);m.page(1,99);m[address(b,'CurrentBank')]=227
            m.page(2,80);m[address(b,'CurrentBankC')]=208
            m[address(b,'SafecallA_SMC')+1]=0x55
            m[address(b,'FarcallJmpTarget_SMC')+1]=address(b,'S2AudioTick')&255
            m[address(b,'FarcallJmpTarget_SMC')+2]=address(b,'S2AudioTick')>>8
            r=D.call(m,address(b,'FarCallCommon'),a=202,x=3,y=7,p=0x30,sp=0xc0,inject=(address(b,seam),74))
            assert(r.a,r.x,r.y,r.p&0xcf,r.sp)==(0x55,3,7,0,0xc0)
            assert m.banks[1:3]==[99,80] and m.banks[3]==ebank
            assert m[address(b,'CurrentBank')]==227 and m[address(b,'CurrentBankC')]==208
            alias_irq.append(dict(E=ebank,seam=seam,minimum_SP=min(r.minimum_SP,m.observed_SP)))
    deepest=[]
    for farcall in[False,True]:
        first=restore(b,deep)
        if farcall:
            first.page(1,99);first[address(b,'CurrentBank')]=227
            first[address(b,'SafecallA_SMC')+1]=0x55
            first[address(b,'FarcallJmpTarget_SMC')+1]=address(b,'S2AudioTick')&255
            first[address(b,'FarcallJmpTarget_SMC')+2]=address(b,'S2AudioTick')>>8
        start=address(b,'FarCallCommon'if farcall else'S2AudioTick');initial=snapshot(first)
        baseline,point,minimum=deepest_call(first,start)
        second=restore(b,initial);after,_,with_irq=deepest_call(second,start,point)
        assert(after.a,after.x,after.y,after.p&0xcf,after.sp)==(baseline.a,baseline.x,baseline.y,baseline.p&0xcf,baseline.sp)
        assert second.banks==first.banks and after.processorCycles-baseline.processorCycles==120
        for p,(x,y)in enumerate(zip(bytes(first)[:0x8000],bytes(second)[:0x8000])):
            assert x==y or 0x100<=p<0x200 or p in[0x2005,0x2006,0x5128],('deep IRQ RAM',hex(p),x,y)
        assert with_irq>=0x17b-0x100,'stack must stay above actual liveSMC'
        deepest.append(dict(real_farcall=farcall,actual_PC=hex(point[0]),bank=point[1],occurrence=point[2],
            ambient_SP=192,minimum_SP=minimum,minimum_SP_with_IRQ=with_irq))
    # All permitted E aliases retain identical interrupt/callable bytes.
    raw=b['raw'];fixed=raw[16+127*8192:16+128*8192]
    aliases=[]
    for bank in[119,120,125]:
        blob=raw[16+bank*8192:16+(bank+1)*8192]
        assert blob[:0x1140]==fixed[:0x1140]and blob[0x1e11:]==fixed[0x1e11:]
        aliases.append(dict(bank=bank,callable_prefix_sha256=hashlib.sha256(blob[:0x1140]).hexdigest(),
            callable_suffix_sha256=hashlib.sha256(blob[0x1e11:]).hexdigest(),vectors=blob[-6:].hex()))
    proof=dict(passed=True,source_CPU_only=True,native_run=False,candidate=bind(D.ROM),build=bind(OUT/'build-proof.json'),
        original_differential=bind(OUT/'differential-controls.json'),foreign_public_guards=foreign,all_byte_flags_cases=len(flags),
        queue_controls=queue,pause_controls=pause,genuine_farcall=far,DMC_busy_completion_and_stop=life,
        actual_reached_IRQ_sites=irqs,IRQ_count=len(irqs),IRQ_hardware_only_final_differences={hex(p):n for p,n in irq_changes.items()},
        actual_IRQ_cycles=sorted(set(irq_cycles)),
        actual_alias_farcall_IRQ_controls=alias_irq,
        deepest_actual_caller_IRQ=deepest,
        minimum_SP_direct_flags=min(flags),minimum_SP_farcall=min(x['minimum_SP']for x in far),minimum_SP_IRQ=irq_min,
        aliases=aliases,tool=bind(__file__),
        RgAudioZp_never_read_or_written=True,
        flags_contract='Direct endpoint fullAXYP/SP exact. Actual genericFarCallCommon preservesC/V/D/I, derivesN/Z from returnedA; five genuine SMC operands intentionally configured by caller.',
        limits='CPU only: no DMC steals/length-counter timing, analog audio/PPU/native NMI scheduling. Raw25 is unadmitted; injecting full old hostNMI on raw25 would falsely qualify an unwired dispatcher. IRQ is actual current handler. Completion is an explicit modeled4015 input. Prior foreign DMC owner must be released by host before Init.')
    dest=OUT/'lease-controls.json';dest.write_text(json.dumps(proof,indent=2)+'\n')
    print(json.dumps(dict(passed=True,IRQ=len(irqs),foreign=foreign,flags=len(flags),farcall=len(far),proof=bind(dest)),indent=2))

if __name__=='__main__':main()
