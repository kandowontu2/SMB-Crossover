"""Real mapper IRQ seams in frozen assembled Rogue audio v4; CPU only.

This does not run ROOT's differential, edit its artifacts, schedule NMI audio,
or qualify v4's known extended transition/RAM-pointer failure.
"""
from pathlib import Path
import hashlib
import json
import re
import sys
import traceback

R = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(R / 'tools'), str(R / 'tools/audit')]
import rogue_dawn_audio_driver_controls_v4 as parent
from check_tmnt_render_oa import load, address, location
from verify_native_relocation import NesMPU

OUT = R / 'docs/qa/rogue-dawn-audio-driver-v4-irq-source-2026-10-29.json'
BASE = R / 'build/rogue-dawn-audio-driver-v4'
EXPECTED = 'c159cf3c68066d5d72a7ba50f836b33125b8d368431e249a6c7a241a072bfb5b'
STOP = 0x5b00


def binding(path):
    path = Path(path).resolve()
    data = path.read_bytes()
    return dict(path=str(path), bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


class Memory(parent.Host):
    def __init__(self, raw, labels):
        self.writes = []
        self.irq_writes = []
        self.irq_reads = []
        self.in_irq = False
        super().__init__(raw, labels)

    def __setitem__(self, at, value):
        if isinstance(at, int):
            self.writes.append((at, value))
            if self.in_irq:
                self.irq_writes.append((at, value))
        super().__setitem__(at, value)

    def __getitem__(self, at):
        if at == 0x5204 and self.in_irq:
            # Actual pending MMC5 IRQ acknowledge. No emulated PPU timing.
            value = bytearray.__getitem__(self, at)
            self.irq_reads.append((at, value))
            bytearray.__setitem__(self, at, 0)
            return value
        return super().__getitem__(at)

    def clone(self):
        other = Memory(self.raw, self.s)
        bytearray.__setitem__(other, slice(None), bytes(self))
        other.banks = list(self.banks)
        other.writes.clear()
        other.maps = 0
        return other


def main():
    assert not OUT.exists(), 'Keep this versioned outcome immutable'
    bundle = load(BASE / 'candidate.nes')
    assert hashlib.sha256(bundle['raw']).hexdigest() == EXPECTED
    syms = parent.labels(BASE / 'candidate.lbl')
    syms.update({n: int(a, 16) for n, a in re.findall(
        r'^(\w+)=\$([0-9a-f]+)$', (BASE / 'src/driver-imports.inc').read_text(), re.M)})
    irq = address(bundle, 'IrqScrollSplit')
    assert irq == 0x8000 and bundle['raw'][-1:]  # real vector checked below
    irq_off = location(bundle, 'IrqScrollSplit')
    assert (irq_off - 16) // 8192 == 126
    irq_bytes = bundle['raw'][irq_off:irq_off + 68]
    assert irq_bytes[-1] == 0x40
    smc = [address(bundle, n) + d for n, d in [
        ('NextBank_SMC', 1), ('SafecallA_SMC', 1),
        ('FarcallJmpTarget_SMC', 1), ('FarcallJmpTarget_SMC', 2), ('SafereturnA_SMC', 1)]]
    smc_seg = next(g for g in bundle['segs'].values() if g['name'] == '"SMCCODE"')
    sc_start, sc_size, sc_off = (int(smc_seg[k], 0) for k in ['start', 'size', 'ooffs'])
    image_helpers = {syms[n]: n for n in syms if n.startswith('GuestNativeStoreSTA')}
    image_helpers[syms['GuestMetroidStoreIndirectY']] = 'GuestMetroidStoreIndirectY'
    graph = json.loads((R / 'docs/qa/rogue-dawn-audio-source-closure-2026-10-28.json').read_text())['graph']
    request_sites = {}
    for row in graph['instructions']:
        data = bytes.fromhex(row['bytes'])
        if len(data) == 3 and 0x4000 <= int.from_bytes(data[1:], 'little') <= 0x4017:
            request_sites[row['pc'] + 0x2000] = (row['instruction'].split()[0],
                                                int.from_bytes(data[1:], 'little'), row['mode'])
    before_bindings = [binding(p) for p in [
        Path(__file__), BASE / 'candidate.nes', BASE / 'candidate.dbg', BASE / 'candidate.lbl',
        BASE / 'build-proof.json', BASE / 'src/driver-imports.inc',
        R / 'tools/rogue_dawn_audio_driver_controls_v4.py',
        R / 'tools/prepare_rogue_dawn_audio_driver_v4.py',
        R / 'src/rogue_dawn_audio_driver_v4.s', R / 'src/rogue_dawn_audio_native_v4.inc',
        R / 'src/rogue_dawn_audio_rng_v4.inc', R / 'src/reset.s',
        R / 'tools/audit/verify_native_relocation.py', R / 'tools/audit/check_tmnt_render_oa.py',
        R / 'docs/qa/rogue-dawn-audio-source-closure-2026-10-28.json']]
    proof = dict(passed=False, source_CPU_only=True, native_run=False,
                 candidate_sha256=EXPECTED, checks={}, bindings=before_bindings,
                 known_v4_transition_negative='ROOT reports area3 phase1 tick120 after35844 matching updates: '
                 'source E6/E7=0100 then0300/0500 reads RAM, while current reader assumes ROM. '
                 'This IRQ study does not waive or qualify that negative.')
    baseline_calls = []
    all_low = 255

    def run(mem, entry, *, a=0x36, x=0x57, y=0x98, p=0x61, entry_sp=251, seam=None):
        nonlocal all_low
        c = NesMPU(memory=mem, pc=syms[entry])
        c.a, c.x, c.y, c.p, c.sp = a, x, y, p, entry_sp + 2
        c.stPushWord(STOP - 1)
        assert c.sp == entry_sp
        trace, low, fired, record = [], c.sp, False, None
        mem.writes.clear()
        mem.requests = []

        def observe_request():
            if mem.banks[(c.pc - 0x8000) // 8192] != 97:
                return
            if c.pc in request_sites:
                op, at, mode = request_sites[c.pc]
                value = c.y if op == 'STY' else c.x if op == 'STX' else c.a
                mem.requests.append((at + (c.y if mode == 'aby' else 0), value))
            elif c.pc == 0xd386:
                at = mem[0xe0] + 256 * mem[0xe1] + c.y
                assert 0x4000 <= at < 0x4010
                mem.requests.append((at, c.a))

        for ordinal in range(50000):
            if c.pc == STOP:
                assert c.sp == entry_sp + 2
                assert seam is None or fired, ('Seam not reached', entry, seam)
                all_low = min(all_low, low)
                return dict(cpu=c, trace=trace, low=low, irq=record)
            assert c.pc >= 0x8000 and mem[c.pc] != 0, (entry, hex(c.pc), mem.banks)
            bank = mem.banks[(c.pc - 0x8000) // 8192]
            trace.append((c.pc, bank, c.x, c.y, c.sp, c.p,
                          tuple(mem.banks), mem[syms['CurrentBank']], mem[syms['CurrentBankC']]))
            if seam == ordinal:
                assert not fired and not c.p & c.INTERRUPT, ('IRQ masked', entry, ordinal)
                fired = True
                regs = (c.a, c.x, c.y, c.p & 0xcf, c.sp, c.pc)
                original_ram, original_banks = bytes(mem[:0x8000]), tuple(mem.banks)
                original_smc = bytes(mem[z] for z in smc)
                live_stack = bytes(mem[0x101 + c.sp:0x200])
                pending_p = (c.p & ~c.BREAK) | c.UNUSED
                start = c.processorCycles
                mem.in_irq = True
                mem[0x5204] = 0x80
                c.irq()                 # genuine CPU IRQ vector/stack entry
                assert c.pc == irq
                stacked_at = 0x100 + ((c.sp + 1) & 255)
                assert mem[stacked_at] == pending_p
                for _ in range(200):
                    low = min(low, c.sp)
                    if mem[c.pc] == 0x40:
                        assert mem[stacked_at] == pending_p, 'IRQ modified actual stacked P'
                    c.step()            # actual complete 68-byte IRQ, no stub
                    if c.pc == regs[5] and c.sp == regs[4]:
                        break
                else:
                    raise AssertionError(('Actual IRQ did not RTI', hex(c.pc)))
                mem.in_irq = False
                assert (c.a, c.x, c.y, c.p & 0xcf, c.sp, c.pc) == regs
                assert tuple(mem.banks) == original_banks
                assert bytes(mem[z] for z in smc) == original_smc
                assert bytes(mem[0x101 + c.sp:0x200]) == live_stack
                assert mem.irq_reads == [(0x5204, 0x80)]
                writes = mem.irq_writes
                dead = sorted({at for at, _ in writes if 0x100 <= at <= 0x100 + regs[4]})
                # Pending flag is the injected hardware input, not an IRQ output.
                io = [(at, val) for at, val in writes if at not in dead and at != 0x5204]
                assert io == [(0x2006, 4), (0x5128, 0), (0x2005, 32),
                              (address(bundle, 'IrqNewScroll'), 128), (0x2005, 137),
                              (0x2006, 145), (address(bundle, 'IrqNewScroll'), 137)], io
                permitted = set(dead) | {0x2005, 0x2006, 0x5128}
                differences = [at for at, (v, w) in enumerate(zip(original_ram, mem[:0x8000])) if v != w]
                assert set(differences) <= permitted, ('IRQ unexpected RAM change', differences)
                record = dict(ordinal=ordinal, PC=f'{regs[5]:04X}', bank=bank,
                              entry_SP=regs[4], minimum_SP=low, CPU=c.processorCycles - start,
                              physical_banks=list(original_banks), shadow_A=trace[-1][7],
                              shadow_C=trace[-1][8], stacked_P=pending_p, stacked_P_unchanged=True,
                              exact_dead_stack_addresses=dead, actual_IRQ_io=io)
            observe_request()
            c.step()
            low = min(low, c.sp)
        raise AssertionError(('Finite CPU bound', entry, hex(c.pc)))

    def fresh(area=0, gear=0, missile=0, vy=0):
        m = Memory(bundle['raw'], syms)
        m[:256] = bytes((i * 37 + 19) & 255 for i in range(256))
        m[sc_start:sc_start + sc_size] = bundle['raw'][sc_off:sc_off + sc_size]
        m[address(bundle, 'IrqPPUCTRL')] = 3
        m[address(bundle, 'IrqNewScroll')] = 137
        assert m[0xfffe] + 256 * m[0xffff] == irq
        run(m, 'RdaAudioInit')
        run(m, 'RdaAudioTick')  # actual init/silence consumes before area request
        run(m, 'RdaAudioSetArea', a=area)
        for n, v in [('RdGear', gear), ('RdMissileMode', missile), ('RdVY', vy),
                     ('RdBeamSfx', 0x80 | (1 if gear & 128 and not missile else 0))]:
            m[syms[n]] = v
        return m

    def save_case(name, mem, entry='RdaAudioTick', **args):
        state = mem.clone()
        base = run(mem, entry, **args)
        baseline_calls.append(dict(name=name, state=state, entry=entry, args=args, base=base,
                                   after=bytes(mem), banks=tuple(mem.banks), requests=list(mem.requests)))

    try:
        # Finite initialized callbacks; no copy/acquisition/native producer claim.
        for area in [0, 1, 3, 5]:
            m = fresh(area)
            for tick in range(16):
                if tick in [0, 7, 15]:
                    save_case(f'normal-area{area}-tick{tick}', m)
                else:
                    run(m, 'RdaAudioTick')
        for name, gear, missile, vy, q, flag in [
            ('Ice', 128, 0, 0, 1, 16), ('Wave', 64, 0, 0, 1, 1),
            ('Screw', 8, 0, 252, 0, 64), ('missile', 0, 1, 0, 0, 32),
            ('bomb', 1, 0, 0, 3, 1), ('item', 0, 0, 0, 4, 64),
            ('hurt', 0, 0, 0, 4, 4), ('death', 0, 0, 0, 3, 128)]:
            m = fresh(1, gear, missile, vy)
            run(m, 'RdaAudioTick')
            run(m, 'RdaAudioSetQueue', a=flag, x=q)
            save_case(name + '-actual-dispatch', m)
            for _ in range(7):
                run(m, 'RdaAudioTick')
            save_case(name + '-continuation', m)
        m = fresh(0)
        run(m, 'RdaAudioSetMode', a=5)
        save_case('real-mode5-pause', m)
        run(m, 'RdaAudioSetMode', a=3)
        save_case('real-mode3-resume', m)
        m = fresh(0)
        for entry, args in [('RdaAudioInit', {}), ('RdaAudioSetQueue', dict(a=16, x=1)),
                            ('RdaAudioSetArea', dict(a=5)), ('RdaAudioSetMode', dict(a=5))]:
            save_case(entry + '-public', m, entry, **args)
        # Real entry C lease restoration; the Tick maps C97 itself.
        m = fresh(1)
        m.map(2, 94)
        m[syms['CurrentBankC']] = 128 | 94
        save_case('incoming-C94-lease', m)
        # Direct compiled mapper reader on all rehomed pages and upper depots.
        table = location(bundle, 'RdaLowerBankTable')
        high_table = location(bundle, 'RdaLowerHighTable')
        targets = [(85, h) for h in range(0xb9, 0xc0)] + [(84, 0xbd)]
        chosen = [next(i for i in range(192)
                       if (bundle['raw'][table + i] & 127, bundle['raw'][high_table + i]) == target)
                  for target in targets]
        assert len(chosen) == 8
        for i in chosen:
            m = fresh(i // 32)
            at = 0x8000 + (i % 32) * 256 + 17
            m[0x23], m[0xe8], m[0xe9] = i // 32, at & 255, at >> 8
            save_case(f'rehomed-lower-index{i}', m, 'RdaReadRom')
        upper = location(bundle, 'RdaUpperRawBankTable')
        for bank in [91, 92, 99]:
            i = next(i for i in range(32) if bundle['raw'][upper + i] & 127 == bank)
            m = fresh(0)
            m[0xe8], m[0xe9] = 17, 0xa0 + i
            save_case(f'raw-upper-bank{bank}', m, 'RdaReadRom')

        # Choose actual executed instructions, not invented labels/callbacks.
        selected = {}
        borrow_lo, release_lo = syms['RdaBorrow'], syms['RdaRelease']
        read_start, rng_start = syms['RdaReadRom'], syms['RdaOriginalRng']
        return_lo = syms['RdaPublicReturn']
        helper_entries = {syms[n]: n for n in ['RdaReadAbsoluteY', 'RdaReadAbsolute',
            'RdaReadAbsoluteCommon', 'RdaReadE6Y', 'RdaReadECY', 'RdaReadReturn',
            'RdaLoadVolume', 'RdaAdvanceNote', 'RdaLoadNoteY']}
        for case in baseline_calls:
            for ordinal, row in enumerate(case['base']['trace']):
                pc, bank, x, y, sp, flags, banks, sa, sc = row
                keys = []
                if ordinal == 0:
                    keys.append(('entry', case['entry'], banks[2]))
                if bank == 62 and return_lo <= pc < return_lo + 7:
                    keys.append(('public-return', pc, banks[2]))
                if bank == 62 and borrow_lo <= pc < release_lo and x in [18, 9, 0]:
                    keys.append(('borrow', pc, x))
                if bank == 62 and release_lo <= pc < syms['ZpAddresses'] and x in [18, 9, 0]:
                    keys.append(('release', pc, x))
                if bank == 97 and read_start <= pc < rng_start:
                    keys.append(('mapper-reader', pc, banks[1]))
                if bank == 62 and pc in helper_entries:
                    keys.append(('image-reader-helper', helper_entries[pc]))
                if bank == 127 and pc in image_helpers:
                    keys.append(('real-buffer-writer', image_helpers[pc]))
                if sa != (128 | banks[1]):
                    keys.append(('actual-A-shadow-gap', pc, banks[1], sa))
                if sc != (128 | banks[2]):
                    keys.append(('actual-C-shadow-gap', pc, banks[2], sc))
                for key in keys:
                    selected.setdefault(key, (case, ordinal))
        assert any(k[0] == 'actual-A-shadow-gap' for k in selected)
        assert any(k[0] == 'actual-C-shadow-gap' for k in selected)
        assert any(k[0] == 'real-buffer-writer' for k in selected)
        assert len(selected) <= 500, len(selected)
        rows = []
        for index, (key, (case, ordinal)) in enumerate(selected.items()):
            for entry_sp, flags in [(251, 0x61), (192, 0xe9)]:
                # Recompute baseline with identical actual caller flags/stack.
                plain = case['state'].clone()
                args = dict(case['args'], entry_sp=entry_sp, p=flags)
                expected = run(plain, case['entry'], **args)
                m = case['state'].clone()
                actual = run(m, case['entry'], seam=ordinal, **args)
                q = actual['irq']
                assert q is not None
                a, z = actual['cpu'], expected['cpu']
                assert (a.a, a.x, a.y, a.p & 0xcf, a.sp) == (z.a, z.x, z.y, z.p & 0xcf, z.sp)
                assert tuple(m.banks) == tuple(plain.banks)
                assert list(m.requests) == list(plain.requests)
                allowed = set(q['exact_dead_stack_addresses']) | {0x2005, 0x2006, 0x5128}
                differences = [i for i, (v, w) in enumerate(zip(m[:0x8000], plain[:0x8000])) if v != w]
                assert set(differences) <= allowed, (case['name'], key, differences[:20])
                assert bytes(m[sc_start:sc_start + sc_size]) == bytes(plain[sc_start:sc_start + sc_size])
                assert bytes(m[n] for n in smc) == bytes(plain[n] for n in smc)
                assert a.processorCycles - z.processorCycles == q['CPU']
                rows.append(dict(case=case['name'], kind=list(key), public_entry_SP=entry_sp,
                                 original_flags=flags, uninterrupted_CPU=z.processorCycles,
                                 whole_call_CPU=a.processorCycles, actual=q,
                                 ordered_requests=len(m.requests), final_extra_dead_bytes=differences))
            if index % 50 == 0:
                print(json.dumps(dict(completed_seams=index + 1, selected=len(selected))), flush=True)
        assert all_low >= 128, ('SMC/stack safety lower bound', all_low)
        proof.update(passed=True, status='PASS_FINITE_REAL_IRQ_SEAMS_ONLY_V4_TRANSITION_NEGATIVE_OPEN',
            minimum_SP=all_low, selected_instruction_contexts=len(selected), IRQ_calls=len(rows),
            initialized_baseline_cases=len(baseline_calls), rows=rows,
            uninterrupted_selected_CPU_range=[min(v['base']['cpu'].processorCycles for v in baseline_calls),
                                               max(v['base']['cpu'].processorCycles for v in baseline_calls)],
            IRQ_code=dict(physical_bank=126, PC='8000', bytes=68,
                          sha256=hashlib.sha256(irq_bytes).hexdigest(), code_hex=irq_bytes.hex()),
            exact_SMC_addresses=smc, complete_SMC_span=[sc_start, sc_start + sc_size],
            scope='Genuine compiled public callbacks/internal ROM reader and actual mapper IRQ/RTI; '
                  'finite initialized normal/effect/pause contexts. Snapshot equality includes '
                  'borrowed ZP, private audio/image state, all five SMC and complete copied SMC code, '
                  'live caller stack, physical/software A/C leases including interrupted shadow gaps. '
                  'Only actual five-byte IRQ dead stack and explicitly measured IRQ PPU/font IO differ.',
            limits=['No source transition pass; known ROOT area3 phase1 tick120 RAM-reader failure remains open.',
                    'No NMI scheduling, nested-NMI safety, actual PPU/IRQ31 raster timing, DMA/DMC stalls, '
                    'hardware APU4011/4017 mixing or native audible result.',
                    'Selected CPU maximum is observed over the listed finite cases, not a global worst-path bound.',
                    'Source queues/context are typed initialized CPU fixtures, not earned acquisition or Main publication.',
                    'RealP comparison coversN/V/D/I/Z/C; B/U are virtual6502 status image bits. Actual stackedP byte is also verified.'])
    except BaseException as exc:
        proof.update(error=str(exc), traceback=traceback.format_exc())
        raise
    finally:
        assert [binding(v['path']) for v in before_bindings] == before_bindings, 'Frozen input changed'
        OUT.write_text(json.dumps(proof, indent=2) + '\n')
    print(json.dumps(dict(passed=True, output=binding(OUT), IRQ_calls=proof['IRQ_calls'],
                          minimum_SP=all_low, selected_CPU=proof['uninterrupted_selected_CPU_range'])))


if __name__ == '__main__':
    main()
