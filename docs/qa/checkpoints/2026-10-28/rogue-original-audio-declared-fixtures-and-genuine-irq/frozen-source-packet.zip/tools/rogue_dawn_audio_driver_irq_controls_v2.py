"""Authenticate two imported bank62 data aliases; retain v1 IRQ mechanics."""
from pathlib import Path
import json
import sys

R = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(R / 'tools'), str(R / 'tools/audit')]
import rogue_dawn_audio_driver_irq_controls_v1 as frozen

NEGATIVE = frozen.OUT
OUT = R / 'docs/qa/rogue-dawn-audio-driver-v4-irq-source-v2-2026-10-29.json'
original_location = frozen.location


def location(bundle, name):
    if name not in ['RdaLowerBankTable', 'RdaLowerHighTable']:
        return original_location(bundle, name)
    # These genuine external imports are constants, not fabricated code PCs.
    # Both actual 192-byte table regions are in ROOT's A62 lower-depot lease.
    expected = dict(RdaLowerBankTable=0xbba7, RdaLowerHighTable=0xbc67)[name]
    assert int(bundle['syms'][name]['val'], 0) == expected
    assert 'seg' not in bundle['syms'][name]
    return 16 + 62 * 8192 + (expected & 8191)


def main():
    assert NEGATIVE.exists() and not OUT.exists()
    negative = json.loads(NEGATIVE.read_text())
    assert negative['passed'] is False and negative['error'] == "'seg'"
    for row in negative['bindings']:
        assert frozen.binding(row['path']) == row, row['path']
    frozen.location = location
    frozen.OUT = OUT
    frozen.main()
    proof = json.loads(OUT.read_text())
    proof['preparation_negative'] = frozen.binding(NEGATIVE)
    proof['observer_only_delta'] = 'Only two authenticated imported data tables BBA7/BC67 use bank62 file offsets; v1 IRQ mechanics/model/assertions unchanged.'
    proof['bindings'].append(frozen.binding(__file__))
    OUT.write_text(json.dumps(proof, indent=2) + '\n')
    print(json.dumps(dict(final=frozen.binding(OUT), original_negative=frozen.binding(NEGATIVE))))


if __name__ == '__main__':
    main()
