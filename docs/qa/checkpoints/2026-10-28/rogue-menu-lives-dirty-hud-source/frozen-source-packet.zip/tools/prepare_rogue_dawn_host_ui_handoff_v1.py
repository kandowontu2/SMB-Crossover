"""Freeze compact private menu/lives/late HUD source unit; never native."""
from pathlib import Path
import json,subprocess,sys
R=Path(__file__).resolve().parents[1];sys.path[:0]=[str(R/'tools'),str(R/'tools/audit')]
import rogue_dawn_map_v1 as ref
import prepare_rogue_dawn_host_body_handoff_v1 as closure
from link_pit_rygar_sophia_audit_cpu import scoped_load
from check_tmnt_render_oa import address
O=R/'build/rogue-dawn-host-ui-v1';P=R/'build/rogue-dawn-host-hazards-v1'
REPORT=R/'docs/qa/rogue-dawn-host-menu-lives-ui-source-2026-10-29.json'
def main():
 assert not(O/'handoff.json').exists(),'Preserve immutable successor'
 build=json.loads((O/'build.json').read_text());checks={n:json.loads((O/n).read_text())for n in['controls.json','edge-controls.json','ordinary-controls.json']}
 for d in[build,*checks.values()]:
  assert d['passed']
  for q in d['bindings']:assert ref.binding(q['path'])==q,q['path']
  if 'ROM'in d:assert d['ROM']['sha256']==build['ROM']['sha256']
 negative=json.loads((O/'menu-palette-counterexample.json').read_text());raw=bytearray((O/'candidate.nes').read_bytes())
 for span in negative['reverse_spans_from_final']:
  at=span['file_offset'];z=bytes.fromhex(span['bytes']);raw[at:at+len(z)]=z
 assert ref.digest(raw)==negative['reconstructed_old_ROM_sha256']==negative['historical_ROM']['sha256']
 b=scoped_load(O/'candidate.nes');c=checks['controls.json']['checks'];e=checks['edge-controls.json']['checks']
 cmd=[str(R/'tools/Windows/cc65/bin/cc65.exe'),'--cpu','6502x','-t','nes','-g','-Oisr','-T','-I',str(R),'--create-full-dep',str(O/'c-full.dep'),'-o',str(O/'c-closure.s')]
 for i,v in enumerate(build['commands'][1]):
  if v=='-D':cmd+=['-D',build['commands'][1][i+1]]
 cmd+=[str(O/'main.c')];z=subprocess.run(cmd,cwd=R,capture_output=True,text=True);(O/'c-closure.log').write_text(z.stdout+z.stderr);assert z.returncode==0,z.stdout+z.stderr
 adeps=list(dict.fromkeys(closure.dependencies(O/'assembler-full.dep')+closure.dependencies(O/'weapon-object.dep')));cdeps=closure.dependencies(O/'c-full.dep')
 assert len(adeps)==build['actual_ASM_inputs']==512 and len(cdeps)==10
 summary=dict(status='PRIVATE bounded source-qualified menu/lives/late optional HUD successor; no menu/native admission',native_run=False,ROM=build['ROM'],parent=ref.binding(P/'candidate.nes'),preserved_parent=ref.binding(P/'handoff.json'),original_source=ref.binding(ref.ROM),
  layout=dict(new_A95=[hex(address(b,'RdUiGateStart')),hex(address(b,'RdUiGateEnd'))],A95_new_bytes=address(b,'RdUiGateEnd')-address(b,'RdUiGateStart'),A95_free_to_root_death_BF00=0xbf00-address(b,'RdUiGateEnd'),new_A121=[hex(address(b,'RdUiStart')),hex(address(b,'RdUiEnd'))],A121_new_bytes=address(b,'RdUiEnd')-address(b,'RdUiStart'),A121_free_to_item_BE00=0xbe00-address(b,'RdUiEnd'),new_RAM=0,CHR='All1MB exact e150. Native world palette1..3 and source palette0 adaptation unchanged. Root death50B, source CORE4090/AUX508/C94art+bridge and all old weapon/item/drop art literal.'),
  authored_UI_adaptation=dict(selection='Same raw Samus2 slot; real menu Select toggles RdVariant0/1, never a temporary raw-ID swap. Actual MenuResolveCharacter retains raw2. Uses genuine direct SamusPortrait callsite, not the unrelated roster portrait tail.',
   names='16-cell native-font ROGUE DAWN menu label; exact7-cell ROGUE status label overwrites only Buffer1+11..17. Byte18 and complete following WORLD/TIME command remain untouched. Native lives card and its number producer remain genuine.',
   portrait='Source-authenticated standing frame8/right with sourceAlt0, actual RdRenderPlayer and body window0 publication, genuine first-record C94 ownership. No action/motion tick or health/ammo/gear reward. Menu acquisition clears transient costume/missile selector BEFORE GetPlayerColors, which precedes portrait.',
   display='Existing safe11-cell2023 row: E099 M005 followed by two spaces. Energy=floor authenticated packedBCD health/10; source default09:99 displays099, raw07 heat is0.7 energy and does not force a packet until the visible integer changes. Missiles are authentic binary stock rendered000..255. No original Rogue UI/color/audio equivalence claim.',
   cache='Reuse only bypassed exact-owner InvHudName[2], InvHudAmmo and InvDirty; InvHudActive remains0. No newRAM/globalserviceflag. All cache writes occur after full14B command+terminator+offset commit. Busy/ineligible queues retain dirty/cache state.'),
  actual_late_admission=dict(caller='Real GameCoreRoutine ResetPalStar18B target, after actors/blocks/misc/cannons/flagpole/RunGameTimer/DrawAll/ColorRotation. Genuine ResetPalStar executes exactly once and its AXYP/SP returned state is preserved.',
   predicates=['exact raw2/RdVariant1','OperMode1/engine8/unpaused','DisableScreenFlag0/TimerControl0','VRAM_Buffer_AddrCtrl0','both queue offsets0 AND first payload bytes0','ReloadCHRBank0/source RdColorRequest0','SmFreezePalettePending0/legacy InvHudActive0','StarInvincibleTimer0/GuestPowerupActive0/PlayerChangeSizeFlag0','AreaParserTaskNum0/ScrollThirtyTwo<32'],
   later_closure='Only subsequent actual native producer is area parser after SaveAB; both of its actual dispatch predicates are excluded. IRQ does not append queues or request CHR. Main NmiDisableFF means any interruption before final publication is a lagNMI.',
   lag='A previously committed optional packet may survive lagNMI into another Main. New early actual GameLoop UI target retracts ONLY sole14B complete cache-matching packet: exact header/length/E/M/spaces/terminator, exact cached health digits, valid three-digit ammo equal cached stock with overflow rejection. Then sets dirty1 and clears only that own queue. Normal NMI already clears the packet, so normal early path does not retract anything.',
   early_ABI='At this sole early caller, X/Y are immediately LDX0/LDY7 and dead. New owner path may clobber them; A/P/VDI retained. Genuine foreign target RdLifeUi and all foreign outputs stay exact. No new dynamic callbacks or return-PC multiplexing.'),
  actual_checks=c,edge_checks=e,
  measured_costs=dict(new_foreign_complete_Main_CPU=[min(r['CPU_delta']for r in e['all_foreign_complete_Main_AXYP_SP_RAM_ordered_writes_banks']),max(r['CPU_delta']for r in e['all_foreign_complete_Main_AXYP_SP_RAM_ordered_writes_banks'])],new_foreign_menu_lives_status_CPU=[min(r['CPU_delta']for r in e['all_foreign_actual_menu_name_preview_lives_status']),max(r['CPU_delta']for r in e['all_foreign_actual_menu_name_preview_lives_status'])],optional_HUD_source_NMI_added_CPU=e['full_source_NMI_optional_packet_cost_no_native_deadline_claim']['extra_source_CPU'],prior='All prior e150/b95c/lifecycle wrapper costs remain separate. Shared final exact-ID routing is still required; no zero-cost or native-lag claim.'),
  ordinary=[dict(mapper=r['mapper'],ROM=r['ROM'])for r in checks['ordinary-controls.json']['rows']],
  actual_ASM_incbin_inputs=len(adeps),actual_C_inputs=len(cdeps),C_command=cmd,minimum_SP=min(v['minimum_SP']for v in checks.values()if 'minimum_SP'in v),
  preserved_negatives=dict(menu_palette=ref.binding(O/'menu-palette-counterexample.json'),counterexample='Old preliminary UI candidate97f6 queued alternate/missile palette [06,15,21] from stale sourceAlt1/missileMode1 before portrait cleared onlyAlt. New acquired-owner toggle clears BOTH transient selectors before palette. Exact old ROM reconstructs byte-for-byte from final image via two saved reverse spans; no old image is silently relabeled.',preparation=ref.binding(O/'preparation-negatives.jsonl'),classification='Recorded setup/comparison negatives include different direct-entry A banks, lag-only NMI fixture missing regular admission, missing test-only symbolic name and ordinary unconditional new-target compile rejection. These are not product/native failures.',old_standalone_flush_SP192=ref.binding(R/'build/rogue-dawn-host-deferred-v1/control-SP192-deferred-negative.json')),
  composition_obligations=['Frozen SMB2 Main already uses same late18B for S2MEnd; Goku may have another late wrapper. Final union needs one actual late dispatcher preserving ResetPalStar exactly once, not overlapping standalone source/E images.','Future Goku controller45B wrappers must retain actual RdLifeGameRoutines/RdLifeCheatRoutines foreign tails; constructor42B must rehome only in future union to124ADA4..ADCD. No frozen packet is changed here.','Both approved code pools are nearly full:32B A95,3B A121 remain before root death/items. Any new code requires measured plan; no silent newspan.'],
  remaining=['Root native menu/lives/body/HUD physicalDMA/CHR/fetch/PPU timing and actual full-world earned gameplay; source bus writes are not displayed pixels.','Authentic Rogue audio bridge remains ROOT-owned/open97. Current source controls initialize legacy audio only to keep real IRQ/NMI protocol valid; no stockSamus/source equivalence.','Source-only menu readiness does not expose a playable route or authorize a native launch. Final shared routing/cold overhead and exact combined native deadline must still qualify.'])
 REPORT.write_text(json.dumps(summary,indent=2)+'\n')
 own=[Path(__file__),REPORT,R/'src/rogue_dawn_host_ui_gate_v1.s',R/'src/rogue_dawn_host_ui_v1.s']+[R/'tools'/n for n in['prepare_rogue_dawn_host_ui_v1.py','rogue_dawn_host_ui_controls_v1.py','rogue_dawn_host_ui_edges_v1.py','rogue_dawn_host_ui_ordinary_v1.py']]
 own += [p for p in O.iterdir()if p.suffix in['.s','.inc','.c','.cfg','.dep','.patch','.json','.jsonl']and p.name not in['handoff.json','owned-files.json']]
 paths=adeps+cdeps+own+[Path(q['path'])for d in[build,*checks.values()]for q in d['bindings']]+[O/'candidate.nes',O/'candidate.dbg',O/'candidate.lbl',O/'candidate.map',O/'weapon-object.o',R/'tools/Windows/cc65/bin/cc65.exe',R/'tools/Windows/cc65/lib/nes.lib',R/'build/rogue-dawn-host-deferred-v1/control-SP192-deferred-negative.json']
 packet=dict(passed=True,source_only=True,native_run=False,playable_admission=False,ROM_sha256=build['ROM']['sha256'],report=ref.binding(REPORT),bindings=[ref.binding(p)for p in dict.fromkeys(paths)],owned_publication_files=[ref.binding(p)for p in dict.fromkeys(own)])
 h=O/'handoff.json';h.write_text(json.dumps(packet,indent=2)+'\n');m=dict(frozen=True,source_only=True,native_run=False,files=packet['owned_publication_files']+[ref.binding(h)]);(O/'owned-files.json').write_text(json.dumps(m,indent=2)+'\n')
 print(json.dumps(dict(ROM=build['ROM']['sha256'],handoff=ref.digest(h.read_bytes()),report=ref.digest(REPORT.read_bytes()),bindings=len(packet['bindings']),owned=len(m['files']))))
if __name__=='__main__':main()
