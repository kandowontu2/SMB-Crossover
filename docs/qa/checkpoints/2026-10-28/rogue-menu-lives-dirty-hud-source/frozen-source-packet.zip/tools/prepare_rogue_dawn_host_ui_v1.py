"""Sparse private e150 menu/lives/late-HUD successor. No native launch."""
from pathlib import Path
import difflib,json,re,subprocess,sys
R=Path(__file__).resolve().parents[1];sys.path[:0]=[str(R/'tools'),str(R/'tools/audit')]
import rogue_dawn_map_v1 as ref
import prepare_rogue_dawn_host_body_handoff_v1 as closure
from link_pit_rygar_sophia_audit_cpu import scoped_load
from check_tmnt_render_oa import address
from prepare_cv3_dmc_mirror import prepare
P=R/'build/rogue-dawn-host-hazards-v1';O=R/'build/rogue-dawn-host-ui-v1'
def once(s,a,z):assert s.count(a)==1,(a,s.count(a));return s.replace(a,z)
def main():
 assert not(O/'handoff.json').exists(),'Frozen successor'
 parent=json.loads((P/'handoff.json').read_text())
 for q in parent['bindings']:assert ref.binding(q['path'])==q,q['path']
 O.mkdir(exist_ok=True);b=scoped_load(P/'candidate.nes');changes={}
 for p in P.iterdir():
  if p.suffix in['.s','.inc','.c','.cfg']:
   (O/p.name).write_text(p.read_text().replace(str(P),str(O)),newline='\n')
 # Pin real transitive caller leaves. Their hashes were verified through the
 # frozen parent's actual ca65 full-dependency closure above.
 for n in ['character_select.s','screen_render.s','little_mac.s','little_mac_core.s']:
  (O/n).write_text((R/'src'/n).read_text(),newline='\n')
 def edit(name,fn):
  p=O/name;a=p.read_text();z=fn(a);assert a!=z,name;p.write_text(z,newline='\n');changes[name]=(a,z)
 edit('entrypoint.s',lambda s:once(s,'.include "rogue_dawn_death_art.inc"','.include "rogue_dawn_host_ui_gate_v1.s"\n.include "rogue_dawn_death_art.inc"'))
 edit('character_select.s',lambda s:once(once(s,'farcall NrMenuToggle','farcall RdUiToggle'),'farcall NrQueueSelectName,jmp','farcall RdUiName,jmp'))
 edit('screen_render.s',lambda s:once(s,'farcall SamusPortrait','.if ::ENABLE_MMC5_EXPANDED\n    farcall RdUiPortrait\n.else\n    farcall SamusPortrait\n.endif'))
 edit('little_mac_core.s',lambda s:once(s,' LmGate NrStatusName',' LmGate RdUiStatus'))
 edit('game.s',lambda s:once(once(s,'farcall ResetPalStar','.if ::ENABLE_MMC5_EXPANDED\n  farcall RdUiLateReset\n.else\n  farcall ResetPalStar\n.endif'),'farcall RdLifeUi','farcall RdUiEarly'))
 edit('weapon-object.s',lambda s:once(s,'.include "rogue_dawn_item_drop_art_v1.inc"','.include "rogue_dawn_host_ui_v1.s"\n.include "rogue_dawn_item_drop_art_v1.inc"'))
 aux=R/'src/rogue_dawn_host_ui_v1.s';main=R/'src/rogue_dawn_host_ui_gate_v1.s'
 code='\n'.join(line.split(';',1)[0]for line in aux.read_text().splitlines());code=re.sub(r'"[^"\n]*"','',code)
 imported=set(re.findall(r'\.import(?:zp)?\s+(\w+)', '\n'.join((O/n).read_text()for n in ['weapon-imports.inc','item-imports.inc','hazard-imports.inc'])))
 localtext='\n'.join((O/n).read_text()for n in ['weapon-source.s','world-source-v3.s'])+'\n'+(R/'src/rogue_dawn_host_items.s').read_text()+'\n'+(R/'src/rogue_dawn_host_hazards_drops_v1.s').read_text()+'\n'+aux.read_text()
 local=set(re.findall(r'^\s*(\w+)\s*:',localtext,re.M))|set(re.findall(r'\.proc\s+(\w+)',localtext))
 ext=sorted((set(re.findall(r'\b[A-Za-z_]\w*\b',code))&set(b['syms']))-local-imported)
 (O/'ui-imports.inc').write_text(''.join(('.importzp 'if b['syms'][n]['addrsize']=='zeropage'else'.import ')+n+'\n'for n in ext),newline='\n')
 public=['RdUiName','RdUiStatus','RdUiLateReset','RdUiEarly','RdUiStart','RdUiEnd']
 e=O/'entrypoint.s';e.write_text(e.read_text()+'\n.if ::ENABLE_MMC5_EXPANDED\n'+''.join('.export '+n+'\n'for n in ext)+''.join('.import '+n+'\n'for n in public)+'.endif\n',newline='\n')
 build=json.loads((P/'build.json').read_text());cmds=[[v.replace(str(P),str(O))for v in cmd]for cmd in build['commands']]
 cmds[0][1:1]=['-I',str(R)]
 for cmd,log in zip(cmds,['weapon-object.log','build.log']):
  z=subprocess.run(cmd,cwd=R,capture_output=True,text=True);(O/log).write_text(z.stdout+z.stderr);assert z.returncode==0,(z.stdout+z.stderr)[-6000:]
 prepare(R,O/'candidate.nes');n=scoped_load(O/'candidate.nes')
 deps=list(dict.fromkeys(closure.dependencies(O/'assembler-full.dep')+closure.dependencies(O/'weapon-object.dep')))
 patch=O/'source.patch';patch.write_text(''.join(''.join(difflib.unified_diff(a.splitlines(True),z.splitlines(True),fromfile='e150/'+name,tofile='private/'+name))for name,(a,z)in changes.items()),newline='\n')
 output=dict(passed=True,source_build_only=True,native_run=False,qualified=False,playable_admission=False,ROM=ref.binding(O/'candidate.nes'),parent=ref.binding(P/'candidate.nes'),commands=cmds,actual_ASM_inputs=len(deps),A95_end=hex(address(n,'RdUiGateEnd')),A121_end=hex(address(n,'RdUiEnd')),bindings=[ref.binding(p)for p in dict.fromkeys(deps+[Path(__file__),P/'handoff.json',main,aux,O/'candidate.nes',O/'candidate.dbg',O/'candidate.lbl',O/'candidate.map',O/'private.cfg',O/'ui-imports.inc',patch])],open=['No native/menu/audio admission. Complete caller, progress, IRQ, ordinary closure unqualified.'])
 (O/'build.json').write_text(json.dumps(output,indent=2)+'\n');print(json.dumps({k:output[k]for k in['ROM','actual_ASM_inputs','A95_end','A121_end']}))
if __name__=='__main__':main()
