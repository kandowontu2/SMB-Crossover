"""Actual private UI target spans, same-caller foreign ABI and IRQ closure."""
from pathlib import Path
import itertools,json,re,sys,traceback
R=Path(__file__).resolve().parents[1];sys.path[:0]=[str(R/'tools'),str(R/'tools/audit')]
import rogue_dawn_host_ui_controls_v1 as c
import rogue_dawn_host_lifecycle_edges_v1 as lifeedge
from check_tmnt_audio_fallback_oc import qualified
from check_tmnt_render_oa import address,location
from verify_native_relocation import NesMPU
from sunny_integrated_controls_v1 import run,app,registers,cleanwrites
O=c.O;P=c.P;w=c.w;get,put,call=c.get,c.put,c.call
def main():
 b=w.life.d.old.scoped_load(O/'candidate.nes');old=w.life.d.old.scoped_load(P/'candidate.nes');checks={};minimum=255
 proof=dict(passed=False,source_CPU_only=True,native_run=False,ROM=w.ref.binding(O/'candidate.nes'),checks=checks)
 try:
  diff=[i for i,(x,y)in enumerate(zip(old['raw'],b['raw']))if x!=y];allowed=set();spans=[];found=set()
  for bank,lo,hi in[(95,0xbe43,0xbf00),(121,0xbb96,0xbe00)]:allowed.update(range(16+bank*8192+(lo&8191),16+bank*8192+(hi&8191)))
  targets={'NrMenuToggle':'RdUiToggle','NrQueueSelectName':'RdUiName','SamusPortrait':'RdUiPortrait','NrStatusName':'RdUiStatus','ResetPalStar':'RdUiLateReset','RdLifeUi':'RdUiEarly'}
  for i in diff:
   if i in allowed:continue
   for at in range(max(16,i-17),i+1):
    a=old['raw'][at:at+18];z=b['raw'][at:at+18]
    for before,after in targets.items():
     pc=address(old,before)
     if a[3:13]!=bytes([169,pc&255,141,108,1,169,pc>>8,141,109,1]):continue
     expect=bytearray(a);v=address(b,after);expect[4]=v&255;expect[9]=v>>8;expect[14]=128|(location(b,after)-16)//8192
     assert z==expect,(before,after,at,a.hex(),z.hex(),expect.hex())
     allowed.update([at+4,at+9,at+14])
     if at not in found:
      seg=next(g for g in old['segs'].values()if 'ooffs'in g and int(g['ooffs'],0)<=at<int(g['ooffs'],0)+int(g['size'],0))
      spans.append(dict(old=before,new=after,bank=(at-16)//8192,PC=hex(int(seg['start'],0)+at-int(seg['ooffs'],0)),file_offset=at,bytes=18,before=a.hex(),after=z.hex()));found.add(at)
  assert all(i in allowed for i in diff),[(i,(i-16)//8192)for i in diff if i not in allowed][:15]
  assert len(spans)==6 and old['raw'][16+1048576:]==b['raw'][16+1048576:]
  assert b['raw'][16+95*8192+0x1f00:16+96*8192]==old['raw'][16+95*8192+0x1f00:16+96*8192]
  a,z=qualified(P/'candidate.nes'),qualified(O/'candidate.nes');moved=[]
  for name,v in a.items():
   if z.get(name)==v:continue
   s='::'.join(name);assert s in['farcall_count','_FARCALL_COUNT','__ROGUE_DAWN_HOST_SIZE__','__ROGUE_DAWN_HOST_AUX_SIZE__'],(s,v,z.get(name));moved.append([s,v,z.get(name)])
  checks['exact_six_target_only_rebindings_new_code_and_all_old_PC_RAM']=dict(changed_ROM_bytes=len(diff),perbank={k:sum(1 for i in diff if(i-16)//8192==k)for k in sorted(set((i-16)//8192 for i in diff))},target_spans=spans,old_qualified_symbols=len(a),compile_time_metadata_changes=moved,CHR_all_exact=True,root_death_tail_exact=True,all_earlier_core_aux_bridge_code_exact=True)
  rows=[]
  for (char,key,var),mode in itertools.product(lifeedge.PROFILES,[0,1]):
   pair=[]
   for bundle in[old,b]:
    q=lifeedge.foreign(bundle,char,key,var,mode);cpu,wr,_=run(q,'GameLoop',p=0x71);pair.append((registers(cpu),app(q),tuple(q.m.banks),cleanwrites(q,wr),cpu.processorCycles))
   assert pair[0][:4]==pair[1][:4],('foreign actual Main',char,key,var,mode,pair[0][0],pair[1][0])
   rows.append(dict(raw=char,variant=var,mode=mode,CPU_delta=pair[1][4]-pair[0][4]))
  checks['all_foreign_complete_Main_AXYP_SP_RAM_ordered_writes_banks']=rows
  print('ROM spans and all foreign full Mains pass',flush=True)
  rows=[]
  for (char,key,var),entry in itertools.product(lifeedge.PROFILES,['QueueSelection','DrawSelectionPreview','DisplayIntermediate','LmStatusNameGate']):
   pair=[]
   for bundle in[old,b]:
    q=lifeedge.foreign(bundle,char,key,var);q.put(OperMode=0,CrossoverMenuIndex=min(char,20),DisableIntermediate=0,AltEntranceControl=0,DisableScreenFlag=0)
    cpu,wr,_=run(q,entry,a=0,x=17,y=23,p=0x71);pair.append((registers(cpu),app(q),tuple(q.m.banks),cleanwrites(q,wr),cpu.processorCycles))
   assert pair[0][:4]==pair[1][:4],('foreign actual menu/lives/status',char,key,var,entry,pair[0][0],pair[1][0])
   rows.append(dict(raw=char,variant=var,caller=entry,CPU_delta=pair[1][4]-pair[0][4]))
  checks['all_foreign_actual_menu_name_preview_lives_status']=rows
  rows=[]
  target={'RdUiPortrait':'SamusPortrait','RdUiName':'NrQueueSelectName','RdUiStatus':'NrStatusName','RdUiEarly':'RdLifeUi'}
  for char,var,entry in itertools.product([0,1,2,21,23,255],[0,1,2,255],target):
   if(char,var)==(2,1):continue
   m=w.life.make(b);put(m,SelectedCharacter=char);m[0x5fee]=var;pc=address(b,entry);bank=(location(b,entry)-16)//8192;m.page(1,bank);put(m,CurrentBank=128|bank)
   cpu=NesMPU(memory=m,pc=pc);cpu.a,cpu.x,cpu.y,cpu.p,cpu.sp=91,17,23,0x71,224;cpu.stPushWord(0x5aff);m.reads.clear()
   for k in range(80):
    if cpu.pc==address(b,target[entry])and m.banks[(cpu.pc-0x8000)//8192]==(location(b,target[entry])-16)//8192:break
    cpu.step()
   else:raise AssertionError(('foreign target not reached',entry,char,var,hex(cpu.pc)))
   assert not m.reads&set(range(0x5c00,0x5c80))and not m.reads&set(range(0x5fb0,0x5fb8)),(entry,char,var,sorted(m.reads&set(range(0x5c00,0x5c80))))
   rows.append([entry,char,var])
  checks['all_new_foreign_prefixes_no_active_or_resource_overlay_read']=dict(cases=len(rows),selector='RdVariant only after raw2')
  rows=[]
  for name,bank in[('RdUiHud::Write',121),('RdUiEarly::Retract',121),('RdUiPortrait',95),('RdUiName',121),('RdUiStatus',121)]:
   for kind in['IRQ','lagNMI']:
    m=c.ready(b)
    if name.startswith('RdUiEarly'):call(m,'RdUiLateReset');entry='RdUiEarly'
    elif name=='RdUiPortrait':entry='DrawPlayer_Intermediate'
    elif name=='RdUiName':entry='QueueSelectName'
    elif name=='RdUiStatus':entry='LmStatusNameGate'
    else:entry='RdUiLateReset'
    cpu,l,tr=call(m,entry,sp=240,seam=(address(b,name),bank,kind));minimum=min(minimum,l)
    rows.append(dict(entry=entry,seam=name,kind=kind,minimum_SP=l))
  # Same source Main admission / natural IdleLoop SP; optional HUD packet is
  # live across the mid-copy interruption and committed atomically afterward.
  for kind in['IRQ','lagNMI']:
   m=w.life.make(b);put(m,DisableScreenFlag=0);call(m,'NrFreshGameInit');c.step(m,0,first=True);w.life.wake(m)
   cpu,row=w.life.mainstep(m,first=True,seam=(address(b,'RdUiHud::Write'),121,kind));minimum=min(minimum,row['minimum_SP'])
   assert row['actual_Main_calls']==(2 if kind=='lagNMI' else 1)
   rows.append(dict(entry='actual_IdleLoop_Main',seam='RdUiHud::Write',kind=kind,minimum_SP=row['minimum_SP'],actual_Mains=row['actual_Main_calls']))
  checks['actual_entry_and_full_Main_IRQ_lagNMI_live_stack_5SMC_banks']=rows
  print('foreign menu/lives, exact owner and actual ISR seams pass',flush=True)
  rows=[]
  for mode in[0,1]:
   m=w.life.make(b,mode);call(m,'X5ColdInit');put(m,SelectedCharacter=2,OperMode=0,CrossoverMenuState=2,CrossoverMenuIndex=2,CrossoverMenuButtons=0,SavedJoypad1Bits=32,DisableScreenFlag=0);call(m,'CrossoverMenuInput',sp=240)
   assert get(m,'RdVariant')==1 and get(m,'InvHudActive')==0
   put(m,CrossoverMenuButtons=0,SavedJoypad1Bits=16,CrossoverContinue=0);cpu,l,tr=call(m,'CrossoverMenuInput',sp=240);minimum=min(minimum,l)
   assert bytes(m[0x5fb0:0x5fb6])==bytes([0,0,0,0,153,9])and get(m,'RdVariant')==1
   assert any(pc==address(b,'RdLifeFresh')and bank==95 for pc,bank in tr)
   put(m,OperMode=1,AreaType=1,AreaAddrsLOffset=5,GameEngineSubroutine=8);cpu,l,tr=call(m,'InitializeArea',sp=240);minimum=min(minimum,l)
   assert get(m,'InvHudActive')==0 and all(get(m,'InvDropKind',i)==0 for i in range(4))
   # Scene transition preserves actual source resources; real life-loss receipt
   # refills capacity, not gear/ammo reset. Cache comparison updates naturally.
   call(m,'RdHsGrantType',a=9);call(m,'RdHsGrantType',a=8);call(m,'RdHsDamage',a=0x80,y=0)
   before=bytes(m[0x5fb0:0x5fb6]);put(m,MmDeathFlag=0,AreaAddrsLOffset=6);call(m,'InitializeArea',sp=240);assert bytes(m[0x5fb0:0x5fb6])==before
   put(m,MmDeathFlag=1);call(m,'InitializeArea',sp=240);assert bytes(m[0x5fb0:0x5fb4])==before[:4]and list(m[0x5fb4:0x5fb6])==[153,25]
   assert get(m,'InvHudActive')==0
   rows.append(dict(mode=mode,raw_selected=2,variant=get(m,'RdVariant'),fresh_resources=[0,0,0,0,153,9],scene_persistent=list(before),new_life=list(m[0x5fb0:0x5fb6]),font_lease_inactive=True,minimum_SP=l))
  checks['actual_menu_fresh_InitializeArea_scene_life_and_font_lease']=rows
  rows=[]
  for present in[False,True]:
   m=c.ready(b);cpu,l,tr=call(m,'RdUiLateReset');producer=cpu.processorCycles
   if not present:put(m,VRAM_Buffer1=0,VRAM_Buffer1_Offset=0)
   cpu=NesMPU(memory=m,pc=0x5b00);cpu.a,cpu.x,cpu.y,cpu.p,cpu.sp=91,17,23,0x71,253
   saved=(cpu.a,cpu.x,cpu.y,cpu.p&207,cpu.sp,tuple(m.banks));m.writes.clear();cpu.nmi();enable=None
   for _ in range(100000):
    if cpu.pc==0x5b00 and cpu.sp==253:break
    if cpu.pc==0xe00b and m.banks[3]==127:enable=cpu.processorCycles+4
    cpu.step()
   else:raise AssertionError('real NMI budget caller timeout')
   assert (cpu.a,cpu.x,cpu.y,cpu.p&207,cpu.sp,tuple(m.banks))==saved
   image,bus=c.ppu(m.writes)
   rows.append(dict(optional_packet=present,source_CPU=cpu.processorCycles,source_enable_CPU_excluding_DMA_stall_DMC=enable,actual_DMA_requests=sum(a==0x4014 for a,v in m.writes),producer_CPU=producer,HUD_bus=[list(z)for z in bus if 0x2023<=z[0]<0x202e]))
  assert len(rows[0]['HUD_bus'])==0 and len(rows[1]['HUD_bus'])==11
  checks['full_source_NMI_optional_packet_cost_no_native_deadline_claim']=dict(rows=rows,extra_source_CPU=rows[1]['source_CPU']-rows[0]['source_CPU'],no_CHR_reload=True,no_pending_freeze_packet=True,limits='Actual CPU instruction schedule only; DMA stall513/514, DMC/PPU scheduling and real render-enable deadline remain ROOT native obligations.')
  proof.update(passed=True,minimum_SP=minimum,limits=['CPU/source-only; actual menu/body/HUD pixels, full native NMI deadline and source audio still OPEN.','New owned early UI caller may clobber X/Y because its only continuation immediately LDX0/LDY7; A/P/VDI and all actual foreign outputs preserved.','Six standalone target rebindings must compose with SMB2/Goku late Main and future raw24 controller wrappers, not overlay their standalone bytes.'])
 except BaseException as e:
  proof.update(error=str(e),traceback=traceback.format_exc())
  with (O/'preparation-negatives.jsonl').open('a')as f:f.write(json.dumps(dict(ROM=proof['ROM']['sha256'],error=str(e),traceback=traceback.format_exc()))+'\n')
  raise
 finally:
  proof['bindings']=[w.ref.binding(p)for p in[Path(__file__),O/'build.json',O/'candidate.nes',O/'candidate.dbg',R/'src/rogue_dawn_host_ui_gate_v1.s',R/'src/rogue_dawn_host_ui_v1.s',R/'tools/rogue_dawn_host_ui_controls_v1.py',R/'tools/rogue_dawn_host_lifecycle_edges_v1.py']]
  (O/'edge-controls.json').write_text(json.dumps(proof,indent=2)+'\n')
 print(json.dumps(dict(passed=True,minimum_SP=minimum,sections=len(checks))))
if __name__=='__main__':main()
