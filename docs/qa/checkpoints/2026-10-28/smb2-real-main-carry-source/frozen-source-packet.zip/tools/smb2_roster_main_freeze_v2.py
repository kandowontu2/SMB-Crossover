"""Freeze the bounded private complete-Main CPU unit, with explicit admission gaps."""
from pathlib import Path
import collections,difflib,json,re,subprocess,sys
import prepare_smb2_roster_main_v2 as B
import smb2_roster_audio_freeze_v1 as F
from check_tmnt_render_oa import address,location
from link_pit_rygar_sophia_audit_cpu import scoped_load
ROOT=B.ROOT;OUT=B.OUT;bind=B.bind
NOTE=ROOT/'docs/qa/smb2-roster-main-source-2026-10-29.txt'

def main():
    source,j=B.A.Rel.check_parent();build=json.loads((OUT/'build-proof.json').read_text())
    assert bind(OUT/'candidate.nes')==build['candidate']and bind(B.__file__)==build['tool']
    for n in['main-controls.json','caller-controls.json']:
        q=json.loads((OUT/n).read_text());assert q['passed']and q['candidate']==build['candidate']
        assert bind(q['tool']['path'])==q['tool']
    command=j['command'].copy();command[command.index('--create-full-dep')+1]=str(OUT/'source-closure.d')
    command[command.index('-o')+1]=str(OUT/'source-closure.o');command[-1]=str(OUT/'objects/entrypoint.s')
    command[4:4]=['-I',str(OUT/'overlay/src')]
    r=subprocess.run(command,cwd=ROOT,capture_output=True,text=True)
    (OUT/'source-closure-launcher.txt').write_text(r.stdout+r.stderr)
    assert not r.returncode,r.stderr[-2000:]
    line=(OUT/'source-closure.d').read_text().splitlines()[0].split(':\t',1)[1]
    deps={Path(v.replace('\\ ',' ')).resolve()for v in re.split(r'(?<!\\)\s+',line.strip())}
    for row in build['changed_shared_overlay_only']:
        assert Path(row['staged']['path']).resolve()in deps,('staged leaf not consumed',row['staged'])
    assert OUT/'overlay/src/little_mac.s'in deps,'Nested pickup includes require their actual staged ancestor'
    for p in[ROOT/'src/smb2_roster_main_v2.s',ROOT/'src/smb2_roster_main_gates_v2.s']:assert p in deps
    bs=list(map(scoped_load,[ROOT/'build/smb2-roster-audio-v1/candidate.nes',OUT/'candidate.nes']))
    old,new=(x['raw']for x in bs);assert len(old)==len(new)and old[:16]==new[:16]
    assert new[16+1048576+796*1024:16+1048576+808*1024]==(ROOT/'chr/characters/smb2-roster.chr').read_bytes()
    assert old[16+1048576:16+1048576+796*1024]==new[16+1048576:16+1048576+796*1024]
    assert old[16+1048576+808*1024:]==new[16+1048576+808*1024:]
    b=bs[1];extents={n:address(b,n)for n in['S2MainBegin','S2MainEndCode','S2MainGatesBegin','S2MainGatesEnd']}
    assert extents['S2MainBegin']==0xb8cb and extents['S2MainEndCode']<=0xc000
    assert extents['S2MainGatesBegin']==0xbc81 and extents['S2MainGatesEnd']<=0xc000
    assert all(new[16+127*8192+i]==new[16+c*8192+i]for c in[119,120]for i in list(range(0x1140))+list(range(0x1e11,8192)))
    for n in['GrowThePowerUp','ChkPUSte','RunPUSubs','RunNormalEnemies','RyuPlatformErase']:
        assert(address(bs[0],n),location(bs[0],n))==(address(bs[1],n),location(bs[1],n)),n
    # Source/reference scan is literal. No computed jump/table reads target
    # an interior rise byte; all entry/exit operands retain genuine symbols.
    refs=[]
    for p in(ROOT/'src').glob('*.s'):
        for i,l in enumerate(p.read_text().splitlines(),1):
            if re.search(r'\b(GrowThePowerUp|ChkPUSte|RunPUSubs)\b',l):refs.append(dict(path=str(p),line=i,text=l))
    assert len([x for x in refs if 'GrowThePowerUp'in x['text']and ':'not in x['text']])==1
    delta=collections.Counter((p-16)//8192 for p,(a,z)in enumerate(zip(old,new))if a!=z)
    ordinary=[]
    for mapper in['mmc3','mmc5']:
        dest=OUT/('flagoff-'+mapper+'.nes')
        cmd=[sys.executable,str(ROOT/'tools/build_mmc5_expanded.py'),'--source-overlay',str(OUT/'overlay'),
            '--output',str(dest),'--flag-off',mapper]
        p=subprocess.run(cmd,cwd=ROOT,capture_output=True,text=True)
        (OUT/('flagoff-'+mapper+'-launcher.txt')).write_text(p.stdout+p.stderr)
        assert not p.returncode,p.stderr[-2000:]
        ref=ROOT/('build/celeste-small-chr-'+mapper+'.nes');assert dest.read_bytes()==ref.read_bytes(),mapper
        ordinary.append(dict(mapper=mapper,actual=bind(dest),reference=bind(ref)))
    patch=''
    for p in sorted((OUT/'overlay/src').glob('*.s')):
        base=ROOT/'src'/p.name
        if base.read_text()==p.read_text():continue
        patch+=''.join(difflib.unified_diff(base.read_text().splitlines(True),p.read_text().splitlines(True),
            fromfile='a/src/'+p.name,tofile='b/src/'+p.name))
    for n in['smb2_roster_main_v2.s','smb2_roster_main_gates_v2.s']:
        p=ROOT/'src'/n;patch+=''.join(difflib.unified_diff([],p.read_text().splitlines(True),fromfile='/dev/null',tofile='b/src/'+n))
    (OUT/'implementation.patch').write_text(patch,newline='\n')
    owned=[ROOT/'src'/n for n in['smb2_roster_main_v2.s','smb2_roster_main_gates_v2.s']]
    owned += [ROOT/'tools'/n for n in['prepare_smb2_roster_main_v2.py','smb2_roster_main_controls_v2.py',
        'smb2_roster_main_callers_v2.py','smb2_roster_main_freeze_v2.py']]+[NOTE,OUT/'implementation.patch',OUT/'overlay/smb1base-mmc5-expanded.cfg']
    owned+=list((OUT/'overlay/src').glob('*.s'))
    consumed=deps|{source,ROOT/'src/main.c',ROOT/'build_options.ini',ROOT/'tools/build_mmc5_expanded.py',
        ROOT/'tools/prepare_cv3_dmc_mirror.py',Path(sys.executable),OUT/'objects/asset.s'}
    for r in j['bindings']:
        if Path(r).suffix.lower()in['.exe','.cfg','.ini']:consumed.add(Path(r))
    for mod in list(sys.modules.values()):
        f=getattr(mod,'__file__',None)
        if f:
            p=Path(f).resolve()
            if p.suffix=='.py'and(p.is_relative_to(ROOT)or'py65'in p.parts):consumed.add(p)
    for p in Path(sys.executable).parent.glob('python3*.dll'):consumed.add(p)
    closure=dict(passed=True,source_only=True,actual_ASM_dependencies=len(deps),candidate=build['candidate'],
        parent_audio=bind(ROOT/'build/smb2-roster-audio-v1/candidate.nes'),source_command=command,
        actual_changed_banks=dict(delta),extents=extents,rise_references=refs,ordinary=ordinary,
        actual_inputs=[bind(p)for p in sorted(consumed)],tool=bind(__file__))
    path=OUT/'source-closure.json';path.write_text(json.dumps(closure,indent=2)+'\n')
    outputs=[p for p in OUT.iterdir()if p.is_file()and p.name!='handoff.json']
    outputs+=list((OUT/'objects').glob('*'))
    handoff=dict(status='HELD_PRIVATE_MAIN_CPU_FUNCTIONAL_UNIT_NOT_HOST_ADMITTED_NO_NATIVE',candidate=build['candidate'],
        canonical_parent=build['canonical_parent'],source_closure=bind(path),Main=bind(OUT/'main-controls.json'),
        callers_IRQ=bind(OUT/'caller-controls.json'),extents=extents,
        immutable_prior=[bind(ROOT/'build'/x/'handoff.json')for x in['smb2-roster-component-v1','smb2-roster-palette-v2',
            'smb2-roll-relocation-v1','smb2-roster-audio-v1']],
        owned_files=[bind(p)for p in sorted(set(owned))],input_bindings=closure['actual_inputs'],
        output_bindings=[bind(p)for p in sorted(set(outputs))],
        open_requirements=['Temporary gate performance cost on foreign Main; requires coherent shared admission',
            'P1 eye/vegetable role composition with native enemy palette, no palette stealing',
            'Native carried-enemy room transfer and battle/reset consumers beyond the finite proven contact arena',
            'Cheat/full-power admission, menu, native NmiClock scheduling, atomic audio cues/mixer/DMC ownership',
            'Actual native cold-start/PPU/render/cadence/gameplay qualification'])
    dest=OUT/'handoff.json';dest.write_text(json.dumps(handoff,indent=2)+'\n')
    print(json.dumps(dict(handoff=bind(dest),ASMdeps=len(deps),inputs=len(consumed),owned=len(set(owned)),outputs=len(set(outputs)),extents=extents),indent=2))

if __name__=='__main__':main()
