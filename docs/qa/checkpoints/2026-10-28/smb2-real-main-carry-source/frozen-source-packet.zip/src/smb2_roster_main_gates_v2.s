; PRIVATE Main-only farcall chaining; all targets are genuine linked owners.
; Never reached from NMI. Shared source routing remains ROOT-owned.
.pushseg
.segment "KIRBY_ABILITIES"
.export S2MainGatesBegin,S2MainGatesEnd,S2MainNativePointers
S2MainGatesBegin:
S2MainGateCount .set 0
.macro S2MainGate Name,Own,Legacy,Index
.proc Name
 php
 pha
 txa
 pha
 tya
 pha
 ldy #Index
 jmp S2MainGateCommon
.endproc
.export Name
.ident(.sprintf("S2MainOwnLo%u",S2MainGateCount))=<Own
.ident(.sprintf("S2MainOwnHi%u",S2MainGateCount))=>Own
.ident(.sprintf("S2MainOwnBank%u",S2MainGateCount))=.bank(Own)|$80
.ident(.sprintf("S2MainLegacyLo%u",S2MainGateCount))=<Legacy
.ident(.sprintf("S2MainLegacyHi%u",S2MainGateCount))=>Legacy
.ident(.sprintf("S2MainLegacyBank%u",S2MainGateCount))=.bank(Legacy)|$80
S2MainGateCount .set S2MainGateCount+1
.endmacro

; Data expressions below are actual linked target bytes, never callable
; aliases or guessed PC/bank metadata. Only raw25 selects the new endpoints.
S2MainGate S2MGames,S2MainGame,GameRoutines,0
S2MainGate S2MGraphics,S2Graphics,RlGraphicsDispatch,1
S2MainGate S2MDraw,S2MainDraw,RlDrawDispatch,2
S2MainGate S2MVisible,S2MainVisible,JnVisibleDispatch,3
S2MainGate S2MInjury,S2MainInjury,JnInjuryStartDispatch,4
S2MainGate S2MStatus,S2MainStatus,JnInjuryStatusDispatch,5
S2MainGate S2MDeathStart,S2DeathStart,JnInventoryDeathDispatch,6
S2MainGate S2MDeath,S2DeathUpdate,JnDeathDispatch,7
S2MainGate S2MScene,S2MainScene,JnResetDispatch,8
S2MainGate S2MFresh,S2MainFresh,CmHostFresh,9
S2MainGate S2MPickup,S2MainPickup,JnPickupDispatch,10
S2MainGate S2MPrepare,S2MainPrepare,NrPrepare,11
S2MainGate S2MRise,S2MainNativeNoop,NrRise,12
S2MainGate S2MPrivate,S2MainNativeNoop,NrPrivate,13
S2MainGate S2MMature,S2MainMature,NrPickupCollision,14
S2MainGate S2MUi,S2MainUi,VvUiDispatch,15
S2MainGate S2MStomp,S2MainStomp,X5StompDispatch,16
S2MainGate S2MPlatform,S2MainPlatform,Z2PositionOnPlatform,17
S2MainGate S2MBody,S2MainBody,JnBodyDispatch,18
S2MainGate S2MWeapons,S2MainProjectiles,RlWeaponsDispatch,19
S2MainGate S2MBox,S2MainBox,LmBoundingBoxGate,20
S2MainGate S2MEnd,S2MainEnd,ResetPalStar,21
S2MainGate S2MEndStar,S2MainEndStar,CyclePlayerPalettePreload,22
S2MainGate S2MColors,S2MainPalette,X5GetPlayerColors,23
S2MainGate S2MSpawn,S2MainSpawn,CrossoverLevelEnemyInit,24
S2MainGate S2MImmunity,S2MainImmunity,MarioSourceBodyImmunity,25
S2MainGate S2MAdder,S2MainAdder,RlAdderDispatch,26
S2MainGate S2MBoxProfile,S2MainBoxProfile,RlBoxDispatch,27
S2MainGate S2MHead,S2Head,JnHeadDispatch,28
S2MainGate S2MSide,S2Side,Z2SideAdmission,29

.proc S2MainGateCommon
 ; No private RAM/R0..R7 lease. Caller AXYP are already on the real stack.
 lda SelectedCharacter
 cmp #25
 beq Own
 tya
 clc
 adc #::S2MainGateCount
 tay
Own:
 lda TargetLo,y
 sta FarcallJmpTarget_SMC+1
 lda TargetHi,y
 sta FarcallJmpTarget_SMC+2
 lda TargetBank,y
 sta NextBank_SMC+1
 pla
 tay
 pla
 tax
 pla
 sta SafecallA_SMC+1
 plp
 lda NextBank_SMC+1
 jmp FarCallCommon
TargetLo:
 .repeat ::S2MainGateCount,I
 .byte .ident(.sprintf("S2MainOwnLo%u",I))
 .endrepeat
 .repeat ::S2MainGateCount,I
 .byte .ident(.sprintf("S2MainLegacyLo%u",I))
 .endrepeat
TargetHi:
 .repeat ::S2MainGateCount,I
 .byte .ident(.sprintf("S2MainOwnHi%u",I))
 .endrepeat
 .repeat ::S2MainGateCount,I
 .byte .ident(.sprintf("S2MainLegacyHi%u",I))
 .endrepeat
TargetBank:
 .repeat ::S2MainGateCount,I
 .byte .ident(.sprintf("S2MainOwnBank%u",I))
 .endrepeat
 .repeat ::S2MainGateCount,I
 .byte .ident(.sprintf("S2MainLegacyBank%u",I))
 .endrepeat
.endproc

.proc S2MainNativePointers
 farcall HpPrepareNativePointers
 lda SelectedCharacter
 cmp #25
 beq Own
 jsr CrossoverGraphicsBank
 rts
Own:
 farcall S2GraphicsBank
 farcall S2PublishBody
 rts
.endproc
S2MainGatesEnd:
.assert S2MainGatesEnd<=$c000,lderror,"SMB2 Main gates need reviewed A74 capacity"
.popseg
