"""Seal one private foreground admission unit; native/audio/drop remain open."""
from pathlib import Path
import difflib,json,re,subprocess,sys
R=Path(__file__).resolve().parents[1];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import dragon_power_gameplay_controls_v1 as C
from sunny_integrated_controls_v1 import *
P=C.O;O=R/'build/dragon-power-admission-v1'
def bind(p):
 p=Path(p).resolve();return dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))
def main():
 assert not(O/'handoff.json').exists()
 assert sha(P/'handoff.json')=='41a77916d651c7a2166b021c240ab59b703174161847513aa9d4a4e0a89573bf'
 rom=O/'candidate.nes';old,b=[scoped_load(p/'candidate.nes')for p in[P,O]]
 receipts={n:json.loads((O/n).read_text())for n in['controls-release.json','gameplay-consumers-release.json']}
 for n,d in receipts.items():
  assert d['passed']and d['bindings'][str(rom.resolve())]==sha(rom),n
  for p,h in d['bindings'].items():assert sha(p)==h,(n,p)
 raw=rom.read_bytes();ref=(P/'candidate.nes').read_bytes();checks={}
 banks={k:sum(a!=z for a,z in zip(ref[16+k*8192:16+(k+1)*8192],raw[16+k*8192:16+(k+1)*8192]))for k in range(128)};banks={k:v for k,v in banks.items()if v}
 assert set(banks)=={66,81,85,86,124},banks
 assert raw[:16]==ref[:16]
 chrpages={i for i in range(1024)if raw[1048592+i*1024:1048592+(i+1)*1024]!=ref[1048592+i*1024:1048592+(i+1)*1024]}
 assert chrpages<=set(range(4,8))|set(range(788,796)),chrpages
 for bank in[125,127]:assert raw[16+bank*8192:16+(bank+1)*8192]==ref[16+bank*8192:16+(bank+1)*8192]
 assert raw[16+124*8192+0xda4:16+124*8192+0xdce]==bytes([255])*42
 for n in['NrUi','NrStatusName','NrPortrait','NrColors','NrReset','NrFreshGameInit','NrQueueSelectName','DpGameC','DpGameHurt','DpHostController','FIXED','SamusFreezeFlushPalette']:
  assert address(b,n)==address(old,n),(n,'public PC moved')
 assert address(b,'DpAdmissionNameResume')==address(old,'NrQueueSelectName::CmOtherName')
 checks['layout']=dict(PRG_byte_delta_vs_7b96=banks,changed_CHR_pages=sorted(chrpages),header_fixed_clones_Samus_and_Rogue_future_exact=True,
  CORE_bytes=6128,CORE_end_exclusive='BFF0',remaining_CORE=16,new_C_code='D100..<D291,401B',approved_C_tail_remaining=1647,
  existing_public_entries_fixed=True,one_genuine_new_resume_label_at_original_B713=True,
  removed_private_prefix_label='NrQueueSelectName::CmMarioName; only its replaced prefix branched here',
  NrUi_internal_labels_replaced_by_151B_bounded_table=True,no_fake_aliases=True,no_new_RAM_state_or_segment=True)
 rows=[]
 for ch,mode,keys in[(ch,m,k)for ch in[0,1,2,3,5,6,8,13,15,19,20,21,22,23,25,26,27,28]for m in[0,1]for k in[0,129]]:
  pair=[]
  for v in[old,b]:
   q=C.setup(v,ch);q.put(CrossoverBehaviorVersion=mode,SavedJoypadBits=keys)
   c,tr,mn=C.M.runtrace(q,'GameLoop',p=0x71)
   exclude=set(smc_at(v))|{address(v,'CurrentBank')}
   writes=[(i,z)for i,z in q.m.writes if not 0x17b<=i<0x200 and i not in exclude and not 0x5114<=i<=0x5117]
   pair.append(((registers(c),C.M.fastapp(q),bytes(q.m[0x100:0x17b]),tuple(q.m.banks)),writes,c.processorCycles,mn))
  assert pair[0][:2]==pair[1][:2],('foreign Main',ch,mode,keys)
  rows.append([ch,mode,keys,pair[1][2]-pair[0][2],pair[1][3]])
 checks['foreign_complete_Main']=dict(cases=len(rows),whole_AXYP_SP_application_live_page1_all33SMC_banks_remaining_ordered_writes_exact=True,
  CPU_delta=[min(z[3]for z in rows),max(z[3]for z in rows)],min_SP=min(z[4]for z in rows),rows=rows)
 # Reuse only the exact compilation command structure, not any old result.
 commands=json.loads((P/'final-controls.json').read_text())['checks']['genuine_ASM_closure']['commands'];deps={};actual=[]
 for prior in commands:
  cmd=[v.replace(str(P),str(O))for v in prior]
  z=subprocess.run(cmd,cwd=R,capture_output=True,text=True);assert z.returncode==0,z.stderr;actual.append(cmd)
 for p in[O/'main-final.d',O/'component-final.d']:
  for word in re.split(r'(?<!\\)\s+',p.read_text().split(':\t',1)[1].strip().removesuffix(':')):
   f=Path(word.replace('\\ ',' '));f=(f if f.is_absolute()else R/f).resolve();assert f.is_file();deps[str(f)]=sha(f)
 from prepare_cv3_dmc_mirror import prepare
 prepare(R,O/'independent.nes');assert sha(O/'independent.nes')==sha(rom)
 checks['independent_actual_ASM_link']=dict(dependencies=len(deps),commands=actual,ROM_exact=True,actual_DBG_LBL_emitted=True,regenerated_125_from_final127=True,future_E_clones_must_regenerate_from_same_final127=True)
 for n,h in[('mmc3','d444cac88e13fa02b29ad16100b8f08fa565ba90f8cedde192de43fb2dc8f3eb'),('mmc5','f4ffd2483c51daa4d60bb575da2da8c4d817692cda407611c243031f67520833')]:assert sha(O/('ordinary-'+n+'.nes'))==h
 checks['ordinary_hashes_exact']=True
 (O/'final-controls.json').write_text(json.dumps(dict(passed=True,source_CPU_only=True,native_run=False,candidate_sha256=sha(rom),checks=checks),indent=2)+'\n')
 patch=''
 for original,target,name in[(P/'src/new_roster_dispatch.s',O/'src/new_roster_dispatch.s','src/new_roster_dispatch.s'),(R/'src/character_select.s',O/'src/character_select.s','src/character_select.s'),(P/'entrypoint.s',O/'entrypoint.s','entrypoint.s'),(R/'build/dragon_power_gameplay_c_v1.inc',O/'gameplay-c.inc','build/dragon_power_gameplay_c_v1.inc')]:
  patch+=''.join(difflib.unified_diff(original.read_text().splitlines(True),target.read_text().splitlines(True),fromfile='a/'+name,tofile='b/'+name))
 for target in[R/'build/dragon_power_admission_core_v1.inc',R/'build/dragon_power_admission_c_v1.inc']:
  patch+=''.join(difflib.unified_diff([],target.read_text().splitlines(True),fromfile='/dev/null',tofile='b/'+target.relative_to(R).as_posix()))
 (O/'source.patch').write_text(patch)
 ck=receipts['controls-release.json']['checks']
 report=R/'docs/qa/dragon-power-admission-host-2026-10-29.txt'
 report.write_text(f'''PRIVATE SOURCE/CPU FOREGROUND ADMISSION UNIT; NO NATIVE/PLAYABLE/RELEASE APPROVAL.
Exact candidate {sha(rom)}, genuine DBG {sha(O/'candidate.dbg')}, LBL {sha(O/'candidate.lbl')}. Based only on immutable f56a plus separately pinned own movement/mixed-render/gameplay7b96. Other pending Rogue/SMB2/Kamikaze/FF units NOT composed.7b96 immutable and independently bound by reference. Actual new delta {banks}; changedCHR pages{sorted(chrpages)}. All current public entries fixed; original private CmMarioName prefix branch replaced, not kept as a false alias. New NameResume is the genuine original B713 instruction. NrUi internal branches compacted inside original151B; next public entry fixed. CORE6128/endBFF0/spare16. Approved ART85 D100..<D291 cold401B,1647B unused; source preimage in both f56a/7b96 allFF. Old ART pointers/record lengths retained; original files remain unchanged. No RAM/global service flag/new segment/bank4 or unrelated lease consumed. Samus protected flush, both fixed clones and Rogue ADA4..<ADCE remain exact.
HAMMER: actual A0 RunAllH JSR PlayerHammerCollision, then JMP InjurePlayer preserves the real misc caller. Original7b96 incorrectly reads the same ObjectOffset as an enemy index and queues nothing with empty enemy slots. New helper verifies saved original bank0 plus both true RunAllH+2 return bytes at proven stack offsets21/24/25, then valid misc slot0..8/state/collision flag. It queues source projectile10 through DpInjuryStart, retains Star/cheat/protection guards and original reflected hammer speed.576all64flag/native-caller cases pass exact AXYP/SP, no immediate HP debit, precise only Protection/Action/Borrow changes;16wrong-caller/misc-flag counterexamples retain ordinary enemy6 or decline. No broad enemy-slot or arbitrary-PC alias. Actual Hammer/new cold helper IRQ/NMI boundaries are included below; no native physical Hammer scene claim.
MENU/LIVES/LIFECYCLE: private slot23/raw24 is newly reachable from real numeric slot22 Right; other holes/raw25+ remain legacy. Thumbnail derived from authenticated source standing pixels and adapted gray portrait, not invented art. Real DrawSelectionPreview and DisplayIntermediate emit24OAM bytes from the source six-part standing record via genuine DrawMetasprite; dynamic C85 pointer/CHR publication retained. Title portrait always invalidates old marker before Ensure, so a ship overlay cannot masquerade as Goku; lives still use actual life/scene Ensure semantics. Fresh Start clears DpReady and next real Main initializes authenticHP100/no equipment. Explicit Reset is now native-connected; 1-Up preservation and scene policy remain as established in gameplay. No state/outcome seeds in product code. CPU scene/menu setup is a source fixture, not actual native cold boot.
PALETTE adaptation approved: source36/30->36,26->26,04/0F->0F, allparts P0. Five source shades cannot simultaneously fit one3-color sprite palette while preserving every enemy palette1..3. All66body/wave face records preserve every opaque pixel/position/partcount; seven pages retain simultaneous body/wave source pose geometry. Exact original colors are NOT claimed. Native world1..3 retain their original values via genuine A3 palette producers (real bank-qualified calls); only Goku P0 gets36/26/0F. Native BackgroundColorCtrl/AreaType backdrop at3F10 retained; no black-sky shortcut. Actual{ck['real_native_palette_bank_backdrop_and_world_ownership']['cases']}bounded area/control/queue/Star cases pass. Star/powerup-active UI leaves P0 to native effect and keeps pending normal palette until effect ends. Native color/legibility/CHR pixel fidelity still requires ROOT PPU review.
UI: authored compact native-font HPddd Pp Wdd at2023, sourceHP including actual hunger loss, earned Pole bit and actual Waves. It does NOT invent a food meter or credit/refill any resource. Every8source ticks; busy84B packet defers (offset<=68) without advancing a new timer/cache.756all-offset/digit/cap cases, real Main updates and strict packet capacity pass. Full name uses16cells; status name exactly7cells preserves the following WORLD packet. Explicit native font IDs are used, not independent-object ASCII. Native UI/palette costs are measured source code, not deadline certification.
NAME/FOREIGN: strict v1 leaf negative retained: AXYP/output exact but added name routing changes six temporary farcall operand bytes.640complete actual QueueSelection continuations return whole AXYP/SP, all live100..17A including33SMC, application/OAM/banks exact, remaining ordered writes exact. Actual CPU bus first-read ownership proves each of six operands is overwritten before use; no final RAM/flags mask. ISR retains interrupted operands exactly. Other foreign native call returns{ck['foreign_full_native_returns']['cases']}cases pass. Local NrUi table avoids the former unconditional legacy A86 UI trip; table City target remains its real two-call native sequence. Actual whole foreign Main{len(rows)}cases CPUdelta{checks['foreign_complete_Main']['CPU_delta']}; source menu QueueSelection delta{ck['foreign_complete_QueueSelection_after_name']['CPU_delta']}. These are finite source costs, NOT FPS or native cadence claims. No foreign default/adoption justified by source tests alone.
IRQ/CONTINUATIONS: {ck['actual_new_foreground_IRQ_lagNMI']['cases']}actual new owned seams, minSP{ck['actual_new_foreground_IRQ_lagNMI']['min_SP']}; IRQ keeps physical mapping exact. NMI normalization only for literal pending CurrentBankC/5116 store with A==shadow, exactly inherited scoped rule; no mapper repair or broad guard relaxation.64fresh adapted DrawAll->no-draw completeMain->realVine tests preserve every retained body byte. Full unchanged gameplay campaigns freshly reexecuted on this exact hash:1448hunger updates, real contact/source queued drain, Easy native stomp/Hard source contact, two earned matureMush+Flower+chargedWave campaigns,104actor/armor/Bowser boundaries and original127tick corpse->real life decrement. Boundary/setup inputs labeled in receipts, not native earned coverage. Ordinary freshly checked d444/f4ffd exact. Independent real main/component ASM closure and same-ROM link required before handoff.
NEGATIVES/HISTORY: original7b96 Vine/callback/stack negatives remain separate immutable lineage. This draft retains assembler/import/path errors, first A3 palette-owner error (e213 exact triple/source ZIP), native-font ASCII correction discovered before controls, strict name-leaf six-SMC negative, and StatusName ISR A0-trace/A91-replay mismatch (corrected replay A only, no hardware guard change). Provisional4a83 positives/stale pre-table runs are historical and NOT rebound. Only release receipts bind final ROM. No native launches or emulator processes.
OPEN: authentic audio scheduler and atomic foreground/NMI cue mailbox remain UNIMPLEMENTED; native fallback music/SFX is not release fidelity. No native menu/lives/HP/color/render/deadline/traversal approval, no complete stages/items claim. Source DragonPower-specific enemy/drop/reveal policy still pending measured native rates/typed reward provenance; current actual native drop hook declines raw24. No unsupported advanced item powers invented. This is the next bounded functional source admission unit, not final character adoption.
''')
 files=set(Path(f)for f in deps)|{rom,O/'candidate.dbg',O/'candidate.lbl',O/'candidate.map',O/'source.patch',O/'final-controls.json',report,Path(__file__),R/'tools/prepare_dragon_power_admission_v1.py',R/'build/dragon_power_admission_core_v1.inc',R/'build/dragon_power_admission_c_v1.inc',P/'handoff.json',P/'candidate.nes',P/'candidate.dbg',O/'main.c',O/'smb1base-mmc5-expanded.cfg'}
 files.update(O.glob('*.json'));files.update(O.glob('*.zip'));files.update(O.glob('*negative*.log'));files.update(O/n for n in receipts)
 files.update(R.glob('tools/audit/dragon_power_admission_*.py'))
 for d in receipts.values():files.update(Path(p)for p in d['bindings'])
 for mod in list(sys.modules.values()):
  p=getattr(mod,'__file__',None)
  if p and Path(p).resolve().is_relative_to(R)and Path(p).suffix=='.py':files.add(Path(p))
 files.update(R/'tools/audit'/n for n in['dragon_power_gameplay_consumers_v1.py','dragon_power_gameplay_consumers_v4.py','dragon_power_gameplay_render_v1.py','dragon_power_gameplay_render_v3.py'])
 files.add(R/'tools/prepare_cv3_dmc_mirror.py');files.add(R/'tools/build_mmc5_expanded.py')
 for n in['mmc3','mmc5']:files.add(O/('ordinary-'+n+'.nes'))
 hand=dict(status='FROZEN_PRIVATE_SOURCE_CPU_FOREGROUND_ADMISSION_NO_NATIVE_AUDIO_OR_DROP_RELEASE',candidate=bind(rom),DBG=bind(O/'candidate.dbg'),LBL=bind(O/'candidate.lbl'),actual_ASM_dependencies=deps,
  bindings={str(p.resolve()):sha(p)for p in sorted(files)},report=bind(report),owned_tools=[str(p.resolve())for p in files if p.suffix=='.py'and'dragon_power_admission'in p.name],
  source_CPU_receipts=[bind(O/n)for n in receipts]+[bind(O/'final-controls.json')],limits=report.read_text())
 for p,h in hand['bindings'].items():assert sha(p)==h
 (O/'handoff.json').write_text(json.dumps(hand,indent=2)+'\n');print(json.dumps(dict(handoff=bind(O/'handoff.json'),candidate=sha(rom),bindings=len(hand['bindings']),ASM_dependencies=len(deps),checks=checks['foreign_complete_Main']['CPU_delta'])))
if __name__=='__main__':main()
