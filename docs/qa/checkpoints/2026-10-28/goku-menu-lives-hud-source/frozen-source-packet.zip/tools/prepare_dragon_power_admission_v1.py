"""Private f56a+own gameplay successor only; no shared/native writes."""
from pathlib import Path
import argparse,hashlib,json,re,subprocess,sys
R=Path(__file__).resolve().parents[1];P=R/'build/dragon-power-gameplay-v1';O=R/'build/dragon-power-admission-v1'
sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
from sunny_integrated_controls_v1 import scoped_load,address,location
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--size-only',action='store_true');a=ap.parse_args()
 assert sha(P/'handoff.json')=='41a77916d651c7a2166b021c240ab59b703174161847513aa9d4a4e0a89573bf'
 assert not (O/'handoff.json').exists()
 O.mkdir(exist_ok=True);(O/'src').mkdir(exist_ok=True)
 b=scoped_load(P/'candidate.nes');raw=(P/'candidate.nes').read_bytes();ref=(R/'build/celeste-small-chr-v2.nes').read_bytes()
 for v in[raw,ref]:assert v[16+85*8192+0x1100:16+85*8192+0x1900]==bytes([255])*2048
 # Role-only adaptation; original record lengths/addresses and body/wave
 # simultaneous packing contract remain. Source ART/CHR files are read-only.
 inc=(R/'build/dragon-power-mixed-render-v3/dragon_power_art_mixed.inc').read_text()
 oldchr=(R/'build/dragon-power-mixed-render-v3/mixed.chr').read_bytes()
 lines=inc.splitlines();records={};posepages=[]
 for i,line in enumerate(lines):
  if line=='DpPosePage:':posepages=[int(v)for v in lines[i+1].split('.byte')[1].split(',')]
  if re.fullmatch(r'DpArt\d+:',line):records[int(line[5:-1])]=[int(v.strip()[1:],16)for v in lines[i+1].split('.byte')[1].split(',')]
 indices=[int(v)for v in re.findall(r'<DpArt(\d+)',inc.split('DpPoseLo:')[1].split('DpPoseHi:')[0])]
 recordpages={n:posepages[i]for i,n in enumerate(indices)}
 def adapt(pattern,pal):
  out=bytearray(32)
  for y in range(16):
   at=y//8*16+y%8
   for x in range(8):
    v=((pattern[at]>>(7-x))&1)|(((pattern[at+8]>>(7-x))&1)<<1)
    z=([0,1,2,3]if pal==0 else[0,1,1,3])[v]
    out[at]|=(z&1)<<(7-x);out[at+8]|=(z>>1)<<(7-x)
  return bytes(out)
 rows={}
 for n,data in records.items():
  page=recordpages[n];row=[]
  for at in range(1,len(data),4):
   tile,pal,y,x=data[at:at+4];pat=oldchr[page*1024+tile*16:page*1024+tile*16+32]
   row.append((adapt(pat,pal&3),y,x))
  rows[n]=row
 common=sorted({pat for i in[64,65]for pat,y,x in rows[indices[i]]})
 assert len(common)<=4
 while len(common)<4:common.append(bytes(32))
 pages=[];newpages={};newrecords={}
 for n,row in rows.items():
  need=set(p for p,y,x in row)|set(common)
  options=[(len(need-set(p)),i)for i,p in enumerate(pages)if len(need|set(p))<=32]
  if not options:pages.append(list(common));page=len(pages)-1
  else:page=min(options)[1]
  for pat in sorted(need):
   if pat not in pages[page]:pages[page].append(pat)
  newpages[n]=page;data=[]
  for pat,y,x in row:data.extend([pages[page].index(pat)*2,0,y,x])
  newrecords[n]=[len(data)]+data
 assert len(pages)<=8
 adapted=b''.join(b''.join(p)+bytes(1024-len(p)*32)for p in pages);adapted+=bytes(8192-len(adapted));(O/'adapted.chr').write_bytes(adapted)
 for i,line in enumerate(lines):
  if line=='DpPosePage:':lines[i+1]=' .byte '+','.join(str(newpages[n])for n in indices)
  if line=='DpPaletteRoles:':lines[i+1]=' .byte $36,$26,$0f,$36,$26,$0f'
  if re.fullmatch(r'DpArt\d+:',line):lines[i+1]=' .byte '+','.join(f'${v:02x}'for v in newrecords[int(line[5:-1])])
  if line.startswith('.incbin '):lines[i]=f'.incbin "{(O/"adapted.chr").as_posix()}"'
 (O/'art.inc').write_text('\n'.join(lines)+'\n')
 # A real source thumbnail in the one new slot. The original28-cell table
 # layout and all old name/preview identities remain; navigation now admits23.
 from PIL import Image
 ntat=location(b,'SelectNameTable');nt=bytearray(raw[ntat:ntat+1024])
 menuchr=bytearray(raw[1048592+4096:1048592+8192])
 n=indices[0];row=rows[n];px={}
 for pat,y,x in row:
  x=x if x<128 else x-256;y=(y if y<128 else y-256)+1
  for yy in range(16):
   at=yy//8*16+yy%8
   for xx in range(8):
    v=(pat[at]>>(7-xx)&1)|((pat[at+8]>>(7-xx)&1)<<1)
    if v:px[x+xx,y+yy]=v
 loX=min(x for x,y in px);loY=min(y for x,y in px)
 pic=Image.new('L',(max(x for x,y in px)-loX+1,max(y for x,y in px)-loY+1))
 for (x,y),v in px.items():pic.putpixel((x-loX,y-loY),v)
 scale=min(16/pic.width,24/pic.height,1);pic=pic.resize((max(1,round(pic.width*scale)),max(1,round(pic.height*scale))),Image.Resampling.NEAREST)
 thumb=Image.new('L',(16,24));thumb.paste(pic,((16-pic.width)//2,24-pic.height))
 free=[i for i in range(64,252)if i not in nt[:960]];assert len(free)>=6
 for ty in range(3):
  for tx in range(2):
   tile=free[ty*2+tx];data=bytes(sum(((thumb.getpixel((tx*8+x,ty*8+y))>>plane)&1)<<(7-x)for x in range(8))for plane in range(2)for y in range(8))
   menuchr[tile*16:(tile+1)*16]=data;nt[(16+ty)*32+11+tx]=tile
 (O/'menu.chr').write_bytes(menuchr);(O/'menu.bin').write_bytes(nt)
 # Use the actual frozen table values instead of rebuilding unrelated assets.
 table=[];present=list(raw[location(b,'X5MenuPresent'):location(b,'X5MenuPresent')+28]);present[23]=1
 chars=list(raw[location(b,'X5MenuCharacters'):location(b,'X5MenuCharacters')+28]);chars[23]=24
 sys.path.insert(0,str(R/'tools/reference'))
 from build_roster_expansion_menu import navigation
 nav=navigation([i for i,v in enumerate(present)if v])
 for name in['Left','Right','Up','Down','Characters','Present','CursorLo','CursorHi']:
  if name in['Left','Right','Up','Down']:values=[nav[i][name.lower()]if i in nav else 0 for i in range(28)]
  elif name=='Characters':values=chars
  elif name=='Present':values=present
  else:values=list(raw[location(b,'X5Menu'+name):location(b,'X5Menu'+name)+28])
  table+=['X5Menu'+name+':',' .byte '+','.join(map(str,values))]
 (O/'menu.inc').write_text('\n'.join(table)+'\n')
 select=(R/'src/character_select.s').read_text().replace('.incbin "chr/raw/roster-expansion-menu.bin"',f'.incbin "{(O/"menu.bin").as_posix()}"').replace('.include "roster_expansion_menu.inc"','.include "build/dragon-power-admission-v1/menu.inc"')
 (O/'src/character_select.s').write_text(select)
 c=(R/'build/dragon_power_gameplay_c_v1.inc').read_text();assert c.count('.proc DpGameHurt\n lda StarInvincibleTimer')==1
 c=c.replace('.proc DpGameHurt\n lda StarInvincibleTimer','.proc DpGameHurt\n jmp DpAdmissionHammer')
 (O/'gameplay-c.inc').write_text(c)
 comp=(P/'component.s').read_text()
 comp=comp.replace('build/dragon-power-mixed-render-v3/dragon_power_art_mixed.inc','build/dragon-power-admission-v1/art.inc').replace('build/dragon_power_gameplay_c_v1.inc','build/dragon-power-admission-v1/gameplay-c.inc')
 names='RunAllH Misc_State Misc_Collision_Flag JnResetDispatch CmHostFresh VvUiDispatch X5GetPlayerColors JnStatusName NrQueueSelectName StarInvincibleTimer CheatInvincible GuestPowerupActive InvHudActive InvDirty VRAM_Buffer1 VRAM_Buffer1_Offset QueueMegaManFacePalette QueueGuestWeaponPalette X5QueueAreaBackdrop MarioVariant OperMode'.split()
 imports=[]
 for n in names:
  assert n in b['syms'],n
  if not re.search(r'^\.import(?:zp)? '+n+r'$',comp,re.M):imports.append(('.importzp 'if address(b,n)<256 else'.import ')+n)
 imports+=['.import DpAdmissionNameResume']
 comp='\n'.join(imports)+'\n'+comp+'.include "build/dragon_power_admission_core_v1.inc"\n.include "build/dragon_power_admission_c_v1.inc"\n'
 (O/'component.s').write_text(comp)
 gate=(P/'src/new_roster_dispatch.s').read_text()
 gate='.import DpAdmissionPortrait,DpAdmissionReset,DpAdmissionFresh,DpAdmissionUi,DpAdmissionColors,DpAdmissionStatusName,DpAdmissionMenuName\n'+gate
 gate=gate.replace('NrGate NrPortrait,IcPortrait,RcPortrait,SunnyPortrait,JnPortraitDispatch,JnPortraitDispatch','NrGate NrPortrait,IcPortrait,RcPortrait,SunnyPortrait,JnPortraitDispatch,DpAdmissionPortrait')
 # Literal old18B farcall targets only; every public gate PC stays fixed.
 for old,new in [('JnResetDispatch','DpAdmissionReset'),('CmHostFresh','DpAdmissionFresh'),('VvUiDispatch','DpAdmissionUi'),('X5GetPlayerColors','DpAdmissionColors'),('JnStatusName','DpAdmissionStatusName')]:
  marker='farcall '+old+',';assert gate.count(marker)==1,(old,gate.count(marker));gate=gate.replace(marker,'farcall '+new+',')
 begin=gate.index('.proc NrUi\n');end=gate.index('.endproc',begin)+len('.endproc')
 gate=gate[:begin]+'''.proc NrUi
 NrCeleste CmHostUi
 sta SafecallA_SMC+1
 php
 tya
 pha
 lda SelectedCharacter
 sec
 sbc #20
 cmp #5
 bcs Legacy
 tay
 lda TargetLo,y
 sta FarcallJmpTarget_SMC+1
 lda TargetHi,y
 sta FarcallJmpTarget_SMC+2
 lda TargetBank,y
 jmp NrTableColdFinish
Legacy:
 pla
 tay
 plp
 lda #<VvUiDispatch
 sta FarcallJmpTarget_SMC+1
 lda #>VvUiDispatch
 sta FarcallJmpTarget_SMC+2
 lda #.bank(VvUiDispatch)|$80
 jmp FarCallCommon
TargetLo:.byte <X5NativeInventoryUiLeaf,<City,<VvUiDispatch,<SunnyUi,<DpAdmissionUi
TargetHi:.byte >X5NativeInventoryUiLeaf,>City,>VvUiDispatch,>SunnyUi,>DpAdmissionUi
TargetBank:.byte .bank(X5NativeInventoryUiLeaf)|$80,.bank(City)|$80,.bank(VvUiDispatch)|$80,.bank(SunnyUi)|$80,.bank(DpAdmissionUi)|$80
City:
 farcall X5NativeInventoryUiLeaf
 farcall RcUi,jmp
 .res 11,$ff
 .assert *-NrUi=151,lderror,"Original NrUi public span"
.endproc'''+gate[end:]
 prefix='''  lda SelectedCharacter
  bne CmOtherName
  lda MarioVariant
  cmp #4
  bne CmMarioName
  lda #44
  jmp NameIndex
CmMarioName:lda #0
CmOtherName:'''
 assert gate.count(prefix)==1
 gate=gate.replace(prefix,'''  farcall DpAdmissionMenuName,jmp
  nop
CmOtherName:
::DpAdmissionNameResume:''')
 # No alias: old genuine root+scoped entry remains at B713.
 (O/'src/new_roster_dispatch.s').write_text(gate)
 for n in['guest_injury.s','megaman_environment.s','sprite_render.s']:(O/'src'/n).write_bytes((P/'src'/n).read_bytes())
 (O/'smb1base-mmc5-expanded.cfg').write_bytes((P/'smb1base-mmc5-expanded.cfg').read_bytes());(O/'main.c').write_bytes((P/'main.c').read_bytes())
 entry=(P/'entrypoint.s').read_text()+'\n'+''.join('.export '+n+'\n'for n in names)+'.export DpAdmissionNameResume\n'
 chunk='.incbin "chr/characters/packed-mmc5-roster-expanded.chr"'
 assert entry.count(chunk)==1
 entry=entry.replace(chunk,chunk+',0,4096\n'+f'.incbin "{(O/"menu.chr").as_posix()}"\n'+chunk+',8192')
 (O/'entrypoint.s').write_text(entry)
 cc=R/'tools/Windows/cc65/bin';cmd=[str(cc/'ca65.exe'),'--cpu','6502x','-g','-I',str(R),'-I',str(R/'src'),str(O/'component.s'),'-o',str(O/'component.o')]
 z=subprocess.run(cmd,cwd=R,capture_output=True,text=True);(O/'assemble.log').write_text(z.stdout+z.stderr);assert not z.returncode,z.stderr
 z=subprocess.run([str(cc/'od65.exe'),'--dump-segments',str(O/'component.o')],capture_output=True,text=True);(O/'size.txt').write_text(z.stdout);print(z.stdout)
 if a.size_only:return
 prior=json.loads((P/'build-proof.json').read_text())['command'];cmd=[v.replace(str(P),str(O))for v in prior]
 z=subprocess.run(cmd,cwd=R,capture_output=True,text=True);(O/'build.log').write_text(z.stdout+z.stderr);assert not z.returncode,z.stderr
 from prepare_cv3_dmc_mirror import prepare
 prepare(R,O/'candidate.nes')
 proof=dict(passed=True,source_CPU_only=True,native_run=False,parent_sha256=sha(P/'candidate.nes'),candidate_sha256=sha(O/'candidate.nes'),DBG_sha256=sha(O/'candidate.dbg'),LBL_sha256=sha(O/'candidate.lbl'),command=cmd,
  palette_mapping={'36':'36','30':'36','26':'26','04':'0F','0F':'0F'},pages=len(pages),pairs=[len(v)for v in pages],record_lengths_exact=True,
  actual_D100_D900_parent_f56a_and_7b96_FF=True,private_menu_slot=23,private_raw=24,native_run_or_playable_approval=False)
 (O/'build-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
if __name__=='__main__':main()
