"""Execute actual foreign name consumer before comparing call publications.

v1's strict leaf six-SMC-byte negative is retained; no unexplained RAM mask.
"""
from pathlib import Path
R=Path(__file__).resolve().parents[2]
p=R/'tools/audit/dragon_power_admission_controls_v1.py';s=p.read_text()
s=s.replace("['NrReset','NrColors','NrUi','NrStatusName','NrQueueSelectName']","['NrReset','NrColors','NrUi','NrStatusName']")
extra=r'''
  rows=[]
  for ch,f in itertools.product([0,1,2,3,5,15,19,20,21,23],flags):
   pair=[]
   for v in[old,b]:
    q=C.setup(v,ch);q.put(OperMode=0,CrossoverMenuState=2,VRAM_Buffer1_Offset=0,CrossoverMenuIndex=0)
    c,tr,mn=C.M.runtrace(q,'QueueSelection',p=f)
    skip=set(smc_at(v))|{address(v,'CurrentBank')}
    writes=[(i,z)for i,z in q.m.writes if not 0x17b<=i<0x200 and i not in skip and not 0x5114<=i<=0x5117]
    pair.append(((registers(c),C.M.fastapp(q),bytes(q.m[0x100:0x17b]),tuple(q.m.banks)),writes,c.processorCycles,mn))
   assert pair[0][:2]==pair[1][:2],('complete real foreign name consumer',ch,f,pair[0][0][0],pair[1][0][0])
   rows.append([ch,f,pair[1][2]-pair[0][2],pair[1][3]])
  ck['foreign_complete_QueueSelection_after_name']=dict(cases=len(rows),whole_AXYP_SP_live_page1_all33SMC_application_banks_remaining_ordered_writes_exact=True,CPU_delta=[min(x[2]for x in rows),max(x[2]for x in rows)],min_SP=min(x[3]for x in rows),strict_leaf_negative_preserved='controls-v1.json')
  # Inspect actual CPU bus reads after the public name routine returns through
  # its genuine JSR/farcall frame. Every differing operand is overwritten
  # before its first consumer. No register, RAM or final SMC exclusion here.
  provenance=[]
  for ch in[0,23]:
   q=C.setup(b,ch);q.put(OperMode=0,CrossoverMenuState=2,VRAM_Buffer1_Offset=0,CrossoverMenuIndex=0)
   base=q.m;tracked=set(smc_at(b));seen={};writes={};monitor=False;atpc=0
   class Bus:
    def __getitem__(self,a):
     if monitor and isinstance(a,int)and a in tracked and a not in seen:
      assert a in writes,('stale SMC operand actually read',hex(a),hex(atpc))
      seen[a]=[atpc,base.banks[:],writes[a]]
     return base[a]
    def __setitem__(self,a,v):
     if monitor and a in tracked and a not in writes:writes[a]=atpc
     base[a]=v
   start=address(b,'QueueSelection');base.page(1,(location(b,'QueueSelection')-16)//8192);q.set('CurrentBank',base.banks[1]|128)
   c=NesMPU(memory=Bus(),pc=start);c.a,c.x,c.y,c.p,c.sp=0,0,0,0x30,253;c.stPushWord(0x5aff);active=None
   for _ in range(200000):
    if c.pc==0x5b00:break
    physical=base.banks[(c.pc-0x8000)//8192]if c.pc>=0x8000 else -1
    if c.pc==address(b,'NrQueueSelectName')and physical==81:
     active=(base[0x101+c.sp]|base[0x102+c.sp]<<8,c.sp)
    if active and c.pc==active[0]+1 and c.sp==active[1]+2:
     assert c.pc==address(b,'FarcallJmpTarget_SMC')+3
     monitor=True;active=None
    atpc=c.pc;c.step()
   else:raise AssertionError('name consumer provenance timeout')
   assert monitor and set(seen)==tracked
   provenance.append(dict(character=ch,first_actual_reads={hex(k):v for k,v in seen.items()}))
  ck['name_SMC_actual_first_read_ownership']=dict(cases=2,all_six_operands_written_before_read=True,rows=provenance)
'''
s=s.replace("  rows=[]\n  for mode,face in itertools.product([0,1],[1,2]):",extra+"\n  rows=[]\n  for mode,face in itertools.product([0,1],[1,2]):")
s=s.replace("['NrUi','NrColors','NrStatusName','NrPortrait']","['NrUi','NrColors','NrStatusName','NrPortrait','NrQueueSelectName']")
s=s.replace("files=[Path(__file__),", "files=[Path(__file__),R/'tools/audit/dragon_power_admission_controls_v1.py',")
exec(compile(s,str(Path(__file__)),'exec'))
