"""Actual private admission consumers, no emulator or resource grants."""
from pathlib import Path
import argparse,itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import dragon_power_gameplay_controls_v1 as C
import dragon_power_gameplay_isr_v1 as I
from sunny_integrated_controls_v1 import *
O=R/'build/dragon-power-admission-v1';P=C.O
def hammer(q,slot=0):
 q.put(FrameCounter=1,ObjectOffset=slot,Misc_OffscreenBits=0)
 q.set('Misc_State',129,slot);q.set('Misc_Collision_Flag',0,slot);q.set('Misc_X_Speed',1,slot)
 at=address(q.b,'BoundingBox_UL_Corner');q.m[at:at+4]=[96,176,112,208]
 q.m[at+36+slot*4:at+40+slot*4]=[98,180,106,196]
def pixels(b,index):
 raw=b['raw'];page=raw[location(b,'DpPosePage')+index]
 ptr=raw[location(b,'DpPoseLo')+index]|raw[location(b,'DpPoseHi')+index]<<8
 at=16+85*8192+ptr-0xc000;rec=raw[at:at+raw[at]+1];out={}
 for i in range(len(rec)-4,0,-4):
  t,p,y,x=rec[i:i+4];x=x if x<128 else x-256;y=(y if y<128 else y-256)+1
  pat=raw[1048592+(788+page)*1024+t*16:1048592+(788+page)*1024+t*16+32]
  for yy in range(16):
   a=yy//8*16+yy%8
   for xx in range(8):
    v=(pat[a]>>(7-xx)&1)|((pat[a+8]>>(7-xx)&1)<<1)
    if v:out[x+xx,y+yy]=(v,p&3)
 return out,len(rec)-1
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();assert not a.output.exists()
 old,b=[scoped_load(p/'candidate.nes')for p in[P,O]];proof=dict(passed=False,source_CPU_only=True,native_run=False,checks={});ck=proof['checks']
 try:
  # The native caller instruction is unchanged in the actual bound A0 bank.
  off=location(b,'RunAllH');assert b['raw'][off:off+3]==bytes([32,address(b,'PlayerHammerCollision')&255,address(b,'PlayerHammerCollision')>>8])
  assert b['raw'][off:off+3]==old['raw'][location(old,'RunAllH'):location(old,'RunAllH')+3]
  rows=[];flags=[f for f in range(256)if f&0x30==0x30]
  for slot,f in itertools.product(range(9),flags):
   pair=[]
   for v in[old,b]:
    q=C.setup(v);run(q,'DpEnsure');hammer(q,slot)
    c,tr,mn=C.M.runtrace(q,'ProcHammerObj',x=slot,p=f)
    pair.append((q,c,tr,mn))
   before,c0,_,_=pair[0];q,c,tr,mn=pair[1]
   assert before.get('DpProtection')==0 and q.get('DpProtection')==10 and q.get('DpAction')==14
   assert q.get('DpHP')==100 and q.get('Misc_Collision_Flag',slot)==1 and q.get('Misc_X_Speed',slot)==255
   assert registers(c)==registers(c0),('Hammer full native return',slot,f,registers(c),registers(c0))
   delta={i for i in range(0x8000)if before.m[i]!=q.m[i]and not 0x17b<=i<0x200 and i not in smc_at(b)}
   assert delta<={address(b,n)for n in['DpProtection','DpAction','DpBorrow']},('unexpected Hammer writes',delta)
   rows.append([slot,f,c.processorCycles-c0.processorCycles,mn])
  ck['actual_ProcHammerObj_JSR_misc_owner']=dict(cases=len(rows),empty_enemy_slots=True,exact_native_AXYP_SP=True,queued10_not_immediate_HP=True,CPU_delta=[min(r[2]for r in rows),max(r[2]for r in rows)],min_SP=min(r[3]for r in rows))
  rows=[]
  for kind,star,cheat,protected in itertools.product([None,6],[0,1],[0,1],[0,6]):
   q=C.setup(b);run(q,'DpEnsure');hammer(q)
   if kind is not None:C.actor(q,kind=kind)
   q.put(StarInvincibleTimer=star,CheatInvincible=cheat,DpProtection=protected)
   c,tr,mn=C.M.runtrace(q,'NrInjury',x=0)
   expected=protected or (6 if kind is not None and not star and not cheat else 0)
   assert q.get('DpProtection')==expected,('no fake Hammer via unrelated caller',kind,star,cheat,protected,q.get('DpProtection'))
   rows.append([kind,star,cheat,protected])
  ck['wrong_caller_misc_flags_do_not_invent_Hammer']=dict(cases=len(rows),no_broad_misc_or_enemy_fallback=True)
  for i in range(66):
   px,n=pixels(old,i);actual,m=pixels(b,i)
   expected={k:(([0,1,2,3]if p==0 else[0,1,1,3])[v],0)for k,(v,p)in px.items()}
   assert actual==expected and n==m,('source opacity/geometry/class mapping',i)
  ck['all_original_body_wave_pixel_geometry']=dict(records=66,both_faces=True,part_counts_exact=True,only_authored_P0_mapping=True)
  count=0
  for hp,offset in itertools.product([0,9,10,29,30,99,100,149,150],range(84)):
   q=C.setup(b);run(q,'DpEnsure');q.put(DpHP=hp,DpPole=1,DpWaves=3,DpClock=0,DpPaletteAck=0,VRAM_Buffer1_Offset=offset)
   q.m[address(b,'VRAM_Buffer1'):address(b,'VRAM_Buffer1')+84]=bytes([0xa5])*84
   c,tr,mn=C.M.runtrace(q,'NrUi')
   data=bytes(q.m[address(b,'VRAM_Buffer1'):address(b,'VRAM_Buffer1')+84])
   if offset<69:
    expected=bytes([0x20,0x23,12,17,25,hp//100,(hp//10)%10,hp%10,36,25,1,36,32,0,3,0])
    assert data[offset:offset+16]==expected,('HUD exact source digits/packet',hp,offset,data[offset:offset+16].hex())
    assert q.get('VRAM_Buffer1_Offset')==offset+15
   else:assert data==bytes([0xa5])*84 and q.get('VRAM_Buffer1_Offset')==offset
   assert [q.get(n)for n in['DpHP','DpPole','DpWaves']]==[hp,1,3]
   count+=1
  ck['bounded_source_HP_hunger_pole_wave_HUD']=dict(cases=count,all_offsets_0_83=True,no_credits_or_refills=True)
  rows=[]
  for area,bg,offset,star in itertools.product(range(4),range(8),[0,61,62,83],[0,1]):
   q=C.setup(b);run(q,'DpEnsure');q.put(AreaType=area,BackgroundColorCtrl=bg,VRAM_Buffer1_Offset=offset,StarInvincibleTimer=star)
   c,tr,mn=C.M.runtrace(q,'NrColors')
   end=q.get('VRAM_Buffer1_Offset');data=bytes(q.m[address(b,'VRAM_Buffer1')+offset:address(b,'VRAM_Buffer1')+end])
   if offset<62:
    assert end-offset==(16 if star else 22),(area,bg,offset,star,end,data.hex())
    at=0;pack=[]
    while at<len(data):
     hi,lo,n=data[at:at+3];pack.append((hi*256+lo,list(data[at+3:at+3+n])));at+=3+n
    assert [a for a,d in pack]==[0x3f1d,0x3f19,0x3f10]+([]if star else[0x3f11])
    expectedbg=[0x22,0x22,15,15,15,0x22,15,15][bg or area]
    assert pack[2]==(0x3f10,[expectedbg])
    if not star:assert pack[-1]==(0x3f11,[0x36,0x26,15])
    assert (3,address(b,'QueueMegaManFacePalette'))in tr and(3,address(b,'QueueGuestWeaponPalette'))in tr
   else:assert end==offset
   rows.append([area,bg,offset,star,c.processorCycles,mn])
  ck['real_native_palette_bank_backdrop_and_world_ownership']=dict(cases=len(rows),all_area_BG_controls=True,native_1_2_3_not_recolored=True,only_Goku_P0_changed=True,CPU=[min(z[-2]for z in rows),max(z[-2]for z in rows)])
  # Full genuine menu/lives and real cold numeric selection, not direct state
  # selection. Typed boundary initial menu state is explicit CPU-only setup.
  rows=[]
  for name,mode in itertools.product(['DrawSelectionPreview','DisplayIntermediate'],[0,1]):
   q=C.setup(b);q.put(OperMode=0 if name=='DrawSelectionPreview' else 1,CrossoverMenuState=2,CrossoverMenuIndex=23,DisableIntermediate=0,AltEntranceControl=0,CrossoverBehaviorVersion=mode,DpReady=0x44,DpHP=1)
   c,tr,mn=C.M.runtrace(q,name)
   assert q.get('ObjectMetasprite')==233 and q.get('CurrentOAMOffset')==24 and q.m.banks[2]==85
   if name=='DrawSelectionPreview':assert q.get('DpHP')==100
   assert (86,address(b,'DpAdmissionPortrait'))in tr and (4,address(b,'MetaspriteRenderLoop'))in tr
   rows.append([name,mode,c.processorCycles,mn])
  q=C.setup(b,23);q.put(OperMode=0,CrossoverMenuState=2,CrossoverMenuIndex=22,SavedJoypad1Bits=1,CrossoverMenuButtons=0)
  c,tr,mn=C.M.runtrace(q,'CrossoverMenuInput');assert q.get('CrossoverMenuIndex')==23 and q.get('SelectedCharacter')==24
  assert (86,address(b,'DpAdmissionMenuName'))in tr
  # The following fresh-Start path invalidates old source marker legitimately.
  q.put(SavedJoypad1Bits=16,CrossoverMenuButtons=0,DpReady=0x44)
  c,tr,mn=C.M.runtrace(q,'CrossoverMenuInput');assert q.get('DpReady')==0 and q.get('CrossoverMenuState')==0
  ck['real_menu_lives_and_fresh_Start_consumers']=dict(rows=rows,actual_right22_to_slot23_raw24=True,fresh_Start_invalidates_old_overlay=True)
  count=0;costs=[]
  for name,ch,f in itertools.product(['NrReset','NrColors','NrUi','NrStatusName','NrQueueSelectName'],[0,1,2,3,5,15,19,20,21,22,23,25,26,27,28],[0x30,0x31,0x70,0xf3]):
   pair=[]
   for v in[old,b]:
    q=C.setup(v,ch);q.put(VRAM_Buffer1_Offset=0);c,tr,mn=C.M.runtrace(q,name,a=0,x=177,y=91,p=f)
    skip=set(smc_at(v))|{address(v,'CurrentBank')}
    writes=[(i,z)for i,z in q.m.writes if not 0x17b<=i<0x200 and i not in skip and not 0x5114<=i<=0x5117]
    pair.append(((registers(c),C.M.fastapp(q),bytes(q.m[0x100:0x17b]),tuple(q.m.banks)),writes,c.processorCycles))
   assert pair[0][:2]==pair[1][:2],('foreign whole native return',name,ch,f,pair[0][0][0],pair[1][0][0])
   costs.append(pair[1][2]-pair[0][2]);count+=1
  ck['foreign_full_native_returns']=dict(cases=count,whole_AXYP_SP_application_live_page1_banks_and_remaining_ordered_writes_exact=True,CPU_delta=[min(costs),max(costs)])
  rows=[]
  for mode,face in itertools.product([0,1],[1,2]):
   q=C.setup(b);q.put(CrossoverBehaviorVersion=mode,PlayerFacingDir=face)
   for age in range(16):
    q.put(SavedJoypadBits=1 if face==1 else 2,NmiDisable=255,VRAM_Buffer1_Offset=0)
    c,tr,mn=C.M.runtrace(q,'GameLoop')
    assert q.get('DpHP')==100 and q.get('DpClock')==age+1
    assert q.get('CurrentBank')&127==q.m.banks[1]and q.get('CurrentBankC')&127==q.m.banks[2]
   rows.append([mode,face,c.processorCycles,mn])
  ck['owned_real_Main_with_UI']=dict(updates=64,rows=rows)
  # New cold service and actual entry/return hardware boundaries, retaining
  # the exact already-qualified literal C-shadow window rule for NMI only.
  count=0;minimum=255
  for name in['NrUi','NrColors','NrStatusName','NrPortrait']:
   q=C.setup(b);run(q,'DpEnsure');c,tr,mn=C.M.runtrace(q,name)
   points=sorted(set((bank,pc)for bank,pc in tr if bank==86 and address(b,'DpAdmissionStart')<=pc<0xc000 or bank==85 and address(b,'DpAdmissionColdStart')<=pc<address(b,'DpAdmissionColdEnd')))
   for kind,point in itertools.product(['IRQ','NMI'],points):
    q=C.setup(b);run(q,'DpEnsure');c,_,mn,_,hit=I.interrupt_actual(q,name,flags=0x30,inject=point,kind=kind);assert hit
    minimum=min(minimum,mn);count+=1
  ck['actual_new_foreground_IRQ_lagNMI']=dict(cases=count,min_SP=minimum,exact_physical_IRQ=True,literal_NMI_C_shadow_windows=I.SHADOW_WINDOWS)
  proof['passed']=True
 except Exception as e:proof.update(failure=repr(e),traceback=traceback.format_exc())
 files=[Path(__file__),Path(C.__file__),Path(I.__file__),O/'candidate.nes',O/'candidate.dbg',O/'candidate.lbl',P/'handoff.json',P/'candidate.nes',P/'candidate.dbg',R/'build/dragon_power_admission_core_v1.inc',R/'build/dragon_power_admission_c_v1.inc',R/'tools/prepare_dragon_power_admission_v1.py']
 proof['bindings']={str(p.resolve()):sha(p)for p in files};a.output.write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(dict(passed=proof['passed'],failure=proof.get('failure'),checks=list(ck))));assert proof['passed']
if __name__=='__main__':main()
