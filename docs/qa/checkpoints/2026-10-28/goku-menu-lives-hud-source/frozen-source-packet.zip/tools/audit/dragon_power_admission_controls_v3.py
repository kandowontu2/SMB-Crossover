"""Match actual entry A in ISR replay; include retained Vine and Hammer seams.

v2's unreached StatusName ISR point was an A0-trace/A91-replay fixture error.
The original strict negative and all hardware assertions remain unchanged.
"""
from pathlib import Path
R=Path(__file__).resolve().parents[2]
p=R/'tools/audit/dragon_power_admission_controls_v2.py';script=p.read_text()
extra=r'''
import dragon_power_gameplay_render_v3 as D
  retained=[]
  for pivot in range(0,256,4):
   q=C.setup(b);run(q,'DpEnsure');q.put(DpPose=6,Player_Y_Position=100,Player_Rel_YPos=100,RgOamFirst=pivot,RgOamUsed=252,FrameCounter=0)
   run(q,'DpGraphics');_,events,mn,_=D.draw(q)
   own=[e for e in events if e['C']==85 and 0xc900<=e['ptr']<=0xcdee]
   slots=sorted(set((e['before']+i+e['rotation'])&255 for e in own for i in range(e['header'])))
   before=bytes(q.m[0x200:0x300]);C.actor(q,5,0x2f,128,80)
   q.put(Vine_FlagOffset=1,Vine_Height=96,ShouldSkipDrawSprites=1,FramesSinceLastSpriteDraw=0,ObjectOffset=5);q.set('Vine_ObjOffset',5,0)
   c,tr,mn=C.M.runtrace(q,'GameLoop')
   assert any(pc==address(b,'VineObjectHandler')for bank,pc in tr)and(4,address(b,'DrawAllMetasprites'))not in tr
   assert all(before[i]==q.m[0x200+i]for i in slots),('new adapted-body partial overlap',pivot)
   retained.append([pivot,len(slots),c.processorCycles,mn])
  ck['fresh_adapted_retained_Vine_complete_Main']=dict(cases=len(retained),zero_body_bytes_overwritten=True,rows=retained)
'''.replace('\nimport dragon_power_gameplay_render_v3 as D','\n  import dragon_power_gameplay_render_v3 as D')
insertion="""
s=s.replace('inject=point,kind=kind)', 'inject=point,kind=kind,a=0)')
s=s.replace("['NrUi','NrColors','NrStatusName','NrPortrait','NrQueueSelectName']", "['NrUi','NrColors','NrStatusName','NrPortrait','NrQueueSelectName','ProcHammerObj']")
s=s.replace("q=C.setup(b);run(q,'DpEnsure');c,tr,mn=C.M.runtrace(q,name)", "q=C.setup(b);run(q,'DpEnsure');hammer(q) if name=='ProcHammerObj' else None;c,tr,mn=C.M.runtrace(q,name)")
s=s.replace("q=C.setup(b);run(q,'DpEnsure');c,_,mn,_,hit=I.interrupt_actual", "q=C.setup(b);run(q,'DpEnsure');hammer(q) if name=='ProcHammerObj' else None;c,_,mn,_,hit=I.interrupt_actual")
s=s.replace("address(b,'DpAdmissionColdStart')<=pc", "address(b,'DpAdmissionHammer')<=pc")
s=s.replace('  # New cold service', EXTRA+'  # New cold service')
s=s.replace("files=[Path(__file__),", "files=[Path(__file__),R/'tools/audit/dragon_power_admission_controls_v2.py',R/'tools/audit/dragon_power_gameplay_render_v3.py',")
"""
script=script.replace("exec(compile(s,str(Path(__file__)),'exec'))",insertion+"\nexec(compile(s,str(Path(__file__)),'exec'))")
EXTRA=extra
exec(compile(script,str(Path(__file__)),'exec'))
