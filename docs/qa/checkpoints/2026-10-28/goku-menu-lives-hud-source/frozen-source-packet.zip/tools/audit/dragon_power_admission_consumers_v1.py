"""Fresh exact admission-ROM execution of the unchanged gameplay campaigns."""
from pathlib import Path
import sys
R=Path(__file__).resolve().parents[2]
sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import dragon_power_gameplay_controls_v1 as C
C.O=R/'build/dragon-power-admission-v1'  # local CPU fixture metadata only
p=R/'tools/audit/dragon_power_gameplay_consumers_v4.py'
exec(compile(p.read_text(),str(Path(__file__)),'exec'))
