"""Freeze the one private Goku gameplay component; no native/shared writes."""
from pathlib import Path
import configparser, difflib, hashlib, json, re, subprocess, sys
R=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import dragon_power_gameplay_controls_v1 as C
from sunny_integrated_controls_v1 import *
O=C.O; P=C.P
def binding(p):
 p=Path(p).resolve();return dict(path=str(p),bytes=p.stat().st_size,sha256=sha(p))
def main():
 assert not (O/'handoff.json').exists(),'already frozen'
 rom=O/'candidate.nes'; b=scoped_load(rom); old=scoped_load(P/'candidate.nes')
 assert sha(rom)=='7b96cced68bce9a0cf0f7a61ab9f122222eb16167efc7647d5dac1c22a264f78'
 assert sha(P/'handoff.json')=='eadd1eef7433c2db9575954b564b2d5cbfed3a48a34ff540089b708f5ff525ba'
 names=['controls-release.json','consumers-release.json','render-release.json','vine-release.json','partial-release.json','abi-v1.json']
 receipts={n:json.loads((O/n).read_text())for n in names}
 for n,d in receipts.items():
  assert d['passed'],n
  assert d['bindings'][str(rom.resolve())]==sha(rom),(n,'candidate')
  for f,h in d['bindings'].items():assert sha(f)==h,(n,f,'binding changed')
 checks={}; raw=rom.read_bytes(); ref=(P/'candidate.nes').read_bytes()
 ds={i:sum(x!=y for x,y in zip(ref[16+i*8192:16+(i+1)*8192],raw[16+i*8192:16+(i+1)*8192]))for i in range(128)}
 ds={k:v for k,v in ds.items()if v}
 assert ds=={0:3,85:561,86:784,124:33,125:2,127:2},ds
 assert raw[:16]==ref[:16]and raw[1048592:]==ref[1048592:]
 assert raw[16+85*8192+0x900:16+85*8192+0xdef]==ref[16+85*8192+0x900:16+85*8192+0xdef]
 assert ref[16+85*8192+0xdf0:16+85*8192+0x1100]==bytes([255])*784
 assert raw[16+85*8192+0x1023:16+85*8192+0x1100]==bytes([255])*221
 assert raw[16+86*8192+0x1ebf:16+87*8192]==bytes([255])*321
 for bank in[125,127]:
  at=16+bank*8192+0x58
  assert raw[at:at+14]==ref[at:at+14]==bytes.fromhex('900ba9e08500a90785014c828060')
 assert address(b,'FIXED')==0xe066
 assert raw[16+124*8192+0xda4:16+124*8192+0xdce]==bytes([255])*42
 checks['layout']=dict(diff_vs_accepted_movement=ds,total_changed_bytes=sum(ds.values()),
  CORE86='A800..<BEBF,5823B;321B remaining',new_CORE86='BBB6..<BEBF,777B',
  cold_code_C85='CDF0..<D023,563B;221B remaining in approved carve',
  approved_C85_CDF0_D100_actual_parent_all_FF=True,original_1263B_ART_and_8192B_CHR_byteexact=True,
  header_all_other_banks_CHR_exact=True,bank4_untouched=True,Samus_E058_E066_exact=True,
  FIXED_E066_exact=True,Rogue_future_ADA4_ADCE_FF=True,no_new_RAM_segment_or_global_service_flag=True)
 # Genuine scoped symbols/root labels, excluding duplicate DBG convenience aliases.
 scopes={};symrows=[]
 for line in (P/'candidate.dbg').read_text().splitlines():
  if line.startswith(('scope\t','sym\t')):
   d=dict(re.findall(r'(\w+)=("[^"]*"|[^,\r\n]+)',line.split('\t',1)[1]))
   if line.startswith('scope\t'):scopes[d['id']]=d
   elif 'val'in d:symrows.append(d)
 def scope_name(i):
  d=scopes.get(i,{})
  return '::'.join(z for z in[scope_name(d.get('parent'))if'parent'in d else'',d.get('name','').strip('"')]if z)
 roots={d['name'].strip('"')for d in symrows if not scope_name(d.get('scope'))};verified=[];aliases=[]
 for n in old['syms']:
  if n=='_FARCALL_COUNT'or n.startswith(('@','__')):continue
  if '::'not in n and n not in roots:
   if n in b['syms']and address(old,n)!=address(b,n):aliases.append(n)
   continue
  assert n in b['syms']and address(old,n)==address(b,n),('old genuine symbol',n)
  verified.append(n)
 checks['symbols']=dict(genuine_old_symbols_fixed=len(verified),ambiguous_unqualified_DBG_aliases=aliases,no_fake_aliases=True)
 # Typed terrain only. Actual Main must perform bump, native spawn, complete
 # emergence, and physical collision/grant. FrameCounter is explicit CPU
 # clock input, not a claim of running a PPU/NMI or native replay.
 rows=[]
 for mode in[0,1]:
  q=C.setup(b);q.put(CrossoverBehaviorVersion=mode)
  q.m[address(b,'Block_Buffer_1')+0x70+6]=0xc1
  birth=mature=pickup=None;seen=set();minimum=255
  for age in range(180):
   keys=(128 if 1<=age<20 else 0)|(1 if age>=100 else 0)
   q.put(SavedJoypadBits=keys,NmiDisable=255,VRAM_Buffer1_Offset=0,FrameCounter=age&255)
   c,tr,mn=C.M.runtrace(q,'GameLoop');seen.update(tr);minimum=min(minimum,mn)
   if q.get('Enemy_ID',5)==0x2e and q.get('Enemy_Flag',5):
    if birth is None:birth=age
    if q.get('Enemy_State',5)&128 and mature is None:mature=age
    if not q.get('Enemy_State',5)&128:assert q.get('DpPole')==0 and q.get('DpPower')==0,'bump/emergence grant'
   if q.get('DpPole'):
    pickup=age
    assert q.get('DpPower')==1 and q.get('Enemy_Flag',5)==0 and q.get('FloateyNum_Control',5)==6
    assert q.get('DpHP')==100-(age+1)//60+20
    break
  for n in['PlayerHeadCollision','SetupPowerUp','PowerUpObjHandler','HandlePowerUpCollision','EraseEnemyObject']:
   assert (int((location(b,n)-16)//8192),address(b,n))in seen,('actual consumer missing',n)
  assert birth is not None and birth<mature<pickup<180,(birth,mature,pickup)
  rows.append(dict(mode=mode,birth=birth,mature=mature,physical_pickup=pickup,HP=q.get('DpHP'),min_SP=minimum))
 checks['real_block_birth_emergence_then_collection']=dict(campaigns=2,rows=rows,only_typed_map_and_controller_inputs=True,
  no_resource_equipment_item_outcome_seeds=True,no_bump_or_early_emergence_grant=True,
  explicit_CPU_FrameCounter_input_not_PPU_or_native=True)
 # Real native drop hook declines the unsupported raw24 profile. This proves
 # refusal, not authored DragonPower food/drop behavior.
 rows=[]
 for rand in[0,1,2,3]:
  q=C.setup(b);run(q,'DpEnsure');C.actor(q,0,6)
  q.set('PseudoRandomBitReg',rand,1)
  before=bytes(q.m[address(b,'InvDropKind'):address(b,'InvDropKind')+4])
  c,tr,mn=C.M.runtrace(q,'InventoryDropHook',x=0)
  assert bytes(q.m[address(b,'InvDropKind'):address(b,'InvDropKind')+4])==before
  rows.append([rand,c.processorCycles,mn])
 checks['actual_native_drop_hook_no_raw24_reward']=dict(cases=4,rows=rows,explicit_unimplemented_DP_drop_policy=True)
 # Net complete-Main cost vs accepted hidden-body movement component. These
 # are labeled source boundary samples with changed gameplay work, not speed
 # estimates, additive totals, matched displayed workloads or FPS.
 costs=[]
 for mode,keys in[(0,0),(1,0),(0,1),(1,129),(0,64),(1,192)]:
  pair=[]
  for v in[old,b]:
   q=C.setup(v);q.put(CrossoverBehaviorVersion=mode,SavedJoypadBits=keys)
   c,tr,mn=C.M.runtrace(q,'GameLoop');pair.append([c.processorCycles,mn])
  costs.append(dict(mode=mode,keys=keys,movement_parent=pair[0][0],gameplay=pair[1][0],delta=pair[1][0]-pair[0][0],min_SP=pair[1][1]))
 checks['complete_Main_source_boundary_cost']=dict(rows=costs,delta=[min(z['delta']for z in costs),max(z['delta']for z in costs)],
  changed_gameplay_work_not_lag_or_FPS=True)
 # Actual main and component dependency closure and independent same-ROM
 # relink from fresh objects. No source clone or replacement of frozen input.
 conf=configparser.ConfigParser();conf.optionxform=str;conf.read(R/'build_options.ini')
 defs={k:v for sec in conf.values()for k,v in sec.items()};defs.update(MAPPER_MMC3='0',MAPPER_MMC5='1',ENABLE_CROSSOVER='1',ENABLE_MMC5_EXPANDED='1')
 cc=R/'tools/Windows/cc65/bin';deps={};commands=[]
 for name,source in[('main',O/'entrypoint.s'),('component',O/'component.s')]:
  dep=O/(name+'-final.d');obj=O/(name+'-final.o')
  cmd=[str(cc/'ca65.exe'),'--cpu','6502x','-g','-I',str(O/'src'),'-I',str(R/'src'),'-I',str(R),'--bin-include-dir',str(R),'--create-full-dep',str(dep),'-o',str(obj)]
  for k,v in defs.items():cmd+=['-D',k+'='+v]
  cmd+=[str(source)];z=subprocess.run(cmd,cwd=R,capture_output=True,text=True);assert z.returncode==0,z.stderr;commands.append(cmd)
  for word in re.split(r'(?<!\\)\s+',dep.read_text().split(':\t',1)[1].strip().removesuffix(':')):
   f=Path(word.replace('\\ ',' '));f=(f if f.is_absolute()else R/f).resolve();assert f.is_file();deps[str(f)]=sha(f)
 cmd=[str(cc/'cl65.exe'),'--cpu','6502x','-t','nes','-g','-Oisr','-c','--include-dir',str(R),'-o',str(O/'c-final.o')]
 for k,v in defs.items():cmd+=['-D',k+'='+v]
 cmd+=[str(O/'main.c')];z=subprocess.run(cmd,cwd=R,capture_output=True,text=True);assert z.returncode==0,z.stderr;commands.append(cmd)
 out=O/'independent.nes';cmd=[str(cc/'cl65.exe'),'--cpu','6502x','-t','nes','-C',str(O/'smb1base-mmc5-expanded.cfg'),'-Ln',str(out.with_suffix('.lbl')),'--ld-args','--dbgfile,'+str(out.with_suffix('.dbg')),'-o',str(out),str(O/'c-final.o'),str(O/'main-final.o'),str(O/'component-final.o')]
 z=subprocess.run(cmd,cwd=R,capture_output=True,text=True);assert z.returncode==0,z.stderr;commands.append(cmd)
 from prepare_cv3_dmc_mirror import prepare
 prepare(R,out);assert sha(out)==sha(rom),'actual full-source independent relink differs'
 checks['genuine_ASM_closure']=dict(dependencies=len(deps),commands=commands,independent_relink_ROM_exact=True,
  all_E_clones_must_regenerate_from_same_final127=True)
 for mapper,h in[('mmc3','d444cac88e13fa02b29ad16100b8f08fa565ba90f8cedde192de43fb2dc8f3eb'),('mmc5','f4ffd2483c51daa4d60bb575da2da8c4d817692cda407611c243031f67520833')]:
  assert sha(O/('ordinary-'+mapper+'.nes'))==h
 checks['fresh_flagoff']=dict(mmc3=sha(O/'ordinary-mmc3.nes'),mmc5=sha(O/'ordinary-mmc5.nes'))
 (O/'final-controls.json').write_text(json.dumps(dict(passed=True,source_CPU_only=True,native_run=False,candidate_sha256=sha(rom),checks=checks),indent=2)+'\n')
 pairs=[(P/'src/new_roster_dispatch.s',O/'src/new_roster_dispatch.s','src/new_roster_dispatch.s'),(R/'src/megaman_environment.s',O/'src/megaman_environment.s','src/megaman_environment.s'),(R/'src/sprite_render.s',O/'src/sprite_render.s','src/sprite_render.s'),(R/'build/dragon_power_movement_host_v1.inc',O/'movement-host.inc','build/dragon_power_movement_host_v1.inc')]
 patch=''.join(''.join(difflib.unified_diff(a.read_text().splitlines(True),z.read_text().splitlines(True),fromfile='a/'+name,tofile='b/'+name))for a,z,name in pairs)
 for f in[R/'build/dragon_power_gameplay_core_v1.inc',R/'build/dragon_power_gameplay_c_v1.inc']:
  patch+=''.join(difflib.unified_diff([],f.read_text().splitlines(True),fromfile='/dev/null',tofile='b/'+f.relative_to(R).as_posix()))
 (O/'source.patch').write_text(patch)
 summary=R/'docs/qa/dragon-power-gameplay-host-2026-10-28.txt'
 summary.write_text(f'''PRIVATE SOURCE/CPU GAMEPLAY COMPONENT; HELD FOR OPEN ADMISSION WORK. NO NATIVE/PLAYABLE/RELEASE APPROVAL.
Candidate {sha(rom)}. Accepted movement parent {sha(P/'candidate.nes')}. DBG {sha(O/'candidate.dbg')}; LBL {sha(O/'candidate.lbl')}.
Actual source rebuilt independently through ca65 main/component dependencies and real imports. No shared/canonical/menu/Downloads/settings/Git writes. Old genuine public PCs/RAM fixed; no fake aliases. Diff vs movement: {ds}, {sum(ds.values())} bytes. CORE86 A800..<BEBF 5823B (321B spare), appended gameplay777B; approved C85 CDF0..<D023 cold563B (221B spare). Original ART1263B/CHR8192B byteexact, only bodywindow0; no bank4 allocation, new segment/RAM/stateflag. Samus E058..E065 exact, FIXED E066 and Rogue future ADA4..<ADCE protected. Foreign paths retain original targets; future Rogue union must chain RdLifeGameRoutines/RdLifeCheatRoutines and remeasure costs, regenerate every E clone from final127.
Policy: original DragonPower coldHP100/cap150, low-health threshold30. Original source health/hunger timers retained; authored SMB scene mapping outdoor1 / indoor-water3 is NOT one HP per host frame. Incoming contact queues6, native projectile10, boss/firebar/hazard30 through original eight-update damage drain. Unknown hazards explicitly excluded; misc Hammer uses a different native ObjectOffset owner and remains UNQUALIFIED (potential wrong/missing budget), not a safe/no-damage claim. Enemy target HP uses explicit existing HealthTable202 ceil(HP/25); accepted source strike1, cooldown32 and exact original asymmetric point predicates. Pole pose16/wave required for Buzzy/Bills. Native Bowser five-hit owner retained, primary/rear canonicalized. Constructor/erase-clear lifetime receipts distinguish reused slots. No generic unknown-target HP default. Easy native stomp vs Hard source contact and actual source bounce are separate.
Actual mature mushroom grants pole/food20/cap150; flower grants three wave charges/tier2 via original DpPickup. Six contacted X slots preserve provenance despite stale ObjectOffset. Full Main block C1 bump->native spawn->original emergence->physical pickup freshly passes Easy/Hard; no bump/emergence grant, resource/ownership/outcome seed. FrameCounter explicitly fed as CPU clock input, no PPU/native claim. Two mature mushroom+flower campaigns earn a real charged wave at update54. Star/1-Up delegate native once; dedicated current-unit native Star/life conservation is NOT established. Real native drop hook declines raw24; DragonPower-specific food/drop policy remains unimplemented. Right-facing moving enemy scene gets one real hit but not a full defeat; left-facing scene reaches native defeat. Do not describe both as earned kills.
Full Main source corpse takes127updates then actual PlayerLoseLife changes lives once. Death boundaryHP0 and real KillPlayer inputs are labeled, not an earned hazard campaign. Pause/controller/source clock and late native carry/camera ownership inherited from accepted movement. Non8/11 transition contexts still delegate actual native GameRoutines; no comprehensive pipe/flag/climb/death-menu campaign.
Rendering: NrDraw pre-body emits actual wave and body once, clears ObjectMetasprite and installs zero-length following reservation. Subsequent real Main reconstructs it. Max original body48+wave8=56B within real Main reservation64. Actual DrawAll256cases, clipping/capacity108, crowded real firebar/score6; these are source controls, not opaque pixel/native scanline fairness. Retained no-draw Vine originally overwrote body at12/64 pivots (partial-v2 real negative). Corrected raw24-only native six-part writer applies existing permutation per sprite, preserves logical cursor/AXYP/R0/R2/scratch;64/64 retained DrawAll->no-draw Main->Vine now preserve body.3840 native geometry/flags cases; invalid cursor213 rejects explicitly, capacity boundary232 wraps then later group0 rejects. Foreign full Vine896 allflags cases exact with +96CPU. No full-buffer copy or new NMI bookkeeping. Native draw order/OAM starvation/fairness remains untested.
Bank ownership: C85 lease restores previous physical/shadowC and whole AXYP/SP in4608 all-six-flags cases; foreign public8callers14336cases exact application/live100..17A/all33SMC/finalbanks, remaining orderedwrites exact. Added nested mapper/SMC call publications intentional, never claimed ordered5SMC identical.436 actual IRQ/lagNMI boundary cases keep IRQ physicalC exact. NMI may finish ONLY literal pending STA CurrentBankC / STA5116 window with A==shadow; strict old physical-window negative retained; no mapper repair/general mask. Cold service measured181..660CPU; own Vine adds497..502; minimum tested SP190 overall. Ordinary fresh d444/f4ffd exact. No native deadline/FPS/cadence claim.
Foreign full Main72 cases empty-actor contexts CPUdelta0. Foreign public added call costs0..96 and foreign real Vine+96; do not claim zero cost when partial native paths are active. Owned complete-Main boundary delta vs hidden-body movement parent {checks['complete_Main_source_boundary_cost']['delta']}CPU includes newly enabled gameplay/render work;512 sequential Main samples19664..27265CPU. These are source benchmarks, not net lag improvements or safe universal frame budgets.
OPEN: no raw24 menu/lives/portrait/UI/palette/audio scheduler admission, no public playable profile. Atomic foreground-to-NMI DpCueCount/DpCues publication still required; NMI must never read partially written cues. Full body/world palette queue and actual scene backdrops not yet owned. Original DragonPower drop rates/rewards and excluded hazard/hammer ownership need explicit adapters. Complete native emergence/pickups/combat/death/audio/graphics and all stages remain unrun. This component can be reviewed/continued, not adopted as a complete character.
Negatives preserved: initial assembler size/branch assumptions; wrong actual-X stack index; macro-PHX clobbering item A; stale pre-C saved-X index; premature charge fresh-A oracle; callback return-SP oracle; zero-firebar fixture; bank-only-PC draw detection; real retained-Vine overlap; NMI shadow-store timing oracle. Compact prior candidate ZIPs retain exact old triples/receipts; historical positives are not retagged to finalhash. Release proofs alone bind final candidate. No native attempt/owned emulator process.
''')
 files={Path(f)for f in deps}|{rom,O/'candidate.dbg',O/'candidate.lbl',O/'candidate.map',O/'build-proof.json',O/'candidate.cv3-mirror.json',O/'source.patch',O/'final-controls.json',O/'smb1base-mmc5-expanded.cfg',O/'main.c',summary,Path(__file__),R/'tools/prepare_dragon_power_gameplay_v1.py',R/'build/dragon_power_gameplay_core_v1.inc',R/'build/dragon_power_gameplay_c_v1.inc',P/'handoff.json',P/'candidate.nes',P/'candidate.dbg',P/'candidate.lbl',R/'build/nr_router_compact_handoff_v1.json',R/'build/dragon-power-mixed-render-v3/handoff.json',R/'build/dragon-power-component-v1/handoff.json',R/'build/dragon-power-audio-v1/handoff.json',R/'tools/prepare_cv3_dmc_mirror.py',R/'tools/build_mmc5_expanded.py'}
 files.update(O/n for n in names)
 files.update(O.glob('*.json'));files.update(O.glob('*negative*.zip'));files.update(O.glob('*negative*.log'))
 files.update(R.glob('tools/audit/dragon_power_gameplay_*.py'))
 # Include all loaded local helper modules as well as wrapper/base sources.
 for mod in list(sys.modules.values()):
  f=getattr(mod,'__file__',None)
  if f and Path(f).resolve().is_relative_to(R)and Path(f).suffix=='.py':files.add(Path(f))
 for d in receipts.values():files.update(Path(f)for f in d['bindings'])
 for mapper in['mmc3','mmc5']:files.add(O/('ordinary-'+mapper+'.nes'))
 hand=dict(status='FROZEN_PRIVATE_SOURCE_CPU_GAMEPLAY_COMPONENT_HELD_OPEN_ADMISSION_NO_NATIVE',candidate=binding(rom),DBG=binding(O/'candidate.dbg'),LBL=binding(O/'candidate.lbl'),
  actual_ASM_dependencies=deps,source_CPU_receipts=[binding(O/n)for n in names]+[binding(O/'final-controls.json')],
  bindings={str(f.resolve()):sha(f)for f in sorted(files)},owned_tools=[str(f.resolve())for f in files if f.name.startswith(('dragon_power_gameplay_','prepare_dragon_power_gameplay_'))and f.suffix=='.py'],
  report=binding(summary),limits=summary.read_text())
 for f,h in hand['bindings'].items():assert sha(f)==h
 (O/'handoff.json').write_text(json.dumps(hand,indent=2)+'\n')
 print(json.dumps(dict(handoff=binding(O/'handoff.json'),candidate=sha(rom),bindings=len(hand['bindings']),actual_ASM_dependencies=len(deps),checks=list(checks))))
if __name__=='__main__':main()
