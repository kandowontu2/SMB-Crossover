"""Actual C85 callback metadata and A86 lease; retain historical controls."""
from pathlib import Path
R=Path(__file__).resolve().parents[2]
p=R/'tools/audit/dragon_power_gameplay_consumers_v1.py';s=p.read_text()
s=s.replace("if age==48:keys|=128","if q.get('DpAction')==8 and q.get('DpTimer')==0 and born is None:keys|=128")
s=s.replace("c,tr,mn=C.M.runtrace(q,'DpGameCombat');", "q.m.page(1,86);q.set('CurrentBank',214);c,tr,mn=C.M.runtrace(q,'DpGameCombat');")
s=s.replace("(86,address(b,'DpGameHurt'))in tr", "((location(b,'DpGameHurt')-16)//8192,address(b,'DpGameHurt'))in tr")
exec(compile(s,str(Path(__file__)),'exec'))
