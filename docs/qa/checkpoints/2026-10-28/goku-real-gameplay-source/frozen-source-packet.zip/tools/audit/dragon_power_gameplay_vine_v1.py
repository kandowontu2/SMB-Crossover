"""Native six-part Vine derivative: exact caller/pixels under OAM permutation."""
from pathlib import Path
import argparse,itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import dragon_power_gameplay_controls_v1 as C
from sunny_integrated_controls_v1 import *
O=C.O
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();assert not a.output.exists()
 old,b=[scoped_load(p)for p in[C.P/'candidate.nes',O/'candidate.nes']];p=dict(passed=False,source_CPU_only=True,native_run=False,checks={});ck=p['checks']
 try:
  costs=[];minsp=255;count=0
  for cursor,rot,phase,x,y in itertools.product([64,88,112,208,232],range(0,256,4),[0,1],[0,250],[0,100,230]):
   pair=[]
   for v in[old,b]:
    q=C.setup(v);q.put(CurrentOAMOffset=cursor,RgOamRotation=rot,Enemy_Rel_XPos=x,Enemy_Rel_YPos=y,Vine_Start_Y_Position=200)
    q.m[0x200:0x300]=bytes(range(256));q.m[0x5c70:0x5c80]=bytes(range(16))
    c,tr,mn=C.M.runtrace(q,'DrawVine',a=42,x=5,y=phase,p=0x71);pair.append((q,c,mn))
   oq,oc,_=pair[0];nq,nc,mn=pair[1]
   assert registers(oc)==registers(nc),('Vine AXYP/SP',cursor,rot,phase,x,y,registers(oc),registers(nc))
   expected=bytearray(range(256))
   for i in range(24):expected[(cursor+i+rot)&255]=oq.m[0x200+cursor+i]
   assert bytes(nq.m[0x200:0x300])==expected,('exact native Vine ring bytes',cursor,rot,phase,x,y)
   assert oq.get('CurrentOAMOffset')==nq.get('CurrentOAMOffset') and oq.get('R0')==nq.get('R0') and oq.get('R2')==nq.get('R2')
   assert bytes(nq.m[0x5c70:0x5c80])==bytes(range(16))
   # Exclude ONLY the intentional OAM permutation and literal outer SMCall
   # target values. All other application state/banks match real native.
   a0=bytearray(oq.m[:0x8000]);a1=bytearray(nq.m[:0x8000])
   for lo,hi in[(0x200,0x300),(0x17b,0x200)]:a0[lo:hi]=bytes(hi-lo);a1[lo:hi]=bytes(hi-lo)
   for at in smc_at(v):a0[at]=a1[at]=0
   assert a0==a1 and oq.m.banks==nq.m.banks,('Vine remaining native RAM/banks',cursor,rot,phase,x,y,[(i,u,w)for i,(u,w)in enumerate(zip(a0,a1))if u!=w][:12])
   assert all(not 0x300<=i<0x400 for i,w in nq.m.writes),'native contiguous overflow escaped OAM'
   costs.append(nc.processorCycles-oc.processorCycles);minsp=min(minsp,mn);count+=1
  ck['exact_native_writer_ring_permutation']=dict(cases=count,whole_AXYP_SP_R0_R2_logical_cursor_restored=True,scratch_restored=True,OAM_no_overflow=True,CPU_delta=[min(costs),max(costs)],min_SP=minsp)
  costs=[];count=0
  for ch,f in itertools.product([0,1,2,5,15,20,21,22,23,25,26,27,28,255],[p for p in range(256)if p&0x30==0x30]):
   pair=[]
   for v in[old,b]:
    q=C.setup(v,ch);q.put(CurrentOAMOffset=64,Enemy_Rel_XPos=96,Enemy_Rel_YPos=100,Vine_Start_Y_Position=200)
    c,tr,mn=C.M.runtrace(q,'DrawVine',a=42,x=5,y=1,p=f)
    pair.append((registers(c),C.M.fastapp(q),bytes(q.m[0x100:0x17b]),tuple(q.m.banks),c.processorCycles))
   assert pair[0][:4]==pair[1][:4],('foreign whole Vine',ch,f,pair[0][0],pair[1][0]);costs.append(pair[1][4]-pair[0][4]);count+=1
  ck['foreign_real_DrawVine_all64flags']=dict(cases=count,AXYP_SP_live_RAM_allSMC_banks_exact=True,CPU_delta=[min(costs),max(costs)])
  # Exhausted/misaligned owned cursor rejects without any OAM write. This
  # is explicit admission behavior outside actual Main's64/88 native entries.
  count=0
  for cursor in range(256):
   if 64<=cursor<=232 and cursor%4==0:continue
   q=C.setup(b);q.put(CurrentOAMOffset=cursor);before=bytes(q.m[0x200:0x300]);c,tr,mn=C.M.runtrace(q,'DrawVine',a=42,x=5,y=1,p=0x71)
   assert bytes(q.m[0x200:0x300])==before and q.get('CurrentOAMOffset')==cursor and not c.p&1
   count+=1
  ck['explicit_owned_invalid_full_cursor_rejection']=dict(cases=count,no_OAM_cursor_mutation=True)
  p['passed']=True
 except Exception as e:p.update(failure=repr(e),traceback=traceback.format_exc())
 p['bindings']={str(x.resolve()):sha(x)for x in[Path(__file__),Path(C.__file__),C.P/'candidate.nes',O/'candidate.nes',O/'candidate.dbg',R/'build/dragon_power_gameplay_core_v1.inc']}
 a.output.write_text(json.dumps(p,indent=2)+'\n');print(json.dumps(dict(passed=p['passed'],failure=p.get('failure'),checks=list(ck))));assert p['passed']
if __name__=='__main__':main()
