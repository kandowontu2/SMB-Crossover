"""Current C85 gameplay services: bind genuine relocated callback bank."""
from pathlib import Path
R=Path(__file__).resolve().parents[2]
p=R/'tools/audit/dragon_power_gameplay_controls_v1.py';s=p.read_text()
exec(compile(s,str(Path(__file__)),'exec'))
