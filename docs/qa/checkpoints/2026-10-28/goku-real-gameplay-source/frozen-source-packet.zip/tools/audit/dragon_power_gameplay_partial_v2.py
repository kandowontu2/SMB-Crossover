"""Use actual bank4 DrawAll PC, not same-PC foreign routines."""
from pathlib import Path
R=Path(__file__).resolve().parents[2]
p=R/'tools/audit/dragon_power_gameplay_partial_v1.py';s=p.read_text()
s=s.replace("any(pc==address(b,'DrawAllMetasprites')for bank,pc in tr)","(4,address(b,'DrawAllMetasprites'))in tr")
exec(compile(s,str(Path(__file__)),'exec'))
