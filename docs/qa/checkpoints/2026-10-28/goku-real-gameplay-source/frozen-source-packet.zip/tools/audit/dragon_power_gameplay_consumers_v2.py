"""Successor: fire only after genuine source ready state, not guessed age48."""
from pathlib import Path
import sys
R=Path(__file__).resolve().parents[2]
p=R/'tools/audit/dragon_power_gameplay_consumers_v1.py'
s=p.read_text()
s=s.replace("if age==48:keys|=128","if q.get('DpAction')==8 and q.get('DpTimer')==0 and born is None:keys|=128")
assert s!=p.read_text()
exec(compile(s,str(Path(__file__)), 'exec'))
