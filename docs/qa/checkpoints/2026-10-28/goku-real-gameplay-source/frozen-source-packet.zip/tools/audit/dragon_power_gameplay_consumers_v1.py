"""Real source/host gameplay integration controls; no native observation."""
from pathlib import Path
import argparse,itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import dragon_power_gameplay_controls_v1 as C
import dragon_power_movement_consumers_v2 as I
from sunny_integrated_controls_v1 import *
O=C.O
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();assert not a.output.exists()
 b=scoped_load(O/'candidate.nes');proof=dict(passed=False,source_CPU_only=True,native_run=False,checks={});ck=proof['checks']
 try:
  rows=[]
  for area,mode in itertools.product(range(4),range(2)):
   q=C.setup(b);q.put(AreaType=area,CrossoverBehaviorVersion=mode)
   for age in range(181):
    q.put(NmiDisable=255,VRAM_Buffer1_Offset=0);c,tr,mn=C.M.runtrace(q,'GameLoop')
    assert q.get('DpHungerPeriod')==(1 if area==1 else 3)
   rows.append([area,mode,q.get('DpHP'),q.get('DpHunger'),q.get('DpSecondPhase')])
   assert q.get('DpHP')==(97 if area==1 else 99),('scene hunger',rows[-1])
  ck['complete_Main_hunger_scene_mapping']=dict(updates=1448,rows=rows,scene_mapping_is_authored_not_original_SMB_fact=True)
  rows=[]
  for mode,face in itertools.product(range(2),[1,2]):
   q=C.setup(b);run(q,'DpEnsure');q.put(CrossoverBehaviorVersion=mode,PlayerFacingDir=face)
   C.actor(q,0,6,96,176)
   c,tr,mn=C.M.runtrace(q,'GameLoop')
   assert q.get('DpHP')==100 and q.get('DpProtection')==6 and q.get('DpAction')==14
   assert any(pc==address(b,'InjurePlayer')for bank,pc in tr) and (86,address(b,'DpGameHurt'))in tr
   # Directly consume only the actual original eight-update health owner;
   # this isolates queued damage arithmetic from a moving enemy encounter.
   for age in range(1,49):q.put(DpClock=age,DpSecondPhase=age);run(q,'DpHealthTick')
   assert q.get('DpHP')==94 and q.get('DpProtection')==0
   rows.append([mode,face,c.processorCycles,mn])
  ck['real_Main_body_contact_queued_not_immediate']=dict(cases=4,rows=rows,source_drain_updates=192)
  rows=[]
  for mode,face in itertools.product(range(2),[1,2]):
   q=C.setup(b);run(q,'DpEnsure');q.put(CrossoverBehaviorVersion=mode,PlayerFacingDir=face,Player_Y_Speed=3,Player_State=2,DpAction=3,DpVertical=12,Player_Y_Position=150)
   C.actor(q,0,6,96,176);c,tr,mn=C.M.runtrace(q,'GameLoop')
   if mode==0:
    assert (86,address(b,'DpGameBounce'))in tr
    assert [q.get(n)for n in['DpAction','DpVertical','Player_Y_Speed','Player_State']]==[2,231,252,1]
   else:assert (86,address(b,'DpGameBounce'))not in tr and q.get('DpProtection')==6
   rows.append([mode,face,q.get('DpAction'),q.get('DpVertical'),q.get('DpProtection'),mn])
  ck['Easy_native_stomp_Hard_source_contact']=dict(cases=4,rows=rows)
  # Real full Main collects mature actors, then actual source charge/fire;
  # no pole/wave/tier/ammo/hit/outcome writes. Both source directions.
  rows=[]
  for face in[1,2]:
   q=C.setup(b);q.put(PlayerFacingDir=face)
   for kind in[0,1]:
    C.actor(q,0,0x2e,96,176);q.set('PowerUpType',kind,0);q.set('Enemy_State',128,0)
    c,tr,mn=C.M.runtrace(q,'GameLoop');assert any(pc==address(b,'HandlePowerUpCollision')for bank,pc in tr)
   assert [q.get(n)for n in['DpPole','DpWaves','DpPower','DpHP']]==[1,3,2,120]
   born=None
   for age in range(70):
    keys=64|(1 if face==1 else 2)if age==0 else 64
    if age==48:keys|=128
    q.put(SavedJoypadBits=keys,NmiDisable=255,VRAM_Buffer1_Offset=0)
    c,tr,mn=C.M.runtrace(q,'GameLoop')
    if q.get('DpWaves')==2 and born is None:born=[age,q.get('DpShotState'),q.get('DpShotX'),q.get('DpShotCamera'),mn]
   assert born,('earned wave never allocated',face,q.get('DpAction'),q.get('DpWaves'))
   rows.append([face,born])
  ck['earned_mature_mushroom_flower_source_charge_wave']=dict(campaigns=2,rows=rows,no_equipment_ammo_outcome_seed=True)
  # Legal contact predicate/armor/native HP boundary controls. Source pose
  # setup is labelled CPU boundary input, not an earned native campaign.
  rows=[]
  for kind,pose in itertools.product(list(range(0x15))+[0x2d,0x33,0x2e,0x2f,0x1b],[5,6,0x15,0x16]):
   q=C.setup(b);run(q,'DpEnsure');q.put(DpPose=pose,DpAction=5,DpX=96,DpY=192,DpHorizontal=0)
   # Obtain the genuine original attack point, then stage a target anchor.
   run(q,'DpSourceBuildPoint');px,py=q.get('DpAttackX'),q.get('DpAttackY')
   C.actor(q,0,kind,(px-8)&255,(py-12)&255);q.put(BowserHitPoints=5)
   c,tr,mn=C.M.runtrace(q,'DpGameCombat');hp=q.get('MmEnemyHealthLo',0)
   excluded=kind in[0x0c,0x2e,0x2f,0x1b]or kind in[2,8,0x33]and pose!=0x16
   assert (q.get('MmEnemyFlash',0)==0)==excluded,('eligible armor',kind,pose,hp,q.get('MmEnemyFlash',0))
   if kind==0x2d:assert q.get('BowserHitPoints')==4
   rows.append([kind,pose,hp,q.get('MmEnemyFlash',0),c.processorCycles,mn])
  ck['explicit_actor_armor_HP_native_Bowser_boundaries']=dict(cases=len(rows),rows=rows,boundary_inputs_not_earned_native=True)
  # Actual 127-tick original corpse and native life consumer, plus true time
  # death path. HP0 is a death-boundary input, not a claimed earned defeat.
  rows=[]
  for forced in[False,True]:
   q=C.setup(b);run(q,'DpEnsure')
   if forced:run(q,'KillPlayer')
   else:q.put(DpHP=0)
   start=q.get('NumberofLives');seen=set();at=None
   for age in range(130):
    q.put(NmiDisable=255,VRAM_Buffer1_Offset=0);c,tr,mn=C.M.runtrace(q,'GameLoop');seen.update(tr)
    if q.get('GameEngineSubroutine')==6:at=age;break
   assert at==126 and q.get('NumberofLives')==start,('original corpse timer',forced,at)
   q.put(NmiDisable=255,VRAM_Buffer1_Offset=0);c,tr,mn=C.M.runtrace(q,'GameLoop');seen.update(tr)
   assert q.get('NumberofLives')==start-1 and any(pc==address(b,'PlayerLoseLife')for bank,pc in seen)
   rows.append([forced,at,start,q.get('NumberofLives'),mn])
  ck['source_death_timer_then_real_native_life_owner']=dict(cases=2,rows=rows)
  proof['passed']=True
 except Exception as e:proof.update(failure=repr(e),traceback=traceback.format_exc())
 proof['bindings']={str(p.resolve()):sha(p)for p in[Path(__file__),Path(C.__file__),Path(I.__file__),O/'candidate.nes',O/'candidate.dbg',O/'candidate.lbl',R/'build/dragon_power_gameplay_core_v1.inc',R/'build/dragon_power_gameplay_c_v1.inc']}
 a.output.write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(dict(passed=proof['passed'],failure=proof.get('failure'),checks=list(ck))));assert proof['passed']
if __name__=='__main__':main()
