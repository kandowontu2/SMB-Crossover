"""Correct the CPU observer's RTS boundary, preserve render-v1 negative."""
from pathlib import Path
R=Path(__file__).resolve().parents[2]
p=R/'tools/audit/dragon_power_gameplay_render_v1.py';s=p.read_text()
s=s.replace("c.sp==active['sp']:","c.sp==active['sp']+2:")
s=s.replace("q.set('FirebarSpinState_High',0,slot)","q.set('FirebarSpinState_High',0,slot);q.put(ObjectOffset=slot);C.M.runtrace(q,'ProcFirebar',x=slot)")
assert s!=p.read_text()
exec(compile(s,str(Path(__file__)),'exec'))
