"""Current source C lease and Vine ISR seams, preserving earlier negatives."""
from pathlib import Path
R=Path(__file__).resolve().parents[2]
p=R/'tools/audit/dragon_power_gameplay_render_v1.py';s=p.read_text()
s=s.replace("c.sp==active['sp']:","c.sp==active['sp']+2:")
s=s.replace("q.set('FirebarSpinState_High',0,slot)","q.set('FirebarSpinState_High',0,slot);q.put(ObjectOffset=slot);C.M.runtrace(q,'ProcFirebar',x=slot)")
s=s.replace("assert any(pc==address(b,'DrawWorldFirebars')for bank,pc in tr)","assert not count or ((location(b,'DrawWorldFirebars')-16)//8192,address(b,'DrawWorldFirebars'))in tr")
s=s.replace("['DpGameStep','DpGameWeapons','DpGamePickup','DpGameDraw','DpGameBounce']","['DpGameStep','DpGameWeapons','DpGamePickup','DpGameDraw','DpGameBounce','DpGameVine']")
s=s.replace("if bank==86 and address(b,'DpGameCoreStart')<=pc<0xc000", "if bank==86 and address(b,'DpGameCoreStart')<=pc<0xc000 or bank==85 and address(b,'DpGameCStart')<=pc<address(b,'DpGameCEnd')")
exec(compile(s,str(Path(__file__)),'exec'))
