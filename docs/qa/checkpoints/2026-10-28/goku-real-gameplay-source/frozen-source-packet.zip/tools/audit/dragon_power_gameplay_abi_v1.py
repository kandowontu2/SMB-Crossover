"""Actual public caller return ABI and strict all-six-flags C lease."""
from pathlib import Path
import argparse,itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import dragon_power_gameplay_controls_v1 as C
from sunny_integrated_controls_v1 import *
O=C.O
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();assert not a.output.exists()
 old,b=[scoped_load(p)for p in[C.P/'candidate.nes',O/'candidate.nes']];proof=dict(passed=False,source_CPU_only=True,native_run=False,checks={});ck=proof['checks']
 try:
  flags=[f for f in range(256)if f&0x30==0x30];rows=[]
  for selector,slot,f,cbank in itertools.product(range(4),range(6),flags,[12,85,98]):
   q=C.setup(b);run(q,'DpEnsure');C.actor(q,slot,0x2e,96,176);q.set('Enemy_State',128,slot);q.set('PowerUpType',0,slot)
   q.m.page(2,cbank);q.set('CurrentBankC',cbank|128)
   c,tr,mn=C.M.runtrace(q,'DpGameC',a=selector,x=slot,y=79,p=f)
   assert registers(c)==[selector,slot,79,f,253],('cold whole AXYP/SP',selector,slot,f,cbank,registers(c))
   assert q.m.banks[2]==cbank and q.get('CurrentBankC')==cbank|128
   rows.append([selector,slot,f,cbank,c.processorCycles,mn])
  ck['cold_service_all64flags_real_C_leases']=dict(cases=len(rows),CPU=[min(x[-2]for x in rows),max(x[-2]for x in rows)],min_SP=min(x[-1]for x in rows),whole_AXYP_SP_and_prior_C_hardware_shadow_exact=True)
  costs=[];minimum=255;count=0
  names=['NrPrepare','NrRise','NrPrivate','NrPickupCollision','NrPickup','NrBody','NrInjury','NrInjuryStatus']
  for name,ch,f in itertools.product(names,list(range(24))+[25,26,27,28],flags):
   pair=[]
   for v in[old,b]:
    q=C.setup(v,ch);q.put(ObjectOffset=0,CrossoverBehaviorVersion=1);C.actor(q,0,0x2e if name!='NrBody' else 6,96,176)
    q.set('PowerUpType',0,0);q.set('Enemy_State',128 if name!='NrBody' else 0,0)
    c,tr,mn=C.M.runtrace(q,name,a=91,x=0,y=6,p=f)
    skip=set(smc_at(v))|{address(v,'CurrentBank')}
    writes=[(i,z)for i,z in q.m.writes if not 0x17b<=i<0x200 and not 0x5114<=i<=0x5117 and i not in skip]
    pair.append(((registers(c),C.M.fastapp(q),bytes(q.m[0x100:0x17b]),tuple(q.m.banks)),writes,c.processorCycles,mn))
   assert pair[0][:2]==pair[1][:2],('foreign actual public return/consumer',name,ch,f,pair[0][0][0],pair[1][0][0])
   costs.append(pair[1][2]-pair[0][2]);minimum=min(minimum,pair[1][3]);count+=1
  ck['foreign_public_whole_callers_all64flags']=dict(cases=count,AXYP_SP_fullapp_live_page1_allSMC_banks_and_remaining_ordered_writes_exact=True,CPU_delta=[min(costs),max(costs)],min_SP=minimum)
  proof['passed']=True
 except Exception as e:proof.update(failure=repr(e),traceback=traceback.format_exc())
 proof['bindings']={str(p.resolve()):sha(p)for p in[Path(__file__),Path(C.__file__),C.P/'candidate.nes',O/'candidate.nes',O/'candidate.dbg',R/'build/dragon_power_gameplay_core_v1.inc',R/'build/dragon_power_gameplay_c_v1.inc']}
 a.output.write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(dict(passed=proof['passed'],failure=proof.get('failure'),checks=list(ck))));assert proof['passed']
if __name__=='__main__':main()
