"""Actual retained DrawAll -> no-draw Main -> native Vine partial writer."""
from pathlib import Path
import argparse,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import dragon_power_gameplay_controls_v1 as C
import dragon_power_gameplay_render_v3 as D
from sunny_integrated_controls_v1 import *
O=C.O
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();assert not a.output.exists()
 b=scoped_load(O/'candidate.nes');p=dict(passed=False,source_CPU_only=True,native_run=False,cases=[])
 try:
  for pivot in range(0,256,4):
   q=C.setup(b);run(q,'DpEnsure');q.put(DpPose=6,Player_Y_Position=100,Player_Rel_YPos=100,RgOamFirst=pivot,RgOamUsed=252,FrameCounter=0)
   run(q,'DpGraphics');_,events,mn,_=D.draw(q)
   own=[e for e in events if e['C']==85 and 0xc900<=e['ptr']<=0xcdee]
   slots=sorted(set((e['before']+i+e['rotation'])&255 for e in own for i in range(e['header'])))
   before=bytes(q.m[0x200:0x300]);C.actor(q,5,0x2f,128,80)
   q.put(Vine_FlagOffset=1,Vine_Height=96,ShouldSkipDrawSprites=1,FramesSinceLastSpriteDraw=0,ObjectOffset=5)
   q.set('Vine_ObjOffset',5,0)
   c,tr,mn=C.M.runtrace(q,'GameLoop')
   assert any(pc==address(b,'VineObjectHandler')for bank,pc in tr),('no real Vine',pivot)
   assert not any(pc==address(b,'DrawAllMetasprites')for bank,pc in tr),('not a no-draw Main',pivot)
   after=bytes(q.m[0x200:0x300]);bad=[i for i in slots if before[i]!=after[i]]
   writes=[(i,v)for i,v in q.m.writes if 0x200<=i<0x300]
   p['cases'].append(dict(pivot=pivot,rotation=q.get('RgOamRotation'),source_body_bytes=slots,changed_body_bytes=bad,actual_partial_writes=writes,CPU=c.processorCycles,min_SP=mn))
  assert not any(x['changed_body_bytes']for x in p['cases']),'actual no-draw Vine overwrites retained rotated body'
  p['passed']=True
 except Exception as e:p.update(failure=repr(e),traceback=traceback.format_exc())
 p['bindings']={str(x.resolve()):sha(x)for x in[Path(__file__),Path(C.__file__),Path(D.__file__),O/'candidate.nes',O/'candidate.dbg']}
 a.output.write_text(json.dumps(p,indent=2)+'\n');print(json.dumps(dict(passed=p['passed'],failure=p.get('failure'),cases=len(p['cases']),overlap_cases=sum(bool(x['changed_body_bytes'])for x in p['cases']))));assert p['passed']
if __name__=='__main__':main()
