"""Sparse private complete-Main Goku successor. No native/shared mutation."""
from pathlib import Path
import argparse,hashlib,json,re,subprocess,sys
R=Path(__file__).resolve().parents[1]
P=R/'build/dragon-power-movement-v1';O=R/'build/dragon-power-gameplay-v1'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def main():
 a=argparse.ArgumentParser();a.add_argument('--size-only',action='store_true');a.add_argument('--approved-art-c-code',action='store_true');a=a.parse_args()
 assert sha(P/'handoff.json')=='eadd1eef7433c2db9575954b564b2d5cbfed3a48a34ff540089b708f5ff525ba'
 assert not(O/'handoff.json').exists(),'frozen output'
 (O/'src').mkdir(parents=True,exist_ok=True)
 sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
 from sunny_integrated_controls_v1 import scoped_load,address
 b=scoped_load(P/'candidate.nes')
 # Every original source/dependency binding must still be present and exact.
 h=json.loads((P/'handoff.json').read_text())
 gate=(P/'src/new_roster_dispatch.s').read_text()
 targets={'NrGraphics':'DpGameLate','NrDraw':'DpGameDraw','NrWeapons':'DpGameWeapons','NrInjury':'DpGameInjury','NrLegacyInjuryStatus':'DpGameStatus','NrDeathStart':'DpGameDeathStart'}
 for n,t in targets.items():
  m=re.search(r'^NrGate '+n+r',.*$',gate,re.M);assert m,n
  parts=m[0].split(',');parts[-1]=t;gate=gate[:m.start()]+','.join(parts)+gate[m.end():]
 wrappers={'JnBodyDispatch':'DpGameBody','JnPrepareDispatch':'DpGamePrepare','JnRiseDispatch':'DpGameRise','JnPrivateDispatch':'DpGamePrivate','JnCollisionDispatch':'DpGameCollision','JnPickupDispatch':'DpGamePickup'}
 for old,new in wrappers.items():
  marker='farcall '+old+',';assert gate.count(marker)==1,(old,gate.count(marker));gate=gate.replace(marker,'farcall '+new+',')
 gate='.import '+','.join(targets.values())+','+','.join(wrappers.values())+'\n'+gate
 (O/'src/new_roster_dispatch.s').write_text(gate)
 host=(R/'build/dragon_power_movement_host_v1.inc').read_text()
 host=host.replace('.proc DpHostController\n','.proc DpHostController\n jmp DpGameController\n .res 0\n',1)
 # Preserve all original PCs: replace, do not insert before original +3.
 host=host.replace(' jmp DpGameController\n .res 0\n ; Non-active',' jmp DpGameController\n ; Non-active',1)
 prefix='.proc DpHostController\n jmp DpGameController\n'
 at=host.index(prefix)+len(prefix);ph=host.index(' php\n pha\n phx\n',at);host=host[:ph]+host[ph:].replace(' php\n pha\n phx\n',' pha\n',1)
 host=host.replace('lda #Bank|$80','lda #<(Bank|$80)')
 # Earlier frozen symbol PCs/length remain; new targets supply added behavior.
 start=host.index('.proc DpHostController');end=host.index('.endproc',start)
 part=host[start:end].replace('jsr DpEnsure','jsr DpGameEnsure').replace('jsr DpMovement','jsr DpGameStep')
 host=host[:start]+part+host[end:]
 (O/'movement-host.inc').write_text(host)
 # Actual native stomp dispatch target operands only; same resident span.
 env=(R/'src/megaman_environment.s').read_text();assert env.count('farcall X5StompDispatch')==1
 env='.import DpGameBounce\n'+env.replace('farcall X5StompDispatch','farcall DpGameBounce')
 (O/'src/megaman_environment.s').write_text(env)
 sprite=(R/'src/sprite_render.s').read_text();assert sprite.count('farcall MmReserveVine')==1
 (O/'src/sprite_render.s').write_text('.if ::ENABLE_MMC5_EXPANDED\n.import DpGameVine\n.endif\n'+sprite.replace('farcall MmReserveVine','farcall DpGameVine'))
 component=(P/'component.s').read_text();head=component[:component.index('.include "src/dragon_power_state.inc"')]
 names='''ObjectOffset Enemy_X_Position Enemy_PageLoc Enemy_CollisionBits EnemyOffscrBitsMasked PowerUpType
 MmEnemyHealthLo MmEnemyHealthHi MmEnemyFlash MmDeathFlag BowserHitPoints HandleEnemyFBallCol ShellOrBlockDefeat
 EraseEnemyObject SetupFloateyNumber Square1SoundQueue Square2SoundQueue Sfx_EnemySmack Sfx_PowerUpGrab
 InvPickupOwner InvPickup InvRisePhase InvPickupSaveLo InvPickupSaveHi GuestBodyStompAllowed GuestBodyNoStomp
 StarInvincibleTimer JnBodyDispatch JnPrepareDispatch JnRiseDispatch JnPrivateDispatch JnCollisionDispatch
 JnPickupDispatch X5StompDispatch MarioSourcePowerupCollision CurrentBank MmReserveVine
 CurrentOAMOffset RgOamRotation Enemy_Rel_YPos Enemy_Rel_XPos Vine_Start_Y_Position
 Sprite_X_Position Sprite_Y_Position Sprite_Tilenumber Sprite_Attributes VINE_TILE_1 VINE_TILE_2'''.split()
 for n in names:
  assert n in b['syms'],n
  if not re.search(r'^\.import(?:zp)? '+n+r'$',head,re.M):head+=('.importzp 'if address(b,n)<256 else'.import ')+n+'\n'
 paths=['src/dragon_power_state.inc','build/dragon-power-movement-v1/dragon_power_native_host.inc','build/dragon-power-movement-v1/dragon_power_host_terrain.inc','build/dragon-power-mixed-render-v3/dragon_power_render_mixed.s','src/dragon_power_contact.s','build/dragon-power-mixed-render-v3/dragon_power_mixed_tail.inc','build/dragon-power-gameplay-v1/movement-host.inc','build/dragon_power_gameplay_core_v1.inc','build/dragon-power-mixed-render-v3/dragon_power_art_mixed.inc','build/dragon_power_gameplay_c_v1.inc']
 (O/'component.s').write_text(head+''.join('.include "'+x+'"\n'for x in paths))
 cc=R/'tools/Windows/cc65/bin'
 cmd=[str(cc/'ca65.exe'),'--cpu','6502x','-g','-I',str(R),'-I',str(R/'src'),str(O/'component.s'),'-o',str(O/'component.o')]
 z=subprocess.run(cmd,cwd=R,capture_output=True,text=True);(O/'assemble.log').write_text(z.stdout+z.stderr)
 assert not z.returncode,z.stderr
 z=subprocess.run([str(cc/'od65.exe'),'--dump-segments',str(O/'component.o')],cwd=R,capture_output=True,text=True)
 (O/'size.txt').write_text(z.stdout);print(z.stdout)
 if a.size_only:return
 assert a.approved_art_c_code,'C85 carve requires explicit approval flag'
 raw=(P/'candidate.nes').read_bytes();assert set(raw[16+85*8192+0xdf0:16+85*8192+0x1100])=={255},'actual parent C carve preimage'
 (O/'src/guest_injury.s').write_bytes((P/'src/guest_injury.s').read_bytes())
 (O/'smb1base-mmc5-expanded.cfg').write_bytes((P/'smb1base-mmc5-expanded.cfg').read_bytes())
 (O/'entrypoint.s').write_text((P/'entrypoint.s').read_text()+'\n'+''.join('.export '+n+'\n'for n in names))
 (O/'main.c').write_bytes((P/'main.c').read_bytes())
 prior=json.loads((P/'build-proof.json').read_text())['command'];cmd=[v.replace(str(P),str(O))for v in prior]
 z=subprocess.run(cmd,cwd=R,capture_output=True,text=True);(O/'build.log').write_text(z.stdout+z.stderr)
 proof={'passed':not z.returncode,'native_run':False,'source_CPU_only':True,'command':cmd,'exit':z.returncode,'parent_sha256':sha(P/'candidate.nes')}
 (O/'build-proof.json').write_text(json.dumps(proof,indent=2)+'\n');assert not z.returncode,z.stderr
 from prepare_cv3_dmc_mirror import prepare
 prepare(R,O/'candidate.nes')
 proof.update(candidate_sha256=sha(O/'candidate.nes'),DBG_sha256=sha(O/'candidate.dbg'),LBL_sha256=sha(O/'candidate.lbl'))
 (O/'build-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof,indent=2))
if __name__=='__main__':main()
