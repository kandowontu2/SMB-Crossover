"""Sparse d232 successor: pole tiles are nonsolid only in Goku's source query."""
from pathlib import Path
import difflib, json, subprocess, sys
R = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(R/'tools'), str(R/'tools/audit')]
from sunny_integrated_controls_v1 import scoped_load, address, location, sha
P = R/'build/dragon-power-platform-v1'
O = R/'build/dragon-power-flagpole-v1'
LEAF = R/'build/dragon-power-gameplay-v1/movement-host.inc'

def main():
    assert not (O/'handoff.json').exists()
    assert sha(P/'candidate.nes') == 'd232e4c1a3957ad467138956e8d71a693901eb7776d2a5326ba275425d67ac3d'
    # Verify every actual parent assembler dependency before rebuilding it.
    deps = json.loads((P/'closure.json').read_text())['actual_ASM_dependencies']
    for p, h in deps.items():
        assert sha(p) == h, ('parent dependency changed', p)
    old = scoped_load(P/'candidate.nes')
    assert old['raw'][16+86*8192+0x1FF5:16+87*8192] == bytes([255])*11
    O.mkdir(exist_ok=True)
    source = LEAF.read_text()
    before = ' lda (R6),y\n beq Empty\n cmp #$c0'
    after = (' lda (R6),y\n beq Empty\n'
             ' ; Native flagpole cap/shaft remain queried by DpHostInteractions.\n'
             ' ; Only this source-solid projection ignores their wide tile box.\n'
             ' cmp #$24\n beq Empty\n cmp #$25\n beq Empty\n cmp #$c0')
    assert source.count(before) == 1
    source = source.replace(before, after)
    (O/'movement-host.inc').write_text(source)
    (O/'source.patch').write_text(''.join(difflib.unified_diff(LEAF.read_text().splitlines(True),
        source.splitlines(True), fromfile='parent/movement-host.inc', tofile='flagpole/movement-host.inc')))
    for name in ['main.c', 'entrypoint.s']:
        (O/name).write_bytes((P/name).read_bytes())
    component = (P/'component.s').read_text()
    old_include = '.include "build/dragon-power-gameplay-v1/movement-host.inc"'
    assert component.count(old_include) == 1
    component = component.replace(old_include, '.include "build/dragon-power-flagpole-v1/movement-host.inc"')
    (O/'component.s').write_text(component)
    replacements = {str(P/name): str(O/name) for name in
                    ['main.c','entrypoint.s','component.s','candidate.nes','candidate.dbg','candidate.lbl','candidate.map']}
    cmd = json.loads((P/'build-proof.json').read_text())['command']
    for i, value in enumerate(cmd):
        for oldpath, newpath in replacements.items():
            value = value.replace(oldpath, newpath)
        cmd[i] = value
    p = subprocess.run(cmd, cwd=R, capture_output=True, text=True)
    (O/'build.log').write_text(p.stdout+p.stderr)
    assert not p.returncode, p.stderr
    from prepare_cv3_dmc_mirror import prepare
    prepare(R, O/'candidate.nes')
    new = scoped_load(O/'candidate.nes')
    changed = {k: sum(a != b for a,b in zip(old['raw'][16+k*8192:16+(k+1)*8192],
                    new['raw'][16+k*8192:16+(k+1)*8192])) for k in range(128)}
    changed = {k:v for k,v in changed.items() if v}
    assert old['raw'][:16] == new['raw'][:16] and old['raw'][16+128*8192:] == new['raw'][16+128*8192:]
    qualified = {s.get('id') for n,s in old['syms'].items() if '::' in n}
    moves = []
    for name, symbol in old['syms'].items():
        if name == '_FARCALL_COUNT' or ('::' not in name and symbol.get('id') in qualified):
            continue
        assert name in new['syms'], ('genuine symbol removed', name)
        if address(old,name) != address(new,name):
            assert name.startswith('Dp'), ('foreign/kernel public PC moved',name)
            assert not name.startswith('DpN'), ('original kernel PC moved',name)
            moves.append(dict(name=name,old=f'{address(old,name):04X}',new=f'{address(new,name):04X}',
                              bank=(location(new,name)-16)//8192 if 'seg' in new['syms'][name] else None))
    assert len(new['raw']) == len(old['raw'])
    proof = dict(assembled=True,qualified=False,native_run=False,parent=sha(P/'candidate.nes'),
                 candidate=sha(O/'candidate.nes'),DBG=sha(O/'candidate.dbg'),LBL=sha(O/'candidate.lbl'),
                 command=cmd,changed_banks=changed,own_genuine_moves=moves,
                 original_kernel_and_foreign_public_PCs_exact=True,header_CHR_exact=True,
                 source_change='Only CMP24/BEQ Empty/CMP25/BEQ Empty in private DpHostTileRead; +8B existing CORE86.',
                 final_CORE_end='BFFD',remaining_CORE_fill=3,
                 sparse_overlay='One changed include; parent frozen src/cfg/all other assembler inputs reused by path.')
    (O/'build-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
    print(json.dumps({k:v for k,v in proof.items() if k not in ['command','own_genuine_moves']},indent=2))

if __name__ == '__main__':
    main()
