"""Separate pole/exit successor; preserve native transition attributes and source art."""
from pathlib import Path
import difflib,json,subprocess,sys
R=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(R/'tools'),str(R/'tools/audit')]
from sunny_integrated_controls_v1 import scoped_load,address,location,sha
P=R/'build/dragon-power-platform-v1'
I=R/'build/dragon-power-flagpole-v1'
O=R/'build/dragon-power-flagpole-v2'
RENDER=R/'build/dragon-power-mixed-render-v3/dragon_power_render_mixed.s'

def main():
 assert not(O/'handoff.json').exists()
 assert sha(P/'candidate.nes')=='d232e4c1a3957ad467138956e8d71a693901eb7776d2a5326ba275425d67ac3d'
 assert sha(I/'candidate.nes')=='3bbf0aeb975a84782158089c9c51127b0e1bd346d5fc75f820af5dc19d81dacc'
 for p,h in json.loads((P/'closure.json').read_text())['actual_ASM_dependencies'].items():assert sha(p)==h,p
 O.mkdir(exist_ok=True)
 for name in ['main.c','entrypoint.s','movement-host.inc']:(O/name).write_bytes((I/name).read_bytes())
 source=RENDER.read_text()
 old=' sta ObjectMetasprite\n lda #0\n sta Player_SprAttrib\n lda Player_Rel_XPos'
 new=' sta ObjectMetasprite\n ; Native pipe/castle transition owns Player_SprAttrib; never erase it.\n lda Player_Rel_XPos'
 assert source.count(old)==1
 source=source.replace(old,new)
 old=' lda #0\n sta R3\n sta R5\n lda Player_Rel_XPos'
 new=(' ; Source records own H/V and adaptedP0; only native background priority\n'
      ' ; may be inherited. Other native palette/flip bits must not leak.\n'
      ' lda Player_SprAttrib\n and #$20\n sta R3\n lda #0\n sta R5\n lda Player_Rel_XPos')
 assert source.count(old)==1
 source=source.replace(old,new)
 (O/'render.inc').write_text(source)
 component=(I/'component.s').read_text().replace('build/dragon-power-flagpole-v1/movement-host.inc','build/dragon-power-flagpole-v2/movement-host.inc')
 old='.include "build/dragon-power-mixed-render-v3/dragon_power_render_mixed.s"'
 assert component.count(old)==1
 component=component.replace(old,'.include "build/dragon-power-flagpole-v2/render.inc"')
 (O/'component.s').write_text(component)
 cmd=[v.replace(str(I),str(O))for v in json.loads((I/'build-proof.json').read_text())['command']]
 z=subprocess.run(cmd,cwd=R,capture_output=True,text=True);(O/'build.log').write_text(z.stdout+z.stderr)
 assert not z.returncode,z.stderr
 from prepare_cv3_dmc_mirror import prepare
 prepare(R,O/'candidate.nes');old,new=[scoped_load(x/'candidate.nes')for x in[P,O]]
 changed={k:sum(x!=y for x,y in zip(old['raw'][16+k*8192:16+(k+1)*8192],new['raw'][16+k*8192:16+(k+1)*8192]))for k in range(128)}
 changed={k:v for k,v in changed.items()if v}
 assert old['raw'][:16]==new['raw'][:16]and old['raw'][16+128*8192:]==new['raw'][16+128*8192:]
 ids={s.get('id')for n,s in old['syms'].items()if'::'in n};moves=[]
 for name,s in old['syms'].items():
  if name=='_FARCALL_COUNT'or('::'not in name and s.get('id')in ids):continue
  assert name in new['syms'],('real symbol removed',name)
  if address(old,name)!=address(new,name):
   assert name.startswith('Dp')and not name.startswith('DpN'),('kernel/foreign symbol moved',name)
   moves.append(dict(name=name,old=f'{address(old,name):04X}',new=f'{address(new,name):04X}'))
 assert new['raw'][16+86*8192+0x1ffd:16+87*8192]==bytes([255])*3
 patch=(I/'source.patch').read_text()+''.join(difflib.unified_diff(RENDER.read_text().splitlines(True),source.splitlines(True),fromfile='parent/render.inc',tofile='flagpole/render.inc'))
 (O/'source.patch').write_text(patch)
 proof=dict(assembled=True,qualified=False,native_run=False,parent=sha(P/'candidate.nes'),intermediate_negative=sha(I/'candidate.nes'),candidate=sha(O/'candidate.nes'),DBG=sha(O/'candidate.dbg'),LBL=sha(O/'candidate.lbl'),changed_banks=changed,command=cmd,own_genuine_moves=moves,original_kernel_and_foreign_public_PCs_exact=True,header_CHR_exact=True,final_CORE_end='BFFD',remaining_CORE_fill=3,source_change='8B native24/25 source query projection; remove5B native-attribute clearing; add5B priority20-only projection in actual body renderer. Net+8B.',sparse_overlay='Two changed includes only; all other actual parent dependencies reused by path.')
 (O/'build-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
 print(json.dumps({k:v for k,v in proof.items()if k not in['command','own_genuine_moves']},indent=2))

if __name__=='__main__':main()
