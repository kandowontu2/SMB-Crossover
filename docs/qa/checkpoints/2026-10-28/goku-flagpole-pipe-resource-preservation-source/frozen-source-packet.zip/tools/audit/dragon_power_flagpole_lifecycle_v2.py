"""Supplement: genuine earned life, pit death, fresh/reentry and ordinary caller cost."""
from pathlib import Path
import argparse,itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import dragon_power_flagpole_controls_v2 as T
from sunny_integrated_controls_v1 import *
C=T.C;P=T.P;O=T.O

def main_with_graphics_writer(q):
 """Identify exactly the removed old writer by physicalPC+real STA operand."""
 b=q.b;actual=address(b,'DpGraphics::Set')+10
 at=16+86*8192+actual-0xa000
 assert b['raw'][at:at+3]==bytes([0x8d,address(b,'Player_SprAttrib')&255,address(b,'Player_SprAttrib')>>8])
 original=NesMPU.step;deleted=[]
 def step(c):
  pc=c.pc;bank=q.m.banks[(pc-0x8000)//8192]if pc>=0x8000 else-1
  before=len(q.m.writes);original(c)
  if bank==86 and pc==actual:
   assert len(q.m.writes)==before+1 and q.m.writes[-1]==(address(b,'Player_SprAttrib'),0)
   deleted.append(before)
 NesMPU.step=step
 try:result=C.M.runtrace(q,'GameLoop',p=0x71)
 finally:NesMPU.step=original
 return result,deleted

def map96(q):
 b=q.b;q.put(AreaPointer=37,WorldNumber=0,Hidden1UpFlag=1);run(q,'GetAreaDataAddrs')
 for j in range(3):q.set('AreaObjectLength',255,j)
 cols=[]
 for _ in range(96):
  run(q,'AreaParserCore');cols.append([q.get('MetatileBuffer',y)for y in range(13)]);run(q,'IncrementColumnPos')
 assert cols[86][11]==cols[87][11]==0
 for x,col in enumerate(cols):
  for y,t in enumerate(col):q.m[address(b,'Block_Buffer_1')+((x//16)%2)*208+y*16+x%16]=t

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();assert not a.output.exists()
 b=scoped_load(O/'candidate.nes');old=scoped_load(P/'candidate.nes');p=dict(passed=False,source_CPU_only=True,native_run=False,checks={});ck=p['checks']
 try:
  rows=[]
  for mode in range(2):
   q=C.setup(b);q.put(CrossoverBehaviorVersion=mode);pickups=T.earn(q,True);before=T.resource(q)
   assert before['NumberofLives']==3
   run(q,'NrReset');assert T.resource(q)==before
   q.put(AreaPointer=194);run(q,'NrReset');assert T.resource(q)==before
   q.put(AreaAddrsLOffset=9);run(q,'NrReset');after=T.resource(q)
   for n in['DpHP','DpPole','DpWaves','DpPower','DpLife','NumberofLives']:assert after[n]==before[n]
   assert q.get('DpArea')==0x29 and q.get('DpClock')==0 and q.get('DpAction')==1
   # Actual fresh-game owner, not a manufactured decrement of a life field.
   run(q,'NrFreshGameInit');assert q.get('DpReady')==0
   run(q,'NrReset');cold=T.resource(q)
   assert [cold[n]for n in['DpHP','DpPole','DpWaves','DpPower','DpReady']]==[100,0,0,0,0x44]
   # Legal new-game owner changes always execute their real fresh hook.
   q.put(SelectedCharacter=23);run(q,'NrFreshGameInit');run(q,'NrReset')
   q.put(SelectedCharacter=24);run(q,'NrFreshGameInit');run(q,'NrReset')
   assert [q.get(n)for n in['DpHP','DpPole','DpWaves','DpPower','DpReady']]==[100,0,0,0,0x44]
   rows.append(dict(mode=mode,pickups=pickups,earned=before,same_life_new_scene=after,new_game=cold,other_owner_new_game_then_return_cold=True))
  ck['earned1Up_same_life_future_pointer_scene_fresh_reentry']=dict(cases=rows,arbitrary_midMain_character_swap_NOT_supported_or_claimed=True)
  rows=[]
  for mode in range(2):
   q=C.setup(b);q.put(CrossoverBehaviorVersion=mode);pickups=T.earn(q,False);before=T.resource(q);map96(q)
   q.put(Player_PageLoc=5,Player_X_Position=100,Player_Y_Position=176,Player_Rel_XPos=100,
         ScreenLeft_PageLoc=5,ScreenLeft_X_Pos=0,ScreenRight_PageLoc=5,ScreenRight_X_Pos=255,Player_Pos_ForScroll=100)
   seen=set();transitions=[];prior=None;minimum=255
   for age in range(1100):
    c,tr,mn,cy,ni=T.tick(q,0);seen.update(tr);minimum=min(minimum,mn)
    key=(q.get('OperMode_Task'),q.get('GameEngineSubroutine'),q.get('NumberofLives'),q.get('DpHP'),q.get('DpReady'))
    if key!=prior:transitions.append([age,*key,q.get('Player_Y_Position')]);prior=key
    if q.get('NumberofLives')==before['NumberofLives']-1 and q.get('DpReady')==0x44 and q.get('DpHP')==100:break
   assert q.get('NumberofLives')==before['NumberofLives']-1,transitions
   assert [q.get(n)for n in['DpHP','DpPole','DpWaves','DpPower']]==[100,0,0,0],transitions
   assert ((location(b,'PlayerLoseLife')-16)//8192,address(b,'PlayerLoseLife'))in seen
   rows.append(dict(mode=mode,pickups=pickups,before=before,actual_death_updates=age+1,transitions=transitions,after=T.resource(q),min_SP=minimum))
  ck['real_Main_pit_death_native_life_owner_and_cold_reset']=dict(cases=rows,no_HP_life_injury_exit_outcome_seeds=True,typed_actual1376_1424_gap_origin1380_Y176=True)
  rows=[];relocations=[]
  for mode,keys in itertools.product(range(2),[0,1,2,129,65]):
   pair=[C.setup(v)for v in[old,b]]
   for q in pair:q.put(CrossoverBehaviorVersion=mode)
   for age in range(32):
    results=[]
    removed=[]
    for j,q in enumerate(pair):
     q.put(SavedJoypadBits=keys,NmiDisable=255,VRAM_Buffer1_Offset=0)
     if j==0:(c,tr,mn),removed=main_with_graphics_writer(q)
     else:c,tr,mn=C.M.runtrace(q,'GameLoop',p=0x71)
     ordered=[w for i,w in enumerate(q.m.writes)if j!=0 or i not in removed]
     results.append((registers(c),C.M.fastapp(q),tuple(q.m.banks),bytes(q.m[z]for z in smc_at(q.b)),ordered,c.processorCycles,mn))
    assert results[0][:4]==results[1][:4],('ordinary full Main live state',mode,keys,age)
    details=T.relocation_writes(old,b,results[0][4],results[1][4]);relocations.extend(details)
    rows.append([mode,keys,age,results[0][5],results[1][5],results[1][5]-results[0][5],results[1][6]])
  ck['ordinary_aligned_complete_Main']=dict(cases=len(rows),whole_AXYP_SP_application_OAM_CHR_banks_final5SMC_exact=True,ordered_game_writes_exact_except_explicitly_removed_old_DpGraphics_zero_writer=True,removed_writer_physical_PC_and_STA_operand_proven=True,only_instruction_proven_transient_code_address_writes_relocated=True,raw_stack_relocation_differences_NOT_hidden_as_byteidentity=True,v1_unfiltered_write_count_negative_retained=True,CPU_delta=[min(r[5]for r in rows),max(r[5]for r in rows)],min_SP=min(r[6]for r in rows),rows=rows,relocated_transient_writes=len(relocations))
  p['passed']=True
 except Exception as e:p.update(failure=repr(e),traceback=traceback.format_exc())
 files=[Path(__file__),Path(T.__file__),Path(C.__file__),Path(C.M.__file__),O/'candidate.nes',O/'candidate.dbg',P/'candidate.nes',P/'candidate.dbg']
 p['bindings']={str(x.resolve()):sha(x)for x in files};a.output.write_text(json.dumps(p,indent=2)+'\n')
 print(json.dumps(dict(passed=p['passed'],failure=p.get('failure'),checks=list(ck),sha256=sha(a.output))));assert p['passed']

if __name__=='__main__':main()
