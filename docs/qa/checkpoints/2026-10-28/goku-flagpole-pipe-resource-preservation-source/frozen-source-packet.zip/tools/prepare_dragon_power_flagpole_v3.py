"""Final sparse pole/exit derivative: area reset uses genuine lifecycle Ensure."""
from pathlib import Path
import difflib,json,subprocess,sys
R=Path(__file__).resolve().parents[1]
sys.path[:0]=[str(R/'tools'),str(R/'tools/audit')]
from sunny_integrated_controls_v1 import scoped_load,address,location,sha
P=R/'build/dragon-power-platform-v1'
I=R/'build/dragon-power-flagpole-v2'
O=R/'build/dragon-power-flagpole-v3'
ADMISSION=R/'build/dragon-power-hud-budget-v1/core.inc'

def main():
 assert not(O/'handoff.json').exists()
 assert sha(I/'candidate.nes')=='1d87f583db4c4b4658d32bed2283b92f565f915781eb2a7ee693532134642cf8'
 for p,h in json.loads((P/'closure.json').read_text())['actual_ASM_dependencies'].items():assert sha(p)==h,p
 O.mkdir(exist_ok=True)
 for name in['main.c','entrypoint.s']:(O/name).write_bytes((I/name).read_bytes())
 source=ADMISSION.read_text()
 before='.proc DpAdmissionReset\n DpGameOwner JnResetDispatch\n jmp DpHostReset'
 after=('.proc DpAdmissionReset\n DpGameOwner JnResetDispatch\n'
        ' ; Real life loss/new-game invalidation and loaded-scene refresh belong\n'
        ' ; to Ensure. A same-life area load must not erase earned equipment.\n'
        ' jmp DpEnsure')
 assert source.count(before)==1
 source=source.replace(before,after);(O/'admission.inc').write_text(source)
 component=(I/'component.s').read_text()
 old='.include "build/dragon-power-hud-budget-v1/core.inc"'
 assert component.count(old)==1
 component=component.replace(old,'.include "build/dragon-power-flagpole-v3/admission.inc"')
 (O/'component.s').write_text(component)
 cmd=[]
 replacements={str(I/n):str(O/n)for n in['main.c','entrypoint.s','component.s','candidate.nes','candidate.dbg','candidate.lbl','candidate.map']}
 for v in json.loads((I/'build-proof.json').read_text())['command']:
  for before,after in replacements.items():v=v.replace(before,after)
  cmd.append(v)
 z=subprocess.run(cmd,cwd=R,capture_output=True,text=True);(O/'build.log').write_text(z.stdout+z.stderr)
 assert not z.returncode,z.stderr
 from prepare_cv3_dmc_mirror import prepare
 prepare(R,O/'candidate.nes');old,new=[scoped_load(x/'candidate.nes')for x in[P,O]]
 changed={k:sum(x!=y for x,y in zip(old['raw'][16+k*8192:16+(k+1)*8192],new['raw'][16+k*8192:16+(k+1)*8192]))for k in range(128)}
 changed={k:v for k,v in changed.items()if v}
 assert old['raw'][:16]==new['raw'][:16]and old['raw'][16+128*8192:]==new['raw'][16+128*8192:]
 ids={s.get('id')for n,s in old['syms'].items()if'::'in n};moves=[]
 for name,s in old['syms'].items():
  if name=='_FARCALL_COUNT'or('::'not in name and s.get('id')in ids):continue
  assert name in new['syms'],('real symbol removed',name)
  if address(old,name)!=address(new,name):
   assert name.startswith('Dp')and not name.startswith('DpN'),('kernel/foreign PC moved',name)
   moves.append(dict(name=name,old=f'{address(old,name):04X}',new=f'{address(new,name):04X}'))
 assert new['raw'][16+86*8192+0x1ffd:16+87*8192]==bytes([255])*3
 patch=(I/'source.patch').read_text()+''.join(difflib.unified_diff(ADMISSION.read_text().splitlines(True),source.splitlines(True),fromfile='parent/admission.inc',tofile='flagpole/admission.inc'))
 (O/'source.patch').write_text(patch)
 proof=dict(assembled=True,qualified=False,native_run=False,parent=sha(P/'candidate.nes'),intermediate_attribute_negative=sha((R/'build/dragon-power-flagpole-v1')/'candidate.nes'),intermediate_resource_negative=sha(I/'candidate.nes'),candidate=sha(O/'candidate.nes'),DBG=sha(O/'candidate.dbg'),LBL=sha(O/'candidate.lbl'),changed_banks=changed,command=cmd,own_genuine_moves=moves,original_kernel_and_foreign_public_PCs_exact=True,header_CHR_exact=True,final_CORE_end='BFFD',remaining_CORE_fill=3,source_change='Only private native24/25 terrain projection, native-attribute preservation/priority20-only body inheritance, and same-span area Reset→Ensure target.',sparse_overlay='Three changed includes reused by path; no source/runtime tree copy.')
 (O/'build-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
 print(json.dumps({k:v for k,v in proof.items()if k not in['command','own_genuine_moves']},indent=2))

def freeze():
 import re
 import dragon_power_flagpole_controls_v2 as T
 assert not(O/'handoff.json').exists()
 receipts=[O/'controls-second.json',O/'lifecycle-second.json']
 for path in receipts:
  data=json.loads(path.read_text());assert data['passed'],path
  for name,h in data['bindings'].items():assert sha(name)==h,('receipt binding changed',name)
 parent=json.loads((P/'handoff.json').read_text())
 for name,h in parent['bindings'].items():assert sha(name)==h,('parent changed',name)
 # The exact requested118/Pole1/Waves3/Power2 tuple, separately from the
 # previously qualified earned1Up variant (117HP after one extra source second).
 b=scoped_load(O/'candidate.nes');pipelines=[]
 for mode in range(2):
  q=T.C.setup(b);q.put(CrossoverBehaviorVersion=mode,AreaPointer=37,WorldNumber=0,Hidden1UpFlag=1)
  pickups=T.earn(q,False);run=T.run;start=T.resource(q)
  assert [start[n]for n in['DpHP','DpPole','DpWaves','DpPower']]==[118,1,3,2]
  run(q,'GetAreaDataAddrs')
  for j in range(3):q.set('AreaObjectLength',255,j)
  cols=[]
  for _ in range(220):
   run(q,'AreaParserCore');cols.append([q.get('MetatileBuffer',y)for y in range(13)]);run(q,'IncrementColumnPos')
  for x,col in enumerate(cols):
   for y,t in enumerate(col):q.m[address(b,'Block_Buffer_1')+((x//16)%2)*208+y*16+x%16]=t
  q.put(Player_PageLoc=12,Player_X_Position=64,Player_Y_Position=176,Player_Rel_XPos=96,ScreenLeft_PageLoc=11,ScreenLeft_X_Pos=224,ScreenRight_PageLoc=12,ScreenRight_X_Pos=223,Player_Pos_ForScroll=96)
  rows=[];prior=None;controlled=0
  for age in range(1500):
   c,tr,mn,cy,ni=T.tick(q,1|(128 if 2<=age%70<12 else 0))
   key=tuple(q.get(n)for n in['OperMode_Task','GameEngineSubroutine','AreaType','AreaAddrsLOffset','LevelNumber'])
   if key!=prior:rows.append(dict(update=age,task_engine_area_offset_level=key,resources=T.resource(q)));prior=key
   if q.get('LevelNumber')==1 and q.get('AreaType')==2 and q.get('GameEngineSubroutine')==8:controlled+=1
   if controlled==25:break
  assert controlled==25
  final=T.resource(q)
  for n in['DpHP','DpPole','DpWaves','DpPower','NumberofLives']:assert start[n]==final[n],(mode,n,start,final)
  pipelines.append(dict(mode=mode,pickups=pickups,start=start,transitions=rows,updates=age+1,controlled_underground=controlled,final=final))
 (O/'earned118-pipeline.json').write_text(json.dumps(dict(passed=True,source_CPU_only=True,cases=pipelines),indent=2)+'\n')
 # Independent genuine ca65 compile/dependency closure and link. Keep parent
 # frozen source/cfg paths; redirect only new artifacts and the two object inputs.
 names=['entrypoint.s','component.s','main.c','main-final.d','main-final.o','component-final.d','component-final.o','c-final.o','independent.lbl','independent.dbg','independent.nes']
 replacements={str(P/n):str(O/n)for n in names};commands=[]
 for cmd in json.loads((P/'closure.json').read_text())['commands']:
  cmd=cmd[:]
  for i,v in enumerate(cmd):
   for before,after in replacements.items():v=v.replace(before,after)
   cmd[i]=v
  z=subprocess.run(cmd,cwd=R,capture_output=True,text=True);assert not z.returncode,z.stderr;commands.append(cmd)
 from prepare_cv3_dmc_mirror import prepare
 prepare(R,O/'independent.nes');assert sha(O/'independent.nes')==sha(O/'candidate.nes')
 deps={}
 for path in[O/'main-final.d',O/'component-final.d']:
  for word in re.split(r'(?<!\\)\s+',path.read_text().split(':\t',1)[1].strip().removesuffix(':')):
   target=Path(word.replace('\\ ',' '));target=(target if target.is_absolute()else R/target).resolve();assert target.is_file();deps[str(target)]=sha(target)
 ordinary={}
 for mapper in['mmc3','mmc5']:
  record=json.loads((P/'closure.json').read_text())['fresh_ordinary'][mapper];cmd=record['command'][:]
  for suffix in['.c','-entry.s']:(O/('ordinary-'+mapper+suffix)).write_bytes((P/('ordinary-'+mapper+suffix)).read_bytes())
  cmd=[v.replace(str(P/('ordinary-'+mapper)),str(O/('ordinary-'+mapper)))for v in cmd]
  # Ordinary ROM equality needs no further large debug artifact.
  j=cmd.index('--ld-args');del cmd[j:j+2]
  z=subprocess.run(cmd,cwd=R,capture_output=True,text=True);assert not z.returncode,z.stderr
  assert sha(O/('ordinary-'+mapper+'.nes'))==record['sha256']
  ordinary[mapper]=dict(sha256=record['sha256'],command=cmd)
 closure=dict(passed=True,actual_ASM_dependencies=deps,actual_commands=commands,independent_link_exact=True,fresh_ordinary=ordinary)
 (O/'closure.json').write_text(json.dumps(closure,indent=2)+'\n')
 controls=json.loads(receipts[0].read_text())['checks'];life=json.loads(receipts[1].read_text())['checks']
 report=R/'docs/qa/dragon-power-flagpole-exit-source-2026-10-29.txt'
 text='''PRIVATE GOKU FLAGPOLE/EXIT SUCCESSOR; SOURCE CPU ONLY, NATIVE UNRUN.
Exact parent d232 retains its only approved native25 elevator and all original source movement constants. No further platform/map/physics change, drop composition, audio scheduler, shared/default/Downloads/settings/Git mutation.
The native24/25 cap/shaft were projected to source solid75 before the genuine thin HandleClimbing window6..9 could admit the pole. Only DpHostTileRead now projects24/25 to blank23; DpHostInteractions still receives the real native metatiles. Parent complete-Main arena remains stuck3151/3152; successor reaches actual HandleClimbing, native flag4 then end5.
The intermediate3bbf pole-only candidate exposed a real1-2 intro defect: DpGraphics erased Player_SprAttrib after native side-pipe collision. Its fresh derivative removes that clear, retains the full native attribute and passes ONLY bit20 to body R3. Original source H/V/P0 and geometry remain exact. Intermediate1d87 then exposed real same-life equipment loss from area Reset->HostReset; final same-span target Reset->Ensure uses genuine life-loss/new-game invalidation and loaded-scene refresh instead. All three intermediate product observations are preserved in controls-second.json; no failed ROM was retagged.
Four complete Main+normal-NMI arenas (both modes, cold and actual mature Mushroom/Flower/1Up acquisition) run native flagpole4->5, actual level load, surface1-2 intro, actual side-pipe and25 underground controlled updates. No direct flag/exit/engine/result calls or resource/HP/life/equipment grants were seeded. Native parser220columns and its real flag/castle actors plus a typed approach3136/Y176 are disclosed staging, NOT a natural full route. Exact two-pickup118/Pole1/Waves3/Power2/lives2 pipelines additionally retain every value through both scene transitions; the earned1Up variant retains117/1/3/2/lives3. Source position/camera synchronization is checked on every actual active Main. Fresh/newgame, same-life/future-pointer scene distinction, legal other-owner newgame reentry and genuine pit->native life decrement->cold100 reset pass. Arbitrary mid-Main identity swaps are not supported or claimed.
896 real query cases cover all256native tiles and selected all64flags; only24/25 source class changes. All returnedAXYP/SP and complete32KB RAM including stack are checked there.512 actual body draws cover32poses/two source facing attributes/eight native attributes: every OAM byte equals parent except the intended priority20 bit. No native palette/flip leakage; old source opaque/HV/CHR/P0 exact.112 foreign completeMain cases keep final registers/entirestack/application/OAM/CHR/5SMC/banks/CPU exact. Ordered game/hardware writes are exact; ONLY genuine linked target/actualJSR saved-return code addresses relocate, with opcode/operand/continuation validation. The initial raw-write rejection remains preserved.74 actual query IRQ/lagNMI seams preserve live caller/source/leases/5SMC, minSP226.
Ordinary aligned wholeMain comparisons include routing/drawing/terrain costs and retain live outputs; the removed old DpGraphics zero writer is identified by physical86 PC and actual STA operand, never by a broad field mask. The initial unfiltered write-count negative remains preserved. Final cycles and119 genuine owned symbol movements are in bound JSON. Original kernel/foreign public PCs/RAM/header/CHR exact; all moved owned descriptors and fixed E mirrors are genuinely rebuilt. CORE endsBFFD with3FF bytes left, no new segment/state/lease. Parent previous targets are not aliased.
These CPU arenas execute real Main/NMI/IRQ instructions and bank switches but do not emulate NES PPU/DMA timing, native poll scheduling, visual display, deadline/cadence, complete-route/fairness or audio fidelity. ROOT must run actual native source-qualified successor and inspect pole, pipe, body priority/world pixels. Original fb28 late-render,1b97 tallpipe and d232 traversal negatives remain historical facts. Held original-drop attack/84 limits and Goku atomic audio remain open.
'''
 text+='\nExact candidate '+sha(O/'candidate.nes')+'\nDBG '+sha(O/'candidate.dbg')+'\nLBL '+sha(O/'candidate.lbl')+'\n'
 text+='WholeMain source CPU delta '+json.dumps(life['ordinary_aligned_complete_Main']['CPU_delta'])+'; minSP '+str(life['ordinary_aligned_complete_Main']['min_SP'])+'. No FPS claim.\n'
 text+='Fresh ordinaryMMC3 '+ordinary['mmc3']['sha256']+'; MMC5 '+ordinary['mmc5']['sha256']+'.\n'
 report.write_text(text)
 files=set(Path(p)for p in parent['bindings'])|set(Path(p)for p in deps)|{Path(__file__),report,P/'handoff.json'}
 files|={R/'tools/prepare_dragon_power_flagpole_v1.py',R/'tools/prepare_dragon_power_flagpole_v2.py',R/'tools/audit/dragon_power_flagpole_controls_v1.py',R/'tools/audit/dragon_power_flagpole_controls_v2.py',R/'tools/audit/dragon_power_flagpole_lifecycle_v1.py',R/'tools/audit/dragon_power_flagpole_lifecycle_v2.py'}
 for directory in[O,I,R/'build/dragon-power-flagpole-v1']:
  files.update(x for x in directory.iterdir()if x.is_file()and x.suffix in['.json','.inc','.s','.patch','.nes','.dbg','.lbl','.log','.d'])
 hand=dict(status='FROZEN_PRIVATE_FLAGPOLE_EXIT_SOURCE_CPU_NATIVE_UNRUN',parent=sha(P/'candidate.nes'),candidate=sha(O/'candidate.nes'),DBG=sha(O/'candidate.dbg'),LBL=sha(O/'candidate.lbl'),native_run=False,source_report=str(report),actual_ASM_dependencies=deps,bindings={str(p.resolve()):sha(p)for p in sorted(files)},limits=text)
 for p,h in hand['bindings'].items():assert sha(p)==h,p
 (O/'handoff.json').write_text(json.dumps(hand,indent=2)+'\n')
 print(json.dumps(dict(candidate=hand['candidate'],DBG=hand['DBG'],LBL=hand['LBL'],handoff=sha(O/'handoff.json'),bindings=len(hand['bindings']),actual_ASM_dependencies=len(deps),report=sha(report))))

if __name__=='__main__':freeze()if'--freeze'in sys.argv else main()
