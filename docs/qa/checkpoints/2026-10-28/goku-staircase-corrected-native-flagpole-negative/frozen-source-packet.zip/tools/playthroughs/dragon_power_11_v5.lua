-- Controller-only: settle on the existing left stair before crossing its valley.
local root=assert(ROSTER_CONFIG.out:match('^(.*)/build/'))
local route=assert(dofile(root..'/tools/playthroughs/dragon_power_11_v4.lua'))
local crossed=false
local hold=0
return function(c)
 local b=route(c)
 if c.world==0 and c.level==0 and not crossed and c.x>=2160 and c.x<2256 then
  b={right=c.x<2188,left=c.x>2189}
  if c.grounded and c.r('DpAction')==1 and c.y<=112 and not c.lastA then
   b={right=true,a=true}
   crossed=true
   hold=7
  end
 elseif crossed and hold>0 then
  b={right=true,a=true}
  hold=hold-1
 end
 return b
end
