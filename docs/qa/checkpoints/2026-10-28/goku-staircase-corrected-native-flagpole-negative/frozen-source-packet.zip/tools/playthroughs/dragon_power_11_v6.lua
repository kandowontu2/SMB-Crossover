-- Controller-only final flagpole-base jump; no source physics/map changes.
local root=assert(ROSTER_CONFIG.out:match('^(.*)/build/'))
local route=assert(dofile(root..'/tools/playthroughs/dragon_power_11_v5.lua'))
return function(c)
 local b=route(c)
 if c.world==0 and c.level==0 and c.x>=3136 and c.x<3176 and c.engine==8 then
  b={right=true}
  if c.grounded and c.r('DpAction')==1 and not c.lastA then b.a=true end
 end
 return b
end
