"""Additive complete menu caller stack/IRQ readback; frozen v5 stays untouched."""
import json
import smb2_roster_hud_controls_v5 as H
B,C,T,M=H.B,H.C,H.T,H.M;O=B.OUT

def main():
 hand=B.bind(O/'handoff.json');tool=B.bind(__file__);b=C.scoped_load(O/'candidate.nes');rows=[];irqs=[]
 dest=O/'full-menu-stack-addendum.json';assert not dest.exists()
 def probe_factory(context):
  lowest=[255]
  def probe(c,q):
   if c.sp>=lowest[0]:return
   lowest[0]=c.sp
   if c.p&4:return
   fork=T.Arena(b,q.get('SelectedCharacter'));list.__setitem__(fork.m,slice(None),bytes(q.m));fork.m.banks=q.m.banks.copy()
   fc=T.NesMPU(memory=fork.m,pc=c.pc);fc.a,fc.x,fc.y,fc.p,fc.sp=c.a,c.x,c.y,c.p,c.sp
   irqs.append(dict(context=context,PC=c.pc,bank=q.m.banks[(c.pc-0x8000)//8192]if c.pc>=0x8000 else-1,SP=c.sp,IRQ_minimum_SP=C.interrupt(fc,fork)))
  return probe
 for mode in[0,1]:
  q=M.menu(b);q.put(CrossoverBehaviorVersion=mode);H.run(q,'NrGlobalInit')
  for key in[4,4,4,1,32,32,32,32,64]:
   for mask in[0,key]:
    q.put(VRAM_Buffer1_Offset=0,VRAM_Buffer2_Offset=0,SavedJoypad1Bits=mask,SavedJoypad2Bits=0)
    context=['actual menu input',mode,mask,q.get('CrossoverMenuIndex')]
    c,tr,low=H.run(q,'CrossoverMenuInput',probe=probe_factory(context))
    rows.append(dict(context=context,slot=q.get('CrossoverMenuIndex'),actual_complete_call_minimum_SP=low,return_SP=c.sp))
 for variant in range(4):
  for entry in['DrawSelectionPreview','DisplayIntermediate']:
   q=M.menu(b);q.put(CrossoverMenuIndex=24,S2Variant=variant);H.run(q,'MenuResolveCharacter')
   q.put(OperMode=0 if entry=='DrawSelectionPreview'else 1,DisableIntermediate=0,AltEntranceControl=0,CurrentOAMOffset=0)
   c,tr,low=H.run(q,entry,a=91,x=17,y=23,p=0x71,probe=probe_factory([entry,variant]))
   rows.append(dict(context=[entry,variant],actual_complete_call_minimum_SP=low,return_SP=c.sp))
 assert B.bind(O/'handoff.json')==hand and B.bind(__file__)==tool
 p=dict(passed=True,source_CPU_only=True,native=False,frozen_handoff=hand,candidate=B.bind(O/'candidate.nes'),actual_complete_call_minimum_SP=min(r['actual_complete_call_minimum_SP']for r in rows),actual_IRQ_minimum_SP=min(r['IRQ_minimum_SP']for r in irqs),
  actual_complete_call_rows=rows,actual_reached_new_low_SP_IRQ_snapshots=irqs,bindings=[tool,B.bind(H.__file__),B.bind(O/'candidate.nes'),B.bind(O/'candidate.dbg'),hand],
  limits='Real compiled cold-menu/navigation/Select/lives caller execution with controlled queue service. IRQ fork snapshots preserve immediate AXYP/SP/banks/ZP/privateRAM/all33SMC. This does not execute or qualify raw25 native NMI, hardware timing, audio scheduler, or video.')
 dest.write_text(json.dumps(p,indent=2)+'\n');print(json.dumps(dict(addendum=B.bind(dest),actual_complete_call_minimum_SP=p['actual_complete_call_minimum_SP'],actual_IRQ_minimum_SP=p['actual_IRQ_minimum_SP'])))

if __name__=='__main__':main()
