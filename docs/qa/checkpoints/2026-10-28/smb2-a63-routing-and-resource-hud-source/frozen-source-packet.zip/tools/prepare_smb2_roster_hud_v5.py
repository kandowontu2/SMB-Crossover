"""Sparse own-host A63 rehome/HUD successor; no Roll/shared/native mutation."""
from pathlib import Path
import json,re,subprocess,sys,hashlib
import prepare_smb2_roster_menu_v4 as M
ROOT=M.ROOT;OLD=M.OUT;OUT=ROOT/'build/smb2-roster-hud-v5';bind=M.bind
PARENT='3cdc122904d8aa55572ebcc592bd45c0a8e9b38c1ce3cd24d49258332d6a11f3'

def sub(s,a,b,n=1):assert s.count(a)>=n,(a,s.count(a));return s.replace(a,b,n)
def main():
 assert bind(OLD/'handoff.json')['sha256']==PARENT
 h=json.loads((OLD/'handoff.json').read_text())
 for k in['owned_files','input_bindings','output_bindings']:
  for r in h[k]:assert bind(r['path'])==r,r['path']
 OUT.mkdir(exist_ok=True);ov=OUT/'overlay';(ov/'src').mkdir(parents=True,exist_ok=True)
 from link_pit_rygar_sophia_audit_cpu import scoped_load
 from check_tmnt_render_oa import address,location
 b=scoped_load(OLD/'candidate.nes');occupied=[]
 for g in b['segs'].values():
  if 'ooffs'not in g or not int(g['size'],0):continue
  at=int(g['ooffs'],0)-16;end=at+int(g['size'],0)
  if max(at,63*8192+0xa21)<min(end,63*8192+0x1800):occupied.append(g)
 assert not occupied,occupied
 assert b['raw'][16+63*8192+0xa21:16+63*8192+0x1800]==bytes([255])*3551
 owners=[]
 for n in['CHEATS_FOUR','PALETTE_COALESCE']:
  g=next(v for v in b['segs'].values()if v['name'].strip('"')==n);owners.append(g)
 assert int(owners[0]['start'],0)+int(owners[0]['size'],0)==0xaa21 and int(owners[1]['start'],0)==0xb800
 refs=[]
 d=json.loads(Path(h['source']['path']).read_text())
 for row in d['input_bindings']:
  p=Path(row['path'])
  if p.suffix.lower()not in['.s','.inc']:continue
  for no,line in enumerate(p.read_text().splitlines(),1):
   if re.search(r'\$aa21|\$b7ff|\$ca21|\$d77c',line,re.I):refs.append(dict(path=str(p),line=no,text=line))
 assert not refs,refs
 # Existing source routines/data all remain at their genuine old PCs.
 gates=(ROOT/'src/smb2_roster_main_gates_fast_v3.s').read_text().replace('.segment "KIRBY_ABILITIES"','.segment "CHEATS_FOUR"')
 gates=sub(gates,'S2MUi,S2MainUi,','S2MUi,S2HudEarly,')
 menu=(ROOT/'src/smb2_roster_menu_v4.s').read_text()
 menu=menu.replace('.segment "PARODIUS_BELLS"','.segment "CHEATS_FOUR"').replace('.segment "KIRBY_ABILITIES"','.segment "CHEATS_FOUR"')
 for target in['S2Ensure','S2ColdInit','S2GraphicsBank','S2Graphics::SetBody','S2PublishBody']:
  menu=menu.replace('jsr '+target,'farcall '+target)
 menu=menu.replace('jmp S2MainPalette','farcall S2MainPalette,jmp')
 dest=ROOT/'src/smb2_roster_host_v5.s';dest.write_text(gates+'\n'+menu,newline='\n')
 nr=(OLD/'overlay/src/new_roster_dispatch.s').read_text();nr=sub(nr,'farcall S2MainUi,jmp','farcall S2HudEarly,jmp')
 (ov/'src/new_roster_dispatch.s').write_text(nr,newline='\n')
 main=(ROOT/'src/smb2_roster_main_v2.s').read_text()
 main=sub(main,'farcall ResetPalStar\n jmp S2MainEndTimers','farcall ResetPalStar\n jmp S2HudLate')
 main=sub(main,'farcall CyclePlayerPalettePreload\n jmp S2MainEndTimers','farcall CyclePlayerPalettePreload\n jmp S2HudLate')
 (ov/'src/smb2_roster_main_v2.s').write_text(main,newline='\n')
 core=(ROOT/'src/smb2_roster_core.s').read_text();core=sub(core,'sta S2PaletteAck\n sta S2ObjectHost0','jsr S2HudInvalidate\n sta S2ObjectHost0')
 (ov/'src/smb2_roster_core.s').write_text(core,newline='\n')
 (ov/'src/smb2_roster.s').write_bytes((OLD/'overlay/src/smb2_roster.s').read_bytes())
 objects=OUT/'objects';objects.mkdir(exist_ok=True)
 entry=(OLD/'objects/entrypoint.s').read_text()
 entry=sub(entry,'.include "smb2_roster_main_gates_fast_v3.s"','.include "smb2_roster_host_v5.s"\n.include "smb2_roster_hud_v5.s"')
 entry=sub(entry,'.include "smb2_roster_menu_v4.s"','; Menu is now in the same actual bank63 host object.')
 (objects/'entrypoint.s').write_text(entry,newline='\n')
 cmd=json.loads((OLD/'build-proof.json').read_text())['command']
 cmd=[v.replace(str(OLD/'objects/entrypoint.s'),str(objects/'entrypoint.s'))for v in cmd]
 for i,v in enumerate(cmd):
  if v==str(OLD/'candidate.nes'):cmd[i]=str(OUT/'candidate.nes')
  elif str(OLD/'candidate.')in v:cmd[i]=v.replace(str(OLD/'candidate.'),str(OUT/'candidate.'))
 at=cmd.index('--asm-include-dir');cmd[at:at]=['--asm-include-dir',str(ov/'src')]
 r=subprocess.run(cmd,cwd=ROOT,capture_output=True,text=True);(OUT/'launcher.txt').write_text(r.stdout+r.stderr)
 if r.returncode:
  with(OUT/'build-negatives.jsonl').open('a')as f:f.write(json.dumps(dict(error=r.stderr[-6000:]))+'\n')
  raise AssertionError(r.stderr[-4000:])
 from prepare_cv3_dmc_mirror import prepare
 rom=OUT/'candidate.nes';prepare(ROOT,rom);raw=bytearray(rom.read_bytes());fixed=raw[16+127*8192:16+128*8192]
 source=M.F.P.A.S.ROM.read_bytes();plan=json.loads((ROOT/'build/smb2-roster-audio-plan-v1.json').read_text())
 for clone in plan['samples']:
  copy=bytearray(fixed)
  for e in clone['entries']:
   at=int(e['target'],16)-0xe000;p=int(e['source'],16);n=e['bytes'];blob=source[16+114688+p-0xc000:16+114688+p-0xc000+n]
   assert hashlib.sha256(blob).hexdigest()==e['sha256'];copy[at:at+n]=blob
  raw[16+clone['bank']*8192:16+(clone['bank']+1)*8192]=copy
 rom.write_bytes(raw)
 proof=dict(status='PRIVATE_A63_HUD_DRAFT_UNQUALIFIED_NO_NATIVE',candidate=bind(rom),parent=bind(OLD/'candidate.nes'),parent_handoff=bind(OLD/'handoff.json'),command=cmd,allocation=dict(bank=63,start='AA21',limit='B800',bytes=3551,old_segment_owners=owners,direct_hole_literal_references=refs),
  new_owned_sources=[bind(dest),bind(ROOT/'src/smb2_roster_hud_v5.s')]+[bind(p)for p in sorted((ov/'src').glob('*'))],tool=bind(__file__))
 (OUT/'build-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(dict(candidate=bind(rom),proof=bind(OUT/'build-proof.json')),indent=2))
if __name__=='__main__':main()
