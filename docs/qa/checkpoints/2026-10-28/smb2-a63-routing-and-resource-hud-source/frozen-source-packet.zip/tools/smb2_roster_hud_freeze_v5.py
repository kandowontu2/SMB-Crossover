"""Freeze one small private A63/Main/HUD unit; never install or launch native."""
from pathlib import Path
import collections,difflib,json,re,subprocess,sys
import prepare_smb2_roster_hud_v5 as B
import smb2_roster_hud_controls_v5 as H
R,O,bind=B.ROOT,B.OUT,B.bind

def main():
 build=json.loads((O/'build-proof.json').read_text());tests=json.loads((O/'hud-controls.json').read_text())
 assert build['candidate']==bind(O/'candidate.nes')==tests['candidate']and tests['passed']
 assert build['tool']==bind(B.__file__)and tests['tool']==bind(H.__file__)
 for row in build['new_owned_sources']+tests['consumed_python']:assert bind(row['path'])==row
 old=json.loads((B.OLD/'source-closure.json').read_text());cmd=old['command'].copy()
 cmd[cmd.index('--create-full-dep')+1]=str(O/'source-closure.d');cmd[cmd.index('-o')+1]=str(O/'source-closure.o');cmd[-1]=str(O/'objects/entrypoint.s')
 cmd[4:4]=['-I',str(O/'overlay/src')]
 p=subprocess.run(cmd,cwd=R,capture_output=True,text=True);(O/'source-closure-launcher.txt').write_text(p.stdout+p.stderr);assert not p.returncode,p.stderr
 line=(O/'source-closure.d').read_text().splitlines()[0].split(':\t',1)[1]
 deps={Path(x.replace('\\ ',' ')).resolve()for x in re.split(r'(?<!\\)\s+',line.strip())}
 for row in build['new_owned_sources']:assert Path(row['path']).resolve()in deps,('not consumed',row['path'])
 inputs=deps|{Path(sys.executable),B.OLD/'objects/asset.s',B.OLD/'smb2-roster-native-area.chr',Path(__file__),Path(B.__file__),Path(H.__file__)}
 for row in old['input_bindings']:
  p=Path(row['path'])
  if p.suffix.lower()in['.exe','.dll','.ini','.cfg','.lib']:assert bind(p)==row;inputs.add(p)
 for row in tests['consumed_python']:inputs.add(Path(row['path']))
 ordinary=[]
 for mode in['mmc3','mmc5']:
  out=O/('flagoff-'+mode+'.nes')
  c=[sys.executable,str(R/'tools/build_mmc5_expanded.py'),'--source-overlay',str(O/'overlay'),'--output',str(out),'--flag-off',mode]
  p=subprocess.run(c,cwd=R,capture_output=True,text=True);(O/('flagoff-'+mode+'-launcher.txt')).write_text(p.stdout+p.stderr);assert not p.returncode,p.stderr[-2000:]
  ref=B.OLD/('flagoff-'+mode+'.nes');assert out.read_bytes()==ref.read_bytes();ordinary.append(dict(mapper=mode,actual=bind(out),reference=bind(ref)))
 b=H.C.scoped_load(O/'candidate.nes');prior=H.C.scoped_load(B.OLD/'candidate.nes');moved=[];stable=0;ram=0
 for n,s in prior['syms'].items():
  if 'seg'not in s:continue
  assert n in b['syms'],('old symbol disappeared',n)
  if 'ooffs'not in prior['segs'][s['seg']]:assert H.C.address(prior,n)==H.C.address(b,n);ram+=1;continue
  before,after=H.C.key(prior,n),H.C.key(b,n)
  if before==after:stable+=1;continue
  assert(before[1]==74 and 0xbc81<=before[0]<=0xbffa)or(before[1]==118 and 0xbf06<=before[0]<0xc000)or(n=='S2MenuCodeEnd'and before==(0xc000,119)),('nonowned symbol moved',n,before,after)
  assert after[1]==63 and 0xaa21<=after[0]<0xb800
  moved.append(dict(name=n,old=list(before),new=list(after)))
 patch=''
 for p in sorted((O/'overlay/src').glob('*')):
  q=B.OLD/'overlay/src'/p.name
  if not q.exists():q=R/'src'/p.name
  patch+=''.join(difflib.unified_diff(q.read_text().splitlines(True),p.read_text().splitlines(True),fromfile='c8da/src/'+p.name,tofile='hud-v5/src/'+p.name))
 for p in[R/'src/smb2_roster_host_v5.s',R/'src/smb2_roster_hud_v5.s']:
  patch+=''.join(difflib.unified_diff([],p.read_text().splitlines(True),fromfile='/dev/null',tofile='hud-v5/src/'+p.name))
 (O/'implementation.patch').write_text(patch,newline='\n')
 a,z=prior['raw'],b['raw'];by=collections.Counter((i-16)//8192 for i,(x,y)in enumerate(zip(a,z))if x!=y and i<16+1048576)
 assert a[:16]==z[:16]and a[16+1048576:]==z[16+1048576:]
 source=dict(passed=True,source_CPU_only=True,native=False,candidate=build['candidate'],parent=build['parent'],command=cmd,actual_ASM_dependencies=len(deps),actual_changed_PRG_bytes=dict(by),ordinary=ordinary,
  old_linked_symbols_stable=stable,old_RAM_symbols_stable=ram,explicit_owned_symbol_relocations=moved,
  layout=dict(A63=['AA21',hex(H.C.address(b,'S2HudHostEnd'))],A63_spare=0xb800-H.C.address(b,'S2HudHostEnd'),CORE118=['BF06',hex(H.C.address(b,'S2HudCoreEnd'))],CORE118_spare=0xc000-H.C.address(b,'S2HudCoreEnd'),A74_audio_whole_approved_span_uncontested=['B180','C000'],Roll_ART121_Rogue_AUX='entire bank unchanged',C80='same2044B ART and native-area adaptation; final union requires ROOT depot first8pages rehome'),
  input_bindings=[bind(p)for p in sorted(inputs)],tool=bind(__file__))
 (O/'source-closure.json').write_text(json.dumps(source,indent=2)+'\n')
 note=R/'docs/qa/smb2-roster-hud-source-2026-10-29.txt';c=tests['checks'];main=c['complete_current_Main_menu_earned_world'];irq=c['actual_IRQ_and_queue_consumption'];cost=main['controlled_queue_service_full_Main_cost'];groups={}
 for row in cost:groups.setdefault(row['kind'],[]).append(row['delta'])
 note.write_text('''PRIVATE SMB2 A63 STORAGE / LIVE-RESOURCE HUD SOURCE UNIT — NO NATIVE ADMISSION

Parent: frozen c8da menu/Main/audio successor, genuine f56a base. No canonical,
shared, Downloads, settings or frozen packet was changed. Candidate and genuine
DBG/LBL/MAP are adjacent to this handoff. Owned relocation uses existing
CHEATS_FOUR physical63/$3F AA21..B800 gap; original cheats AA20 and earlier and
PALETTE_COALESCE B800+ remain exact. Own menu/compatibility gates move, so callers
use actual new symbols. No fake aliases or new segments. Original shared PCs
and all RAM symbol values stay exact; exact owned move list is in source proof.

The A74 BC81..BFFF Main/menu use is removed; B180..BC80 authentic audio stays
exact and its whole approved B180..BFFF lease is now uncontested. RollART121
remains live and wholly unchanged; no RollART relocation or Rogue AUX borrowing.
C80 CE00..D5FB original art/menu remains: final ROOT union must include its
approved first-eight-depot-page rehome. This component does not use those
replacement pages or modify any Rogue depot.

Actual completed Main health/reserve UI: native font HP2 MAX4 V3, 11 cells at
2023..202D (Y8 row, X24..111). Native title/name 2043..2049, WORLD/TIME2052..205C,
score/coin/time numeric row3 ($2060..207F) are separate. No sprites, new CHR, palette writes
or invented glyphs. HP=0 at source0; otherwise (health>>4)+1, max=maxfield+2,
reserve=0..9. Those are displayed values, not new health/resource semantics.

Exact raw25 precedes private Ready/resource reads. Existing InvHudName(2B) and
InvHudAmmo(1B) are used only under this owner; original S2MainUi clears generic
InvHudActive/Fresh. No new RAM/global flags. Ready/OperMode1/engine8/unpaused and
screen/timer/parser/scroll/AddrCtrl/both queues idle are required. Actual normal
S2 rendering leaves ReloadCHRBank2, so a zero-reload condition was rejected as a
HUD-liveness bug; genuine CHR publication is preserved. A complete sole14B packet
plus terminator is acknowledged only after every store. Before later Main
producers, only a fully cache-matching sole owned packet can retract and retry;
appended/foreign/corrupt queues are untouched. Real cold/life/scene reset
retracts before invalidating cache. Consumed unchanged HUD stays quiet. Deferred
queue work can delay display; death/transition/menu engine paths are not HUD
publication targets. Native deadline/cadence and visible display epoch remain
unqualified.

The original ResetPalStar or CyclePlayerPalettePreload executes once, then the
original local S2MainEndTimers executes once. New local S2HudLate saves that
actual completed timer return AXYP and all five mutable farcall operands,
publishes, and restores it. All33SMC compare exact, including immutable bytes.
Do not call private S2HudLate before raw25 admission. ROOT's final Rogue/Goku/
SMB2 dispatcher must preserve this order and actual returned state while
servicing each admitted owner once. S2HudEarly and Publish independently guard
raw25; NmiClock remains a separate approved-but-unwired source endpoint.

All previous original gameplay/audio/palette/roll packets remain references,
not fresh native evidence. Source tests explicitly supply NmiClock and queue
service boundaries; no native NMI/PPU/DMC or clock/cadence claim. Source/art
adapters and authored mushroom/flower/swim differences remain as documented in
the frozen predecessors. Original health, size keyframes, carry/throw physics,
retirement, earned upgrades and physical1Up preservation assertions are reused
unchanged on this actual ROM.

Retained drafts: HP0 branch error; display-equivalent fractional cache negative
was too strict; resident HpGraphicsBankCopy uses its real15B (not18B) target load;
intermediate palette vs completed timer AXYP mismatch; no-reload publisher
liveness failure. Unbound drafts were overwritten in the same authorized
working directory; compact first errors/candidate hashes survive, not old full
ROM/source trees. No frozen historical receipt was relabeled or modified.

Remaining admission work: native Main/menu/actual cold owner startup; native
NmiClock, atomic music/SFX cue producer, mixer/DMC lifecycle and final audio
scheduling; true held-enemy room transfer; cheat integration; final shared
Rogue/Goku/Kamikaze/Celeste union and measured native render deadline/cadence.
This is a private complete source unit, not an exposed/playable native slot.
'''+f'\nActual candidate {build["candidate"]["sha256"]}\nASM dependencies {len(deps)}; stable linked symbols {stable}; own moves {len(moved)}; RAM symbols {ram}.\nA63 spare {source["layout"]["A63_spare"]}B, CORE118 spare {source["layout"]["CORE118_spare"]}B.\nForeign completeMain {main["foreign_complete_Main"]}: CPU delta {main["foreign_CPU_delta"]}, complete live state exact.\nOwned pairedMain {main["owned_paired_complete_Main"]}: CPU delta {main["owned_CPU_delta"]}.\nQueue-serviced completeMain measured groups '+json.dumps({k:dict(calls=len(v),delta=[min(v),max(v)])for k,v in groups.items()})+f'.\nUnchanged earned/world assertion campaign {main["actual_earned_world_Main_calls"]} actual Main updates.\nIRQ contexts {irq["actual_ISR_sites"]}, minimumSP {irq["minimum_ISR_SP"]}; direct caller minima/costs in controls.\nFull compiled UpdateScreen isolated HUD: {irq["full_compiled_UpdateScreen"]["cycles"]}CPU including terminal RTS,11 ordered PPUDATA writes (no synthetic incoming JSR cycles). No hardware DMA/NMI budget inference.\nOrdinary fresh MMC3/MMC5 byte-exact to frozen parent; references/hashes in source proof.\n',newline='\n')
 owned=[Path(B.__file__),Path(H.__file__),Path(__file__),R/'src/smb2_roster_host_v5.s',R/'src/smb2_roster_hud_v5.s',note,O/'implementation.patch']+list((O/'overlay/src').glob('*'))
 outputs=[p for p in O.iterdir()if p.is_file()and p.name!='handoff.json']+list((O/'objects').glob('*'))
 h=dict(status='PRIVATE_A63_MENU_MAIN_REAL_RESOURCE_HUD_SOURCE_CPU_IRQ_PASS_NO_NATIVE',candidate=build['candidate'],parent=build['parent'],parent_handoff=build['parent_handoff'],source=bind(O/'source-closure.json'),controls=bind(O/'hud-controls.json'),
  owned_files=[bind(p)for p in sorted(owned)],input_bindings=source['input_bindings'],output_bindings=[bind(p)for p in sorted(outputs)],scope_note=bind(note),
  open=['Final ROOT C80 depot rehome and shared owner dispatcher composition','Native Main/menu/health HUD timing and final render deadline/cadence','Actual held-enemy room transfer and cheats','Raw25 NmiClock/native audio scheduling/atomic cues/mixer/DMC lifecycle'])
 (O/'handoff.json').write_text(json.dumps(h,indent=2)+'\n');print(json.dumps(dict(handoff=bind(O/'handoff.json'),ASMdeps=len(deps),inputs=len(inputs),PRGdiff=dict(by),layout=source['layout']),indent=2))

if __name__=='__main__':main()
