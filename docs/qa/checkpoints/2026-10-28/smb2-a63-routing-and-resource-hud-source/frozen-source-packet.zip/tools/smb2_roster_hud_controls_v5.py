"""Actual compiled HUD/late-return/queue ownership controls, source only."""
import collections,hashlib,itertools,json,sys,traceback
from pathlib import Path
import prepare_smb2_roster_hud_v5 as B
import smb2_roster_menu_controls_v4 as M
T,C=M.T,M.C;R,O=B.ROOT,B.OUT
run=M.run

def packet(q):return M.getbytes(q,'VRAM_Buffer1',q.get('VRAM_Buffer1_Offset')+1)
def expected(q):
 h=q.get('S2Health');h=0 if h==0 else(h>>4)+1
 return bytes([32,35,11])+M.encoded(f'HP{h} MAX{q.get("S2MaxHealth")+2} V{q.get("S2Vegetables")}')+bytes([0])
def ready(b,variant=0,mode=1):
 q=T.arena(b,variant,mode)
 q.put(OperMode=1,OperMode_Task=3,GameEngineSubroutine=8,GamePauseStatus=0,TimerControl=0,
  DisableScreenFlag=0,ReloadCHRBank=0,VRAM_Buffer_AddrCtrl=0,VRAM_Buffer1_Offset=0,VRAM_Buffer2_Offset=0,
  VRAM_Buffer1=0,VRAM_Buffer2=0,AreaParserTaskNum=0,ScrollThirtyTwo=0)
 return q

def integration(b,old):
 # Same incoming/complete-return callers; no virtual routine aliases.
 identities=[(n,x[1],x[2],x[3])for n,x in C.BASE.items()]
 identities += [('popo',20,'IcVariant',0),('nana',20,'IcVariant',1),('alex',21,'RcVariant',0),('ryan',21,'RcVariant',1),('sunny',23,None,0),('celeste',0,'MarioVariant',4)]
 foreign=[]
 for name,raw,field,variant in identities:
  for mode in[0,1]:
   qs=[C.make(z,raw,field,variant,mode)for z in[old,b]];hist=[[],[]]
   for mask in[0,1,129,0]:
    out=[T.frame(q,mask)for q in qs]
    for j,(_,tr)in enumerate(out):hist[j]+=tr
    C.same_live(qs,[v[0]for v in out],('A63 foreign full Main',name,mode,mask),hist)
    foreign.append(out[1][0].processorCycles-out[0][0].processorCycles)
 # Changed menu mapping and new-game init are exercised on the actual new
 # image; previous v4 fixtures/receipts remain immutable.
 menu_rows=[]
 for mode in[0,1]:
  q=M.menu(b);q.set('CrossoverBehaviorVersion',mode);run(q,'NrGlobalInit')
  q.m[0x5c00:0x5c80]=bytes([165])*128;q.m[0x5f98:0x5fa0]=bytes([178])*8
  for key in[4,4,4,1]:M.click(q,key)
  for variant in range(4):
   assert q.get('SelectedCharacter')==25 and q.get('S2Variant')==variant and q.get('S2NativeCharacter')==[0,3,2,1][variant]
   assert q.get('S2Health')==31 and q.get('S2Vegetables')==0 and q.get('S2Ready')==178
   assert M.encoded('    '+M.NAMES[variant]+'    ')in M.getbytes(q,'VRAM_Buffer1',q.get('VRAM_Buffer1_Offset')+1)
   menu_rows.append(dict(mode=mode,variant=variant,OAM_bytes=q.get('CurrentOAMOffset')));M.click(q,32)
 # Paired actual full Main owned states: the only intentional live changes
 # are the three existing HUD cache bytes and the actual VRAM1 queue.
 # Both are read/asserted explicitly below, not silently masked away.
 owned=[];allowed=set(range(C.address(b,'VRAM_Buffer1'),C.address(b,'VRAM_Buffer1')+84))|{C.address(b,'VRAM_Buffer1_Offset'),C.address(b,'InvHudName'),C.address(b,'InvHudName')+1,C.address(b,'InvHudAmmo')}
 for variant,mode in itertools.product(range(4),[0,1]):
  qs=[T.arena(z,variant,mode)for z in[old,b]];hist=[[],[]]
  for frame,mask in enumerate([0]*3+[1]*5+[129]*8+[1]*5+[0]*4):
   out=[T.frame(q,mask)for q in qs]
   for j,(_,tr)in enumerate(out):hist[j]+=tr
   assert all(qs[0].m[p]==qs[1].m[p]for p in list(range(0x17b))+list(range(0x200,0x8000))if p not in allowed),('owned live non-HUD',variant,mode,frame)
   if packet(qs[0])!=packet(qs[1]):assert packet(qs[0])==bytes([0])and packet(qs[1])==expected(qs[1]),('actual added complete HUD packet',variant,mode,frame)
   if qs[0].get('InvHudName')!=qs[1].get('InvHudName'):
    assert qs[1].get('InvHudName')==255 or [qs[1].get('InvHudName'),qs[1].get('InvHudName',1),qs[1].get('InvHudAmmo')]==[qs[1].get('S2Health'),qs[1].get('S2MaxHealth'),qs[1].get('S2Vegetables')]
   assert qs[0].m.banks==qs[1].m.banks and tuple(getattr(out[0][0],n)for n in['a','x','y','p','sp'])==tuple(getattr(out[1][0],n)for n in['a','x','y','p','sp']),('owned return',variant,mode,frame,qs[0].m.banks,qs[1].m.banks,[tuple(getattr(o[0],n)for n in['a','x','y','p','sp'])for o in out])
   owned.append(out[1][0].processorCycles-out[0][0].processorCycles)
 # Re-run the finite original earned/contact/retirement/1-Up and world
 # campaigns on THIS linked image without modifying their assertions.
 hits=collections.Counter();step0=T.NesMPU.step
 sites={C.key(b,n):n for n in['S2MainPickup','S2StandOnActor','S2MainStomp']};calls=0
 def observe(c):
  nonlocal calls
  at=(c.pc,c.memory.banks[(c.pc-0x8000)//8192]if c.pc>=0x8000 else-1)
  if at in sites:hits[sites[at]]+=1
  if at==C.key(b,'GameLoop'):calls+=1
  return step0(c)
 T.NesMPU.step=observe
 try:earned=T.components(b,hits);world=T.world_components(b)
 finally:T.NesMPU.step=step0
 costs=[]
 for variant,mode in itertools.product(range(4),[0,1]):
  qs=[T.arena(z,variant,mode)for z in[old,b]]
  for frame,mask in enumerate([0]*4+[1]*4+[129]*8+[0]*4):
   for q in qs:
    # Controlled source NMI queue-service boundary, not a native NMI model.
    q.put(VRAM_Buffer1_Offset=0,VRAM_Buffer1=0,VRAM_Buffer2_Offset=0,VRAM_Buffer2=0,ReloadCHRBank=0,AreaParserTaskNum=0,ScrollThirtyTwo=0,DisableScreenFlag=0)
   out=[T.frame(q,mask)for q in qs];new=packet(qs[1]);oldp=packet(qs[0]);kind='unchanged-or-priority-deferred'
   if new!=oldp:
    assert oldp==bytes([0])and new==expected(qs[1]);kind='actual-complete-publish'
   costs.append(dict(variant=variant,mode=mode,frame=frame,mask=mask,kind=kind,old_CPU=out[0][0].processorCycles,new_CPU=out[1][0].processorCycles,delta=out[1][0].processorCycles-out[0][0].processorCycles))
 assert sum(r['kind']=='actual-complete-publish'for r in costs)>=8,('complete Main HUD liveness',costs)
 return dict(foreign_complete_Main=len(foreign),foreign_CPU_delta=[min(foreign),max(foreign)],owned_paired_complete_Main=len(owned),owned_CPU_delta=[min(owned),max(owned)],real_menu_lives=menu_rows,actual_earned_world_Main_calls=calls,unchanged_earned_campaign_assertions=earned,unchanged_world_campaign_assertions=world,controlled_queue_service_full_Main_cost=costs)

def irq_and_queue(b):
 # Interrupt every first reached instruction in the changed complete late
 # caller, early retract, and real lifecycle reset, including partial SMC
 # targets. Snapshot fork avoids comparing IRQ hardware ACK writes to an
 # uninterrupted side. Actual immediate live AXYP/bank/33SMC contract strict.
 irqs=[];cost={}
 ranges=[(63,C.address(b,'S2MainGatesBegin'),C.address(b,'S2HudHostEnd')),(118,C.address(b,'S2HudCoreBegin'),C.address(b,'S2HudCoreEnd')),(80,C.address(b,'S2MenuArtBegin'),C.address(b,'S2MenuArtEnd'))]
 entries=[('S2MainEnd',False),('S2MainEnd',True),('S2MainEndStar',False),('S2HudEarly',True),('S2ColdInit',True),('MenuResolveCharacter',False),('QueueSelectName',False),('DrawSelectionPreview',False),('DisplayIntermediate',False)]
 for entry,pending in entries:
  q=ready(b);q.set('S2PaletteAck',q.get('S2NativeCharacter'))
  if entry in['MenuResolveCharacter','QueueSelectName','DrawSelectionPreview']:q.put(OperMode=0,CrossoverMenuIndex=24)
  if entry=='DisplayIntermediate':q.put(DisableIntermediate=0,AltEntranceControl=0,CurrentOAMOffset=0)
  if pending:run(q,'S2HudPublish')
  seen=set()
  def probe(c,q):
   bank=q.m.banks[(c.pc-0x8000)//8192]if c.pc>=0x8000 else-1;site=(c.pc,bank)
   if site in seen or not(any(bank==bk and lo<=c.pc<hi for bk,lo,hi in ranges)or 0x15a<=c.pc<0x17b):return
   seen.add(site);fork=T.Arena(b,25);list.__setitem__(fork.m,slice(None),bytes(q.m));fork.m.banks=q.m.banks.copy()
   fc=T.NesMPU(memory=fork.m,pc=c.pc);fc.a,fc.x,fc.y,fc.p,fc.sp=c.a,c.x,c.y,c.p,c.sp
   irqs.append(dict(entry=entry,pending=pending,pc=c.pc,bank=bank,minimum_SP=C.interrupt(fc,fork)))
  c,tr,low=run(q,entry,a=87,x=17,y=23,p=0x71,probe=probe);cost[entry+str(pending)]=dict(cycles=c.processorCycles,minimum_SP=low)
 # Exact completed queue, genuine UpdateScreen, and subsequent dirty change.
 q=ready(b);run(q,'S2HudPublish');p=packet(q)
 q.set('NmiR0',C.address(b,'VRAM_Buffer1')&255);q.set('NmiR1',C.address(b,'VRAM_Buffer1')>>8)
 q.m.page(2,C.key(b,'FastNmiVramCopy')[1]);c,tr,lo=run(q,'UpdateScreen')
 from audit.proto_palette_coalesce_controls_v1 import ppu
 image,bus=ppu(q.m.writes);assert image=={0x2023+i:v for i,v in enumerate(p[3:14])},(image,p)
 q.put(VRAM_Buffer1_Offset=0,VRAM_Buffer1=0);cache=[q.get('InvHudName'),q.get('InvHudName',1),q.get('InvHudAmmo')]
 run(q,'S2HudEarly');assert[q.get('InvHudName'),q.get('InvHudName',1),q.get('InvHudAmmo')]==cache
 run(q,'S2HudPublish');assert packet(q)==bytes([0]),'unchanged consumed cache must suppress'
 run(q,'S2GiveItem',a=1);run(q,'S2HudPublish');assert packet(q)==expected(q)and q.get('S2Vegetables')==3
 # An unconsumed Main-owned packet is removed before future producers run;
 # changed resources become the one final command at the next late service.
 run(q,'S2HudEarly');assert packet(q)==bytes([0])and q.get('InvHudName')==255
 run(q,'S2GiveItem',a=0);run(q,'S2HudPublish');assert packet(q)==expected(q)and q.get('S2Health')==47
 return dict(actual_ISR_sites=len(irqs),minimum_ISR_SP=min(r['minimum_SP']for r in irqs),ISR_rows=irqs,late_early_reset_cost=cost,full_compiled_UpdateScreen=dict(cycles=c.processorCycles,PPUDATA_writes=len(image),actual_NT_addresses=[hex(i)for i in sorted(image)],exact_source_font_bus=True),real_queue_consumption_and_changed_lag_republication=True)

def main():
 d=json.loads((O/'build-proof.json').read_text());assert B.bind(O/'candidate.nes')==d['candidate']and B.bind(B.__file__)==d['tool']
 for row in d['new_owned_sources']:assert B.bind(row['path'])==row
 b=C.scoped_load(O/'candidate.nes');old=C.scoped_load(B.OLD/'candidate.nes');ck={};proof=dict(passed=False,source_CPU_only=True,native=False,candidate=d['candidate'],tool=B.bind(__file__),checks=ck)
 try:
  # Exact lease recovery: old audio bytes and every callable E clone stay put;
  # no part of Roll ART or future Rogue AUX is borrowed.
  a,z=old['raw'],b['raw'];off=16+74*8192
  assert a[off:off+0x1c81]==z[off:off+0x1c81]
  assert z[off+0x1c81:off+8192]==bytes([255])*(8192-0x1c81)
  for bank in[121]:
   at=16+bank*8192;assert a[at:at+8192]==z[at:at+8192],('protected entire bank',bank)
  # Relocated real public compatibility gates have genuine resident callers.
  # Authenticate the complete farcall instruction shape, then require ONLY
  # its three literal target bytes to change, including same-final E clones.
  targets={C.key(old,n):C.key(b,n)for n in old['syms']if n.startswith('S2M')and'::'not in n and 'seg'in old['syms'][n]and 'ooffs'in old['segs'][old['syms'][n]['seg']]}
  caller_rows=[]
  for bank in[119,120,125,126,127]:
   at=16+bank*8192;want=bytearray(a[at:at+8192]);sites=[]
   for i in range(8192-18):
    v=want[i:i+18]
    if v[0]!=0x8d or v[3]!=0xa9 or v[5]!=0x8d or v[8]!=0xa9 or v[10]!=0x8d or v[13]!=0xa9 or v[15]not in[0x20,0x4c]:continue
    if int.from_bytes(v[1:3],'little')!=C.address(old,'SafecallA_SMC')+1 or int.from_bytes(v[6:8],'little')!=C.address(old,'FarcallJmpTarget_SMC')+1 or int.from_bytes(v[11:13],'little')!=C.address(old,'FarcallJmpTarget_SMC')+2:continue
    key=(v[4]+256*v[9],v[14]&127)
    if key not in targets:continue
    pc,bk=targets[key];want[i+4]=pc&255;want[i+9]=pc>>8;want[i+14]=bk|128;sites.append(i)
   if bank==126:
    # Genuine HpGraphicsBankCopy deliberately omits the dead incoming-A
    # store. Its literal 15B target load/call is source-owned, not a normal
    # 18B macro; authenticate that complete helper before its three changes.
    pc,bk=C.key(old,'HpGraphicsBankCopy');assert bk==126
    i=pc-0x8000;v=want[i:i+18]
    target,owner=C.key(old,'S2MainNativePointers')
    assert bytes(v)==bytes([0xa9,target&255,0x8d,(C.address(old,'FarcallJmpTarget_SMC')+1)&255,1,0xa9,target>>8,0x8d,(C.address(old,'FarcallJmpTarget_SMC')+2)&255,1,0xa9,owner|128,0x20,C.address(old,'FarCallCommon')&255,C.address(old,'FarCallCommon')>>8,0x60,0xea,0xea])
    target,owner=C.key(b,'S2MainNativePointers');want[i+1]=target&255;want[i+6]=target>>8;want[i+11]=owner|128;sites.append(i)
   assert bytes(want)==z[at:at+8192],('non-genuine resident/clone difference',bank)
   caller_rows.append(dict(bank=bank,actual_farcall_sites=sites))
  at=16+63*8192;assert a[at:at+0xa21]==z[at:at+0xa21]and a[at+0x1800:at+8192]==z[at+0x1800:at+8192]
  assert a[:16]==z[:16]and a[16+1048576:]==z[16+1048576:]
  ck['actual_storage']=dict(A74_audio_unchanged=True,A74_plan_spare_reclaimed=True,Roll_ART121_Rogue_AUX_unchanged=True,header_CHR_exact=True,actual_same_final_resident_gate_operand_relocations=caller_rows)
  # Every actual valid HP/max/reserve representation is a precise font packet.
  rows=[]
  for maximum in range(3):
   for hp in[0]+[15+16*i for i in range(maximum+2)]:
    for reserve in range(10):
     q=ready(b);q.put(S2Health=hp,S2MaxHealth=maximum,S2Vegetables=reserve)
     run(q,'S2HudPublish');assert packet(q)==expected(q),(hp,maximum,reserve,list(packet(q)),list(expected(q)))
     assert [q.get('InvHudName'),q.get('InvHudName',1),q.get('InvHudAmmo')]==[hp,maximum,reserve]
     before=packet(q);run(q,'S2HudRetract');assert packet(q)==bytes([0])and q.get('InvHudName')==255,('complete pending packet did not retract',hp,maximum,reserve,list(packet(q)),list(before))
     rows.append([hp,maximum,reserve])
  ck['all_legal_health_max_reserve_queue_and_retract']=dict(cases=len(rows))
  # All original packet/caches strictly authenticated; never erase a similar
  # foreign, aliased, partial or edited command.
  n=0
  for byte in range(15):
   for bit in[1,16,128]:
    q=ready(b);run(q,'S2HudPublish');at=C.address(b,'VRAM_Buffer1');q.m[at+byte]^=bit;before=packet(q);run(q,'S2HudRetract');assert packet(q)==before;n+=1
  for name,i,delta in[('InvHudName',0,16),('InvHudName',1,1),('InvHudAmmo',0,1)]:
   # Fractional HP bits can legitimately share one displayed heart digit;
   # require refusal when the authenticated DISPLAY value differs.
   q=ready(b);run(q,'S2HudPublish');q.set(name,q.get(name,i)^delta,i);before=packet(q);run(q,'S2HudRetract');assert packet(q)==before;n+=1
  for raw in[0,2,3,5,20,24,26,255]:
   q=ready(b);run(q,'S2HudPublish');q.set('SelectedCharacter',raw);before=bytes(q.m);run(q,'S2HudRetract');assert bytes(q.m[0x200:0x8000])==before[0x200:0x8000];n+=1
  ck['strict_foreign_corrupt_packet_cache_negatives']=n
  # A queued HUD is retracted before real cold/area/life reset invalidates the
  # cache. Source-owned health/reserve semantics themselves do not change.
  rows=[]
  for change in['cold','life','scene']:
   q=ready(b);run(q,'S2GiveItem',a=0);run(q,'S2GiveItem',a=1);run(q,'S2HudPublish');assert len(packet(q))==15
   old_resource=[q.get('S2Health'),q.get('S2MaxHealth'),q.get('S2Vegetables')]
   if change=='cold':run(q,'S2ColdInit')
   elif change=='life':q.set('NumberofLives',(q.get('NumberofLives')-1)&255);run(q,'S2Ensure')
   else:q.set('AreaAddrsLOffset',q.get('AreaAddrsLOffset')^1);run(q,'S2Ensure')
   assert packet(q)==bytes([0])and q.get('InvHudName')==255
   assert [q.get('S2Health'),q.get('S2MaxHealth'),q.get('S2Vegetables')]==(old_resource if change=='scene'else[31,0,0])
   rows.append(change)
  ck['pending_then_real_cold_life_scene_reset']=rows
  # Guard decline never acknowledges or partially writes the font command.
  guards=['DisableScreenFlag','TimerControl','VRAM_Buffer_AddrCtrl','VRAM_Buffer1_Offset','VRAM_Buffer1','VRAM_Buffer2_Offset','VRAM_Buffer2','AreaParserTaskNum','GamePauseStatus']
  for field in guards:
   q=ready(b);q.set(field,1);before=M.getbytes(q,'VRAM_Buffer1',84);cache=[q.get('InvHudName'),q.get('InvHudName',1),q.get('InvHudAmmo')]
   run(q,'S2HudPublish');assert M.getbytes(q,'VRAM_Buffer1',84)==before and [q.get('InvHudName'),q.get('InvHudName',1),q.get('InvHudAmmo')]==cache,field
  for field,value in[('OperMode',0),('GameEngineSubroutine',3),('ScrollThirtyTwo',32),('ScrollThirtyTwo',255),('S2Ready',0)]:
   q=ready(b);q.set(field,value);run(q,'S2HudPublish');assert packet(q)==bytes([0])and q.get('InvHudName')==255,(field,value)
  ck['deferred_no_false_ack_admission']=dict(guards=guards,other_declines=5)
  # Preserve the ORIGINAL completed timer-service return, not a selected
  # intermediate palette state. Observe actual post-JSR PC in the new local
  # wrapper and compare the old full caller AXYP/all33SMC independently.
  returns=[]
  for entry in['S2MainEnd','S2MainEndStar']:
   for variant,flag in itertools.product(range(4),[0x30,0x31,0x70,0x71]):
    qs=[ready(z,variant)for z in[old,b]];snap=[]
    for q in qs:q.put(S2Hurt=7,S2WalkTimer=9,S2Timer=11)
    def probe(c,q):
     if c.pc==C.address(b,'S2HudLate')+3 and q.m.banks[1]==118:
      snap.append(((c.a,c.x,c.y,c.p&0xcf),bytes(q.m[0x15a:0x17b])))
    out=[run(qs[0],entry,a=87,x=17,y=23,p=flag),run(qs[1],entry,a=87,x=17,y=23,p=flag,probe=probe)]
    state=lambda c:(c.a,c.x,c.y,c.p&0xcf)
    assert len(snap)==1 and state(out[0][0])==state(out[1][0])==snap[0][0]and bytes(qs[0].m[0x15a:0x17b])==bytes(qs[1].m[0x15a:0x17b])==snap[0][1],('original timer caller return lost',entry,variant,flag,snap,[state(o[0])for o in out])
    assert[qs[1].get('S2Hurt'),qs[1].get('S2WalkTimer'),qs[1].get('S2Timer')]==[6,8,10]
    returns.append(dict(entry=entry,variant=variant,P=flag,minimum_SP=out[1][2],AXYP=list(snap[0][0]),SMC=hashlib.sha256(snap[0][1]).hexdigest(),old_cycles=out[0][0].processorCycles,new_cycles=out[1][0].processorCycles))
  ck['original_completed_timer_return_AXYP_all33SMC_once']=returns
  ck['complete_current_Main_menu_earned_world']=integration(b,old)
  ck['actual_IRQ_and_queue_consumption']=irq_and_queue(b)
  assert B.bind(__file__)==proof['tool']and B.bind(O/'candidate.nes')==proof['candidate']
  modules=set()
  for m in sys.modules.values():
   p=getattr(m,'__file__',None)
   if p:
    p=Path(p).resolve()
    if p.suffix=='.py'and(p.is_relative_to(R)or'py65'in p.parts):modules.add(p)
  proof['consumed_python']=[B.bind(p)for p in sorted(modules)]
  proof.update(passed=True,limits=['Source CPU and explicit queue-service boundaries only; no native/NMI/audio/menu admission.'])
 except BaseException as e:
  proof.update(error=repr(e),traceback=traceback.format_exc())
  with(O/'control-negatives.jsonl').open('a')as f:f.write(json.dumps(dict(candidate=d['candidate'],error=repr(e),traceback=traceback.format_exc()))+'\n')
  raise
 finally:(O/'hud-controls.json').write_text(json.dumps(proof,indent=2)+'\n')
 print(json.dumps(dict(passed=True,sections=len(ck),proof=B.bind(O/'hud-controls.json'))))
if __name__=='__main__':
 import hashlib
 main()
