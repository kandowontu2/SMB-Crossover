; PRIVATE Main-only farcall chaining; all targets are genuine linked owners.
; Never reached from NMI. Shared source routing remains ROOT-owned.
.pushseg
.segment "CHEATS_FOUR"
.export S2MainGatesBegin,S2MainGatesEnd,S2MainNativePointers
S2MainGatesBegin:
S2MainGateCount .set 0
.macro S2MainGate Name,Own,Legacy,Index
.proc Name
 .if .xmatch({Name},{S2MGames}) .or .xmatch({Name},{S2MBox}) .or .xmatch({Name},{S2MEnd}) .or .xmatch({Name},{S2MEndStar}) .or .xmatch({Name},{S2MImmunity})
 jmp .ident(.concat(.string(Name),"Fast"))
 .res 8,$ea
 .else
 php
 pha
 txa
 pha
 tya
 pha
 ldy #Index
 jmp S2MainGateCommon
 .endif
.endproc
.export Name
.ident(.sprintf("S2MainOwnLo%u",S2MainGateCount))=<Own
.ident(.sprintf("S2MainOwnHi%u",S2MainGateCount))=>Own
.ident(.sprintf("S2MainOwnBank%u",S2MainGateCount))=.bank(Own)|$80
.ident(.sprintf("S2MainLegacyLo%u",S2MainGateCount))=<Legacy
.ident(.sprintf("S2MainLegacyHi%u",S2MainGateCount))=>Legacy
.ident(.sprintf("S2MainLegacyBank%u",S2MainGateCount))=.bank(Legacy)|$80
S2MainGateCount .set S2MainGateCount+1
.endmacro

; Data expressions below are actual linked target bytes, never callable
; aliases or guessed PC/bank metadata. Only raw25 selects the new endpoints.
S2MainGate S2MGames,S2MainGame,GameRoutines,0
S2MainGate S2MGraphics,S2Graphics,RlGraphicsDispatch,1
S2MainGate S2MDraw,S2MainDraw,RlDrawDispatch,2
S2MainGate S2MVisible,S2MainVisible,JnVisibleDispatch,3
S2MainGate S2MInjury,S2MainInjury,JnInjuryStartDispatch,4
S2MainGate S2MStatus,S2MainStatus,JnInjuryStatusDispatch,5
S2MainGate S2MDeathStart,S2DeathStart,JnInventoryDeathDispatch,6
S2MainGate S2MDeath,S2DeathUpdate,JnDeathDispatch,7
S2MainGate S2MScene,S2MainScene,JnResetDispatch,8
S2MainGate S2MFresh,S2MainFresh,CmHostFresh,9
S2MainGate S2MPickup,S2MainPickup,JnPickupDispatch,10
S2MainGate S2MPrepare,S2MainPrepare,NrPrepare,11
S2MainGate S2MRise,S2MainNativeNoop,NrRise,12
S2MainGate S2MPrivate,S2MainNativeNoop,NrPrivate,13
S2MainGate S2MMature,S2MainMature,NrPickupCollision,14
S2MainGate S2MUi,S2HudEarly,VvUiDispatch,15
S2MainGate S2MStomp,S2MainStomp,X5StompDispatch,16
S2MainGate S2MPlatform,S2MainPlatform,Z2PositionOnPlatform,17
S2MainGate S2MBody,S2MainBody,JnBodyDispatch,18
S2MainGate S2MWeapons,S2MainProjectiles,RlWeaponsDispatch,19
S2MainGate S2MBox,S2MainBox,LmBoundingBoxGate,20
S2MainGate S2MEnd,S2MainEnd,ResetPalStar,21
S2MainGate S2MEndStar,S2MainEndStar,CyclePlayerPalettePreload,22
S2MainGate S2MColors,S2MainPalette,X5GetPlayerColors,23
S2MainGate S2MSpawn,S2MainSpawn,CrossoverLevelEnemyInit,24
S2MainGate S2MImmunity,S2MainImmunity,MarioSourceBodyImmunity,25
S2MainGate S2MAdder,S2MainAdder,RlAdderDispatch,26
S2MainGate S2MBoxProfile,S2MainBoxProfile,RlBoxDispatch,27
S2MainGate S2MHead,S2Head,JnHeadDispatch,28
S2MainGate S2MSide,S2Side,Z2SideAdmission,29

.proc S2MainGateCommon
 ; No private RAM/R0..R7 lease. Caller AXYP are already on the real stack.
 lda SelectedCharacter
 cmp #25
 beq Own
 tya
 clc
 adc #::S2MainGateCount
 tay
Own:
 lda TargetLo,y
 sta FarcallJmpTarget_SMC+1
 lda TargetHi,y
 sta FarcallJmpTarget_SMC+2
 lda TargetBank,y
 sta NextBank_SMC+1
 pla
 tay
 pla
 tax
 pla
 sta SafecallA_SMC+1
 plp
 lda NextBank_SMC+1
 jmp FarCallCommon
TargetLo:
 .repeat ::S2MainGateCount,I
 .byte .ident(.sprintf("S2MainOwnLo%u",I))
 .endrepeat
 .repeat ::S2MainGateCount,I
 .byte .ident(.sprintf("S2MainLegacyLo%u",I))
 .endrepeat
TargetHi:
 .repeat ::S2MainGateCount,I
 .byte .ident(.sprintf("S2MainOwnHi%u",I))
 .endrepeat
 .repeat ::S2MainGateCount,I
 .byte .ident(.sprintf("S2MainLegacyHi%u",I))
 .endrepeat
TargetBank:
 .repeat ::S2MainGateCount,I
 .byte .ident(.sprintf("S2MainOwnBank%u",I))
 .endrepeat
 .repeat ::S2MainGateCount,I
 .byte .ident(.sprintf("S2MainLegacyBank%u",I))
 .endrepeat
.endproc

.proc S2MainNativePointers
 farcall HpPrepareNativePointers
 lda SelectedCharacter
 cmp #25
 beq Own
 jsr CrossoverGraphicsBank
 rts
Own:
 farcall S2GraphicsBank
 farcall S2PublishBody
 rts
.endproc
S2MainGatesEnd:
.assert S2MainGatesEnd<=$c000,lderror,"SMB2 Main gates need reviewed A74 capacity"
.popseg

.pushseg
.segment "CHEATS_FOUR"
S2FastGatesBegin:
.proc S2MGamesFast
 php
 pha
 lda SelectedCharacter
 cmp #25
 beq Own
 pla
 plp
 farcall GameRoutines,jmp
Own:pla
 plp
 farcall S2MainGame,jmp
 .assert *-S2MGamesFast=49,lderror,"literal fast gate size"
.endproc
.proc S2MBoxFast
 php
 pha
 lda SelectedCharacter
 cmp #25
 beq Own
 pla
 plp
 farcall LmBoundingBoxGate,jmp
Own:pla
 plp
 farcall S2MainBox,jmp
 .assert *-S2MBoxFast=49,lderror,"literal fast gate size"
.endproc
.proc S2MEndFast
 php
 pha
 lda SelectedCharacter
 cmp #25
 beq Own
 pla
 plp
 farcall ResetPalStar,jmp
Own:pla
 plp
 farcall S2MainEnd,jmp
 .assert *-S2MEndFast=49,lderror,"literal fast gate size"
.endproc
.proc S2MEndStarFast
 php
 pha
 lda SelectedCharacter
 cmp #25
 beq Own
 pla
 plp
 farcall CyclePlayerPalettePreload,jmp
Own:pla
 plp
 farcall S2MainEndStar,jmp
 .assert *-S2MEndStarFast=49,lderror,"literal fast gate size"
.endproc
.proc S2MImmunityFast
 php
 pha
 lda SelectedCharacter
 cmp #25
 beq Own
 pla
 plp
 farcall MarioSourceBodyImmunity,jmp
Own:pla
 plp
 farcall S2MainImmunity,jmp
 .assert *-S2MImmunityFast=49,lderror,"literal fast gate size"
.endproc
S2FastGatesEnd:
.assert *<=$c000,lderror,"A74 fast gates exceed existing lease"
.popseg

; PRIVATE additive menu/lives endpoints; source gameplay/audio are unchanged.
; A118 and C80 occupy only the previously measured remainder of their leases.
.pushseg
.segment "CHEATS_FOUR"
.export S2MenuResolve,S2MenuName,S2MenuStatus,S2MenuPortrait,S2MenuToggle
S2MenuCodeBegin:
.proc S2MenuResolve
 ; Preserve the actual former owner on the stack, not a global overlay flag.
 ; CmHostResolve defines X itself. Recover its genuine incoming A unchanged.
 pha
 lda SelectedCharacter
 pha
 tsx
 lda $0102,x
 farcall CmHostResolveCharacter
 php
 pha
 cmp #25
 bne Done
 phx
 phy
 tsx
 lda $0105,x                    ; actual previous SelectedCharacter, before resolve.
 cmp #25
 bne Cold
 farcall S2Ensure                   ; same owner/variant may preserve Continue rewards.
 jmp Restored
Cold:farcall S2ColdInit              ; new selection precedes EVERY Ready read.
Restored:
 ply
 plx
Done:pla
 plp
 pla
 pla
 lda SelectedCharacter          ; exact original resolver's returned A/N/Z.
 rts
.endproc
.proc S2MenuName
 php
 pha
 lda SelectedCharacter
 cmp #25
 beq Own
 pla
 plp
 farcall NrQueueSelectName,jmp
Own:
 pla
 plp
 farcall S2GraphicsBank
 jmp S2MenuNameC
.endproc
.proc S2MenuToggle
 php
 pha
 lda SelectedCharacter
 cmp #25
 beq Own
 pla
 plp
 farcall NrMenuToggle,jmp
Own:pla
 plp
 lda CrossoverMenuPressed
 and #Select_Button
 beq No
 inc S2Variant
 lda S2Variant
 and #3
 sta S2Variant
 sec
 rts
No:clc
 rts
.endproc
.proc S2MenuStatus
 php
 pha
 lda SelectedCharacter
 cmp #25
 beq Own
 pla
 plp
 farcall JnStatusName,jmp
Own:pla
 bne Done
 phx
 phy
 farcall S2GraphicsBank
 ldx #11
 lda #7
 sta R0
 jsr S2MenuCopyC
 ply
 plx
 lda #0
Done:plp
 rts
.endproc
.proc S2MenuPortrait
 farcall S2Ensure
 farcall S2GraphicsBank
 lda S2NativeCharacter
 asl
 ora S2Size
 .repeat 5
 asl
 .endrepeat
 ora #1                        ; authentic standing, unheld, source-facing1.
 tax
 lda S2BodyRecord,x
 farcall S2Graphics::SetBody         ; genuine shared descriptor/CHR tail, no copy.
 farcall S2PublishBody              ; actual X5PortraitRender consumes this record.
 lda #$ff
 sta S2PaletteAck
 farcall S2MainPalette,jmp
.endproc
S2MenuCodeEnd:
.assert *<=$c000,lderror,"SMB2 menu exceeds remaining CORE118 lease"
.segment "CHEATS_FOUR"
S2MenuGlobalBegin:
.proc S2MenuGlobal
 lda #0
 sta S2Variant                 ; dedicated selector, never overlay Ready.
 farcall IcGlobalInit,jmp
.endproc
S2MenuGlobalEnd:
.assert *<=$c000,lderror,"SMB2 menu exceeds remaining A74 lease"
.segment "CD_GFX"
S2MenuArtBegin:
.proc S2MenuNameC
 ldx VRAM_Buffer1_Offset
 cpx #65                       ; 19-byte command plus terminator within84B.
 bcs Done
 stx R1
 lda #$23
 sta VRAM_Buffer1,x
 lda #<X5MenuNameAddress
 sta VRAM_Buffer1+1,x
 lda #16
 sta VRAM_Buffer1+2,x
 lda #$24
 ldy #15
Blank:sta VRAM_Buffer1+3,x
 inx
 dey
 bpl Blank
 ldx R1
 txa
 clc
 adc #7
 tax
 lda #8
 sta R0
 jsr S2MenuCopyC
 txa
 clc
 adc #4
 tax
 stx VRAM_Buffer1_Offset
 lda #0
 sta VRAM_Buffer1,x
Done:rts
.endproc
.proc S2MenuCopyC
 ; Genuine A118 caller explicitly leases C80 before this direct JSR.
 lda S2Variant
 and #3
 asl
 asl
 asl
 tay
Loop:lda Names,y
 sta VRAM_Buffer1,x
 inx
 iny
 dec R0
 bne Loop
 rts
Names:.byte "MARIO   ","LUIGI   ","TOAD    ","PEACH   "
.endproc
S2MenuArtEnd:
.assert *<=$d600,lderror,"SMB2 menu exceeds remaining C80 lease"
.popseg
