.export RdTxMovementFlush
.pushseg
.segment "ROGUE_DAWN_HOST"
.proc RdTxMovementFlush
 jsr RdHostEnabled
 jcc No
 RdHsSave
 lda GameEngineSubroutine
 cmp #8
 jne Done
 lda Player_Y_HighPos
 cmp #1
 jne Done
 ; Flush before any actor/weapon update. Restore source-published Y speed
 ; after the genuine BumpBlock writes its native0, as the original immediate
 ; callback was followed by the exact same source ExportPosition publication.
 lda RdHeadCell
 cmp #$ff
 beq NoHead
 and #$f0
 clc
 adc #32
 sta Rh3
 lda RdHeadCell
 asl
 asl
 asl
 asl
 sta Rh4
 lda RdHeadPage
 sta Rh2
 lda #$ff
 sta RdHeadCell
 lda #0
 sta RdHeadPage
 jsr RdTxNativeCell
 jsr PlayerHeadCollision
 lda RdVY
 sta Player_Y_Speed
NoHead:
 lda #0
 sta Rh6
CoinLoop:
 lda RdRoomHi
 sta Rh2
 lda RdX
 sta Rh4
 lda RdY
 sta Rh3
 lda Rh6
 cmp #3
 bcc Upper
 cmp #6
 bcc Middle
 lda Rh3
 clc
 adc RdRadiusY
 sta Rh3
 jmp Across
Upper:lda Rh3
 sec
 sbc RdRadiusY
 sta Rh3
Middle:
Across:lda Rh6
 ; repeated subtraction keeps the exact nine probes without new state/RAM
 cmp #6
 bcc :+
 sec
 sbc #6
:cmp #3
 bcc :+
 sec
 sbc #3
:cmp #1
 beq CoinCheck
 bcs CoinRight
 lda Rh4
 sec
 sbc RdRadiusX
 sta Rh4
 lda Rh2
 sbc #0
 sta Rh2
 jmp CoinCheck
CoinRight:lda Rh4
 clc
 adc RdRadiusX
 sta Rh4
 lda Rh2
 adc #0
 sta Rh2
CoinCheck:
 lda Rh3
 cmp #32
 bcc Next
 cmp #240
 bcs Next
 lda #1
 sta Rh5
 jsr RdTxLoadedCell       ; validates current loaded page, retains raw tile
 lda Rh7
 cmp #$c2
 beq Coin
 cmp #$c3
 beq Coin
Next:inc Rh6
 lda Rh6
 cmp #9
 jne CoinLoop
 jmp Pipe
Coin:jsr RdTxNativeCell
 jsr HandleCoinMetatile   ; real buffer erase/VRAM/score/coin-life transaction
Pipe:
 lda RdHeld
 and #4
 jeq Done
 ; Actual current source foot ordinate, not Mario's standing size heuristic.
 lda RdY
 clc
 adc RdRadiusY
 clc
 adc #1
 sta Rh3
 cmp #32
 jcc Done
 cmp #240
 jcs Done
 lda RdX
 sec
 sbc RdRadiusX
 sta Rh4
 lda RdRoomHi
 sbc #0
 sta Rh2
 jsr RdTxLoadedCell
 lda Rh7
 cmp #$10
 jne Done
 lda #$10
 sta R1
 lda RdX
 clc
 adc RdRadiusX
 sta Rh4
 lda RdRoomHi
 adc #0
 sta Rh2
 jsr RdTxLoadedCell
 lda Rh7
 cmp #$11
 jne Done
 sta R0
 jsr HandlePipeEntry      ; actual Down gate, engine3/timer/warp native owner
Done:lda #$ff
 sta RdHeadCell
 lda #0
 sta RdHeadPage
 sec
 jmp RdHsRestoreC
No:clc
 rts
.endproc
.popseg
