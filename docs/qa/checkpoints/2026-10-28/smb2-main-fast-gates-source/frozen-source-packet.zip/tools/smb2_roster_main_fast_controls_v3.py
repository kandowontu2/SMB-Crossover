"""Reuse frozen literal Main assertions on the new same-entry route image."""
from pathlib import Path
import argparse,collections,json,re,sys
import prepare_smb2_roster_main_fast_v3 as B
import smb2_roster_main_controls_v2 as T
import smb2_roster_main_callers_v2 as C
T.B=B;T.OUT=B.OUT;C.B=B;C.OUT=B.OUT;C.T=T
R=B.ROOT;OUT=B.OUT

def router_targets(b):
 # Every changed table branch reaches a genuine target on all raw bytes.
 nr=(OUT/'overlay/src/new_roster_dispatch.s').read_text().split('\n.else\n')[0]
 routes=[v.split(',')for v in re.findall(r'^S2NRoute7? ([^\n]+)$',nr,re.M)]
 assert len(routes)==12,routes
 original=(R/'src/new_roster_dispatch.s').read_text()
 old=C.scoped_load(B.OLD/'candidate.nes');rows=[];irq_rows=[]
 for args in routes:
  name,ice,city,sunny,legacy,smb,size,celeste,explicit=args
  assert C.key(old,name)==C.key(b,name),('public PC moved',name)
  lo=[ice,city,legacy,sunny,legacy,smb]+([celeste]if celeste!='0'else[])
  # Assert the actual compiled tables, rather than only trusting source text.
  for label in ['Lo','Hi','Bank']:
   off=C.location(b,name+'::Target'+label)
   actual=list(b['raw'][off:off+len(lo)])
   expected=[(C.key(b,t)[0]&255 if label=='Lo'else C.key(b,t)[0]>>8 if label=='Hi'else C.key(b,t)[1]|128)for t in lo]
   assert actual==expected,(name,label,actual,expected)
  for raw in range(256):
   for flag in [0x30,0x31,0x79,0xff]:
    for variant in ([0,4]if raw==0 and len(lo)==7 else[0]):
     for explicit_bad in ([False,True]if name in ['NrAdder','NrBox']else[False]):
      q=T.Arena(b,raw);q.set('MarioVariant',variant)
      pc,bank=C.key(b,name);q.m.page(1,bank);q.set('CurrentBank',bank|128)
      c=T.NesMPU(memory=q.m,pc=pc);aval=(raw^255)if explicit_bad else raw
      c.a,c.x,c.y,c.p,c.sp=aval,3,6,flag,0xfd;c.stPushWord(0x5aff)
      target=legacy
      if not explicit_bad:
       if raw==0 and len(lo)==7 and variant==4:target=lo[6]
       elif 20<=raw<=25:target=lo[raw-20]
      want=C.key(b,target)
      for _ in range(120):
       at=(c.pc,q.m.banks[(c.pc-0x8000)//8192]if c.pc>=0x8000 else-1)
       if at==want:break
       if raw in [0,20,21,25]and flag==0x30 and variant==0 and not explicit_bad:
        irq_rows.append(dict(name=name,raw=raw,pc=c.pc,bank=at[1],minimum_SP=C.interrupt(c,q)))
       assert q.m[c.pc]!=0;c.step()
      else:raise AssertionError(('actual direct table target bound',name,raw,flag,variant,explicit_bad,want,at))
      assert(c.a,c.x,c.y)==(aval,3,6),(name,raw,'AXY')
      expected=(flag&0x4d)|(aval&0x80)|(2 if aval==0 else 0)
      assert c.p&0xcf==expected,(name,raw,'actual farcall P',flag,c.p,expected)
      rows.append((name,raw,flag,variant,explicit_bad))
 return dict(passed=True,actual_direct_table_targets=len(rows),tables=len(routes),literal_four_physical_flag_patterns=True,
  actual_table_ISR_boundaries=irq_rows,minimum_ISR_SP=min(v['minimum_SP']for v in irq_rows))

def supplemental(b):
 old=C.scoped_load(B.OLD/'candidate.nes');irqs=[]
 for name in ['S2MGames','S2MBox','S2MEnd','S2MEndStar','S2MImmunity']:
  own,legacy=re.search(r'^S2MainGate '+name+r',(\w+),(\w+),\d+$',
   (R/'src/smb2_roster_main_gates_fast_v3.s').read_text(),re.M).groups()
  for raw in [0,25]:
   for flag in [0x30,0x31,0x79,0xff]:
    q=T.Arena(b,raw);pc,bank=C.key(b,name);q.m.page(1,bank);q.set('CurrentBank',bank|128)
    c=T.NesMPU(memory=q.m,pc=pc);c.a,c.x,c.y,c.p,c.sp=0x55,3,6,flag,0xfd;c.stPushWord(0x5aff)
    want=C.key(b,own if raw==25 else legacy)
    for _ in range(100):
     at=(c.pc,q.m.banks[(c.pc-0x8000)//8192]if c.pc>=0x8000 else-1)
     if at==want:break
     if flag==0x30:irqs.append(dict(name=name,raw=raw,pc=c.pc,bank=at[1],minimum_SP=C.interrupt(c,q)))
     c.step()
    else:raise AssertionError(('fast compatibility target',name,raw,flag))
    assert(c.a,c.x,c.y)==(0x55,3,6)
    assert c.p&0xcf==flag&0x4d
 owned=[]
 for variant in range(4):
  for mode in [0,1]:
   qs=[T.arena(x,variant,mode)for x in [old,b]];history=[[],[]]
   for frame,mask in enumerate([0]*3+[1]*5+[129]*8+[1]*5+[0]*4):
    cs=[]
    for i,q in enumerate(qs):
     c,t=T.frame(q,mask);cs.append(c);history[i]+=t
    C.same_live(qs,cs,('owned',variant,mode,frame),history)
    owned.append(dict(variant=variant,mode=mode,frame=frame,mask=mask,
     cycles_v2=cs[0].processorCycles,cycles_v3=cs[1].processorCycles))
 # Full native Main contact callers for every actual current identity;
 # actor placement is disclosed source-arena setup, not a damage result.
 identities=[(n,x[1],x[2],x[3])for n,x in C.BASE.items()]
 identities += [('popo',20,'IcVariant',0),('nana',20,'IcVariant',1),('alex',21,'RcVariant',0),
  ('ryan',21,'RcVariant',1),('sunny',23,None,0),('celeste',0,'MarioVariant',4)]
 contact=[]
 for name,raw,field,variant in identities:
  for mode in [0,1]:
   qs=[C.make(x,raw,field,variant,mode)for x in [old,b]];cs=[];tr=[]
   for q in qs:
    T.actor(q,0,x=112);c,t=q.invoke('GameLoop');cs.append(c);tr.append(t)
   C.same_live(qs,cs,('contact',name,mode),tr)
   contact.append(dict(identity=name,mode=mode,cycles_v2=cs[0].processorCycles,cycles_v3=cs[1].processorCycles))
 pickup=[];pickup_irqs=[];admissions=0
 for name,raw,field,variant in identities+[('smb2',25,'S2Variant',0)]:
  for mode in [0,1]:
   for method,endpoint in [('LmPrepareGate','NrPrepare'),('LmRiseGate','NrRise'),('LmPrivateGate','NrPrivate')]:
    for aval in [0,0x55,0xff]:
     qs=[C.make(x,raw,field,variant,mode)for x in [old,b]];cs=[];tr=[]
     for i,q in enumerate(qs):
      T.actor(q,5,kind=0x2e,x=176,y=152,item=0)
      step0=T.NesMPU.step;in_irq=False
      def observed(c):
       nonlocal admissions,in_irq
       at=(c.pc,q.m.banks[(c.pc-0x8000)//8192]if c.pc>=0x8000 else-1)
       if not in_irq and at==C.key(q.b,endpoint):
        assert q.m[C.address(q.b,'SafecallA_SMC')+1]==c.a,('actual caller SavedA',name,method)
        admissions+=1
       if i==1 and not in_irq and raw in[0,20,25]and variant==0 and mode==1 and aval==0 and at[1]==124:
        # Genuine reached pickup callers and same-bank tails, including
        # partial target writes. No synthetic callable aliases are used.
        # Replay the genuine reached CPU/RAM/bank snapshot in an independent
        # CPU instance. The IRQ necessarily writes PPU/ack registers; mixing
        # it into only one un-interrupted byte-comparison side is not valid.
        # C.interrupt retains its full immediate CPU/bank/ZP/SMC contract.
        fork=T.Arena(q.b,raw);list.__setitem__(fork.m,slice(None),bytes(q.m));fork.m.banks=q.m.banks.copy()
        fc=T.NesMPU(memory=fork.m,pc=c.pc)
        fc.a,fc.x,fc.y,fc.p,fc.sp=c.a,c.x,c.y,c.p,c.sp
        in_irq=True;low=C.interrupt(fc,fork);in_irq=False
        pickup_irqs.append(dict(identity=name,method=method,pc=c.pc,minimum_SP=low))
       return step0(c)
      T.NesMPU.step=observed
      try:c,t=q.invoke(method,a=aval,x=5,y=6)
      finally:T.NesMPU.step=step0
      cs.append(c);tr.append(t)
     C.same_live(qs,cs,('real pickup caller',name,mode,method,aval),tr)
     pickup.append(dict(identity=name,mode=mode,method=method,A=aval,cycles_v2=cs[0].processorCycles,cycles_v3=cs[1].processorCycles))
 return dict(passed=True,fast_gate_ISR=irqs,owned_complete_Main=owned,foreign_contact_Main=contact,
  actual_pickup_callers=pickup,actual_SafecallA_admissions=admissions,pickup_ISR_boundaries=pickup_irqs,
  minimum_fast_ISR_SP=min(v['minimum_SP']for v in irqs))

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--part',choices=['main','callers'],required=True);a=ap.parse_args()
 if a.part=='main':T.main();file=OUT/'main-controls.json'
 else:
  targets=router_targets(C.scoped_load(OUT/'candidate.nes'))
  extra=supplemental(C.scoped_load(OUT/'candidate.nes'))
  C.main();file=OUT/'caller-controls.json'
 q=json.loads(file.read_text());q['runner_wrapper']=B.bind(__file__);q['new_literal_source']=B.bind(OUT/'overlay/src/new_roster_dispatch.s')
 if a.part=='callers':q['merged_NR_targets']=targets;q['supplemental']=extra
 file.write_text(json.dumps(q,indent=2)+'\n');print(json.dumps(dict(final=B.bind(file)),indent=2))

if __name__=='__main__':main()
