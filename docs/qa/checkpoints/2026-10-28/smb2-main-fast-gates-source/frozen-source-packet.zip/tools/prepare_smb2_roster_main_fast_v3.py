"""Sparse same-entry Main router successor of immutable SMB2 v2."""
from pathlib import Path
import json,re,subprocess,sys
import prepare_smb2_roster_main_v2 as P
ROOT=P.ROOT;OUT=ROOT/'build/smb2-roster-main-fast-v3';bind=P.bind
OLD=ROOT/'build/smb2-roster-main-v2'
PARENT_SHA='696826d9f1a69a7111b7e664a0c07f9537daf520f3f315d4d6fc36b0f550dbba'

def proc(s,name,new):
 start=s.index('.proc '+name+'\n');end=s.index('.endproc',start)+len('.endproc')
 return s[:start]+new+s[end:]

def route(name,ice,city,sunny,legacy,smb,size,celeste='0',explicit=0):
 return f'S2NRoute {name},{ice},{city},{sunny},{legacy},{smb},{size},{celeste},{explicit}'

MACRO=""".macro S2NRoute Name,Ice,City,Sunny,Legacy,Smb,Size,Celeste,Explicit
.proc Name
 sta SafecallA_SMC+1
 php
 .if Explicit
 cmp SelectedCharacter
 bne RejectArgument
 .endif
 tya
 pha
 lda SelectedCharacter
 .if .not .xmatch({Celeste},{0})
 bne Number
 lda MarioVariant
 cmp #4
 bne LegacyRoute
 ldy #6
 bne Table
Number:
 .endif
 sec
 sbc #20
 cmp #6
 bcs LegacyRoute
 tay
Table:
 lda TargetLo,y
 sta FarcallJmpTarget_SMC+1
 lda TargetHi,y
 sta FarcallJmpTarget_SMC+2
 lda TargetBank,y
 jmp S2NColdFinish
LegacyRoute:
 pla
 tay
 plp
 lda #<Legacy
 sta FarcallJmpTarget_SMC+1
 lda #>Legacy
 sta FarcallJmpTarget_SMC+2
 lda #.bank(Legacy)|$80
 jmp FarCallCommon
 .if Explicit
RejectArgument:
 plp
 farcall Legacy,jmp
 .endif
TargetLo:.byte <Ice,<City,<Legacy,<Sunny,<Legacy,<Smb
TargetHi:.byte >Ice,>City,>Legacy,>Sunny,>Legacy,>Smb
TargetBank:.byte .bank(Ice)|$80,.bank(City)|$80,.bank(Legacy)|$80,.bank(Sunny)|$80,.bank(Legacy)|$80,.bank(Smb)|$80
 .if .not .xmatch({Celeste},{0})
 ; Celeste is the seventh entry in EACH table, emitted separately below.
 .error "Celeste route must use the seven-entry specialization"
 .endif
 .if .xmatch({Name},{NrMovement})
::S2NColdFinish:
 sta NextBank_SMC+1
 pla
 tay
 plp
 jmp FarCallCommon+3
 .endif
 .if .xmatch({Name},{NrGraphics})
::S2NSideLegacy:
 farcall Z2SideAdmission,jmp
 .endif
 .assert *-Name<=Size,error,"SMB2 same-entry route exceeds original slot"
 .res Size-(*-Name),$ff
.endproc
.endmacro
"""

def main():
 assert bind(OLD/'handoff.json')['sha256']==PARENT_SHA
 h=json.loads((OLD/'handoff.json').read_text())
 for key in ['owned_files','input_bindings','output_bindings']:
  for r in h[key]:assert bind(r['path'])==r,r['path']
 OUT.mkdir(exist_ok=True);ov=OUT/'overlay';(ov/'src').mkdir(parents=True,exist_ok=True)
 for src in (OLD/'overlay/src').glob('*.s'):(ov/'src'/src.name).write_bytes(src.read_bytes())
 (ov/'smb1base-mmc5-expanded.cfg').write_bytes((OLD/'overlay/smb1base-mmc5-expanded.cfg').read_bytes())
 nr=(ov/'src/new_roster_dispatch.s').read_text()
 # Expanded branch only: retain ordinary old source verbatim.
 split='\n.else\n';expanded,flagoff=nr.rsplit(split,1)
 canon=(ROOT/'src/new_roster_dispatch.s').read_text()
 nr=expanded
 oldmacro=re.search(r'\.macro NrGate Name,Ice,City,Sunny,Legacy\n.*?\.endmacro',nr,re.S)[0]
 nr=nr.replace(oldmacro,oldmacro+'\n'+MACRO)
 own={'NrGraphics':'S2Graphics','NrDraw':'S2MainDraw','NrInjury':'S2MainInjury',
 'NrLegacyInjuryStatus':'S2MainStatus','NrDeathStart':'S2DeathStart','NrDeath':'S2DeathUpdate',
 'NrVisible':'S2MainVisible','NrHead':'S2Head'}
 originals={m[1]:m[2]for m in re.finditer(r'^NrGate (\w+),([^\n]+)$',canon,re.M)}
 for name,args in originals.items():
  nr=re.sub(r'^NrGate '+name+r',[^\n]+$',route(name,*args.split(','),own.get(name,args.split(',')[-1]),97),nr,flags=re.M)
 # No new ownership endpoint is needed for these three original routes.
 for name in ['NrMovement']:
  nr=re.sub(r'^S2NRoute '+name+r',[^\n]+$','NrGate '+name+','+originals[name],nr,flags=re.M)
 nr=nr.replace('.xmatch({Name},{NrMovement})','.xmatch({Name},{NrInjury})')
 # Handwritten body uses the same71B dispatcher, then its14B Ice policy.
 name='NrBody';ice='S2NIceBody'
 body=route(name,ice,'RcBodyContact','SunnyBody','JnBodyDispatch','S2MainBody',93)
 # Helper is placed in another original gate's unexecuted slack.
 nr=proc(nr,name,body)
 nr=nr.replace(' .if .xmatch({Name},{NrDraw})',' .if .xmatch({Name},{NrDraw})')
 anchor=' .assert *-Name<=Size,error,'
 extra=""" .if .xmatch({Name},{NrDraw})
::S2NBodyLegacy:
 farcall JnBodyDispatch,jmp
 .endif
 .if .xmatch({Name},{NrLegacyInjuryStatus})
::S2NBodyCity:
 farcall RcBodyContact,jmp
 .endif
 .if .xmatch({Name},{NrVisible})
::S2NUiLegacy:
 farcall VvUiDispatch,jmp
 .endif
 .if .xmatch({Name},{NrHead})
::S2NUiIce:
 farcall X5NativeInventoryUiLeaf,jmp
 .endif
"""
 nr=nr.replace(anchor,extra+anchor)
 for name,ice,city,sunny,old,new in[
 ('NrAdder','IcAdder','RcCollisionAdder','SunnyAdder','RlAdderDispatch','S2MainAdder'),
 ('NrBox','IcBox','RcCollisionBox','SunnyBox','RlBoxDispatch','S2MainBoxProfile')]:
  nr=proc(nr,name,route(name,ice,city,sunny,old,new,99,explicit=1))
 # Real side-probe owner25 shares nativeBlockBuffer route with20/21/23.
 start=nr.index('.proc NrSide\n');end=nr.index('.endproc',start)+len('.endproc')
 old=nr[start:end]
 new=old.replace(' cmp #CHARACTER_ICE_CLIMBERS',' cmp #25\n beq Native\n cmp #CHARACTER_ICE_CLIMBERS',1)
 new=new.replace('farcall S2MSide,jmp','jmp S2NSideLegacy')
 new=new.replace('.endproc',' .assert *-NrSide<=42,error,"side original slot"\n .res 11,$ff\n.endproc')
 nr=nr[:start]+new+nr[end:]
 # Ui/colors use a seven-entry direct table. Keep Celeste0/variant4 admission.
 macro7=MACRO.replace('.macro S2NRoute ','.macro S2NRoute7 ')
 macro7=macro7.replace('TargetLo:.byte <Ice,<City,<Legacy,<Sunny,<Legacy,<Smb','TargetLo:.byte <Ice,<City,<Legacy,<Sunny,<Legacy,<Smb,<Celeste')
 macro7=macro7.replace('TargetHi:.byte >Ice,>City,>Legacy,>Sunny,>Legacy,>Smb','TargetHi:.byte >Ice,>City,>Legacy,>Sunny,>Legacy,>Smb,>Celeste')
 macro7=macro7.replace('.bank(Smb)|$80\n','.bank(Smb)|$80,.bank(Celeste)|$80\n')
 macro7=re.sub(r' \.if \.not \.xmatch\(\{Celeste\},\{0\}\)\n ; Celeste.*? \.endif\n','',macro7,flags=re.S)
 nr=nr.replace('.macro S2NRoute ',macro7+'\n.macro S2NRoute ',1)
 ui=route('NrUi','X5NativeInventoryUiLeaf','S2NUiCity','SunnyUi','VvUiDispatch','S2MainUi',151,'CmHostUi').replace('S2NRoute ','S2NRoute7 ')
 nr=proc(nr,'NrUi',ui)
 # Preserve the original direct20/21/23 policies. Admit25 only after their
 # successful branches, and share genuine same-bank legacy tails.
 original_nr=(OLD/'overlay/src/new_roster_dispatch.s').read_text()
 for name,legacy,first,second,target in[
 ('NrBody','S2MBody','farcall RcBodyContact,jmp','jmp S2NBodyCity','S2MainBody'),
 ('NrUi','S2MUi','farcall X5NativeInventoryUiLeaf,jmp','jmp S2NUiIce','S2MainUi')]:
  start=original_nr.index('.proc '+name+'\n');end=original_nr.index('.endproc',start)+len('.endproc')
  body=original_nr[start:end]
  if name=='NrBody':
   body=body.replace(' cmp #CHARACTER_ICE_CLIMBERS\n beq Ice',' cmp #CHARACTER_ICE_CLIMBERS\n beq Ice\n cmp #25\n beq Smb',1)
   size=93;tail='S2NBodyLegacy'
  else:
   body=body.replace(' cmp #CHARACTER_RIVER_CITY\n beq City',' cmp #CHARACTER_RIVER_CITY\n beq City\n cmp #25\n beq Smb',1)
   size=151;tail='S2NUiLegacy'
  body=body.replace('farcall '+legacy+',jmp','jmp '+tail).replace(first,second)
  body=body.replace('.endproc','Smb:pla\n plp\n farcall '+target+',jmp\n .res 6,$ff\n .assert *-'+name+'='+str(size)+',lderror,"native policy original slot"\n.endproc')
  nr=re.sub(r'^S2NRoute7? '+name+r',[^\n]+$',lambda _:body,nr,flags=re.M)
 # City helper requires36B; two original adjacent bodies cannot be treated as
 # one free range. Use available UI slot tail via a dedicated macro finish.
 # It follows the table in NrUi, within its original151B entry span.
 marker=' .assert *-Name<=Size,error,'
 more=""" .if .xmatch({Name},{NrUi})
::S2NUiCity:
 farcall X5NativeInventoryUiLeaf
 farcall RcUi,jmp
 .endif
"""
 nr=nr.replace(marker,more+marker)
 # Reuse genuine same-bank tails in original gate slack. This keeps the
 # three native color queue calls in their original order without a new
 # same-bank FarCallCommon frame on Ice/City/Sunny.
 start=nr.index('.proc NrColors\n');end=nr.index('.endproc',start)+len('.endproc')
 color=nr[start:end]
 color=color.replace(' cmp #CHARACTER_SUNNY\n beq Own',' cmp #CHARACTER_SUNNY\n beq Own\n cmp #25\n beq Smb',1)
 color=color.replace('farcall S2MColors,jmp','jmp S2NColorsLegacy').replace('City:farcall RcColors,jmp','City:jmp S2NColorsCity')
 color=color.replace('.endproc','Smb:pla\n plp\n farcall S2MainPalette,jmp\n .res 6,$ff\n .assert *-NrColors=194,lderror,"colors original slot"\n.endproc')
 nr=nr[:start]+color+nr[end:]
 # Two18B tails consume only previously unreachable per-slot padding.
 more2=' .if .xmatch({Name},{NrDeathStart})\n::S2NColorsLegacy:\n farcall X5GetPlayerColors,jmp\n .endif\n .if .xmatch({Name},{NrDeath})\n::S2NColorsCity:\n farcall RcColors,jmp\n .endif\n'
 more2+=''' .if .xmatch({Name},{NrPortrait})
 ; All genuine incoming NrPrepare/Rise/Private calls are tail farcalls.
 ; SafecallA still contains their exact incoming A: no nested call occurred.
 ; The three target routines are genuinely in one page/bank, asserted below.
::S2NPrepareLegacy:
 lda #<JnPrepareDispatch
 bne S2NPickupLegacyCommon
::S2NRiseLegacy:
 lda #<JnRiseDispatch
 bne S2NPickupLegacyCommon
::S2NPrivateLegacy:
 lda #<JnPrivateDispatch
::S2NPickupLegacyCommon:
 sta FarcallJmpTarget_SMC+1
 lda #>JnPrepareDispatch
 sta FarcallJmpTarget_SMC+2
 lda #.bank(JnPrepareDispatch)|$80
 jmp FarCallCommon
 .assert >JnPrepareDispatch=>JnRiseDispatch .and >JnPrepareDispatch=>JnPrivateDispatch,lderror,"pickup actual page"
 .assert .bank(JnPrepareDispatch)=.bank(JnRiseDispatch) .and .bank(JnPrepareDispatch)=.bank(JnPrivateDispatch),lderror,"pickup actual bank"
 .assert <JnPrepareDispatch<>0 .and <JnRiseDispatch<>0,lderror,"genuine unconditional branch"
 .endif
 .if .xmatch({Name},{NrWeapons})
::S2NPrepareOwn:
 farcall S2MainPrepare,jmp
 .endif
 .if .xmatch({Name},{NrInjury})
::S2NNoopOwn:
 ; Exact same incoming-A lease, including the old terminal five-SMC image.
 lda #<S2MainNativeNoop
 sta FarcallJmpTarget_SMC+1
 lda #>S2MainNativeNoop
 sta FarcallJmpTarget_SMC+2
 lda #.bank(S2MainNativeNoop)|$80
 jmp FarCallCommon
 .endif
'''
 nr=nr.replace(marker,more2+marker)
 # Forward SMC operand addresses prevent a first-pass PC-difference .res.
 # Use literal body sizes, retaining a link-time exact-size assertion.
 macros=re.findall(r'\.macro S2NRoute7? .*?\.endmacro',nr,re.S)
 for m in macros:
  base=87 if m.startswith('.macro S2NRoute7 ')else 71
  fill=''
  for i,(name,size)in enumerate([('NrInjury',24),('NrGraphics',18),('NrDraw',18),('NrLegacyInjuryStatus',18),('NrVisible',18),('NrHead',18),('NrUi',36),('NrDeathStart',18),('NrDeath',18),('NrPortrait',23),('NrWeapons',18)]):
   fill+=(' .if 'if i==0 else' .elseif ')+'.xmatch({Name},{'+name+'})\n .res Size-'+str(base+size)+'-24*Explicit,$ff\n'
  fill+=' .else\n .res Size-'+str(base)+'-24*Explicit,$ff\n .endif\n .assert *-Name=Size,lderror,"same-entry original slot"'
  nr=nr.replace(m,m.replace(' .res Size-(*-Name),$ff',fill))
 for name,legacy,tail,size,label in[
 ('NrPrepare','JnPrepareDispatch','S2NPrepareLegacy',74,'Own'),
 ('NrRise','JnRiseDispatch','S2NRiseLegacy',53,'Native'),
 ('NrPrivate','JnPrivateDispatch','S2NPrivateLegacy',53,'Native')]:
  start=nr.index('.proc '+name+'\n');end=nr.index('.endproc',start)+len('.endproc');body=nr[start:end]
  target='Smb'
  body=body.replace(' cmp #CHARACTER_SUNNY\n beq '+label,' cmp #CHARACTER_SUNNY\n beq '+label+'\n cmp #25\n beq '+target,1)
  body=body.replace('farcall '+legacy+',jmp','jmp '+tail)
  suffix='Smb:pla\n plp\n jmp '+('S2NPrepareOwn'if name=='NrPrepare'else'S2NNoopOwn')+'\n'
  padding=6
  body=body.replace('.endproc',suffix+' .res '+str(padding)+',$ff\n .assert *-'+name+'='+str(size)+',lderror,"pickup original slot"\n.endproc')
  nr=nr[:start]+body+nr[end:]
 (ov/'src/new_roster_dispatch.s').write_text(nr+split+flagoff,newline='\n')
 pickup=ov/'src/little_mac_pickups.s'
 text=pickup.read_text()
 for n in ['Prepare','Rise','Private']:text=text.replace('LmGate S2M'+n,'LmGate Nr'+n)
 pickup.write_text(text,newline='\n')
 # Five frequent compatibility wrappers keep the exact original11B public
 # entries, but use direct target literals without needless X/Y stack saves.
 # The original table and all other endpoints remain byte-layout stable.
 gate=(ROOT/'src/smb2_roster_main_gates_v2.s').read_text()
 hot=['S2MGames','S2MBox','S2MEnd','S2MEndStar','S2MImmunity']
 oldhead='.proc Name\n php\n pha\n txa\n pha\n tya\n pha\n ldy #Index\n jmp S2MainGateCommon\n.endproc'
 test=' .if '+ ' .or '.join('.xmatch({Name},{'+n+'})'for n in hot)+'\n jmp .ident(.concat(.string(Name),"Fast"))\n .res 8,$ea\n .else\n'
 gate=gate.replace(oldhead,'.proc Name\n'+test+oldhead.split('\n',1)[1].rsplit('\n.endproc',1)[0]+'\n .endif\n.endproc')
 tail='\n.pushseg\n.segment "KIRBY_ABILITIES"\nS2FastGatesBegin:\n'
 for name in hot:
  m=re.search(r'^S2MainGate '+name+r',(\w+),(\w+),\d+$',gate,re.M);assert m,name
  own_target,legacy=m[1],m[2]
  tail+=f'.proc {name}Fast\n php\n pha\n lda SelectedCharacter\n cmp #25\n beq Own\n pla\n plp\n farcall {legacy},jmp\nOwn:pla\n plp\n farcall {own_target},jmp\n .assert *-{name}Fast=49,lderror,"literal fast gate size"\n.endproc\n'
 tail+='S2FastGatesEnd:\n.assert *<=$c000,lderror,"A74 fast gates exceed existing lease"\n.popseg\n'
 leaf=ROOT/'src/smb2_roster_main_gates_fast_v3.s';leaf.write_text(gate+tail,newline='\n')
 # Keep ALL other v2 semantics and native consumers byte/source identical.
 objects=OUT/'objects';objects.mkdir(exist_ok=True)
 for n in ['entrypoint.s','main.c','asset.s']:(objects/n).write_bytes((OLD/'objects'/n).read_bytes())
 for target in [objects/'entrypoint.s',ov/'src/entrypoint.s']:
  target.write_text(target.read_text().replace('.include "smb2_roster_main_gates_v2.s"','.include "smb2_roster_main_gates_fast_v3.s"'),newline='\n')
 cmd=json.loads((OLD/'build-proof.json').read_text())['command']
 cmd=[v.replace(str(OLD),str(OUT))for v in cmd]
 r=subprocess.run(cmd,cwd=ROOT,capture_output=True,text=True);(OUT/'launcher.txt').write_text(r.stdout+r.stderr)
 if r.returncode:
  q=OUT/'first-link-negative.txt'
  if not q.exists():q.write_text(r.stdout+r.stderr)
  raise AssertionError(r.stderr[-2500:])
 # Same current-final127 regeneration, never stale reclaimed E windows.
 from prepare_cv3_dmc_mirror import prepare
 dest=OUT/'candidate.nes';prepare(ROOT,dest)
 raw=bytearray(dest.read_bytes());fixed=raw[16+127*8192:16+128*8192]
 audio=json.loads((ROOT/'build/smb2-roster-audio-v1/build-proof.json').read_text())if False else None
 source=P.A.S.ROM.read_bytes();plan=json.loads((ROOT/'build/smb2-roster-audio-plan-v1.json').read_text())
 for clone in plan['samples']:
  copy=bytearray(fixed)
  for e in clone['entries']:
   at=int(e['target'],16)-0xe000;p=int(e['source'],16);n=e['bytes']
   blob=source[16+114688+p-0xc000:16+114688+p-0xc000+n]
   assert P.A.digest(blob)==e['sha256'];copy[at:at+n]=blob
  raw[16+clone['bank']*8192:16+(clone['bank']+1)*8192]=copy
 dest.write_bytes(raw)
 proof=dict(status='PRIVATE_ROUTER_DRAFT_NOT_QUALIFIED_NO_NATIVE',candidate=bind(dest),parent_Main=bind(OLD/'candidate.nes'),
 parent_handoff=bind(OLD/'handoff.json'),canonical_parent=h['canonical_parent'],command=cmd,
 new_owned_sources=[bind(ov/'src/new_roster_dispatch.s'),bind(pickup),bind(leaf)],new_RAM=False,new_menu=False,NMI_audio_scheduling=False,tool=bind(__file__))
 (OUT/'build-proof.json').write_text(json.dumps(proof,indent=2)+'\n')
 print(json.dumps(dict(candidate=bind(dest),proof=bind(OUT/'build-proof.json')),indent=2))

if __name__=='__main__':main()
