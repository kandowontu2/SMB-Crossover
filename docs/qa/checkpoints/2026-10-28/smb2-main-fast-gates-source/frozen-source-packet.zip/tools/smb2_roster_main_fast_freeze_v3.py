"""Freeze one private same-entry router successor; no native/adoption claim."""
from pathlib import Path
import collections,difflib,json,re,subprocess,sys
import prepare_smb2_roster_main_fast_v3 as B
import smb2_roster_main_controls_v2
import smb2_roster_main_callers_v2
from check_tmnt_render_oa import address,location
from link_pit_rygar_sophia_audit_cpu import scoped_load
R=B.ROOT;O=B.OUT;bind=B.bind

def main():
    _,parent=B.P.A.Rel.check_parent()
    build=json.loads((O/'build-proof.json').read_text())
    assert bind(O/'candidate.nes')==build['candidate'] and bind(B.__file__)==build['tool']
    for f in ['main-controls.json','caller-controls.json']:
        j=json.loads((O/f).read_text());assert j['passed']and j['candidate']==build['candidate']
        assert bind(j['runner_wrapper']['path'])==j['runner_wrapper']
        for row in build['new_owned_sources']:assert bind(row['path'])==row
    old,new=map(scoped_load,[B.OLD/'candidate.nes',O/'candidate.nes'])
    a,z=old['raw'],new['raw'];assert a[:16]==z[:16]and a[16+1048576:]==z[16+1048576:]
    by=collections.Counter((i-16)//8192 for i,(x,y)in enumerate(zip(a,z))if x!=y)
    assert set(by)=={74,93,124}and by[93]==9,by
    public=[]
    for n,s in old['syms'].items():
        if s.get('scope')!='1'or s.get('type')!='lab'or'seg'not in s:continue
        if n!=s['name'].strip('"')or int(s['val'],0)<0x8000:continue
        assert n in new['syms'],('global symbol missing',n)
        assert(address(old,n),location(old,n))==(address(new,n),location(new,n)),('global symbol moved',n)
        public.append(n)
    assert address(new,'S2MainGatesEnd')==0xbeee
    assert address(new,'S2FastGatesBegin')==0xbeee and address(new,'S2FastGatesEnd')==0xbfe3
    # Explicit protected storage/public capsule checks, independent of diff count.
    for bank,lo,hi in [(124,0xd9b,0x2000),(127,0,0x2000),(126,0,0x2000),
                       (74,0x1180,0x1c81),(118,0,0x2000)]:
        off=16+bank*8192;assert a[off+lo:off+hi]==z[off+lo:off+hi],(bank,lo,hi)
    command=parent['command'].copy()
    command[command.index('--create-full-dep')+1]=str(O/'source-closure.d')
    command[command.index('-o')+1]=str(O/'source-closure.o');command[-1]=str(O/'objects/entrypoint.s')
    command[4:4]=['-I',str(O/'overlay/src')]
    p=subprocess.run(command,cwd=R,capture_output=True,text=True)
    (O/'source-closure-launcher.txt').write_text(p.stdout+p.stderr);assert not p.returncode,p.stderr[-2000:]
    line=(O/'source-closure.d').read_text().splitlines()[0].split(':\t',1)[1]
    deps={Path(x.replace('\\ ',' ')).resolve()for x in re.split(r'(?<!\\)\s+',line.strip())}
    for p in(O/'overlay/src').glob('*.s'):
        if p.name!='entrypoint.s':assert p.resolve()in deps,('overlay not consumed',p)
    for row in build['new_owned_sources']:assert Path(row['path']).resolve()in deps
    refs=[]
    for p in(R/'src').glob('*.s'):
        if p.name.startswith('smb2_roster_main_gates'):continue
        for i,line in enumerate(p.read_text().splitlines(),1):
            if re.search(r'\bNr(?:Prepare|Rise|Private)\b',line)and not line.lstrip().startswith(';'):
                refs.append(dict(path=str(p),line=i,text=line))
    # Current real incoming references are LmGate's restored-A tail farcalls;
    # no new direct callable alias assumes an uninitialized SafecallA operand.
    incoming=[x for x in refs if not x['text'].lstrip().startswith('.proc')]
    assert len(incoming)==3 and all('LmGate 'in x['text']for x in incoming),incoming
    ordinary=[]
    for mode in ['mmc3','mmc5']:
        out=O/('flagoff-'+mode+'.nes')
        cmd=[sys.executable,str(R/'tools/build_mmc5_expanded.py'),'--source-overlay',str(O/'overlay'),
             '--output',str(out),'--flag-off',mode]
        p=subprocess.run(cmd,cwd=R,capture_output=True,text=True)
        (O/('flagoff-'+mode+'-launcher.txt')).write_text(p.stdout+p.stderr);assert not p.returncode,p.stderr[-2000:]
        ref=B.OLD/('flagoff-'+mode+'.nes');assert out.read_bytes()==ref.read_bytes()
        ordinary.append(dict(mapper=mode,actual=bind(out),reference=bind(ref)))
    patch=''
    for p in sorted((O/'overlay/src').glob('*.s')):
        base=B.OLD/'overlay/src'/p.name
        if p.read_bytes()!=base.read_bytes():
            patch+=''.join(difflib.unified_diff(base.read_text().splitlines(True),p.read_text().splitlines(True),
              fromfile='v2-overlay/src/'+p.name,tofile='v3-overlay/src/'+p.name))
    leaf=R/'src/smb2_roster_main_gates_fast_v3.s'
    patch+=''.join(difflib.unified_diff((R/'src/smb2_roster_main_gates_v2.s').read_text().splitlines(True),
      leaf.read_text().splitlines(True),fromfile='a/src/smb2_roster_main_gates_v2.s',tofile='b/src/smb2_roster_main_gates_fast_v3.s'))
    (O/'implementation.patch').write_text(patch,newline='\n')
    callers=json.loads((O/'caller-controls.json').read_text())
    v2=json.loads((B.OLD/'caller-controls.json').read_text())
    costs={}
    for name in ['foreign_Main_rows','foreign_rising_Main_rows']:
        before=v2[name];after=callers[name];assert len(before)==len(after)
        for x,y in zip(before,after):assert {k:v for k,v in x.items()if not k.startswith('cycles')and k!='changed_dead_stack_bytes'}=={k:v for k,v in y.items()if not k.startswith('cycles')and k!='changed_dead_stack_bytes'}
        old_delta=[v['cycles_new']-v['cycles_old']for v in before]
        delta=[v['cycles_new']-v['cycles_old']for v in after]
        saves=[x['cycles_new']-y['cycles_new']for x,y in zip(before,after)]
        costs[name]=dict(cases=len(after),v2_overhead=[min(old_delta),max(old_delta)],v3_overhead=[min(delta),max(delta)],savings=[min(saves),max(saves)])
    owned=callers['supplemental']['owned_complete_Main']
    costs['owned_Main']=dict(cases=len(owned),v2=[min(v['cycles_v2']for v in owned),max(v['cycles_v2']for v in owned)],
      v3=[min(v['cycles_v3']for v in owned),max(v['cycles_v3']for v in owned)],
      savings=[min(v['cycles_v2']-v['cycles_v3']for v in owned),max(v['cycles_v2']-v['cycles_v3']for v in owned)])
    inputs=deps|{Path(sys.executable),O/'objects/asset.s',O/'overlay/smb1base-mmc5-expanded.cfg',
      Path(B.__file__),Path(__file__),R/'tools/smb2_roster_main_fast_controls_v3.py'}
    for m in sys.modules.values():
        p=getattr(m,'__file__',None)
        if p:
            p=Path(p).resolve()
            if p.suffix=='.py'and(p.is_relative_to(R)or'py65'in p.parts):inputs.add(p)
    for k in parent['bindings']:
        p=Path(k)
        if p.suffix.lower()in['.exe','.ini','.cfg']:inputs.add(p)
    for p in Path(sys.executable).parent.glob('python3*.dll'):inputs.add(p)
    library=R/'tools/Windows/cc65/lib/nes.lib'
    if library.exists():inputs.add(library)
    source=dict(passed=True,source_only=True,native=False,candidate=build['candidate'],parent=build['parent_Main'],
      actual_changed_PRG_bytes=dict(by),public_global_symbol_count=len(public),all_original_global_PCs_locations_exact=True,
      protected_resident_audio_CORE118_Rogue_bytes_exact=True,CHR_header_RAM_layout_unchanged=True,
      actual_ASM_dependencies=len(deps),command=command,ordinary=ordinary,actual_pickup_references=refs,
      costs=costs,input_bindings=[bind(p)for p in sorted(inputs)],tool=bind(__file__))
    (O/'source-closure.json').write_text(json.dumps(source,indent=2)+'\n')
    owned_files=[Path(B.__file__),Path(__file__),R/'tools/smb2_roster_main_fast_controls_v3.py',leaf,
      R/'docs/qa/smb2-roster-main-fast-source-2026-10-29.txt',O/'implementation.patch']
    owned_files+=list((O/'overlay/src').glob('*.s'))+[O/'overlay/smb1base-mmc5-expanded.cfg']
    outputs=[p for p in O.iterdir()if p.is_file()and p.name!='handoff.json']+list((O/'objects').glob('*'))
    handoff=dict(status='HELD_PRIVATE_SAME_ENTRY_MAIN_SOURCE_CPU_NO_NATIVE_NO_MENU_ADMISSION',candidate=build['candidate'],
      parent=build['parent_Main'],parent_handoff=build['parent_handoff'],source=bind(O/'source-closure.json'),
      Main=bind(O/'main-controls.json'),callers_IRQ=bind(O/'caller-controls.json'),costs=costs,
      owned_files=[bind(p)for p in sorted(set(owned_files))],input_bindings=source['input_bindings'],
      output_bindings=[bind(p)for p in sorted(set(outputs))],
      open=['Remaining foreign Main mapper overhead still material; no native cadence claim',
        'Actual held native-enemy room transfer, menu/lives/UI/cheat admission, P1 eye/vegetable palette adaptation',
        'Real NmiClock scheduling, atomic Main-to-audio publication/mixer/DMC lifecycle',
        'Native cold-start/render/PPU/audio/gameplay qualification and final shared composition'])
    dest=O/'handoff.json';dest.write_text(json.dumps(handoff,indent=2)+'\n')
    print(json.dumps(dict(handoff=bind(dest),public_globals=len(public),ASMdeps=len(deps),inputs=len(inputs),costs=costs),indent=2))

if __name__=='__main__':main()
