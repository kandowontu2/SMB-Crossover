"""Separate earned-drop successor; immutable1b97 stays read-only."""
from pathlib import Path
import argparse,hashlib,json,re,sys,subprocess
R=Path(__file__).resolve().parents[1];sys.path[:0]=[str(R/'tools'),str(R/'tools/audit')]
import dragon_power_reference_v1 as Original
from sunny_integrated_controls_v1 import scoped_load,address,location,sha
P=R/'build/dragon-power-hud-budget-v1';O=R/'build/dragon-power-drops-v1'
def flip(p):
 return bytes(int(f'{v:08b}'[::-1],2)for v in p)
def canonical(p):
 h=flip(p);return (h,64)if h<p else(p,0)
def original_item(kind,state):
 m=Original.Memory(3);m.ram[0x23]=4;m.ram[0x628]=kind;m.ram[0x632]=state;m.ram[0x600]=80;m.ram[0x614]=80
 z=Original.call(m,0xb697);oam=bytes(m.ram[0x704:0x700+m[0x23]])
 assert oam and len(oam)%4==0 and len(oam)<=32,(kind,state,oam.hex())
 chrdata=Original.D.raw()[16+131072+3*8192:16+131072+4*8192];parts=[];pixels={}
 for at in range(0,len(oam),4):
  y,t,a,x=oam[at:at+4];assert a&3 in[2,3]
  tile=chrdata[t*16:t*16+16];pattern=bytearray(32)
  for yy in range(8):
   sy=7-yy if a&128 else yy
   for xx in range(8):
    sx=7-xx if a&64 else xx;v=(tile[sy]>>(7-sx)&1)|((tile[sy+8]>>(7-sx)&1)<<1)
    v=([0,1,2,3]if a&3==2 else[0,1,1,3])[v]
    pattern[yy]|=(v&1)<<(7-xx);pattern[yy+8]|=(v>>1)<<(7-xx)
    if v:pixels.setdefault((x-80+xx,y+1-80+yy),v)
  p,attr=canonical(bytes(pattern));parts.append((p,attr,y-80,x-80))
 # Native host renderer consumes descriptors backward: reverse the source
 # parts so actual physical priority remains original OAM order.
 return list(reversed(parts)),dict(kind=kind,state=state,original_OAM=oam.hex(),source_CPU=z['cycles'],pixels_SHA256=hashlib.sha256(repr(sorted(pixels.items())).encode()).hexdigest())
def art():
 assert sha(P/'candidate.nes')=='1b97a99f1056808b99ac978aded95fe132d0e84209156a4ed909f80513f717e4'
 b=scoped_load(P/'candidate.nes');raw=b['raw'];body=[]
 for i in range(66):
  ptr=raw[location(b,'DpPoseLo')+i]|raw[location(b,'DpPoseHi')+i]<<8;page=raw[location(b,'DpPosePage')+i]
  at=16+85*8192+ptr-0xc000;d=raw[at:at+raw[at]+1];row=[]
  for k in range(1,len(d),4):
   t,a,y,x=d[k:k+4];assert a==0
   pattern=raw[1048592+(788+page)*1024+t*16:1048592+(788+page)*1024+t*16+32]
   p,attr=canonical(pattern);row.append((p,attr,y if y<128 else y-256,x if x<128 else x-256))
  body.append(row)
 specs=[(0x8a,0),(0x83,0),(0x83,1),(0x83,2),(0x84,0),(0x85,0),(0x86,0),(0x86,1)]+[(0x80,i)for i in range(1,5)]
 items=[original_item(k,s)for k,s in specs]
 # Original decoder emits later OAM parts first on priority; preserve actual
 # source ordering. Every item and wave pattern coexists on every body page.
 common=sorted({p for row in body[64:]for p,a,y,x in row}|{p for row,f in items for p,a,y,x in row})
 pages=[];encoded=[];indices=[];unique={}
 for row in body:
  need=set(p for p,a,y,x in row)|set(common)
  choices=[(len(need-set(v)),j)for j,v in enumerate(pages)if len(need|set(v))<=32]
  if not choices:pages.append(list(common));page=len(pages)-1
  else:page=min(choices)[1]
  for p in sorted(need):
   if p not in pages[page]:pages[page].append(p)
  data=[]
  for p,a,y,x in row:data.extend([pages[page].index(p)*2,a,y&255,x&255])
  key=(page,tuple(data))
  if key not in unique:unique[key]=len(encoded);encoded.append([len(data)]+data)
  indices.append(unique[key])
 facts=dict(source_ROM=Original.D.binding(Original.D.ROM),parent=sha(P/'candidate.nes'),common_pairs=len(common),pairs=[len(p)for p in pages],pages=len(pages),body_records=66,items=[f for row,f in items],item_source_palette_quantization='same parent P2identity,P3index2->1; P0 only',lossless_Hflip_canonicalization=True)
 (O/'art-fit.json').write_text(json.dumps(facts,indent=2)+'\n')
 assert len(pages)<=8,('simultaneous source-pattern fit exceeds8KB',facts['pairs'],len(common))
 lines=['; Private source pixels: body+wave+earned items simultaneously in window0.','.pushseg','.segment "DRAGON_POWER_ART"','DpArtStart:']
 for name,values in [('DpPoseLo',[f'<DpArt{v}'for v in indices]),('DpPoseHi',[f'>DpArt{v}'for v in indices])]:
  lines.extend([name+':',' .byte '+','.join(values)])
 # Actual selected page follows each record, not an alias or disjoint page.
 keys=list(unique);posepages=[keys[n][0]for n in indices]
 lines.extend(['DpPosePage:',' .byte '+','.join(map(str,posepages)),'DpPaletteRoles:',' .byte $36,$26,$0f,$36,$26,$0f'])
 for i,data in enumerate(encoded):lines.extend([f'DpArt{i}:',' .byte '+','.join(f'${v:02x}'for v in data)])
 lines.extend(['DpArtEnd:','.assert DpArtEnd<=$cdf0,error,"Source item repack preserves frozen gameplay start"','.export DpArtStart,DpPoseLo,DpPoseHi,DpPosePage,DpPaletteRoles','.popseg'])
 itemlines=['; Genuine original item render records; shared common indices on every body page.']
 itemrecords=[]
 for i,(row,f)in enumerate(items):
  data=[]
  for p,a,y,x in row:data.extend([common.index(p)*2,a,y&255,x&255])
  itemrecords.append(data);itemlines.extend([f'DpDropArt{i}:',' .byte '+','.join(f'${v:02x}'for v in[len(data)]+data)])
 chrdata=b''.join(b''.join(p)+bytes(1024-len(p)*32)for p in pages);chrdata+=bytes(8192-len(chrdata))
 (O/'drops.chr').write_bytes(chrdata)
 lines.extend(['.pushseg','.segment "DRAGON_POWER_CHR"',f'.incbin "{(O/"drops.chr").as_posix()}"','.popseg'])
 (O/'art.inc').write_text('\n'.join(lines)+'\n');(O/'item-art.inc').write_text('\n'.join(itemlines)+'\n')
 return facts
def build():
 assert bytes.fromhex(re.search(r'Kinds:\.byte([^\n]+)',(O/'drops.inc').read_text())[1].replace('$','').replace(',',''))==Original.D.memory(0)[0x8d9f:0x8dbf]
 (O/'src').mkdir(exist_ok=True)
 for p in(P/'src').iterdir():
  if p.is_file():(O/'src'/p.name).write_bytes(p.read_bytes())
 for name in['main.c','smb1base-mmc5-expanded.cfg','entrypoint.s']:(O/name).write_bytes((P/name).read_bytes())
 c=(P/'cold.inc').read_text();assert c.count(' jmp DpBudgetDispatch\n')==1
 (O/'cold.inc').write_text(c.replace(' jmp DpBudgetDispatch\n',' jmp DpDropsDispatch\n'))
 core=(P/'core.inc').read_text().replace('DpAdmissionEnd:','''.proc DpDropsDrawStub
 lda #9
 jmp DpAdmissionC
.endproc
DpAdmissionEnd:''')
 (O/'core.inc').write_text(core)
 game=(R/'build/dragon_power_gameplay_core_v1.inc').read_text();assert game.count(' jsr DpDrawBody\n')==1
 (O/'gameplay-core.inc').write_text(game.replace(' jsr DpDrawBody\n',' jsr DpDropsDrawStub\n'))
 game=(R/'build/dragon-power-admission-v1/gameplay-c.inc').read_text()
 assert game.count('.proc DpGameTick\n lda DpAction')==1 and game.count(' jsr ShellOrBlockDefeat')==1
 game=game.replace('.proc DpGameTick\n lda DpAction','.proc DpGameTick\n jmp DpDropsTick').replace(' jsr ShellOrBlockDefeat',' jsr DpDropsDefeat')
 (O/'gameplay-c.inc').write_text(game)
 comp=(P/'component.s').read_text()
 for old,new in [('build/dragon_power_gameplay_core_v1.inc','build/dragon-power-drops-v1/gameplay-core.inc'),('build/dragon-power-admission-v1/gameplay-c.inc','build/dragon-power-drops-v1/gameplay-c.inc'),('build/dragon-power-admission-v1/art.inc','build/dragon-power-drops-v1/art.inc'),('build/dragon-power-hud-budget-v1/core.inc','build/dragon-power-drops-v1/core.inc'),('build/dragon-power-hud-budget-v1/cold.inc','build/dragon-power-drops-v1/cold.inc')]:
  assert comp.count(old)==1,old;comp=comp.replace(old,new)
 fields='AvDropItem InvDropKind InvDropX InvDropPage InvDropY InvDropVY InvDropVYMid InvDropVYHi InvDropFraction InvDropFractionHi InvDropAge InvDropAgeHi InvDropSlot InvDrawSlot InvRandom DigitModifier AddToScore'.split()
 b=scoped_load(P/'candidate.nes');entry=(O/'entrypoint.s').read_text()
 for n in fields:
  if not re.search(r'^\.import(?:zp)? '+n+r'$',comp,re.M):comp=('.importzp 'if address(b,n)<256 else'.import ')+n+'\n'+comp
  entry+='\n.export '+n
 comp+='\n.include "build/dragon-power-drops-v1/drops.inc"\n'
 (O/'component.s').write_text(comp);(O/'entrypoint.s').write_text(entry+'\n')
 cmd=[v.replace(str(P),str(O))for v in json.loads((P/'build-proof.json').read_text())['command']]
 z=subprocess.run(cmd,cwd=R,capture_output=True,text=True);(O/'build.log').write_text(z.stdout+z.stderr)
 if z.returncode:
  print(z.stderr);raise AssertionError('Private sparse assembly failed; original artifacts unchanged')
 from prepare_cv3_dmc_mirror import prepare
 prepare(R,O/'candidate.nes')
 now=scoped_load(O/'candidate.nes');raw=b['raw'];new=now['raw']
 banks={k:sum(x!=y for x,y in zip(raw[16+k*8192:16+(k+1)*8192],new[16+k*8192:16+(k+1)*8192]))for k in range(128)}
 proof=dict(assembled=True,qualified=False,native_run=False,candidate=sha(O/'candidate.nes'),DBG=sha(O/'candidate.dbg'),LBL=sha(O/'candidate.lbl'),command=cmd,changed_banks={k:v for k,v in banks.items()if v},CORE_end=hex(address(now,'DpAdmissionEnd')),drops_start=hex(address(now,'DpDropsStart')),drops_end=hex(address(now,'DpDropsEnd')),timed84_sideview_policy_HELD=True)
 (O/'build-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(proof))
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--art-only',action='store_true');a=ap.parse_args()
 assert not(O/'handoff.json').exists();O.mkdir(exist_ok=True)
 facts=art();print(json.dumps(facts))
 if not a.art_only:build()
if __name__=='__main__':main()
