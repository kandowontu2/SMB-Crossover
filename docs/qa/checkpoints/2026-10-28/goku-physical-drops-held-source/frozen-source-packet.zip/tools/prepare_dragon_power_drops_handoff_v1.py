"""Freeze the finite private drop experiment with explicit unsupported policies."""
from pathlib import Path
import difflib,json,re,subprocess,sys
R=Path(__file__).resolve().parents[1];sys.path[:0]=[str(R/'tools'),str(R/'tools/audit')]
from sunny_integrated_controls_v1 import sha,scoped_load,address
import dragon_power_drops_controls_v1 as T
O=T.O;P=T.P

def main():
 assert not(O/'handoff.json').exists()
 receipt=json.loads((O/'controls-final.json').read_text());assert receipt['passed']
 for p,h in receipt['bindings'].items():assert sha(p)==h,p
 cmds=[];deps={}
 for cmd in json.loads((P/'closure.json').read_text())['checks']['actual_ASM_dependency_closure']['commands']:
  cmd=[s.replace(str(P),str(O))for s in cmd]
  z=subprocess.run(cmd,cwd=R,capture_output=True,text=True);assert not z.returncode,z.stderr;cmds.append(cmd)
 from prepare_cv3_dmc_mirror import prepare
 prepare(R,O/'independent.nes');assert sha(O/'independent.nes')==sha(O/'candidate.nes')
 for file in[O/'main-final.d',O/'component-final.d']:
  for word in re.split(r'(?<!\\)\s+',file.read_text().split(':\t',1)[1].strip().removesuffix(':')):
   p=Path(word.replace('\\ ',' '));p=(p if p.is_absolute()else R/p).resolve();assert p.is_file();deps[str(p)]=sha(p)
 old,b=[scoped_load(p/'candidate.nes')for p in[P,O]]
 moved=[]
 for name in old['syms']:
  if name.startswith('Dp')and'::'not in name and name in b['syms']and address(old,name)!=address(b,name):moved.append([name,address(old,name),address(b,name)])
 assert {n for n,a,z in moved}<={'DpAdmissionEnd'},moved
 a=old['raw'];z=b['raw'];assert a[:16]==z[:16]
 assert all(a[16+k*8192:16+(k+1)*8192]==z[16+k*8192:16+(k+1)*8192]for k in range(128)if k not in[85,86])
 assert a[1048592:1048592+788*1024]==z[1048592:1048592+788*1024]
 assert a[1048592+795*1024:]==z[1048592+795*1024:]
 patches=[]
 for name in['core.inc','cold.inc']:
  patches.extend(difflib.unified_diff((P/name).read_text().splitlines(True),(O/name).read_text().splitlines(True),fromfile='parent/'+name,tofile='drops/'+name))
 (O/'source.patch').write_text(''.join(patches))
 closure=dict(passed=True,actual_ASM_dependencies=deps,commands=cmds,independent_link_exact=True,old_public_PCs_exact_except_genuine_end=moved,PRG_only_85_86=True,CHR_only_788_794=True,ordinary_fresh_not_run=True)
 (O/'closure.json').write_text(json.dumps(closure,indent=2)+'\n')
 report=R/'docs/qa/dragon-power-drops-held-2026-10-29.txt'
 report.write_text('''PRIVATE EARNED PHYSICAL DROP EXPERIMENT — HELD, NOT NATIVE READY.
Parent1b97 is immutable. This unit preserves the exact original32-byte kind order and LCG after the explicitly authored first-room SMB paid-defeat admission (source clock<=100, active live raw24, admitted ordinary native species; excludes8/12/>=15). It is NOT an original universal kill probability: source terrain/script/room thresholds differ from the authored SMB mapping. Four native drop slots replace the original nine-slot capacity; full pool still advances selector and declines without reward.
Actual paid terminal executes native ShellOrBlockDefeat once, initializes a slot and publishes AvDropItem last. InvDropKind stays0 so generic collectors/renderers cannot grant or duplicate it. Original24+64 popup wait, physical container contact,32-update reveal and next-update mature collection are distinct. Source food20/100 caps150 or explicit source250 upgrade; plain-wave3/cap60 preserves advanced kind; polebit1 and genuine random10/20/50/100 point grants use actual native score arithmetic through a real A3 lease. No remote automatic HP/resource grants. Original food hunger reset and source collection cue5F retained; audio scheduler remains outside this unit.
HOLD1: outcome84 retains its exact collector state bit10/seconds16 and50point reward, but the ported side-view kernel has no proved source speed/expiry consumer. Do not call that a working timed powerup, substitute another item, renormalize its5/32 bins or admit this build as complete.
HOLD2: contact reveal/collection is implemented; original pole/attack-mediated item interception is not. Authored enemy species/scene analogues are explicit, not source species equivalence. No block-reveal mapping, all-room eligibility, natural source drop rates or full native campaign is qualified.
PIXELS: original0/3 item renderer records provide12 container/item/score frames. All66 body/wave records and all12 item records coexist on every selected body page after lossless H-flip deduplication:7KB of the approved8KB,17 common pairs, page occupancies31/32/31/29/25/29/27. Original opaque geometry/HV/OAM priority is preserved with the parent's explicitly approved P0 color-class adaptation; no physical world/effect CHR windows1..3 are stolen. CHR795 is unused. Native visual/color fidelity still needs ROOT review.
CONCRETE NEGATIVES: first grouped table had correct counts but80 wrong seed outcomes; exact original order now tested. Initial items-before-body layout let genuine no-draw Vine overwrite24 body bytes; body is now first, new world items afterward, and64 real retained-body/Vine turns pass. Native partial writers may still replace item/world planes; whole-page ownership and per-item fairness are not promised. The first direct AddToScore JSR used physicalA86 instead of actualA3:B815 and failed real score credit; genuine A3 farcall replaces it. Branch-range rejection and the PC-only no-draw oracle alias are retained; final controls compare genuine bank+PC.
SOURCE CONTROLS:256 exact seed outcomes/native defeat;288 actual collector cap/stock/score boundaries;512 actual body/item capacity/ring cases;64 real DrawAll->no-draw Main->Vine body-retention turns;64 foreign complete Main AXYP/SP/application/live stack/finalbanks/5SMC/CPU exact;476 actual reached new-service IRQ/lagNMI seams minSP202. All66 body/wave and84 item/page decoded records pass. Two actual complete Main input campaigns physically earn food through unseeded paid punches: defeat74, container162, reveal195, pickup196 +20HP. Typed enemy/map staging is disclosed; this is CPU execution, not native acquisition.
FINITE COST: the measured typed complete Main is21750CPU parent;22446 with no items(+696),23324 with one(+1574),25960 with four(+4210); minSP211. Costs include real draw/update/routing and are material; no lag/FPS improvement or universal frame-budget claim. Existing native1b97 route remains finite7000-frame pipe-controller stop; fb28 frame2654 product deadline failure remains unchanged historical evidence.
LAYOUT: CORE endsBFFA, cold drop service D33A..<D7EF (1205B), within approved85:D100..<D900. Header/fixed clones/all other PRG/CHR outside788..794 exact to1b97. Actual ca65 dependency closure and independent link reproduce8c000072586f0e71a3578324442c1e4ed2a717d5bfceeb50d1d4aaf9b5376266. Fresh ordinary builds were not rerun for this held unit. No shared/source/default/Downloads/settings/native/Git changes. The approved one-platform traversal successor is explicitly independent1b97, not this held experiment.
''')
 files={Path(p)for p in deps}|set(O.glob('*.inc'))|set(O.glob('*negative*'))|{O/'candidate.nes',O/'candidate.dbg',O/'candidate.lbl',O/'candidate.map',O/'drops.chr',O/'art-fit.json',O/'build-proof.json',O/'build-proof-first.json',O/'controls-first.json',O/'controls-first.py',O/'controls-second.json',O/'controls-third.json',O/'controls-final.json',O/'closure.json',O/'source.patch',report,Path(__file__),R/'tools/prepare_dragon_power_drops_v1.py',Path(T.__file__),P/'handoff.json',P/'candidate.nes',P/'candidate.dbg'}
 for p in receipt['bindings']:files.add(Path(p))
 hand=dict(status='FROZEN_PRIVATE_DROPS_HELD_TIMED84_AND_ATTACK_REVEAL',native_ready=False,native_run=False,parent=sha(P/'candidate.nes'),candidate=sha(O/'candidate.nes'),DBG=sha(O/'candidate.dbg'),LBL=sha(O/'candidate.lbl'),report=str(report),actual_ASM_dependencies=deps,bindings={str(p.resolve()):sha(p)for p in sorted(files)if p.is_file()},limits=report.read_text())
 for p,h in hand['bindings'].items():assert sha(p)==h,p
 (O/'handoff.json').write_text(json.dumps(hand,indent=2)+'\n');print(json.dumps(dict(handoff=sha(O/'handoff.json'),candidate=hand['candidate'],bindings=len(hand['bindings']),ASM_dependencies=len(deps),report=sha(report))))
if __name__=='__main__':main()
