"""Finite private drop implementation controls; explicit84 HOLD, no native."""
from pathlib import Path
import argparse,itertools,json,sys,traceback
R=Path(__file__).resolve().parents[2];sys.path[:0]=[str(R/'tools/audit'),str(R/'tools')]
import dragon_power_gameplay_controls_v1 as C
import dragon_power_gameplay_render_v3 as D
import dragon_power_gameplay_isr_v1 as ISR
import dragon_power_reference_v1 as Original
from sunny_integrated_controls_v1 import *
P=R/'build/dragon-power-hud-budget-v1';O=R/'build/dragon-power-drops-v1'
def pixels(b,index):
 raw=b['raw'];page=raw[location(b,'DpPosePage')+index];ptr=raw[location(b,'DpPoseLo')+index]|raw[location(b,'DpPoseHi')+index]<<8
 at=16+85*8192+ptr-0xc000;d=raw[at:at+raw[at]+1];px={}
 for i in range(1,len(d),4):
  t,a,y,x=d[i:i+4];x=x if x<128 else x-256;y=(y if y<128 else y-256)+1
  pattern=raw[1048592+(788+page)*1024+t*16:1048592+(788+page)*1024+t*16+32]
  # Later descriptors are higher physical priority: process low priority first.
  for yy in range(16):
   sy=15-yy if a&128 else yy;at2=sy//8*16+sy%8
   for xx in range(8):
    sx=7-xx if a&64 else xx;v=(pattern[at2]>>(7-sx)&1)|((pattern[at2+8]>>(7-sx)&1)<<1)
    if v:px[x+xx,y+yy]=(v,a&3)
 return px,len(d)-1
def setup(b):
 q=C.setup(b);run(q,'DpEnsure');run(q,'DpHostSync');q.set('InvRandom',0);return q
def boundary(b,seed=0):
 q=setup(b);C.actor(q,0,6,114,176);q.put(DpPose=6,DpAction=4,DpClock=1,InvRandom=seed);q.set('MmEnemyHealthLo',1,0)
 q.m.page(1,86);q.set('CurrentBank',214);return q
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--output',type=Path,required=True);a=ap.parse_args();assert not a.output.exists()
 old,b=[scoped_load(p/'candidate.nes')for p in[P,O]];proof=dict(passed=False,source_CPU_only=True,native_run=False,timed84_HELD=True,checks={});ck=proof['checks']
 try:
  for i in range(66):assert pixels(old,i)==pixels(b,i),('source body/wave pixel geometry changed',i)
  ck['all_body_wave_decoded_pixels']=dict(records=66,both_faces=True,original_opaque_geometry_palette_classes_exact=True)
  original_kinds=Original.D.memory(0)[0x8d9f:0x8dbf]
  assert b['raw'][location(b,'DpDropsSpawn::Kinds'):location(b,'DpDropsSpawn::Kinds')+32]==original_kinds
  rows=[]
  for seed in range(256):
   q=boundary(b,seed);c,tr,mn=C.M.runtrace(q,'DpGameCombat',a=91,x=0,y=66,p=0x71)
   slots=[i for i in range(4)if q.get('AvDropItem',i)]
   assert slots==[3],('no real paid spawn',seed,slots,q.get('Enemy_State',0),q.get('MmEnemyHealthLo',0))
   expected=((seed*5+17)&255);assert q.get('InvRandom')==expected
   assert q.get('AvDropItem',3)==original_kinds[expected>>3],('exact original seed outcome',seed)
   assert q.get('InvDropKind',3)==0 and q.get('InvDropX',3)==122 and q.get('InvDropY',3)==192
   assert q.get('InvDropAge',3)==88 and q.get('InvDropAgeHi',3)==0
   assert tr.count((126,address(b,'ShellOrBlockDefeat')))==1
   assert q.get('Enemy_State',0)&32 and q.get('FloateyNum_Control',0)==1
   rows.append([seed,q.get('AvDropItem',3),c.processorCycles,mn])
  ck['actual_paid_terminal_native_defeat_and_source_selector']=dict(cases=256,rows=rows,one_real_native_defeat_score=True,original_LCG=True,no_immediate_food_credit=True)
  q=boundary(b);c,tr,mn=C.M.runtrace(q,'DpGameCombat');kind=q.get('AvDropItem',3)
  for age in range(88):run(q,'DpDropsUpdate')
  assert q.get('InvDropAgeHi',3)==1 and q.get('DpHP')==100
  q.put(Player_X_Position=122,Player_Y_Position=176)
  run(q,'DpDropsUpdate');assert q.get('InvDropAgeHi',3)==2
  for age in range(32):run(q,'DpDropsUpdate')
  assert q.get('InvDropAgeHi',3)==3 and q.get('InvDropY',3)==172 and q.get('DpHP')==100
  q.set('Player_Y_Position',156);run(q,'DpDropsUpdate');assert q.get('AvDropItem',3)==0 and q.get('DpHP')==120
  ck['physical_source_88_container_32_reveal_then_food']=dict(earned_via_real_native_terminal=True,original_physical_contact=True,no_remote_or_emerging_grant=True,source_mature_Y_minus20=True)
  # Complete real Main, source fresh B and existing native enemy body/score.
  rows=[]
  for mode in[0,1]:
   q=C.setup(b);q.set('CrossoverBehaviorVersion',mode);C.actor(q,0,6,114,176)
   visits=set();spawn=None;grants=[]
   for age in range(320):
    keys=64 if age%18==2 else 0
    if spawn is not None:
     keys=0;delta=q.get('InvDropX',3)-q.get('Player_X_Position')
     if delta>2:keys=1
     elif delta<-2:keys=2
     if q.get('InvDropAgeHi',3)==3 and q.get('DpAction')==1:keys|=128
    q.put(SavedJoypadBits=keys,NmiDisable=255,VRAM_Buffer1_Offset=0)
    hp=q.get('DpHP');c,tr,mn=C.M.runtrace(q,'GameLoop');visits.update(tr)
    if spawn is None and q.get('AvDropItem',3):spawn=age
    if (85,address(b,'DpDropsGrant'))in tr:grants.append([age,hp,q.get('DpHP'),q.get('DpWaves'),q.get('DpPole')])
    if grants:break
   assert spawn is not None and len(grants)==1 and grants[0][2]-grants[0][1]==20,('complete Main physical food',mode,spawn,grants)
   rows.append(dict(mode=mode,spawn=spawn,physical_grants=grants,source_clock=q.get('DpClock'),native_score=q.get('FloateyNum_Control',0),updates=age+1))
  ck['actual_full_Main_source_input_earned_food']=dict(rows=rows,no_health_tier_stock_or_outcome_seeds=True,typed_enemy_and_flat_map_staging=True)
  # Physical item art is decoded from the actual compiled records/CHR, then
  # compared with the actual original renderer's physical sprite priority.
  import prepare_dragon_power_drops_v1 as Art
  rows=[]
  for index,(kind,state)in enumerate([(0x8a,0),(0x83,0),(0x83,1),(0x83,2),(0x84,0),(0x85,0),(0x86,0),(0x86,1)]+[(0x80,i)for i in range(1,5)]):
   parts,facts=Art.original_item(kind,state)
   ptr=address(b,'DpDropArt'+str(index));at=16+85*8192+ptr-0xc000;data=b['raw'][at:at+b['raw'][at]+1]
   expected={};actual={}
   for pattern,attr,yy,xx in parts:
    for y in range(16):
     for x in range(8):
      sx=7-x if attr&64 else x;at2=y//8*16+y%8
      v=(pattern[at2]>>(7-sx)&1)|((pattern[at2+8]>>(7-sx)&1)<<1)
      if v:expected[xx+x,yy+1+y]=v
   for page in range(7):
    actual={}
    for offset in range(1,len(data),4):
     tile,attr,yy,xx=data[offset:offset+4];yy=yy if yy<128 else yy-256;xx=xx if xx<128 else xx-256
     pattern=b['raw'][1048592+(788+page)*1024+tile*16:1048592+(788+page)*1024+tile*16+32]
     for y in range(16):
      for x in range(8):
       sx=7-x if attr&64 else x;at2=y//8*16+y%8
       v=(pattern[at2]>>(7-sx)&1)|((pattern[at2+8]>>(7-sx)&1)<<1)
       if v:actual[xx+x,yy+1+y]=v
    assert actual==expected,('actual simultaneous item pixels',index,page)
   rows.append([kind,state,len(data)-1,facts['pixels_SHA256']])
  ck['original_item_pixels_on_every_body_page']=dict(records=12,pages=7,rows=rows,source_HV_and_priority=True,P0_quantization_explicit=True)
  # Full pool and lifetime/scene/foreign-owner boundaries never grant or
  # retype another owner's drop. They are boundary fixtures, not acquisitions.
  rows=[]
  for condition in ['clock101','paused','timer','dead','foreign','full','foreign_slot']:
   q=boundary(b)
   if condition=='clock101':q.put(DpClock=101)
   if condition=='paused':q.put(GamePauseStatus=1)
   if condition=='timer':q.put(TimerControl=1)
   if condition=='dead':q.put(DpHP=0)
   if condition=='foreign':q.put(SelectedCharacter=23)
   if condition=='full':
    for i in range(4):q.set('AvDropItem',0x83,i)
   if condition=='foreign_slot':q.set('InvDropKind',4,3)
   before=[q.get('AvDropItem',i)for i in range(4)];run(q,'DpGameCombat')
   after=[q.get('AvDropItem',i)for i in range(4)]
   if condition=='foreign_slot':assert after==[0,0,0x83,0]and q.get('InvDropKind',3)==4
   else:assert after==before,(condition,before,after)
   rows.append([condition,q.get('InvRandom'),after])
  for change,survives in [('future_pointer',True),('life_gain',True),('life_loss',False),('scene',False),('world',False)]:
   q=boundary(b);run(q,'DpGameCombat')
   if change=='future_pointer':q.put(AreaPointer=0xc2)
   elif change=='life_gain':q.put(DpLife=q.get('DpLife')+1)
   elif change=='life_loss':q.put(DpLife=q.get('DpLife')-1)
   elif change=='scene':q.put(DpArea=q.get('DpArea')+1)
   else:q.put(DpWorld=q.get('DpWorld')+1)
   run(q,'DpDropsUpdate');assert bool(q.get('AvDropItem',3))==survives,('birth lifecycle',change)
  ck['negative_admission_pool_and_birth_lifecycle']=dict(rows=rows,stable_loaded_scene_not_future_pipe=True,loss_scene_world_retire_gain_preserves=True)
  rows=[]
  for kind in sorted(set(original_kinds)):
   for hp,flags,stock in itertools.product([1,100,149,150,240,250],[0,64],[0,59,60,0x43]):
    q=setup(b);q.put(DpHP=hp,DpFlags=flags,DpWaves=stock,InvDropSlot=3)
    q.set('AvDropItem',kind,3);q.set('InvDropAgeHi',3,3)
    before_score=bytes(q.m[address(b,'PlayerScoreDisplay'):address(b,'PlayerScoreDisplay')+6])
    c,tr,mn=C.M.runtrace(q,'DpDropsGrant')
    if kind in[0x83,0x93]:
     assert q.get('DpHP')==min(250 if flags&64 else 150,hp+(20 if kind==0x83 else 100))
     assert q.get('AvDropItem',3)==0 and q.get('DpHunger')==0
     assert bytes(q.m[address(b,'PlayerScoreDisplay'):address(b,'PlayerScoreDisplay')+6])==before_score
    else:
     index=q.get('InvDropFraction',3);assert index in[1,2,3,4]and q.get('DpHP')==hp
     digits=list(q.m[address(b,'PlayerScoreDisplay'):address(b,'PlayerScoreDisplay')+6]);value=sum(d*10**(5-i)for i,d in enumerate(digits))
     assert value==[1,2,5,10][index-1],('actual native score units',kind,index,digits)
     assert tr.count(((location(b,'AddToScore')-16)//8192,address(b,'AddToScore')))==1
     if kind==0x85:assert q.get('DpPole')&1
     if kind==0x86:assert q.get('DpWaves')==(stock if stock&0xc0 and stock&63 else min(60,(stock&63)+3))
     if kind==0x84:assert q.get('DpFlags')==flags|16 and q.get('DpSeconds')==16
    rows.append([kind,hp,flags,stock,c.processorCycles,mn])
  ck['real_collector_food_cap_stock_pole_score_boundaries']=dict(cases=len(rows),CPU=[min(r[-2]for r in rows),max(r[-2]for r in rows)],timed84_state_only_not_speed_or_expiry=True,boundary_resources_not_earned_native_claim=True)
  rows=[]
  for pose,face,cursor,pivot in itertools.product(range(32),[0,64],[0,192,224,252],[0,252]):
   q=setup(b);q.put(DpPose=pose,DpAttribute=face,CurrentOAMOffset=cursor,GuestOamRotationActive=1,RgOamRotation=pivot,Player_Rel_XPos=96,Player_Y_Position=100)
   for i in range(4):
    q.set('AvDropItem',0x86,i);q.set('InvDropAgeHi',3,i);q.set('InvDropX',96+i*16,i);q.set('InvDropY',140,i)
   run(q,'DpGraphics');c,events,mn,tr=D.draw(q,'DpGameDraw');used=set()
   for e in events:
    if not e['accepted']:assert e['after']==e['before'];continue
    assert e['after']==e['before']+e['header']<=255
    span={(e['before']+i+e['rotation'])&255 for i in range(e['header'])};assert not used&span;used|=span
   rows.append([pose,face,cursor,pivot,len(used),c.processorCycles,mn])
  ck['actual_body_items_capacity_ring']=dict(cases=len(rows),nonoverlap_and_no_wrap=True,CPU=[min(r[-2]for r in rows),max(r[-2]for r in rows)],rows=rows)
  # Actual retained body -> actual no-draw Main -> actual Vine partial writer.
  # Items are after body and can be replaced as world sprites; never claim
  # whole-page/item retention from the bounded native player reservation.
  rows=[]
  for pivot in range(0,256,4):
   q=setup(b);q.put(DpPose=6,Player_Y_Position=100,Player_Rel_YPos=100,RgOamFirst=pivot,RgOamUsed=252,FrameCounter=0)
   for i in range(4):
    q.set('AvDropItem',0x86,i);q.set('InvDropAgeHi',3,i);q.set('InvDropX',96+i*16,i);q.set('InvDropY',140,i)
    q.set('InvDropVY',q.get('DpLife'),i);q.set('InvDropVYMid',q.get('DpArea'),i);q.set('InvDropVYHi',q.get('DpWorld'),i)
   run(q,'DpGraphics');c,events,mn,tr=D.draw(q)
   own=[e for e in events if e['C']==85 and address(b,'DpArtStart')<=e['ptr']<address(b,'DpArtEnd')and e['header']]
   assert own and max(e['after']for e in own)<=64,('bounded native retained body',pivot,own)
   slots=sorted(set((e['before']+i+e['rotation'])&255 for e in own for i in range(e['header'])))
   before=bytes(q.m[0x200:0x300]);C.actor(q,5,0x2f,128,80)
   q.put(Vine_FlagOffset=1,Vine_Height=96,ShouldSkipDrawSprites=1,FramesSinceLastSpriteDraw=0,ObjectOffset=5)
   q.set('Vine_ObjOffset',5,0);c,tr,mn=C.M.runtrace(q,'GameLoop')
   vine=((location(b,'VineObjectHandler')-16)//8192,address(b,'VineObjectHandler'))
   drawall=((location(b,'DrawAllMetasprites')-16)//8192,address(b,'DrawAllMetasprites'))
   assert vine in tr and drawall not in tr,('actual physical Vine/no-draw',pivot,vine,drawall)
   assert all(q.m[0x200+i]==before[i]for i in slots),('Vine retained body',pivot)
   rows.append([pivot,len(slots),c.processorCycles,mn])
  ck['four_items_actual_DrawAll_Vine_retained_body']=dict(cases=len(rows),rows=rows,world_item_partial_replacement_not_claimed_safe=True)
  rows=[]
  for ch,mode,keys in itertools.product([0,2,15,20,21,23,25,28],range(2),[0,129]):
   pair=[]
   for v in[old,b]:
    q=C.setup(v,ch);q.put(CrossoverBehaviorVersion=mode,SavedJoypadBits=keys)
    c,tr,mn=C.M.runtrace(q,'GameLoop',p=0x71)
    pair.append((registers(c),C.M.fastapp(q),tuple(q.m.banks),bytes(q.m[z]for z in smc_at(v)),bytes(q.m[0x100:0x17b]),c.processorCycles))
   assert pair[0]==pair[1],('foreign complete Main',ch,mode,keys)
   rows.append([ch,mode,keys,pair[1][-1]])
  ck['foreign_complete_Main']=dict(cases=len(rows),AXYP_SP_application_live_stack_banks_5SMC_CPU_exact=True)
  rows=[]
  for count in[0,1,4]:
   pair=[]
   for v in[old,b]:
    q=setup(v)
    if v is b:
     for i in range(count):
      q.set('AvDropItem',0x86,i);q.set('InvDropAgeHi',3,i);q.set('InvDropX',160+i*16,i);q.set('InvDropY',100,i)
      q.set('InvDropVY',q.get('DpLife'),i);q.set('InvDropVYMid',q.get('DpArea'),i);q.set('InvDropVYHi',q.get('DpWorld'),i)
    q.put(NmiDisable=255,VRAM_Buffer1_Offset=0,SavedJoypadBits=1)
    c,tr,mn=C.M.runtrace(q,'GameLoop');pair.append([c.processorCycles,mn])
   rows.append(dict(world_items=count,parent=pair[0],successor=pair[1],CPU_delta=pair[1][0]-pair[0][0]))
  ck['actual_complete_Main_finite_cost']=dict(rows=rows,source_benchmark_not_native_or_universal_timing=True)
  rows=[]
  for name in ['DpGameCombat','DpGameTick','DpGameDraw']:
   def fixture():
    q=boundary(b);q.put(DpPose=6)
    if name!='DpGameCombat':run(q,'DpGameCombat')
    return q
   q=fixture();c,tr,mn=C.M.runtrace(q,name,p=0x30)
   points=sorted(set((bank,pc)for bank,pc in tr if bank==85 and address(b,'DpDropsStart')<=pc<address(b,'DpDropsEnd')))
   # Every reached new service boundary including the actual helper stack
   # frame, not an unexecuted synthetic leaf target.
   for kind,point in itertools.product(['IRQ','NMI'],points):
    q=fixture();c,_,mn,_,hit=ISR.interrupt_actual(q,name,flags=0x30,inject=point,kind=kind)
    assert hit;rows.append([name,kind,*point,mn])
  ck['actual_new_service_IRQ_lagNMI']=dict(cases=len(rows),minimum_SP=min(x[-1]for x in rows),rows=rows,strict_context_and_literal_shadow_only=True)
  proof['passed']=True
 except Exception as e:proof.update(failure=repr(e),traceback=traceback.format_exc())
 files=[Path(__file__),Path(C.__file__),O/'candidate.nes',O/'candidate.dbg',O/'drops.inc',O/'art.inc',O/'drops.chr',P/'candidate.nes',P/'candidate.dbg',P/'handoff.json']
 proof['bindings']={str(p.resolve()):sha(p)for p in files};a.output.write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(dict(passed=proof['passed'],failure=proof.get('failure'),checks=list(ck))));assert proof['passed']
if __name__=='__main__':main()
