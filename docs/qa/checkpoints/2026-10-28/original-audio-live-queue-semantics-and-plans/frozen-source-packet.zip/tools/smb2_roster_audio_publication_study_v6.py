"""Read-only original queue/cadence study. No port, hook or transport mutation."""
from pathlib import Path
import collections,hashlib,json,re
import smb2_roster_audio_controls_v1 as A
import smb2_roster_hud_controls_v5 as H
R=A.ROOT;OUT=R/'build/smb2-roster-audio-publication-study-v6.json'
REF=R.parent/'mario in kid icarus/vendor/smb2/src'
NAMES=['MusicQueue1','DPCMQueue','SoundEffectQueue1','MusicQueue2','SoundEffectQueue2','SoundEffectQueue3']

def digest(v):return hashlib.sha256(json.dumps(v,separators=(',',':')).encode()).hexdigest()
def original(writes,ticks=1,repeat=False):
 m=A.Original();labels=A.S.labels()
 for p in list(range(0xbb,0xc7))+list(range(0x5ec,0x620)):m.ram[p]=0
 m.ram[0x100]=0;history=[]
 for t in range(ticks):
  if t==0 or repeat:
   for index,value in writes:m.ram[0x600+index]=value
  c=A.call(m,labels['StartProcessingSoundQueue'])
  history.append(dict(APU=m.events.copy(),fetches=m.fetches.copy(),state=bytes(m.ram[0x5ec:0x620]).hex(),queues=bytes(m.ram[0x600:0x606]).hex(),cycles=c.processorCycles))
 return history

def main():
 assert not OUT.exists()
 paths=[Path(__file__),Path(A.__file__),Path(A.S.__file__),A.S.ROM,REF/'defs.asm',A.OUT/'handoff.json',H.O/'candidate.nes',H.O/'candidate.dbg',H.O/'handoff.json',H.O/'source-closure.json',OUT.with_name('smb2-roster-audio-publication-study-first-negative-v6.json')]
 paths+=list(REF.glob('prg-*.asm'))+list((A.S.REF/'bin').glob('native.nes.*.nl'))
 bindings=[A.bind(p)for p in paths]
 writers=[];reads=[]
 for p in sorted(REF.glob('prg-*.asm')):
  for line,text in enumerate(p.read_text().splitlines(),1):
   s=text.split(';',1)[0].strip();m=re.fullmatch(r'(STA|STX|STY|LDA|ORA|AND|INC|DEC|LSR|ASL|ROL|ROR)\s+('+('|'.join(NAMES))+')',s)
   if not m:continue
   row=dict(path=str(p),line=line,opcode=m[1],queue=m[2])
   (writers if m[1]in['STA','STX','STY']else reads).append(row)
 assert not any(r['opcode']=='ORA'for r in reads)
 # Genuine original code equality/counterexamples, no port-facing model.
 a=original([(4,8),(4,1)])[0];b=original([(4,1)])[0]
 assert a==b and a['queues']=='000000000000'
 ring_first=original([(4,8)])[0];assert ring_first['APU']!=a['APU']or ring_first['state']!=a['state']
 hurt_pull=original([(1,4),(1,8)])[0];pull=original([(1,8)])[0];hurt=original([(1,4)])[0]
 assert hurt_pull==pull and hurt_pull['fetches']!=hurt['fetches']
 mixed=original([(1,12)])[0];assert mixed['fetches']==hurt['fetches']
 once=original([(0,1)],2);repeated=original([(0,1)],2,True);assert once[1]['state']!=repeated[1]['state']
 # Exact live IdleLoop bytes prove two genuine GameLoop calls and the forced
 # wait after the one catch-up. This is a compiled CFG bound, not a new native
 # timing observation or an instruction-level NMI scheduling simulation.
 C=H.C;bun=C.scoped_load(H.O/'candidate.nes');pc,bk=C.key(bun,'IdleLoop');end=C.address(bun,'GameLoop');blob=bun['raw'][C.location(bun,'IdleLoop'):C.location(bun,'GameLoop')]
 def ab(op,n):v=C.address(bun,n);return bytes([op,v&255,v>>8])
 want=ab(0xad,'NmiDisable')+bytes([0xf0,251])+ab(0xad,'NmiSkipped')+bytes([0x48])+ab(0x20,'GameLoop')+bytes([0x68])+ab(0xcd,'NmiSkipped')
 assert blob.startswith(want)
 assert blob.count(ab(0x20,'GameLoop'))==2 and blob.endswith(ab(0x4c,'IdleLoop'))
 assert bun['raw'][C.location(bun,'GameLoop'):C.location(bun,'GameLoop')+5]==bytes([0xa9,255])+ab(0x8d,'NmiDisable')
 at=C.location(bun,'GameLoop::PauseSkip');assert bun['raw'][at:at+6]==bytes([0xa9,0])+ab(0x8d,'NmiDisable')+bytes([0x60])
 at=C.location(bun,'NonMaskableInterrupt');n=int(bun['syms']['NonMaskableInterrupt']['size'],0)
 assert bun['raw'][at:at+n].count(ab(0x20,'AudioUpdate'))==2
 catch=C.address(bun,'IdleLoop::CatchUpOnce')-pc
 assert blob[catch:]==ab(0xad,'NmiSkipped')+bytes([0x48])+ab(0x20,'GameLoop')+bytes([0x68,0xa9,0])+ab(0x8d,'ShouldSkipDrawSprites')+ab(0x4c,'IdleLoop')
 result=dict(passed=True,READ_ONLY_STUDY=True,source_CPU_only=True,native=False,bindings=bindings,
  original_queue_writers=writers,original_queue_reads=reads,writer_opcodes=dict(collections.Counter(r['opcode']for r in writers)),
  source_conclusion='Original producer stores assign bytes. There is no producer OR/RMW of these six queues in the authenticated prg sources. The audio consumer prioritizes bits/shifts and clears all6 at each real NMI callback. The one non-audio read is native enemy DPCM-pending suppression; it is not a ported SMB2 hero producer read. Writer counts are a textual source census including consumer clears/conditional branches, not a claimed emitted-writer count.',
  actual_original_counterexamples=dict(last_SFX2_assignment=dict(assignments=[8,1],equals_final1=True,APU_sha256=digest(a['APU']),separate_record8_has_different_first_callback=True),last_DPCM_assignment=dict(assignments=[4,8],equals_final8=True,actual_fetches=pull['fetches'],obsolete_record4_fetches=hurt['fetches']),combined_DPCM_lowbit_priority=dict(value=12,equals4_fetches=True),no_republish_same_generation=dict(first_queues_zero=once[0]['queues'],second_native_state=once[1]['state'],wrong_republish_second_state=repeated[1]['state'])),
  actual_compiled_cadence=dict(IdleLoop_PC=hex(pc),physical_bank=bk,exact_bytes=blob.hex(),GameLoop_PC=hex(end),GameLoop_calls_per_idle_iteration=2,catchup_unconditional_return_to_wait=True,maximum_complete_Main_between_adjacent_real_NMI_callbacks=2,reason='Regular NMI wakes one Main; a lag NMI permits at most one subsequent catch-up. Catch-up then always returns to IdleLoop, and Main setsNmiDisable0 at its exit, forcing another actual NMI before another iteration. Source NMI has one AudioUpdate on each regular/lag branch.'),
  preferred_plan='No event FIFO. Stable six-byte pending image with atomic commit/ack generation and only original assignment/priority semantics. Two Main completions before one callback collapse assignments exactly as original. No overflow/full handling or extra source ticks is needed for a fixed6B image.',
  unresolved_before_code=['ACK during an in-flight Main must not resurrect a consumed field or erase a newly assigned identical byte. Actual per-field write occurrence/dirty or equivalent source-owned staging is required; comparing values alone is insufficient.','Original hero S2DpcmRequest/S2Sfx1/S2Sfx2 writers are STA-only and Main does not read them. Their finite actual value sets may permit a non-source-value staging sentinel, but that requires complete compiled-writer proof; no approval/implementation claimed.','Shared native world/music queues must retain their current real-NMI assignment/OR semantics or be integrated with equally explicit per-field provenance, not blindly appended to a per-Main ring.','NMI-first owner retirement/init and commit25last; Main never initializes a former owner RgAudioRam image.','ROOT common BEGIN/COMMIT and NMI dispatch, source-safe mixer pause/DAC and DMC-owner routing remain review decisions. No5FB6 or newallocation claimed.'])
 OUT.write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(dict(proof=A.bind(OUT),writer_opcodes=result['writer_opcodes'],max_Main_distance=2)))

if __name__=='__main__':main()
