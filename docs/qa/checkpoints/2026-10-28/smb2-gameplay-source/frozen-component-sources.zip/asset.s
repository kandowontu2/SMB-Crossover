.segment "SMB2_ROSTER_CHR"
.incbin "chr/characters/smb2-roster.chr"
