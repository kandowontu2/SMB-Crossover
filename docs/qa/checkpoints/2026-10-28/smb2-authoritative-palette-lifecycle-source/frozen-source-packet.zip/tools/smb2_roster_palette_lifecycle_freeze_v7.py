"""Freeze palette lifecycle only; no common NMI/audio or native admission."""
from pathlib import Path
import collections,difflib,json,re,subprocess,sys
import prepare_smb2_roster_palette_lifecycle_v7 as B
import smb2_roster_palette_lifecycle_controls_v7 as T
R,O,bind=B.R,B.O,B.bind;C,M,H=T.C,T.M,T.H

def symbols(path):
 scopes={};rows=[]
 for line in path.open():
  d=dict(re.findall(r'(\w+)=("[^"]*"|[^,\r\n]+)',line))
  if line.startswith('scope\t'):scopes[d['id']]=d
  elif line.startswith('sym\t')and'val'in d:rows.append(d)
 def scope(i):
  if i is None:return None
  x=scopes[i];return(scope(x.get('parent')),x.get('mod'),x['name'])
 return collections.Counter((scope(d.get('scope')),)+tuple(d.get(k)for k in ['name','seg','type','addrsize'])+(int(d['val'],0),)for d in rows)

def menu_stack(b):
 low=255;deep=None;rows=[]
 def observe(c,q):
  nonlocal low,deep
  if c.sp<low:
   low=c.sp;deep=(bytes(q.m),q.m.banks.copy(),c.pc,c.a,c.x,c.y,c.p,c.sp)
 for variant,mode in __import__('itertools').product(range(4),[0,1]):
  q=M.menu(b);q.put(CrossoverBehaviorVersion=mode)
  M.run(q,'NrGlobalInit',probe=observe)
  for mask in[0,4,0,4,0,4,0,1]+[m for _ in range(variant)for m in[0,32]]:
   q.put(VRAM_Buffer1_Offset=0,VRAM_Buffer1=0,VRAM_Buffer2_Offset=0,SavedJoypad1Bits=mask,SavedJoypad2Bits=0)
   M.run(q,'CrossoverMenuInput',probe=observe)
  q.put(OperMode=1,DisableIntermediate=0,AltEntranceControl=0,CurrentOAMOffset=0)
  c,tr,sp=M.run(q,'DisplayIntermediate',probe=observe);rows.append(dict(variant=variant,mode=mode,cycles=c.processorCycles,min_SP=sp))
 raw,banks,pc,a,x,y,p,sp=deep
 q=T.T.Arena(b,25);list.__setitem__(q.m,slice(None),raw);q.m.banks=banks
 cpu=T.T.NesMPU(memory=q.m,pc=pc);cpu.a,cpu.x,cpu.y,cpu.p,cpu.sp=a,x,y,p,sp
 irq=C.interrupt(cpu,q)
 return dict(actual_whole_MenuInput_Select_lives_source=True,min_SP=low,deepest=dict(PC=hex(pc),bank=banks[(pc-0x8000)//8192]if pc>=0x8000 else-1,SP=sp),genuine_IRQ_at_actual_deepest=min(irq,sp),rows=rows,native=False)

def main():
 assert not(O/'handoff.json').exists(),'freeze must not be overwritten'
 h=json.loads((B.OLD/'handoff.json').read_text())
 for k in ['owned_files','input_bindings','output_bindings']:
  for row in h[k]:assert bind(row['path'])==row
 build=json.loads((O/'build-proof.json').read_text());tests=json.loads((O/'palette-controls.json').read_text())
 assert tests['passed']and tests['candidate']==build['candidate']==bind(O/'candidate.nes')
 assert build['tool']==bind(B.__file__)and tests['tool']==bind(T.__file__)
 old=json.loads((B.OLD/'source-closure.json').read_text());cmd=old['command'].copy()
 cmd[cmd.index('--create-full-dep')+1]=str(O/'source-closure.d');cmd[cmd.index('-o')+1]=str(O/'source-closure.o');cmd[-1]=str(O/'objects/entrypoint.s');cmd[4:4]=['-I',str(O/'overlay/src')]
 p=subprocess.run(cmd,cwd=R,capture_output=True,text=True);(O/'source-closure-launcher.txt').write_text(p.stdout+p.stderr);assert not p.returncode,p.stderr
 line=(O/'source-closure.d').read_text().splitlines()[0].split(':\t',1)[1];deps={Path(x.replace('\\ ',' ')).resolve()for x in re.split(r'(?<!\\)\s+',line.strip())}
 assert R/'src/smb2_roster_palette_lifecycle_v7.s'in deps
 assert all(Path(row['overlay']['path'])in deps for row in build['source_edits'])
 # Real final symbol identities. The only moved existing values are own
 # physical118 labels at/after the3B OR insertion, including the exactC000 end.
 before=symbols(B.OLD/'candidate.dbg');after=symbols(O/'candidate.dbg');missing=before-after;moves=[];descriptors=[]
 b=C.scoped_load(O/'candidate.nes');prior=C.scoped_load(B.OLD/'candidate.nes');seg=prior['syms']['S2MainPalette']['seg'];cut=C.address(prior,'S2MainPalette')+3
 gates=[]
 for path,z in [(R/'src/smb2_roster_host_v5.s',prior),(O/'overlay/src/smb2_roster_host_v5.s',b)]:
  actual={}
  for name,target,index in re.findall(r'^S2MainGate (\w+),(\w+),\w+,(\d+)$',path.read_text(),re.M):
   pc,bank=C.key(z,target);actual[int(index)]=(pc,bank,target)
   for suffix,value in [('Lo',pc&255),('Hi',pc>>8),('Bank',bank|128)]:assert C.address(z,'S2MainOwn'+suffix+index)==value
  assert len(actual)==30;gates.append(actual)
 for identity,n in missing.items():
  val=identity[-1];name=identity[1].strip('"')
  if identity[2]is None:
   match=re.fullmatch(r'S2MainOwn(Lo|Hi|Bank)(\d+)',name)
   if match:
    suffix,index=match[1],int(match[2]);pc,bank,target=gates[1][index]
    value=dict(Lo=pc&255,Hi=pc>>8,Bank=bank|128)[suffix]
    assert after[identity[:-1]+(value,)]>=n
    descriptors.append(dict(name=name,old=val,new=value,actual_old_target=gates[0][index],actual_new_target=gates[1][index]));continue
   if name=='_FARCALL_COUNT':
    assert after[identity[:-1]+(val+1,)]>=n;descriptors.append(dict(name=name,old=val,new=val+1,meaning='one genuine extra helper farcall macro'));continue
  assert identity[2]==seg and cut<=val<=0xbffd,('unexpected symbol move',identity,n)
  new=identity[:-1]+(val+3,);assert after[new]>=n,('expected genuine3B move missing',identity,new)
  moves.append(dict(scope=str(identity[0]),name=identity[1],old=hex(val),new=hex(val+3),records=n))
 assert C.address(b,'S2HudCoreEnd')==0xc000 and C.address(b,'S2PaletteLifecycleEnd')==0xb001
 a=prior['raw'];z=b['raw'];delta=collections.Counter((i-16)//8192 for i,(x,y)in enumerate(zip(a,z))if x!=y)
 assert a[:16]==z[:16]and a[16+1048576:]==z[16+1048576:]
 for bank in[74,117,119,120,125,127]:
  at=16+bank*8192;assert a[at:at+8192]==z[at:at+8192],('audio/clone/finalE changed',bank)
 # Genuine fresh ordinary builds, using the same expanded-only entry chain.
 (O/'overlay/src/entrypoint.s').write_bytes((O/'objects/entrypoint.s').read_bytes());ordinary=[]
 for mode in ['mmc3','mmc5']:
  dest=O/('flagoff-'+mode+'.nes');command=[sys.executable,str(R/'tools/build_mmc5_expanded.py'),'--source-overlay',str(O/'overlay'),'--output',str(dest),'--flag-off',mode]
  p=subprocess.run(command,cwd=R,capture_output=True,text=True);(O/('flagoff-'+mode+'-launcher.txt')).write_text(p.stdout+p.stderr);assert not p.returncode,p.stderr[-2000:]
  ref=B.OLD/('flagoff-'+mode+'.nes');assert dest.read_bytes()==ref.read_bytes();ordinary.append(dict(mapper=mode,actual=bind(dest),reference=bind(ref),command=command))
 stack=menu_stack(b);(O/'menu-stack.json').write_text(json.dumps(stack,indent=2)+'\n')
 patch=''
 for row in build['source_edits']:
  p=Path(row['preimage']['path']);q=Path(row['overlay']['path'])
  patch+=''.join(difflib.unified_diff(p.read_text().splitlines(True),q.read_text().splitlines(True),fromfile='204b/src/'+p.name,tofile='palette-v7/src/'+p.name))
 leaf=R/'src/smb2_roster_palette_lifecycle_v7.s';patch+=''.join(difflib.unified_diff([],leaf.read_text().splitlines(True),fromfile='/dev/null',tofile='palette-v7/src/'+leaf.name))
 (O/'implementation.patch').write_text(patch,newline='\n')
 inputs=deps|{Path(row['path'])for row in h['input_bindings']}|{Path(sys.executable)}
 for mod in list(sys.modules.values()):
  f=getattr(mod,'__file__',None)
  if f:
   p=Path(f).resolve()
   if p.suffix=='.py'and(p.is_relative_to(R)or'py65'in p.parts):inputs.add(p)
 source=dict(passed=True,source_CPU_only=True,native=False,candidate=build['candidate'],parent=build['parent'],actual_ASM_dependencies=len(deps),command=cmd,
  changed_bytes=dict(delta),genuine_private_3B_symbol_moves=moves,genuine_source_target_descriptor_constants=descriptors,all_other_qualified_old_symbol_identities_exact=True,actual_shared_caller_literals=build['genuine_relocated_caller_literals'],
  header_CHR_audio_fullE_and_all_other_banks_exact=True,ordinary=ordinary,stack=bind(O/'menu-stack.json'),A63=['AFDC','B000'],A63_end='B001',CORE118_end='C000',input_bindings=[bind(p)for p in sorted(inputs)],tool=bind(__file__))
 (O/'source-closure.json').write_text(json.dumps(source,indent=2)+'\n')
 note=R/'docs/qa/smb2-roster-palette-lifecycle-source-2026-10-29.txt'
 note.write_text('''PRIVATE SMB2 AUTHORITATIVE PALETTE LIFECYCLE REPAIR — NO NATIVE

Parent204bf57a is frozen mailbox successor of6173, genuine f56a base.
Original native evidence remains immutable: menu/lives blue-red Mario,
world orange-green. It was not the documented eyeP1/vegetableP3 adaptation.
No claim that unwired audio/clock caused palette writes.

Concrete source-CPU reproduction calls real GetPlayerColors, native selected
SamusFreezeUpdateScreen gateway, GetAreaPalette, GetBackgroundColor and complete
S2MainEnd. First queue writesP0=[01,16,27]. Actual native GroundPaletteData
126:8176 then writesP0=[16,27,18]. Old subsequent GetBackgroundColor/NrColors
and MainEnd emit nothing because classAck0 survives. This is an authoritative
palette-owner/cache invalidation defect; no first nativePPU overwrite stamp is
invented from the selected still. Actual source gateway PPUDATA and native
InitBuffer basic-block stores are executed in controls.

Fix: authoritative NrColors and S2MColors raw25 routes call new37B A63
AFDC..B000 helper. It raw-admits before private reads, invalidates only the
existing S2PaletteAck and invokes the genuine original publisher. Original
publisher adds OR VRAM_Buffer_AddrCtrl to its existing Star rejection. A ROM
palette selector cannot make a false successful queueAck. Capacity/Star/ROM
declines retain invalidation; next legal check completes the entire packet
before acknowledging. Normal unchanged checks stay cache-quiet; no per-frame
force or new RAM/CHR/palette roles. Original eye/enemyP1 and vegetableP3
composition remains untouched.

The3B OR consumes exact remaining CORE118 capacity, endC000. Actual following
own labels move3B; fresh DBG/LBL/MAP and exact symbol moves are bound. Actual
A0 Grow/Carry and126 Erase caller low-byte operands move to the genuine new
targets; every other byte of those banks is exact. Other shared/public PCs
remain stable. All audio74/117, samples/clones119/120/125/current127, header,
CHR and foreign banks are exact. No commonNMI or mixer work is included.

Finite controls cover all4classes/bothmodes/4areas, genuine cold MenuInput and
Select route before native level palettes, background control4->0/5->9/6->10/
7->4, capacity edges, Star deferral and retry, unchanged-scene refresh, actual
new-life/scene reset callbacks. All tests are sourceCPU component/caller
evidence, not native visible-epoch or hardware scheduling qualification.
344complete foreignMain and86complete foreignGetPlayerColors calls retain
full live state/AXYP/SP/banks/33SMC with0CPU delta.32paired normal ownedMain
retain live state with+4CPU; quiet owned palette tail+4CPU. Unchanged actual
earned/world/collision/carry/retirement/1Up source campaign reused on this ROM.
63genuine reachedIRQ seams preserve actual state. Whole source menu/lives
stack and deepestIRQ are separately in menu-stack.json.

Retained setup/control negatives: initial preparer forgot3real relocated
caller operands; one caller name first mislabeledInvalidate before actual
BD1A Erase attribution; background4 incorrectly assumed nonzeroROM selector;
inherited earned assertion initially lacked its real compiled entry counter.
No game behavior or original assertions were relaxed for those corrections.

OPEN: ROOT native palette/coldlevel/gameplay review, actual per-real-NMI
S2NmiClock including lag/pause, complete atomic context/music/world-cue/mixer/
DMC ownership and final sharedunion.6173 diagnostics/204b source packets are
not retagged as new native success. No canonical/settings/Downloads edits.
''',encoding='utf-8',newline='\n')
 owned=[Path(B.__file__),Path(T.__file__),Path(__file__),leaf,note,O/'implementation.patch']+[Path(x['overlay']['path'])for x in build['source_edits']]+[O/'overlay/src/entrypoint.s']
 outputs=[p for p in O.rglob('*')if p.is_file()and p.name!='handoff.json']
 h=dict(status='PRIVATE_AUTHORITATIVE_PALETTE_LIFECYCLE_SOURCE_CPU_IRQ_PASS_NO_NATIVE',candidate=build['candidate'],parent=build['parent'],parent_handoff=bind(B.OLD/'handoff.json'),source=bind(O/'source-closure.json'),controls=bind(O/'palette-controls.json'),stack=bind(O/'menu-stack.json'),scope_note=bind(note),owned_files=[bind(p)for p in owned],input_bindings=source['input_bindings'],output_bindings=[bind(p)for p in sorted(outputs)],limits='No actual native menu/gameplay/audio/clock qualification or shared admission; original negatives immutable.')
 (O/'handoff.json').write_text(json.dumps(h,indent=2)+'\n');print(json.dumps(dict(handoff=bind(O/'handoff.json'),inputs=len(inputs),ASMdeps=len(deps),owned=len(owned),outputs=len(outputs),delta=dict(delta),stack=stack),indent=2))

if __name__=='__main__':main()
