"""Sparse palette-lifecycle successor of frozen204b; no shared source edits."""
from pathlib import Path
import hashlib,json,subprocess
import prepare_smb2_roster_audio_effects_v6 as B
R=B.R;OLD=B.OUT;O=R/'build/smb2-roster-palette-lifecycle-v7';bind=B.bind
PARENT='b46b7c837481218d42c55bafc794e21b01d244aae002a2213ec687700908ef90'

def main():
 assert not(O/'handoff.json').exists(),'never change a frozen successor'
 assert bind(OLD/'handoff.json')['sha256']==PARENT
 old=json.loads((OLD/'handoff.json').read_text())
 for k in ['owned_files','input_bindings','output_bindings']:
  for row in old[k]:assert bind(row['path'])==row
 O.mkdir(exist_ok=True);ov=O/'overlay/src';ov.mkdir(parents=True,exist_ok=True);obj=O/'objects';obj.mkdir(exist_ok=True)
 edits=[]
 for path,needle,replacement in [
  (B.P.OUT/'overlay/src/new_roster_dispatch.s','Smb:pla\n plp\n farcall S2MainPalette,jmp','Smb:pla\n plp\n farcall S2HostForcePalette,jmp'),
  (B.P.OUT/'overlay/src/smb2_roster_main_v2.s','.proc S2MainPalette\n ; Publish sourceP0', '.proc S2MainPalette\n ; Publish sourceP0'),
  (R/'src/smb2_roster_host_v5.s','S2MainGate S2MColors,S2MainPalette,X5GetPlayerColors,23','S2MainGate S2MColors,S2HostForcePalette,X5GetPlayerColors,23')]:
  s=path.read_text();assert s.count(needle)==1,(path,needle)
  if path.name=='smb2_roster_main_v2.s':
   at=s.index('.proc S2MainPalette');head,tail=s[:at],s[at:]
   needle=' lda StarInvincibleTimer\n bne Done';assert tail.count(needle)==1
   tail=tail.replace(needle,' lda StarInvincibleTimer\n ora VRAM_Buffer_AddrCtrl       ; ROM palette service must precede acknowledgment.\n bne Done',1);s=head+tail
  else:s=s.replace(needle,replacement,1)
  target=ov/path.name;target.write_text(s,newline='\n');edits.append(dict(preimage=bind(path),overlay=bind(target)))
 entry=(OLD/'objects/entrypoint.s').read_text()+'\n.if ::ENABLE_MMC5_EXPANDED .and ::MAPPER_MMC5\n.include "smb2_roster_palette_lifecycle_v7.s"\n.endif\n'
 (obj/'entrypoint.s').write_text(entry,newline='\n')
 cmd=json.loads((OLD/'build-proof.json').read_text())['command']
 cmd=[v.replace(str(OLD/'objects/entrypoint.s'),str(obj/'entrypoint.s')).replace(str(OLD/'candidate.'),str(O/'candidate.'))for v in cmd]
 at=cmd.index('--asm-include-dir');cmd[at:at]=['--asm-include-dir',str(ov)]
 p=subprocess.run(cmd,cwd=R,capture_output=True,text=True);(O/'launcher.txt').write_text(p.stdout+p.stderr);assert not p.returncode,p.stderr[-3000:]
 from prepare_cv3_dmc_mirror import prepare
 prepare(R,O/'candidate.nes');raw=bytearray((O/'candidate.nes').read_bytes());fixed=raw[16+127*8192:16+128*8192]
 plan=json.loads((R/'build/smb2-roster-audio-plan-v1.json').read_text());original=B.P.M.F.P.A.S.ROM.read_bytes()
 for clone in plan['samples']:
  copy=bytearray(fixed)
  for row in clone['entries']:
   at=int(row['target'],16)-0xe000;p=int(row['source'],16);n=row['bytes'];blob=original[16+114688+p-0xc000:16+114688+p-0xc000+n]
   assert hashlib.sha256(blob).hexdigest()==row['sha256'];copy[at:at+n]=blob
  raw[16+clone['bank']*8192:16+(clone['bank']+1)*8192]=copy
 (O/'candidate.nes').write_bytes(raw)
 a=(OLD/'candidate.nes').read_bytes();diff=[i for i,(x,y)in enumerate(zip(a,raw))if x!=y]
 assert a[:16]==raw[:16]and a[16+1048576:]==raw[16+1048576:]
 # Three real shared caller literal operands follow the moved own CORE
 # helpers. Their opcodes, preimages and actual new symbols are mandatory.
 import smb2_roster_main_callers_v2 as C
 prior=C.scoped_load(OLD/'candidate.nes');now=C.scoped_load(O/'candidate.nes');callers=[]
 for bank,offset,name,length in [(0,0x17ba,'S2MainGrow',18),(0,0x17d3,'S2MainCarryPrelude',15),(126,0x1fde,'S2MainErase',18)]:
  pc,bk=C.key(prior,name);dest,newbank=C.key(now,name);assert bk==newbank==118 and dest==pc+3
  # Locate only the actual LDA #low / STA FarcallJmpTarget operand triple;
  # the surrounding genuine farcall is checked separately below.
  at=16+bank*8192;lo=bytes([0xa9,pc&255,0x8d,(C.address(prior,'FarcallJmpTarget_SMC')+1)&255,(C.address(prior,'FarcallJmpTarget_SMC')+1)>>8])
  hits=[i for i in range(offset-3,offset+8)if a[at+i:at+i+5]==lo];assert len(hits)==1,(bank,name,hits)
  i=hits[0];want=bytearray(a[at:at+8192]);want[i+1]=dest&255
  # Bank0 contains two distinct actual helper callers in the same page.
  actual=raw[at:at+8192]
  assert actual[i-1:i+1]==a[at+i-1:at+i+1]and actual[i+2:i+11]==a[at+i+2:at+i+11]
  callers.append(dict(bank=bank,operand_offset=hex(i+1),old_target=[hex(pc),bk],new_target=[hex(dest),newbank],target=name))
 for bank in[0,126]:
  at=16+bank*8192;want=bytearray(a[at:at+8192])
  for row in callers:
   if row['bank']==bank:want[int(row['operand_offset'],16)]=int(row['new_target'][0],16)&255
  assert raw[at:at+8192]==want,('nonoperand shared mutation',bank)
 assert {(i-16)//8192 for i in diff}<={0,63,118,124,126},'unexpected shared/foreign ROM delta'
 proof=dict(status='PRIVATE_PALETTE_LIFECYCLE_UNQUALIFIED_NO_NATIVE',candidate=bind(O/'candidate.nes'),parent=bind(OLD/'candidate.nes'),parent_handoff=bind(OLD/'handoff.json'),command=cmd,
  source_edits=edits,new_leaf=bind(R/'src/smb2_roster_palette_lifecycle_v7.s'),tool=bind(__file__),changed_bytes=len(diff),changed_banks=sorted({(i-16)//8192 for i in diff}),genuine_relocated_caller_literals=callers,header_CHR_audio_Ebytes_exact=True)
 (O/'build-proof.json').write_text(json.dumps(proof,indent=2)+'\n');print(json.dumps(dict(candidate=proof['candidate'],changed_bytes=len(diff),banks=proof['changed_banks'])))

if __name__=='__main__':main()
