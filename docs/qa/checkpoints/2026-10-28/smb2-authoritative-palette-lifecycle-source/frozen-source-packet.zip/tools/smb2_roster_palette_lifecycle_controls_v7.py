"""Native screen-pipeline palette counterexample and private source controls."""
import collections,hashlib,itertools,json
import prepare_smb2_roster_palette_lifecycle_v7 as B
import smb2_roster_hud_controls_v5 as H
from audit.proto_palette_coalesce_controls_v1 import ppu
R,O,bind=B.R,B.O,B.bind;C,T,M=H.C,H.T,H.M

def nmi_update(q):
 """Execute genuine gateway and the real selected ROM/queue pointer.

 This is the actual called NMI component, not a hardware NMI/cadence claim.
 Explicit queue service below models the genuine nativeInitBuffer stores.
 """
 ctrl=q.get('VRAM_Buffer_AddrCtrl')
 p=q.m[C.address(q.b,'VRAM_AddrTable_Low')+ctrl]+256*q.m[C.address(q.b,'VRAM_AddrTable_High')+ctrl]
 q.put(NmiR0=p&255,NmiR1=p>>8);c,tr,sp=M.run(q,'SamusFreezeUpdateScreen');image,bus=ppu(q.m.writes)
 # Execute the actual complete buffer-clear basic block, ending immediately
 # before native AudioUpdate. No source clock/audio dispatcher is simulated.
 pc=C.address(q.b,'NonMaskableInterrupt::InitBuffer')
 q.m.page(3,127);cpu=T.NesMPU(memory=q.m,pc=pc);cpu.y=1 if ctrl==6 else 0
 stop=C.address(q.b,'AudioUpdate');count=0
 while True:
  if q.m[cpu.pc]==0x20 and q.m[cpu.pc+1]+256*q.m[cpu.pc+2]==stop:break
  cpu.step();count+=1;assert count<20
 return image,dict(control=ctrl,pointer=hex(p),gateway_cycles=c.processorCycles,PPUDATA=len(bus),P0=[image.get(0x3f11+i)for i in range(3)],P1=[image.get(0x3f15+i)for i in range(3)],bus_sha256=hashlib.sha256(bytes(v for p,v in bus)).hexdigest(),actual_clear_instructions=count)

def initialized(b,variant=0,mode=0,menu=False):
 if menu:
  q=M.menu(b);q.put(CrossoverBehaviorVersion=mode);M.run(q,'NrGlobalInit')
  for mask in[4,4,4,1]:M.click(q,mask)
  for _ in range(variant):M.click(q,32)
  assert q.get('SelectedCharacter')==25 and q.get('S2Variant')==variant and q.get('S2Ready')==178
  # Service the actual final menu queue before the native level pipeline.
  nmi_update(q)
 else:
  q=M.menu(b,25);q.put(S2Variant=variant,CrossoverBehaviorVersion=mode);M.run(q,'S2ColdInit')
 q.put(OperMode=1,OperMode_Task=1,ScreenRoutineTask=9,AreaType=1,BackgroundColorCtrl=0,StarInvincibleTimer=0)
 return q

def expected(q):
 at=C.location(q.b,'S2CharacterPalettesC')+q.get('S2NativeCharacter')*4
 return list(q.b['raw'][at+1:at+4])

def pipeline(b,variant=0,mode=0,area=1,bg=0,menu=False):
 q=initialized(b,variant,mode,menu=menu);q.put(AreaType=area,BackgroundColorCtrl=bg)
 M.run(q,'GetPlayerColors');initial=H.packet(q).hex();_,menu=nmi_update(q)
 M.run(q,'GetAreaPalette');_,native=nmi_update(q)
 M.run(q,'GetBackgroundColor');after=H.packet(q).hex();ack=q.get('S2PaletteAck');ctrl=q.get('VRAM_Buffer_AddrCtrl')
 if ctrl:
  assert ack==255 and after=='00','ROM service must retain pending invalidate'
  _,background=nmi_update(q)
  q.put(GameEngineSubroutine=8,TimerControl=0);M.run(q,'S2MainEnd')
 else:background=None
 queued=H.packet(q).hex();actual,final=nmi_update(q)
 return dict(variant=variant,mode=mode,area=area,background=bg,expected_P0=expected(q),initial_queue=initial,initial=menu,native_area=native,GetBackgroundColor_queue=after,ack_after_background=ack,background_ROM=background,repair_queue=queued,final=final),actual

def main():
 build=json.loads((O/'build-proof.json').read_text());assert bind(O/'candidate.nes')==build['candidate']
 old=C.scoped_load(B.OLD/'candidate.nes');b=C.scoped_load(O/'candidate.nes');out=dict(passed=False,source_CPU_only=True,native=False,candidate=build['candidate'],parent=build['parent'],tool=bind(__file__))
 # The negative follows real native screen owners, rather than inferring
 # palette state from a contact sheet or an endFrame screenshot.
 q=initialized(old);M.run(q,'GetPlayerColors');_,first=nmi_update(q);M.run(q,'GetAreaPalette');_,second=nmi_update(q);M.run(q,'GetBackgroundColor')
 miss=H.packet(q).hex();q.put(GameEngineSubroutine=8,TimerControl=0);M.run(q,'S2MainEnd')
 assert first['P0']==[1,22,39]and second['P0']==[22,39,24]and miss==H.packet(q).hex()=='00'and q.get('S2PaletteAck')==0
 out['original_204b_visible_palette_counterexample']=dict(first=first,native_ground=second,subsequent_GetBackgroundColor_and_MainEnd_queue=miss,ack=0,first_area_owner=dict(symbol='GroundPaletteData',physical_bank=C.key(old,'GroundPaletteData')[1],CPU=hex(C.address(old,'GroundPaletteData'))),matching6173_bytes=True)
 rows=[]
 for variant,mode,area in itertools.product(range(4),[0,1],range(4)):
  row,image=pipeline(b,variant,mode,area,0)
  assert row['final']['P0']==row['expected_P0'],('repaired native screen pipeline',row)
  # Source eye remap is unchanged: P1index2 supplied by the real area owner.
  assert row['native_area']['P1'][1]==(0x30 if area in[0,1]else 0x36)
  assert not any(0x3f14<=p<0x3f18 for p in image),'never steal eye/enemy palette1'
  rows.append(row)
 # Native background-control ROM packets override the queue; no false Ack.
 background=[]
 for bg in[4,5,6,7]:
  row,image=pipeline(b,0,0,1,bg)
  assert row['final']['P0']==[1,22,39]and(row['background_ROM']is not None)==(bg!=4)
  background.append(row)
 out['complete_native_screen_pipelines']=rows;out['background_ROM_deferral']=background
 cold=[]
 for variant,mode in itertools.product(range(4),[0,1]):
  row,image=pipeline(b,variant,mode,menu=True)
  assert row['final']['P0']==row['expected_P0'];cold.append(row)
 out['actual_cold_MenuInput_Select_then_native_level_palette']=cold
 # Every ROM selector, queued capacity edge and Star state. Actual source
 # stores remain absent on declined calls; pending invalidation survives.
 deferred=[]
 for variant,entry,ctrl,off,star in itertools.product(range(4),['GetPlayerColors','S2MColors'],[0,1,6,13],[0,77,78,83,255],[0,1]):
  q=initialized(b,variant);q.put(VRAM_Buffer_AddrCtrl=ctrl,VRAM_Buffer1_Offset=off,StarInvincibleTimer=star,S2PaletteAck=q.get('S2NativeCharacter'))
  at=C.address(b,'VRAM_Buffer1');q.m[at:at+256]=bytes([0x59])*256;before=bytes(q.m[at:at+256])
  M.run(q,entry)
  accepts=ctrl==0 and star==0 and off<78
  if accepts:
   assert q.get('VRAM_Buffer1_Offset')==off+6 and q.get('S2PaletteAck')==q.get('S2NativeCharacter')
   assert bytes(q.m[at+off:at+off+7])==bytes([0x3f,0x11,3]+expected(q)+[0])
  else:
   assert bytes(q.m[at:at+256])==before and q.get('VRAM_Buffer1_Offset')==off and q.get('S2PaletteAck')==255
   q.put(VRAM_Buffer_AddrCtrl=0,VRAM_Buffer1_Offset=0,VRAM_Buffer1=0,StarInvincibleTimer=0)
   M.run(q,'S2MainPalette');assert H.packet(q)==bytes([0x3f,0x11,3]+expected(q)+[0])
  deferred.append(dict(variant=variant,entry=entry,control=ctrl,offset=off,Star=star,published=accepts))
 out['busy_capacity_Star_and_eventual_retry']=dict(cases=len(deferred),accepted=sum(x['published']for x in deferred),rows=deferred)
 # Cold life/same-scene native refresh and an actual changed scene: native
 # source routes, not a new per-frame force or blanket cache clear.
 lifecycle=[]
 for variant,mode in itertools.product(range(4),[0,1]):
  q=initialized(b,variant,mode);M.run(q,'GetPlayerColors');nmi_update(q)
  for action in ['same-scene-native-colors','new-life','scene']:
   if action=='new-life':M.run(q,'S2NewLife')
   elif action=='scene':q.set('AreaAddrsLOffset',q.get('AreaAddrsLOffset')^1);M.run(q,'S2Ensure')
   # A native palette owner may have run even with unchanged class/scene.
   M.run(q,'GetAreaPalette');nmi_update(q);M.run(q,'GetBackgroundColor');image,record=nmi_update(q)
   assert record['P0']==expected(q)
   lifecycle.append(dict(variant=variant,mode=mode,action=action,PPUDATA=record['PPUDATA'],P0=record['P0']))
 out['real_lifecycle_callers']=lifecycle
 # Quiet owned publisher remains cache quiet; only OR abs adds4CPU.
 costs=[]
 for variant,mode in itertools.product(range(4),[0,1]):
  qs=[initialized(z,variant,mode)for z in[old,b]]
  for q in qs:q.put(S2PaletteAck=q.get('S2NativeCharacter'),OperMode_Task=3,GameEngineSubroutine=8)
  cs=[];ts=[]
  for q in qs:c,t,s=M.run(q,'S2MainEnd');cs.append(c);ts.append(t)
  # Own moved helper target operands are genuine requested call targets;
  # completeMain below must restore every liveSMC exactly as before.
  assert cs[1].processorCycles-cs[0].processorCycles==4
  costs.append(cs[1].processorCycles-cs[0].processorCycles)
 identities=[(n,x[1],x[2],x[3])for n,x in C.BASE.items()]+[('popo',20,'IcVariant',0),('nana',20,'IcVariant',1),('alex',21,'RcVariant',0),('ryan',21,'RcVariant',1),('sunny',23,None,0),('celeste',0,'MarioVariant',4)]
 foreign=[]
 for name,raw,field,variant in identities:
  for mode in[0,1]:
   qs=[C.make(z,raw,field,variant,mode)for z in[old,b]];hist=[[],[]]
   for mask in[0,1,129,0]:
    results=[T.frame(q,mask)for q in qs]
    for i,x in enumerate(results):hist[i]+=x[1]
    C.same_live(qs,[v[0]for v in results],('palette-v7 complete foreign Main',name,mode,mask),hist)
    foreign.append(results[1][0].processorCycles-results[0][0].processorCycles)
 out['complete_foreign_Main']=dict(calls=len(foreign),CPU_delta=sorted(set(foreign)),live='fullAXYP/SP,banks,allnonstackRAM/lowstack/33SMC; actual dead-stack writers retained')
 colors=[]
 for name,raw,field,variant in identities:
  for mode in[0,1]:
   qs=[C.make(z,raw,field,variant,mode)for z in[old,b]];cs=[];tr=[]
   for q in qs:c,t,s=M.run(q,'GetPlayerColors',a=0x55,x=17,y=23,p=0x71);cs.append(c);tr.append(t)
   C.same_live(qs,cs,('palette-v7 foreign full GetPlayerColors',name,mode),tr);colors.append(cs[1].processorCycles-cs[0].processorCycles)
 out['complete_foreign_colors']=dict(calls=len(colors),CPU_delta=sorted(set(colors)))
 owned=[]
 for variant,mode in itertools.product(range(4),[0,1]):
  qs=[T.arena(z,variant,mode)for z in[old,b]];hist=[[],[]]
  for mask in[0,1,129,0]:
   pair=[T.frame(q,mask)for q in qs]
   for i,x in enumerate(pair):hist[i]+=x[1]
   C.same_live(qs,[x[0]for x in pair],('palette-v7 owned complete Main',variant,mode,mask),hist)
   owned.append(pair[1][0].processorCycles-pair[0][0].processorCycles)
 out['paired_complete_owned_Main']=dict(calls=len(owned),CPU_delta=sorted(set(owned)),all_live_state_exact_on_unchanged_normal_palette_path=True)
 # Full owned Main, unchanged actual earned/collision/retirement/1Up assertions.
 hits=collections.Counter();step0=T.NesMPU.step
 actual={C.key(b,n):n for n in ['S2MainPickup','S2StandOnActor','S2MainStomp','GameLoop']}
 def observe(c):
  bank=c.memory.banks[(c.pc-0x8000)//8192]if c.pc>=0x8000 else-1
  name=actual.get((c.pc,bank))
  if name:hits[name]+=1
  return step0(c)
 T.NesMPU.step=observe
 try:
  out['unchanged_earned_source']=T.components(b,hits);out['unchanged_world_source']=T.world_components(b)
 finally:T.NesMPU.step=step0
 out['unchanged_source_Main_calls']=hits['GameLoop']
 # Actual IRQ at each newly reached private path and every temporary SMC
 # execution seam in the real GetPlayerColors caller.
 irqs=[];seen=set()
 for entry,ctrl,off,star in [('GetPlayerColors',0,0,0),('GetBackgroundColor',0,0,0),('GetPlayerColors',1,0,0),('GetPlayerColors',0,78,0),('GetPlayerColors',0,0,1),('S2MainEnd',0,0,0)]:
  q=initialized(b);q.put(VRAM_Buffer_AddrCtrl=ctrl,VRAM_Buffer1_Offset=off,StarInvincibleTimer=star,S2PaletteAck=255,GameEngineSubroutine=8,TimerControl=0)
  def probe(c,q):
   bank=q.m.banks[(c.pc-0x8000)//8192]if c.pc>=0x8000 else-1;site=(c.pc,bank)
   if site in seen:return
   if not((bank==63 and C.address(b,'S2PaletteLifecycleStart')<=c.pc<C.address(b,'S2PaletteLifecycleEnd'))or(bank==118 and C.address(b,'S2MainPalette')<=c.pc<C.address(b,'S2MainSpawn'))or 0x15a<=c.pc<0x17b):return
   seen.add(site);fork=T.Arena(b,25);list.__setitem__(fork.m,slice(None),bytes(q.m));fork.m.banks=q.m.banks.copy()
   cc=T.NesMPU(memory=fork.m,pc=c.pc);cc.a,cc.x,cc.y,cc.p,cc.sp=c.a,c.x,c.y,c.p,c.sp
   irqs.append(dict(entry=entry,PC=hex(c.pc),bank=bank,min_SP=C.interrupt(cc,fork)))
  M.run(q,entry,a=0x55,x=17,y=23,p=0x71,probe=probe)
 out['IRQ']=dict(contexts=len(irqs),minimum_SP=min(x['min_SP']for x in irqs),sites=irqs)
 out['quiet_owned_Main_incremental_cycles']=sorted(set(costs));out['layout']=dict(A63=[hex(C.address(b,'S2PaletteLifecycleStart')),hex(C.address(b,'S2PaletteLifecycleEnd'))],CORE118_end=hex(C.address(b,'S2HudCoreEnd')))
 assert C.address(b,'S2HudCoreEnd')==0xc000
 out['passed']=True;out['limits']='SourceCPU called native screen/gateway/real buffer-clear instructions, not actual PPU visible epoch/NMI scheduling. NmiClock/audio still unhooked; inherited6173/204b native negatives remain exact. Native palette/menu/gameplay review still required.'
 (O/'palette-controls.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(dict(passed=True,proof=bind(O/'palette-controls.json'),foreign=len(foreign),IRQ=len(irqs),layout=out['layout'])))

if __name__=='__main__':main()
