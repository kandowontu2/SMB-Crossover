"""Assemble the real Rogue driver and executable paged ROM reader privately.

No scheduler/Main/mixer hook is installed. Complete A480..BFFF source bytes and
all six lower banks remain represented; source PCs retain their +2000 layout.
"""
from pathlib import Path
import hashlib
import json
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT/"tools"), str(ROOT/"tools/audit")]
import rogue_dawn_map_v1 as ref
from py65.devices.mpu6502 import MPU

OUT = ROOT/"build/rogue-dawn-audio-driver-v1"
PAGES = ROOT/"build/rogue-dawn-audio-pages-v2"
SOURCE_GRAPH = ROOT/"docs/qa/rogue-dawn-audio-source-closure-2026-10-28.json"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def binding(path):
    path = Path(path).resolve()
    return dict(path=str(path), bytes=path.stat().st_size, sha256=sha(path))


def once(text, old, new):
    assert text.count(old) == 1, old
    return text.replace(old, new)


def labels(path):
    return {n: int(a, 16) for a,n in re.findall(r"^al ([0-9A-Fa-f]+) \.([^\r\n]+)$", Path(path).read_text(), re.M)}


def generate(raw, graph):
    source = ref.cpu_image(raw, a_bank=49, lower_bank=48)
    instructions = {r["pc"]: r for r in graph["instructions"]}
    words = {}
    for row in graph["dispatch_descriptions"]:
        for p in [row["address"], row["address"]+2] + list(range(row["table"], row["table"]+16, 2)):
            words[p] = source[p] | source[p+1] << 8
    for p in range(0xa7a0, 0xa7aa, 2):
        words[p] = source[p] | source[p+1] << 8
    assert all(0xa480 <= value < 0xc000 for value in words.values())
    compounds = {
        0xb386: (bytes.fromhex("91e0c8"), "jsr GuestMetroidStoreIndirectY", 3),
        0xba69: (bytes.fromhex("b1ec85ea"), "jsr RdaLoadVolume", 4),
        0xbadc: (bytes.fromhex("bc3806fe3806b1e6"), "jsr RdaAdvanceNote", 8),
        0xbb3d: (bytes.fromhex("b1e6a8"), "jsr RdaLoadNoteY", 3),
    }
    for pc, (data, _, length) in compounds.items():
        assert bytes(source[pc:pc+length]) == data
        interior = set(range(pc+1, pc+length))
        assert not (set(graph["roots"]) & interior)
        assert not [(a,b) for a,b in graph["static_edges"] if b in interior and a not in range(pc,pc+length)]
    aliases = set(words.values()) | {0xa770}
    for r in instructions.values():
        b = bytes.fromhex(r["bytes"])
        if len(b) == 3:
            v = int.from_bytes(b[1:], "little")
            if 0xa480 <= v < 0xc000:
                aliases.add(v)
        elif r["mode"] == "rel":
            aliases.add((r["pc"]+2+(b[1] if b[1]<128 else b[1]-256)) & 65535)
    aliases |= set(instructions)
    lines = ["; Generated actual source49, complete A480..BFFF; source SHA "+ref.EXPECTED]
    lines += [f"RdaN{pc:04X}=RdaUpperStart+${pc-0xa480:04x}" for pc in sorted(aliases)]
    projections = {0x10e:"RdMissileMode", 0x6878:"RdGear", 0x308:"RdVY", 0x61f:"RdBeamSfx"}
    needed = set()
    pc = 0xa480
    while pc < 0xc000:
        if pc in compounds:
            data, text, length = compounds[pc]
            lines += [f".assert *-RdaUpperStart=${pc-0xa480:04x},error,\"Source PC layout\"",
                      " "+text+f" ; original49:{pc:04X} {data.hex()}"]
            lines += [" nop"]*(length-3)
            pc += length
            continue
        if pc in instructions:
            r = instructions[pc]
            b = bytes.fromhex(r["bytes"])
            op, mode = MPU.disassemble[b[0]]
            v = int.from_bytes(b[1:], "little")
            operand = ""
            if mode == "rel":
                target = (pc+2+(b[1] if b[1]<128 else b[1]-256)) & 65535
                operand = f"RdaN{target:04X}"
            elif mode == "imm":
                operand = f"#${v:02x}"
                if pc in [0xb37e,0xb4c2,0xbc89]:
                    assert v in [0xb2,0xb3]
                    operand = f"#${v+0x20:02x}"
            elif mode == "acc":
                operand = "a"
            elif mode != "imp":
                if 0x4000 <= v <= 0x4017 and len(b) == 3:
                    if v in [0x4011,0x4017]:
                        assert op == "STA" and mode == "abs"
                        operand = "RdaDac" if v == 0x4011 else "RdaFrameControl"
                    elif mode == "aby" or v in [0x4001,0x4003,0x4005,0x4007,0x400b,0x400f]:
                        helper = "GuestNativeStore"+op+f"{v-0x4000:02x}"+("Y" if mode=="aby" else "")
                        needed.add(helper)
                        op, operand = "JSR", helper
                    else:
                        assert mode == "abs" and op in ["STA","STY"]
                        operand = f"GuestNativeApu+${v-0x4000:02x}"
                elif 0x8000 <= v < 0xa000 and len(b)==3:
                    assert op == "LDA" and mode == "aby" and v in [0x8002,0x8003,0x801a,0x804c]
                    op, operand = "JSR", f"RdaRead{v:04X}Y"
                else:
                    if v in projections and len(b)==3:
                        assert op == "LDA"
                        operand = projections[v]
                    elif 0x600 <= v < 0x700 and len(b)==3:
                        operand = f"RdaState+${v-0x600:02x}"
                    elif 0xa480 <= v < 0xc000 and len(b)==3:
                        operand = f"RdaN{v:04X}"
                    else:
                        assert len(b)==2 or v in [0xe0,0xe2], (hex(pc),r)
                        operand = f"${v:02x}" if len(b)==2 else f"${v:04x}"
                    if mode in ["zpx","abx"]:
                        operand += ",x"
                    elif mode in ["zpy","aby"]:
                        operand += ",y"
                    elif mode == "iny":
                        operand = "("+operand+"),y"
                    elif mode == "inx":
                        operand = "("+operand+",x)"
                    elif mode == "ind":
                        operand = "("+operand+")"
            lines += [f".assert *-RdaUpperStart=${pc-0xa480:04x},error,\"Source PC layout\"",
                      " "+op.lower()+(" "+operand if operand else "")+f" ;49:{pc:04X} {b.hex()}"]
            pc += len(b)
        elif pc in words:
            lines.append(f" .word RdaN{words[pc]:04X} ; source pointer49:{pc:04X}")
            pc += 2
        else:
            lines.append(f" .byte ${source[pc]:02x} ;49:{pc:04X}")
            pc += 1
    native = ROOT/"src/rogue_dawn_audio_native_v1.inc"
    native.write_text("\n".join(lines)+"\n")
    # Actual fixed62:C000 RNG. Keep the native branches and source ZP owners.
    from py65.disassembler import Disassembler
    m = ref.cpu_image(raw)
    d = Disassembler(MPU(memory=m))
    pc = 0xc000
    rng = ["RdaOriginalRng:"]
    while True:
        length, text = d.instruction_at(pc)
        op, mode = MPU.disassemble[m[pc]]
        rng.append(f"RdaRng{pc:04X}:")
        if mode == "rel":
            target = (pc+2+(m[pc+1] if m[pc+1]<128 else m[pc+1]-256))&65535
            text = op+f" RdaRng{target:04X}"
        rng.append(" "+text)
        pc += length
        if op == "RTS":
            break
        assert pc < 0xc020
    (ROOT/"src/rogue_dawn_audio_rng_v1.inc").write_text("\n".join(rng)+"\n")
    return needed


def main():
    assert not (OUT/"build-proof.json").exists(), "Keep frozen unit immutable"
    OUT.mkdir(exist_ok=True)
    raw = ref.ROM.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == ref.EXPECTED
    graph = json.loads(SOURCE_GRAPH.read_text())["graph"]
    needed = generate(raw, graph)
    parent = PAGES/"candidate.nes"
    assert sha(parent) == "4a071288e7d8d8d9f57685525bb9e35a52091686d979844da4ffb84e257ba0e2"
    names = labels(PAGES/"candidate.lbl")
    rogue_dbg = ROOT/"build/rogue-dawn-host-hazards-v1/candidate.dbg"
    for line in rogue_dbg.read_text().splitlines():
        if line.startswith("sym\t"):
            n = re.search(r'name="(RdVariant|RdMissileMode|RdGear|RdVY|RdBeamSfx)"',line)
            v = re.search(r'val=(0x[0-9A-Fa-f]+)',line)
            if n and v:
                names[n[1]] = int(v[1],0)
    needed |= set("SelectedCharacter RdVariant RdMissileMode RdGear RdVY RdBeamSfx CurrentBank CurrentBankC RgAudioRam RgAudioCpuZp GuestNativeEnable GuestNativeApu GuestMetroidStoreIndirectY RdaLowerHighTable RdaLowerBankTable".split())
    imports = OUT/"src/driver-imports.inc"
    imports.parent.mkdir(exist_ok=True)
    assert not needed-names.keys(), sorted(needed-names.keys())
    imports.write_text("\n".join(f"{n}=${names[n]:04x}" for n in sorted(needed))+"\n")
    leases = [(62,0x1d27,0x2000),(97,0x409,0x2000)]
    old = parent.read_bytes()
    for bank,lo,hi in leases:
        assert old[16+bank*8192+lo:16+bank*8192+hi] == b"\xff"*(hi-lo)
    cfg = (PAGES/"overlay/smb1base-mmc5-expanded.cfg").read_text()
    mem = {int(b,16):name for name,b in re.findall(r"^\s*(\w+):[^\n]*bank\s*=\s*\$([0-9a-f]+);",cfg,re.M|re.I)}
    extra = f'    ROGUE_AUDIO_ADAPTER_A62:load={mem[62]},type=ro,start=$bd27,optional=yes;\n    ROGUE_AUDIO_DRIVER_C97:load={mem[97]},type=ro,start=$c409,optional=yes;'
    cfg = once(cfg,"}\nSYMBOLS {",extra+"\n}\nSYMBOLS {")
    (OUT/"smb1base-mmc5-expanded.cfg").write_text(cfg)
    builder = (PAGES/"private_builder.py").read_text()
    existing = " if flag: command += ["+repr(str(ROOT/"src/rogue_dawn_audio_pages_v2.s"))+"]"
    builder = once(builder,existing,existing+"\n if flag: command += ["+repr(str(ROOT/"src/rogue_dawn_audio_driver_v1.s"))+"]")
    private = OUT/"private_builder.py"
    private.write_text(builder)
    command = [sys.executable,"-B",str(private),"--workspace",str(ROOT),"--source-overlay",str(OUT),"--output",str(OUT/"candidate.nes")]
    q = subprocess.run(command,cwd=ROOT,capture_output=True,text=True)
    if (OUT/"build.log").exists() and not (OUT/"first-build-negative.log").exists():
        (OUT/"first-build-negative.log").write_bytes((OUT/"build.log").read_bytes())
    (OUT/"build.log").write_text(q.stdout+q.stderr)
    assert q.returncode == 0,q.stdout+q.stderr
    output = OUT/"candidate.nes"
    new = output.read_bytes()
    assert len(new)==len(old) and new[:16]==old[:16] and new[16+1048576:]==old[16+1048576:]
    for bank in range(128):
        for off,(a,b) in enumerate(zip(old[16+bank*8192:16+(bank+1)*8192],new[16+bank*8192:16+(bank+1)*8192])):
            if a != b:
                assert any(bank==cb and lo<=off<hi for cb,lo,hi in leases),(bank,off)
    s = labels(OUT/"candidate.lbl")
    assert s["RdaUpperStart"]==0xc480 and s["RdaUpperEnd"]==0xe000
    report = dict(status="ASSEMBLED_PRIVATE_SOURCE_UNIT_NOT_YET_DIFFERENTIAL_QUALIFIED",native_run=False,
                  original=ref.binding(ref.ROM),parent=binding(parent),candidate=binding(output),
                  upper_source_bytes=7040,all_upper_PCs_preserved_plus_2000=True,
                  lower_source_banks_byte_complete=True,adapter_bytes=s["RdaAdapterEnd"]-s["RdaAdapterStart"],
                  no_scheduler_or_mixer_hooks=True,consumer_exclusive_APIs=True,
                  source_graph_instructions=len(graph["instructions"]),
                  limitations="Actual assembled differential, complete data reads/contexts, IRQ safety and native audio remain open. Source4011/4017 requests are private buffered bytes, not hardware publications; final mixed APU/DMC policy remains open.",
                  command=command,bindings=[binding(p) for p in [Path(__file__),SOURCE_GRAPH,imports,private,OUT/"smb1base-mmc5-expanded.cfg",ROOT/"src/rogue_dawn_audio_driver_v1.s",ROOT/"src/rogue_dawn_audio_native_v1.inc",ROOT/"src/rogue_dawn_audio_rng_v1.inc",rogue_dbg]])
    (OUT/"build-proof.json").write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps({k:report[k] for k in ["status","candidate","adapter_bytes","upper_source_bytes"]}))


if __name__=="__main__":
    main()
