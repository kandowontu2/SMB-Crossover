; Private original Rogue Dawn audio source unit. No scheduling/mixer hooks.
; All public APIs are consumer-exclusive and preserve AXYP. They are not an
; atomic foreground/NMI publication protocol. Init is required on identity entry.
.include "driver-imports.inc"
.macpack longbranch
RdaState=RgAudioRam
RdaZpState=RgAudioRam+$100
RdaSavedC=RgAudioRam+$113
RdaReadValue=RgAudioRam+$114
RdaFrameControl=RgAudioRam+$115
RdaDac=RgAudioRam+$116
RdaPtr=$e8

.macro RdaPublic
 php
 pha
 txa
 pha
 tya
 pha
 lda SelectedCharacter
 cmp #2
 jne RdaPublicReturn
 lda RdVariant
 cmp #1
 jne RdaPublicReturn
.endmacro

.segment "ROGUE_AUDIO_ADAPTER_A62"
.export RdaAudioInit,RdaAudioTick,RdaAudioSetQueue,RdaAudioSetArea,RdaAudioSetMode
.export RdaAdapterStart,RdaAdapterEnd,RdaState,RdaZpState,RdaFrameControl,RdaDac
RdaAdapterStart:
; Put the shared public return nearby to keep each identity branch in range.
RdaPublicReturn:
 pla
 tay
 pla
 tax
 pla
 plp
 rts
.proc RdaAudioInit
 RdaPublic
 lda #0
 tax
Clear:
 sta RdaState,x
 sta RdaState+$100,x
 inx
 bne Clear
 lda #3
 sta RdaZpState             ; actual source1E gameplay mode
 lda #$1d
 sta RdaZpState+3           ; explicit original LFSR seed2F
 lda #1
 sta RdaState+$80           ; original silence/init request, consumed by Tick
 sta RdaState+$2c           ; original repeating music flag
 lda #15
 sta GuestNativeEnable     ; buffered only: source has no DMC
 jmp RdaPublicReturn
.endproc
.proc RdaAudioSetQueue
 RdaPublic
 tsx
 txa
 tay
 lda $0102,y
 tax
 cpx #6
 bcs Done
 lda $0103,y
 sta RdaState+$80,x         ; actual assignment to0680..0685
Done:jmp RdaPublicReturn
.endproc
.proc RdaAudioSetArea
 RdaPublic
 tsx
 lda $0103,x
 cmp #6
 bcs Done
 sta RdaZpState+1           ; source23; lower note-bank selection
 tax
 lda NormalFlags,x
 sta RdaState+$85
Done:jmp RdaPublicReturn
NormalFlags:.byte 16,1,8,64,16,128 ; actual sourceC256
.endproc
.proc RdaAudioSetMode
 RdaPublic
 tsx
 lda $0103,x
 cmp #3
 beq Valid
 cmp #5
 bne Done
Valid:sta RdaZpState
Done:jmp RdaPublicReturn
.endproc
.proc RdaAudioTick
 RdaPublic
 lda CurrentBankC
 sta RdaSavedC
 lda #$e1                  ; exact physical97 driver, stable during A remaps
 sta CurrentBankC
 sta $5116
 jsr RdaBorrow
 jsr RdaOriginalRng
 jsr RdaNA770
 jsr RdaRelease
 lda RdaSavedC
 sta CurrentBankC
 sta $5116
 jmp RdaPublicReturn
.endproc
.proc RdaBorrow
 ldx #18
Loop:
 ldy ZpAddresses,x
 lda $0000,y
 sta RgAudioCpuZp,x
 lda RdaZpState,x
 sta $0000,y
 dex
 bpl Loop
 rts
.endproc
.proc RdaRelease
 ldx #18
Loop:
 ldy ZpAddresses,x
 lda $0000,y
 sta RdaZpState,x
 lda RgAudioCpuZp,x
 sta $0000,y
 dex
 bpl Loop
 rts
.endproc
ZpAddresses:.byte $1e,$23,$2e,$2f,$79,$e0,$e1,$e2,$e3,$e4,$e5,$e6,$e7,$e8,$e9,$ea,$eb,$ec,$ed

.macro RdaReadSave
 php
 txa
 pha
 tya
 pha
.endmacro
.macro RdaFixedReader name,base
.proc name
 RdaReadSave
 tya
 clc
 adc #<base
 sta RdaPtr
 lda #>base
 adc #0
 sta RdaPtr+1
 jsr RdaReadRom
 jmp RdaReadReturn
.endproc
.endmacro
RdaFixedReader RdaRead8002Y,$8002
RdaFixedReader RdaRead8003Y,$8003
RdaFixedReader RdaRead801AY,$801a
RdaFixedReader RdaRead804CY,$804c
.macro RdaIndirectReader name,pointer
.proc name
 RdaReadSave
 tya
 clc
 adc pointer
 sta RdaPtr
 lda pointer+1
 adc #0
 sta RdaPtr+1
 jsr RdaReadRom
 jmp RdaReadReturn
.endproc
.endmacro
RdaIndirectReader RdaReadE6Y,$e6
RdaIndirectReader RdaReadECY,$ec
RdaReadReturn:
 sta RdaReadValue
 pla
 tay
 pla
 tax
 plp
 lda RdaReadValue           ; original LDA changes NZ, preserves CV/DI
 rts
; Compound source instruction replacements retain every original upper PC.
.proc RdaLoadVolume
 jsr RdaReadECY
 sta $ea
 rts
.endproc
.proc RdaAdvanceNote
 ldy RdaState+$38,x
 inc RdaState+$38,x
 jmp RdaReadE6Y
.endproc
.proc RdaLoadNoteY
 jsr RdaReadE6Y
 tay
 rts
.endproc
RdaAdapterEnd:
.assert RdaAdapterEnd-RdaAdapterStart<=$2d9,lderror,"Rogue audio adapter exceeds root BD27..BFFF lease"

.segment "ROGUE_AUDIO_DRIVER_C97"
.export RdaDriverStart,RdaUpperStart,RdaUpperEnd,RdaReadRom,RdaOriginalRng
RdaDriverStart:
; Called only by the A62 wrappers with A62 currently mapped. Leave the actual
; software A-bank shadow and hardware together, including each temporary map.
.proc RdaReadRom
 lda RdaPtr+1
 cmp #$a0
 bcs Upper
 lda $23
 asl a
 asl a
 asl a
 asl a
 asl a
 clc
 adc RdaPtr+1
 sec
 sbc #$80
 tax
 lda RdaLowerHighTable,x
 sta RdaPtr+1
 lda RdaLowerBankTable,x
 sta CurrentBank
 sta $5115
 ldy #0
 lda (RdaPtr),y
 pha
 lda #$be
 sta CurrentBank
 sta $5115
 pla
 rts
Upper:
 ; Raw lower-bank descriptors may contain original A480..BFFF pointers.
 ; Translate the read, preserving the byte-complete original page depot.
 clc
 adc #$20
 sta RdaPtr+1
 ldy #0
 lda (RdaPtr),y
 rts
.endproc
.include "rogue_dawn_audio_rng_v1.inc"
.res $77-(*-RdaDriverStart),$ff
RdaUpperStart:
.include "rogue_dawn_audio_native_v1.inc"
RdaUpperEnd:
.assert RdaUpperStart-RdaDriverStart=$77,lderror,"Original A480 source remains at C480"
.assert RdaUpperEnd-RdaUpperStart=$1b80,lderror,"Complete original upper span retained"
